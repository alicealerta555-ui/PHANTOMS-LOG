# Integration Contract – Etappe 12

## Input
Nach erfolgreicher ActionPipeline-Resolution liefert der Host:
- `ResolvedGameplayEvent`
- Liste der NPCs, die die Handlung tatsächlich wahrgenommen haben
- je NPC einen Snapshot der bereits kanonischen Actor-Eigenschaften

## Actor Snapshot
Die NPC-Lernschicht darf Actor-Intelligenz, Kompetenz, Vertrauen, Offenheit, Sturheit, Eigeninteresse, Rollen- und Werte-Tags lesen.
Sie darf diese Werte nicht neu definieren oder überschreiben.

## Output
Pro NPC optional:
- dialogue hook
- memory note
- ordinary behavior hint
- suggested alternative

Kein Output darf:
- Player Hidden Insight IDs an NPCs vergeben
- Hidden World Truth enthalten
- irreversible Actor-State-Änderungen ohne State Authority committen

## Order
1. authoritative action resolution
2. player adaptive learning
3. NPC observation of visible result
4. optional dialogue/memory/behavior proposal
5. host/Actor Runtime decides/commits NPC behavior

## Persistence
NPC observational state is separate from player progression state.
