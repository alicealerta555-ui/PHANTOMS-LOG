# Integration Contract – Etappe 16

Host liefert nur wahrnehmbare Itemdaten und explizit freigegebene Diagnoseinformation.

Pflichttrennung:
- sichtbarer Schaden != versteckter Schaden
- Interesse != Wissen
- technische Modifikation != biologische Eignung
- NPC-Vorschlag != objektiv beste Lösung

Host-Einstieg:
- `AdaptiveGameplayRuntime.evaluate_item_of_interest(...)`
- `AdaptiveGameplayRuntime.revisit_item_topic(...)`

Persistenz:
- `npc_item_interest` liegt separat im Adaptive-Runtime-Snapshot.
