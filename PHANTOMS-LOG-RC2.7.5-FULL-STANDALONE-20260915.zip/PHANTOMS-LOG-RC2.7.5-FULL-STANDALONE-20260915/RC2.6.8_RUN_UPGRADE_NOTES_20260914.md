# RC2.6.8 Run Upgrade Notes

This package is intended to be usable as a replacement engine/content master for an existing full-version run.

- Keep the existing save/profile data unchanged.
- Load the run through RC2.6.8 using the same save root / same run identity.
- RC2.6.8 does not require a new character or new run solely because of the version update.
- New persistent-world state is run-scoped and initializes lazily when absent.
- Existing canonical save state remains authoritative.
- Internal legacy loot aliases are no longer valid player-facing loot names; active Stage-11 tables now reference concrete canonical item definitions.

If a save fails structural/identity validation, the runtime fails closed rather than silently creating a replacement run.
