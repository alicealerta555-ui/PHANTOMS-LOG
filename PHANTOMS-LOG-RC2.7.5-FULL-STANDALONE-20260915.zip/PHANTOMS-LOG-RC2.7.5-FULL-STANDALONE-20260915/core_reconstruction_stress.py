#!/usr/bin/env python3
from runtime.core.world_sim import PHASES, RelevanceTier, SimulationCadence, SimulationEvent, WorldSimOrchestrator
from runtime.stage3a.integration import RuntimeAuthorityBridge, RuntimeDelta
from runtime.stage3a.kernel import CommitKernel, StateStore


def main() -> None:
    checks = 0
    events = 0
    for batch in range(100):
        kernel = CommitKernel(StateStore(), world_seed=9000 + batch)
        bridge = RuntimeAuthorityBridge(kernel)

        def p4(ctx):
            return (RuntimeDelta(
                domain="RUNTIME_STATE",
                key="synthetic.core_stress_tick",
                value=ctx.event.tick,
                producer="RULE_KERNEL",
                cause=ctx.event.cause,
            ),)

        orch = WorldSimOrchestrator(
            bridge,
            cadence=SimulationCadence(1, 5, 20),
            producers={"P4": p4},
        )
        for local in range(1, 11):
            events += 1
            eid = f"core-stress-{batch}-{local}"
            result = orch.run(
                SimulationEvent(eid, "synthetic_world_tick", f"seed:{eid}", RelevanceTier.HOT, local),
                narration_runtime_keys=("synthetic.core_stress_tick",),
            )
            assertions = (
                result.processed is True,
                result.phase_order == PHASES,
                kernel.store.revision == local,
                kernel.store.runtime_state.get("synthetic.core_stress_tick") == local,
                "WORLD_TRUTH" not in result.presentation,
                "ACTOR_KNOWLEDGE" not in result.presentation,
                "UNRESOLVED_WORLD" not in result.presentation,
                result.presentation["PRESENTATION_RUNTIME"].get("synthetic.core_stress_tick") == local,
                result.commit is not None,
                getattr(result.commit, "event_id", None) == eid,
            )
            for ok in assertions:
                if not ok:
                    raise SystemExit(f"CORE_RECONSTRUCTION_STRESS=FAIL batch={batch} local={local} check={checks+1}")
                checks += 1
    assert checks == 10_000
    print(f"CORE_RECONSTRUCTION_STRESS=PASS CHECKS={checks} EVENTS={events}")


if __name__ == "__main__":
    main()
