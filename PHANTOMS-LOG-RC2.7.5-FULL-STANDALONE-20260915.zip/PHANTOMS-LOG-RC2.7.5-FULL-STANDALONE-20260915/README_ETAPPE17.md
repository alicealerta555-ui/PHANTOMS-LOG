# Etappe 17 — NPC Lived Experience

Diese Etappe ergänzt das bestehende NPC-System um soziale Kontinuität und Alltag.

Ein NPC kann gerade müde, hungrig, gestresst, verletzt oder beschäftigt sein. Das beeinflusst, ob er ausführlich spricht, nur knapp antwortet, ein Thema vertagt oder lediglich sichtbares Interesse zeigt.

Die Schicht ist absichtlich keine zweite Entscheidungs-KI. Sie konsumiert den autoritativen Actor-/World-State des Hosts und übersetzt ihn in glaubwürdiges soziales Verhalten.

### Kernfluss
Actor State + Situation + Beziehung + Thema
→ soziale Verfügbarkeit
→ ENGAGE / BRIEF / DEFER / DECLINE / INITIATE / SILENT
→ sichtbare Körpersprache / kurzer Dialoghinweis / späteres Wiederaufgreifen

### Wichtig
NPCs dürfen das Gespräch beenden und ihre Arbeit fortsetzen. Sie müssen dem Spieler nicht jederzeit zur Verfügung stehen.
