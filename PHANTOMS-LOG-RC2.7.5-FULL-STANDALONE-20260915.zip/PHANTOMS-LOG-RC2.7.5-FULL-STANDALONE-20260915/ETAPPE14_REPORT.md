# PH4NT0M5-L0G RC2.2 — Etappe 14: NPC First Contact & Introduction Logic

Status: IMPLEMENTED / TESTED / PASS

## Scope
Etappe 14 verbindet die persistente NPC-Namenslogik aus Etappe 13 mit einer epistemisch sicheren Erstbegegnungs- und Vorstellungslogik.

## Kernregeln
- Ein unbekannter NPC wird nicht automatisch mit Namen vorgestellt.
- Zufällige Sichtung erzeugt standardmäßig keine Selbstvorstellung.
- Name/Callsign/Vollname werden abhängig von Situation und sozialem Verhalten stufenweise enthüllt.
- Feindseligkeit, Gefahr und Zeitdruck können Vorstellungen blockieren.
- Callsign kann als primärer sozialer Rufname dienen.
- Profession wird niemals aus sichtbaren Indizien als Fakt inferiert.
- Sichtbare Berufsindizien dürfen beschrieben werden; der Berufsname bleibt unbekannt, bis er plausibel bekannt ist.
- Namenswissen wächst monoton und springt nicht zurück.
- Persistente Trennung von wahrer Identität und Spielerwissen.

## Neue Runtime
`runtime/player_progression/npc_encounter.py`

Wichtige Typen:
- `NPCVisualSnapshot`
- `NPCEncounterContext`
- `NPCPresentationProfile`
- `NPCPlayerKnowledge`
- `NPCEncounterRegistry`
- `NPCFirstContactResult`
- `NPCFirstContactEngine`

## Host-Integration
`AdaptiveGameplayRuntime` unterstützt jetzt zusätzlich:
- `attach_npc_identity()`
- `ensure_npc_name()`
- `present_npc()`
- persistentes Speichern/Laden von Naming Registry + First-Contact Knowledge

## Tests
Gesamtsuite: 128/128 PASS

Abgedeckt:
- keine automatische Vorstellung bei Zufallsbegegnung
- keine Berufs-Leaks aus Indizien
- bekannte Rolle darf korrekt angezeigt werden
- Feindseligkeit blockiert Namensenthüllung
- Callsign-only Vorstellung
- formelle Vollnamensvorstellung
- Gefahr blockiert selbst formelle Vorstellung
- Namenswissen ist monoton
- Persistenz des Spielerwissens
- sichtbare Beschreibung enthält nur gelieferte Wahrnehmungsdaten
- Adaptive Runtime Roundtrip mit NPC-Identity Layer
