# RC2.7.3 Working Validation — Crew & Organization

Date: 2026-09-15

## Result

**PASS — feature block and complete current regression set**

### Executed test evidence

- `tests/`: **4608/4608 PASS**
- pytest subtests: **23 PASS**
- capability tree / talent scenario / binding / action policy: **3025/3025 PASS**
- `tests_stage5/`: **216/216 PASS**
- Playable full-version selftest: **PASS**
- compileall active Python roots: **PASS**

### Architecture / release gates

All executed PASS:

- Runtime-I9 single-writer through Integrity Harness
- Full-Version transition
- CONTENT-S6 biology
- CONTENT-S7 needs
- CONTENT-S8 world/travel/information
- CONTENT-S10 dungeon/ecology
- active reference audit
- Full-Version master/status audit
- master merge/closure audit
- Lifetime-start audit
- class tutorial/two-start-talent audit
- Crew & Organization capability audit
- RC2.7.0 frozen base-release metadata audit

### New Crew/Organization invariants verified

- Breaker, Ghost, Operator and Resonant have distinct capacity curves.
- Social organization capacity and command span are separate axes.
- Controller/Drohnenwart uses a narrow four-skill core line.
- Operator machine bandwidth scales substantially above human direct-crew scale.
- Resonant large-organization scale exceeds the other classes at late progression.
- large organizations require actual delegated ranks rather than Social score alone.
- Stage-17 crew roles and Stage-24 ranks remain distinct.
- recruitment requires candidate acceptance.
- companion/hierarchical orders remain actor-decision requests.
- machine profiles provide machine functions without changing player skill values.
- team templates bridge existing dungeon/loot/travel/labor/industry systems.
- group operations cannot auto-resolve authoritative subsystem results.
- operation completion requires an authoritative result reference.
- no class is hard-blocked from a team template.

### Wrapper note

The single all-in-one validator process exceeded the execution tool's wall-time while in the pytest phase. The pytest collection was therefore completed in explicit shards and summed to the complete **4608** tests. All remaining validator commands were then executed separately and passed. This is a tooling/runtime-window limitation, not a skipped regression gate.
