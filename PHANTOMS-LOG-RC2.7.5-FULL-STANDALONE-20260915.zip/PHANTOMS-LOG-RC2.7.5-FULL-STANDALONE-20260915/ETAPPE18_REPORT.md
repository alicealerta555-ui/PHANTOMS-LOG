# Etappe 18 – Psychological State & Supportive Dialogue

Implemented: compact non-diagnostic psychological state, trigger/avoidance themes, coping-compatible support, ordinary short supportive dialogue, voluntary positive exposure, boundary respect, no instant cure, pressure penalties, persistence.

Core rule: diagnosis never defines personality, morality, intelligence or violence. Support creates safety/recovery memories; severe burdens are not erased by one conversation.
