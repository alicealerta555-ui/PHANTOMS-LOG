# RC2.5.1 Content Variation Patch — 2026-09-13

## Added
- Data-item content schema V2 with 10 content records.
- Each content record now has a title, document type, canonical facts, and at least three bounded presentation variants.
- Run-stable deterministic presentation selection based on `run_uuid + content_id`.
- `CONTENT_VARIATION_PROMPT_CORE.md` for LLM-facing wording variation.
- Knowledge commit stores canonical facts and the selected variation provenance.

## Invariants
- Variation is presentation-only.
- No new world facts, identities, causes, locations, quest state, items, ownership, encryption state, or access rights may be invented.
- Same run + same content item => same selected variant.
- New run may select a different allowed variant.

## Validation
- Dedicated variation tests: PASS.
- Relevant content/information/quest/trade regression subset: 45/45 PASS.
