# PHANTOMS-LOG

**RC2.7.0 — FULL MASTER RELEASE · 2026-09-15**

**Current package overlay:** RC2.7.2 working overlay — lifetime history + two-start-talent class tutorial. The underlying frozen base release remains RC2.7.0 FULL MASTER; this development package is therefore intentionally named **Working Master**, not a new FULL Master.

PHANTOMS-LOG is an experimental persistent AI-assisted text RPG and game-runtime project. The language model is a bounded presentation/decision component; canonical world state remains owned by the runtime.

## Current authority

This package is the **RC2.7.2 Working Master overlay** on the frozen **RC2.7.0 FULL Master** base. The base remains the last promoted FULL Master; the current package adds validated lifetime-history and class-tutorial work without claiming a new FULL Master or Standalone promotion. Current source code and passing tests outrank older reports if prose conflicts. Start with:

1. `RC2.7.2_LIFETIME_CLASS_TUTORIAL_WORKING_REPORT.md`
2. `RELEASE_VALIDATION_RC2.7.2_WORKING.md`
3. `OPEN_WORK_RC2.7.2.md`
4. `FULL_MASTER_RELEASE.md`
5. `PROJECT_STATUS_RC2.7.0.md`
6. `CURRENT_REFERENCES.md`
7. `master/PROJECT_MASTER.md`

This release deliberately does **not** use the label `Standalone`: standalone status is reserved for a package that also carries the complete current continuation/thought/change context required to continue development without any external project context.

## Character and capability model

The former character foundation has been replaced by one canonical tree:

**10 Stats → 30 Skills → 26 Talents → use-earned Expertises → class/path specialization**

Classes do not create a second physical or supernatural ruleset. BREAKER, GHOST, OPERATOR and RESONANT specialize the same character tree.

Actions are resolved through staged capability chains:

**INPUT → INTERPRET → SETUP → EXECUTE → CONTROL**

The runtime determines a performance zone before ordinary success resolution:

- `SAFE` — reliably inside current capability; no artificial success roll required.
- `EDGE` — genuinely uncertain; normal resolution applies.
- `EXTREME` — possible but strongly outside reliable application; warn first.
- `HARD_LIMIT` — a required natural/current limit is not met; no success roll may override it.
- `INACCESSIBLE` — required technique/skill/talent is unavailable.

Earlier successful stages remain valid when a later stage fails. A character may perceive correctly and fail at focus, choose the correct silent foothold and fail at balance, or use correct lifting technique while lacking the required strength.

Expertise improves reliability and efficiency through validated use; it does not silently raise natural stat limits.

## Classes and supernatural layer

All characters use the same human capability substrate. `STAT_RES` (Resonance) represents natural coupling capacity to the setting's supernatural resonance layer. Classes specialize that layer differently:

- **BREAKER** — force, endurance, protection, banishing/manifestation pressure.
- **GHOST** — stealth, mobility, perception, concealment, threshold/astral tracing.
- **OPERATOR** — technology, diagnostics, ritual construction, containment and artifact engineering.
- **RESONANT** — direct resonance perception/control, echo work, entity contact, divination and related supernatural perception.

Supernatural material is a fictional game system inspired by occult/esoteric traditions, not a claim of real-world scientific validity.

## AI image pipeline

Images are subordinate to canonical state:

**visible game state → structured visible scene → AI-authored image prompt → image generator**

Hidden state, unknown rooms, secret NPC information and unperceived facts may not be inserted into an image prompt. The image never becomes world-state evidence.

## NPC and world direction

NPCs are persistent simulated actors with memory, needs, relationships, risk, self-interest, role constraints and security boundaries. Friendly behavior does not imply obedience. Current design direction also reserves later work for real-life-inspired NPC mindset templates; this is recorded as pending work, not a completed feature.

## Quick start

```bash
chmod +x START_GAME.sh
bash START_GAME.sh --class OPERATOR
```

Other base classes: `BREAKER`, `GHOST`, `RESONANT`.

Useful commands include:

```text
/stats
/skills
/talente
/tutorial
/expertisen
/abilities
/character
/look
/save
/quit
```

See `START_HIER.md` and `CHAT_SPIELSTART.md` for the active playable host contract.

## Validation

Run the complete release gate:

```bash
bash run_full_version_validation.sh
```

The validation record for this working overlay is `RELEASE_VALIDATION_RC2.7.2_WORKING.md`. The frozen base-release record remains `RELEASE_VALIDATION_RC2.7.0.md`.

## License

Original project material covered by this repository is distributed under GPL-3.0. See `LICENSE` and `THIRD_PARTY_NOTICES.md`.
