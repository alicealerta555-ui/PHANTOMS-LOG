# PHANTOMS-LOG RC2.7.5 — FULL STANDALONE

A self-contained AI-assisted text-RPG runtime and world package built around authoritative persistent state rather than free-form model invention.

This release closes the current mission/profession layer, class progression quest content, Level-50 legend capstones, persistent quest groups, organization operations and production/logistics systems. Every profession can attempt every mission; skills, preparation, equipment, crew and circumstances determine how difficult that work is, and failure is a real persistent outcome.

## Start
Run `START_GAME.sh` on the supported local setup or launch the playable full-version entry point described in `README.md`.

## Validation
4,663 main tests PASS; 216 Stage-5 tests + 266 subtests PASS; closure and release audits PASS.
