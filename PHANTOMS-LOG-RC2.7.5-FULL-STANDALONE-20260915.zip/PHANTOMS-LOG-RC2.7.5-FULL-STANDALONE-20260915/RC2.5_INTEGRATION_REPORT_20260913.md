# PH4NT0M5-L0G — RC2.5 Playable Integration Report

Date: 2026-09-13

## Scope

RC2.5 closes the RC2.4 playtest wiring gaps between parser/playable host, deterministic resolvers, static data, State/Knowledge authority, CommitKernel persistence and presentation.

## Completed integration matrix

| Area | RC2.5 state |
|---|---|
| SEARCH | Playable; persistent bounded search state; world-time cost |
| Resource hooks | 100 location-specific resource profiles over category/biome plausibility |
| Information hooks | Persistent direct-observation knowledge; mission discovery keys |
| Loot spawning | Real item instances with provenance, condition, location and later ownership |
| TALK | Real co-located NPC actors; identity learned through actor knowledge |
| NPC runtime names | 45 deterministic run-persistent generated identities |
| NPC inventories | Real item instances per role; queryable without invention |
| TRADE | BUY and SELL; atomic credits + item transfer + owner correction |
| CRAFT | Real inputs consumed; persistent outputs; skill/time gates |
| REPAIR | Owned damaged targets only; bounded condition repair; real input consumption |
| TREAT | Medical skill/input gate; bounded HP heal; visible actor mirror updated |
| Data items | 10 content records; terminal requirement; encryption/NETWORKS capability gate; knowledge commit |
| Interactables | Concrete objects for all 100 locations |
| Quest discovery | SEARCH-derived unverified leads feed prerequisite knowledge |
| Quest-giver mapping | Legacy issuer-role names mapped to actual runtime NPC roles |
| Quests | 4 templates: offer -> accept -> concrete asset/target -> progress -> completion |
| Quest consequences | Completion emits authority-owned consequence candidates, not narration writes |
| Progression | Only committed semantic player actions feed hidden adaptive progression |
| NPC day routines | World-time slots; route-connected deterministic movement; save-persistent |
| Start classes | BREAKER/GHOST/OPERATOR/RESONANT only; old productive start profiles absent |
| Prompt cores | 10 bounded authority/presentation prompt contracts present |
| Image path | Explicit presentation-only boundary; verified not to mutate game state |
| Scene/location variation | Run-stable contextual location naming + existing arrival variation |

## Content improvements

- Generic `Tool Item ###`, `Data Item ###`, etc. display names were replaced with usable world item names.
- All 15 field operations now have meaningful names and are exposed as craft, repair or treatment operations.
- Quest-specific runtime items include Reaktorschlüssel, Archivkern, Pumpenregler and Karawanenfracht.
- Hidden quest assets cannot be acquired before discovery merely by guessing an instance ID.

## Authority invariants retained

- Static content never contains mutable player/run state.
- Runtime state remains isolated by player UUID and run UUID.
- Search and dialogue prompts cannot invent items, knowledge or state.
- Failed/blocked actions do not train player progression.
- NPC movement updates canonical actor state and the Stage-9 visible mirror together.
- Images remain presentation artifacts and cannot commit world truth.

## Validation

- Full pytest suite: 1656 passed.
- Pytest subtests: 289 passed.
- Full-version transition audit: PASS.
- Full-version master audit: PASS.
- Reference audit: PASS.
- Playable package selftest: PASS.
