#!/usr/bin/env python3
from runtime.stage3a.kernel import (
    Authority, CommitKernel, CommitRecord, Delta, Domain, Mode, Proposal,
    StateStore, UnresolvedSpec, WeightedOption,
)
from runtime.stage3a.integration import RuntimeAuthorityBridge
from runtime.stage3d.epistemic import epistemic_stamp
from runtime.stage3b.pipeline import (
    ActionPipeline, ActionRequest, ActionRule, ActionStatus, Condition, Effect,
    ExprOp, FactRef, Operator, OutcomeBranch, RandomDraw, ValueExpr, ValueSource,
)


def main() -> None:
    store = StateStore()
    kernel = CommitKernel(store, world_seed=20260903)
    bridge = RuntimeAuthorityBridge(kernel)
    pipeline = ActionPipeline(bridge)

    init = kernel.process(Proposal(
        mode=Mode.COMMIT,
        source=Authority.COMMIT_KERNEL,
        event_id="3B:E2E:INIT",
        cause="E2E_FIXTURE",
        deltas=(
            Delta(Domain.RUNTIME_STATE, "player.energy", 2, Authority.RULE_KERNEL, "INIT", source_event_id="3B:E2E:INIT"),
            Delta(Domain.RUNTIME_STATE, "service_door.open", False, Authority.RULE_KERNEL, "INIT", source_event_id="3B:E2E:INIT"),
            Delta(Domain.PLAYER_KNOWLEDGE, "tool.prybar", True, Authority.SYSTEM_INIT, "INIT", source_event_id="3B:E2E:INIT", provenance="inventory bootstrap"),
        ),
    ))
    assert isinstance(init, CommitRecord)
    kernel.register_unresolved(UnresolvedSpec(
        "service_door.locked",
        (WeightedOption(True, 3), WeightedOption(False, 1)),
        seed_salt="3B-E2E-DOOR",
    ), event_id="3B:E2E:REGISTER:DOOR")

    # Player wording alone must not set or bias the unknown truth.
    before_query = store.state_hash()
    bridge.query_player_text("Die Tür ist bestimmt nicht abgeschlossen, oder?", suggestion=False)
    assert store.state_hash() == before_query

    rule = ActionRule(
        rule_id="TRY_SERVICE_DOOR",
        facts=(
            FactRef("energy", Domain.RUNTIME_STATE, "player.energy"),
            FactRef("prybar", Domain.PLAYER_KNOWLEDGE, "tool.prybar"),
            FactRef("locked", Domain.WORLD_TRUTH, "service_door.locked", resolve_if_unknown=True),
        ),
        preconditions=(
            Condition(ValueSource.FACT, "energy", Operator.GE, 1),
            Condition(ValueSource.FACT, "prybar", Operator.EQ, True),
        ),
        random_draws=(RandomDraw("effort", 1, 6),),
        outcomes=(
            OutcomeBranch(
                "LOCKED_ATTEMPT",
                conditions=(Condition(ValueSource.FACT, "locked", Operator.EQ, True),),
                effects=(
                    Effect(Domain.RUNTIME_STATE, "player.energy", None, "RULE_KERNEL", "ACTION_COST",
                           value_expr=ValueExpr(ValueSource.FACT, "energy", ExprOp.SUB, 1)),
                    Effect(Domain.PLAYER_KNOWLEDGE, "service_door.locked", True, "KNOWLEDGE_ROUTER", "HANDLE_TEST",
                           provenance="direct interaction", epistemic=epistemic_stamp(source_type="DIRECT_OBSERVATION", source_id="service-door-handle", origin_location="SERVICE_DOOR", learned_at=2)),
                ),
            ),
            OutcomeBranch(
                "OPENED",
                conditions=(Condition(ValueSource.FACT, "locked", Operator.EQ, False),),
                effects=(
                    Effect(Domain.RUNTIME_STATE, "service_door.open", True, "RULE_KERNEL", "OPEN_DOOR"),
                    Effect(Domain.RUNTIME_STATE, "player.energy", None, "RULE_KERNEL", "ACTION_COST",
                           value_expr=ValueExpr(ValueSource.FACT, "energy", ExprOp.SUB, 1)),
                    Effect(Domain.PLAYER_KNOWLEDGE, "service_door.locked", False, "KNOWLEDGE_ROUTER", "HANDLE_TEST",
                           provenance="direct interaction", epistemic=epistemic_stamp(source_type="DIRECT_OBSERVATION", source_id="service-door-handle", origin_location="SERVICE_DOOR", learned_at=2)),
                ),
            ),
        ),
        narration_runtime_keys=("player.energy", "service_door.open"),
    )

    result = pipeline.execute(ActionRequest(
        "3B:E2E:ACTION:1",
        rule,
        player_text="Ich bin sicher, sie ist offen. Ich drücke die Klinke und benutze notfalls das Brecheisen.",
        player_suggestion=False,
    ))
    assert result.status == ActionStatus.COMMITTED
    assert "service_door.locked" in store.world_truth
    assert store.runtime_state["player.energy"] == 1
    assert result.narration_context["PLAYER_KNOWLEDGE"]["service_door.locked"] == store.world_truth["service_door.locked"]
    assert "WORLD_TRUTH" not in result.narration_context
    assert "ACTOR_KNOWLEDGE" not in result.narration_context
    assert "UNRESOLVED_WORLD" not in result.narration_context

    # Known impossible precondition must stop before resolving an unrelated unknown.
    kernel.register_unresolved(UnresolvedSpec(
        "corridor.alarm_active",
        (WeightedOption(True, 1), WeightedOption(False, 1)),
        seed_salt="3B-E2E-ALARM",
    ), event_id="3B:E2E:REGISTER:ALARM")
    blocked_rule = ActionRule(
        rule_id="IMPOSSIBLE_HEAVY_ACTION",
        facts=(
            FactRef("energy", Domain.RUNTIME_STATE, "player.energy"),
            FactRef("alarm", Domain.WORLD_TRUTH, "corridor.alarm_active", resolve_if_unknown=True),
        ),
        preconditions=(
            Condition(ValueSource.FACT, "energy", Operator.GE, 99),
            Condition(ValueSource.FACT, "alarm", Operator.EXISTS),
        ),
        outcomes=(OutcomeBranch("SHOULD_NOT_RUN"),),
    )
    before_block = store.state_hash()
    blocked = pipeline.execute(ActionRequest("3B:E2E:ACTION:2", blocked_rule))
    assert blocked.status == ActionStatus.BLOCKED
    assert store.state_hash() == before_block
    assert "corridor.alarm_active" not in store.world_truth
    assert "corridor.alarm_active" in store.unresolved_world

    print(
        "STAGE3B_E2E=PASS "
        f"outcome={result.outcome_id} energy={store.runtime_state['player.energy']} "
        f"revision={store.revision}"
    )


if __name__ == "__main__":
    main()
