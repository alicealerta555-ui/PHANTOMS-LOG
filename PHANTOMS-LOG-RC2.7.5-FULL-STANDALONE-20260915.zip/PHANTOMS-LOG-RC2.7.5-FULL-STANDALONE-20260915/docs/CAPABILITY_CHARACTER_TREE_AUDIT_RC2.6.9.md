# PHANTOMS-LOG RC2.6.9 – Character Capability Tree Audit

## Authority

`Stats → Skills → Talente → Expertisen → Klassenbaum`

Der Klassenbaum spezialisiert den Charakterbaum und darf natürliche Grenzen nicht überschreiben. Expertise verbessert Zuverlässigkeit innerhalb vorhandener Grenzen; sie erhöht keine natürliche Hard-Limit-Grenze.

## Stats (10)

| ID | Name | Bedeutung |
|---|---|---|
| `STAT_STR` | Kraft | Natürliche mechanische Kraftgrenze. |
| `STAT_END` | Ausdauer | Belastung, Ermüdung und körperliche Dauerleistung. |
| `STAT_MOB` | Beweglichkeit | Grobmotorik, Bewegungsumfang und Körperpositionierung. |
| `STAT_DEX` | Präzision | Feinmotorik und exakte kontrollierte Bewegung. |
| `STAT_REA` | Reaktion | Zeitgerechte Auswahl und Einleitung einer Handlung. |
| `STAT_PER` | Wahrnehmung | Qualität der sensorischen Informationsaufnahme. |
| `STAT_COG` | Kognition | Verarbeitung, Gedächtnis, Schlussfolgern und Planung. |
| `STAT_WIL` | Selbstkontrolle | Fokus, Stresskontrolle und willentliche Stabilität. |
| `STAT_SOC` | Sozialwahrnehmung | Erfassen und Verarbeiten sozialer Signale. |
| `STAT_RES` | Resonanz | Natürliche Kopplungsgrenze an die übernatürliche Resonanzebene. |

## Skills (30)

| Skill | Stat-Wurzeln | Fähigkeitskette | typische Situationen | Expertise-Beispiele |
|---|---|---|---|---|
| `SKILL_ATHLETICS` Athletik | STAT_MOB, STAT_STR, STAT_END | SETUP(STAT_MOB) → EXECUTE(STAT_STR/STAT_MOB) → CONTROL(STAT_END) | klettern, springen, rennen, schwimmen, hindernisse überwinden | Trümmerklettern, Langstreckenlauf, enge Schächte, nasse Oberflächen |
| `SKILL_FORCE_APPLICATION` Kraftanwendung | STAT_PER, STAT_MOB, STAT_COG, STAT_STR, STAT_END | INPUT(STAT_PER) → SETUP(STAT_MOB/STAT_COG) → EXECUTE(STAT_STR) → CONTROL(STAT_END) | heben, drücken, ziehen, halten, aufbrechen, schwere lasten bewegen | schwere Lasten, Hebelarbeit, verklemmte Türen, Bergung |
| `SKILL_LOAD_CONTROL` Belastungskontrolle | STAT_END, STAT_WIL | INPUT(STAT_END) → SETUP(STAT_WIL) → CONTROL(STAT_END/STAT_WIL) | lange belastung, atemkontrolle, marsch, schmerz unter kontrolle, erschöpfung managen | Höhenmarsch, Hitze, Atemrhythmus, Schmerzmanagement |
| `SKILL_BALANCE` Balance | STAT_PER, STAT_MOB, STAT_DEX, STAT_REA | INPUT(STAT_PER) → EXECUTE(STAT_MOB) → CONTROL(STAT_DEX/STAT_REA) | schmale flächen, rutschiger boden, instabile konstruktionen, gleichgewicht halten | Metallstreben, Dächer, Schiffsdecks, Geröll |
| `SKILL_ACROBATICS` Akrobatik | STAT_PER, STAT_MOB, STAT_REA, STAT_DEX | INPUT(STAT_PER) → SETUP(STAT_MOB) → EXECUTE(STAT_MOB/STAT_REA) → CONTROL(STAT_DEX) | rollen, vault, komplexe sprünge, abfangen, enge bewegungen | Parkour, Fensterdurchstieg, Sturzrollen, Leiterwechsel |
| `SKILL_STEALTH` Schleichen | STAT_PER, STAT_COG, STAT_MOB, STAT_DEX, STAT_REA | INPUT(STAT_PER) → INTERPRET(STAT_COG) → EXECUTE(STAT_MOB/STAT_DEX) → CONTROL(STAT_REA) | schleichen, versteckt bewegen, geräusche vermeiden, sichtlinien meiden | Metallböden, Laub, Menschenmengen, Industriehallen |
| `SKILL_AIM_CONTROL` Zielkontrolle | STAT_PER, STAT_COG, STAT_DEX, STAT_REA, STAT_WIL | INPUT(STAT_PER) → INTERPRET(STAT_COG) → EXECUTE(STAT_DEX/STAT_REA) → CONTROL(STAT_WIL) | werfen, schießen, präzise angriffe, bewegte ziele | Kurzdistanzen, bewegte Ziele, schlechte Sicht, enge Schussfenster |
| `SKILL_FINE_MECHANICS` Feinmechanik | STAT_PER, STAT_COG, STAT_DEX, STAT_WIL | INPUT(STAT_PER) → INTERPRET(STAT_COG) → EXECUTE(STAT_DEX) → CONTROL(STAT_WIL) | kleinteile, schlösser, kontakte, feine werkzeuge, präzisionsmontage | Mikrostecker, Feinlager, Ventile, mechanische Schlösser |
| `SKILL_TECHNOLOGY` Technik | STAT_PER, STAT_COG, STAT_DEX | INPUT(STAT_PER) → INTERPRET(STAT_COG) → SETUP(STAT_COG/STAT_DEX) → EXECUTE(STAT_DEX) | maschinen, mechanik, reparatur, wartung, technische manipulation | Hydraulik, Antriebe, Pumpen, Industrieanlagen |
| `SKILL_ELECTRONICS` Elektronik | STAT_PER, STAT_COG, STAT_DEX, STAT_WIL | INPUT(STAT_PER) → INTERPRET(STAT_COG) → EXECUTE(STAT_DEX) → CONTROL(STAT_WIL) | schaltungen, sensoren, verkabelung, stromversorgung, elektronische reparatur | Sensorbusse, Leistungsstufen, Platinen, Feldverkabelung |
| `SKILL_NETWORKS` Netzwerke | STAT_PER, STAT_COG, STAT_WIL | INPUT(STAT_PER) → INTERPRET(STAT_COG) → SETUP(STAT_COG) → CONTROL(STAT_WIL) | netzwerke, datenzugriff, protokolle, schnittstellen, signalpfade | Industrieprotokolle, Mesh-Netze, alte Bussysteme, gesicherte Terminals |
| `SKILL_DIAGNOSTICS` Diagnostik | STAT_PER, STAT_COG, STAT_WIL | INPUT(STAT_PER) → INTERPRET(STAT_COG) → CONTROL(STAT_WIL) | fehleranalyse, ursachen finden, zustand bewerten, vergleich von symptomen | Maschinenfehler, Sensorfehler, Mehrfachausfälle, intermittierende Fehler |
| `SKILL_MEDICINE` Medizin | STAT_PER, STAT_COG, STAT_DEX, STAT_WIL | INPUT(STAT_PER) → INTERPRET(STAT_COG) → SETUP(STAT_COG) → EXECUTE(STAT_DEX) → CONTROL(STAT_WIL) | erste hilfe, trauma, stabilisierung, behandlung, medizinische diagnose | Traumaversorgung, Blutungen, Atemweg, Feldmedizin |
| `SKILL_ATTENTION` Aufmerksamkeit | STAT_PER, STAT_WIL | INPUT(STAT_PER) → CONTROL(STAT_WIL) | wache halten, signal filtern, lange beobachten, mehrere reize | Maschinenlärm, Nachtwache, Menschenmengen, Sensorüberwachung |
| `SKILL_OBSERVATION` Observation | STAT_PER, STAT_COG | INPUT(STAT_PER) → INTERPRET(STAT_COG) | spuren, details, beobachten, umgebung lesen, veränderungen erkennen | Tatorte, Mikrobewegungen, Werkspuren, Patrouillenmuster |
| `SKILL_ORIENTATION` Orientierung | STAT_PER, STAT_COG, STAT_WIL | INPUT(STAT_PER) → INTERPRET(STAT_COG) → CONTROL(STAT_WIL) | navigation, karten, wegesuche, raumlage, zurückfinden | Tunnel, Ruinen, Großstadt, Wildnis |
| `SKILL_PEOPLE_READING` Menschenkenntnis | STAT_PER, STAT_SOC, STAT_COG, STAT_WIL | INPUT(STAT_PER/STAT_SOC) → INTERPRET(STAT_COG/STAT_SOC) → CONTROL(STAT_WIL) | emotionen lesen, täuschung erkennen, absichten einschätzen, soziale lage | Mikroexpressionen, Verhandlung, Angstreaktionen, Gruppendynamik |
| `SKILL_COMMUNICATION` Kommunikation | STAT_SOC, STAT_PER, STAT_COG, STAT_WIL | INPUT(STAT_SOC/STAT_PER) → INTERPRET(STAT_COG) → EXECUTE(STAT_SOC) → CONTROL(STAT_WIL) | erklären, verhandeln, überzeugen, deeskalieren, koordinieren | Techniker erklären, Krisengespräch, Handel, Führung |
| `SKILL_SELF_CONTROL` Selbstbeherrschung | STAT_PER, STAT_WIL, STAT_END | INPUT(STAT_PER) → SETUP(STAT_WIL) → CONTROL(STAT_WIL/STAT_END) | angst, schmerz, stress, provokation, panik vermeiden | Schmerz, Verhör, Panik, Sensorische Überlastung |
| `SKILL_RESONANCE_SENSE` Resonanzwahrnehmung | STAT_RES, STAT_PER, STAT_WIL | INPUT(STAT_RES/STAT_PER) → CONTROL(STAT_WIL) | präsenz spüren, felder erkennen, anomalien wahrnehmen, resonanz lokalisieren | Entitätssignaturen, Artefaktfelder, Ortsresonanzen, schwache Echos |
| `SKILL_RESONANCE_CONTROL` Resonanzkontrolle | STAT_RES, STAT_WIL | INPUT(STAT_RES) → SETUP(STAT_WIL) → EXECUTE(STAT_RES) → CONTROL(STAT_WIL) | fokussieren, koppeln, abschirmen, resonanz halten | Entitätskontakt, Feldstabilisierung, Artefaktkopplung, Abschirmung |
| `SKILL_RESONANCE_PROJECTION` Resonanzprojektion | STAT_WIL, STAT_RES, STAT_END | SETUP(STAT_WIL) → EXECUTE(STAT_RES) → CONTROL(STAT_WIL/STAT_END) | resonanz senden, feldwirkung, impuls, resonante projektion | Druckimpulse, Ward-Verstärkung, Signalgebung, Feldprojektion |
| `SKILL_OCCULT_KNOWLEDGE` Okkultes Wissen | STAT_PER, STAT_COG | INPUT(STAT_PER) → INTERPRET(STAT_COG) | dämonologie, rituale verstehen, entitäten klassifizieren, okkulte symbole | Dämonologie, Schutzzeichen, Kultsysteme, Entitätsregeln |
| `SKILL_RITUAL_TECHNIQUE` Ritualtechnik | STAT_COG, STAT_DEX, STAT_RES, STAT_WIL | INTERPRET(STAT_COG) → SETUP(STAT_COG/STAT_DEX) → EXECUTE(STAT_DEX/STAT_RES) → CONTROL(STAT_WIL) | siegel, schutzkreis, bindung, ritual, artefaktaktivierung | Schutzsiegel, Bindungskreise, Artefaktrituale, Beschwörungsgeometrie |
| `SKILL_ASTRAL_NAVIGATION` Astrale Navigation | STAT_RES, STAT_PER, STAT_COG, STAT_WIL | INPUT(STAT_RES/STAT_PER) → INTERPRET(STAT_COG) → EXECUTE(STAT_RES) → CONTROL(STAT_WIL) | astrale räume, schwellen, resonanzpfade, fernsondierung | Schwellenräume, Traumpfade, Entitätsräume, Fernsondierung |
| `SKILL_RESONANCE_CONCEALMENT` Resonanzverschleierung | STAT_RES, STAT_PER, STAT_WIL | INPUT(STAT_RES/STAT_PER) → SETUP(STAT_WIL) → EXECUTE(STAT_RES) → CONTROL(STAT_WIL) | signatur verbergen, resonant schleichen, okkulte tarnung, feld dämpfen | Entitäten umgehen, Artefaktsensoren, Wards, Resonanzjagd |
| `SKILL_ENTITY_CONTACT` Entitätskontakt | STAT_RES, STAT_PER, STAT_SOC, STAT_COG, STAT_WIL | INPUT(STAT_RES/STAT_PER) → INTERPRET(STAT_SOC/STAT_COG) → SETUP(STAT_WIL) → EXECUTE(STAT_RES/STAT_SOC) → CONTROL(STAT_WIL) | geistkontakt, entität ansprechen, mediumismus, nichtmenschliche kommunikation | Gebundene Entitäten, Ortsgeister, Restmuster, fremde Signaturen |
| `SKILL_BANISHING` Bannung | STAT_RES, STAT_PER, STAT_COG, STAT_WIL, STAT_END | INPUT(STAT_RES/STAT_PER) → INTERPRET(STAT_COG) → SETUP(STAT_WIL) → EXECUTE(STAT_RES) → CONTROL(STAT_WIL/STAT_END) | fluch brechen, besessenheit lösen, entität bannen, bindung zerstören | Besessenheitsbindungen, Fluchknoten, Entitätsanker, Artefaktbindungen |
| `SKILL_ECHO_ANALYSIS` Echoanalyse | STAT_RES, STAT_PER, STAT_WIL, STAT_COG | INPUT(STAT_RES/STAT_PER) → CONTROL(STAT_WIL) → INTERPRET(STAT_COG) | objektspuren, ortsechos, resonanzreste, ereignisfragmente | Tatort-Echos, Besitzerreste, Traumaorte, Artefaktgeschichte |
| `SKILL_DIVINATION` Divination | STAT_RES, STAT_PER, STAT_COG, STAT_WIL | INPUT(STAT_RES/STAT_PER) → INTERPRET(STAT_COG) → CONTROL(STAT_WIL) | vorzeichen, symboldeutung, präkognitive fragmente, muster lesen | Traumbilder, Orakelmedien, Gefahrenvorahnungen, Wahrscheinlichkeitsmuster |

## Talente (26)

| Talent | Klasse | erforderliche Skills | Stat-Wurzeln | beeinflusste Stufen | vorgesehene Situationen |
|---|---|---|---|---|---|
| `TALENT_FORCE_LINE` Kraftlinie | BREAKER | SKILL_FORCE_APPLICATION | STAT_STR, STAT_MOB | SETUP, EXECUTE | heben, brechen, schieben, ringen |
| `TALENT_UNYIELDING` Unnachgiebig | BREAKER | SKILL_LOAD_CONTROL, SKILL_SELF_CONTROL | STAT_END, STAT_WIL | CONTROL | schmerz, erschöpfung, halten, schutz |
| `TALENT_IMPACT_CONTROL` Impact Control | BREAKER | SKILL_FORCE_APPLICATION, SKILL_AIM_CONTROL | STAT_STR, STAT_REA | EXECUTE, CONTROL | stoß, schlag, breach, kontrollierte gewalt |
| `TALENT_RESONANCE_ARMOR` Resonanzpanzer | BREAKER | SKILL_RESONANCE_CONTROL, SKILL_SELF_CONTROL | STAT_RES, STAT_WIL | SETUP, CONTROL | resonanzdruck, fluchkontakt, entitätsnähe |
| `TALENT_BANISHING_STRIKE` Bannschlag | BREAKER | SKILL_BANISHING, SKILL_FORCE_APPLICATION | STAT_RES, STAT_STR | EXECUTE | manifestation, gebundene entität, fluchanker |
| `TALENT_ANCHOR` Anker | BREAKER | SKILL_SELF_CONTROL, SKILL_RESONANCE_CONTROL | STAT_END, STAT_WIL, STAT_RES | CONTROL | besessenheit, forced movement, resonanzzug |
| `TALENT_PHANTOM_STEP` Phantom Step | GHOST | SKILL_STEALTH, SKILL_BALANCE | STAT_MOB, STAT_DEX | EXECUTE, CONTROL | leise bewegung, schmale wege, beobachter umgehen |
| `TALENT_BLIND_MOVEMENT` Blind Movement | GHOST | SKILL_BALANCE, SKILL_ORIENTATION | STAT_MOB, STAT_PER | INPUT, CONTROL | dunkelheit, rauch, blendung, enge räume |
| `TALENT_ECHO_TRACKING` Echo Tracking | GHOST | SKILL_OBSERVATION, SKILL_ECHO_ANALYSIS | STAT_PER, STAT_RES | INPUT, INTERPRET | spuren, resonanzreste, verfolgung |
| `TALENT_VEIL` Veil | GHOST | SKILL_RESONANCE_CONCEALMENT, SKILL_STEALTH | STAT_RES, STAT_WIL | SETUP, CONTROL | resonanzsensoren, entitäten umgehen, tarnung |
| `TALENT_ASTRAL_TRACE` Astral Trace | GHOST | SKILL_ASTRAL_NAVIGATION, SKILL_OBSERVATION | STAT_RES, STAT_PER | INPUT, INTERPRET | schwellen, resonanzpfade, fernspuren |
| `TALENT_GLAMOUR` Glamour | GHOST | SKILL_RESONANCE_CONCEALMENT, SKILL_COMMUNICATION | STAT_RES, STAT_SOC | EXECUTE, CONTROL | aufmerksamkeit umlenken, soziale tarnung, fehlwahrnehmung |
| `TALENT_MACHINEWORK` Maschinenwerk | OPERATOR | SKILL_TECHNOLOGY, SKILL_DIAGNOSTICS | STAT_COG, STAT_DEX | INTERPRET, EXECUTE | maschinen, reparatur, wartung, störungsanalyse |
| `TALENT_SYSTEM_VIEW` Systemblick | OPERATOR | SKILL_DIAGNOSTICS, SKILL_ATTENTION | STAT_COG, STAT_PER | INPUT, INTERPRET | systemfehler, mehrfachausfälle, infrastruktur |
| `TALENT_FIELD_REPAIR` Field Repair | OPERATOR | SKILL_TECHNOLOGY, SKILL_FINE_MECHANICS | STAT_DEX, STAT_COG | SETUP, EXECUTE | improvisierte reparatur, zeitdruck, fehlende teile |
| `TALENT_SIGILCRAFT` Sigilcraft | OPERATOR | SKILL_RITUAL_TECHNIQUE, SKILL_OCCULT_KNOWLEDGE | STAT_COG, STAT_DEX, STAT_RES | INTERPRET, SETUP, EXECUTE | siegel, wards, ritualstruktur |
| `TALENT_CONTAINMENT` Containment | OPERATOR | SKILL_RITUAL_TECHNIQUE, SKILL_DIAGNOSTICS | STAT_COG, STAT_RES | SETUP, CONTROL | anomalie eindämmen, entität binden, feld stabilisieren |
| `TALENT_ARTIFACT_ENGINEERING` Artifact Engineering | OPERATOR | SKILL_TECHNOLOGY, SKILL_RITUAL_TECHNIQUE | STAT_COG, STAT_DEX, STAT_RES | INTERPRET, EXECUTE | artefakt, resonanzkern, hybridsystem |
| `TALENT_AURA_READING` Aura Reading | RESONANT | SKILL_RESONANCE_SENSE, SKILL_PEOPLE_READING | STAT_RES, STAT_PER, STAT_SOC | INPUT, INTERPRET | aura, affekt, resonanzzustand |
| `TALENT_PSYCHOMETRY` Psychometrie | RESONANT | SKILL_ECHO_ANALYSIS, SKILL_RESONANCE_CONTROL | STAT_RES, STAT_PER, STAT_WIL | INPUT, CONTROL, INTERPRET | objekte, orte, ereignisechos |
| `TALENT_TELEPATHIC_LINK` Telepathische Kopplung | RESONANT | SKILL_ENTITY_CONTACT, SKILL_RESONANCE_CONTROL | STAT_RES, STAT_SOC, STAT_WIL | SETUP, EXECUTE, CONTROL | mentale impulse, kontakt, resonante kommunikation |
| `TALENT_CLAIRVOYANCE` Clairvoyance | RESONANT | SKILL_RESONANCE_SENSE, SKILL_ASTRAL_NAVIGATION | STAT_RES, STAT_PER, STAT_WIL | INPUT, CONTROL | verborgene resonanz, fernwahrnehmung, schwellen |
| `TALENT_RETROCOGNITION` Retrokognition | RESONANT | SKILL_ECHO_ANALYSIS, SKILL_DIVINATION | STAT_RES, STAT_COG | INPUT, INTERPRET | vergangenheitsechos, tatorte, ereignisreste |
| `TALENT_PRECOGNITIVE_RESONANCE` Präkognitive Resonanz | RESONANT | SKILL_DIVINATION, SKILL_ATTENTION | STAT_RES, STAT_PER, STAT_WIL | INPUT, INTERPRET, CONTROL | gefahr, mögliche nächste ereignisse, vorahnung |
| `TALENT_MEDIUMSHIP` Mediumismus | RESONANT | SKILL_ENTITY_CONTACT, SKILL_SELF_CONTROL | STAT_RES, STAT_SOC, STAT_WIL | INPUT, EXECUTE, CONTROL | geister, entitäten, restbewusstsein |
| `TALENT_ASTRAL_PROJECTION` Astralprojektion | RESONANT | SKILL_ASTRAL_NAVIGATION, SKILL_RESONANCE_CONTROL | STAT_RES, STAT_WIL, STAT_COG | SETUP, EXECUTE, CONTROL | fernsondierung, schwellenraum, projektion |

## Mechanische Situationsklassen

Für jede benannte Talentsituation werden dieselben mechanischen Fälle geprüft: SAFE_ROUTINE, EDGE_UNCERTAIN, EXTREME_RISK, HARD_LIMIT, INACCESSIBLE_TALENT, INACCESSIBLE_SKILL, STATE_IMPAIRMENT, AIDED_METHOD, EXPERTISE_APPLIED, ACTIVE_OPPOSITION und PARTIAL_SUCCESS_LATE_LIMIT.

Benannte Talentsituationen: **83**  
Generierte Talent-Szenarien: **913**  
Klassenfähigkeiten mit Character-Tree-Wurzeln: **1680**

## Verbindliche Auflösungsregel

- SAFE: keine Erfolgsprobe nötig.
- EDGE: echte Unsicherheit, normale Probe.
- EXTREME: grundsätzlich möglich, aber vorherige Warnung und hohe Fehlschlagwahrscheinlichkeit.
- HARD_LIMIT: keine Erfolgsprobe; die konkrete körperliche/kognitive/resonante Grenze wird dem Spieler vor der Handlung erklärt.
- INACCESSIBLE: notwendige Technik/Skill/Talent ist nicht verfügbar.

Frühere erfolgreiche Teilstufen bleiben erhalten. Wahrnehmung darf z. B. erfolgreich sein, obwohl Fokus, Balance, Kraft oder Präzision in einer späteren Stufe scheitert.

## Prüfstatus

- Capability-/Talent-/Class-Tree-Testblock: **3018 PASS**
- Capability Character Tree Audit: **PASS**
- 10 Stats / 30 Skills / 26 Talente: **PASS**
- alle 30 Skills speisen mindestens eine Klassenfähigkeit: **PASS**
- alle 26 Talente speisen mindestens eine Klassenfähigkeit: **PASS**
- 1680 Klassenfähigkeiten besitzen kanonische Stat-/Skill-Wurzeln: **PASS**
- 913 benannte Talent-Szenarien vorhanden: **PASS**
- Stage-9 PlayableRuntime nach Entfernung direkter Shell-Commits: **PASS**
- vollständige 42 Release-Gates: **segmentiert vollständig PASS**

## Gefundene und behobene Modelllücken

1. `Psychometrie` war als Skill und Talent doppeldeutig. Basisfähigkeit heißt jetzt `SKILL_ECHO_ANALYSIS` / Echoanalyse; `TALENT_PSYCHOMETRY` bleibt die spezialisierte Anwendung.
2. Sechs Skills hatten keinen direkten Basistalent-Pfad. Sie bleiben zulässige Grundskills, sind jetzt aber nachweislich in den späteren Klassenbaum eingebunden.
3. Vier übernatürliche Skills wurden durch eine starre Fallback-Reihenfolge aus Klassenfähigkeiten verdrängt. Die Ableitung rotiert nun über den gesamten Klassenprofilraum.
4. Playable-Shell enthielt zwei direkte Commit-Pfade (Survival-Status und Ability-Learning). Diese wurden in Runtime-Adapter verlagert.
5. Der historische Stage-9-Closure-Report fehlte im RC2.6.9-Paket und wurde byte-identisch aus der vollständigen RC2.6.8-Projektquelle wiederhergestellt.
