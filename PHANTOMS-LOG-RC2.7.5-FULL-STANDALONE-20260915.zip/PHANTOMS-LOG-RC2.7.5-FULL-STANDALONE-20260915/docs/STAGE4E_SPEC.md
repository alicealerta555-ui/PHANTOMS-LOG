# Stage 4E · Branch Classes

**Authority date:** 2026-09-03  
**Status:** IMPLEMENTED / VALIDATION PENDING

Stage 4E separates branch labels that older/simple RPG systems often collapse into one hierarchy. PH4NT0M5-L0G treats cognition, developmental ecology, synthetic source history and post-control drift as different axes.

## Canonical branch labels

- **SAPIENT** — evidence-backed cognitive assessment. It is not inferred from humanoid morphology, tools, social role or species stereotype.
- **SEMI_SAPIENT** — evidence-backed cognitive assessment distinct from sapience. It is not a moral, legal-worth or hostility score.
- **FERAL** — post-control developmental/ecological branch history outside maintained directed-development systems. It does not mean evil, stupid, hostile, unsocial or non-sapient.
- **SYNTHETIC** — explicit synthetic-biology source history. It does not imply sapience, obedience, artificial personality or machine-like psychology.
- **DRIFT** — free-drift evolutionary history downstream of Stage-4A B5/B6. It does not imply degeneration, unpredictability or low cognition.

## Multi-axis rule

The five labels are not a single mutually exclusive ladder. `SAPIENT` and `SEMI_SAPIENT` are mutually exclusive cognitive assessments, while FERAL / SYNTHETIC / DRIFT are orthogonal developmental/source-history labels.

Valid examples therefore include:

- `SAPIENT + FERAL`
- `SAPIENT + SYNTHETIC`
- `SAPIENT + FERAL + DRIFT`
- `SEMI_SAPIENT + SYNTHETIC + DRIFT`
- `FERAL` with cognition still `UNASSESSED`

The system preserves unknown cognition instead of guessing.

## Evidence and chronology

Cognitive classes require explicit evidence references and an assessment scope. Morphology and biological capability never auto-assign cognition.

FERAL lineage-history classification is restricted to post-control developmental phases B4–B6. DRIFT is restricted to B5–B6. SYNTHETIC requires actual Stage-4C synthetic-biology source provenance. These constraints prevent retroactive branch labels.

## Non-determinism boundary

Branch classes do not assign morality, personality, profession, dominance/submission, attraction, consent, loyalty, obedience or hostility. They do not directly mutate morphology, metabolism, environment or regeneration.

Stage 4F owns Cognitive Drift / Behavioral Echoes and must preserve the causal order:

`BIO disposition → culture/history → individual psychology/values → current situation → behavior`

Stage 5 retains detailed senses/communication. Stage 6 retains inheritance/germline/speciation mechanics.
