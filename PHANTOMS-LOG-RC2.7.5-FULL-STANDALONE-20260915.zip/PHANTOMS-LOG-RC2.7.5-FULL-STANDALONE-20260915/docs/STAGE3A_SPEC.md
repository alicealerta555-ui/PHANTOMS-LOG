# PH4NT0M5-L0G · STAGE 3A · STATE AUTHORITY / COMMIT KERNEL · v0.1

Status: PRIVATE DEVELOPMENT · reference implementation · no new game `.0` version.

## Authority domains

- `WORLD_TRUTH`: objective committed facts.
- `ACTOR_KNOWLEDGE`: actor-scoped knowledge with provenance.
- `PLAYER_KNOWLEDGE`: player-observed/learned knowledge with provenance.
- `UNRESOLVED_WORLD`: bounded possibility spaces only; not facts.
- `RUNTIME_STATE`: mutable mechanical/run state.
- Event ledger is append-only evidence for committed transitions.

## Non-authoritative inputs

`PLAYER_INPUT`, `LLM_PROPOSAL`, and `NARRATOR` have zero direct commit rights.
Questions and hypotheses are handled as `QUERY` and always remain `NO_COMMIT` unless a separate authorized resolver operation is explicitly invoked.

## Modes

- `GENERATE`: produce draft only -> HOLD.
- `QUERY`: inspect/ask/hypothesize -> HOLD / NO_COMMIT.
- `RESOLVE`: resolve a registered unknown via deterministic seed + fixed plausible weights.
- `COMMIT`: validate all deltas, then apply atomically.
- `HOLD`: preserve without state effect.
- `REJECT`: discard without state effect.

## Core locks

1. No reality write from player question/hypothesis.
2. No direct LLM or narrator state mutation.
3. Unknown truth can resolve only if registered as unresolved.
4. Resolution ignores player suggestion in seed and weights.
5. Resolved truth is not rerolled.
6. Knowledge writes require provenance; actor knowledge additionally requires actor identity.
7. All commit deltas need explicit writer authority and cause.
8. Duplicate event IDs are idempotent and never apply a second effect.
9. A rejected transaction applies zero deltas.
10. Narration receives a copy/read-only committed view and cannot create canon.

## Compatibility

This layer is intentionally additive to the existing fixed-phase/delta-buffer/atomic-commit architecture, Event Ledger, Hidden Locks and Foundation Crosschecker. It does not replace the Rule Kernel or Stage 3B action-resolution pipeline.
