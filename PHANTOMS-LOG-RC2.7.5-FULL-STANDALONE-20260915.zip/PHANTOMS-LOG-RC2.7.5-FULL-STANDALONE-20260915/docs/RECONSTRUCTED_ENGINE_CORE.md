# PH4NT0M5-L0G · Reconstructed Engine Core

**Authority date:** 2026-09-03  
**Game-base reference:** `PhantomsLog 0.2.2.0`  
**Integrated development:** Stage 3A + Stage 3B  
**Purpose:** restore the missing static Stage-1/Stage-2 engine shell from surviving validated project sources and align it to the current master without importing historical player/run state.

## What was reconstructed

- Stage-1 invariant contract (`runtime/core/contracts.py`).
- Stage-2 canonical causal spine E0–E5 and CRY 0→10,000/T0 axis (`runtime/core/chronology.py`).
- Fixed P0–P9 world-simulation shell connected to the Stage-3A authority/atomic-commit bridge (`runtime/core/world_sim.py`).
- Event-driven + configurable multi-rate HOT/WARM/COLD scheduling contract.
- Post-commit-only player projection.
- Generic mission/catalog/bestiary contracts without copying historical run state.
- Regression tests proving the reconstruction coexists with Stage 3A/3B.

## Deliberately not copied

Historical NEXUS-7 files mixed reusable rules/content with a concrete run (`CURRENT_STATE`, concrete credits/XP, M12/Jax state, checkpoint IDs, etc.). The current project architecture explicitly forbids concrete player/save/run state in the static Core. Those values are therefore migration evidence only and are not part of this reconstructed engine package.

## Source-evidence basis

Surviving project-library evidence established:

- six-file compact project architecture (index/runtime/missions/equipment/bestiary/world);
- world-before-story and locked hidden facts;
- symmetric actor resolution and real failure;
- mission persistence classes and three real solution families;
- event-driven + multi-rate + HOT/WARM/COLD + fixed P0–P9 delta/atomic commit world simulation;
- actor-knowledge boundaries, explicit information channels, ecology and history/legacy processing;
- presentation only after commit;
- current Stage-3A/3B authority and action pipeline.

This is a **reconstruction aligned to the current master**, not a byte-identical restoration of an older private ZIP.

## Conflict discipline

Surviving historical files do not all represent the same mechanical revision. For example, the library contains both W100-oriented runtime material and a later 5W20 balance experiment. The current master does not authorize selecting a superseded mechanic solely from file age. Therefore this reconstruction restores stable architecture/invariants first and leaves disputed detailed mechanics behind an explicit current-master decision boundary.

This is deliberate: a reconstructed core must be current-master-correct before it is legacy-complete.
