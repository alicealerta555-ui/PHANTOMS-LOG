# PH4NT0M5-L0G – Kumulativer Entwicklungsstand mit Integration I3

Privates, getrenntes Entwicklungsmodul. Keine automatische Installation und keine Änderung des privaten Masters. Benötigt dessen runtime.stage4b. Keine externen Python-Abhängigkeiten.

## Implementiert

- Unveränderliche Sinnesprofile mit Modalität und Verweisen auf biologische Einschränkungen.
- Explizite Bindung an vorhandene SensorCapabilityHooks einer validierten Geneline.
- ACTIVE, LATENT, CONDITIONAL und UNRESOLVED; fehlende Bindung bleibt UNRESOLVED.
- AVAILABLE bedeutet nur biologisch verfügbar. Es bedeutet weder wahrgenommen noch bekannt.
- LATENT und fehlende Modalität ergeben UNAVAILABLE, bleiben über die zurückgegebenen Quellen unterscheidbar.
- Mehrere Quellen und ihre Ausprägungen bleiben erhalten. Keine Mittelung oder automatische Merkmalsauswahl.
- Unbekannte Profile/Hooks/Einschränkungen, doppelte Bindungen und Modalitätskonflikte werden abgewiesen.
- Kein Welt-, Wissens-, Spieler- oder Run-State wird gelesen oder geschrieben.

## Grenzen und Anschluss

Die bindende Engine muss Ausprägung und Evidenzbelege autorisieren. Dieses Modul prüft Referenzstruktur und die vorhandenen biologischen Einschränkungs-IDs, nicht die Wahrheit externer Evidenzreferenzen. Es akzeptiert keine Spielereingaben als biologische Entscheidungen. Pro Profil gelten Modalitätsnamen exakt wie im zugehörigen Hook; keine impliziten Alias-Zuordnungen.

SenseProfile selbst bleibt die biologische Bindung. VisualLimits ergänzt explizit profilgebundene Reichweite und Lichtschwelle. ACTIVE ist keine Wahrnehmungsgarantie. Bedingte Ausprägungen werden nicht eigenständig aufgelöst. Wahrnehmungsergebnisse werden erst in einer späteren Integration über die bestehende EpistemicEngine zu Wissen verarbeitet. Bewusste Entwicklung getrennt von einer noch ausstehenden Gesamtfreigabe und Modell-/DEMO-0-Abnahme.

## Tests starten

Im entpackten Paketordner:

```bash
python3 run_tests.py --core "$HOME/Downloads/PH4NT0M5-L0G_PRIVATE_RUNTIME_WORKBASE_STAGE3C_2026-09-09"
```

Der Zielordner muss die vollständigen Stage-4-Module enthalten. Der Test verwendet ausschließlich neue anonyme synthetische biologische Fixtures. Kein Modell, GPU-Training oder Netz benötigt.

## API

SenseRegistry(profiles).bind(geneline, bindings) liefert nach Hook-ID sortierte BoundSense-Werte. assess_modality(bound_senses, modality) liefert Verfügbarkeit plus alle passenden Quellen. Die Priorität ACTIVE > CONDITIONAL > UNRESOLVED > UNAVAILABLE gibt an, ob mindestens eine Quelle verfügbar ist; sie löscht die anderen Quellen nicht.

Quelldatei: phantoms_stage5/senses.py. Tests: tests/test_senses.py. In dieses Paket wurden keine privaten Masterquellen kopiert.


## Erweiterung 5.2

`phantoms_stage5.visual.detect_visual(bound_sense, limits, conditions)` bewertet genau eine gebundene visuelle Quelle. VisualLimits enthält profile_id, max_distance_m und min_illuminance_lux. VisualConditions enthält distance_m, incident_illuminance_lux und line_of_sight_clear; unbekannte Werte sind None.

Ergebnisse: DETECTED, NOT_DETECTED oder UNRESOLVED mit Gründen und Hook-ID. Es wird kein Objektinhalt, keine Weltwahrheit und kein Wissen ausgegeben oder gespeichert. Die Prüfung ist deterministisch. Reichweitengrenze und Lichtschwelle sind inklusive. Ungültige, negative oder nicht endliche Messwerte werden abgewiesen.

Ein ungebundenes Profil bleibt UNRESOLVED; fremde Reichweitenwerte können es nicht auflösen. Bei einem gebundenen Profil genügt eine bekannte blockierende Bedingung für NOT_DETECTED, selbst wenn andere Messwerte fehlen. Sonst führen fehlende Messwerte oder nicht aktive bedingte/ungeklärte Ausprägung zu UNRESOLVED. Ein latenter Sinn detektiert nicht.

Alle Werte müssen aus autorisiertem Engine-Zustand kommen. Die Sichtlinie ist eine explizite Vorbedingung, kein hier implementiertes Raycasting. Weder partielle Verdeckung, Sehschärfe, Nebel noch Objekterkennung sind in 5.2 enthalten. Lichtschwelle und Reichweite werden ausdrücklich konfiguriert; die Zahlen der Testfixtures sind kein kanonisches Balancing.

Dieses Paket enthält 5.1 vollständig und braucht nicht über das alte Paket kopiert zu werden. Separat entpacken und run_tests.py mit dem vorhandenen vollständigen Stage-4-Master starten. Insgesamt 21 Tests: 11 aus 5.1 und 10 neue visuelle Testmethoden einschließlich Grenzwerten und Negativfällen. Der private Core bleibt unverändert.


## Erweiterung 5.3a – Hören

`phantoms_stage5.auditory.detect_auditory(bound_sense, limits, conditions)` prüft eine explizit gebundene auditory-Quelle. AuditoryLimits enthält profile_id, max_distance_m, min_signal_db_spl und min_snr_db. Die maximale Reichweite ist eine konfigurierte Spielgrenze, kein automatisch berechnetes physikalisches Gesetz. Die Signal-/Störabstandsschwelle ist in diesem vereinfachten Modell nichtnegativ.

AuditoryConditions enthält Entfernung, empfangenen Signalpegel und empfangenen Störpegel in dB SPL sowie acoustic_path_available. Pegel müssen am Empfänger nach Ausbreitung und Dämpfung gelten und dieselbe Referenz, Frequenzband- und Zeitfensterdefinition verwenden. Die Welt-Engine liefert diese Werte; das Modul berechnet keine Raumakustik. Es wird keine zusätzliche Entfernungsdämpfung auf bereits empfangene Pegel angewandt. Negative endliche dB-SPL-Werte sind zulässig; None steht für unbekannt, nicht für Stille.

Ein Signal muss Hörschwelle und Signal-/Störabstand erfüllen. Grenzwerte sind inklusive. Ein geschlossener akustischer Weg verhindert Detektion unabhängig von der gelieferten Lautstärke. Sichtlinie ist keine Hörbedingung: Hören kann bei von der Engine bestätigtem Schallweg auch ohne direkte Sicht stattfinden. Fehlende Angaben führen zu UNRESOLVED, sofern nicht bereits eine bekannte Bedingung Detektion ausschließt. Ein ungebundenes Profil bleibt ungeklärt. ACTIVE/LATENT/CONDITIONAL/UNRESOLVED folgen den bereits verwendeten Regeln.

Ergebnis enthält nur Hook-ID, DETECTED/NOT_DETECTED/UNRESOLVED und Gründe. Weder Wörter, Sprecheridentität, Richtung noch Objektinformationen werden erzeugt. Kein Wissens- oder Welt-Commit. Keine modellierte Frequenzantwort, Sprachverständlichkeit, Echoortung oder Schädigung durch Lautstärke in dieser Etappe.

Dieses kumulative Paket enthält 5.1, 5.2 und 5.3a. Separat entpacken; der Teststarter benötigt weiter den vollständigen Stage-4-Master. Insgesamt 32 Tests bestanden (21 bisherige plus 11 auditive Testmethoden). Zahlen in Testfixtures sind synthetische Konfiguration und kein kanonisches Balancing. Keine private Core-Datei wurde verändert oder mitgeliefert.


## Erweiterung 5.3b – Thermische Wahrnehmung

`phantoms_stage5.thermal.detect_thermal(bound_sense, limits, conditions)` prüft eine gebundene thermal-Quelle. ThermalLimits enthält profile_id, max_distance_m und min_abs_contrast_k. ThermalConditions enthält Entfernung, vorzeichenbehafteten empfangenen scheinbaren thermischen Kontrast in Kelvin und thermal_path_available. Positive und negative Kontraste werden über ihren Betrag geprüft. Nullkontrast wird nicht erkannt; Reichweiten- und Kontrastgrenzen sind inklusive.

Die Engine liefert Kontrast und kanalbezogenen Übertragungsweg für das gewählte thermische Band nach Ausbreitung und Dämpfung. Optische Transparenz ist kein Eingabewert und wird nicht als thermische Durchlässigkeit übernommen. Das Modell berechnet weder Wärmeleitung/Strahlung noch Materialeigenschaften, exakte Temperaturen oder Spektren. Es ist ein vereinfachtes Detektionsmodell mit konfigurierten Grenzen, keine physikalische Messsimulation.

Ergebnis: DETECTED/NOT_DETECTED/UNRESOLVED, Gründe und Hook-ID. Keine Temperatur-, Objekt- oder Wissensdaten werden erzeugt. Ein ungebundenes Profil bleibt ungeklärt; latente Sinne erkennen nichts. Fehlende Messwerte werden nicht erfunden. Eine bekannte Blockade bei gebundenem Profil reicht zum Ausschluss; sonst bleiben bedingte oder ungeklärte Ausprägungen und fehlende Angaben offen.

Dieses kumulative Paket enthält 5.1 bis 5.3b und ersetzt für die getrennte Entwicklung die vorherigen Stage-5-Pakete. Separat entpacken und mit run_tests.py --core auf dem vollständigen Stage-4-Master prüfen. 42 Tests bestanden: 32 bisherige und 10 thermische Testmethoden. Grenzwerte sind synthetische Testkonfiguration, kein kanonisches Arten-Balancing. Keine produktive Installation, Modellabnahme oder Gesamtfreigabe.

## Erweiterung 5.3c – Chemische und olfaktorische Wahrnehmung

`phantoms_stage5.chemical.detect_chemical(bound_sense, limits, conditions)` prüft genau eine explizite Stoffsignatur. ChemicalLimits bindet profile_id, die exakte Modalität chemical oder olfactory, signature_id, medium_id und die positive min_concentration_mol_m3. ChemicalConditions liefert received_signature_id, received_medium_id, received_concentration_mol_m3 und transport_available. None bedeutet unbekannt.

Die autorisierte Engine liefert die Konzentration am Rezeptor nach Transport und Verdünnung. Das Modul berechnet keine Diffusion, Strömung oder Entfernungsausbreitung. Bekannte falsche Signatur, falsches Medium, fehlender Transport, Konzentration unter der inklusiven Schwelle oder latente Ausprägung blockieren Detektion. Fehlende Angaben bleiben sonst ungeklärt; ein ungebundenes Profil bleibt UNRESOLVED. chemical und olfactory werden nicht als Aliase behandelt.

Ergebnis enthält nur Hook-ID, Detektionsstatus und Gründe. Der Signaturvergleich erzeugt kein Spielerwissen über Stoffidentität oder Giftigkeit. Keine Welt-/Wissensänderung, keine Gemischanalyse oder Rezeptoradaptation. Messwerte müssen endlich und nichtnegativ sein; Bool, Nicht-Zahlen und Überläufe werden abgewiesen.

Kumulativer Stand: 52 Tests bestanden, davon 42 bisherige und 10 neue chemische Testmethoden. Geprüft sind Signatur, Medium, Schwelle, Transport, unbekannte Werte, Modalitätstrennung, Bindungen/Ausprägungen, Eingabevalidierung und unveränderte Eingaben. Paket separat entpacken und mit dem vollständigen Stage-4-Core testen. Produktive Spielintegration und Gesamt-Abnahmen stehen weiterhin aus.

## Erweiterung 5.3d – Taktile Kontaktdetektion

`phantoms_stage5.tactile.detect_tactile(bound_sense, limits, conditions)` prüft eine explizit gebundene tactile-Quelle. TactileLimits enthält profile_id und positive min_contact_pressure_pa. TactileConditions enthält contact_available und received_contact_pressure_pa. None bedeutet unbekannt. Kontakt bezeichnet die mechanische Kopplung des geprüften Reizes zum Rezeptor, gegebenenfalls durch ein Zwischenmaterial. Der empfangene Druck ist die effektive normale Kontaktbelastung am Rezeptor in Pascal nach Materialübertragung, kein atmosphärischer Absolutdruck.

Die Welt-Engine liefert diese Werte. Es wird weder Kraft durch Fläche berechnet noch ein Materialmodell angewandt. Druck ab der inklusiven Schwelle und bestätigter Kontakt erlauben bei aktiver Quelle Detektion. Bekannter fehlender Kontakt, zu geringer Druck oder latente Ausprägung blockieren; fehlende Angaben bleiben sonst ungeklärt. Ungebundene Profile bleiben UNRESOLVED. pressure und vibration sind keine Aliase für tactile.

Ergebnis nur Hook-ID, Status und Gründe; keine Objektidentität, Textur, Schmerz, Schaden oder Wissensänderung. Das vereinfachte Modell erfasst ausschließlich normalen Kontakt an einer Quelle, nicht alle Mechanorezeptoren, Scherkräfte, zeitliche Adaptation oder räumliche Verteilung.

Kumulativer Stand: 62 Tests bestanden (52 bisherige plus 10 taktile Testmethoden). Nachweise: Kontakt-Minimalpaar, inklusive Schwelle, Null, unbekannte Werte und bekannte Blockaden, Ausprägungen, ungebundene/falsche Profile, Modalitätstrennung, ungültige Werte und unveränderte Eingaben. Testwerte sind synthetisch; Spielintegration und Gesamt-Abnahmen stehen aus.

## Erweiterung 5.3e – Vibrationswahrnehmung

`phantoms_stage5.vibration.detect_vibration(bound_sense, limits, conditions)` bewertet eine gebundene vibration-Quelle. VibrationLimits enthält profile_id, positive min_frequency_hz und max_frequency_hz sowie positive min_acceleration_rms_m_s2. Frequenzgrenzen sind geordnet und inklusive; auch ein einzelner konfigurierter Frequenzwert ist erlaubt. VibrationConditions enthält mechanical_path_available, received_frequency_hz und received_acceleration_rms_m_s2. None steht für unbekannt.

Die Engine liefert eine einzelne schmalbandige Frequenzkomponente und deren RMS-Beschleunigung in m/s² am Rezeptor nach Ausbreitung und Dämpfung. Messfenster und Messachse müssen mit der Profilkalibrierung übereinstimmen. Keine zusätzliche Entfernungsdämpfung. Ein fehlender mechanischer Übertragungsweg, eine Frequenz außerhalb des Bandes, zu geringe Beschleunigung oder latente Ausprägung verhindern Detektion. Null Hz gilt als statisch und liegt außerhalb jedes positiven Durchlassbereichs. Fehlende Werte bleiben sonst ungeklärt, ungebundene Profile ebenfalls.

Die Modalität vibration bleibt von tactile, pressure und auditory getrennt. Eine Quelle muss nicht unmittelbar berührt werden; die autorisierte Engine bestätigt den mechanischen Pfad bis zum Rezeptor. Keine Spektralzerlegung oder Behauptung über ein gesamtes Mehrfrequenzsignal. Keine Resonanz-, Material-, Maskierungs- oder Schadenssimulation, keine Richtung oder Quellenidentität und kein Wissens-Commit.

74 Tests bestanden: 62 bestehende plus 12 neue Testmethoden. Geprüft sind Kopplung, inklusive Stärke-/Frequenzgrenzen, Null, unbekannte Werte, bekannte Blockaden, Ausprägung, Bindung, Modalitätstrennung, ungültige Zahlen/Bänder/Typen und unveränderte Eingaben. Testwerte sind synthetisch. Dieses kumulative Paket enthält 5.1 bis 5.3e; Spielintegration und Gesamt-Abnahmen bleiben offen.

## Erweiterung 5.3f – Druckdifferenzwahrnehmung

`phantoms_stage5.pressure.detect_pressure(bound_sense, limits, conditions)` bewertet eine explizit gebundene pressure-Quelle. PressureLimits enthält profile_id, reference_id und positive min_abs_difference_pa. PressureConditions enthält reference_id, signed received_difference_pa und pressure_path_available; None steht für unbekannt. Grenzwerte sind inklusive; positive und negative Differenzen werden über ihren Betrag geprüft.

Die autorisierte Engine liefert die Druckdifferenz am Rezeptor in Pascal gegenüber der durch reference_id bezeichneten Referenz nach Übertragung. Referenzdefinition, Messfenster und Rezeptor müssen zur Profilkalibrierung passen. Dies ist weder absoluter Umgebungsdruck noch Kontaktdruck oder dB SPL. Die biologische Umweltverträglichkeit pressure_kpa im Core ist keine Wahrnehmungsschwelle. Keine Einheitenkonvertierung oder Referenzanpassung erfolgt automatisch.

Eine bekannte fremde Referenz wird bei gebundenem Profil als Eingabefehler abgewiesen. Ohne Referenz wird der Differenzwert nicht gegen die Schwelle geprüft; das Ergebnis bleibt ungeklärt, sofern nicht ein fehlender Druckpfad oder latente Ausprägung bereits blockiert. Null bzw. ein zu geringer Betrag bei passender Referenz verhindert Detektion. Ein ungebundenes Profil bleibt UNRESOLVED.

Das Ergebnis enthält nur Hook-ID, Detektionsstatus und Gründe. Keine Druckmessanzeige, Richtung, Höhe, Tiefe, Schaden, Quellenidentität oder Wissensänderung. Keine Strömungs-/Materialphysik, zeitliche Adaptation oder Druckverträglichkeitsberechnung. Exakte Modalität pressure; tactile, vibration und auditory bleiben getrennt.

86 Tests bestanden: 74 bisherige plus 12 neue Testmethoden. Nachweise umfassen Übertragungsweg, inklusive positive/negative Grenzen, Null, fehlende/fremde Referenz, unbekannte Angaben, Ausprägung, Bindung, Modalitätstrennung, ungültige Werte/Typen und unveränderte Eingaben. Synthetische Testwerte. Kumulatives Paket 5.1 bis 5.3f; produktive Integration und Gesamt-Abnahmen stehen aus.

## Erweiterung 5.3g – Vestibulärer Drehreiz

`phantoms_stage5.vestibular.detect_vestibular(bound_sense, limits, conditions)` bewertet eine gebundene vestibular-Quelle. VestibularLimits enthält profile_id, calibration_id und positive min_abs_angular_response_rad_s. VestibularConditions enthält calibration_id, signed received_angular_response_rad_s und receptor_coupling_available; None bedeutet unbekannt.

Die autorisierte Engine liefert einen bereits durch das Rezeptormodell gefilterten, auf rad/s kalibrierten Drehreiz für eine einzelne Achse. Die Kalibrierungs-ID bezeichnet gemeinsam Achse, Bezugsrahmen, Zeitfenster und zeitliches Rezeptormodell. Das Modul vergleicht IDs; deren physikalische Definition und Berechnung bleiben Verantwortung der Engine. Rohe Welt-Winkelgeschwindigkeit darf nicht automatisch als Rezeptorantwort eingesetzt werden. Zeitliche Anpassung wird hier nicht berechnet.

Positive und negative Antworten werden über ihren Betrag mit inklusiver Schwelle geprüft. Fehlende Rezeptorkopplung oder latente Ausprägung blockieren. Eine bekannte fremde Kalibrierung wird bei gebundenem Profil abgewiesen. Ohne Kalibrierung wird kein Schwellenvergleich vorgenommen; fehlende Angaben bleiben sonst UNRESOLVED. Ein ungebundenes Profil bleibt ungeklärt.

Ergebnis ausschließlich Hook-ID, Status und Gründe. Keine Aussage über Standfestigkeit, Bewegungsrichtung, Position, Orientierung, Schwindel oder Sturz. Keine lineare Beschleunigung, Schwerkraft-/Neigungswahrnehmung oder vollständige Gleichgewichtsregelung in dieser Etappe. Keine Wissens-/Weltänderung und keine implizite Umdeutung anderer Modalitäten.

98 Tests bestanden: 86 bisherige und 12 vestibuläre Testmethoden. Kopplung, inklusive positive/negative Schwellen, Null, fehlende/fremde Kalibrierung, unbekannte Werte, Bindung/Ausprägung, Modalitätstrennung, ungültige Eingaben und Unveränderlichkeit geprüft. Testkonfiguration synthetisch. Kumulativer Stand 5.1 bis 5.3g; produktive Spielintegration und Gesamt-Abnahmen offen.

## 5.3h – Abdeckungsprüfung

Siehe COVERAGE_REPORT.md und COVERAGE.json. 8 von 16 kanonischen Modalitätsnamen exakt abgedeckt; acht Sondernamen offen. Zusätzlicher thermal-Kanal vorhanden. 98 bisherige Tests als übernommener Bericht; keine neue Spielintegration. audit_coverage.py ermöglicht erneuten Abgleich mit einem vollständigen Core.

## 5.3i – Explizite thermal_hook-Unterstützung

ThermalLimits besitzt jetzt das zusätzliche Feld modality mit Standardwert "thermal". Bestehende Aufrufe mit drei Positionsargumenten bleiben kompatibel. Für den kanonischen Hook ausdrücklich ThermalLimits("PROFILE_ID", 15, 0.5, modality="thermal_hook") verwenden; Zahlen sind nur ein Syntaxbeispiel, keine kanonische Kalibrierung.

Hook-Modalität, Profil-Modalität und Limits-Modalität müssen exakt übereinstimmen. thermal und thermal_hook werden nicht umbenannt. Es gibt keine automatische Aktivierung allein durch Origin-Paket oder Hook-Präsenz. Fehlende Bindung bleibt ungeklärt; Ausprägungen und bisherige thermische Grenzprüfungen bleiben erhalten. Beide Namen verwenden das dokumentierte vereinfachte thermische Kontrastmodell, sobald die Engine dieses Profil ausdrücklich autorisiert.

112 Tests bestanden; aktueller Abgleich 9/16 kanonische Namen. COVERAGE_REPORT.md und COVERAGE.json beschreiben den neuen Stand; ältere Abschnitte und der historische 5.3h-Bericht dokumentieren frühere Etappen. Spielintegration und Gesamtfreigabe stehen aus.

## 5.3j – Explizite pressure_hook-Unterstützung

PressureLimits besitzt das zusätzliche Feld modality mit Standardwert "pressure". Alte Aufrufe mit drei Positionsargumenten bleiben kompatibel. Für pressure_hook muss modality="pressure_hook" ausdrücklich angegeben werden. Hook, Sinnesprofil und Limits müssen dieselbe Modalität verwenden. Keine Umbenennung, kein automatisches Aktivieren durch Hook-Präsenz.

Das vorhandene vereinfachte Druckdifferenzmodell wird nach expliziter autorisierter Profilbindung verwendet: Referenz-ID, positive Betragsschwelle und Druckpfad erforderlich. Es ist keine absolute Umgebungsdruckmessung oder biologische Verträglichkeitsprüfung. Bestehende Regeln für fehlende Referenzen, falsche Referenz, unbekannte Angaben und latente Sinne bleiben erhalten.

128 Tests bestanden. Aktuelle Abdeckung 10/16 kanonische Namen; sechs Sondernamen offen. Aktueller Bericht: COVERAGE_REPORT.md und COVERAGE.json. Frühere Abschnitte und historische Berichte beschreiben frühere Stände. Spielintegration weiterhin offen.

## 5.3k – Kalibrierte Lichtreizdetektion

`phantoms_stage5.light.detect_light(bound_sense, limits, conditions)` akzeptiert exakt light_hook. LightLimits enthält profile_id, calibration_id und positive min_irradiance_w_m2. LightConditions enthält calibration_id, received_irradiance_w_m2 und light_path_available; None bedeutet unbekannt.

Die Engine liefert nichtnegative Bestrahlungsstärke am Rezeptor in W/m² nach Ausbreitung/Abschirmung. Die Kalibrierung definiert spektrale Gewichtung, Rezeptorgeometrie und Messfenster; Eingang und Schwelle müssen dieselbe Definition verwenden. Keine automatische Umrechnung von Lux und keine zusätzliche Entfernungsdämpfung. Ein über Reflexion bestätigter Lichtpfad benötigt keine direkte Sicht auf die ursprüngliche Quelle. Das Modul berechnet keinen Lichttransport.

Passende Kalibrierung, aktiver Sinn, bestätigter Pfad und inklusive Schwelle erlauben DETECTED. Null bei bekannter Kalibrierung liegt unter jeder positiven Schwelle. Fremde Kalibrierung wird bei gebundenem Profil abgewiesen; ohne Kalibrierung wird kein Schwellenvergleich vorgenommen. Ein bekannter blockierter Pfad oder latenter Sinn kann unabhängig davon Detektion ausschließen. Ungebundene Profile bleiben ungeklärt.

Ergebnis nur Hook-ID, Status und Gründe. Keine Bildentstehung, Farbe, Richtung, Objektidentität, Photosynthese oder Wissensänderung. light_hook ist kein Alias für visual oder light. Synthetische Testwerte, keine kanonische Artenkalibrierung.

140 Tests bestanden, 11/16 kanonische Namen im Teilumfang unterstützt. COVERAGE_REPORT.md und COVERAGE.json zeigen den aktuellen Stand; ältere Abschnitte sind historisch. Spielintegration und Gesamt-Abnahmen bleiben offen.

## 5.3l – Kalibrierter Luftfeuchtereiz

`phantoms_stage5.moisture.detect_moisture(bound_sense, limits, conditions)` akzeptiert exakt moisture_hook. MoistureLimits enthält profile_id, calibration_id und min_relative_humidity_pct im Bereich größer 0 bis einschließlich 100. MoistureConditions enthält calibration_id, received_relative_humidity_pct (0 bis 100) und receptor_exposed. None bedeutet unbekannt.

Die Engine liefert lokale relative Luftfeuchte am exponierten Rezeptor. Die Kalibrierung bezeichnet Temperatur-/Sättigungsreferenz, Rezeptorbedingungen und Messfenster. Eingang und Schwelle müssen dazu passen. Keine automatische Berechnung aus Temperatur oder absoluter Feuchte. Der Bereich 0–100 ist eine ausdrückliche Begrenzung dieses Spielmodells; Übersättigung ist nicht modelliert und wird als nicht unterstützte Eingabe abgewiesen, nicht abgeschnitten.

DETECTED bedeutet ausschließlich: der konfigurierte Feuchteschwellenreiz ist bei aktiver Quelle und bekannter passender Kalibrierung erreicht. Es bedeutet nicht, dass unterhalb der Schwelle jede Wahrnehmung von Trockenheit unmöglich wäre; diese Reizklasse ist hier nicht implementiert. Grenzwert inklusive. Bekannte fehlende Exposition oder latente Ausprägung blockieren. Unbekannte Kalibrierung verhindert einen Schwellenvergleich; eine fremde bekannte Kalibrierung wird bei gebundenem Profil abgewiesen. Ungebundene Profile bleiben ungeklärt.

Keine Bodenfeuchte, direkter Wasserkontakt, Wasseraufnahme, Durst, Hydratation, Schädigung oder Quellenlokalisierung. Ergebnis enthält nur Hook-ID, Status und Gründe. Keine Wissens-/Weltänderung. Testwerte synthetisch, keine kanonischen Artenprofile.

153 Tests bestanden; aktueller Abgleich 12/16 kanonische Namen. Aktueller Bericht in COVERAGE_REPORT.md und COVERAGE.json; frühere Abschnitte sind historisch. Spielintegration bleibt offen.

## 5.3m – Kalibrierte Magnetfeldkomponente

`phantoms_stage5.magnetic.detect_magnetic(bound_sense, limits, conditions)` akzeptiert exakt magnetoreception_hook. MagneticLimits enthält profile_id, calibration_id und positive min_abs_field_component_ut. MagneticConditions enthält calibration_id, received_field_component_ut und receptor_coupling_available. None bedeutet unbekannt; ut bezeichnet Mikrotesla (µT).

Die Engine liefert eine vorzeichenbehaftete lokale Komponente der magnetischen Flussdichte entlang der kalibrierten Rezeptorachse. Die Kalibrierung definiert Achse, Bezugsrahmen, Rezeptorantwort und Messfenster. Projektion eines Weltvektors und lokale Feldberechnung geschehen außerhalb des Moduls. Eingang und Schwelle müssen zur gleichen Kalibrierung passen. Dies ist ein ausdrücklich vereinfachtes Spielmodell, kein allgemeiner biologischer Mechanismus der Magnetorezeption.

Betrag ab der inklusiven Schwelle, aktive Quelle, passende Kalibrierung und bestätigte Rezeptorkopplung erlauben Detektion. Positive und negative Komponenten sind zulässig. Null bzw. zu geringer Betrag bei passender Kalibrierung blockieren diesen Achsenreiz; daraus folgt kein Urteil über das Gesamtfeld oder andere Achsen. Keine optische Sichtlinie erforderlich; magnetische Abschirmung und lokale Überlagerung muss die Engine berücksichtigen, nicht aus visueller Transparenz ableiten.

Fremde Kalibrierung bei gebundenem Profil wird abgewiesen. Ohne Kalibrierung erfolgt kein Schwellenvergleich. Bekannte fehlende Kopplung oder latente Ausprägung blockieren; fehlende Angaben bleiben sonst ungeklärt. Ungebundene Profile bleiben UNRESOLVED.

Ergebnis nur Hook-ID, Status und Gründe. Kein Kompasswinkel, Nordwissen, Richtung, Standort, Navigation, Quellenidentität oder Schaden. Keine Welt-/Wissensänderung. Testwerte synthetisch; keine kanonische Artenkalibrierung.

166 Tests bestanden; aktueller Abgleich 13/16 kanonische Namen. Aktueller Bericht in COVERAGE_REPORT.md und COVERAGE.json. Spielintegration und Gesamt-Abnahmen bleiben offen.

## 5.3n – Lineare Polarisationswahrnehmung

`phantoms_stage5.polarization.detect_polarization(bound_sense, limits, conditions)` akzeptiert exakt polarization_hook. PolarizationLimits enthält profile_id, calibration_id, positive min_irradiance_w_m2 und min_linear_fraction im Bereich größer 0 bis einschließlich 1. PolarizationConditions enthält calibration_id, received_irradiance_w_m2, polarization_path_available und received_linear_fraction (0 bis 1); None bedeutet unbekannt.

Die Engine liefert gesamte empfangene Bestrahlungsstärke W/m² und zugehörigen linearen Polarisationsgrad nach Ausbreitung, Reflexion und Depolarisation. Beide Werte und Schwellen müssen zu demselben Spektralband, Rezeptorfeld und Zeitfenster passen. Die Kalibrierung beschreibt diese Definitionen sowie die Rezeptorauswertung. Das Modul prüft Kalibrierungs-IDs, berechnet aber weder Stokes-Parameter noch Rezeptorsignale oder Materialeffekte. Null Licht wird bei bekannter Kalibrierung auch bei unbekanntem Polarisationsgrad ausgeschlossen.

DETECTED nur bei aktiver gebundener Quelle, passender Kalibrierung, bestätigtem Pfad und Erfüllung beider inklusiven Schwellen. Hell und unpolarisiert genügt nicht. Fremde Kalibrierung bei gebundenem Profil wird abgewiesen; ohne Kalibrierung kein Schwellenvergleich. Bekannte Pfadblockade oder latenter Sinn blockieren. Fehlende Werte bleiben sonst ungeklärt. Bei vollständig depolarisiertem empfangenem Licht ist der lineare Anteil null, auch wenn ein Lichtpfad existiert.

Vereinfachtes Modell für lineare Polarisation. Keine Polarisationswinkel, zirkuläre Polarisation, Richtung, Navigation, Bildsehen oder Quellenidentität. Keine Welt-/Wissensänderung. Das Ergebnis enthält nur Hook-ID, Status und Gründe. Synthetische Testkonfiguration, keine kanonische Artenkalibrierung.

180 Tests bestanden; aktueller Abgleich 14/16 Namen. Spielintegration und Gesamt-Abnahmen bleiben offen.

## 5.3o – Facettenweise Reizdetektion

`phantoms_stage5.compound_visual.detect_compound_visual(sense, limits, conditions)` akzeptiert exakt compound_visual_hook. CompoundVisualLimits enthält profile_id und ein nichtleeres Tupel aus FacetLimits. Jede Facette hat facet_id, calibration_id, max_distance_m und min_irradiance_w_m2. FacetConditions enthält facet_id, calibration_id, distance_m, received_irradiance_w_m2, in_field_of_view und line_of_sight_clear. Conditions werden als Tupel übergeben; eine fehlende konfigurierte Facette bleibt ungeklärt.

Alle Facetten eines Aufrufs müssen denselben geprüften Reiz im selben Engine-Ereignis betreffen. Die Engine autorisiert diese Zusammengehörigkeit und liefert Facettengeometrie, Gesichtsfeld, Sichtlinie sowie empfangene Bestrahlungsstärke W/m². Kalibrierung definiert Facettenausrichtung, Spektralgewichtung, Geometrie und Messfenster. Keine Geometrie-/Lichttransportberechnung im Modul. Reichweiten- und Lichtgrenzen sind inklusive.

Jede Facette wird getrennt geprüft. DETECTED insgesamt bedeutet mindestens eine detektierende Facette; sonst UNRESOLVED bei mindestens einer ungeklärten Facette; sonst NOT_DETECTED. Ergebnisse bleiben nach Facetten-ID sortiert erhalten. Keine Mehrheitsentscheidung oder Summierung unterschwelliger Lichtwerte. Doppelte oder fremde Facetten-IDs werden abgewiesen; eine fremde Kalibrierung wird auch bei sonst erfolgreicher Facette nicht verschluckt.

Ohne passende Facettenkalibrierung werden deren Messwerte nicht bewertet. LATENT blockiert alle Facetten; fehlende Bindung bleibt ungeklärt und übernimmt keine fremden Limits. Bedingte/ungeklärte Ausprägung wird nicht aktiviert. Es gibt keine Bildrekonstruktion, Sehschärfen-, Bewegungs- oder Objekterkennung. Keine Welt-/Wissensänderung. Das Gesamtergebnis enthält Hook-ID, Status, Gründe und einzelne Facettenergebnisse. Testwerte sind synthetisch.

190 Tests bestanden; Abgleich 15/16 kanonische Namen im Teilumfang. biosensor_hook, produktive Integration und Gesamt-Abnahmen offen.

## 5.3p – Explizite Biosensor-Schnittstelle

`phantoms_stage5.biosensor.detect_biosensor(sense, limits, conditions)` akzeptiert exakt biosensor_hook. BiosensorLimits enthält profile_id, calibration_id, measurement_id, unit_id, min_value und max_value. Das endliche geschlossene Intervall beschreibt den konfigurierten Auslösebereich, nicht Sensorbetriebsgrenzen oder biologische Verträglichkeit. Gleichheit der Grenzen ist zulässig. BiosensorConditions enthält calibration_id, measurement_id, unit_id, received_value und sensor_ready; None bedeutet unbekannt.

Die autorisierte Engine muss ein konkretes biologisch zulässiges Messprofil definieren und Werte liefern. Messgrößen-ID kann beispielsweise einen spezifizierten Rezeptorausgang bezeichnen; die Beispiele im Test sind rein synthetisch. Alle drei Vertrags-IDs müssen exakt passen. Fremde IDs werden bei gebundenem Profil abgewiesen. Ohne vollständige bekannte IDs erfolgt kein Bereichsvergleich. Keine automatische Einheitenumrechnung, Aliasbildung oder universelle Stoffidentifikation.

DETECTED bedeutet ausschließlich: der autorisiert gebundene aktive Sensor ist bereit und sein angegebener Messwert liegt im konfigurierten Auslösebereich. NOT_DETECTED außerhalb des Bereichs bedeutet nicht, dass der Stoff oder das Objekt nicht existiert. Bekannte fehlende Bereitschaft oder latente Ausprägung blockieren. Fehlende Werte bleiben sonst ungeklärt. Ungebundene Profile bleiben UNRESOLVED.

Diese Schnittstelle authentifiziert keine externen Belege, berechnet keine Sensormessung und ersetzt keine spezifischen Modalitätsmodelle. Physikalisch gültige Wertebereiche und Signalaufbereitung gehören zum konkreten autorisierten Sensorvertrag. Ergebnis nur Hook-ID, Status und Gründe, kein Rohwert oder Stoffwissen. Keine Welt-/Wissensänderung.

200 Tests bestanden. 16/16 kanonische Namen mit Entwicklungsbausteinen im Teilumfang; keine Gesamtfreigabe. Die nächste Etappe beginnt die Anbindung an die vorhandene Wissensverwaltung.

## I2 – Erster visueller Wissensadapter

VisualObservationAdapter(engine, lineage_id=..., actor_id=...) bindet die vorhandene EpistemicEngine und eine durch die Engine autorisierte Beobachter-/Geneline-Zuordnung. actor_id=None wählt ausdrücklich Spielerwissen; eine gesetzte ID wählt Akteurwissen. Kein impliziter Wechsel zwischen beiden.

observe(sense, limits, conditions, event_id=..., location=..., world_time=...) führt detect_visual selbst aus. Nichtdetektion und ungeklärtes Ergebnis liefern ObservationOutcome mit commit=None und rufen keinen Wissens-Commit auf. Positive Detektion ruft die vorhandene record_actor_observation bzw. record_player_observation auf. Deren tatsächlicher Rückgabewert wird als commit durchgereicht; Detektion allein ist keine Behauptung über den Commit-Erfolg.

Beobachtungswert ist fest auf {signal_detected: true, modality: visual} begrenzt. Der Schlüssel lautet perception.<event_id>. Herkunft ist die Hook-ID. Keine beliebigen fact_key/value-Parameter, Rohmesswerte, Objektidentitäten oder komplette Weltwahrheit. Wiederholungen gehen durch die bestehende Authority, nicht durch einen neuen Commit-Mechanismus.

Vertrauensgrenze: Dies ist eine interne Engine-Schnittstelle. Der Aufrufer muss Geneline/Beobachter, aktuelle Weltbedingungen, Ort und Zeitpunkt sowie die richtige Run-Engine autorisieren. Das Modul prüft gleiche Geneline-ID, aber noch keine Besitz-/Positionsdaten aus einem Save. Keine untrusted Client-API; keine kryptografische Authentifizierung. Eine direkte Nutzung der bestehenden Stage3D-Methoden außerhalb des Adapters wird nicht verhindert. Alle anderen Sinneskanäle und echte Spielaktionen bleiben noch anzubinden.

208 Tests bestanden, davon 8 neue Stage3D-Integrationsprüfungen. Master unverändert. Folgeschritt I3 prüft echte RunSession-Zuordnung und Persistenz; Gesamtfreigabe und Modell-/DEMO-Abnahmen bleiben offen.

## I3 – Explizite Spielsitzung und Persistenz

SessionVisualObserver(manager, identity, lineage_id=..., actor_id=...) aus phantoms_stage5.session_observation bindet eine bereits geöffnete echte RunSession. observe(identity, sense, limits, conditions, event_id=..., location=..., world_time=...) benötigt bei jedem Aufruf dieselbe RunIdentity aus player_uuid und run_uuid. Der Manager wird erneut abgefragt; es gibt keinen aktuellen/letzten Run als Fallback. Geschlossene Sitzungen werden abgewiesen. Nach Laden oder Ersetzen der Sitzung muss ein neuer Observer gebunden werden; ein alter Observer darf nicht in einen veralteten Store schreiben.

Persistenz erfolgt weiterhin ausdrücklich über FilesystemRunRepository.save(session) und load_session(manager, identity). observe führt keinen automatischen Dateispeichervorgang aus. Die Tests verwenden ausschließlich synthetische Identitäten und temporäre Verzeichnisse. Beobachtungswerte und Herkunftsmetadaten bleiben beim Laden erhalten; wiederholte Ereignisse nutzen die vorhandene Authority.

Die Sitzungstrennung ersetzt keine Spieleranmeldung und keine Prüfung, ob eine Geneline tatsächlich dem ausgewählten Akteur gehört. Die Engine muss Beobachterbindung, Quelle, Ort, Weltzeit und Messwerte autorisieren. Der Adapter prüft Sitzung und Geneline-Übereinstimmung im dokumentierten Vertrauensmodell. Er ist kein untrusted Client-Endpunkt. Der private Core bleibt unverändert.

216 Tests bestanden. Positive visuelle Beobachtung persistiert, negative/ungeklärte erzeugt kein Wissen. Echte Turn-Loop-Anbindung, übrige Sinnesadapter und Gesamt-Abnahmen bleiben offen.
