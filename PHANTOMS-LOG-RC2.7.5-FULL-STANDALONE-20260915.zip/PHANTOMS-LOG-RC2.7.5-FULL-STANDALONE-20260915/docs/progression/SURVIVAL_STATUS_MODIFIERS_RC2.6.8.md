# Survival status modifiers — canonical capability model

Survival pressure does **not** rewrite permanent character values. The stored character tree remains authoritative:

**Stats → Skills → Talents → Expertises**

Stage-7 embodied needs may create temporary condition flags. `IMPAIRED` contributes a -1 condition penalty for an affected capability and `CRITICAL` contributes -2 for that need. The two severities of the same need never stack; different needs may stack up to the configured total cap.

Effective values are calculated only when an action is evaluated:

`current usable capability = stored base - temporary condition penalty + matching mitigation`

A mitigation can never raise current usable performance above the stored base and can never convert a natural `HARD_LIMIT` into a possible action. Stats floor at 1; Skills floor at 0.

Examples of canonical domain mitigation include:

- `TALENT_UNYIELDING` for Belastungskontrolle/Selbstkontrolle under matching temporary pressure
- `TALENT_FORCE_LINE` for trained Kraftanwendung without increasing the natural strength ceiling
- `TALENT_PHANTOM_STEP` / `TALENT_BLIND_MOVEMENT` for matching movement-control domains
- `TALENT_MACHINEWORK` / `TALENT_FIELD_REPAIR` for matching technical domains
- `TALENT_AURA_READING` / `TALENT_MEDIUMSHIP` for matching resonance-control domains

Playable checks use canonical `STAT_*`, `SKILL_*` and `TALENT_*` IDs only. Survival condition logic changes present usability, not identity, learned capability, or natural limits.
