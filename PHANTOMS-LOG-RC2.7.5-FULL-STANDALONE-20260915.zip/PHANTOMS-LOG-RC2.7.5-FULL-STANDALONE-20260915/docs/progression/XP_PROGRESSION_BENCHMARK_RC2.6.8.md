# XP Progression Benchmark — RC2.6.8 calibrated hotfix

## Level curve

Levels 1–3 preserve the onboarding thresholds: **Level 2 = 12 XP**, **Level 3 = 36 XP**.

For levels 4–50:

`XP(level) = 36 + 1064 × ((level - 3) / 47)^1.4`

The level cap is 50 at **1100 cumulative XP**.

| Level | Cumulative XP |
|---:|---:|
| 1 | 0.000 |
| 2 | 12.000 |
| 3 | 36.000 |
| 5 | 48.807 |
| 10 | 109.985 |
| 20 | 292.232 |
| 30 | 525.682 |
| 40 | 797.179 |
| 50 | 1100.000 |

## Gameplay XP

XP comes from the existing meaningful-action/evidence pipeline rather than a flat reward per click. Difficulty, consequence, variety, intentionality, outcome, novelty and risk can improve effective evidence; repetition, triviality and exploit signals reduce it. One event remains capped at 4 effective XP.

Legacy RC2.6.8 saves without an XP field backfill their existing `pattern_evidence` once.

## Time-to-Level-50 benchmark

These are calibration scenarios, not measured player telemetry.

| Scenario | Meaningful actions/hour | Avg effective XP/action | XP/hour | Approx. Level-50 time |
|---|---:|---:|---:|---:|
| Cautious / low-risk | 8 | 0.45 | 3.6 | 305.6 h |
| Normal varied play | 12 | 0.75 | 9.0 | 122.2 h |
| Active / high-risk | 16 | 1.10 | 17.6 | 62.5 h |

The design target is approximately **100–150 hours for a normal varied playthrough**. The current normal benchmark is **122.2 hours**. High-risk/efficient play can reach the cap faster, while cautious low-yield play takes substantially longer.

Real player telemetry should later replace these assumptions.
