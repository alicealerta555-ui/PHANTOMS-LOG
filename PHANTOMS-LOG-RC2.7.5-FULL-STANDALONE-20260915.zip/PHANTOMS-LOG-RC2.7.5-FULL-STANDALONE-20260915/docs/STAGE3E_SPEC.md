# PH4NT0M5-L0G · Stage 3E Specification

**Date:** 2026-09-03  
**Status:** VERIFIED + INTEGRATED  
**Base:** Stage 3A + 3B + 3C + 3D current master

## Purpose

Stage 3E operationalizes two LOCK9 requirements: controlled resolution of genuinely unknown Ground Truth and neutral exogenous circumstances that can disrupt exploitable patterns without becoming arbitrary plot generation.

## Ground-Truth contract

1. Exploratory/player language is `QUERY`/`NO_COMMIT`; it cannot directly write proposed content.
2. A query may trigger resolution only for a key already registered in `UNRESOLVED_WORLD`.
3. The Stage-3E resolver API does not accept player suggestion data when performing resolution.
4. Resolution uses only the predeclared weighted possibility space and deterministic run/world seed material.
5. Resolution consumes the unresolved possibility space and commits one stable `WORLD_TRUTH` value.
6. A resolved key is never rerolled.
7. Known state is simulated causally; it is not sent back through unknown-state randomization.

## Circumstance contract

Circumstances are a neutral exogenous engine actor, not an LLM plot generator. A candidate must pass all relevant guards before it is eligible:

- **Plausibility Guard:** committed-state preconditions must be true.
- **State/Story Integrity Guard:** explicit integrity conditions and target protection must pass.
- **Interest Guard:** a live interest signal or sufficient predeclared intrinsic interest is required.

Only after guard eligibility may deterministic weighted selection and anti-pattern choice occur.

### Hard restrictions

- The action-facing circumstance API receives engine IDs only; no player text or suggestion enters selection.
- Circumstances may write only `RUNTIME_STATE` or explicitly declared mutable `WORLD_TRUTH` through `RULE_KERNEL` and the Stage-3A commit path.
- A `WORLD_TRUTH` circumstance update requires the key to already exist, be declared mutable in the circumstance spec, and match an expected current value.
- Circumstances cannot create an absent latent truth, write `UNRESOLVED_WORLD`, or directly write Actor/Player Knowledge.
- Knowledge about a circumstance still requires Stage-3D observation/propagation.
- Anti-pattern logic may only choose among candidates that already passed all guards. It cannot make an implausible candidate eligible.
- Cooldowns and deterministic trigger sequence are persisted in run-local `RUNTIME_STATE` and therefore survive Stage-3C save/load.
- Duplicate trigger IDs are idempotent and do not reroll or advance the sequence twice.

## 3B integration order

For an action requiring a circumstance check:

`schema → collect known facts → known-precondition gate → Stage-3E circumstance check → re-read known facts → known-precondition gate → allowed unknown resolution → final preconditions → RNG/outcome → verification → atomic commit → narration`

This prevents an already impossible action from materializing an unnecessary circumstance and ensures a circumstance that actually changes known state is re-evaluated before unknown facts are resolved.
