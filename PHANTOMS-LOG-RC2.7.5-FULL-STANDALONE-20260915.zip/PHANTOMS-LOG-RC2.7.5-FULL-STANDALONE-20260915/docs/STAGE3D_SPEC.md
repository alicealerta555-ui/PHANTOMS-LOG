# PH4NT0M5-L0G · Stage 3D · Epistemic Engine Layer

**Date:** 2026-09-03  
**Base:** `PhantomsLog 0.2.2.0` current private master  
**Status:** IMPLEMENTED · VERIFIED · INTEGRATED

## Purpose

Stage 3D makes knowledge causal. A fact in `WORLD_TRUTH` does not become actor or player knowledge merely because the engine knows it. Runtime knowledge must have an explicit source and acquisition history.

## Knowledge stamp

Every runtime write by `KNOWLEDGE_ROUTER` to `ACTOR_KNOWLEDGE` or `PLAYER_KNOWLEDGE` carries:

- `source_type`
- `source_id`
- `origin_location`
- `learned_at`
- explicit transmission `path`
- `confidence_ppm`
- zero or more `distortions`

Direct observation has an empty transmission path. Relayed information contains ordered route hops with edge, origin, destination, channel, departure time and arrival time.

`SYSTEM_INIT` remains able to seed static/bootstrap knowledge, but unstamped bootstrap knowledge may not be relayed as if it had a runtime causal history.

## Information geography

`InformationGraph` provides deterministic weighted routing over static location/communication edges. Effective propagation time can be changed by current run modifiers:

- traffic / carrier flow;
- information hubs;
- season delays;
- event delays or acceleration (including war, closures, festival flow, trade surges, etc.);
- route closure;
- route reliability.

Equal-time routes are resolved deterministically. Information cannot arrive before the computed route time.

## Relay lifecycle

`SOURCE ACTOR KNOWS FACT -> ROUTE PLAN -> PENDING RUNTIME MESSAGE -> ARRIVAL TIME -> KNOWLEDGE COMMIT`

Pending messages are mutable run state and therefore inherit Stage-3C player/run isolation and persistence. Delivery writes knowledge only through the Stage-3A commit kernel.

## Distortion

Distortion is allowed only through predeclared `DistortionVariant` alternatives. A deterministic run-seeded decision may replace the relayed claim and records the distortion tag and route hop. It never changes `WORLD_TRUTH`.

No free-form or narrator-generated distortion is accepted as authoritative state.

## Context projection

Actor epistemic context contains only the requested actor's knowledge records and their source metadata. `WORLD_TRUTH`, unresolved state and other actors' knowledge are not exposed by the Stage-3D projector.

## Persistence

Stage-3C serialization preserves epistemic metadata in current knowledge state and in the event ledger. Pending messages survive save/load under the exact `(player_uuid, run_uuid)` session identity.

## Hard invariants

1. `WORLD_TRUTH != ACTOR_KNOWLEDGE != PLAYER_KNOWLEDGE`.
2. Truth alone is never sufficient evidence that an actor knows it.
3. Runtime knowledge must have source, origin and time.
4. Relayed knowledge must have a causal path and cannot arrive early.
5. A source actor cannot relay a fact it does not possess.
6. Unstamped bootstrap knowledge cannot masquerade as runtime-learned knowledge.
7. Traffic/hub/season/event conditions alter propagation through deterministic run inputs, not narration.
8. Distortion can alter a claim, never objective truth.
9. Pending information is isolated and persistent per run.
10. Stage 3D never writes committed state directly; all writes pass through Stage 3A.
