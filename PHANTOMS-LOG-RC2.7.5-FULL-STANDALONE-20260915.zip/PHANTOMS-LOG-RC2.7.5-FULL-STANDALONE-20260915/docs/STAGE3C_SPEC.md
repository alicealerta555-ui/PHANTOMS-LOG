# Stage 3C · Runtime-State Isolation

**Status:** implementation candidate

## Hard contract

1. Every player has an explicit canonical `player_uuid`.
2. Every new run has an explicit canonical `run_uuid`.
3. Runtime state is owned by the exact tuple `(player_uuid, run_uuid)`.
4. There is no `current`, `last`, default-player or nearest-match fallback.
5. A lookup for an unknown tuple fails closed.
6. Two runs never share a mutable `StateStore`.
7. Each run receives a deterministic seed derived from master seed + both UUIDs; player text is excluded.
8. All mutable state — world truth resolved during the run, unresolved spaces, actor/player knowledge, runtime state, event ledger and revision — persists beneath the owning tuple.
9. Save identity and state hash are verified on load.
10. Mutable saves must live outside protected static-core roots.
11. Static core/training/benchmarks contain no concrete player/save/run data. Tests use synthetic temporary UUID fixtures only.
12. Stage 3A remains the sole commit authority and Stage 3B remains the action pipeline inside each isolated run session.

## Persistence layout

`<external_save_root>/<player_uuid>/<run_uuid>/state.json`

No loader may scan sibling directories to substitute another player or run when this exact path is absent.
