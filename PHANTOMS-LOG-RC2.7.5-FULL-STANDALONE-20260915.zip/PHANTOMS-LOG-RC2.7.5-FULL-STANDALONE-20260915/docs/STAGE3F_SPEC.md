# Stage 3F · Tenfold Verification Gate

**Status:** VERIFIED + INTEGRATED  
**Date:** 2026-09-03  
**Base:** Stage 3A–3E current master

## Purpose

Stage 3F turns the previously specified tenfold self-verification target into an operational structured gate. It is not a second state engine and it does not inspect free player prose for semantic danger words. It verifies structured facts, candidate deltas, causal metadata and presentation boundaries.

## Mandatory dimensions

Every Stage-3F report contains exactly ten signals:

1. `STATE`
2. `INVENTORY_RESOURCES`
3. `TIME`
4. `POSITION_SPACE`
5. `RULES_MECHANICS`
6. `CAUSALITY_PRECONDITIONS`
7. `NPC_KNOWLEDGE_EPISTEMICS`
8. `MEMORY_RETCON`
9. `PLAYER_AGENCY`
10. `NARRATION_VS_COMMIT`

A proven hard contradiction produces `REJECT`. Missing information by itself does not. There is no semantic keyword veto over `player_text`.

## Integration

The same per-run `TenfoldVerificationGate` is attached in two places:

- Stage 3B `PreCommitVerifier` for selected action/outcome verification.
- Stage 3A `PreCommitGuard` after structural delta validation and before every persistent commit.

This means action, world-sim, epistemic, ground-truth and circumstance writes share the same global gate. The gate is owned by one Stage-3C `RunSession` and cannot be reused against another store.

## Hard checks implemented now

- conflicting writes to the same target inside one transaction;
- unresolved Ground Truth cannot be bypassed by a normal rule write;
- explicitly classified resource/inventory quantities cannot become negative;
- canonical monotonic time keys cannot regress;
- explicitly classified position keys cannot become clearly empty/invalid;
- outcome conditions and preconditions are independently rechecked from structured facts/RNG;
- writer/domain mechanics are cross-checked against Stage 3A authority rules;
- knowledge route continuity, route arrival, acquisition time and known world-time are cross-checked;
- knowledge acquisition timestamps cannot regress;
- immutable Ground Truth resolved from an immutable unresolved specification cannot later be retconned;
- engine commits may not manufacture persistent `player.choice`/`player.intent`/equivalent agency state;
- narration-output namespaces cannot become persistent state and hidden domains cannot be requested as narration-runtime keys;
- final player-facing projection can be independently checked for safe shape and revision.

## False-veto rule

Stage 3F is intentionally conservative. Unknown or unclassified state passes unless a structured contract proves a contradiction. Example: a negative temperature is valid; a negative `credits` balance under the current resource convention is rejected. The verifier AST audit additionally fails if Stage 3F begins reading `request.player_text` directly.

## Boundaries

Stage 3F does not replace:

- Stage 3A structural authority validation;
- Stage 3B declarative action resolution;
- Stage 3C run isolation;
- Stage 3D epistemic routing;
- Stage 3E plausibility/ground-truth resolution;
- Stage 3G multi-turn and minimal-pair closure harness.

Later mechanics may register narrower structured policies as they become canonical. Stage 3F must not guess future gameplay semantics from names or prose.
