# Stage 4G · Biological Validation / Closure

**Authority date:** 2026-09-03  
**Status:** VERIFIED / INTEGRATED / CLOSURE PASS

Stage 4G adds no new phenotype generator or gameplay state writer. It closes Stage 4 by composing the Stage-4A–4F validators into a fail-closed biological validation matrix.

## Closure invariants

1. **Chronology / causality** — biological processes and lineage provenance may not be backdated before their Stage-4A prerequisites.
2. **Costed capability** — advantages require explicit costs or constraints; regeneration and origin contributions cannot be free upgrades.
3. **Origin provenance / tradeoffs** — every Stage-4C functional candidate remains source-attributed and retains the tradeoffs required by its source package.
4. **Hybrid ancestry causality** — Mono/Multi/Poly classification follows the ancestry/integration DAG and its historical phases, not visible trait count.
5. **Biological coherence** — unresolved/conflicted combinations may remain unresolved, but a `CONFLICTED` composition may not simultaneously assert active phenotype candidates.
6. **No genetic destiny** — biology may not encode morality, personality, consent, attraction, profession, loyalty, hostility or chosen behavior.
7. **Branch-axis separation** — sapience assessment, feral history, synthetic origin and drift ancestry remain orthogonal evidence-backed axes.
8. **Influence is not decision** — Stage-4F pressure/envelope output remains influence-only; deliberate choice belongs to the individual actor/runtime.
9. **Stage-5/6 boundary** — Stage 4 may expose hooks but may not own detailed perception, communication, germline, inheritance, fertility or speciation mechanics.
10. **Complexity preservation** — multiple biological sources and unresolved candidates remain separately attributable; no automatic averaging, archetype collapse or phenotype selection.

## Closure harness

`validation/stage4g/` executes 14 dedicated closure cases:

- 10 adversarial minimal pairs, one for every required invariant;
- 4 multi-layer chains that validate cross-layer composition, context divergence, unresolved multi-source complexity and fail-closed bundle validation.

Closure fails if a scenario fails **or** required invariant coverage is missing.

## Post-Stage-4 gate

Stage 4 closure does **not** activate Stage 5. The next mandatory project step is model training/evaluation against the closed Stage-4 Core. Stage 5 remains blocked until that gate is consciously completed.
