# Stage 4F · Cognitive Drift / Behavioral Echoes

**Authority date:** 2026-09-03  
**Status:** IMPLEMENTED / VALIDATION PENDING

Stage 4F models bounded biological predispositions and biologically/culturally reinforced behavioral echoes without converting lineage into personality or destiny.

## Core causal order

The runtime keeps the four causal layers separate:

`BIO disposition → culture/history → individual psychology/values → current situation → behavior`

Stage 4F ends **before behavior selection**. It returns an influence envelope containing separate contributions, net pressures and unresolved conflicts. Final deliberate choice remains owned by the individual actor/runtime layer.

## Cognitive Drift is not the Stage-4E DRIFT branch

`DRIFT` in Stage 4E is evolutionary/source history. `Cognitive Drift` in Stage 4F is an evidence-backed population-level influence model. Neither implies the other:

- a Stage-4E DRIFT lineage receives no automatic cognitive disposition;
- a non-DRIFT lineage may have evidence-backed Stage-4F dispositions;
- morphology, origin-package family and branch label never infer morality, cognition, hostility or choice.

## Biological dispositions

A biological disposition is a bounded signal on a cognitive/physiological domain such as attentional salience, activation threshold, recovery tempo, novelty salience, uncertainty tolerance, pattern completion, social-cue salience or impulse gating.

Properties:

- explicit evidence and scope are mandatory;
- magnitude is bounded below deterministic strength;
- activation may require situation tags;
- physiological and cognitive response layers remain separate;
- no disposition stores an action, preference, moral trait, relationship choice or consent state.

## Behavioral echoes

A behavioral echo is not inherited behavior. It is a **bio-cultural reinforcement signal** and activates only when all required causes are present:

1. its referenced biological disposition is active;
2. its explicit culture/history anchor is present in context;
3. its situation trigger is present.

The echo is capped more strictly than a direct biological disposition and still produces only influence pressure.

## Complex / conflicting reasoning

Stage 4F deliberately preserves every causal contribution. Opposing biological, cultural, individual and situational influences remain visible simultaneously. A zero or clamped net score does not delete the underlying conflict or provenance.

This prevents simplifications such as:

- `animal ancestry → aggression`;
- `feral → stupid/hostile`;
- `synthetic → obedient`;
- `drift → unstable personality`;
- `physiological arousal → conscious consent/choice`.

## Boundary to later stages

- Stage 5 owns detailed sensory channels and communication.
- Stage 6 owns inheritance/germline/speciation.
- Stage 7 owns full needs/motivation and individual decision hierarchy.
- Stage 9 owns concrete cultures and social institutions.

Stage 4F provides typed interfaces for those layers without prematurely implementing them.
