# Stage 4C · Functional Origin Packages Specification

## Purpose

Stage 4C defines canonical functional biological source packages used by the Stage-4B Geneline Matrix. An origin package is a causal source-space for traits, not a species template, personality archetype or automatic trait bundle.

## Canonical source families

The current canonical registry covers exactly these eight functional families:

- Mammalian
- Avian
- Reptilian
- Amphibian
- Fish/Cephalopod
- Arthropod/Insect
- Fungal/Plant/Microbial
- Synthetic Biology

These are engineering/source groupings rather than claims that every organism in a taxonomic group shares every listed trait.

## Hard rules

- Linking a package records biological provenance; it does **not** auto-copy all package capabilities into a lineage.
- Every positive functional contribution must reference at least one explicit tradeoff/constraint.
- Every declared tradeoff must constrain at least one contribution; decorative costs are rejected.
- Package availability is Stage-4A chronological: a lineage may not cite a package before that package's earliest allowed Superevolution phase.
- Package provenance is WORLD_TRUTH only.
- Biological tags may not encode morality, profession, dominance/submission, attraction, consent, personality, loyalty or obedience.
- Stage-5 sensor detail remains out of scope; packages expose modality hooks only.
- Stage-6 alleles, germline, fertility and inheritance mechanics remain out of scope.
- Stage 4C is static biological-core data and has no player/run state writer.

## Canonical package roles

- `ORG_MAMMALIAN_HOMEOSTASIS`: thermoregulation, sustained aerobic output and soft-tissue repair motifs with energy/heat/material costs.
- `ORG_AVIAN_RESPIRATORY_STRUCTURAL`: respiratory throughput, reduced-mass structures, aerial-locomotion and insulation hooks with load/energy/maintenance costs.
- `ORG_REPTILIAN_WATER_THERMAL`: water conservation, lower baseline throughput and keratinized protection with temperature/exchange/renewal tradeoffs.
- `ORG_AMPHIBIAN_EXCHANGE_PLASTICITY`: cutaneous exchange, wet-interface adaptation and tissue plasticity with dehydration/contaminant/barrier costs.
- `ORG_AQUATIC_FISH_CEPHALOPOD`: aquatic respiration, hydrodynamic movement, pigment-control and flexible-appendage hooks with water/support/energy constraints.
- `ORG_ARTHROPOD_INSECT_SEGMENTAL`: exoskeletal support, segmented specialization and local strength-to-mass hooks with growth/scaling/control costs.
- `ORG_FUNGAL_PLANT_MICROBIAL_SYMBIOSIS`: symbiotic processing, substrate specialization, supplemental environmental energy capture and modular growth with ecology/specificity/power/time constraints.
- `ORG_SYNTHETIC_BIOLOGY_PLATFORM`: engineered biochemistry, scaffold tissues, biosensor interfaces and modular biological subsystems with feedstock/calibration/compatibility/integration costs.

## Combinatorial design-space contract

A resolved lineage may cite multiple functional source packages simultaneously. Package membership is set-like and canonical-order, so caller ordering has no biological meaning. `build_origin_design_space()` exposes every source-supported contribution as a separate candidate carrying its package/family attribution and exact required tradeoffs.

The Stage-4C layer deliberately does **not** rank, average, merge, select or auto-express those candidates. Multiple packages may contribute possibilities in the same functional domain without one erasing the others. This preserves a high-dimensional causal design space for later reasoning rather than collapsing a lineage into a single archetype.

## Stage boundary

Stage 4D owns Mono/Multi/Polyhybrid classification and integration-depth semantics. Stage 5 owns detailed sense-scapes. Stage 6 owns germline/inheritance/speciation mechanics.
