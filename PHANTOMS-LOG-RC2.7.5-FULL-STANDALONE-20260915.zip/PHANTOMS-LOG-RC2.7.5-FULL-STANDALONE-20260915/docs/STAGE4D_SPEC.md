# Stage 4D · Mono / Multi / Polyhybrids

**Authority date:** 2026-09-03  
**Status:** VERIFIED / INTEGRATED

Stage 4D classifies hybrid ancestry from causal lineage structure, not visible animal-part count, stereotype, package count or current phenotype.

## Core model

A `HybridCompositionRecord` contains:

- independent `HybridSourceComponent`s with source-lineage and Stage-4C origin-package provenance;
- a directed acyclic integration graph (`IntegrationNode`);
- source-qualified active / latent / conditional expression-candidate partitions;
- a separate biological-coherence assessment;
- WORLD_TRUTH provenance.

Unassigned Stage-4C candidates remain unresolved possibilities. Stage 4D never auto-selects phenotype.

## Classification semantics

- **MONO** — one independent source-lineage complex. A MONO lineage may reference multiple functional origin packages because package count is not ancestry count.
- **MULTI** — multiple independent source-lineage complexes without qualifying nested poly ancestry. A single-horizon integration can contain many sources and still be MULTI.
- **POLY** — at least three independent source-lineage complexes plus nested composite ancestry: an earlier composite is later consumed by repeated mixing. This is a hybrid-of-hybrids history, not merely a high visible-trait count.

A two-source backcross can have integration depth >1 while remaining MULTI. Classification therefore depends on both independent-source structure and integration history.

## Chronology

- direct first-horizon hybridization maps to Stage-4A B2 / E2;
- nested composite input is forbidden in B2 direct hybridization;
- repeated/nested mixing maps to B3 / E2–E3;
- later B4–B6 lineages may inherit this ancestry history but Stage 4D does not invent new unsupported integration events in those phases.

## Expression-space rule

`TraitCandidateRef` is source-qualified by component + package + contribution. Active, latent and conditional sets are disjoint. `latent` means an unexpressed/available Stage-4C contribution context only; it does **not** define alleles, germline transmission, penetrance or other Stage-6 inheritance mechanics.

Visible phenotype does not determine ancestry class, and ancestry class does not determine personality, morality, consent, attraction, social role or behavior.

## Stage boundaries

Stage 5 owns detailed sense-scapes and communication. Stage 6 owns germline, inheritance, compatibility and speciation mechanics. Stage 4E owns sapient/semi-sapient/feral/synthetic/drift branch classes.
