# Stage 3B · Action → Resolution → Commit

Status: DEVELOPMENT
Basis: Stage 3A Foundation Workbase

## Verbindlicher Laufweg

`ActionRequest → Rule-Schema → Fact Read → zulässige Unknown-Resolution → Preconditions → deterministic RNG → Outcome → candidate Delta → PreCommitVerifier → Stage3A CommitKernel → player-facing Narration Projection`

## Harte Regeln

- Spielertext, LLM-Draft und Narration besitzen kein State-Schreibrecht.
- Action Rules sind deklarativ; kein Rule-Callback bekommt Zugriff auf den mutierbaren StateStore.
- Unknown Ground Truth darf nur über den Stage-3A World Resolver resolvt werden.
- Spielertext und Player Suggestion sind kein RNG-/Resolution-Seedmaterial.
- Fehlende harte Preconditions blockieren die Aktion ohne Action-Commit.
- Optional fehlende Fakten können mit `NOT_EXISTS` geprüft werden.
- Persistente Action-Effekte werden ausschließlich als Candidate Deltas erzeugt.
- Vor dem Commit liegt ein explizites `PreCommitVerifier`-Gate. Stage 3F kann dieses Interface um die zehn Verifikationsdimensionen erweitern, ohne 3B umzubauen.
- `SYSTEM_INIT` und direkte `UNRESOLVED_WORLD`-Writes sind innerhalb normaler Spieleraktionen verboten.
- Knowledge-Effekte benötigen Provenienz; Actor Knowledge zusätzlich actor_id.
- Erst nach erfolgreichem Commit wird die Narration-Projektion erzeugt.
- Die Narration-Projektion enthält kein WORLD_TRUTH.
- Circumstances werden in 3B nicht improvisiert. Im aktuellen Build verlangt `requires_circumstance=True` eine `circumstance_id`; Ausführung erfolgt über den integrierten Stage-3E-Provider. Ohne Provider bleibt die Aktion fail-closed/HOLD.

## Absichtliche Nicht-Ziele

- Das vollständige Tenfold Verification Gate ist seit Stage 3F integriert.
- Circumstance Engine: über `runtime/stage3e/` integriert; 3B bleibt nur Orchestrierungs-/Providergrenze.
- Run-/Player-Isolation: Stage 3C.
- Vollständige epistemische Informationsausbreitung: Stage 3D.

Diese Trennung verhindert, dass Stage 3B spätere Blöcke durch provisorische Nebenpfade umgeht.
