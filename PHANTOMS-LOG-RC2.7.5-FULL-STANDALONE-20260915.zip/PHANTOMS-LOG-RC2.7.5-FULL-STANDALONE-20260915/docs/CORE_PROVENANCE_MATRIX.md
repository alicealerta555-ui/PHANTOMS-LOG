# Core provenance matrix

| Reconstructed contract | Surviving source evidence | Current-master treatment |
|---|---|---|
| Static core must not contain run state | Current master + historical runtime clearly mixed CURRENT_STATE with rules | concrete historical run values removed |
| World before story / locked hidden facts | historical runtime core and mission system | retained as hard invariant |
| Fixed P0–P9 + atomic commit | v0.375 validation/evaluation | connected to Stage-3A FixedPhaseCommitBuffer |
| Event-driven + multi-rate + HOT/WARM/COLD | v0.375 validation/evaluation | retained; numeric cadence configurable, not invented as canon |
| Player presence not a world cause | v0.375 validation | hard rejection in orchestrator |
| Actor knowledge boundaries | v0.375 validation + current master | authority layer preserved; full epistemic implementation remains on current Stage-3 roadmap |
| Mission persistence | historical missions system | generic RANDOM_EPHEMERAL / PERSISTENT_ECHO / PERSISTENT_WORLD_CHANGE contract |
| Multiple real solution families | historical missions system + current master solvability rule | DIRECT / STEALTH / TECHNICAL generic contract |
| Equipment/bestiary provenance and symmetric usage | historical equipment/bestiary databases | generic catalog contracts retained; historical run ownership not copied |
| Stage-2 E0–E5 causal history | current master/Stage-2 handoff | represented as immutable foundation chronology |
| Stage-3A/3B | current master workbase | carried forward unchanged except integration with reconstructed shell |
