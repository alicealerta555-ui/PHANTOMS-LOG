# Stage 3G · Stage-3 Closure Test Harness

**Status:** ✅ VERIFIED + INTEGRATED · Stage 3 CLOSED  
**Date:** 2026-09-03  
**Base:** Stage 3A–3F current master

## Purpose

Stage 3G adds no gameplay mechanics and no new state authority. It is the fail-closed release gate for Stage 3. It executes adversarial minimal pairs and multi-turn chains against the integrated Stage 3A–3F runtime and refuses closure if either behavior or coverage is incomplete.

## Required closure invariants

1. Authority / atomicity
2. No reality-write from exploratory player language
3. Anti-suggestion
4. No reroll of resolved Ground Truth
5. Causal epistemics
6. Circumstance guards
7. No semantic false-veto from player prose
8. Narration remains projection-only
9. Tenfold hard-veto behavior
10. Player/run isolation and no fallback
11. Multi-turn stability across commit, relay, circumstance, veto and save/reload chains

## Harness structure

`validation/stage3g/harness.py` provides a deterministic anonymous fixture layer, scenario results and a closure report. The current closure matrix contains nine minimal-pair cases and five multi-turn cases. Stage 3 can close only when:

- every scenario passes;
- every required invariant is covered;
- every required single-difference invariant has minimal-pair coverage;
- every cross-turn invariant has multi-turn coverage;
- no scenario mutates committed state outside the existing Stage-3A authority path.

The harness deliberately uses synthetic UUIDv5 fixture identities and temporary save roots only. It never imports concrete player/save/run data into static core or training material.

## Boundaries

Stage 3G is validation tooling. It does not become a new persistent runtime writer, does not alter RNG weighting, does not relax Stage 3F, and does not create a new `.0` game version.
