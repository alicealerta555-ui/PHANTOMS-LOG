# Stage 4B · Geneline Matrix Specification

## Purpose

Stage 4B defines the canonical typed data schema for biological genelines. It is a static biological truth model, not a save-state system and not a personality generator.

## Canonical record domains

Every `GenelineRecord` has explicit fields for:

- lineage identity;
- Stage-4C origin-package linkage;
- morphology and broad locomotion/structural hooks;
- metabolism and energetic-cost hooks;
- environmental envelope;
- regeneration capability plus costs/constraints;
- Stage-5 sensor capability hooks only;
- biological stability status;
- Stage-4D hybridization/classification hooks;
- known biological constraints;
- Stage-4A-aligned provenance in `WORLD_TRUTH`.

## Hard boundaries

- No arbitrary metadata dictionary is provided as a semantic backdoor.
- Morality, profession, dominance/submission, attraction, consent, personality, loyalty and obedience may not be encoded as biological tags.
- Detailed sense-scapes and sensor response functions remain Stage 5.
- Alleles, germline rules, inheritance probabilities and fertility-compatibility mechanics remain Stage 6.
- Origin packages may remain explicitly `PENDING_STAGE_4C`; a package cannot be marked resolved without references.
- Hybrid classification remains owned by Stage 4D.
- Public belief cannot be used as biological provenance; lineage records require `WORLD_TRUTH` provenance.
- Provenance phase/epoch combinations must be valid under Stage 4A.
- Nontrivial regeneration must carry at least one cost or constraint.

## Deterministic registry

`GenelineMatrix` rejects duplicate IDs, returns sorted records, exports a canonical payload and produces an order-independent SHA-256 digest. The matrix is static-core data only; it has no CommitKernel or runtime state writer.

## Code

- `runtime/stage4b/geneline_matrix.py`
- `tests/test_stage4b.py`
- `stage4b_stress.py`
- `smoke_stage4b_e2e.py`
- `scripts/stage4b_geneline_audit.py`

## Downstream interface

Stage 4C resolves functional origin-package references. Stage 4D interprets lineage composition/hybridization classes. Stage 5 expands sensor hooks into actual sense-scapes. Stage 6 owns germline/inheritance/speciation mechanics.
