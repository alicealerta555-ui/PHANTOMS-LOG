# Stage 4A · Superevolution Timeline Specification

## Purpose

Stage 4A turns the broad Stage-2 biological history into an executable causal ordering. It refines E0–E5; it does not replace them.

## Canonical biological sequence

1. `B0` bounded therapeutic precursors · E0–E1
2. `B1` directed adaptation · E1
3. `B2` directed hybridization · E2
4. `B3` repeated/distributed mixing · E2–E3
5. `B4` distributed survival selection · E3–E4
6. `B5` free drift/local divergence · E4–E5
7. `B6` stable sublineage formation · E5

The current master intentionally avoids unsupported exact dates inside those broad epochs. The only hard temporal floor inherited from the project roadmap is that the Superevolution process begins at least 2000 years before T0.

## Causal guards

- Therapy precedes adaptation.
- Adaptation precedes directed hybridization.
- Directed hybridization cannot be asserted in E0.
- Repeated mixing follows hybridization.
- Distributed survival selection requires the E3 loss of comprehensive registration/control.
- Free drift cannot be asserted as an E2 phenomenon.
- Stable sublineages are later outcomes and are not retroactive primordial identities.

## Non-determinism boundary

Biology may affect physical capability, energetic cost, stress response, environmental need, reproduction interfaces and future sense/communication hooks. It does not assign morality, profession, dominance/submission, attraction, consent or personality.

`physiological response != deliberate decision`

Public stereotypes about a lineage remain Stage-3 public belief, not biological truth.

## Code

- `runtime/stage4a/biology_timeline.py`
- `tests/test_stage4a.py`
- `stage4a_stress.py`
- `scripts/stage4a_biology_audit.py`

## Downstream interface

4A provides only chronology/process authority. 4B will define the Geneline Matrix. Stage 5 owns detailed senses/communication; Stage 6 owns inheritance/speciation mechanics.
