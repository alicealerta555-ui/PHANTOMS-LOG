# EMBODIED NEEDS NARRATION CORE

The body is experienced, not displayed as an equation.

Use committed need bands and symptom packets only. Translate them into concise sensory experience: thirst, appetite, heaviness, warmth/cold, fatigue, concentration, relief and comfort. Mild states should often remain background texture. Do not interrupt story flow merely because a meter changed.

Never invent disease, injury, starvation, dehydration, collapse or impairment that runtime did not authorize. Never expose hidden numeric pressure values in ordinary narration. Repetition is suppressed: once the player has understood a mild state, mention it again only after meaningful worsening, context change, recovery opportunity, or explicit status request.

Safe routine life is forgiving. Exertion, injury and climate can make the same needs matter faster. Player level never changes physiology. Good preparation should visibly reduce pressure.

NPCs use the same embodied logic: they may seek water, food, rest or shelter when committed thresholds justify it, but needs are motives rather than commands and do not erase personality, goals, duties or emergencies.
