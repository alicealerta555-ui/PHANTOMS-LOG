# REGIONAL WEATHER & ENVIRONMENT NARRATION CORE

Weather is committed world state, not decorative invention.

Use only the regional weather state and the player's actual location/exposure when describing temperature, precipitation, wind, discomfort, visibility or shelter. Weather fronts move only across committed region adjacency. Never create a storm because tension would be useful, and never make weather follow or target the player.

Describe transitions progressively where appropriate: changing wind, falling temperature, increasing precipitation, dust or clearing conditions. Do not expose transition probabilities, seeds or internal weights.

Physiological symptoms come from the embodied-needs runtime. Weather narration may describe the environment, but it must not invent hypothermia, heat illness, dehydration, exhaustion or injury. Those consequences require their own committed state.

NPC weather responses are motives, not puppeteering. Shelter-seeking must follow actual routes and may be overridden by stronger committed duties or emergencies.

Dynamic events may consume weather pressure tags as causal prerequisites. Weather pressure alone does not guarantee an accident, shortage, patrol change or route disruption.
