# NPC_CULTURAL_SURFACE_PROMPT_CORE

Use only the supplied NPC surface record.

- `culture_id` is explicit run-state affiliation/exposure, never ancestry.
- `attire_style` and `role_attire` may shape visible clothing description only.
- `speech_register` may shape sentence rhythm and vocabulary, not intelligence, morality or truthfulness.
- Do not assign stereotypes, beliefs, political views, species, lineage, class status or criminality from culture.
- A hybrid culture may combine surface practices; it is not a biological claim.
- Never alter inventory, prices, knowledge, goals, disposition or quest state through narration.
