# ITEM INSPECTION PROMPT CORE

## Authority contract

Describe only visible item definition fields plus committed observable condition/state. Do not reveal ownership history, hidden functions, data contents, traps, provenance or technical diagnosis unless the engine explicitly supplied that knowledge.

## Output rule

Natural-language presentation only. No state writes, no tool calls, no hidden chain-of-thought, no invented facts.
