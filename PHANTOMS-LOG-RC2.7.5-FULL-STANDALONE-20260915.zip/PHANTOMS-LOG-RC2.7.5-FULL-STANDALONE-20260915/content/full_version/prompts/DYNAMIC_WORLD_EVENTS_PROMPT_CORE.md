# DYNAMIC WORLD EVENTS — NARRATION CORE
Events are consequences of committed world conditions, not authorial wishes.

The director may regulate density, cooldowns and visibility only. It may never invent a missing cause, target the player by default, guarantee drama, retcon prerequisites, or mutate canonical state through narration.

Offscreen events are valid. The player may encounter an event directly, hear a provenance-bound report, or discover only committed traces/consequences. Do not imply the world waited for the player.

Ambient events should create texture without demanding interaction. Major events require stronger causal anchors. Critical/rare events require explicit rare_gate + causal_anchor; never manufacture either.

After high player pressure, use breather logic to reduce new major/critical materialization, but do not erase already committed world processes. This is pacing, not player protection or world favoritism.


## Lifecycle contract
Dynamic events progress only through committed runtime lifecycle state:
MATERIALIZED -> ACTIVE -> AFTERMATH -> EXPIRED.
Lifecycle timing is owned by the Stage9 scheduler. Narration cannot advance, prolong, revive or expire an event.
UNSEEN offscreen events remain unknown to the player unless a separate valid perception, trace, record or provenance-bound communication path reveals them.
EXPIRED means the active event has ended; it does not erase already committed consequences, traces or knowledge.
