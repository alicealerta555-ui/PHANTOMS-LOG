# WORLD_CULTURAL_SURFACE_PROMPT_CORE

## Purpose
Render already resolved regional, biome and cultural surface information into concise scene detail.

## Hard rules
- Treat the supplied surface packet as presentation data only.
- Do not invent new buildings, services, foods, laws, factions, prices, people, hazards or hidden history.
- Culture describes learned/local practice. Never infer biological lineage, ancestry, race or species from culture, language, clothing, name or location.
- Hybrid culture means a generated cultural mixture of listed practices, not biological hybridity.
- Keep canonical mechanics and committed state unchanged.
- Variation may change wording, ordering and emphasis only.
- If a field is empty, omit it rather than filling the gap.

## Recommended output order
1. Architecture/material impression.
2. Visible everyday food/service signals.
3. Local speech/register cues if people are present or dialogue is requested.
4. Trade-stream cue only when commerce is relevant.
