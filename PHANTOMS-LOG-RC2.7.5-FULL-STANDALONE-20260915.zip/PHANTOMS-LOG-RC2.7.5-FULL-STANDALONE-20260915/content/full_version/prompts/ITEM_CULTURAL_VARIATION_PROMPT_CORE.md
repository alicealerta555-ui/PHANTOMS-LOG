# ITEM_CULTURAL_VARIATION_PROMPT_CORE

Purpose: describe an already resolved concrete item instance with culturally/localized surface variation without changing game truth.

## Inputs
- canonical item definition: id, kind, canonical display name
- concrete item instance and provenance
- resolved surface_variant packet
- distribution_context: origin region distance, biome/category match, culture/hybrid culture, rarity
- optional explicit lineage context only when present in committed state

## Hard rules
1. Canonical identity and mechanics are immutable. Never turn one item definition into another.
2. Use only the committed `surface_variant` for cultural/local styling. Never invent a culture, lineage, species, owner, maker, faction, age, material, function, bonus, defect or history.
3. Culture and lineage are separate. Never infer lineage/species from culture, name, region, profession or appearance.
4. Hybrid-culture styling may combine only the already resolved parent-cultural surface conventions. Do not invent ancestry or biological hybridity.
5. Distance/rarity explain plausibility, not certainty. A rare foreign object may exist locally if the engine already materialized it.
6. Biome mismatch may be mentioned only as environmental atypicality; it does not prove smuggling, migration, theft or trade.
7. Preserve ownership, condition, quest semantics, encryption, canonical facts and mechanical effects exactly.
8. Keep descriptions concise and observational. Distinguish visible surface detail from unknown provenance.

## Allowed variation
- wording and ordering
- visible finish, packaging convention, cut, stitching, labeling style or non-mechanical surface treatment already present in `surface_variant`
- brief note that an execution is locally typical, hybrid, foreign-looking or uncommon when the distribution packet supports it

## Forbidden variation
- new stats, bonuses, damage, protection or durability
- new ingredients or medical effects
- invented historical events or manufacturers
- invented cultural ownership claims
- inferred race/species/lineage
- hidden quest clues not already committed

Output describes; engine state decides.
