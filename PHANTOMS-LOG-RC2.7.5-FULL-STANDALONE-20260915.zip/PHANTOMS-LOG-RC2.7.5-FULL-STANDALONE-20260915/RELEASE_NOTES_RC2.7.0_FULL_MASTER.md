# PHANTOMS-LOG RC2.7.0 — FULL MASTER

## Major release change

RC2.7.0 promotes the Capability/Character Tree hardening work into the current project authority.

### Character architecture
- Canonical `PLAYABLE-CAPABILITY-2.0` schema.
- 10 stats, 30 skills, 26 base talents and use-earned expertises.
- Character tree is the foundation; class/path tree is derived from it.
- Old incompatible character schemas fail closed instead of being silently reinterpreted.

### Capability resolution
- INPUT / INTERPRET / SETUP / EXECUTE / CONTROL staging.
- SAFE / EDGE / EXTREME / HARD_LIMIT / INACCESSIBLE zones.
- Natural/current hard limits are checked before ordinary success resolution.
- Partial successes survive later-stage failure.
- Tools/methods can change task demands without secretly inflating base stats.
- Expertise increases reliable application but cannot override hard natural limits.

### Class/path integration
- 1,680 class/path abilities rooted in canonical stat/skill requirements.
- Selected-class/path visibility is fail closed.
- Class abilities remain bounded by NPC agency, security, knowledge and canonical authority.

### Gameplay integration
Shared capability resolution is bound into major active action families including combat execution, searching, crafting, repair, treatment, encrypted-data access, rebuilding, corpse investigation and class-ability use. Ordinary low-risk interactions are explicitly marked as routine-safe rather than being accidental bypasses.

### Resonance/supernatural layer
`STAT_RES` and resonance-related skills/talents support the setting's fictional supernatural layer. The layer is inspired by occult/esoteric motifs but is implemented as game fiction, not scientific fact.

### Image pipeline
Scene imagery now follows visible state → structured scene → AI-authored image prompt → generator. Hidden state is excluded and images cannot create canonical facts.

### Validation infrastructure
- Complete pytest discovery is sharded/process isolated.
- Capability character-tree audit.
- Action-capability policy audit.
- Stage-9 authority/integrity audits retained.
- Full-version master and reference audits retained.
- Release file index and SHA-256 manifest rebuilt from the frozen release tree.
