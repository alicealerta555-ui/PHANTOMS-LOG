# PHANTOMS-LOG RC2.7.0 — Open Work

These items are current design/development targets and are **not** claimed as implemented by RC2.7.0.

## Lifetime-cycle character start
- Generate a short family/life history during character start.
- Inheritance influences starting circumstances rather than handing out arbitrary start items.
- One parent may have died during a mission/accident without being an exceptional hero.
- The player and remaining family member inherit possessions, obligations and a small journal containing world clues.
- Debts and the need for work create an organic first motivation.
- Start in a small location outside a major city: village, farm, hamlet, small settlement or outpost with several everyday NPCs.
- Additional parental possessions/clues may remain in a dungeon, ruin, abandoned factory, laboratory, mine, tunnel complex, bunker, research station, power plant, transport wreck, abandoned farm, underground service complex, old clinic, military facility, transit hub, warehouse, cave system, cult site, submerged facility, quarantine zone or destroyed outpost.

## Generational inheritance
If a player character later has children, the same principle can propagate possessions, debts, journals, contacts, reputation, obligations and unresolved quest traces to the next generation.

## NPC mindset work
Research and formalize real-life-inspired mindset patterns: priorities, self-image, incentives, risk perception, social strategies, biases and decision habits. These become structured NPC-logic inputs rather than generic personality flavor.

## Continued capability work
- Broader free-language semantic mapping to canonical action/method primitives.
- Real playtest tuning of SAFE/EDGE/EXTREME boundaries.
- Continue expanding scenario matrices when new action families are introduced.
