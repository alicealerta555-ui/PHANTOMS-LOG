# Etappe 16 – Item of Interest & Equipment Expertise

NPCs können sichtbare ungewöhnliche Ausrüstung bemerken, Interesse zeigen, Fragen stellen, Schäden erkennen, Reparaturen anregen und bei passender Beziehung/Kontext Modifikationen diskutieren.

Modifikationen sind Kalibrierungen mit Vor- und Nachteilen, keine linearen Upgrade-Stufen. Körpernahe/implantierte Systeme prüfen zusätzlich biologische Grenzen.
