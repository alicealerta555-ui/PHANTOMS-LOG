# RC2.5.8 — Dynamic Events & Encounters

Selected design: Option 5 / Hybrid 1+2+3+4.

Implemented:
- ambient world events
- causal eligibility from location/world-pressure tags
- pacing director limited to budget, density and breather windows
- offscreen materialization
- player is never the default target
- rare events require explicit rare_gate AND causal_anchor
- deterministic run-stable weighted resolution
- no narration-side state mutation
- existing Stage9 scheduler and Stage10 encounter systems remain authoritative in their domains; no duplicate replacement system
- event runtime is additive and stores committed event records separately

Director rule:
The director may decide WHEN an already plausible event is allowed to materialize. It may not decide WHAT is true merely because drama would be useful.

Validation:
- focused RC2.5.8: 7 passed
- full suite: 1701 passed + 289 subtests passed
