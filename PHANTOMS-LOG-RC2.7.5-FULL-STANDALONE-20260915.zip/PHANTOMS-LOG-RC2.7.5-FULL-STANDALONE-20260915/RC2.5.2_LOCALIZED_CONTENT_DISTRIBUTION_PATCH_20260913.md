# RC2.5.2 Localized Content Distribution

Adds deterministic, run-stable content availability and presentation variation based on location graph distance, biome/category fit, explicit culture/hybrid-culture profiles, rarity tier and optional explicit lineage affinity. Culture and biological lineage remain separate dimensions. Distance never makes an item impossible by itself; it lowers probability to a configurable floor.

Search uses the resolved availability to scale candidate weight and chance. Spawned search items preserve a `distribution_context` provenance packet. Data-content presentation uses only engine-authorized culture variant indexes while canonical facts remain locked.
