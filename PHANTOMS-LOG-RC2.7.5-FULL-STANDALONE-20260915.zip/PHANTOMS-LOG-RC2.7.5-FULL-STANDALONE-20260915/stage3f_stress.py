from __future__ import annotations

from uuid import uuid4

from runtime.stage3a.integration import RuntimeDelta
from runtime.stage3a.kernel import Delta, Domain, Authority, Mode, Proposal, Verdict
from runtime.stage3b.pipeline import ActionRequest, ActionRule, Condition, Operator, OutcomeBranch, ValueSource
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage3d.epistemic import epistemic_stamp
from runtime.stage3f.verification import TenfoldVerificationGate, VerificationDimension


N = 1000


def meta(t: int):
    return epistemic_stamp(
        source_type="DIRECT_OBSERVATION", source_id="stress", origin_location="A", learned_at=t,
    )


def main() -> None:
    manager = RunSessionManager(master_seed=20260903)
    session = manager.create_run(player_uuid=str(uuid4()), run_uuid=str(uuid4()))
    gate: TenfoldVerificationGate = session.verification
    store = session.store
    store.runtime_state["time"] = 100
    store.actor_knowledge["NPC"] = {
        "old": {"value": True, "provenance": "stress", "source_event_id": "old", "epistemic": meta(50)}
    }

    checks = 0

    def global_check(idx: int, delta: Delta, dimension: VerificationDimension):
        nonlocal checks
        report = gate.verify_proposal(
            proposal=Proposal(Mode.COMMIT, Authority.COMMIT_KERNEL, (delta,), event_id=f"S:{dimension.value}:{idx}", cause="stress"),
            deltas=(delta,), store=store,
        )
        assert report.verdict == Verdict.REJECT, (dimension, report)
        assert any(f"V3F:{dimension.value}:" in reason for reason in report.reasons), report.reasons
        checks += 1

    # 1 State
    for i in range(N):
        d1 = Delta(Domain.RUNTIME_STATE, "x", i, Authority.RULE_KERNEL, "stress", source_event_id=f"x{i}")
        d2 = Delta(Domain.RUNTIME_STATE, "x", i + 1, Authority.RULE_KERNEL, "stress", source_event_id=f"x{i}")
        result = gate.verify_proposal(
            proposal=Proposal(Mode.COMMIT, Authority.COMMIT_KERNEL, (d1, d2), event_id=f"STATE:{i}", cause="stress"),
            deltas=(d1, d2), store=store,
        )
        assert result.verdict == Verdict.REJECT and any("V3F:STATE:" in r for r in result.reasons)
        checks += 1

    # 2 Resources
    for i in range(N):
        global_check(i, Delta(Domain.RUNTIME_STATE, "credits", -1 - i, Authority.RULE_KERNEL, "stress", source_event_id=f"R{i}"), VerificationDimension.INVENTORY_RESOURCES)

    # 3 Time
    for i in range(N):
        global_check(i, Delta(Domain.RUNTIME_STATE, "time", 99, Authority.RULE_KERNEL, "stress", source_event_id=f"T{i}"), VerificationDimension.TIME)

    # 4 Position
    for i in range(N):
        global_check(i, Delta(Domain.RUNTIME_STATE, "position", "", Authority.RULE_KERNEL, "stress", source_event_id=f"P{i}"), VerificationDimension.POSITION_SPACE)

    # 5 Rules/mechanics via action outcome mismatch
    bad_outcome = OutcomeBranch("bad", conditions=(Condition(ValueSource.RNG, "roll", Operator.GE, 10),))
    request_rules = ActionRequest("RULES", ActionRule("rules", default_outcome=OutcomeBranch("ok")))
    for i in range(N):
        decision = gate.verify(request=request_rules, outcome=bad_outcome, facts={}, rng={"roll": 1}, deltas=())
        assert decision.verdict == Verdict.REJECT and any("V3F:RULES_MECHANICS:" in r for r in decision.reasons)
        checks += 1

    # 6 Causality/preconditions via action precondition mismatch
    bad_rule = ActionRule(
        "causal",
        preconditions=(Condition(ValueSource.RNG, "roll", Operator.GE, 5),),
        default_outcome=OutcomeBranch("ok"),
    )
    request_causal = ActionRequest("CAUSAL", bad_rule)
    for i in range(N):
        decision = gate.verify(request=request_causal, outcome=bad_rule.default_outcome, facts={}, rng={"roll": 1}, deltas=())
        assert decision.verdict == Verdict.REJECT and any("V3F:CAUSALITY_PRECONDITIONS:" in r for r in decision.reasons)
        checks += 1

    # 7 Epistemics
    for i in range(N):
        global_check(i, Delta(
            Domain.ACTOR_KNOWLEDGE, f"future{i}", True, Authority.KNOWLEDGE_ROUTER, "stress",
            source_event_id=f"E{i}", actor_id="NPC", provenance="stress", epistemic=meta(101),
        ), VerificationDimension.NPC_KNOWLEDGE_EPISTEMICS)

    # 8 Memory/retcon
    for i in range(N):
        global_check(i, Delta(
            Domain.ACTOR_KNOWLEDGE, "old", False, Authority.KNOWLEDGE_ROUTER, "stress",
            source_event_id=f"M{i}", actor_id="NPC", provenance="stress", epistemic=meta(49),
        ), VerificationDimension.MEMORY_RETCON)

    # 9 Player agency
    for i in range(N):
        global_check(i, Delta(
            Domain.RUNTIME_STATE, f"player.choice.route{i}", "left", Authority.RULE_KERNEL, "stress", source_event_id=f"A{i}"
        ), VerificationDimension.PLAYER_AGENCY)

    # 10 Narration-vs-commit via hidden domain projection request
    narr_rule = ActionRule("narr", default_outcome=OutcomeBranch("ok"), narration_runtime_keys=("WORLD_TRUTH",))
    narr_request = ActionRequest("NARR", narr_rule)
    for i in range(N):
        decision = gate.verify(request=narr_request, outcome=narr_rule.default_outcome, facts={}, rng={}, deltas=())
        assert decision.verdict == Verdict.REJECT and any("V3F:NARRATION_VS_COMMIT:" in r for r in decision.reasons)
        checks += 1

    # 10,000 false-veto checks: extreme prose + unclassified negative temperature remain valid.
    safe_rule = ActionRule("safe", default_outcome=OutcomeBranch("ok"))
    for i in range(10_000):
        decision = gate.verify(
            request=ActionRequest(
                f"SAFE:{i}", safe_rule,
                player_text="-999 credits impossible death retcon WORLD_TRUTH teleportation — prose only",
            ),
            outcome=safe_rule.default_outcome,
            facts={}, rng={},
            deltas=(RuntimeDelta("RUNTIME_STATE", "temperature", -50 + (i % 100), "RULE_KERNEL", "weather"),),
        )
        assert decision.verdict == Verdict.PASS, decision.reasons
        checks += 1

    assert checks == 20_000, checks
    print(f"STAGE3F_STRESS={checks}/20000 PASS")


if __name__ == "__main__":
    main()
