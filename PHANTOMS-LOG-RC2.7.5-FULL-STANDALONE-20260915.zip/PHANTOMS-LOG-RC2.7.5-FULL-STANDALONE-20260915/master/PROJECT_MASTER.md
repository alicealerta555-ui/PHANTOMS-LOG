# PHANTOMS-LOG · FULL VERSION PROJECT MASTER

**Authority date:** 2026-09-15  
**Release:** RC2.7.5 FULL STANDALONE  
**Character schema:** `PLAYABLE-CAPABILITY-2.0`  
**Frozen runtime substrate:** Runtime-I9.33 / 9A001–9A032 CLOSED

This is the current semantic project master. Older stage and release reports are implementation history only when they conflict with this document, current source or passing tests.

## 1. Hard authority pipeline

All canonical mutable state changes use:

```text
Action/Event
  -> Guards
  -> Resolution
  -> EffectProposal
  -> StateAuthority
  -> CommitKernel
  -> Canonical State
```

The language model may interpret/present/propose bounded behavior. It does not own canonical world state and may not declare hidden facts or mutate state outside the authority pipeline.

## 2. Character and class law

There is one active character foundation:

```text
Stats -> Skills -> Talents -> Expertises -> Class/Path specialization
```

- 10 stats define natural capability foundations.
- 30 skills describe learned application of those foundations.
- 26 base talents specialize existing skills.
- Expertises arise from validated repeated use and improve reliability/efficiency rather than silently increasing natural maxima.
- BREAKER, GHOST, OPERATOR and RESONANT specialize this same tree; no class may create a parallel physics/capability model.
- `STAT_RES` is the natural resonance coupling stat used by the fictional supernatural layer.

## 3. Capability resolution law

Relevant actions may be decomposed into INPUT, INTERPRET, SETUP, EXECUTE and CONTROL requirements.

Performance zones:

- SAFE — reliable application.
- EDGE — genuine uncertainty.
- EXTREME — possible but strongly risky; warn first.
- HARD_LIMIT — a necessary current/natural requirement is not met; no success roll may override it.
- INACCESSIBLE — the required technique/skill/talent is unavailable.

Earlier successful stages remain valid when a later stage fails. Narration should explain the actual failure point when the character can reasonably know it.

## 4. Identity, isolation and epistemics

- Explicit player/run/actor identity at authoritative boundaries.
- No cross-run mutable state.
- Actor definition, actor instance, actor runtime state and actor knowledge are distinct.
- World truth, perception, knowledge and belief are distinct.
- NPCs do not receive hidden world truth merely because a language model can infer it.

## 5. NPC law

NPCs are actors, not assistants. Self-protection, role, law/security, economic risk, relationships, trust, fear, grievance, reputation and faction interests constrain cooperation. Social influence may change decisions only through rule-valid mechanisms; it cannot erase hard authority/security boundaries.

## 6. World/content baseline

Active full-version roots include Stage-3/4 foundations, cumulative Stage-5 perception, Stage-6 biology/inheritance infrastructure, Stage-7 needs, Stage-8 world/travel/information infrastructure, closed Runtime-I9 authority, Stage-10 creatures/dungeons/ecology, the current full-version world/content tree and later content-stage modules present in the release.

## 7. Image/presentation law

Images are presentation only:

```text
visible canonical state -> visible scene context -> AI-authored image prompt -> image generator
```

No hidden/unperceived fact may enter the prompt. Generated images do not become canonical evidence.

## 8. Active implementation roots

- `runtime/`
- `phantoms_stage5/`
- `content/full_version/`
- `playable_full_version/`
- `tests/`, `tests_stage5/`
- `scripts/`, `reports/`

## 9. Standalone closure

The release contains the active runtime, content, tests, audits and the current design-context handoff. Future expansion remains possible, but no advertised RC2.7.5 feature depends on an older chat or archive.

## 10. Release gate

A build is not release-valid merely because it launches. The full regression/closure/audit pipeline must pass after the final change set and the file index/checksums must match the packaged tree.
