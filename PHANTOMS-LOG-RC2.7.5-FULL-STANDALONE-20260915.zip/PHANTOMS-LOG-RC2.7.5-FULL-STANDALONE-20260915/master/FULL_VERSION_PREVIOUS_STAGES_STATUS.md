# PH4NT0M5-L0G · FULL-VERSION PROMOTION OF PREVIOUS STAGES

**Authority date:** 2026-09-12  
**Status:** ACTIVE FULL-VERSION BASELINE

The active Stage 3–10 line is a full-version path. Demo-specific starts, actors, locations, fallback profiles and compatibility shells are history-only.

## Stage status

- **Stage 3:** CLOSED / VERIFIED runtime foundation.
- **Stage 4:** CLOSED / VERIFIED biological/actor foundation.
- **Stage 5:** cumulative I3 perception/epistemics active; 216/216 regression baseline.
- **CONTENT-S6:** reproduction/inheritance/drift fully implemented and tested, including persistence and speciation gates.
- **CONTENT-S7:** complete NEEDS layer implemented and tested on the frozen Actor Runtime architecture; NEEDS enter actor context but never become authority.
- **CONTENT-S8:** complete region/biome/travel/infrastructure/population layer implemented and tested on the frozen Gameplay Authority architecture.
- **Runtime-I9 / 9A001–9A032:** CLOSED / FROZEN technical substrate.
- **CONTENT-S10:** bestiary, encounter logic, persistent dungeons, ecology and causal recolonization implemented/tested/pass.

## Active playable law

Only `playable_full_version/` is active. Fresh runs require explicit `start_class`; no implicit demo start exists.

## History law

Retired demo material remains under `history/` for provenance/regression only and cannot override active references.
