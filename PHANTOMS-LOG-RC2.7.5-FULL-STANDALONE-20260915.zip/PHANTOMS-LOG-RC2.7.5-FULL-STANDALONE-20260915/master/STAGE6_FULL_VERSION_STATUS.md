# PH4NT0M5-L0G · CONTENT-S6 FULL-VERSION STATUS

**Authority date:** 2026-09-12  
**Status:** IMPLEMENTED / TESTED / PASS

Stage 6 is the historical full-version biology layer for reproduction, inheritance and drift. It is not a relationship, consent or personality engine.

## Implemented historical scope

- 6.1 Germline and somatic traits are explicit; somatic-only changes never auto-inherit.
- 6.2 Compatibility is three-way: `ALLOWED`, `BLOCKED`, `UNKNOWN`; unknown fails closed for reproduction resolution.
- 6.3 Inheritance is deterministic/seeded by run + event and preserves latent germline alternatives.
- 6.4 Drift is generation-based, cause/pressure driven and bounded per generation.
- 6.5 Speciation requires multiple independent thresholds; no single drift event creates a species.
- Persistent inheritance/drift records use `EffectProposal -> StateAuthority -> CommitKernel` and survive save/load.
- Stage-10 creature lineages must be covered by the Stage-6 lineage catalog.

## Boundary law

`Biology != Personality != Relationship != Consent != Profession`

## Active files

- `runtime/stage6/biology.py`
- `content/full_version/stage6_biology.json`
- `tests/test_stage6_full_version.py`
- `scripts/stage6_full_version_audit.py`
