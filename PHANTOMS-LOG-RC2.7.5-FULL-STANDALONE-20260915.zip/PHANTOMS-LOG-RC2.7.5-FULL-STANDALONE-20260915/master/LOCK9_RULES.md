# PH4NT0M5-L0G · LOCK9 · CURRENT AUTHORITY

**Current authority date:** 2026-09-03  
**Closed game-base reference:** `PhantomsLog 0.2.2.0`  
**Status:** ACTIVE · canonical project rule set

These nine rules are the active post-`0.2.2.0` rule block. Earlier rejected candidate additions are not active requirements unless explicitly reintroduced by a later current master decision.

1. **TRUTH_KNOWLEDGE_SEPARATION** — `WORLD_TRUTH`, `ACTOR_KNOWLEDGE` and `PLAYER_KNOWLEDGE` are distinct. Actors only know what can have reached them causally.
2. **EXPLORATORY_NO_REALITY_WRITE** — questions, guesses and exploratory formulations never write their proposed content directly into reality.
3. **UNKNOWN_GROUND_TRUTH_RESOLUTION** — a genuinely unresolved world variable may be resolved seedably and plausibility-weighted from its already allowed possibility space, then becomes stable Ground Truth.
4. **ANTI_SUGGESTION** — wording or expectations in the player's query do not shift Ground-Truth weighting toward the suggestion.
5. **CIRCUMSTANCE_ANTI_PATTERN** — circumstances may break exploitable recurring engine/narration patterns.
6. **NO_ARBITRARY_EXPECTATION_BREAK** — surprise must remain plausible, causal and compatible with committed state/story.
7. **OBSERVATION_BASED_DANGER** — danger/fear/threat assessment requires observation, credible information or experience; no magical meta-knowledge.
8. **ACTOR_INTELLIGENCE_LOGIC** — multi-valued decision logic belongs only to autonomous-actor intelligent processing, never to `WORLD_TRUTH` or commit authority. The current trained core is deliberately restricted to `YES / NO / MAYBE`. `BOTH / NEITHER` are reserved and disabled until a concrete query relation is formally defined and tested; undefined relations must not improvise them.
9. **TENFOLD_SELF_VERIFICATION** — before final output verify State, Inventory/Resources, Time, Position/Space, Rules/Mechanics, Causality/Preconditions, NPC Knowledge/Epistemics, Memory/Retcon, Player Agency and Narration-vs-Commit. A real hard contradiction has veto power.

## Permanent companion invariants

- Randomize the unknown; simulate the known.
- Causes before consequences.
- Draft is not state. Narration is not commit.
- Single active authority per system family.
- Meta/service/UX/safety/session mechanisms are not diegetic world truth.
- Persistent named actors and persistent places keep causal biographies rather than reset for convenience.
- No concrete player, character, savegame or run data in static Core, training datasets or benchmark datasets. Tests use anonymous synthetic temporary fixtures only.
- Each player/run is isolated by its own identifiers; no implicit fallback to another player or run.
- Player agency and NPC agency remain separate. Needs, money, status, biology, attraction, fear and social pressure are influences/constraints, not automatic commands.
