# PH4NT0M5-L0G · CONTENT-S10 · BESTIARY / DUNGEONS / ECOLOGY

**Authority date:** 2026-09-12

## 10.1 Creature profiles

Static immutable creature definitions bind Stage-4 branch/cognition classifications to Stage-5-compatible sense modalities, needs, habitat tags and bounded threat/behavior traits. FERAL is never an intelligence/morality shortcut.

## 10.2 Encounter behavior

Encounter decisions consume only actor-visible `ActorDecisionContext`. An unperceived target cannot become an automatic hunt/attack target. No hidden World Truth or direct state writes.

## 10.3 Persistent dungeons

Dungeon occupancy, population identity and traces are mutable run state under the canonical store. Leaving a location does not reset it.

## 10.4 Ecology

Resources and populations are causal run state. Negative resources/populations are rejected. Changes use semantic `ECOLOGY_*` effects through StateAuthority and CommitKernel.

## 10.5 Causal recolonization

Recolonization requires:

- current dungeon occupancy = VACANT;
- sufficient elapsed canonical world time;
- explicit habitat/resource attractors;
- a compatible creature profile;
- deterministic scheduling.

No blind respawn. Due recolonization events are Scheduler events that re-enter Authority and commit semantic dungeon/ecology effects exactly once.

## 10.6 Acceptance

Required vertical slice:

`visit -> persistent change -> leave -> time -> causal recolonization -> save/load -> process due event -> return -> consequences preserved`

Stage 10 may be promoted to PASS only with targeted tests, complete runtime regression, Stage-5 regression, full-version playable selftest, single-writer audit, full-version transition audit and Stage-10 content audit all PASS.
