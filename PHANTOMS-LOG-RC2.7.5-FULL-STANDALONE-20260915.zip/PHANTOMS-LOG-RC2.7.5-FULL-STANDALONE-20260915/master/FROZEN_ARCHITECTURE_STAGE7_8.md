# PH4NT0M5-L0G · STAGE 7–8 ARCHITECTURE + FULL-VERSION IMPLEMENTATION

**Authority date:** 2026-09-12  
**Stage 7 technical architecture:** FROZEN / REALIZED by Runtime-I9  
**Stage 7 historical content layer:** IMPLEMENTED / TESTED / PASS  
**Stage 8 technical architecture:** FROZEN / REALIZED by Runtime-I9  
**Stage 8 historical content layer:** IMPLEMENTED / TESTED / PASS

## Non-negotiable identity/state boundaries

- Mutable player/run data never lives in static Core or training data.
- Explicit `player_uuid`, `run_uuid`, `actor_instance_id` are mandatory.
- No current/last/default identity fallback and no cross-run mutable state.
- `ActorDefinition != ActorInstance != ActorRuntimeState != ActorKnowledge`.
- `Static World Definition != Mutable Run State`.
- `Perception != Knowledge != Belief != World Truth`.

## Stage 7 — Actor Runtime + NEEDS

Qwen is actor-local decision logic only. It receives bounded actor-visible context. Stage-7 NEEDS are now an additional actor-visible input but remain non-authoritative motivation pressures.

- one normal action per Actor/ActionWindow;
- explicit controller authority;
- actor/run isolated NEEDS;
- competing motives;
- time/event causal updates;
- multi-turn NPC continuity;
- no NEED may force action or imply consent.

## Stage 8 — Gameplay Authority + regional world systems

Canonical mutable state changes only through:

```text
Action/Event
  -> Guards
  -> Resolution
  -> EffectProposal
  -> StateAuthority
  -> CommitKernel
  -> State
```

The active Stage-8 layer now adds region/biome definitions, travel/time, infrastructure-limited information and causal bounded migration without creating another engine or writer.

## Frozen Stage-8 gates

`PLAYER_ISOLATION`, `RUN_ISOLATION`, `ACTOR_ISOLATION`, `KNOWLEDGE_ISOLATION`, `NO_HIDDEN_STATE_LEAK`, `NO_MODEL_STATE_WRITE`, `NO_DIRECT_SYSTEM_STATE_WRITE`, `ONE_ACTION_GATE`, `RESOURCE_DOUBLE_SPEND`, `ITEM_DOUBLE_SPEND`, `AMMO_DOUBLE_SPEND`, `COMMUNICATION_NO_TELEPATHY`, `RUMOUR_NO_WORLDTRUTH`, `FACTION_NO_AUTO_ATTACK`, `SAVE_LOAD_EQUIVALENCE`, `SCHEDULER_STATE_EQUIVALENCE`, `RNG_CONTINUITY`, `REHYDRATION_SIDE_EFFECT_FREE`, `NO_IMPLICIT_RUNTIME_FALLBACK`.

These gates are already executed PASS in frozen Runtime-I9.33 and remain binding on CONTENT-S7/S8.

See `master/STAGE7_FULL_VERSION_STATUS.md` and `master/STAGE8_FULL_VERSION_STATUS.md`.
