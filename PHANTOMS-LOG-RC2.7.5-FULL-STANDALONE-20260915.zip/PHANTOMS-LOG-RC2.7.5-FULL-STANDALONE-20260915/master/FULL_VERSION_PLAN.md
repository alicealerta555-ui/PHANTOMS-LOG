# PH4NT0M5-L0G · FULL VERSION TRANSITION

**Authority date:** 2026-09-12

## Goal

Promote the project from the former DEMO-0 vertical-slice line to a full-version development baseline without rewriting or weakening the closed Runtime-I9.33 substrate.

## Binding transition rules

1. No active DEMO-0 start location, actor, turn state, rules or compatibility shell.
2. Former demo artifacts are history/test provenance only.
3. A fresh run requires an explicit full-version character start class.
4. Static world definitions remain separate from mutable run state.
5. All gameplay mutation remains on the Stage-9 Authority/Commit path.
6. Full-version content must survive existing save/load isolation.
7. Runtime-I9 closure evidence remains frozen and auditable.

## Promoted full-version baseline

- 100+ enterable locations with deterministic topology and gameplay hooks.
- 5 factions.
- 45+ persistent NPC definitions.
- 80+ item definitions.
- 10 conflict chains.
- 15+ craft/repair/field operations with valid item references.
- 5 explicit character start classs.
- 15 underground/dungeon definitions.
- 12 creature profiles.

## Active playable

`playable_full_version/`

Fresh runs fail closed without explicit start-class selection. Existing saved runs reuse the recorded start class and explicit player/run identity.
