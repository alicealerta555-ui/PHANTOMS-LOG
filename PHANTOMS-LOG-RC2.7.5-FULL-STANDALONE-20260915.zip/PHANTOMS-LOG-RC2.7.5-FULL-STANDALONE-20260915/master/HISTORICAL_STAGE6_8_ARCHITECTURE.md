# PH4NT0M5-L0G · Historical Stage 6–8 Architecture Integration

**Date:** 2026-09-12  
**Mode:** compatibility integration; no duplicate canonical writer

This revision preserves the earlier development-line meanings alongside the newer content-stage numbering:

- historical **Stage 6 = World Runtime / 100-location world basis**;
- historical **Stage 7 = Actor / NPC Runtime**;
- historical **Stage 8 = Gameplay Systems**.

The older meanings remain architectural contracts, not competing runtime namespaces. Their functions are mapped to the current active implementation so that old design work can still be referenced without reintroducing obsolete writers or fallback state.

## Historical Stage 6 · World Runtime

Integrated coverage: world/location catalog, regions/biomes/conditions, explicit graph/routes, travel time, infrastructure, causal information channels, populations and bounded migration, mutable run-scoped world state, world time/off-screen scheduling, authorized world mutation, save/load rehydration and full-world location coverage.

## Historical Stage 7 · Actor Runtime

Integrated architecture: ActorDefinition/identity separation, ActorInstance/run registry, runtime fields, knowledge, belief, perception, needs, decision-context projection, decision backend/validation, StateAuthority, continuity/rehydration, single-writer and idempotency boundaries.

**Invariant:** Actor definition ≠ actor instance ≠ mutable runtime state ≠ actor knowledge/belief.

## Historical Stage 8 · Gameplay Systems

Integrated architecture: freeform action ingress, action window, semantic resolution, typed effect proposals, effect adaptation, validation/authority, atomic turn transaction, world time, scheduled events/re-entry, perception→knowledge path, narration after commit, playable runtime, save/load continuity and revision guards.

## Authority rule

No compatibility mapping may write canonical state directly. All mutation stays inside the active StateAuthority / CommitKernel path. Static world definition remains separate from mutable run state; no fallback to old/current/last runs is introduced.

Machine-readable map: `content/full_version/historical_stage6_8_map.json`.
