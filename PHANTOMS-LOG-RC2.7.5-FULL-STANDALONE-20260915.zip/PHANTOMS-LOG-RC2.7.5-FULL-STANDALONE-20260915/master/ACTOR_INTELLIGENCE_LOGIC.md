# PH4NT0M5-L0G · AUTONOMOUS ACTOR INTELLIGENCE LOGIC · CURRENT CONTRACT

**Authority date:** 2026-09-03  
**Status:** ACTIVE · training-gate input

## 1. Scope

The actor intelligence core is invoked only where **intelligent processing** matters:

- interpretation of already-available perception/sensor observations;
- evidence assessment from actor-local knowledge and provenance;
- uncertainty handling;
- assessment of handling/action options before an actor chooses among them;
- actor-local planning/choice formation.

It does **not** own raw sensing, `WORLD_TRUTH`, physics, inventory, time, position, RNG, action outcome, state delta, verification or commit. Those remain engine-owned.

## 2. Current enabled decision logic

For the current post-Stage-4 model training, the actor logic is deliberately restricted to:

`YES / NO / MAYBE`

- `YES` — the actor's available evidence is sufficient for the queried actor-level conclusion.
- `NO` — the actor's available evidence is sufficient against the queried actor-level conclusion.
- `MAYBE` — the actor does not have enough reliable actor-local evidence for `YES` or `NO`, or an interpretive assessment remains genuinely uncertain.

This is an **epistemic/decision signal**, not objective world truth.

## 3. Actor families

The current three-state core may be used for autonomous organic, feral, semi-sapient and synthetic actors when they perform intelligent interpretation or handling/planning.

Androids, AIs, bots and drones stay on this compact three-state core unless a later explicit contract grants a richer logic. Very simple deterministic devices do not require an LLM actor core at all.

## 4. BOTH / NEITHER are reserved and disabled

`BOTH` and `NEITHER` are **not part of the current training target, validation set or blind benchmarks**.

They may only be introduced later for a query family whose logical relation has first been formally specified, including which combinations are admissible and how scope/time/aspect are normalized. Until such a contract and tests exist, the engine/model must not improvise either state.

Undefined relation => do not use `BOTH` or `NEITHER`.

## 5. Causal boundary

`WORLD_TRUTH -> sensing/observation mechanics -> actor-local evidence -> actor intelligence assessment -> actor choice proposal -> engine resolution/verification/commit`

The intelligence core never runs the arrow backward. A belief, guess, fear, interpretation or chosen action cannot create the world fact that would justify it.

## 6. Examples

- Door sensor and direct view both confirm the door is open -> actor assessment `YES`.
- Direct observation confirms the door is closed -> `NO`.
- Actor has no current observation or credible report -> `MAYBE`.
- Feral actor sees smoke, fresh blood and hears nearby gunfire -> threat assessment may be `YES` because actor-local evidence exists.
- Hidden danger exists only in `WORLD_TRUTH`, but the actor has no observation/source -> the actor may not meta-know it; assessment stays `MAYBE` rather than importing truth.

## 7. Training rule

The post-Stage-4 training package must fail selftest if `BOTH` or `NEITHER` appear as expected decision targets in SFT, validation, checkpoint-selection, blind or multi-turn benchmark material.
