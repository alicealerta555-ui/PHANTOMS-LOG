# PH4NT0M5-L0G · STAGE 9 PLAYABLE RUNTIME INTEGRATION MASTER CONTRACT

**Authority date:** 2026-09-11  
**Status:** Architecture frozen through 9.33. Runtime implementation patches 9A001–9A032 are IMPLEMENTED / TESTED / PASS in the final I9.33 master. The ordered 34-step closure validator is PASS; Stage 9 is CLOSED.

Stage 9 joins the frozen Stage-7/8 components into one actually playable runtime path without silently redefining Stage 7 or 8.

## Canonical playable path

```text
Player Input
  -> Action Proposal
  -> Validation / Guards
  -> Resolution
  -> EffectProposal[]
  -> StateAuthority
  -> CommitKernel
  -> Canonical State
  -> World-Time Commit
  -> Scheduler / Due Events
  -> Event Validation + Resolution
  -> EffectProposal[]
  -> StateAuthority
  -> CommitKernel
  -> Perception
  -> Knowledge
  -> Belief
  -> Narrative Projection
  -> TurnResult
  -> Next ActionWindow
```

No layer may bypass StateAuthority/CommitKernel for mutable state.

## 9.1 — Playable Runtime Integration Root Contract

Every turn carries explicit `player_uuid`, `run_uuid`, `actor_instance_id`, `turn_id`, `action_window_id`. Missing identity fails closed. Narrative is not authority. Qwen is not authority. Events are not authority. The root orchestrates one canonical pipeline.

## 9.2 — Lifecycle & Turn Transaction

Canonical lifecycle:

```text
CREATED -> REHYDRATING -> READY -> TURN_OPEN -> TURN_PROCESSING
-> TURN_COMMITTING -> POST_COMMIT -> TURN_COMPLETE -> READY
```

A `TurnTransaction` is turn-local and never a second authoritative world copy. It records pre-state revision/RNG/time, proposals, decisions, commit chain and output. Pre-commit work is tentative. Only CommitKernel crosses tentative -> canonical. Rehydration is side-effect-free. Narrative failure never rolls back an already committed turn. Crash replay requires idempotent commit detection.

## 9.3 — Player Input -> ActionProposal

Raw input is preserved. Normalization may change formatting but not meaning. Parsing answers "what is being attempted?" rather than "is it allowed?". Target resolution is actor-visible only. Unknown/hallucinated runtime references are rejected rather than created. Multi-action input is detected and remains subject to ONE_ACTION_GATE. Input processing itself advances neither time nor events nor knowledge.

## 9.4 — Validation & Guards

Validation is deterministic/read-only and asks whether an attempt is admissible. Guard order covers identity, run/actor isolation, ActionWindow, schema, targets, visibility/knowledge, capability, resources, permissions/conflicts and preconditions. Validation consumes no resource and normally no RNG. `VALIDATION_ACCEPTED != ACTION_SUCCESS`.

## 9.5 — Resolution -> EffectProposal

Only validated actions may resolve. Resolution computes outcome with deterministic rules or the central gameplay RNG and emits semantic `EffectProposal`s. No generic raw state patches. Combat, inventory, quest, devices, time and scheduler requests all become typed proposals. RNG use is recorded and replay-safe. Resolution outcome is not yet canonical.

## 9.6 — StateAuthority -> CommitKernel

StateAuthority is read-only and is the last rule gate. It validates effect identity/domain, current revision, ownership, resource/precondition and atomicity, then emits a controlled `CommitPlan`. CommitKernel is the only mutable state writer. It checks schema/idempotency/revision, applies registered semantic operations atomically, verifies invariants, advances revision and records commit provenance. Authority may approve but not write; CommitKernel may write but not invent gameplay decisions.

## 9.7 — World Time & Scheduler

One canonical `world_time` exists per run. Real wall-clock time/model latency/load duration never advances it. Time changes are committed effects. Scheduler is read-only dispatch logic that selects due events deterministically. Events themselves go through validation -> resolution -> effect proposals -> authority -> commit. Ordering is stable, events are idempotent, cascades are bounded and scheduler is re-evaluated after each event commit. Load never advances time.

## 9.8 — Perception -> Knowledge -> Belief

World Truth, Perception, Knowledge and Belief are separate layers. Perception is observer-specific and channel-specific. It is calculated only from committed state. Perception never directly writes knowledge; knowledge/belief updates use their own proposal/authority/commit path. Communication needs a channel; rumours never become World Truth. Actor context and NarrativeView are built only from actor-visible information. Rehydration creates no perception/knowledge/belief side effects.

## 9.9 — Actor Decision / Qwen Runtime Boundary

Qwen receives only compact actor-visible `ActorDecisionContext`. Model output is untrusted and schema/reference/context-fingerprint validated. Qwen may choose an attempt but cannot permit it, make it succeed or write state. `ActorDecisionToken.COMMIT` is an actor-choice token and has no relation to Runtime `CommitKernel`. Stale outputs are rejected. Model retries are bounded; safe fallback is deterministic HOLD/NO_ACTION. No reuse of the last action. Runtime must remain testable with Qwen disabled through a deterministic stub backend.

## 9.10 — Narrative & TurnResult

Narrative is downstream of canonical gameplay. A deterministic `NarrativeProjection` first decides what may be said. A model may style those facts but may not add facts. Hidden committed effects remain hidden if the actor cannot know them. Unsupported narrative claims are rejected/fallback-rendered and never become state. `TurnResult` is a player-facing projection, not a state container.

## 9.11 — Persistence / Rehydration

Save contains canonical mutable run state, explicit identity, revision, world time, RNG, scheduler/event lifecycle, actor state, knowledge/beliefs and required idempotency metadata. Static definitions remain separate. Normal save boundary is `TURN_COMPLETE`; half-transactions are not serialized as canonical progress. Load validates schema/identity/definition compatibility, restores state/scheduler/RNG/idempotency, rebuilds technical handles and only then becomes READY. Constructors and rehydration must trigger no gameplay.

## 9.12 — Integrity Harness

No gate is PASS merely because it is architecturally named. The harness traces input -> action -> resolution -> effects -> authority -> commits -> events -> final state, asserts mutation provenance and hard isolation/duplicate/replay/persistence gates, and supports deterministic failure injection. Golden paths include basic interaction, combat and persistence. `ARCHITECTURALLY DEFINED != IMPLEMENTED != TESTED != PASSED`.

## 9.13 — Package / Module Boundaries

Target structure separates runtime orchestration, input, validation, resolution, authority, commit, world/scheduler, epistemics, actor logic, narrative, persistence, state and integrity. Gameplay systems are Effect Producers, not State Writers. No runtime singleton or mutable gameplay globals. Dependencies are explicit/injected. Qwen and narrative are side adapters with no state handles.

## 9.14 — First Vertical Slice

Minimal slice: one player/run/actor, two rooms, one unlocked closed door, one flashlight. Supported initial actions: LOOK, TAKE, OPEN, MOVE (optional HOLD). Qwen disabled/stubbed; narrative initially template-based. Despite tiny content, the slice must use the complete architecture, including time/scheduler path, perception/knowledge and save/load. Negative tests include duplicate TAKE, closed-door MOVE, nonexistent item, wrong run and direct-write detection.

## 9.15 — Implementation Order

Build order:

```text
Identity + State
-> Lifecycle
-> Input/Proposal
-> Validation
-> Resolution/Effects
-> StateAuthority
-> CommitKernel
-> World Time
-> Scheduler
-> Perception
-> Knowledge
-> Deterministic Narrative
-> Persistence
-> Integrity Harness
-> Negative tests
-> first event
-> RNG
-> Actor Stub
-> Qwen Adapter
-> Minimal Combat
```

Deterministic core first, model integration second, complex gameplay third.

## 9.16 — Existing Codebase Reconciliation

The first source audit is read-only. Relevant components are classified `KEEP`, `KEEP_AND_WRAP`, `PATCH`, `REPLACE`, or `QUARANTINE`. Audit targets direct mutable writes, false/current/last state loads, identity fallback, cross-run globals, Definition/Instance mixing, action shortcuts, scheduler/time writers, gameplay RNG, Qwen hidden-state/state-write paths, epistemic mixing, narrative-back-to-state paths, persistence side effects and dependency inversions.

## 9.17 — Compatibility Matrix / Legacy Containment

Legacy behavior must adapt to frozen architecture, never the reverse. No shadow state. Unsafe legacy modules are contained behind adapters or quarantined. Patch priority is P0 State Integrity/Isolation, P1 Authority/Epistemic security, P2 runtime correctness/persistence, P3 architecture maintenance, P4 cleanup. No P0 issue may be knowingly carried into the Stage-9 vertical slice.

## Stage-9 hard status rule

Broad Stage-9 gates remain **DEFINED / NOT RUN** unless explicitly promoted by real patches. 9A001 identity validation, 9A002 authoritative entry/fallback-rejection, 9A003 run-owned ActorInstance ownership, 9A004 active-tree single-writer enforcement, 9A005 semantic EffectProposal validation, 9A006 read-only StateAuthority validation, 9A007 commit-boundary state-revision hardening, and 9A008 persistent commit/effect idempotency, 9A009 PlayableRuntime orchestration, 9A010 explicit immutable RuntimeContext, 9A011 turn-local non-authoritative TurnTransaction 9A012 non-authoritative ActionProposal adaptation and 9A013 one-normal-action ActionWindow enforcement are real PASS evidence. I9.4a adds binding emergent contracts for controller authority, actor-epistemic identity, migration/readiness and active-master consistency. The compatibility playable layer now routes authoritative actions through the Stage-9 PlayableRuntime and its lifecycle root, but it is still not a complete Stage-9 runtime because explicit Validation/Resolution split, post-commit systems and TurnResult remain pending. ActionWindow save/load/recovery semantics remain deferred to the persistence/recovery waves.


## I9.4a emergent cross-stage machine contracts

Binding addendum: `STAGE9_I9_4A_EMERGENT_MACHINE_CONTRACTS.md`. These contracts supplement the frozen architecture and remain status-separated from implementation/test evidence.

## I9.33 closure implementation update

Patches 9A022–9A032 close side-effect-free rehydration, save identity/continuity, ActorLogicBackend/model privilege/decision validation, narrative projection, deterministic rendering, TurnResult, mutation provenance, basic/NPC/persistence/combat/crash-retry golden paths and the read-only integrity harness. The I9.4a controller/epistemic/rehydration contracts are closed in the implemented Stage-9 paths, including explicit model-controller actor binding and a separate canonical actor-belief route. Final closure remains conditional on the ordered final master validator PASS.
