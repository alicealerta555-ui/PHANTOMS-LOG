# PH4NT0M5-L0G · STAGE 9 I9.4a EMERGENT MACHINE CONTRACT ADDENDUM

**Authority date:** 2026-09-11  
**Status:** CONTRACTS INTEGRATED / MIXED IMPLEMENTATION STATUS  
**Predecessor:** I9.4 / 9A003 PASS

This addendum records cross-stage machine contracts that became visible only after the Stage-3C/Stage-5 runtime and Stage-9 9A001-9A003 identity/actor-registry work were integrated into one active master.

## Binding precedence

These contracts supplement the frozen Stage-9 architecture. They do not revoke 9A001-9A003 PASS status. Where an older document is weaker, this addendum governs the active master.

## MC-01 · RUN_MEMBERSHIP != CONTROL_AUTHORITY

**Status:** IMPLEMENTED / TESTED / PASS in I9.33 closure hardening

An `actor_instance_id` being registered in a `run_uuid` proves membership only. It does not prove that the current input controller may command that actor.

Required future boundary:

```text
actor registered in run
!=
player may control actor
!=
NPC stub may control actor
!=
Qwen actor backend may control actor
```

A separate controller/authority binding must be validated before general Player/NPC action integration.

## MC-02 · ACTOR_EPISTEMIC_IDENTITY_BINDING

**Status:** IMPLEMENTED / TESTED / PASS across Perception, Knowledge and separate Belief paths

Actor-scoped Perception, Knowledge and Belief writes must target an `actor_instance_id` registered in the exact `run_uuid`. Free actor identifiers are not sufficient for Stage-9 canonical epistemics.

Required key:

```text
(run_uuid, actor_instance_id)
```

No Knowledge/Belief record may be committed for an unregistered actor in the Stage-9 active path.

## MC-03 · PLAYER_ACTOR_KNOWLEDGE_NAMESPACE

**Status:** IMPLEMENTED / TESTED / PASS

Diegetic knowledge of the player character belongs to actor knowledge keyed by `actor_instance_id`. A player/account-level knowledge store must not silently become a second canonical store for the same in-world facts.

## MC-04 · REHYDRATION != MIGRATION

**Status:** IMPLEMENTED / TESTED / PASS in 9A022–9A023

Normal load/rehydration must be side-effect free. If an older save lacks structures required by the current runtime, any upgrade must happen through an explicit, versioned migration step before the runtime reaches `READY`.

```text
LOAD / REHYDRATE -> no gameplay mutation
LEGACY MIGRATION -> explicit versioned transformation -> validation -> READY
```

## MC-05 · SAVE_SCHEMA_VALID != STAGE9_READY

**Status:** IMPLEMENTED / TESTED / PASS in 9A021–9A023

A save that passes an older schema may still lack capabilities required by the current Stage-9 runtime. Runtime readiness therefore requires both schema compatibility and capability/runtime-state compatibility.

**I9.22 status:** IMPLEMENTED / TESTED / PASS for canonical Stage-9 snapshot capture. Legacy Stage-3C schema validity remains insufficient; `CanonicalSaveSnapshotBuilder` requires the Stage-9 actor-registry ownership root and validates bound epistemic/runtime structures before declaring the capture ready. Rehydration/migration handling remains 9A022/9A023.

## MC-06 · BOOTSTRAP_COMMITS_ARE_CANONICAL

**Status:** IMPLEMENTED / TESTED / PASS — explicit bootstrap commits are canonical; ordinary rehydration is mutation-free

If bootstrap/migration creates canonical state through CommitKernel, those writes are real commits and advance the run revision. Gameplay must never assume a newly loaded or initialized run begins at revision zero.

This does not permit bootstrap mutation during normal side-effect-free rehydration; MC-04 governs that boundary.

## MC-07 · ACTOR_KEY = (run_uuid, actor_instance_id)

**Status:** IMPLEMENTED / TESTED / PASS via 9A003

Actor instance identity is run-scoped. The same actor identifier text may exist in separate runs without cross-run authority or state sharing.

## MC-08 · ACTOR_DEFINITION_BINDING_IMMUTABLE

**Status:** IMPLEMENTED / TESTED / PASS via 9A003 registry semantics

A registered ActorInstance may not be rebound to a different static ActorDefinition. Runtime transformations belong in ActorRuntimeState, not by silently changing definition identity.

## MC-09 · SESSION_HANDLES_REBIND_AFTER_LOAD

**Status:** IMPLEMENTED / TESTED / PASS in 9A022

After load/run switch, runtime helpers (ActorRegistry, Observer, scheduler/context builders and similar handles) must bind to the newly loaded `RunSession`. No stale handle from a prior session may remain authoritative.

## MC-10 · ACTIVE_MASTER_STATUS_CONSISTENCY

**Status:** IMPLEMENTED AS MASTER-AUDIT CONTRACT IN I9.4a

Active master metadata must agree on the current Stage-9 patch state and next real step. Historical reports may retain their historical status, but active references must not contradict each other.

## Scheduling constraints introduced by this addendum

- MC-01 must be implemented before general Player/NPC/Qwen ActionProposal integration (Wave 3/5 boundary).
- MC-02 and MC-03 must be implemented before Stage-9 Perception/Knowledge/Belief integration is promoted.
- MC-04, MC-05 and MC-09 must be implemented before final Save/Load/Rehydration gates can PASS.
- MC-06 is subordinate to MC-04: bootstrap commits may be canonical only in explicit bootstrap/migration flows, never hidden inside ordinary rehydration.

## Hard rule

A newly discovered cross-stage contract is not called PASS merely because it is documented here. Only MC-07/MC-08 inherit real PASS evidence from 9A003; MC-10 is enforced by the master audit in this build. All other new contracts remain DEFINED/PENDING until implemented and executed.

## I9.33 closure resolution

MC-01 is enforced on Player input and ActorLogic/model output through explicit controlled-actor bindings. MC-02/03 are enforced through observer-bound Perception, actor-namespaced Knowledge and the separate actor-belief route. MC-04/05/09 are enforced by CanonicalSaveSnapshot + side-effect-free Rehydrator + fresh technical handles. MC-06 is demonstrated by explicit bootstrap-vs-rehydration separation. MC-07/08/10 remain PASS.
