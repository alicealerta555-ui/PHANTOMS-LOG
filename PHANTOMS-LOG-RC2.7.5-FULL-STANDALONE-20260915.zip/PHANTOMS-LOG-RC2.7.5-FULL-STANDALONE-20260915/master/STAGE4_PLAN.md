# PH4NT0M5-L0G · STAGE 4 · SUPEREVOLUTION / BIOLOGICAL CORE

**Authority date:** 2026-09-03  
**Status:** CLOSED / VERIFIED  
**Current relation to active project:** Stage 4 remains CLOSED / VERIFIED; former vertical-slice gating is historical only; full-version development is controlled by `master/PROJECT_MASTER.md`

Stage 4 builds the biological causal layer downstream of the closed Stage-1/2 foundation and the closed Stage-3 runtime authority architecture. It must not rewrite Stage-2 chronology, collapse public belief into biological truth, or encode personality/morality/consent as genetic destiny.

## 4A · Superevolution Timeline · VERIFIED / INTEGRATED

Refines Stage-2 E0–E5 into a biological process sequence without inventing unsupported exact dates:

`bounded therapy → directed adaptation → directed hybridization → repeated/distributed mixing → post-control-failure survival selection → free drift → stable sublineages`

Hard constraints:
- Superevolution begins at least 2000 years before T0.
- Directed hybridization belongs to E2 and may not be backdated into E0.
- Distributed survival selection requires E3 control/registration failure.
- Free drift requires persistent post-control-failure populations and maps to E4–E5.
- Stable sublineages are late results of prolonged divergence and do not retroactively become primordial species.
- Biology can constrain capability/cost/need, but cannot assign morality, profession, dominance/submission, attraction, consent or personality.

## 4B · Geneline Matrix · VERIFIED / INTEGRATED

Canonical typed lineage records now cover origin-package linkage, morphology, metabolism, environmental envelope, regeneration/costs, Stage-5 sensor hooks, stability, hybridization-depth hooks, constraints and Stage-4A-aligned WORLD_TRUTH provenance. The schema deliberately excludes arbitrary metadata backdoors, genetic morality/personality/consent assignments, detailed Stage-5 sensor models and Stage-6 inheritance mechanics.

## 4C · Functional Origin Packages · VERIFIED / INTEGRATED

The canonical functional-source registry now covers mammalian, avian, reptilian, amphibian, fish/cephalopod, arthropod/insect, fungal/plant/microbial and synthetic-biology packages. Packages expose possible biological contributions plus explicit causal tradeoffs; linking a package records provenance but never auto-assigns all traits or any personality/agency property. Stage-4A chronological availability is enforced, while Stage-5 sensor detail and Stage-6 inheritance remain out of scope. Multi-package bindings are canonical-order and expose a non-collapsing OriginDesignSpace: every source-supported candidate remains separately attributable with its required tradeoffs, with no automatic ranking, averaging or phenotype selection.

## 4D · Mono / Multi / Polyhybrids · VERIFIED / INTEGRATED

Hybrid class now derives from independent source-lineage complexes plus an explicit ancestry/integration DAG rather than visible trait count or origin-package count. MONO means one independent source complex; MULTI means multiple independent sources without qualifying nested poly ancestry; POLY requires at least three independent sources plus nested composite ancestry (a hybrid/composite later consumed by repeated mixing). Active/latent/conditional expression candidates remain source-qualified and do not auto-select phenotype. Biological coherence is tracked separately from ancestry class.

## 4E · Branch Classes · VERIFIED / INTEGRATED

Branch classification is multi-axis rather than a single hierarchy. SAPIENT and SEMI_SAPIENT are mutually exclusive evidence-backed cognitive assessments; FERAL, SYNTHETIC and DRIFT are orthogonal developmental/source-history labels and may coexist with either cognitive class or with cognition left UNASSESSED. Morphology never infers cognition. FERAL is not a moral/intelligence/hostility category, SYNTHETIC does not imply obedience or machine psychology, and DRIFT does not imply degeneration. FERAL lineage history is restricted to B4–B6, DRIFT to B5–B6, and SYNTHETIC requires Stage-4C synthetic-source provenance.

## 4F · Cognitive Drift / Behavioral Echoes · VERIFIED / INTEGRATED

Stage 4F now models bounded evidence-backed biological dispositions plus bio-cultural behavioral echoes without selecting behavior. The causal layers remain distinct and source-attributed:

`BIO disposition → culture/history → individual psychology/values → current situation → behavior`

The Stage-4F runtime stops before the final behavior node. Biological signals and behavioral echoes are bounded, physiology and cognition remain separate response layers, conflicting influences are preserved instead of erased by averaging, and final choice remains owned by the individual actor/runtime. Stage-4E DRIFT ancestry is explicitly not equivalent to Cognitive Drift and creates no automatic psychological state.

## 4G · Biological Validation / Closure · VERIFIED / CLOSURE PASS

The fail-closed Stage-4 closure harness composes 4A–4F through ten required invariants: chronology/causality, costed capability, origin tradeoff provenance, hybrid ancestry causality, biological coherence, no genetic destiny, branch-axis separation, influence-not-decision, Stage-5/6 boundary protection and complexity preservation. It executes 10 dedicated minimal pairs plus 4 cross-layer chains. Conflicted biological combinations may remain explicitly unresolved but cannot simultaneously assert active phenotype candidates.

**Stage 4 is CLOSED.**

## Post-Stage-4 historical transition note · SUPERSEDED

The former mandatory sequence `model training -> DEMO-0 -> Stage 5` was a historical vertical-slice development gate. It is preserved under `history/full_version_transition_pre_20260912/master/STAGE4_PLAN.md` and `history/retired_demo0_20260912/`, but it is **not an active blocker** for the current full-version line.

Stage 4 remains CLOSED / VERIFIED. Current full-version development uses the closed Runtime-I9 substrate and the active references in `CURRENT_REFERENCES.md`. Model training/evaluation remains an explicit later benchmark task and never grants model StateAuthority.

## Stage boundary

Stage 4 may expose hooks for senses and inheritance; detailed sense-scapes/communication remain downstream systems and germline/inheritance/speciation mechanics remain separate from actor decision authority.
