# PH4NT0M5-L0G · CONTENT-S7 FULL-VERSION STATUS

**Authority date:** 2026-09-12  
**Status:** IMPLEMENTED / TESTED / PASS

Stage 7 implements actor/run-local NEEDS on top of the frozen Actor Runtime architecture.

## Implemented historical scope

- 7.1 Complete actor/run-scoped need state.
- 7.2 Time and causal events change only applicable needs.
- 7.3 Multiple needs can coexist and compete.
- 7.4 Need pressures are projected into `ActorDecisionContext` as actor-visible motivation evidence.
- 7.5 Multi-turn NPC acceptance scene demonstrates changing motives without forced action.
- Physiological, social, autonomy, safety, status/career and regulation needs are represented.
- Stage-10 legacy creature needs are normalized to canonical Stage-7 keys and branch classes map to Stage-7 profiles.

## Authority boundary

NEEDS are attractors, never commands. They cannot authorize an action, imply consent, manufacture knowledge, override boundaries or write canonical state directly.

Canonical mutation remains:

`NEED_DELTA -> StateAuthority -> Stage7CommitAdapter -> CommitKernel`

## Active files

- `runtime/stage7/needs.py`
- `content/full_version/stage7_needs.json`
- `tests/test_stage7_full_version.py`
- `scripts/stage7_full_version_audit.py`
