# PH4NT0M5-L0G · STAGE 9 IMPLEMENTATION BRIDGE · 9.18–9.33 + I9.1

**Authority date:** 2026-09-11  
**Status:** Stage-9 architecture frozen through 9.33; patches 9A001–9A032 are IMPLEMENTED / TESTED / PASS in the final I9.33 master; ordered 34-step validator PASS; Stage 9 CLOSED.

This document continues `STAGE9_PLAYABLE_RUNTIME_INTEGRATION.md` (9.1–9.17) and records the final planning/freeze bridge into real source integration.

## 9.18 — Master Precedence & Integration Freeze

Precedence is fixed:

```text
Frozen current contract
> latest verified compatible implementation
> older compatible implementation
> legacy/history
```

Older packages may preserve provenance or fill proven gaps, but may never silently override a newer frozen rule. Historical packages remain inactive by default. The master is one active tree, not a stack of competing runtimes.

## 9.19 — Active Master Runtime Spine Mapping

Stage 9 reuses the verified Stage-3/4 runtime core and cumulative Stage-5 integration, then adds the Stage-9 orchestration spine. The existing playable v0.1 layer is `KEEP_AND_WRAP`: useful for input/CLI compatibility, but not State Authority. Stage 6/7/8 contracts remain frozen inputs. The target is one runtime, one canonical state and one commit path.

## 9.20 — Integration Gap Register & Mandatory Patch Families

Gaps are grouped by identity/isolation, state authority, turn runtime, scheduler/time, epistemics, persistence, Qwen boundary, narrative/integrity and legacy cleanup. First mandatory patch IDs:

- `9A001` Explicit Runtime Identity
- `9A002` Remove Authoritative Fallbacks
- `9A003` Run Ownership Guards
- `9A004` Single Commit Writer
- `9A005` Semantic EffectProposal
- `9A006` StateAuthority Gate
- `9A007` State Revision Guard
- `9A008` Commit Idempotency
- `9A009` PlayableRuntime Root
- `9A010` RuntimeContext
- `9A011` TurnTransaction
- `9A012` Playable -> ActionProposal Adapter
- `9A013` One-Action Window Gate
- `9A014` Validation/Resolution Split
- `9A015` Canonical World Time
- `9A016` Scheduler Dispatch Only
- `9A017` Event Authority Re-entry
- `9A018` Perception Read-only
- `9A019` Knowledge Commit Path
- `9A020` Actor Context Projection
- `9A021` Canonical Save Snapshot
- `9A022` Side-effect-free Rehydration
- `9A023` Save Identity & Continuity
- `9A024` ActorLogicBackend Interface
- `9A025` Model Privilege Removal
- `9A026` Model Decision Validation
- `9A027` Narrative Projection Boundary
- `9A028` Deterministic Turn Renderer
- `9A029` TurnResult Contract
- `9A030` State Mutation Provenance
- `9A031` Basic Golden Path
- `9A032` Stage-9 Integrity Harness

No patch is considered PASS merely because it is listed here.

## 9.21 — Wave 1 Contract: Identity / Fallback / Run Ownership

Authoritative runtime paths require explicit player, run and actor identity. Missing or mismatched identity fails closed. UI convenience may remain outside the authority boundary, but the runtime may not infer current/last/default identities. Mutable instances, knowledge and scheduled events must remain run-owned and cross-run references must reject.

## 9.22 — Wave 2 Contract: Single Writer / Effects / Authority / Revision / Idempotency

All gameplay systems produce semantic Effects. StateAuthority is read-only. CommitKernel is the sole canonical mutable-state writer. Raw arbitrary state patches are prohibited. Commits are revision-checked, atomic where required, idempotent and fully traceable to effect/action/event provenance.

## 9.23 — Wave 3 Contract: Playable Turn Spine

`PlayableRuntime` becomes orchestration only. `RuntimeContext` carries explicit identity and revision. `TurnTransaction` records turn-local artifacts but never becomes a second world state. The existing parser feeds `ActionProposal`. One normal action is allowed per ActionWindow. Validation and Resolution are separate and read-only; gameplay RNG belongs only to Resolution when required.

## 9.24 — Core Barrier Freeze

Patches 9A001–9A014 form the Stage-9 Core Barrier. Complex gameplay, Qwen NPC runtime and advanced world systems must not be promoted on top of a broken core. Status vocabulary is fixed: `DEFINED`, `IMPLEMENTED`, `TESTED`, `PASS`, `FAIL`, `BLOCKED`.

## 9.25 — Implementation Wave 1 Procedure

Real code procedure: preserve a pre-patch snapshot, run baseline tests, inventory runtime entry points, add/extend explicit identity, remove authoritative fallbacks, harden run ownership, run targeted cross-run tests, then full regression. Promotion requires all Wave-1 gates to pass with no unresolved P0 identity/isolation finding.

## 9.26 — Implementation Wave 2 Procedure

Inventory actual mutable writes first. Introduce/harden the CommitKernel, semantic EffectProposal schema, StateAuthority registry, revision checks and idempotency. Each patch is small, testable and rollback-safe. Direct state writes and stale/duplicate mutation remain hard blockers.

## 9.27 — Implementation Wave 3 Procedure

Build the real playable spine on top of Waves 1–2. Initial action set is `LOOK`, `TAKE`, `OPEN`, `MOVE`. The existing parser is wrapped rather than discarded. Initial resolution may be deterministic. The first golden path must use the real authority/commit pipeline and include negative tests for duplicate input, stale turn, invalid target and second action in the same ActionWindow.

## 9.28 — Implementation Wave 4 Procedure

Add canonical world time, scheduler dispatch/re-entry, perception, knowledge, deterministic narrative, TurnResult and canonical persistence. Save/load must preserve identity, scheduler, RNG, revision, knowledge/belief and idempotency. Rehydration must cause no gameplay side effects. Continuation equivalence is mandatory.

## 9.29 — Implementation Wave 5 Procedure

Introduce `ActorLogicBackend` with a deterministic stub first and Qwen only second. Qwen receives actor-visible `ActorDecisionContext`, never full world state or mutation handles. Model output is untrusted, schema/reference/revision/context validated and mapped to the ordinary ActionProposal path. Runtime must work with `QWEN_DISABLED=true`.

## 9.30 — Implementation Wave 6 Procedure

Add a minimal Combat vertical slice through the same runtime spine: ATTACK, ammo consumption, hit/miss, damage, world time, noise event, perception and NPC response. Combat may not directly mutate HP/ammo or bypass Authority. Ammo/resource double-spend, RNG continuity, hidden-state leakage and crash/retry behavior are mandatory tests.

## 9.31 — Implementation Wave 7 Procedure

Harden crash recovery, duplicate input/action/effect/commit/event handling, event re-entry, scheduler cascades and revision continuity. Rule: before commit nothing canonical; after commit never apply again. The IntegrityHarness observes and fails but never repairs production state.

## 9.32 — Stage-9 Closure Audit / Freeze Candidate

Stage 9 closes only when required identity, isolation, state-authority, action-window, resource, scheduler, epistemic, persistence, Qwen-boundary, combat and recovery gates are actually executed and PASS. Mandatory golden paths cover basic interaction, persistence continuation, NPC action, combat and crash/retry. Builds move through `CANDIDATE -> TEST_CANDIDATE -> FREEZE_CANDIDATE -> ACTIVE_MASTER`; a hard-gate failure blocks promotion.

## 9.33 — Final Pre-Implementation Closure

Core architecture is frozen. No further core-architecture expansion is allowed without evidence from real implementation revealing a true contract gap. The implementation order is Waves 1–7. Existing correct code is reused or wrapped rather than replaced wholesale. Current Stage-3/4 and Stage-5 verified tests remain regression baselines but do not prove Stage 9.

The next engineering phase is source-driven rather than theory-driven.

# I9.1 — Active Master Source Audit

**Status:** COMPLETE · READ-ONLY

The real active master was audited against the Stage-9 contracts. The audit did not patch source code.

Confirmed findings:

- Existing Stage-3C run isolation is a strong reusable basis.
- Existing `RunIdentity(player_uuid, run_uuid)` and exact run/session addressing substantially cover the player/run part of 9A001/9A002.
- Existing persistence uses explicit player/run paths and rejects sibling-run fallback/tampering in the audited path.
- Stage-3C targeted audit/tests: **17/17 PASS**.
- Stage-5 run-session/observation targeted audit/tests: **8/8 PASS**.
- Playable v0.1 selftest: **PASS**.
- Master merge audit: **PASS**.
- The principal Wave-1 gap is canonical `actor_instance_id` ownership/registration and propagation through the playable Stage-9 entry boundary.
- The playable compatibility layer still depends on its loaded profile/session object and therefore must be wrapped before it can become a Stage-9 entry path.
- Existing Stage-3A/3B ActionPipeline / Authority / Commit concepts should be preserved and hardened, not blindly rewritten.
- `StateStore` remains technically reachable and the existing pipeline combines responsibilities that Stage 9 intends to separate/wrap in later waves.

The detailed evidence report is stored at:

`reports/stage9/STAGE9_I9_1_ACTIVE_MASTER_SOURCE_AUDIT_20260911.md`

## Next real implementation step

```text
I9.2 / PATCH-9A001
Extend the existing explicit RunIdentity boundary with canonical actor_instance_id
and propagate it through the Stage-9 runtime entry contract.
```

Current truth:

```text
Stage 9 architecture 9.1–9.33: DEFINED / FROZEN
I9.1 source audit: COMPLETE
9A001+ real source patches: NOT STARTED
Stage-9 implementation gates: NOT RUN unless explicitly evidenced above
```

## I9.33 closure note

The source-driven implementation sequence 9A001–9A032 is complete in the final I9.33 Stage-9 master. See `reports/stage9/STAGE9_I9_33_STAGE9_CLOSURE_20260911.md` for the closure gate matrix and final validation evidence.
