# RC2.2 Etappe 7 Integration Contract — Habit & Instinct Layer

1. Emit `DecisionEvent` only after a player has actually chosen an action.
2. Use stable `situation_family` / `choice_key` identifiers; do not feed natural-language player text directly into the habit engine.
3. Player-only. NPC and Crew decisions must set `actor_is_player=False` or bypass this subsystem.
4. The host may call `suggest_instinct_action()` before repetitive low-impact routines. Returned action is only a suggestion for the host executor.
5. Never invoke instinct automation for irreversible, moral, story, kill, betrayal, faction or major-resource decisions.
6. Any explicit player command wins over the suggested instinct action.
7. `override_instinct()` records that the old routine is no longer absolute and helps it fade over time.
8. Persist `habit_state` per `player_uuid + run_uuid`; never share across runs.
9. Player UI uses `visible_habits()` and transition messages only. Hidden strength, stability and thresholds are runtime-only.
