from runtime.stage4b import (
    EnvironmentalEnvelope, GenelineRecord, HybridizationProfile, KnownBiologicalConstraint,
    LineageProvenance, MetabolismProfile, MorphologyProfile, OriginPackageLink,
    RegenerationProfile, StabilityProfile,
)
from runtime.stage4c import bind_origin_packages, build_canonical_origin_registry
from runtime.stage4e import (
    BranchClass, BranchProfile, BranchProvenance, CognitiveAssessment, CognitiveBranch,
    DevelopmentalBranchEvidence, classify_branch,
)


def base(lineage_id: str, phase="B6", epoch="E5"):
    return GenelineRecord(
        lineage_id=lineage_id, display_name=lineage_id, origin_packages=OriginPackageLink(),
        morphology=MorphologyProfile(("bilateral",)),
        metabolism=MetabolismProfile(("heterotrophic",), energetic_cost_tags=("finite",)),
        environment=EnvironmentalEnvelope(("temperate",)), regeneration=RegenerationProfile("NONE"),
        sensor_hooks=(), stability=StabilityProfile(), hybridization=HybridizationProfile((), 0),
        known_constraints=(KnownBiologicalConstraint(f"C_{lineage_id}", "stress", "Finite resources."),),
        provenance=LineageProvenance(phase, epoch, ("STAGE4E_STRESS",)),
    )


def prof(lineage, cognitive=CognitiveBranch.UNASSESSED, cognitive_refs=(), scope="", feral=(), synthetic=(), drift=()):
    return BranchProfile(
        lineage.lineage_id,
        CognitiveAssessment(cognitive, tuple(cognitive_refs), scope),
        DevelopmentalBranchEvidence(tuple(feral), tuple(synthetic), tuple(drift)),
        BranchProvenance(("STAGE4E_STRESS",)),
    )


def main() -> None:
    registry = build_canonical_origin_registry()
    checks = 0
    for i in range(20_000):
        mode = i % 5
        if mode == 0:
            lineage = bind_origin_packages(base(f"S4E_SAP_{i}"), ("ORG_MAMMALIAN_HOMEOSTASIS",), registry)
            result = classify_branch(lineage, prof(lineage, CognitiveBranch.SAPIENT, (f"OBS_{i}",), "longitudinal population evidence"), registry)
            if result.branch_classes != (BranchClass.SAPIENT,):
                raise AssertionError("STAGE4E_SAPIENT_FAILED")
        elif mode == 1:
            lineage = bind_origin_packages(base(f"S4E_FERAL_{i}"), ("ORG_REPTILIAN_WATER_THERMAL",), registry)
            result = classify_branch(lineage, prof(lineage, feral=(f"FERAL_{i}",)), registry)
            if result.branch_classes != (BranchClass.FERAL,) or result.cognitive_branch != CognitiveBranch.UNASSESSED:
                raise AssertionError("STAGE4E_FERAL_ORTHOGONALITY_FAILED")
        elif mode == 2:
            lineage = bind_origin_packages(base(f"S4E_SYN_{i}"), ("ORG_SYNTHETIC_BIOLOGY_PLATFORM",), registry)
            result = classify_branch(lineage, prof(lineage, CognitiveBranch.SEMI_SAPIENT, (f"OBS_{i}",), "longitudinal population evidence", synthetic=(f"SYN_{i}",)), registry)
            if result.branch_classes != (BranchClass.SEMI_SAPIENT, BranchClass.SYNTHETIC):
                raise AssertionError("STAGE4E_SYNTHETIC_ORTHOGONALITY_FAILED")
        elif mode == 3:
            lineage = bind_origin_packages(base(f"S4E_DRIFT_{i}"), ("ORG_AMPHIBIAN_EXCHANGE_PLASTICITY",), registry)
            result = classify_branch(lineage, prof(lineage, CognitiveBranch.SAPIENT, (f"OBS_{i}",), "longitudinal population evidence", feral=(f"FERAL_{i}",), drift=(f"DRIFT_{i}",)), registry)
            if result.branch_classes != (BranchClass.SAPIENT, BranchClass.FERAL, BranchClass.DRIFT):
                raise AssertionError("STAGE4E_MULTI_AXIS_FAILED")
        else:
            lineage = bind_origin_packages(base(f"S4E_INVALID_{i}", "B4", "E4"), ("ORG_MAMMALIAN_HOMEOSTASIS",), registry)
            try:
                classify_branch(lineage, prof(lineage, drift=(f"DRIFT_{i}",)), registry)
            except ValueError as exc:
                if "DRIFT_BRANCH_BACKDATED" not in str(exc):
                    raise
            else:
                raise AssertionError("STAGE4E_DRIFT_BACKDATE_NOT_REJECTED")
        checks += 1
    print(f"STAGE4E_STRESS={checks}/{checks} PASS")


if __name__ == "__main__":
    main()
