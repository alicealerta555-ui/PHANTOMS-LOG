# PH4NT0M5-L0G RC2.2 — Etappe 17: NPC Lived Experience

Status: IMPLEMENTED / TESTED / PASS

## Ziel
NPCs sollen nicht nur korrekt auf den Spieler reagieren, sondern wie Personen wirken, die ein eigenes Leben fortführen.

## Implementiert
- laufende Aufgabe bleibt während Gesprächen sichtbar
- Müdigkeit, Hunger, Schmerz, Stress und soziale Energie beeinflussen Verfügbarkeit
- Gespräch ist kontextabhängig: Gefahr, Zeitdruck, Privatsphäre, Unterbrechungskosten
- persönliches Thema kann wegen geringer Vertrautheit oder fehlender Privatsphäre abgelehnt/verschoben werden
- explizite Spielerfrage wird bevorzugt beantwortet, aber bei Belastung kurz statt als Infodump
- NPC-Initiative entsteht nur bei Interesse + passendem Moment
- sichtbares Interesse ist möglich, ohne Dialog zu erzwingen
- Wiederholung gleicher Themen wird gedämpft
- offene Themen können vertagt und später wieder aufgenommen werden
- Wiedersehen nach längerer Abwesenheit kann sichtbar registriert werden
- NPC kann Details über den Spieler und eigene Versprechen persistent behalten
- keine Zahlen-/Stat-Dumps in der Narration
- keine zweite Actor-KI; Host-Actor-State bleibt Autorität

## Designprinzipien
1. NPCs existieren nicht nur für den Spieler.
2. Interesse wird zuerst körperlich/sozial sichtbar, nicht automatisch verbalisiert.
3. Beziehung schaltet Tiefe frei, nicht Allwissenheit.
4. Ein ungünstiger Moment erzeugt DEFER statt künstlichen Dialogzwang.
5. Wiederholungen werden gedämpft.
6. Alltag und laufende Aufgaben bleiben präsent.
7. Wissen/Bedürfnisse werden vom Host geliefert; diese Schicht erfindet keine Hidden Facts.

## Integration
Neue Runtime-Komponente:
`runtime/player_progression/npc_lifelike.py`

Host API über `AdaptiveGameplayRuntime`:
- `npc_social_moment(...)`
- `revisit_npc_topic(...)`

Persistenz:
- `npc_lived_experience`

## Regression
172/172 Tests PASS.
