#!/usr/bin/env python3
import os
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
env = dict(os.environ)
env['PYTHONPATH'] = os.pathsep.join([str(root), str(root / 'runtime')])
commands = [
    [sys.executable, '-m', 'unittest', 'discover', '-s', str(root / 'tests'), '-p', 'test_*.py', '-q'],
    [sys.executable, str(root / 'stress_test.py')],
    [sys.executable, str(root / 'integration_stress.py')],
    [sys.executable, str(root / 'stage3b_stress.py')],
    [sys.executable, str(root / 'core_reconstruction_stress.py')],
    [sys.executable, str(root / 'stage3c_stress.py')],
    [sys.executable, str(root / 'smoke_e2e.py')],
    [sys.executable, str(root / 'smoke_stage3b_e2e.py')],
    [sys.executable, str(root / 'smoke_stage3c_e2e.py')],
    [sys.executable, str(root / 'scripts' / 'stage3c_isolation_audit.py')],
    [str(root / 'scripts' / 'reference_audit.sh')],
    [sys.executable, '-m', 'compileall', '-q', str(root / 'runtime'), str(root / 'tests')],
]
for cmd in commands:
    proc = subprocess.run(cmd, cwd=root, env=env)
    if proc.returncode:
        raise SystemExit(proc.returncode)
print('CURRENT_PACKAGE_SELFTEST=PASS')
