# Integration Contract — Etappe 17 NPC Lived Experience

## Host liefert
- autoritativen NPC-Life-Snapshot: Beziehung, Stimmung, Belastung, soziale Energie, laufende Aufgabe, Interessen
- aktuelle Situation: Gefahr, Zeitdruck, Privatsphäre, Busy-State
- ConversationTopic ohne Hidden World Facts

## Runtime liefert
- SocialAction: ENGAGE / BRIEF / DEFER / DECLINE / INITIATE / SILENT
- sichtbare Cues
- optionalen line hint
- deferred topic key
- indication whether NPC resumes current task

## Harte Regeln
- keine Hidden-Facts ableiten
- keine Actor-Entscheidung überschreiben
- kein automatischer Infodump
- Beziehung != Wahrheit / Wissen
- Müdigkeit/Schmerz/Stress werden qualitativ beschrieben, nie als Zahl ausgegeben
- Topics dürfen persistieren und später wieder auftauchen
