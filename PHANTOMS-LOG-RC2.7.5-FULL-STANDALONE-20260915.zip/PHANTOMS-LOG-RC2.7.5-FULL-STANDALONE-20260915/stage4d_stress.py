from runtime.stage4b import (
    EnvironmentalEnvelope, GenelineRecord, HybridizationProfile, KnownBiologicalConstraint,
    LineageProvenance, MetabolismProfile, MorphologyProfile, OriginPackageLink,
    RegenerationProfile, StabilityProfile,
)
from runtime.stage4c import bind_origin_packages, build_canonical_origin_registry
from runtime.stage4d import (
    ExpressionPartition, HybridClass, HybridCompositionProvenance, HybridCompositionRecord,
    HybridSourceComponent, IntegrationMode, IntegrationNode, TraitCandidateRef, classify_hybrid,
)


def base(lineage_id: str):
    return GenelineRecord(
        lineage_id=lineage_id, display_name=lineage_id, origin_packages=OriginPackageLink(),
        morphology=MorphologyProfile(("bilateral",)),
        metabolism=MetabolismProfile(("heterotrophic",), energetic_cost_tags=("finite",)),
        environment=EnvironmentalEnvelope(("synthetic",)), regeneration=RegenerationProfile("NONE"),
        sensor_hooks=(), stability=StabilityProfile(), hybridization=HybridizationProfile((), 0),
        known_constraints=(KnownBiologicalConstraint(f"C_{lineage_id}", "stress", "Finite resources."),),
        provenance=LineageProvenance("B3", "E3", ("STAGE4D_STRESS",)),
    )


def comp(lineage, components, nodes=(), root=None, expression=None):
    return HybridCompositionRecord(
        lineage.lineage_id, tuple(components), tuple(nodes), root or components[0].component_id,
        expression or ExpressionPartition(),
        __import__("runtime.stage4d", fromlist=["CoherenceAssessment"]).CoherenceAssessment(),
        HybridCompositionProvenance(("STAGE4D_STRESS",)),
    )


def main() -> None:
    registry = build_canonical_origin_registry()
    refs = registry.ids()
    checks = 0
    for i in range(20_000):
        mode = i % 3
        if mode == 0:
            selected = (refs[i % len(refs)], refs[(i + 1) % len(refs)])
            selected = tuple(dict.fromkeys(selected))
            lineage = bind_origin_packages(base(f"S4D_MONO_{i}"), selected, registry)
            components = (HybridSourceComponent("A", f"SRC_{i}_A", selected),)
            result = classify_hybrid(lineage, comp(lineage, components), registry)
            if result.hybrid_class != HybridClass.MONO or result.integration_depth != 0:
                raise AssertionError("STAGE4D_MONO_CLASSIFICATION_FAILED")
        elif mode == 1:
            selected = tuple(refs[(i + j) % len(refs)] for j in range(4))
            selected = tuple(dict.fromkeys(selected))
            lineage = bind_origin_packages(base(f"S4D_MULTI_{i}"), selected, registry)
            components = tuple(HybridSourceComponent(f"C{j}", f"SRC_{i}_{j}", (pkg,)) for j, pkg in enumerate(selected))
            node = IntegrationNode("H", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, tuple(c.component_id for c in reversed(components)))
            result = classify_hybrid(lineage, comp(lineage, tuple(reversed(components)), (node,), "H"), registry)
            if result.hybrid_class != HybridClass.MULTI or result.integration_depth != 1:
                raise AssertionError("STAGE4D_MULTI_CLASSIFICATION_FAILED")
        else:
            selected = tuple(refs[(i + j) % len(refs)] for j in range(3))
            if len(set(selected)) < 3:
                continue
            lineage = bind_origin_packages(base(f"S4D_POLY_{i}"), selected, registry)
            components = tuple(HybridSourceComponent(x, f"SRC_{i}_{x}", (pkg,)) for x, pkg in zip(("A", "B", "C"), selected))
            nodes = (
                IntegrationNode("H1", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("B", "A")),
                IntegrationNode("H2", "B3", "E3", IntegrationMode.REPEATED_MIXING, ("C", "H1")),
            )
            package = registry.get(selected[0])
            trait = TraitCandidateRef("A", selected[0], package.contributions[0].contribution_id)
            result = classify_hybrid(lineage, comp(lineage, components, nodes, "H2", ExpressionPartition(latent_candidate_refs=(trait,))), registry)
            if result.hybrid_class != HybridClass.POLY or result.integration_depth != 2 or result.latent_candidate_count != 1:
                raise AssertionError("STAGE4D_POLY_CLASSIFICATION_FAILED")
        checks += 1
    print(f"STAGE4D_STRESS={checks}/{checks} PASS")


if __name__ == "__main__":
    main()
