---
name: Feature request
about: Suggest a gameplay, engine, AI or tooling improvement
title: "[FEATURE] "
labels: enhancement
---

## Problem / opportunity

## Proposed behaviour

## Why it improves PHANTOMS-LOG

## Runtime / persistence implications

## Possible tests
