---
name: Bug report
about: Report a reproducible PHANTOMS-LOG problem
title: "[BUG] "
labels: bug
---

## Version / commit

## Environment

## What happened?

## What did you expect?

## Reproduction steps

1.
2.
3.

## Relevant input / command

## Logs or save details
