## What changes?

## Why?

## Gameplay/runtime impact

## State/persistence impact

## Tests performed

## Checklist

- [ ] No narration path invents authoritative world state.
- [ ] Tests added/updated where appropriate.
- [ ] Licensing/attribution requirements are satisfied.
