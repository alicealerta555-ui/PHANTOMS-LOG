# Etappe 11 – Gameplay Hooks

Diese Etappe bindet Adaptive Player Evolution an **semantisch aufgelöste, bereits committete Gameplay-Aktionen**.

Unterstützte Domänen:
- Bewegung
- Kampf
- Interaktion
- Medizin
- Technik
- Hacking
- Dialog
- Exploration
- Survival
- Crafting

Wichtige Grenzen:
- Kein Lernen aus bloßem Spielertext.
- Kein Lernen vor Action-Resolution/Commit.
- NPC/Crew-Ereignisse speisen das exklusive Player-Lernsystem nicht.
- Nur sichtbarer/bekannter Kontext darf als Lernkontext übergeben werden.
- High-Stakes-, irreversible und moralische Entscheidungen werden nie vorausautomatisiert.
- Die Integration ist host-neutral und kann an RC2.1/RC2.2 ActionPipeline/Playable-Resolver angeschlossen werden, ohne deren State Authority zu ersetzen.
