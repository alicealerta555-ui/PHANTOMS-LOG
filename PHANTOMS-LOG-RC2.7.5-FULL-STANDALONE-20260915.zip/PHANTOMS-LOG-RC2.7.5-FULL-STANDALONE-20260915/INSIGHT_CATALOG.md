# Hidden Insight Catalog

Total: 96

## MICRO
- **Improvised Solution** (`adapt_improvise`) — Unvollständige Werkzeuge fühlen sich seltener wie ein Ende und häufiger wie ein Anfang an.
- **Clear Callout** (`cmd_callout`) — Deine kurzen Anweisungen werden klarer und kommen in hektischen Momenten besser an.
- **Second Wind** (`end_second_wind`) — Dein Körper findet nach extremer Belastung schneller zurück in einen brauchbaren Rhythmus.
- **Brace** (`force_brace`) — Du setzt dein Gewicht inzwischen instinktiv gegen einen erwarteten Aufprall.
- **Remote Familiarity** (`mach_remote`) — Fernsteuerung verlangt dir weniger bewusste Aufmerksamkeit ab.
- **Bleeding Recognition** (`med_bleeding`) — Du erkennst schneller, welche Blutung sofort zählt und welche noch warten kann.
- **Balance** (`mob_balance`) — Unsichere Flächen kosten dich weniger Aufmerksamkeit als früher.
- **Network Mapping** (`net_map`) — Verbindungen und Abhängigkeiten eines Netzes ordnen sich für dich schneller.
- **Audio Direction** (`perc_audio_dir`) — Geräusche bekommen Richtung, Entfernung und Bedeutung schneller als früher.
- **Breath Control** (`prec_breath`) — Du bemerkst, wann dein Atem einen Schuss stört und wann er ihn trägt.
- **Cover Body** (`prot_cover_body`) — Du stellst dich inzwischen automatisch zwischen Gefahr und diejenigen, die du schützen willst.
- **Static** (`res_static`) — Manche Orte fühlen sich falsch an, noch bevor du einen Grund dafür findest.
- **Read Room** (`soc_read_room`) — Du bemerkst schneller, wer tatsächlich spricht und wer nur darauf wartet, dass jemand anderes entscheidet.
- **Soft Step** (`stealth_soft_step`) — Du setzt deine Schritte dort, wo die Umgebung sie am ehesten verschluckt.
- **Scavenger Eye** (`surv_scav_eye`) — Zwischen Schrott fällt dir Brauchbares schneller auf.
- **Part Memory** (`tech_part_memory`) — Bauteile, die du schon einmal in der Hand hattest, erkennst du schneller wieder.

## TECHNIQUE
- **Failure Read** (`adapt_failure_read`) — Fehlschläge hinterlassen dir inzwischen mehr Information als Frust.
- **Target Share** (`cmd_target_share`) — Du teilst nicht mehr nur ein Ziel mit – du vermittelst, warum es jetzt zählt.
- **Pain Focus** (`end_pain_focus`) — Schmerz ist noch da, aber er bestimmt nicht mehr automatisch deine nächste Entscheidung.
- **Follow Through** (`force_follow_through`) — Du hörst nicht mehr am Treffpunkt auf. Deine Bewegung trägt den Angriff kontrolliert weiter.
- **Sensor Link** (`mach_sensor_link`) — Du liest fremde Sensorsichten inzwischen fast so schnell wie deine eigenen.
- **Trauma Control** (`med_trauma`) — Unter Druck konzentrierst du dich zuverlässiger auf das, was einen Menschen zuerst am Leben hält.
- **Fast Vault** (`mob_fast_vault`) — Hindernisse sind immer seltener Unterbrechungen deiner Bewegung.
- **Trace Awareness** (`net_trace`) — Du bemerkst früher, wann ein Zugriff beginnt Spuren zu hinterlassen.
- **Motion Priority** (`perc_motion`) — Bewegung zieht deinen Blick an, ohne dass du aktiv danach suchen musst.
- **Range Feel** (`prec_range_feel`) — Entfernungen fühlen sich weniger wie Schätzungen und mehr wie Erfahrung an.
- **Intercept** (`prot_intercept`) — Du erkennst den Augenblick früher, in dem du eine Gefahr noch abfangen kannst.
- **Grounding** (`res_grounding`) — Du hast Wege gefunden, dich nach fremden Eindrücken schneller wieder bei dir selbst zu verankern.
- **Calm Voice** (`soc_calm_voice`) — Du weißt besser, wann Ruhe ansteckender ist als Lautstärke.
- **Noise Masking** (`stealth_noise_mask`) — Du nutzt fremde Geräusche inzwischen bewusst als Deckung für die eigenen.
- **Route Sense** (`surv_route`) — Du merkst früher, welche Route nur kurz aussieht und welche tatsächlich sicher durchführt.
- **Fault Sound** (`tech_fault_sound`) — Einige Defekte hörst du inzwischen, bevor du ein Gehäuse öffnest.
- **Hard Reset** (`hyb_hard_reset`) [HYBRID] — Du erkennst, wann ein System eher physisch als elegant überzeugt werden will.
- **Predator Clock** (`hyb_predator_clock`) [HYBRID] — Du wartest nicht mehr auf eine Öffnung. Du merkst, wann sie entstehen wird.
- **Field Armorer** (`hyb_field_armorer`) [HYBRID] — Du behandelst Panzerung nicht mehr getrennt von deinem eigenen Bewegungsstil.
- **Combat Medic** (`hyb_combat_medic`) [HYBRID] — Du behandelst nicht mehr nach dem Gefecht. Du behandelst mitten in seinem Rhythmus.
- **Field Tuning** (`hyb_field_tuning`) [HYBRID] — Du stimmst Waffen nicht auf Tabellen ab, sondern auf die Art, wie du sie tatsächlich führst.
- **Social Engineer** (`hyb_social_engineer`) [HYBRID] — Menschen und Systeme haben unterschiedliche Passwörter, aber oft denselben Fehler: Vertrauen.
- **Quiet Hands** (`hyb_quiet_hands`) [HYBRID] — Du behandelst Verletzte, ohne dabei deine Aufmerksamkeit oder Ruhe an die Umgebung zu verlieren.
- **Silent Repair** (`hyb_silent_repair`) [HYBRID] — Werkzeuggeräusche sind für dich inzwischen genauso kontrollierbar wie Schritte.
- **Survival Engineer** (`hyb_survival_engineer`) [HYBRID] — Du baust nicht für Eleganz. Du baust dafür, dass es draußen weitergeht.

## ADVANCED
- **Context Switch** (`adapt_context_switch`) — Du wechselst Lösungswege schneller, wenn sich die Lage verändert.
- **Battle Rhythm** (`cmd_battle_rhythm`) — Du erkennst den Rhythmus einer Gruppe und gibst Anweisungen zunehmend dort, wo sie ihn verstärken statt unterbrechen.
- **Last Reserve** (`end_last_reserve`) — Unter Belastung findest du Reserven, auf die du dich früher nicht verlassen konntest.
- **Shock Entry** (`force_shock_entry`) — Du hast gelernt, den Moment des Eindringens selbst als Waffe zu benutzen.
- **Mesh** (`mach_mesh`) — Mehrere Geräte fühlen sich nicht mehr wie einzelne Werkzeuge an, sondern wie ein gemeinsames System.
- **Adaptive Treatment** (`med_adaptive`) — Du behandelst nicht mehr nur nach Schema. Körper, Implantate und Umstände fließen in dieselbe Entscheidung ein.
- **Flow** (`mob_flow`) — Gelungene Bewegungen verbinden sich beinahe von selbst zur nächsten.
- **Ghost Access** (`net_ghost_access`) — Unauffälliger Zugriff ist für dich nicht mehr nur Glück, sondern eine eigene Disziplin.
- **Pattern Recognition** (`perc_pattern`) — Wiederkehrende Abläufe springen dir schneller ins Auge – gerade dann, wenn etwas davon abweicht.
- **Weakpoint Memory** (`prec_weakpoint`) — Du merkst dir Schwachstellen, noch bevor du bewusst entscheidest, auf sie zu zielen.
- **Hold Line** (`prot_hold_line`) — Du hältst Positionen nicht nur. Andere beginnen sich darauf zu verlassen, dass sie hinter dir bestehen bleiben.
- **Redirect** (`res_redirect`) — Energie fühlt sich weniger wie etwas an, das nur auf dich trifft – und mehr wie etwas, dessen Weg sich beeinflussen lässt.
- **Pressure Point** (`soc_pressure`) — Du erkennst häufiger, welche Sorge oder Hoffnung ein Gespräch wirklich steuert.
- **Lost Contact** (`stealth_lost_contact`) — Wenn Sichtkontakt abreißt, verlässt du instinktiv die Route, die man von dir erwarten würde.
- **Hazard Recognition** (`surv_hazard`) — Umweltgefahren wirken auf dich zunehmend wie Spuren statt Überraschungen.
- **Field Fabrication** (`tech_field_fab`) — Aus brauchbaren Resten entstehen in deinem Kopf schon Lösungen, bevor du alle Teile sortiert hast.
- **Command Mesh** (`hyb_command_mesh`) [HYBRID] — Du verteilst Aufmerksamkeit zwischen Menschen und Maschinen, ohne beide getrennt führen zu müssen.
- **Pack Hunter** (`hyb_pack_hunter`) [HYBRID] — Du liest nicht nur das Ziel, sondern auch, wie deine Gruppe sich am besten darum schließt.
- **Field Leader** (`hyb_field_leader`) [HYBRID] — Deine Anweisungen beginnen dort, wo Schutz nicht mehr allein mit deinem eigenen Körper möglich ist.
- **Ironhand Seed** (`hyb_ironhand_seed`) [HYBRID] — Schwere Technik beginnt sich deinem Angriffstempo unterzuordnen statt es auszubremsen.
- **Kinetic Execution** (`hyb_kinetic_execution`) [HYBRID] — Geschwindigkeit ist für dich nicht mehr der Weg zum Angriff. Sie ist ein Teil des Angriffs.
- **Guardian Drive** (`hyb_guardian_drive`) [HYBRID] — Du hast gelernt, offensiven Druck so einzusetzen, dass er Raum für andere schafft.
- **Warsaint Seed** (`hyb_warsaint_seed`) [HYBRID] — Kraft und Resonanz antworten zunehmend im selben Moment aufeinander.
- **Wild Medic** (`hyb_wild_medic`) [HYBRID] — Wenn Material fehlt, hörst du nicht auf zu behandeln. Du denkst anders weiter.
- **Angel Drone** (`hyb_angel_drone`) [HYBRID] — Deine Drohnen suchen Gefahr nicht mehr nur. Sie suchen diejenigen, die darin verschwinden könnten.
- **Bioshaper Seed** (`hyb_bioshaper_seed`) [HYBRID] — Biologie und Resonanz beginnen für dich dieselben Fragen mit unterschiedlichen Worten zu stellen.
- **Impossible Route** (`hyb_impossible_route`) [HYBRID] — Wo andere zwischen Wegen wählen, beginnst du manchmal einen neuen zu sehen.
- **Signal Empathy** (`hyb_signal_empathy`) [HYBRID] — Manche Systemzustände bemerkst du inzwischen, bevor du sie technisch sauber erklären kannst.
- **Adaptive Shooter** (`hyb_adaptive_shooter`) [HYBRID] — Du hältst nicht an einem perfekten Schuss fest, wenn die Lage längst einen anderen verlangt.
- **Sensor Shot** (`hyb_sensor_shot`) [HYBRID] — Fremde Sensoren werden zunehmend zu einer Erweiterung deiner eigenen Zielwahrnehmung.
- **Signal Warden** (`hyb_signal_warden`) [HYBRID] — Du verteidigst nicht mehr nur Räume und Menschen, sondern auch ihre Verbindungen.
- **Resonant Guard** (`hyb_resonant_guard`) [HYBRID] — Dein Schutzinstinkt beginnt Resonanz genauso selbstverständlich einzubeziehen wie Deckung und Körperposition.
- **Cold Reader** (`hyb_cold_reader`) [HYBRID] — Kleine Reaktionen verraten dir immer öfter, welche Worte wirklich getroffen haben.
- **Ghost Drone** (`hyb_ghost_drone`) [HYBRID] — Deine Geräte lernen denselben Grundsatz wie du: gesehen werden ist oft schon der erste Fehler.
- **Dead Circuit** (`hyb_dead_circuit`) [HYBRID] — Du weißt, wie elektronische Störungen aussehen müssen, damit niemand zuerst an Sabotage denkt.
- **Recon Specialist** (`hyb_recon_specialist`) [HYBRID] — Unsichtbar zu bleiben und alles zu sehen sind für dich zu einer gemeinsamen Aufgabe geworden.
- **Phase Seed** (`hyb_phase_seed`) [HYBRID] — Du beginnst Resonanz nicht nur als Kraft, sondern als Möglichkeit zum Verschwinden zu begreifen.
- **Ruin Whisper** (`hyb_ruin_whisper`) [HYBRID] — Ruinen erzählen dir zunehmend, wo Menschen gingen, wo etwas brach und wo noch Gefahr wartet.

## SIGNATURE
- **Wildcard** (`adapt_wildcard`) — Du hast aufgehört, ungewöhnliche Lösungen erst dann zu erwägen, wenn alle normalen versagt haben.
- **Field Conductor** (`cmd_field_conductor`) — Menschen und Systeme um dich herum beginnen sich unter Druck wie Teile derselben Handlung zu bewegen.
- **Unbroken** (`end_unbroken`) — Du hast gelernt weiterzuarbeiten, wenn andere längst nur noch versuchen würden durchzuhalten.
- **Redline** (`force_redline`) — Wenn du einmal Druck aufgebaut hast, fühlt sich jeder weitere Schritt natürlicher an als Rückzug.
- **Living Network** (`mach_living_network`) — Deine Systeme beginnen miteinander zu arbeiten, bevor du jeden Schritt einzeln anweisen musst.
- **Last Light** (`med_last_light`) — In den schlimmsten Sekunden wird deine Ruhe für andere zu Zeit.
- **Combat Parkour** (`mob_combat_parkour`) — Kampf und Bewegung sind für dich keine getrennten Zustände mehr.
- **Dead Signal** (`net_dead_signal`) — Du weißt inzwischen, wie ein System ausfallen muss, damit sein Schweigen natürlich wirkt.
- **Threat Forecast** (`perc_threat_forecast`) — Manche Gefahren erkennst du inzwischen im Ablauf, bevor sie offen sichtbar werden.
- **Focus Lock** (`prec_focus_lock`) — Je länger du ein Ziel liest, desto weniger bleibt am entscheidenden Moment dem Zufall überlassen.
- **Bastion Instinct** (`prot_bastion_instinct`) — Schutz ist kein einzelner Handgriff mehr. Er ist zu deinem Raumgefühl geworden.
- **Resonance Cascade** (`res_cascade`) — Du erkennst Verbindungen zwischen Resonanzen, die früher wie einzelne Ereignisse wirkten.
- **Personal Gravity** (`soc_gravity`) — Menschen beginnen deine Haltung mitzudenken, noch bevor du sie ausdrücklich formulierst.
- **Vanish Window** (`stealth_vanish`) — Ein kurzer Moment ohne Augen auf dir reicht inzwischen, um aus einer Verfolgung ein Rätsel zu machen.
- **Last Exit** (`surv_last_exit`) — Wenn eine Lage kippt, siehst du oft noch einen Weg, bevor andere überhaupt akzeptieren, dass sie fliehen müssen.
- **Gear Whisper** (`tech_gear_whisper`) — Mechanik wirkt auf dich immer weniger wie ein Rätsel und immer mehr wie eine Sprache.
- **Machine Communion** (`hyb_machine_communion`) [HYBRID] — Maschinen wirken nicht lebendig. Aber ihr Zustand ist für dich auch nicht mehr stumm.
