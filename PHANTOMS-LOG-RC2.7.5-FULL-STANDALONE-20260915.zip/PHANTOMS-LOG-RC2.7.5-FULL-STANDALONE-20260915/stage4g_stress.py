#!/usr/bin/env python3
from validation.stage4g import Stage4GClosureHarness, REQUIRED_INVARIANTS

checks = 0
required_count = len(REQUIRED_INVARIANTS)
for _ in range(1_000):
    report = Stage4GClosureHarness().run()
    assert report.passed
    checks += 1
    for case in report.cases:
        assert case.passed
        checks += 1
    assert not report.missing_invariants
    checks += 1
    assert not report.missing_pair_coverage
    checks += 1
    assert not report.missing_chain_coverage
    checks += 1
    assert len(report.covered_invariants) == required_count
    checks += 1
    assert len(report.pair_coverage) == required_count
    checks += 1

assert checks == 20_000, checks
print(f"STAGE4G_STRESS={checks}/{checks} PASS")
