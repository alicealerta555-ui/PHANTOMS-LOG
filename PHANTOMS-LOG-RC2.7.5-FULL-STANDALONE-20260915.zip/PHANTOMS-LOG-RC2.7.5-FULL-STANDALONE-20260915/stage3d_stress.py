#!/usr/bin/env python3
from runtime.stage3a.kernel import StateStore
from runtime.stage3a.integration import RuntimeAuthorityBridge
from runtime.stage3a.kernel import CommitKernel
from runtime.stage3d.epistemic import (
    PPM, DistortionPolicy, DistortionVariant, EpistemicEngine,
    InformationGraph, InformationRoute, PropagationModifiers, Stage3DError,
)


def build(seed: int):
    graph = InformationGraph((
        InformationRoute("AB", "A", "B", 7, reliability_ppm=950_000),
        InformationRoute("BC", "B", "C", 11, reliability_ppm=900_000),
        InformationRoute("AC", "A", "C", 30, reliability_ppm=990_000),
    ), hub_flow_ppm={"B": 1_200_000})
    store = StateStore()
    kernel = CommitKernel(store, world_seed=seed)
    engine = EpistemicEngine(RuntimeAuthorityBridge(kernel), run_seed=seed, graph=graph)
    return store, kernel, engine, graph


def main():
    checks = 0
    # 5,000 deterministic geography checks.
    _, _, _, graph = build(1)
    for i in range(5000):
        mods = PropagationModifiers(
            traffic_ppm={"AB": PPM + (i % 4) * 100_000},
            season_delay_ppm={"BC": PPM + (i % 3) * 50_000},
            event_delay_ppm={"AB": PPM + (i % 5) * 25_000},
        )
        p1 = graph.plan("A", "C", depart_at=i % 100, modifiers=mods)
        p2 = graph.plan("A", "C", depart_at=i % 100, modifiers=mods)
        assert p1 == p2 and p1.arrive_at >= p1.depart_at
        checks += 1

    # 5,000 no-early-delivery / causal-source checks, using fresh bounded stores.
    for i in range(5000):
        store, _, engine, _ = build(100 + i)
        engine.record_actor_observation(
            actor_id="src", fact_key="f", value=i % 2, event_id="OBS",
            source_id="sensor", location="A", world_time=0,
        )
        q = engine.queue_actor_relay(
            message_id="M", source_actor_id="src", target_actor_id="dst", fact_key="f",
            source_location="A", target_location="C", depart_at=1,
        )
        early = engine.deliver_due(world_time=q.arrival_at - 1, event_id="EARLY")
        assert early.reasons == ("NO_INFORMATION_DUE",)
        assert "dst" not in store.actor_knowledge
        engine.deliver_due(world_time=q.arrival_at, event_id="DUE")
        assert store.actor_knowledge["dst"]["f"]["value"] == i % 2
        checks += 1

    # 5,000 deterministic distortion / no-truth-write checks.
    policy = DistortionPolicy((DistortionVariant("flip", 500_000, "DISTORTED"),))
    for i in range(5000):
        def one():
            store, _, engine, _ = build(9000 + i)
            engine.record_actor_observation(
                actor_id="src", fact_key="f", value="ORIGINAL", event_id="OBS",
                source_id="eyes", location="A", world_time=0,
            )
            q = engine.queue_actor_relay(
                message_id="M", source_actor_id="src", target_actor_id="dst", fact_key="f",
                source_location="A", target_location="B", depart_at=0, distortion_policy=policy,
            )
            engine.deliver_due(world_time=q.arrival_at, event_id="DUE")
            return store.actor_knowledge["dst"]["f"], dict(store.world_truth)
        a, truth_a = one()
        b, truth_b = one()
        assert a == b and truth_a == truth_b == {}
        checks += 1

    # 5,000 fail-closed route checks.
    for i in range(5000):
        closed = frozenset({"AB", "AC"})
        try:
            graph.plan("A", "C", depart_at=i, modifiers=PropagationModifiers(closed_edges=closed))
        except Stage3DError as exc:
            assert str(exc) == "NO_INFORMATION_ROUTE"
        else:
            raise AssertionError("closed graph unexpectedly routed")
        checks += 1

    print(f"STAGE3D_STRESS={checks}/{checks}=PASS")


if __name__ == "__main__":
    main()
