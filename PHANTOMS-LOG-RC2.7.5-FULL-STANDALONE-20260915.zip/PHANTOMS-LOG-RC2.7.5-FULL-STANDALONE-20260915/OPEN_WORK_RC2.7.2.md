# PHANTOMS-LOG RC2.7.2 — Open Work

Current package: RC2.7.2 Lifetime + Class Tutorial Working Master
Base authority: RC2.7.0 FULL Master

## Open design / implementation items

1. **Playable biological inheritance** — Stage 6 heredity exists for creature lines, but playable human/hybrid germline traits need a canonical catalogue and rules before they may affect a player character. Do not invent placeholder genes.
2. **Generational succession** — lifetime/estate foundations exist, but full descendant/succession play beyond the current inheritance trail remains future design work.
3. **Tutorial breadth** — current onboarding demonstrates the two selected Level-1 class talents. Later class/path abilities should only gain tutorial scenarios when those abilities become player-selected in a concrete onboarding/progression context; do not auto-unlock or reward them.
4. **Regression rule** — after every code change, re-run the complete benchmark/regression gates before packaging or promotion.
5. **Promotion naming** — do not call a future build FULL Master unless all current project content/functions/integrations/relevant documents are present and validated. Do not call it Standalone unless continuation/design context is also complete enough to continue without older chats or side archives.

## Current non-open items

- two Level-1 class talents: implemented and validated
- +1 talent per later level: contract enforced and audited
- class-specific selected-talent tutorial: implemented and validated
- tutorial reward isolation: implemented and validated
- normal intro preserved after tutorial: regression-tested
- RC2.7.1 life-history start: retained and audited
