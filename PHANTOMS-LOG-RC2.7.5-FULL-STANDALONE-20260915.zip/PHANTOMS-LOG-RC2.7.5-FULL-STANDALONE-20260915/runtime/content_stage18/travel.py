
import hashlib, math
def travel_minutes(route, transport, delay_min=0):
    if transport["id"] not in route.get("allowed",[]): return None
    speed=max(1,float(transport["speed_kph"]))
    return int(math.ceil(float(route["distance_km"])/speed*60.0))+max(0,int(delay_min))
def cargo_allowed(transport, cargo_mass_kg):
    return float(cargo_mass_kg)<=float(transport["cargo_kg"])
def travel_proposal(route, transport, actor_ids, cargo_mass_kg, causal_event_id):
    if transport["id"] not in route.get("allowed",[]) or not cargo_allowed(transport,cargo_mass_kg): return None
    return {"kind":"TRAVEL_PROPOSAL","route_id":route["id"],"transport_id":transport["id"],
            "actor_ids":list(actor_ids),"cargo_mass_kg":float(cargo_mass_kg),
            "duration_min":travel_minutes(route,transport),"causal_event_id":causal_event_id,"authority_required":True}
def hazard_candidate(route, hazards, seed):
    risk=max(0,min(10000,int(route.get("hazard_bp",0))))
    h=int(hashlib.sha256(("gate:"+str(seed)).encode()).hexdigest()[:16],16)%10000
    if h>=risk:return None
    total=sum(max(0,int(x["weight"])) for x in hazards)
    pick=int(hashlib.sha256(("pick:"+str(seed)).encode()).hexdigest()[:16],16)%total
    n=0
    for x in hazards:
        n+=max(0,int(x["weight"]))
        if pick<n:
            return {"kind":"ROUTE_HAZARD_CANDIDATE","route_id":route["id"],"hazard_id":x["id"],
                    "effects":list(x["effects"]),"authority_required":True}
def cargo_record(carrier,owner,items,mass,source,destination,loaded_at,provenance):
    return {"carrier_id":carrier,"owner_id":owner,"items":dict(items),"mass_kg":float(mass),
            "source_location_id":source,"destination_location_id":destination,"loaded_at":int(loaded_at),
            "provenance":list(provenance)}
def validate_cargo(r):
    return bool(r.get("carrier_id")) and bool(r.get("owner_id")) and bool(r.get("source_location_id")) and bool(r.get("destination_location_id")) and isinstance(r.get("provenance"),list)
