
def clamp(v,a,b): return max(a,min(b,v))

def language_progress(current, exposure_minutes, teaching_quality=50, learner_factor=50):
    if int(exposure_minutes)<=0:
        return clamp(int(current),0,100)
    tq=clamp(int(teaching_quality),0,100)
    lf=clamp(int(learner_factor),0,100)
    gain=max(0, int(exposure_minutes)//120)
    gain=gain*(tq+lf)//100
    return clamp(int(current)+gain,0,100)

def language_level(value):
    v=clamp(int(value),0,100)
    if v<10: return "LANG_NONE"
    if v<30: return "LANG_BASIC"
    if v<60: return "LANG_CONVERSATIONAL"
    if v<85: return "LANG_FLUENT"
    return "LANG_NATIVE_LIKE"

def custom_pressure(custom_weight, familiarity, group_expectation):
    raw=int(custom_weight)+int(group_expectation)-int(familiarity)//2
    return clamp(raw,0,100)

def cultural_drift_candidate(actor_id, source_culture_id, target_culture_id, contact_mode, elapsed_days, current_identity_strength, causal_event_id):
    if not actor_id or not source_culture_id or not target_culture_id:
        return None
    if source_culture_id==target_culture_id or int(elapsed_days)<=0:
        return None
    drift=max(0,int(contact_mode.get("drift_rate",0)))*int(elapsed_days)//30
    return {
        "kind":"CULTURAL_DRIFT_CANDIDATE",
        "actor_id":actor_id,
        "source_culture_id":source_culture_id,
        "target_culture_id":target_culture_id,
        "proposed_drift":clamp(drift,0,100),
        "current_identity_strength":clamp(int(current_identity_strength),0,100),
        "auto_identity_overwrite":False,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def identity_change_proposal(actor_id, culture_id, current_strength, delta, reason, causal_event_id):
    if not actor_id or not culture_id or not reason:
        return None
    return {
        "kind":"CULTURAL_IDENTITY_CHANGE_PROPOSAL",
        "actor_id":actor_id,
        "culture_id":culture_id,
        "current_strength":clamp(int(current_strength),0,100),
        "proposed_strength":clamp(int(current_strength)+int(delta),0,100),
        "reason":reason,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def cultural_memory_record(culture_id,memory_id,narrative,sources,reinforced_at):
    return {
        "culture_id":culture_id,
        "memory_id":memory_id,
        "narrative":narrative,
        "sources":list(sources or []),
        "reinforced_at":int(reinforced_at)
    }

def validate_cultural_memory(record):
    return bool(record.get("culture_id")) and bool(record.get("memory_id")) and bool(record.get("narrative")) and len(record.get("sources",[]))>0
