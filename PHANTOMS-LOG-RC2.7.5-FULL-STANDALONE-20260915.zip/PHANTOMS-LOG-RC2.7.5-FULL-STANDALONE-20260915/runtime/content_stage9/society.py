
def minute_of_day(t): return int(t)%1440
def is_open(windows,t):
    m=minute_of_day(t); return any(int(a)<=m<int(b) for a,b in windows)
def access_allowed(inst,area,role):
    if area in inst.get("public",[]): return True
    if area not in inst.get("restricted",[]): return False
    # Restricted areas require the institution's privileged operational role.
    privileged={"medicine_store":"medic","stockroom":"merchant","guild_archive":"guild_member","secured_store":"quartermaster","bond_room":"broker","pump_core":"engineer","operations":"warden"}
    return privileged.get(area)==role
def routine_activity(template,t):
    m=minute_of_day(t)
    for a,b,name in template.get("segments",[]):
        if int(a)<=m<int(b): return name
def plan_supply_transfer(source,requested):
    return {k:q for k,v in requested.items() if (q:=max(0,min(int(v),int(source.get(k,0)))))}
def apply_transfer_projection(source,dest,moved):
    a,b=dict(source),dict(dest)
    for k,v in moved.items():
        if v<0 or v>a.get(k,0): raise ValueError("invalid transfer")
        a[k]-=v; b[k]=b.get(k,0)+v
    return a,b
def validate_social_memory(r):
    req={"subject_id","claim","source_actor_id","observed_at","received_at","channel","confidence"}
    return req.issubset(r) and bool(r["source_actor_id"]) and int(r["received_at"])>=int(r["observed_at"])
def relationship_delta(current,delta):
    out=dict(current)
    for k,v in delta.items(): out[k]=max(-100,min(100,int(out.get(k,0))+int(v)))
    return out
