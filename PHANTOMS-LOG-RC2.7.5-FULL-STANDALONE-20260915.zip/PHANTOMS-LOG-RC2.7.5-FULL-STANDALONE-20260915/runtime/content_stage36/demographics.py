
def clamp(v,a,b): return max(a,min(b,v))

def age_years(born_at_minute, now_minute, days_per_year=365):
    if int(now_minute) < int(born_at_minute):
        return 0
    minutes_per_year=max(1,int(days_per_year))*1440
    return max(0,(int(now_minute)-int(born_at_minute))//minutes_per_year)

def cohort_for_age(age):
    a=max(0,int(age))
    if a<=2: return "COHORT_INFANT"
    if a<=12: return "COHORT_CHILD"
    if a<=17: return "COHORT_YOUTH"
    if a<=59: return "COHORT_ADULT"
    return "COHORT_ELDER"

def cohort_projection(count,birth_rate_bp,mortality_rate_bp,migration_in_bp,migration_out_bp,elapsed_days):
    c=max(0,int(count))
    days=max(0,float(elapsed_days))
    births=int(round(c*clamp(int(birth_rate_bp),0,10000)/10000.0*days/365.0))
    deaths=int(round(c*clamp(int(mortality_rate_bp),0,10000)/10000.0*days/365.0))
    incoming=int(round(c*clamp(int(migration_in_bp),0,10000)/10000.0*days/365.0))
    outgoing=int(round(c*clamp(int(migration_out_bp),0,10000)/10000.0*days/365.0))
    return max(0,c+births-deaths+incoming-outgoing)

def birth_candidate(new_actor_id,birth_parent_ids,household_id,location_id,born_at,causal_event_id):
    if not new_actor_id or not birth_parent_ids or not location_id:
        return None
    return {
        "kind":"BIRTH_ACTOR_CREATION_CANDIDATE",
        "new_actor_id":new_actor_id,
        "birth_parent_ids":list(birth_parent_ids),
        "household_id":household_id,
        "location_id":location_id,
        "born_at":int(born_at),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def mortality_pressure_candidate(region_id,cohort_id,rate_bp,cause_ref,elapsed_days,causal_event_id):
    if not region_id or not cohort_id or int(elapsed_days)<=0:
        return None
    return {
        "kind":"AGGREGATE_MORTALITY_PRESSURE_CANDIDATE",
        "region_id":region_id,
        "cohort_id":cohort_id,
        "rate_bp":clamp(int(rate_bp),0,10000),
        "cause_ref":cause_ref,
        "elapsed_days":int(elapsed_days),
        "affects_named_actors_directly":False,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def death_record(actor_id,death_event_id,died_at,cause_ref):
    if not actor_id or not death_event_id:
        return None
    return {
        "actor_id":actor_id,
        "death_event_id":death_event_id,
        "died_at":int(died_at),
        "cause_ref":cause_ref,
        "authoritative_event_required":True
    }

def generation_snapshot(generation_id,start_time,end_time,cohort_snapshot_ids):
    if not generation_id or int(end_time)<int(start_time):
        return None
    return {
        "generation_id":generation_id,
        "start_time":int(start_time),
        "end_time":int(end_time),
        "cohort_snapshot_ids":list(cohort_snapshot_ids or []),
        "historical_provenance_required":True
    }
