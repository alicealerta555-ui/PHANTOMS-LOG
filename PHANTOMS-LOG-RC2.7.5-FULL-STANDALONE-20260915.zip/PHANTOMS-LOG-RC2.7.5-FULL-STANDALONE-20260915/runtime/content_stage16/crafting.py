
def can_craft(recipe, inventory, tools, skill_value):
    for item,qty in recipe.get("inputs",{}).items():
        if int(inventory.get(item,0))<int(qty): return False
    if not set(recipe.get("tools",[])).issubset(set(tools)): return False
    return int(skill_value)>=int(recipe.get("difficulty",0))
def craft_proposal(recipe, actor_id, location_id, causal_event_id, input_sources=None):
    return {"kind":"CRAFT_PROPOSAL","recipe_id":recipe["id"],"actor_id":actor_id,"location_id":location_id,
            "consume":dict(recipe["inputs"]),"produce":dict(recipe["output"]),"duration_min":int(recipe["duration_min"]),
            "input_sources":list(input_sources or []),"causal_event_id":causal_event_id,"authority_required":True}
def repair_amount(current_condition, max_condition, requested_restore, profile):
    missing=max(0,int(max_condition)-int(current_condition))
    return max(0,min(missing,int(requested_restore),int(profile["max_restore"])))
def repair_proposal(profile, item_id, actor_id, current_condition, max_condition, requested_restore, causal_event_id):
    amount=repair_amount(current_condition,max_condition,requested_restore,profile)
    return {"kind":"REPAIR_PROPOSAL","profile_id":profile["id"],"item_id":item_id,"actor_id":actor_id,
            "restore":amount,"duration_min":int(profile["duration_min"]),"causal_event_id":causal_event_id,"authority_required":True}
def provenance_record(output_id, process_id, input_sources, actor_id, location_id, world_time):
    return {"output_id":output_id,"recipe_or_repair_id":process_id,"input_sources":list(input_sources),
            "crafted_or_repaired_by":actor_id,"location_id":location_id,"world_time":int(world_time)}
def validate_provenance(r):
    req={"output_id","recipe_or_repair_id","input_sources","crafted_or_repaired_by","location_id","world_time"}
    return req.issubset(r) and bool(r["crafted_or_repaired_by"]) and bool(r["location_id"])
