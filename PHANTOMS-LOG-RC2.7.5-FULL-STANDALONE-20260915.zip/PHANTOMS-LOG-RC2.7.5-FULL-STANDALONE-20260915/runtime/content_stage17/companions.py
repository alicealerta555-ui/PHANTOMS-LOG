
def clamp(v,a,b): return max(a,min(b,v))
def recruitment_offer(candidate,recruiter,role,terms,offered_at,expires_at):
    return {"kind":"RECRUITMENT_OFFER","candidate_actor_id":candidate,"recruiter_actor_id":recruiter,"role_id":role,
            "terms":list(terms or []),"offered_at":int(offered_at),"expires_at":int(expires_at),"status":"OFFERED"}
def recruitment_decision(offer, candidate_actor_id, decision, now):
    if offer.get("status")!="OFFERED" or candidate_actor_id!=offer.get("candidate_actor_id") or int(now)>int(offer["expires_at"]):
        return None
    if decision not in ("ACCEPT","REFUSE"): return None
    out=dict(offer); out["status"]="ACCEPTED" if decision=="ACCEPT" else "REFUSED"; out["decided_at"]=int(now)
    out["authority_required"]=True
    return out
def loyalty_delta(current, delta):
    out=dict(current)
    for k,v in delta.items(): out[k]=clamp(int(out.get(k,0))+int(v),-100,100)
    return out
def order_request(issuer, companion, action, causal_event_id):
    return {"kind":"COMPANION_ORDER_REQUEST","issuer_actor_id":issuer,"companion_actor_id":companion,
            "requested_action":action,"causal_event_id":causal_event_id,"requires_actor_decision":True}
def desertion_pressure(loyalty, unpaid=False, unsafe=False, betrayal=False):
    p=0
    p += max(0,-int(loyalty.get("trust",0)))//2
    p += max(0,-int(loyalty.get("satisfaction",0)))//2
    p += max(0,int(loyalty.get("fear",0)))//3
    if unpaid:p+=25
    if unsafe:p+=20
    if betrayal:p+=45
    return clamp(p,0,100)
def departure_proposal(actor_id, reason, pressure, causal_event_id):
    if int(pressure)<65:return None
    return {"kind":"CREW_DEPARTURE_PROPOSAL","actor_id":actor_id,"reason":reason,"pressure":int(pressure),
            "causal_event_id":causal_event_id,"authority_required":True}
