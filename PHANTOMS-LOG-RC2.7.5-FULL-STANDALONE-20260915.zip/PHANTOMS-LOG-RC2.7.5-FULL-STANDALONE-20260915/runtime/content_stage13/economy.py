
def clamp(v,a,b): return max(a,min(b,v))
def scarcity_multiplier_bp(stock, target):
    if target<=0: return 10000
    ratio=clamp(float(stock)/float(target),0.0,1.0)
    if ratio<=0.10:return 18000
    if ratio<=0.30:return 14000
    if ratio<=0.70:return 11000
    return 10000
def quote_price(base_price, stock, target_stock, risk_bp=0, markup_bp=0, reputation_bp=0):
    scarcity=scarcity_multiplier_bp(stock,target_stock)
    modifier=10000+int(risk_bp)+int(markup_bp)+clamp(int(reputation_bp),-2500,2500)
    return max(1,(int(base_price)*scarcity*modifier + 50_000_000)//100_000_000)
def make_trade_proposal(seller,buyer,market,lines,currency,quoted_at,prices,stock):
    normalized=[]; total=0
    for item,qty in lines:
        q=max(0,min(int(qty),int(stock.get(item,0))))
        if q:
            unit=int(prices[item]); normalized.append({"item_id":item,"qty":q,"unit_price":unit}); total+=q*unit
    return {"kind":"TRADE_PROPOSAL","seller_id":seller,"buyer_id":buyer,"market_id":market,"lines":normalized,
            "currency_id":currency,"total":total,"quoted_at":int(quoted_at),"accepted":False,"authority_required":True}
def accept_trade(proposal, actor_id):
    if actor_id!=proposal.get("buyer_id"): return None
    out=dict(proposal); out["accepted"]=True; return out
def service_proposal(service, provider, customer, now):
    return {"kind":"SERVICE_PROPOSAL","service_id":service["id"],"provider_id":provider,"customer_id":customer,
            "price":int(service["base_price"]),"duration_min":int(service["duration_min"]),"requires":list(service.get("requires",[])),
            "effect":service["effect"],"quoted_at":int(now),"authority_required":True}
