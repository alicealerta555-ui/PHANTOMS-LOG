from .character_creation import gameplay_context, skill_value, stat_value


def action_context(character, action_text):
    base=gameplay_context(character)
    if base is None: return {"ok":False,"reason":"CHARACTER_CREATION_INCOMPLETE_OR_LEGACY_SCHEMA"}
    if not str(action_text or "").strip(): return {"ok":False,"reason":"EMPTY_ACTION"}
    return {"ok":True,"action_text":str(action_text),"player_uuid":base["player_uuid"],"run_uuid":base["run_uuid"],
            "character_id":base["character_id"],"location_id":base["location_id"],"stats":base["stats"],"skills":base["skills"],
            "talents":base["talents"],"expertises":base["expertises"],"inventory_instance_ids":base["inventory_instance_ids"]}


def check_inputs(character, skill_id=None, stat_id=None):
    return {"skill_value":skill_value(character,skill_id) if skill_id else None,
            "stat_value":stat_value(character,stat_id) if stat_id else None}
