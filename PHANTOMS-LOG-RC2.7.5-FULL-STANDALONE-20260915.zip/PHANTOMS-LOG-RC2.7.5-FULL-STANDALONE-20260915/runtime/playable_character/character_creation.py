from copy import deepcopy
import uuid

from runtime.full_version.capability_catalog import SCHEMA_ID, STATS, SKILLS, TALENTS

STAT_MIN=1
STAT_MAX=10
SKILL_MIN=0
SKILL_MAX=10


def _clamp(v,a,b):
    return max(a,min(b,int(v)))


def validate_character_input(data):
    errors=[]
    if not str(data.get("name","")).strip(): errors.append("name_required")
    try: age=int(data.get("age",0) or 0)
    except (TypeError,ValueError): age=0
    if age<18: errors.append("age_invalid")
    stats=data.get("stats")
    if not isinstance(stats,dict) or set(stats)!=set(STATS):
        errors.append("stats_require_canonical_set")
    else:
        for key,val in stats.items():
            if type(val) is not int or not STAT_MIN<=val<=STAT_MAX: errors.append(f"stat_out_of_bounds:{key}")
    skills=data.get("skills")
    if not isinstance(skills,dict) or set(skills)!=set(SKILLS):
        errors.append("skills_require_canonical_set")
    else:
        for key,val in skills.items():
            if type(val) is not int or not SKILL_MIN<=val<=SKILL_MAX: errors.append(f"skill_out_of_bounds:{key}")
    talents=data.get("talents")
    if not isinstance(talents,list) or any(t not in TALENTS for t in talents): errors.append("talents_invalid")
    if data.get("expertises") not in (None,{},[]): errors.append("expertises_cannot_be_assigned_at_creation")
    if not str(data.get("location_id","")).strip(): errors.append("location_required")
    return {"ok":not errors,"errors":errors}


def new_identity(player_uuid=None, run_uuid=None):
    return {"player_uuid":player_uuid or str(uuid.uuid4()),"run_uuid":run_uuid or str(uuid.uuid4())}


def inventory_instances(items, run_uuid):
    result=[]; seen_unique=set()
    for idx,item in enumerate(items or []):
        item=dict(item)
        if item.get("unique"):
            uid=item.get("unique_id") or item.get("item_id")
            if uid in seen_unique: raise ValueError("duplicate_unique_item")
            seen_unique.add(uid)
        item.setdefault("instance_id",f"{run_uuid}:item:{idx+1}"); item.setdefault("quantity",1); result.append(item)
    return result


def knowledge_records(records):
    out=[]
    for rec in records or []:
        rec=dict(rec)
        if not rec.get("fact_id") or not rec.get("source"): raise ValueError("knowledge_requires_fact_and_source")
        rec.setdefault("confidence",100); out.append(rec)
    return out


def create_character(data, player_uuid=None, run_uuid=None):
    check=validate_character_input(data)
    if not check["ok"]: return {"ok":False,"errors":check["errors"]}
    ids=new_identity(player_uuid,run_uuid)
    state={
        "schema":SCHEMA_ID,"player_uuid":ids["player_uuid"],"run_uuid":ids["run_uuid"],
        "character_id":f'{ids["run_uuid"]}:player',"name":str(data["name"]),"sex":data.get("sex"),
        "age":int(data["age"]),"origin":data.get("origin"),"role":data.get("role"),
        "stats":{k:_clamp(v,STAT_MIN,STAT_MAX) for k,v in data["stats"].items()},
        "skills":{k:_clamp(v,SKILL_MIN,SKILL_MAX) for k,v in data["skills"].items()},
        "talents":list(dict.fromkeys(data.get("talents") or [])),"expertises":{},
        "inventory":inventory_instances(data.get("inventory") or [],ids["run_uuid"]),
        "knowledge":knowledge_records(data.get("knowledge") or []),"location_id":data["location_id"],
        "status":{"alive":True,"condition":"ACTIVE","character_creation_complete":True},
    }
    return {"ok":True,"proposal":{"kind":"CREATE_PLAYER_CHARACTER","state":state,"authority_required":True,"commit_required":True}}


def committed_character(proposal, commit_id):
    if not proposal or proposal.get("kind")!="CREATE_PLAYER_CHARACTER": return None
    if not proposal.get("authority_required") or not proposal.get("commit_required"): return None
    state=deepcopy(proposal["state"]); state["creation_commit_id"]=commit_id; return state


def skill_value(character, skill_id): return int((character.get("skills") or {}).get(skill_id,0))
def stat_value(character, stat_id): return int((character.get("stats") or {}).get(stat_id,0))


def gameplay_context(character):
    if not character or character.get("schema")!=SCHEMA_ID or not character.get("status",{}).get("character_creation_complete"): return None
    return {"player_uuid":character["player_uuid"],"run_uuid":character["run_uuid"],"character_id":character["character_id"],
            "location_id":character["location_id"],"stats":dict(character.get("stats") or {}),"skills":dict(character.get("skills") or {}),
            "talents":list(character.get("talents") or []),"expertises":dict(character.get("expertises") or {}),
            "inventory_instance_ids":[x["instance_id"] for x in character.get("inventory") or []]}
