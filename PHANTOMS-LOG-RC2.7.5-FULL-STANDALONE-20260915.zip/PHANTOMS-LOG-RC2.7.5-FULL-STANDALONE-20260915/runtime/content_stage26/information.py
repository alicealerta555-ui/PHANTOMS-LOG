
def clamp(v,a,b): return max(a,min(b,v))

def rumor_record(claim, source_actor_id, channel_id, created_at, confidence, event_id=None):
    return {
        "kind":"RUMOR",
        "claim":claim,
        "source_actor_id":source_actor_id,
        "channel_id":channel_id,
        "created_at":int(created_at),
        "confidence":clamp(int(confidence),0,100),
        "event_id":event_id
    }

def valid_rumor(r):
    return bool(r.get("claim")) and bool(r.get("source_actor_id")) and bool(r.get("channel_id")) and 0 <= int(r.get("confidence",0)) <= 100

def transmit_information(record, channel, sender_id, receiver_id, sent_at):
    if not valid_rumor(record) and record.get("kind")=="RUMOR":
        return None
    return {
        "kind":"INFORMATION_TRANSFER_PROPOSAL",
        "record":dict(record),
        "channel_id":channel["id"],
        "sender_actor_id":sender_id,
        "receiver_actor_id":receiver_id,
        "sent_at":int(sent_at),
        "arrives_at":int(sent_at)+int(channel.get("latency_min",0)),
        "authority_required":True
    }

def opinion_delta(current, dimension, delta):
    bounds={
        "trust":(-100,100),"fear":(0,100),"hostility":(-100,100),
        "support":(-100,100),"familiarity":(0,100)
    }
    lo,hi=bounds[dimension]
    out=dict(current)
    out[dimension]=clamp(int(out.get(dimension,0))+int(delta),lo,hi)
    return out

def propaganda_influence(effect_def, repetitions=1, resistance_bp=0):
    reps=max(0,int(repetitions))
    resistance=clamp(int(resistance_bp),0,10000)
    base=int(effect_def["max_delta"])
    # Diminishing returns: repetition raises familiarity/reach more than belief pressure.
    effective=min(base, (base * min(reps,3) // 3) if reps else 0)
    effective=effective*(10000-resistance)//10000
    return {
        "dimension":effect_def["dimension"],
        "delta":effective,
        "truth_claimed":False,
        "auto_belief":False
    }

def counter_message_influence(current_confidence, strength):
    return clamp(int(current_confidence)-max(0,int(strength)),0,100)

def cultural_memory_record(memory_id, subject, narrative, sources, origin_time, last_reinforced, confidence):
    return {
        "memory_id":memory_id,
        "subject":subject,
        "narrative":narrative,
        "sources":list(sources or []),
        "origin_time":int(origin_time),
        "last_reinforced":int(last_reinforced),
        "confidence":clamp(int(confidence),0,100)
    }

def validate_cultural_memory(r):
    req=("memory_id","subject","narrative","sources","origin_time","last_reinforced","confidence")
    return all(k in r for k in req) and isinstance(r["sources"],list) and len(r["sources"])>0
