# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

"""Full-version historical Stage 6: reproduction, inheritance and drift.

Biology is deliberately separated from relationship, profession, desire and consent.
All persistent results travel through EffectProposal -> StateAuthority -> CommitKernel.
"""

from dataclasses import dataclass
from enum import Enum
from hashlib import sha256
import copy
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal, ValidationResult, Verdict
from runtime.stage3c.isolation import RunSession
from runtime.stage9.authority import AuthorityDecision, AuthorityStatus
from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType

STAGE6_RUNTIME_KEY = "__content_stage6_biology__"

class Stage6BiologyError(RuntimeError): pass

class TraitOrigin(str, Enum):
    GERMLINE = "GERMLINE"
    SOMATIC = "SOMATIC"

class CompatibilityStatus(str, Enum):
    ALLOWED = "ALLOWED"
    BLOCKED = "BLOCKED"
    UNKNOWN = "UNKNOWN"

class SpeciationStatus(str, Enum):
    NO = "NO"
    CANDIDATE = "CANDIDATE"
    STABLE_LINEAGE = "STABLE_LINEAGE"

@dataclass(frozen=True, slots=True)
class TraitState:
    value: Any
    origin: TraitOrigin
    latent: bool = False

@dataclass(frozen=True, slots=True)
class CompatibilityResult:
    status: CompatibilityStatus
    reason: str

@dataclass(frozen=True, slots=True)
class InheritanceResult:
    record_id: str
    parent_lineage_a: str
    parent_lineage_b: str
    compatibility_status: CompatibilityStatus
    inherited_traits: Mapping[str, Any]
    latent_traits: Mapping[str, Any]
    cause_ref: str

@dataclass(frozen=True, slots=True)
class SpeciationEvidence:
    stable_generations: int
    reproductive_isolation_ppm: int
    heritable_divergence_ppm: int
    population_continuity_generations: int

@dataclass(frozen=True, slots=True)
class DriftResult:
    record_id: str
    lineage_id: str
    generation: int
    trait_deltas_ppm: Mapping[str, int]
    pressures: Mapping[str, int]
    speciation_status: SpeciationStatus
    cause_ref: str

class Stage6BiologyCatalog:
    def __init__(self, raw: Mapping[str, Any]):
        self.raw=copy.deepcopy(dict(raw)); self.validate()
        self._compat={}
        for r in self.raw["compatibility_rules"]:
            key=tuple(sorted((r["lineage_a"],r["lineage_b"])))
            self._compat[key]=CompatibilityResult(CompatibilityStatus(r["status"]),r["reason"])
    @classmethod
    def load(cls,path:Path)->"Stage6BiologyCatalog":
        return cls(json.loads(Path(path).read_text(encoding="utf-8")))
    def validate(self)->None:
        if self.raw.get("schema")!="PH4NT0M5-L0G_STAGE6_BIOLOGY_V1": raise Stage6BiologyError("STAGE6_SCHEMA_INVALID")
        if not isinstance(self.raw.get("lineages"),list) or not self.raw["lineages"]: raise Stage6BiologyError("STAGE6_LINEAGES_REQUIRED")
        seen=set()
        for r in self.raw.get("compatibility_rules",[]):
            key=tuple(sorted((r.get("lineage_a"),r.get("lineage_b"))))
            if None in key or key in seen: raise Stage6BiologyError("STAGE6_COMPATIBILITY_RULE_INVALID")
            seen.add(key); CompatibilityStatus(r.get("status"))
        spec=self.raw.get("speciation",{})
        for k in ("minimum_stable_generations","minimum_reproductive_isolation_ppm","minimum_heritable_divergence_ppm","minimum_population_continuity_generations"):
            if not isinstance(spec.get(k),int) or spec[k]<0: raise Stage6BiologyError(f"STAGE6_SPECIATION_RULE_INVALID:{k}")
    @property
    def max_drift_ppm(self)->int: return int(self.raw["drift"]["max_trait_delta_ppm_per_generation"])
    def compatibility(self,a:str,b:str)->CompatibilityResult:
        return self._compat.get(tuple(sorted((a,b))), CompatibilityResult(CompatibilityStatus.UNKNOWN,"no canonical compatibility evidence"))

class Stage6BiologyEngine:
    def __init__(self, session:RunSession, catalog:Stage6BiologyCatalog): self.session=session; self.catalog=catalog
    def _pick(self,event_id:str,trait_id:str,n:int)->int:
        if n<=0: raise Stage6BiologyError("PICK_EMPTY")
        material=f"{self.session.run_seed}|{event_id}|{trait_id}".encode(); return int.from_bytes(sha256(material).digest()[:8],"big")%n
    def resolve_inheritance(self, *, record_id:str, event_id:str, parent_lineage_a:str, parent_lineage_b:str,
                            parent_a_traits:Mapping[str,TraitState], parent_b_traits:Mapping[str,TraitState], cause_ref:str)->InheritanceResult:
        comp=self.catalog.compatibility(parent_lineage_a,parent_lineage_b)
        if comp.status==CompatibilityStatus.BLOCKED: raise Stage6BiologyError("REPRODUCTION_COMPATIBILITY_BLOCKED")
        if comp.status==CompatibilityStatus.UNKNOWN: raise Stage6BiologyError("REPRODUCTION_COMPATIBILITY_UNKNOWN")
        inherited={}; latent={}
        for trait_id in sorted(set(parent_a_traits)|set(parent_b_traits)):
            candidates=[]
            for src in (parent_a_traits.get(trait_id),parent_b_traits.get(trait_id)):
                if src is not None and src.origin==TraitOrigin.GERMLINE: candidates.append(src)
            if not candidates: continue  # somatic-only changes never auto-inherit
            chosen=candidates[self._pick(event_id,trait_id,len(candidates))]
            if chosen.latent: latent[trait_id]=copy.deepcopy(chosen.value)
            else: inherited[trait_id]=copy.deepcopy(chosen.value)
            # Divergent germline alternative survives as latent instead of disappearing.
            if len(candidates)>1:
                other=candidates[(self._pick(event_id,trait_id,len(candidates))+1)%len(candidates)]
                if other.value!=chosen.value: latent.setdefault(trait_id,copy.deepcopy(other.value))
        return InheritanceResult(record_id,parent_lineage_a,parent_lineage_b,comp.status,inherited,latent,cause_ref)

    def assess_speciation(self,e:SpeciationEvidence)->SpeciationStatus:
        s=self.catalog.raw["speciation"]
        stable=e.stable_generations>=s["minimum_stable_generations"]
        isolation=e.reproductive_isolation_ppm>=s["minimum_reproductive_isolation_ppm"]
        divergence=e.heritable_divergence_ppm>=s["minimum_heritable_divergence_ppm"]
        continuity=e.population_continuity_generations>=s["minimum_population_continuity_generations"]
        if stable and isolation and divergence and continuity: return SpeciationStatus.STABLE_LINEAGE
        candidate_count=sum((stable,isolation,divergence,continuity))
        return SpeciationStatus.CANDIDATE if candidate_count>=2 else SpeciationStatus.NO

    def simulate_drift(self, *, record_id:str, lineage_id:str, generation:int, pressures:Mapping[str,int], evidence:SpeciationEvidence, cause_ref:str)->DriftResult:
        if generation<0: raise Stage6BiologyError("GENERATION_INVALID")
        maxd=self.catalog.max_drift_ppm; deltas={}
        for trait_id,p in sorted(pressures.items()):
            if isinstance(p,bool) or not isinstance(p,int) or not -1_000_000<=p<=1_000_000: raise Stage6BiologyError("DRIFT_PRESSURE_INVALID")
            # deterministic bounded variation weighted by signed pressure
            raw=int.from_bytes(sha256(f"{self.session.run_seed}|{lineage_id}|{generation}|{trait_id}".encode()).digest()[:8],"big")
            noise=(raw%(2*maxd+1))-maxd
            directed=(p*maxd)//1_000_000
            deltas[trait_id]=max(-maxd,min(maxd,(noise//3)+directed))
        return DriftResult(record_id,lineage_id,generation,deltas,dict(pressures),self.assess_speciation(evidence),cause_ref)

    def inheritance_proposal(self,result:InheritanceResult,*,resolution_id:str,source_action_id:str,effect_id:str)->EffectProposal:
        return EffectProposal(effect_id=effect_id,run_uuid=self.session.identity.run_uuid,resolution_id=resolution_id,source_action_id=source_action_id,
            effect_type=EffectType.BIOLOGY_INHERITANCE_RECORD,target_ref=result.record_id,
            payload={"record_id":result.record_id,"parent_lineage_a":result.parent_lineage_a,"parent_lineage_b":result.parent_lineage_b,
                     "compatibility_status":result.compatibility_status.value,"inherited_traits":dict(result.inherited_traits),"latent_traits":dict(result.latent_traits),"cause_ref":result.cause_ref},
            authority_domain=AuthorityDomain.BIOLOGY,expected_state_revision=self.session.store.revision)
    def drift_proposal(self,result:DriftResult,*,resolution_id:str,source_action_id:str,effect_id:str)->EffectProposal:
        return EffectProposal(effect_id=effect_id,run_uuid=self.session.identity.run_uuid,resolution_id=resolution_id,source_action_id=source_action_id,
            effect_type=EffectType.BIOLOGY_DRIFT_RECORD,target_ref=result.record_id,
            payload={"record_id":result.record_id,"lineage_id":result.lineage_id,"generation":result.generation,"trait_deltas_ppm":dict(result.trait_deltas_ppm),
                     "pressures":dict(result.pressures),"speciation_status":result.speciation_status.value,"cause_ref":result.cause_ref},
            authority_domain=AuthorityDomain.BIOLOGY,expected_state_revision=self.session.store.revision)

class Stage6BiologyView:
    def __init__(self,session:RunSession): self.session=session
    def snapshot(self)->Mapping[str,Any]:
        raw=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,STAGE6_RUNTIME_KEY)
        if raw is None: return {"run_uuid":self.session.identity.run_uuid,"inheritance_records":{},"drift_records":{}}
        if not isinstance(raw,Mapping) or raw.get("run_uuid")!=self.session.identity.run_uuid: raise Stage6BiologyError("STAGE6_STATE_CORRUPT")
        return copy.deepcopy(dict(raw))

class Stage6CommitAdapter:
    def __init__(self,session:RunSession): self.session=session; self.view=Stage6BiologyView(session)
    def apply_many(self, decisions:Sequence[AuthorityDecision], *, commit_id:str,event_id:str)->CommitRecord|ValidationResult:
        if not decisions: raise Stage6BiologyError("STAGE6_DECISIONS_REQUIRED")
        revision=self.session.store.revision; root=dict(self.view.snapshot()); root.setdefault("inheritance_records",{}); root.setdefault("drift_records",{})
        ids=[]
        for d in decisions:
            if d.status!=AuthorityStatus.ALLOW or d.commit_operation is None: raise Stage6BiologyError("STAGE6_AUTHORITY_ALLOW_REQUIRED")
            op=d.commit_operation
            if op.approved_state_revision!=revision or op.authority_domain!=AuthorityDomain.BIOLOGY: raise Stage6BiologyError("STAGE6_AUTHORITY_OR_REVISION_INVALID")
            p=copy.deepcopy(dict(op.payload)); rid=p["record_id"]
            bucket="inheritance_records" if op.effect_type==EffectType.BIOLOGY_INHERITANCE_RECORD else "drift_records" if op.effect_type==EffectType.BIOLOGY_DRIFT_RECORD else None
            if bucket is None: raise Stage6BiologyError("STAGE6_EFFECT_REQUIRED")
            if rid in root[bucket]:
                if root[bucket][rid]!=p: raise Stage6BiologyError("STAGE6_RECORD_ID_COLLISION")
            else: root[bucket][rid]=p
            ids.append(op.effect_id)
        delta=Delta(Domain.RUNTIME_STATE,STAGE6_RUNTIME_KEY,root,Authority.RULE_KERNEL,"CONTENT_S6_MUTATION",Mode.COMMIT,source_event_id=event_id,provenance="|".join(f"EFFECT:{x}" for x in ids))
        result=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(delta,),event_id=event_id,cause="CONTENT_S6_ATOMIC_COMMIT",expected_state_revision=revision,commit_id=commit_id,effect_ids=tuple(ids)))
        if isinstance(result,ValidationResult) and result.verdict not in {Verdict.HOLD,Verdict.PASS}: raise Stage6BiologyError("STAGE6_COMMIT_REJECTED")
        return result
