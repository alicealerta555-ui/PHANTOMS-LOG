# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from hashlib import sha256
import copy
import json
import random
from typing import Any, Iterable, Mapping, Optional, Sequence, Tuple

from runtime.stage3a.integration import RuntimeAuthorityBridge, RuntimeDelta
from runtime.stage3a.kernel import (
    Authority,
    CommitRecord,
    Domain,
    Stage3AError,
    ValidationResult,
    Verdict,
)
from runtime.stage3b.pipeline import CircumstanceDecision


PPM = 1_000_000
SEQ_PREFIX = "__circumstance:sequence:"
LAST_PREFIX = "__circumstance:last:"
HISTORY_PREFIX = "__circumstance:history:"


class Stage3EError(RuntimeError):
    pass


class StateOp(str, Enum):
    EQ = "EQ"
    NE = "NE"
    GT = "GT"
    GE = "GE"
    LT = "LT"
    LE = "LE"
    IN = "IN"
    NOT_IN = "NOT_IN"
    EXISTS = "EXISTS"
    NOT_EXISTS = "NOT_EXISTS"
    TRUTHY = "TRUTHY"
    FALSY = "FALSY"


def _json_safe(value: Any, code: str) -> None:
    try:
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise Stage3EError(code) from exc


def _seed64(*parts: Any) -> int:
    raw = "|".join(str(p) for p in parts).encode("utf-8")
    return int.from_bytes(sha256(raw).digest()[:8], "big")


@dataclass(frozen=True)
class StateCondition:
    domain: Domain
    key: str
    op: StateOp
    expected: Any = None

    def validate(self) -> None:
        if self.domain not in {Domain.WORLD_TRUTH, Domain.RUNTIME_STATE}:
            raise Stage3EError(f"CIRCUMSTANCE_CONDITION_DOMAIN_FORBIDDEN:{self.domain.value}")
        if not self.key:
            raise Stage3EError("CIRCUMSTANCE_CONDITION_KEY_EMPTY")
        if self.op not in {StateOp.EXISTS, StateOp.NOT_EXISTS, StateOp.TRUTHY, StateOp.FALSY}:
            _json_safe(self.expected, f"CIRCUMSTANCE_CONDITION_EXPECTED_NOT_JSON_SAFE:{self.key}")


@dataclass(frozen=True)
class CircumstanceEffect:
    domain: Domain
    key: str
    value: Any
    cause: str
    expected_current: Any = None
    require_current_match: bool = False

    def validate(self) -> None:
        if self.domain not in {Domain.WORLD_TRUTH, Domain.RUNTIME_STATE}:
            raise Stage3EError(f"CIRCUMSTANCE_EFFECT_DOMAIN_FORBIDDEN:{self.domain.value}")
        if not self.key or not self.cause:
            raise Stage3EError("CIRCUMSTANCE_EFFECT_KEY_OR_CAUSE_EMPTY")
        _json_safe(self.value, f"CIRCUMSTANCE_EFFECT_VALUE_NOT_JSON_SAFE:{self.key}")
        if self.require_current_match:
            _json_safe(self.expected_current, f"CIRCUMSTANCE_EXPECTED_CURRENT_NOT_JSON_SAFE:{self.key}")


@dataclass(frozen=True)
class CircumstanceCandidate:
    candidate_id: str
    weight: int
    effects: Tuple[CircumstanceEffect, ...]
    plausibility: Tuple[StateCondition, ...] = ()
    integrity: Tuple[StateCondition, ...] = ()
    interest: Tuple[StateCondition, ...] = ()
    intrinsic_interest_ppm: int = 0
    pattern_group: str = ""
    cooldown_checks: int = 0

    def validate(self) -> None:
        if not self.candidate_id:
            raise Stage3EError("CIRCUMSTANCE_CANDIDATE_ID_EMPTY")
        if self.weight <= 0:
            raise Stage3EError(f"CIRCUMSTANCE_WEIGHT_NONPOSITIVE:{self.candidate_id}")
        if not self.effects:
            raise Stage3EError(f"CIRCUMSTANCE_EFFECTS_EMPTY:{self.candidate_id}")
        if not 0 <= self.intrinsic_interest_ppm <= PPM:
            raise Stage3EError(f"CIRCUMSTANCE_INTEREST_PPM_INVALID:{self.candidate_id}")
        if self.cooldown_checks < 0:
            raise Stage3EError(f"CIRCUMSTANCE_COOLDOWN_INVALID:{self.candidate_id}")
        for condition in (*self.plausibility, *self.integrity, *self.interest):
            condition.validate()
        for effect in self.effects:
            effect.validate()


@dataclass(frozen=True)
class CircumstanceSpec:
    circumstance_id: str
    candidates: Tuple[CircumstanceCandidate, ...]
    activation_ppm: int = PPM
    min_interest_ppm: int = 1
    seed_salt: str = ""
    mutable_world_keys: Tuple[str, ...] = ()
    anti_pattern: bool = True

    def validate(self) -> None:
        if not self.circumstance_id:
            raise Stage3EError("CIRCUMSTANCE_ID_EMPTY")
        if not self.candidates:
            raise Stage3EError(f"CIRCUMSTANCE_CANDIDATES_EMPTY:{self.circumstance_id}")
        if not 0 <= self.activation_ppm <= PPM:
            raise Stage3EError(f"CIRCUMSTANCE_ACTIVATION_PPM_INVALID:{self.circumstance_id}")
        if not 0 <= self.min_interest_ppm <= PPM:
            raise Stage3EError(f"CIRCUMSTANCE_MIN_INTEREST_PPM_INVALID:{self.circumstance_id}")
        ids = []
        for candidate in self.candidates:
            candidate.validate()
            ids.append(candidate.candidate_id)
            for effect in candidate.effects:
                if effect.domain == Domain.WORLD_TRUTH:
                    if effect.key not in self.mutable_world_keys:
                        raise Stage3EError(
                            f"CIRCUMSTANCE_WORLD_KEY_NOT_DECLARED_MUTABLE:{candidate.candidate_id}:{effect.key}"
                        )
                    if not effect.require_current_match:
                        raise Stage3EError(
                            f"CIRCUMSTANCE_WORLD_UPDATE_REQUIRES_EXPECTED_CURRENT:{candidate.candidate_id}:{effect.key}"
                        )
        if len(ids) != len(set(ids)):
            raise Stage3EError(f"CIRCUMSTANCE_DUPLICATE_CANDIDATE_ID:{self.circumstance_id}")


@dataclass(frozen=True)
class QueryResolutionResult:
    query_verdict: Verdict
    query_reasons: Tuple[str, ...]
    resolution: CommitRecord | ValidationResult
    state_unchanged_by_query: bool


class GroundTruthResolver:
    """Stage-3E boundary for unresolved objective state.

    Player language can trigger this service, but player wording/suggestions are never
    accepted by resolve_unknown() and therefore cannot enter seed material or weights.
    The underlying Stage-3A resolver consumes exactly one pre-registered possibility space
    and guarantees no-reroll after commit.
    """

    def __init__(self, bridge: RuntimeAuthorityBridge):
        self.bridge = bridge

    def resolve_unknown(
        self,
        key: str,
        *,
        event_id: Optional[str] = None,
        cause: str = "UNKNOWN_GROUND_TRUTH_RESOLUTION",
    ) -> CommitRecord | ValidationResult:
        return self.bridge.resolve_unknown(key, event_id=event_id, cause=cause)

    def resolve_triggered_by_query(
        self,
        key: str,
        *,
        query_text: str,
        player_suggestion: Any = None,
        event_id: Optional[str] = None,
        cause: str = "QUERY_TRIGGERED_GROUND_TRUTH_RESOLUTION",
    ) -> QueryResolutionResult:
        before = self.bridge.kernel.store.state_hash()
        query = self.bridge.query_player_text(query_text, suggestion=player_suggestion)
        after_query = self.bridge.kernel.store.state_hash()
        # The suggestion is deliberately not forwarded to resolve_unknown().
        resolution = self.resolve_unknown(key, event_id=event_id, cause=cause)
        return QueryResolutionResult(
            query_verdict=query.verdict,
            query_reasons=query.reasons,
            resolution=resolution,
            state_unchanged_by_query=(before == after_query),
        )


class CircumstanceEngine:
    """Deterministic exogenous-event layer with three hard guards.

    Guard order:
      1) Plausibility: candidate preconditions must match committed state.
      2) State/story integrity: explicit integrity conditions plus protected world-key rules.
      3) Interest: the event needs a live interest signal or sufficient intrinsic interest.

    Selection never receives player text. Anti-pattern behavior only selects among candidates
    that already passed all guards; it cannot make an implausible event eligible.
    """

    def __init__(
        self,
        bridge: RuntimeAuthorityBridge,
        *,
        run_seed: int,
        specs: Iterable[CircumstanceSpec] = (),
    ) -> None:
        self.bridge = bridge
        self.run_seed = int(run_seed)
        self._specs: dict[str, CircumstanceSpec] = {}
        for spec in specs:
            self.register(spec)

    def register(self, spec: CircumstanceSpec) -> None:
        spec.validate()
        if spec.circumstance_id in self._specs:
            raise Stage3EError(f"CIRCUMSTANCE_SPEC_ALREADY_REGISTERED:{spec.circumstance_id}")
        self._specs[spec.circumstance_id] = spec

    def spec_ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._specs))

    def resolve_for_action(
        self,
        *,
        circumstance_id: str,
        action_event_id: str,
        rule_id: str,
    ) -> CircumstanceDecision:
        # The public signature intentionally contains no player text/suggestion.
        return self.trigger(
            circumstance_id=circumstance_id,
            trigger_event_id=f"ACTION:{action_event_id}",
            trigger_kind=f"ACTION_RULE:{rule_id}",
        )

    def trigger(
        self,
        *,
        circumstance_id: str,
        trigger_event_id: str,
        trigger_kind: str = "WORLD_TICK",
    ) -> CircumstanceDecision:
        if not circumstance_id or not trigger_event_id or not trigger_kind:
            return CircumstanceDecision(Verdict.REJECT, ("CIRCUMSTANCE_TRIGGER_FIELDS_REQUIRED",), circumstance_id)
        spec = self._specs.get(circumstance_id)
        if spec is None:
            return CircumstanceDecision(Verdict.HOLD, ("CIRCUMSTANCE_SPEC_NOT_REGISTERED",), circumstance_id)

        digest = sha256(f"{circumstance_id}|{trigger_event_id}|{trigger_kind}".encode("utf-8")).hexdigest()[:20]
        event_id = f"CIRCUMSTANCE:{circumstance_id}:{digest}"
        existing = self.bridge.kernel.store.event_ledger.get(event_id)
        if existing is not None:
            candidate_id = self._candidate_from_record(existing, circumstance_id)
            return CircumstanceDecision(
                Verdict.PASS,
                ("CIRCUMSTANCE_TRIGGER_IDEMPOTENT_REPLAY",),
                circumstance_id,
                candidate_id,
                event_id,
                existing,
            )

        sequence = self._read_int(SEQ_PREFIX + circumstance_id, default=0)
        history = self._read_history(circumstance_id)
        last = self._read_mapping(LAST_PREFIX + circumstance_id)

        activation_seed = _seed64(self.run_seed, "CIRCUMSTANCE", circumstance_id, sequence, spec.seed_salt, "ACTIVATE")
        activation_roll = random.Random(activation_seed).randrange(PPM)
        applicable: list[CircumstanceCandidate] = []
        reasons: list[str] = []

        if activation_roll < spec.activation_ppm:
            for candidate in spec.candidates:
                passed, reason = self._candidate_passes(spec, candidate, sequence, history)
                if passed:
                    applicable.append(candidate)
                else:
                    reasons.append(f"{candidate.candidate_id}:{reason}")

        chosen: Optional[CircumstanceCandidate] = None
        if applicable:
            if spec.anti_pattern and len(applicable) > 1 and isinstance(last, Mapping):
                last_group = last.get("pattern_group")
                alternatives = [c for c in applicable if not last_group or c.pattern_group != last_group]
                if alternatives:
                    applicable = alternatives
            choice_seed = _seed64(self.run_seed, "CIRCUMSTANCE", circumstance_id, sequence, spec.seed_salt, "CHOOSE")
            rng = random.Random(choice_seed)
            chosen = rng.choices(applicable, weights=[c.weight for c in applicable], k=1)[0]

        deltas: list[RuntimeDelta] = []
        selected_reason = "NO_CIRCUMSTANCE_TRIGGERED"
        if chosen is not None:
            try:
                deltas.extend(self._effect_deltas(spec, chosen))
            except Stage3EError as exc:
                return CircumstanceDecision(
                    Verdict.REJECT, (f"CIRCUMSTANCE_INTEGRITY_REJECT:{exc}",),
                    circumstance_id, chosen.candidate_id, event_id,
                )
            history = dict(history)
            history[chosen.candidate_id] = sequence
            selected_reason = "CIRCUMSTANCE_SELECTED"

        last_record = {
            "circumstance_id": circumstance_id,
            "candidate_id": chosen.candidate_id if chosen else None,
            "pattern_group": chosen.pattern_group if chosen else None,
            "sequence": sequence,
            "trigger_kind": trigger_kind,
            "activation_roll": activation_roll,
            "activation_ppm": spec.activation_ppm,
            "guard_rejections": reasons,
        }
        deltas.extend([
            RuntimeDelta(
                Domain.RUNTIME_STATE.value,
                SEQ_PREFIX + circumstance_id,
                sequence + 1,
                "RULE_KERNEL",
                "CIRCUMSTANCE_SEQUENCE_ADVANCE",
            ),
            RuntimeDelta(
                Domain.RUNTIME_STATE.value,
                LAST_PREFIX + circumstance_id,
                last_record,
                "RULE_KERNEL",
                "CIRCUMSTANCE_DECISION_RECORD",
            ),
            RuntimeDelta(
                Domain.RUNTIME_STATE.value,
                HISTORY_PREFIX + circumstance_id,
                history,
                "RULE_KERNEL",
                "CIRCUMSTANCE_HISTORY_UPDATE",
            ),
        ])

        committed = self.bridge.commit_runtime_event(
            event_id=event_id,
            cause=f"CIRCUMSTANCE_TRIGGER:{circumstance_id}:{trigger_kind}",
            deltas=deltas,
        )
        if isinstance(committed, ValidationResult):
            return CircumstanceDecision(
                committed.verdict,
                committed.reasons,
                circumstance_id,
                chosen.candidate_id if chosen else None,
                event_id,
                None,
            )
        return CircumstanceDecision(
            Verdict.PASS,
            (selected_reason,),
            circumstance_id,
            chosen.candidate_id if chosen else None,
            event_id,
            committed,
        )

    def _candidate_passes(
        self,
        spec: CircumstanceSpec,
        candidate: CircumstanceCandidate,
        sequence: int,
        history: Mapping[str, int],
    ) -> tuple[bool, str]:
        if candidate.cooldown_checks:
            last_seq = history.get(candidate.candidate_id)
            if isinstance(last_seq, int) and sequence - last_seq <= candidate.cooldown_checks:
                return False, "COOLDOWN"
        if not all(self._condition(c) for c in candidate.plausibility):
            return False, "PLAUSIBILITY_GUARD"
        if not all(self._condition(c) for c in candidate.integrity):
            return False, "STATE_STORY_INTEGRITY_GUARD"
        live_interest = any(self._condition(c) for c in candidate.interest) if candidate.interest else False
        if not live_interest and candidate.intrinsic_interest_ppm < spec.min_interest_ppm:
            return False, "INTEREST_GUARD"
        # Validate world-mutation targets against the current committed state before choice.
        for effect in candidate.effects:
            if effect.domain != Domain.WORLD_TRUTH:
                continue
            if effect.key not in spec.mutable_world_keys:
                return False, "WORLD_TARGET_NOT_MUTABLE"
            if not self.bridge.kernel.exists(Authority.RULE_KERNEL, Domain.WORLD_TRUTH, effect.key):
                return False, "KNOWN_STATE_REQUIRED_NO_RANDOMIZE_ABSENT_WORLD_TRUTH"
            current = self.bridge.kernel.read(Authority.RULE_KERNEL, Domain.WORLD_TRUTH, effect.key)
            if effect.require_current_match and current != effect.expected_current:
                return False, "EXPECTED_CURRENT_MISMATCH"
        return True, "PASS"

    def _effect_deltas(self, spec: CircumstanceSpec, candidate: CircumstanceCandidate) -> list[RuntimeDelta]:
        out: list[RuntimeDelta] = []
        for effect in candidate.effects:
            if effect.domain == Domain.WORLD_TRUTH:
                if effect.key not in spec.mutable_world_keys:
                    raise Stage3EError(f"WORLD_TARGET_NOT_MUTABLE:{effect.key}")
                if not self.bridge.kernel.exists(Authority.RULE_KERNEL, Domain.WORLD_TRUTH, effect.key):
                    raise Stage3EError(f"WORLD_TARGET_UNKNOWN_USE_GROUND_TRUTH_RESOLVER:{effect.key}")
                current = self.bridge.kernel.read(Authority.RULE_KERNEL, Domain.WORLD_TRUTH, effect.key)
                if not effect.require_current_match or current != effect.expected_current:
                    raise Stage3EError(f"WORLD_TARGET_CURRENT_STATE_MISMATCH:{effect.key}")
            out.append(RuntimeDelta(
                effect.domain.value,
                effect.key,
                copy.deepcopy(effect.value),
                "RULE_KERNEL",
                effect.cause,
            ))
        return out

    def _condition(self, condition: StateCondition) -> bool:
        authority = Authority.RULE_KERNEL
        present = self.bridge.kernel.exists(authority, condition.domain, condition.key)
        if condition.op == StateOp.EXISTS:
            return present
        if condition.op == StateOp.NOT_EXISTS:
            return not present
        if not present:
            return False
        value = self.bridge.kernel.read(authority, condition.domain, condition.key)
        try:
            if condition.op == StateOp.EQ:
                return value == condition.expected
            if condition.op == StateOp.NE:
                return value != condition.expected
            if condition.op == StateOp.GT:
                return value > condition.expected
            if condition.op == StateOp.GE:
                return value >= condition.expected
            if condition.op == StateOp.LT:
                return value < condition.expected
            if condition.op == StateOp.LE:
                return value <= condition.expected
            if condition.op == StateOp.IN:
                return value in condition.expected
            if condition.op == StateOp.NOT_IN:
                return value not in condition.expected
            if condition.op == StateOp.TRUTHY:
                return bool(value)
            if condition.op == StateOp.FALSY:
                return not bool(value)
        except (TypeError, ValueError):
            return False
        return False

    def _read_int(self, key: str, *, default: int) -> int:
        if not self.bridge.kernel.exists(Authority.RULE_KERNEL, Domain.RUNTIME_STATE, key):
            return default
        value = self.bridge.kernel.read(Authority.RULE_KERNEL, Domain.RUNTIME_STATE, key)
        if not isinstance(value, int) or value < 0:
            raise Stage3EError(f"CIRCUMSTANCE_COUNTER_CORRUPT:{key}")
        return value

    def _read_mapping(self, key: str) -> Mapping[str, Any]:
        if not self.bridge.kernel.exists(Authority.RULE_KERNEL, Domain.RUNTIME_STATE, key):
            return {}
        value = self.bridge.kernel.read(Authority.RULE_KERNEL, Domain.RUNTIME_STATE, key)
        if not isinstance(value, Mapping):
            raise Stage3EError(f"CIRCUMSTANCE_RUNTIME_RECORD_CORRUPT:{key}")
        return copy.deepcopy(dict(value))

    def _read_history(self, circumstance_id: str) -> Mapping[str, int]:
        raw = self._read_mapping(HISTORY_PREFIX + circumstance_id)
        out: dict[str, int] = {}
        for key, value in raw.items():
            if not isinstance(key, str) or not isinstance(value, int) or value < 0:
                raise Stage3EError(f"CIRCUMSTANCE_HISTORY_CORRUPT:{circumstance_id}")
            out[key] = value
        return out

    @staticmethod
    def _candidate_from_record(record: CommitRecord, circumstance_id: str) -> Optional[str]:
        key = LAST_PREFIX + circumstance_id
        for delta in record.deltas:
            if delta.domain == Domain.RUNTIME_STATE and delta.key == key and isinstance(delta.value, Mapping):
                candidate_id = delta.value.get("candidate_id")
                return str(candidate_id) if candidate_id is not None else None
        return None
