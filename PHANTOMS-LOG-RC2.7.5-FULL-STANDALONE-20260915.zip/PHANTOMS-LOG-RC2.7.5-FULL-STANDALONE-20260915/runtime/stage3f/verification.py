# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import math
from typing import Any, Iterable, Mapping, Optional, Sequence, Tuple

from runtime.stage3a.integration import RuntimeDelta
from runtime.stage3a.kernel import (
    Authority,
    Delta,
    Domain,
    Proposal,
    StateStore,
    UnresolvedSpec,
    ValidationResult,
    Verdict,
    WRITE_MATRIX,
)
from runtime.stage3b.pipeline import (
    ActionPipeline,
    ActionRequest,
    BaselineVerifier,
    OutcomeBranch,
    PreCommitVerifier,
    VerificationDecision,
)


class VerificationDimension(str, Enum):
    STATE = "STATE"
    INVENTORY_RESOURCES = "INVENTORY_RESOURCES"
    TIME = "TIME"
    POSITION_SPACE = "POSITION_SPACE"
    RULES_MECHANICS = "RULES_MECHANICS"
    CAUSALITY_PRECONDITIONS = "CAUSALITY_PRECONDITIONS"
    NPC_KNOWLEDGE_EPISTEMICS = "NPC_KNOWLEDGE_EPISTEMICS"
    MEMORY_RETCON = "MEMORY_RETCON"
    PLAYER_AGENCY = "PLAYER_AGENCY"
    NARRATION_VS_COMMIT = "NARRATION_VS_COMMIT"


ALL_DIMENSIONS: Tuple[VerificationDimension, ...] = tuple(VerificationDimension)


@dataclass(frozen=True)
class DimensionSignal:
    dimension: VerificationDimension
    hard_failures: Tuple[str, ...] = ()
    notes: Tuple[str, ...] = ()

    @property
    def passed(self) -> bool:
        return not self.hard_failures


@dataclass(frozen=True)
class VerificationReport:
    phase: str
    event_id: Optional[str]
    signals: Tuple[DimensionSignal, ...]

    @property
    def verdict(self) -> Verdict:
        return Verdict.REJECT if any(not signal.passed for signal in self.signals) else Verdict.PASS

    @property
    def reasons(self) -> Tuple[str, ...]:
        out: list[str] = []
        for signal in self.signals:
            out.extend(
                f"V3F:{signal.dimension.value}:{reason}"
                for reason in signal.hard_failures
            )
        return tuple(out)

    def signal(self, dimension: VerificationDimension) -> DimensionSignal:
        for signal in self.signals:
            if signal.dimension == dimension:
                return signal
        raise KeyError(dimension)


@dataclass(frozen=True)
class VerificationPolicy:
    """Conservative structured invariants.

    Stage 3F deliberately does not infer hard constraints from prose. A key only receives
    numeric/time/agency semantics when it matches an explicit stable convention below.
    Unknown keys are left alone unless another structured contract proves a contradiction.
    """

    resource_exact: Tuple[str, ...] = (
        "credits", "energy", "ammo",
    )
    resource_prefixes: Tuple[str, ...] = (
        "inventory.", "resource.", "resources.", "ammo.",
    )
    quantity_fields: Tuple[str, ...] = (
        "qty", "quantity", "count", "amount", "charges", "stack", "units",
    )
    monotonic_time_keys: Tuple[str, ...] = (
        "time", "world_time", "world.tick", "tick",
    )
    position_keys: Tuple[str, ...] = (
        "position", "location", "player.position", "player.location",
    )
    agency_owned_prefixes: Tuple[str, ...] = (
        "player.intent", "player.choice", "player.decision", "player.command",
        "player.request", "player.input",
    )
    narration_reserved_prefixes: Tuple[str, ...] = (
        "__narration", "narration.output", "narration.text", "presentation.output",
    )


class Stage3FError(RuntimeError):
    pass


def _norm_key(key: str) -> str:
    return key.strip().lower()


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def _target(delta: Delta) -> tuple[str, str, str]:
    return (delta.domain.value, delta.actor_id or "", delta.key)


def _runtime_target(delta: RuntimeDelta) -> tuple[str, str, str]:
    return (delta.domain, delta.actor_id or "", delta.key)


def _resource_key(key: str, policy: VerificationPolicy) -> bool:
    normalized = _norm_key(key)
    return normalized in policy.resource_exact or any(normalized.startswith(p) for p in policy.resource_prefixes)


def _negative_quantity_paths(value: Any, *, policy: VerificationPolicy, path: str = "") -> list[str]:
    failures: list[str] = []
    if isinstance(value, Mapping):
        for raw_key, child in value.items():
            key = str(raw_key)
            child_path = f"{path}.{key}" if path else key
            if _norm_key(key) in policy.quantity_fields and _is_number(child) and child < 0:
                failures.append(child_path)
            elif isinstance(child, (Mapping, list, tuple)):
                failures.extend(_negative_quantity_paths(child, policy=policy, path=child_path))
    elif isinstance(value, (list, tuple)):
        for idx, child in enumerate(value):
            child_path = f"{path}[{idx}]"
            if isinstance(child, (Mapping, list, tuple)):
                failures.extend(_negative_quantity_paths(child, policy=policy, path=child_path))
    return failures


def _valid_position(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple)):
        if not value:
            return False
        if len(value) in {2, 3} and all(_is_number(x) for x in value):
            return True
        # Unknown structured representation: non-empty is not itself a proven contradiction.
        return True
    if isinstance(value, Mapping):
        if not value:
            return False
        if "location_id" in value:
            return isinstance(value["location_id"], str) and bool(value["location_id"].strip())
        if "x" in value and "y" in value:
            return _is_number(value["x"]) and _is_number(value["y"])
        return True
    return True


def _existing_knowledge(store: StateStore, delta: Delta) -> Any:
    if delta.domain == Domain.ACTOR_KNOWLEDGE:
        return store.actor_knowledge.get(delta.actor_id or "", {}).get(delta.key)
    if delta.domain == Domain.PLAYER_KNOWLEDGE:
        return store.player_knowledge.get(delta.key)
    return None


def _immutable_resolved_keys(store: StateStore) -> set[str]:
    keys: set[str] = set()
    for record in store.event_ledger.values():
        for delta in record.deltas:
            if delta.domain != Domain.UNRESOLVED_WORLD:
                continue
            if isinstance(delta.value, UnresolvedSpec) and delta.value.immutable_after_resolution:
                keys.add(delta.key)
    return keys


def _prospective_time(store: StateStore, deltas: Sequence[Delta], policy: VerificationPolicy) -> Optional[float]:
    # Ordered aliases: use the first canonical time key present rather than comparing clocks
    # that may use different units.
    for key in policy.monotonic_time_keys:
        candidate = None
        seen = False
        for delta in deltas:
            if delta.domain == Domain.RUNTIME_STATE and _norm_key(delta.key) == key:
                candidate = delta.value
                seen = True
        if not seen:
            matching_store_key = next((k for k in store.runtime_state if _norm_key(k) == key), None)
            if matching_store_key is not None:
                candidate = store.runtime_state[matching_store_key]
                seen = True
        if seen and _is_number(candidate):
            return float(candidate)
    return None


class TenfoldVerificationGate:
    """Stage 3F operational tenfold gate.

    The gate implements both interfaces already present in the runtime:
    - Stage-3B action verification before an action commit is requested.
    - Stage-3A global PreCommitGuard for every persistent mutation, including world-sim,
      epistemic and circumstance commits.

    All ten dimensions always emit a compact signal. The gate never searches player prose
    for danger words or intentions; semantic mention alone therefore cannot create a veto.
    """

    def __init__(self, store: StateStore, *, policy: Optional[VerificationPolicy] = None) -> None:
        self.store = store
        self.policy = policy or VerificationPolicy()
        self.last_action_report: Optional[VerificationReport] = None
        self.last_commit_report: Optional[VerificationReport] = None

    # ---------- Stage-3B PreCommitVerifier ----------
    def verify(
        self,
        *,
        request: ActionRequest,
        outcome: OutcomeBranch,
        facts: Mapping[str, Any],
        rng: Mapping[str, int],
        deltas: Sequence[RuntimeDelta],
    ) -> VerificationDecision:
        failures = {dimension: [] for dimension in ALL_DIMENSIONS}
        notes = {dimension: [] for dimension in ALL_DIMENSIONS}

        baseline = BaselineVerifier().verify(
            request=request, outcome=outcome, facts=facts, rng=rng, deltas=deltas,
        )
        if baseline.verdict != Verdict.PASS:
            failures[VerificationDimension.RULES_MECHANICS].extend(baseline.reasons)

        # STATE: conflicting writes in one action are objectively ambiguous.
        seen: dict[tuple[str, str, str], Any] = {}
        for delta in deltas:
            target = _runtime_target(delta)
            if target in seen and seen[target] != delta.value:
                failures[VerificationDimension.STATE].append(
                    f"CONFLICTING_ACTION_DELTAS:{delta.domain}:{delta.actor_id or '-'}:{delta.key}"
                )
            else:
                seen[target] = delta.value

        # INVENTORY/RESOURCES: only explicitly classified keys are constrained.
        for delta in deltas:
            if delta.domain != Domain.RUNTIME_STATE.value or not _resource_key(delta.key, self.policy):
                continue
            if _is_number(delta.value) and delta.value < 0:
                failures[VerificationDimension.INVENTORY_RESOURCES].append(f"NEGATIVE_RESOURCE:{delta.key}")
            for path in _negative_quantity_paths(delta.value, policy=self.policy):
                failures[VerificationDimension.INVENTORY_RESOURCES].append(
                    f"NEGATIVE_RESOURCE_QUANTITY:{delta.key}:{path}"
                )

        # TIME: action candidate cannot regress a known canonical monotonic clock.
        for delta in deltas:
            key = _norm_key(delta.key)
            if delta.domain != Domain.RUNTIME_STATE.value or key not in self.policy.monotonic_time_keys:
                continue
            existing = self.store.runtime_state.get(delta.key)
            if existing is not None and _is_number(existing) and _is_number(delta.value) and delta.value < existing:
                failures[VerificationDimension.TIME].append(f"TIME_REGRESSION:{delta.key}")

        # POSITION/SPACE: reject only clearly invalid position values.
        for delta in deltas:
            if delta.domain == Domain.RUNTIME_STATE.value and _norm_key(delta.key) in self.policy.position_keys:
                if not _valid_position(delta.value):
                    failures[VerificationDimension.POSITION_SPACE].append(f"INVALID_POSITION:{delta.key}")

        # RULES/MECHANICS + CAUSALITY: independently re-check structured conditions.
        for condition in request.rule.preconditions:
            if not ActionPipeline._eval_condition(condition, facts, rng):
                failures[VerificationDimension.CAUSALITY_PRECONDITIONS].append(
                    f"PRECONDITION_NOT_SATISFIED:{condition.source.value}:{condition.name}:{condition.op.value}"
                )
        for condition in outcome.conditions:
            if not ActionPipeline._eval_condition(condition, facts, rng):
                failures[VerificationDimension.RULES_MECHANICS].append(
                    f"OUTCOME_CONDITION_NOT_SATISFIED:{condition.source.value}:{condition.name}:{condition.op.value}"
                )

        # EPISTEMICS/MEMORY: action deltas are checked again globally after bridge mapping;
        # here we can still catch timestamp regressions from their structured metadata.
        for delta in deltas:
            if delta.domain not in {Domain.ACTOR_KNOWLEDGE.value, Domain.PLAYER_KNOWLEDGE.value}:
                continue
            self._check_runtime_knowledge_delta(delta, failures)

        # PLAYER AGENCY: engine may model consequences, but may not persist an invented choice.
        for delta in deltas:
            key = _norm_key(delta.key)
            if any(key.startswith(prefix) for prefix in self.policy.agency_owned_prefixes):
                failures[VerificationDimension.PLAYER_AGENCY].append(f"ENGINE_WRITES_PLAYER_CHOICE:{delta.key}")

        # NARRATION-VS-COMMIT: narration is a projection request, never a persistent delta.
        narration_keys = request.rule.narration_runtime_keys
        if len(narration_keys) != len(set(narration_keys)):
            failures[VerificationDimension.NARRATION_VS_COMMIT].append("DUPLICATE_NARRATION_RUNTIME_KEY")
        for key in narration_keys:
            if not isinstance(key, str) or not key.strip():
                failures[VerificationDimension.NARRATION_VS_COMMIT].append("INVALID_NARRATION_RUNTIME_KEY")
            if str(key) in {domain.value for domain in Domain if domain != Domain.RUNTIME_STATE}:
                failures[VerificationDimension.NARRATION_VS_COMMIT].append(f"HIDDEN_DOMAIN_NARRATION_REQUEST:{key}")
        for delta in deltas:
            key = _norm_key(delta.key)
            if any(key.startswith(prefix) for prefix in self.policy.narration_reserved_prefixes):
                failures[VerificationDimension.NARRATION_VS_COMMIT].append(f"NARRATION_PERSISTENCE_FORBIDDEN:{delta.key}")

        # Explicit note proves the false-veto design: prose is intentionally not inspected.
        notes[VerificationDimension.PLAYER_AGENCY].append("PLAYER_TEXT_NOT_USED_AS_VETO_SIGNAL")

        report = self._report("ACTION", request.event_id, failures, notes)
        self.last_action_report = report
        return VerificationDecision(report.verdict, report.reasons)

    # ---------- Stage-3A PreCommitGuard ----------
    def verify_proposal(
        self,
        *,
        proposal: Proposal,
        deltas: Sequence[Delta],
        store: StateStore,
    ) -> ValidationResult:
        if store is not self.store:
            # A gate is bound to exactly one run/store. Reusing it across runs would defeat 3C.
            report = self._single_hard_failure(
                "COMMIT", proposal.event_id, VerificationDimension.STATE, "VERIFIER_STORE_IDENTITY_MISMATCH"
            )
            self.last_commit_report = report
            return ValidationResult(Verdict.REJECT, report.reasons, ())

        failures = {dimension: [] for dimension in ALL_DIMENSIONS}
        notes = {dimension: [] for dimension in ALL_DIMENSIONS}

        # STATE: no contradictory double-write; no bypass of unresolved Ground Truth.
        seen: dict[tuple[str, str, str], Any] = {}
        for delta in deltas:
            target = _target(delta)
            if target in seen and seen[target] != delta.value:
                failures[VerificationDimension.STATE].append(
                    f"CONFLICTING_COMMIT_DELTAS:{delta.domain.value}:{delta.actor_id or '-'}:{delta.key}"
                )
            else:
                seen[target] = delta.value
            if (
                delta.domain == Domain.WORLD_TRUTH
                and delta.key in store.unresolved_world
                and delta.writer != Authority.WORLD_RESOLVER
            ):
                failures[VerificationDimension.STATE].append(f"UNRESOLVED_TRUTH_RESOLVER_BYPASS:{delta.key}")

        # INVENTORY/RESOURCES.
        for delta in deltas:
            if delta.domain != Domain.RUNTIME_STATE or not _resource_key(delta.key, self.policy):
                continue
            if _is_number(delta.value) and delta.value < 0:
                failures[VerificationDimension.INVENTORY_RESOURCES].append(f"NEGATIVE_RESOURCE:{delta.key}")
            for path in _negative_quantity_paths(delta.value, policy=self.policy):
                failures[VerificationDimension.INVENTORY_RESOURCES].append(
                    f"NEGATIVE_RESOURCE_QUANTITY:{delta.key}:{path}"
                )

        # TIME.
        for delta in deltas:
            key = _norm_key(delta.key)
            if delta.domain != Domain.RUNTIME_STATE or key not in self.policy.monotonic_time_keys:
                continue
            existing_key = next((k for k in store.runtime_state if _norm_key(k) == key), delta.key)
            existing = store.runtime_state.get(existing_key)
            if existing is not None and _is_number(existing) and _is_number(delta.value) and delta.value < existing:
                failures[VerificationDimension.TIME].append(f"TIME_REGRESSION:{delta.key}")

        # POSITION/SPACE.
        for delta in deltas:
            if delta.domain == Domain.RUNTIME_STATE and _norm_key(delta.key) in self.policy.position_keys:
                if not _valid_position(delta.value):
                    failures[VerificationDimension.POSITION_SPACE].append(f"INVALID_POSITION:{delta.key}")

        # RULES/MECHANICS: repeat authority matrix at the tenfold layer; Stage 3A remains
        # independently authoritative, so this is a cross-check rather than a replacement.
        for delta in deltas:
            if delta.writer not in WRITE_MATRIX.get(delta.domain, frozenset()):
                failures[VerificationDimension.RULES_MECHANICS].append(
                    f"WRITER_DOMAIN_CONTRACT:{delta.domain.value}:{delta.writer.value}:{delta.key}"
                )

        # CAUSALITY/PRECONDITIONS: commit objects need explicit cause/event and delta causes.
        if not proposal.event_id:
            failures[VerificationDimension.CAUSALITY_PRECONDITIONS].append("EVENT_ID_REQUIRED")
        if not proposal.cause:
            failures[VerificationDimension.CAUSALITY_PRECONDITIONS].append("CAUSE_REQUIRED")
        for delta in deltas:
            if not delta.cause:
                failures[VerificationDimension.CAUSALITY_PRECONDITIONS].append(f"DELTA_CAUSE_REQUIRED:{delta.key}")

        # NPC KNOWLEDGE/EPISTEMICS + MEMORY/RETCON.
        prospective_time = _prospective_time(store, deltas, self.policy)
        immutable = _immutable_resolved_keys(store)
        for delta in deltas:
            if delta.domain in {Domain.ACTOR_KNOWLEDGE, Domain.PLAYER_KNOWLEDGE}:
                self._check_delta_epistemics(delta, prospective_time, failures)
                self._check_memory_regression(store, delta, failures)
            if delta.domain == Domain.WORLD_TRUTH and delta.key in immutable and delta.key in store.world_truth:
                if store.world_truth[delta.key] != delta.value:
                    failures[VerificationDimension.MEMORY_RETCON].append(
                        f"IMMUTABLE_RESOLVED_TRUTH_RETCON:{delta.key}"
                    )

        # PLAYER AGENCY.
        for delta in deltas:
            key = _norm_key(delta.key)
            if any(key.startswith(prefix) for prefix in self.policy.agency_owned_prefixes):
                failures[VerificationDimension.PLAYER_AGENCY].append(f"ENGINE_WRITES_PLAYER_CHOICE:{delta.key}")

        # NARRATION VS COMMIT.
        for delta in deltas:
            key = _norm_key(delta.key)
            if delta.writer == Authority.NARRATOR:
                failures[VerificationDimension.NARRATION_VS_COMMIT].append(f"NARRATOR_WRITE_FORBIDDEN:{delta.key}")
            if any(key.startswith(prefix) for prefix in self.policy.narration_reserved_prefixes):
                failures[VerificationDimension.NARRATION_VS_COMMIT].append(f"NARRATION_PERSISTENCE_FORBIDDEN:{delta.key}")

        report = self._report("COMMIT", proposal.event_id, failures, notes)
        self.last_commit_report = report
        return ValidationResult(report.verdict, report.reasons, tuple(deltas) if report.verdict == Verdict.PASS else ())

    def verify_narration_projection(self, view: Mapping[str, Any]) -> VerificationDecision:
        """Independent final-output cross-check. It does not mutate or infer hidden state."""
        failures: list[str] = []
        allowed = {"PLAYER_KNOWLEDGE", "PRESENTATION_RUNTIME", "revision"}
        unexpected = set(view) - allowed
        if unexpected:
            failures.append("UNEXPECTED_PRESENTATION_KEYS:" + ",".join(sorted(unexpected)))
        if view.get("revision") != self.store.revision:
            failures.append("PRESENTATION_REVISION_MISMATCH")
        if "PLAYER_KNOWLEDGE" not in view or "PRESENTATION_RUNTIME" not in view:
            failures.append("PRESENTATION_SHAPE_INCOMPLETE")
        return VerificationDecision(
            Verdict.REJECT if failures else Verdict.PASS,
            tuple(f"V3F:{VerificationDimension.NARRATION_VS_COMMIT.value}:{x}" for x in failures),
        )

    def _check_runtime_knowledge_delta(
        self,
        delta: RuntimeDelta,
        failures: dict[VerificationDimension, list[str]],
    ) -> None:
        meta = delta.epistemic
        if not isinstance(meta, Mapping):
            failures[VerificationDimension.NPC_KNOWLEDGE_EPISTEMICS].append(
                f"EPISTEMIC_METADATA_REQUIRED:{delta.key}"
            )
            return
        old = None
        if delta.domain == Domain.ACTOR_KNOWLEDGE.value:
            old = self.store.actor_knowledge.get(delta.actor_id or "", {}).get(delta.key)
        else:
            old = self.store.player_knowledge.get(delta.key)
        old_meta = old.get("epistemic") if isinstance(old, Mapping) else None
        if isinstance(old_meta, Mapping):
            old_time = old_meta.get("learned_at")
            new_time = meta.get("learned_at")
            if isinstance(old_time, int) and isinstance(new_time, int) and new_time < old_time:
                failures[VerificationDimension.MEMORY_RETCON].append(f"KNOWLEDGE_TIME_REGRESSION:{delta.key}")

    def _check_delta_epistemics(
        self,
        delta: Delta,
        prospective_time: Optional[float],
        failures: dict[VerificationDimension, list[str]],
    ) -> None:
        if delta.writer == Authority.SYSTEM_INIT:
            return
        meta = delta.epistemic
        if not isinstance(meta, Mapping):
            failures[VerificationDimension.NPC_KNOWLEDGE_EPISTEMICS].append(f"EPISTEMIC_METADATA_REQUIRED:{delta.key}")
            return
        learned_at = meta.get("learned_at")
        path = meta.get("path")
        origin = meta.get("origin_location")
        if prospective_time is not None and isinstance(learned_at, int) and learned_at > prospective_time:
            failures[VerificationDimension.NPC_KNOWLEDGE_EPISTEMICS].append(
                f"KNOWLEDGE_FROM_FUTURE:{delta.key}:{learned_at}>{int(prospective_time)}"
            )
        if isinstance(path, (list, tuple)) and path:
            first = path[0]
            if isinstance(first, Mapping) and isinstance(origin, str) and first.get("from") != origin:
                failures[VerificationDimension.NPC_KNOWLEDGE_EPISTEMICS].append(f"KNOWLEDGE_ROUTE_ORIGIN_MISMATCH:{delta.key}")
            previous_to = None
            previous_arrive = None
            for hop in path:
                if not isinstance(hop, Mapping):
                    continue
                if previous_to is not None and hop.get("from") != previous_to:
                    failures[VerificationDimension.NPC_KNOWLEDGE_EPISTEMICS].append(f"KNOWLEDGE_ROUTE_DISCONTINUITY:{delta.key}")
                    break
                depart = hop.get("depart_at")
                if previous_arrive is not None and isinstance(depart, int) and depart < previous_arrive:
                    failures[VerificationDimension.NPC_KNOWLEDGE_EPISTEMICS].append(f"KNOWLEDGE_ROUTE_TIME_OVERLAP:{delta.key}")
                    break
                previous_to = hop.get("to")
                previous_arrive = hop.get("arrive_at")
            if isinstance(previous_arrive, int) and isinstance(learned_at, int) and previous_arrive > learned_at:
                failures[VerificationDimension.NPC_KNOWLEDGE_EPISTEMICS].append(f"KNOWLEDGE_BEFORE_ROUTE_ARRIVAL:{delta.key}")

    def _check_memory_regression(
        self,
        store: StateStore,
        delta: Delta,
        failures: dict[VerificationDimension, list[str]],
    ) -> None:
        existing = _existing_knowledge(store, delta)
        if not isinstance(existing, Mapping):
            return
        old_meta = existing.get("epistemic")
        new_meta = delta.epistemic
        if not isinstance(old_meta, Mapping) or not isinstance(new_meta, Mapping):
            return
        old_time = old_meta.get("learned_at")
        new_time = new_meta.get("learned_at")
        if isinstance(old_time, int) and isinstance(new_time, int) and new_time < old_time:
            failures[VerificationDimension.MEMORY_RETCON].append(f"KNOWLEDGE_TIME_REGRESSION:{delta.key}")

    @staticmethod
    def _report(
        phase: str,
        event_id: Optional[str],
        failures: Mapping[VerificationDimension, Sequence[str]],
        notes: Mapping[VerificationDimension, Sequence[str]],
    ) -> VerificationReport:
        signals = tuple(
            DimensionSignal(dimension, tuple(failures.get(dimension, ())), tuple(notes.get(dimension, ())))
            for dimension in ALL_DIMENSIONS
        )
        if len(signals) != 10:
            raise Stage3FError("TENFOLD_SIGNAL_COUNT_INVALID")
        return VerificationReport(phase, event_id, signals)

    @classmethod
    def _single_hard_failure(
        cls,
        phase: str,
        event_id: Optional[str],
        dimension: VerificationDimension,
        reason: str,
    ) -> VerificationReport:
        failures = {d: [] for d in ALL_DIMENSIONS}
        notes = {d: [] for d in ALL_DIMENSIONS}
        failures[dimension].append(reason)
        return cls._report(phase, event_id, failures, notes)


class CompositeActionVerifier:
    """Run the mandatory tenfold verifier plus an optional caller verifier."""

    def __init__(self, verifiers: Iterable[PreCommitVerifier]) -> None:
        self.verifiers = tuple(verifiers)
        if not self.verifiers:
            raise Stage3FError("COMPOSITE_VERIFIER_EMPTY")

    def verify(self, **kwargs: Any) -> VerificationDecision:
        reasons: list[str] = []
        saw_hold = False
        saw_reject = False
        for verifier in self.verifiers:
            decision = verifier.verify(**kwargs)
            if decision.verdict == Verdict.REJECT:
                saw_reject = True
                reasons.extend(decision.reasons)
            elif decision.verdict == Verdict.HOLD:
                saw_hold = True
                reasons.extend(decision.reasons)
        if saw_reject:
            return VerificationDecision(Verdict.REJECT, tuple(reasons))
        if saw_hold:
            return VerificationDecision(Verdict.HOLD, tuple(reasons))
        return VerificationDecision(Verdict.PASS, ())
