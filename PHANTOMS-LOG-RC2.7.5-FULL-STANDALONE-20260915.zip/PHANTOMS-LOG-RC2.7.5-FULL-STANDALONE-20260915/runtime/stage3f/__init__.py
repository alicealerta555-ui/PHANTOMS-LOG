# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Stage 3F: operational tenfold pre-commit verification gate."""

from .verification import (
    ALL_DIMENSIONS,
    CompositeActionVerifier,
    DimensionSignal,
    Stage3FError,
    TenfoldVerificationGate,
    VerificationDimension,
    VerificationPolicy,
    VerificationReport,
)

__all__ = [
    "ALL_DIMENSIONS",
    "CompositeActionVerifier",
    "DimensionSignal",
    "Stage3FError",
    "TenfoldVerificationGate",
    "VerificationDimension",
    "VerificationPolicy",
    "VerificationReport",
]
