
def cross_effect_candidate(parent_event_id,source_system,target_system,effect_type,payload,causal_event_id):
    if not parent_event_id or not source_system or not target_system or not effect_type: return None
    if source_system==target_system: return None
    return {"kind":"CROSS_SYSTEM_EFFECT_CANDIDATE","parent_event_id":parent_event_id,
            "source_system":source_system,"target_system":target_system,"effect_type":effect_type,
            "payload":dict(payload or {}),"causal_event_id":causal_event_id,"authority_required":True}
def cascade_hop(parent_effect_id,child_effect_type,target_system,causal_event_id):
    if not parent_effect_id or not child_effect_type or not target_system: return None
    return {"kind":"CASCADE_HOP_CANDIDATE","parent_effect_id":parent_effect_id,"child_effect_type":child_effect_type,
            "target_system":target_system,"causal_event_id":causal_event_id,"authority_required":True}
def long_term_projection(current,delta_per_day,elapsed_days,min_value=0,max_value=100):
    if int(elapsed_days)<=0: return max(min_value,min(max_value,int(current)))
    return max(min_value,min(max_value,int(current)+int(delta_per_day)*int(elapsed_days)))
def mitigate(value, mitigation_amount):
    return max(0,int(value)-max(0,int(mitigation_amount)))
def provenance_chain(events):
    if not events: return False
    for i,e in enumerate(events):
        if i==0: continue
        if e.get("parent_event_id") != events[i-1].get("event_id"): return False
    return True
def duplicate_guard(parent_event_id,effect_type,existing_keys):
    return (parent_event_id,effect_type) not in set(existing_keys or [])
