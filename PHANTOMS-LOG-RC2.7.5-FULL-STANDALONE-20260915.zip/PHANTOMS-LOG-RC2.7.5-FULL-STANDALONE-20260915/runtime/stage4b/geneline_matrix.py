# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import asdict, dataclass, fields
from enum import Enum
import hashlib
import json
from typing import Iterable, Optional, Tuple

from runtime.stage4a import SUPEREVOLUTION_PHASES, assert_process_allowed_in_epoch
from runtime.stage4a.biology_timeline import BiologicalProcess


class LinkStatus(str, Enum):
    PENDING_STAGE_4C = "PENDING_STAGE_4C"
    RESOLVED = "RESOLVED"


class StabilityStatus(str, Enum):
    UNASSESSED = "UNASSESSED"
    CONTEXT_DEPENDENT = "CONTEXT_DEPENDENT"
    ROBUST = "ROBUST"


@dataclass(frozen=True)
class NumericRange:
    minimum: float
    maximum: float
    unit: str


@dataclass(frozen=True)
class OriginPackageLink:
    status: LinkStatus = LinkStatus.PENDING_STAGE_4C
    package_refs: Tuple[str, ...] = ()


@dataclass(frozen=True)
class MorphologyProfile:
    body_plan_tags: Tuple[str, ...]
    locomotion_hooks: Tuple[str, ...] = ()
    structural_traits: Tuple[str, ...] = ()
    height_m: Optional[NumericRange] = None
    mass_kg: Optional[NumericRange] = None


@dataclass(frozen=True)
class MetabolismProfile:
    strategy_tags: Tuple[str, ...]
    thermal_strategy_tags: Tuple[str, ...] = ()
    hydration_dependency_tags: Tuple[str, ...] = ()
    energetic_cost_tags: Tuple[str, ...] = ()


@dataclass(frozen=True)
class EnvironmentalEnvelope:
    habitat_tags: Tuple[str, ...]
    temperature_c: Optional[NumericRange] = None
    pressure_kpa: Optional[NumericRange] = None
    oxygen_fraction: Optional[NumericRange] = None
    constraints: Tuple[str, ...] = ()


@dataclass(frozen=True)
class RegenerationProfile:
    capability_tag: str = "NONE"
    cost_tags: Tuple[str, ...] = ()
    constraints: Tuple[str, ...] = ()


@dataclass(frozen=True)
class SensorCapabilityHook:
    hook_id: str
    modality: str
    capability_tags: Tuple[str, ...] = ()
    detail_owner: str = "STAGE_5"


@dataclass(frozen=True)
class StabilityProfile:
    status: StabilityStatus = StabilityStatus.UNASSESSED
    known_conditions: Tuple[str, ...] = ()


@dataclass(frozen=True)
class HybridizationProfile:
    source_lineage_refs: Tuple[str, ...] = ()
    integration_depth_hint: int = 0
    classification_owner: str = "STAGE_4D"


@dataclass(frozen=True)
class KnownBiologicalConstraint:
    constraint_id: str
    domain: str
    statement: str


@dataclass(frozen=True)
class LineageProvenance:
    origin_phase_id: str
    origin_epoch_id: str
    source_refs: Tuple[str, ...]
    authority_domain: str = "WORLD_TRUTH"


@dataclass(frozen=True)
class GenelineRecord:
    lineage_id: str
    display_name: str
    origin_packages: OriginPackageLink
    morphology: MorphologyProfile
    metabolism: MetabolismProfile
    environment: EnvironmentalEnvelope
    regeneration: RegenerationProfile
    sensor_hooks: Tuple[SensorCapabilityHook, ...]
    stability: StabilityProfile
    hybridization: HybridizationProfile
    known_constraints: Tuple[KnownBiologicalConstraint, ...]
    provenance: LineageProvenance


# Generic typed fields are deliberately narrow. These axes may not be smuggled
# into biology via tags because the project treats them as culture/individual/
# agency domains rather than genetic destiny.
FORBIDDEN_BIOLOGICAL_TAG_PREFIXES: Tuple[str, ...] = (
    "morality:",
    "profession:",
    "dominance:",
    "submission:",
    "attraction:",
    "consent:",
    "personality:",
    "loyalty:",
    "obedience:",
)

STAGE5_DETAIL_FIELDS: Tuple[str, ...] = (
    "wavelength_response",
    "acuity_curve",
    "frequency_response_hz",
    "polarization_resolution",
    "echo_model",
)

STAGE6_DETAIL_FIELDS: Tuple[str, ...] = (
    "alleles",
    "dominance_model",
    "recessive_model",
    "germline_rules",
    "inheritance_probability",
    "fertility_compatibility",
)

_PHASE_PROCESS = {
    "B0": BiologicalProcess.THERAPEUTIC_MODIFICATION,
    "B1": BiologicalProcess.DIRECTED_ADAPTATION,
    "B2": BiologicalProcess.DIRECTED_HYBRIDIZATION,
    "B3": BiologicalProcess.REPEATED_MIXING,
    "B4": BiologicalProcess.DISTRIBUTED_SURVIVAL_SELECTION,
    "B5": BiologicalProcess.FREE_DRIFT,
    "B6": BiologicalProcess.STABLE_SUBLINEAGE_FORMATION,
}


def _validate_id(value: str, code: str) -> None:
    if not value or value.strip() != value or any(ch.isspace() for ch in value):
        raise ValueError(code)


def _validate_range(value: Optional[NumericRange], code: str, *, unit: Optional[str] = None) -> None:
    if value is None:
        return
    if value.minimum > value.maximum:
        raise ValueError(f"{code}:MIN_GT_MAX")
    if not value.unit:
        raise ValueError(f"{code}:UNIT_REQUIRED")
    if unit is not None and value.unit != unit:
        raise ValueError(f"{code}:UNIT_INVALID:{value.unit}")


def _iter_typed_tags(record: GenelineRecord) -> Iterable[str]:
    yield from record.morphology.body_plan_tags
    yield from record.morphology.locomotion_hooks
    yield from record.morphology.structural_traits
    yield from record.metabolism.strategy_tags
    yield from record.metabolism.thermal_strategy_tags
    yield from record.metabolism.hydration_dependency_tags
    yield from record.metabolism.energetic_cost_tags
    yield from record.environment.habitat_tags
    for hook in record.sensor_hooks:
        yield hook.modality
        yield from hook.capability_tags


def validate_geneline_record(record: GenelineRecord) -> None:
    _validate_id(record.lineage_id, "GENELINE_ID_INVALID")
    if not record.display_name.strip():
        raise ValueError("GENELINE_DISPLAY_NAME_REQUIRED")

    if record.origin_packages.status == LinkStatus.RESOLVED and not record.origin_packages.package_refs:
        raise ValueError("ORIGIN_PACKAGE_RESOLVED_WITHOUT_REFS")
    if record.origin_packages.status == LinkStatus.PENDING_STAGE_4C and record.origin_packages.package_refs:
        raise ValueError("ORIGIN_PACKAGE_PENDING_WITH_REFS")
    for ref in record.origin_packages.package_refs:
        _validate_id(ref, "ORIGIN_PACKAGE_REF_INVALID")

    if not record.morphology.body_plan_tags:
        raise ValueError("MORPHOLOGY_BODY_PLAN_REQUIRED")
    if not record.metabolism.strategy_tags:
        raise ValueError("METABOLISM_STRATEGY_REQUIRED")
    if not record.environment.habitat_tags:
        raise ValueError("ENVIRONMENT_HABITAT_REQUIRED")

    _validate_range(record.morphology.height_m, "HEIGHT_RANGE", unit="m")
    _validate_range(record.morphology.mass_kg, "MASS_RANGE", unit="kg")
    _validate_range(record.environment.temperature_c, "TEMPERATURE_RANGE", unit="C")
    _validate_range(record.environment.pressure_kpa, "PRESSURE_RANGE", unit="kPa")
    _validate_range(record.environment.oxygen_fraction, "OXYGEN_RANGE", unit="fraction")
    if record.environment.oxygen_fraction is not None:
        if record.environment.oxygen_fraction.minimum < 0 or record.environment.oxygen_fraction.maximum > 1:
            raise ValueError("OXYGEN_RANGE:OUT_OF_BOUNDS")

    if record.regeneration.capability_tag != "NONE" and not (
        record.regeneration.cost_tags or record.regeneration.constraints
    ):
        raise ValueError("REGENERATION_ADVANTAGE_WITHOUT_COST_OR_CONSTRAINT")

    hook_ids = [hook.hook_id for hook in record.sensor_hooks]
    if len(hook_ids) != len(set(hook_ids)):
        raise ValueError("DUPLICATE_SENSOR_HOOK_ID")
    for hook in record.sensor_hooks:
        _validate_id(hook.hook_id, "SENSOR_HOOK_ID_INVALID")
        if not hook.modality.strip():
            raise ValueError("SENSOR_MODALITY_REQUIRED")
        if hook.detail_owner != "STAGE_5":
            raise ValueError("SENSOR_DETAIL_OWNER_MUST_BE_STAGE_5")

    if record.hybridization.integration_depth_hint < 0:
        raise ValueError("HYBRIDIZATION_DEPTH_NEGATIVE")
    if record.hybridization.classification_owner != "STAGE_4D":
        raise ValueError("HYBRID_CLASSIFICATION_OWNER_MUST_BE_STAGE_4D")
    if len(record.hybridization.source_lineage_refs) != len(set(record.hybridization.source_lineage_refs)):
        raise ValueError("DUPLICATE_HYBRID_SOURCE_LINEAGE")
    if record.lineage_id in record.hybridization.source_lineage_refs:
        raise ValueError("GENELINE_CANNOT_BE_ITS_OWN_SOURCE")

    constraint_ids = [item.constraint_id for item in record.known_constraints]
    if len(constraint_ids) != len(set(constraint_ids)):
        raise ValueError("DUPLICATE_BIOLOGICAL_CONSTRAINT_ID")
    for item in record.known_constraints:
        _validate_id(item.constraint_id, "BIOLOGICAL_CONSTRAINT_ID_INVALID")
        if not item.domain.strip() or not item.statement.strip():
            raise ValueError("BIOLOGICAL_CONSTRAINT_INCOMPLETE")

    for tag in _iter_typed_tags(record):
        normalized = tag.strip().lower()
        if any(normalized.startswith(prefix) for prefix in FORBIDDEN_BIOLOGICAL_TAG_PREFIXES):
            raise ValueError(f"GENETIC_DETERMINISM_TAG_FORBIDDEN:{tag}")

    prov = record.provenance
    if prov.authority_domain != "WORLD_TRUTH":
        raise ValueError("GENELINE_PROVENANCE_MUST_BE_WORLD_TRUTH")
    if prov.origin_phase_id not in _PHASE_PROCESS:
        raise ValueError("GENELINE_ORIGIN_PHASE_UNKNOWN")
    if not prov.source_refs:
        raise ValueError("GENELINE_PROVENANCE_SOURCE_REQUIRED")
    process = _PHASE_PROCESS[prov.origin_phase_id]
    assert_process_allowed_in_epoch(process, prov.origin_epoch_id)

    # The data model itself must remain below the Stage-5/6 boundary.
    names = {f.name for f in fields(GenelineRecord)}
    forbidden = set(STAGE5_DETAIL_FIELDS) | set(STAGE6_DETAIL_FIELDS)
    if names & forbidden:
        raise ValueError("GENELINE_SCHEMA_STAGE_BOUNDARY_VIOLATION")


class GenelineMatrix:
    def __init__(self) -> None:
        self._records: dict[str, GenelineRecord] = {}

    def register(self, record: GenelineRecord) -> None:
        validate_geneline_record(record)
        if record.lineage_id in self._records:
            raise ValueError(f"GENELINE_DUPLICATE_ID:{record.lineage_id}")
        self._records[record.lineage_id] = record

    def get(self, lineage_id: str) -> GenelineRecord:
        try:
            return self._records[lineage_id]
        except KeyError as exc:
            raise KeyError(f"GENELINE_NOT_FOUND:{lineage_id}") from exc

    def ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._records))

    def records(self) -> Tuple[GenelineRecord, ...]:
        return tuple(self._records[key] for key in sorted(self._records))

    def canonical_payload(self) -> list[dict]:
        return [asdict(record) for record in self.records()]

    def canonical_digest(self) -> str:
        raw = json.dumps(self.canonical_payload(), sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def __len__(self) -> int:
        return len(self._records)
