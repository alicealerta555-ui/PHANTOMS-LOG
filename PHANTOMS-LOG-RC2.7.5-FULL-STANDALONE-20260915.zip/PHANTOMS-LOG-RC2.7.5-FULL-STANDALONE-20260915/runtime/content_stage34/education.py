
def clamp(v,a,b): return max(a,min(b,v))

def training_progress(current_progress, base_progress, elapsed_min, teacher_quality=50, aptitude=50, fatigue=0, relevance=100):
    if int(elapsed_min)<=0:
        return clamp(int(current_progress),0,100)
    tq=clamp(int(teacher_quality),0,100)
    ap=clamp(int(aptitude),0,100)
    ft=clamp(int(fatigue),0,100)
    rel=clamp(int(relevance),0,100)
    factor=(tq+ap+rel)//3
    factor=factor*(100-ft)//100
    gain=max(0,int(base_progress))*factor//100
    gain=gain*max(1,int(elapsed_min))//60
    return clamp(int(current_progress)+gain,0,100)

def skill_gain_candidate(actor_id, skill_id, current_skill, training_progress_value, causal_event_id):
    if not actor_id or not skill_id or int(training_progress_value)<=0:
        return None
    gain=max(0,int(training_progress_value))//20
    return {
        "kind":"SKILL_GAIN_CANDIDATE",
        "actor_id":actor_id,
        "skill_id":skill_id,
        "current_skill":clamp(int(current_skill),0,100),
        "proposed_skill":clamp(int(current_skill)+gain,0,100),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def certification_record(certificate_id,institution_id,actor_id,skill_id,assessed_level,issued_at):
    return {
        "certificate_id":certificate_id,
        "institution_id":institution_id,
        "actor_id":actor_id,
        "skill_id":skill_id,
        "assessed_level":clamp(int(assessed_level),0,100),
        "issued_at":int(issued_at),
        "writes_skill_directly":False
    }

def institution_access(capacity,current_enrollment,authorized=True):
    if not authorized:
        return False
    return int(current_enrollment) < int(capacity)

def apprenticeship_candidate(actor_id,mentor_actor_id,skill_id,work_context_id,elapsed_min,causal_event_id):
    if not actor_id or not mentor_actor_id or actor_id==mentor_actor_id:
        return None
    if not skill_id or not work_context_id or int(elapsed_min)<=0:
        return None
    return {
        "kind":"APPRENTICESHIP_PROGRESS_CANDIDATE",
        "actor_id":actor_id,
        "mentor_actor_id":mentor_actor_id,
        "skill_id":skill_id,
        "work_context_id":work_context_id,
        "elapsed_min":int(elapsed_min),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def skill_band(value):
    v=clamp(int(value),0,100)
    if v<20: return "NOVICE"
    if v<40: return "BASIC"
    if v<60: return "COMPETENT"
    if v<80: return "ADVANCED"
    return "EXPERT"
