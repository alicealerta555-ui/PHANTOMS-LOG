# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from enum import Enum
import hashlib
import json
from typing import Iterable, Mapping, Tuple

from runtime.stage4b import GenelineRecord
from runtime.stage4c import OriginPackageRegistry, validate_origin_bound_geneline


class InfluenceLayer(str, Enum):
    BIOLOGICAL_DISPOSITION = "BIOLOGICAL_DISPOSITION"
    CULTURE_HISTORY = "CULTURE_HISTORY"
    INDIVIDUAL_PSYCHOLOGY = "INDIVIDUAL_PSYCHOLOGY"
    CURRENT_SITUATION = "CURRENT_SITUATION"
    BEHAVIORAL_ECHO = "BEHAVIORAL_ECHO"


class ResponseLayer(str, Enum):
    PHYSIOLOGICAL = "PHYSIOLOGICAL"
    COGNITIVE = "COGNITIVE"


class CognitiveDomain(str, Enum):
    ATTENTIONAL_SALIENCE = "ATTENTIONAL_SALIENCE"
    ACTIVATION_THRESHOLD = "ACTIVATION_THRESHOLD"
    RECOVERY_TEMPO = "RECOVERY_TEMPO"
    NOVELTY_SALIENCE = "NOVELTY_SALIENCE"
    UNCERTAINTY_TOLERANCE = "UNCERTAINTY_TOLERANCE"
    PATTERN_COMPLETION = "PATTERN_COMPLETION"
    SOCIAL_CUE_SALIENCE = "SOCIAL_CUE_SALIENCE"
    IMPULSE_GATING = "IMPULSE_GATING"


@dataclass(frozen=True)
class BiologicalDisposition:
    disposition_id: str
    domain: CognitiveDomain
    response_layer: ResponseLayer
    signed_strength: float
    trigger_tags: Tuple[str, ...]
    evidence_refs: Tuple[str, ...]
    scope_note: str


@dataclass(frozen=True)
class BehavioralEcho:
    echo_id: str
    domain: CognitiveDomain
    response_layer: ResponseLayer
    signed_strength: float
    trigger_tags: Tuple[str, ...]
    biological_disposition_refs: Tuple[str, ...]
    culture_anchor_refs: Tuple[str, ...]
    evidence_refs: Tuple[str, ...]
    scope_note: str


@dataclass(frozen=True)
class DriftProvenance:
    source_refs: Tuple[str, ...]
    authority_domain: str = "WORLD_TRUTH"


@dataclass(frozen=True)
class CognitiveDriftProfile:
    lineage_id: str
    biological_dispositions: Tuple[BiologicalDisposition, ...]
    behavioral_echoes: Tuple[BehavioralEcho, ...]
    provenance: DriftProvenance
    interpretation_note: str = "population-level influence model; not a diagnosis or individual destiny"


@dataclass(frozen=True)
class ContextInfluence:
    signal_id: str
    layer: InfluenceLayer
    domain: CognitiveDomain
    response_layer: ResponseLayer
    signed_strength: float
    evidence_refs: Tuple[str, ...]
    scope_note: str


@dataclass(frozen=True)
class InfluenceContext:
    culture_history: Tuple[ContextInfluence, ...] = ()
    individual_psychology: Tuple[ContextInfluence, ...] = ()
    current_situation: Tuple[ContextInfluence, ...] = ()
    situation_tags: Tuple[str, ...] = ()


@dataclass(frozen=True)
class InfluenceContribution:
    contribution_id: str
    layer: InfluenceLayer
    domain: CognitiveDomain
    response_layer: ResponseLayer
    signed_strength: float
    source_refs: Tuple[str, ...]
    rationale_code: str


@dataclass(frozen=True)
class DomainPressure:
    domain: CognitiveDomain
    response_layer: ResponseLayer
    net_pressure: float
    has_internal_conflict: bool
    contribution_ids: Tuple[str, ...]


@dataclass(frozen=True)
class InfluenceEnvelope:
    lineage_id: str
    contributions: Tuple[InfluenceContribution, ...]
    domain_pressures: Tuple[DomainPressure, ...]
    unresolved_conflicts: Tuple[str, ...]
    resolution_status: str = "INFLUENCE_ONLY_NO_BEHAVIOR_SELECTED"
    decision_owner: str = "INDIVIDUAL_ACTOR_RUNTIME"


# Biology and biologically/culturally inherited echoes are deliberately bounded.
# They can bias salience/activation/readiness but are never an action selector.
MAX_BIOLOGICAL_SIGNAL_STRENGTH = 0.35
MAX_BEHAVIORAL_ECHO_STRENGTH = 0.25

FORBIDDEN_DETERMINISTIC_TERMS: Tuple[str, ...] = (
    "morality:",
    "personality:",
    "consent:",
    "attraction:",
    "dominance:",
    "submission:",
    "profession:",
    "loyalty:",
    "obedience:",
    "hostility:",
    "will:",
    "decision:",
    "behavior:",
)

_CONTEXT_LAYER_FOR_FIELD = {
    "culture_history": InfluenceLayer.CULTURE_HISTORY,
    "individual_psychology": InfluenceLayer.INDIVIDUAL_PSYCHOLOGY,
    "current_situation": InfluenceLayer.CURRENT_SITUATION,
}


def _validate_id(value: str, code: str) -> None:
    if not value or value.strip() != value or any(ch.isspace() for ch in value):
        raise ValueError(code)


def _validate_refs(values: Tuple[str, ...], *, duplicate: str, invalid: str, required: bool = False) -> None:
    if required and not values:
        raise ValueError(invalid.replace("_INVALID", "_REQUIRED"))
    if len(values) != len(set(values)):
        raise ValueError(duplicate)
    for value in values:
        _validate_id(value, invalid)


def _validate_tags(values: Tuple[str, ...], *, duplicate: str, invalid: str) -> None:
    if len(values) != len(set(values)):
        raise ValueError(duplicate)
    for value in values:
        _validate_id(value, invalid)
        normalized = value.lower()
        if any(normalized.startswith(prefix) for prefix in FORBIDDEN_DETERMINISTIC_TERMS):
            raise ValueError(f"GENETIC_DETERMINISM_TAG_FORBIDDEN:{value}")


def _validate_strength(value: float, maximum: float, code: str) -> None:
    if value == 0:
        raise ValueError(f"{code}:ZERO_NOT_INFORMATIVE")
    if not (-maximum <= value <= maximum):
        raise ValueError(f"{code}:OUT_OF_BOUNDS")


def validate_cognitive_drift_profile(
    lineage: GenelineRecord,
    profile: CognitiveDriftProfile,
    origin_registry: OriginPackageRegistry,
) -> None:
    validate_origin_bound_geneline(lineage, origin_registry)
    if profile.lineage_id != lineage.lineage_id:
        raise ValueError("COGNITIVE_DRIFT_LINEAGE_MISMATCH")
    if profile.provenance.authority_domain != "WORLD_TRUTH":
        raise ValueError("COGNITIVE_DRIFT_PROVENANCE_MUST_BE_WORLD_TRUTH")
    _validate_refs(
        profile.provenance.source_refs,
        duplicate="COGNITIVE_DRIFT_PROVENANCE_DUPLICATE_REF",
        invalid="COGNITIVE_DRIFT_PROVENANCE_SOURCE_REF_INVALID",
        required=True,
    )
    if not profile.interpretation_note.strip():
        raise ValueError("COGNITIVE_DRIFT_INTERPRETATION_NOTE_REQUIRED")
    if not profile.biological_dispositions:
        raise ValueError("COGNITIVE_DRIFT_BIOLOGICAL_DISPOSITION_REQUIRED")

    ids: set[str] = set()
    disposition_ids: set[str] = set()
    for disposition in profile.biological_dispositions:
        _validate_id(disposition.disposition_id, "BIOLOGICAL_DISPOSITION_ID_INVALID")
        if disposition.disposition_id in ids:
            raise ValueError("COGNITIVE_DRIFT_DUPLICATE_SIGNAL_ID")
        ids.add(disposition.disposition_id)
        disposition_ids.add(disposition.disposition_id)
        _validate_strength(disposition.signed_strength, MAX_BIOLOGICAL_SIGNAL_STRENGTH, "BIOLOGICAL_DISPOSITION_STRENGTH")
        _validate_tags(disposition.trigger_tags, duplicate="BIOLOGICAL_DISPOSITION_DUPLICATE_TRIGGER", invalid="BIOLOGICAL_DISPOSITION_TRIGGER_INVALID")
        _validate_refs(
            disposition.evidence_refs,
            duplicate="BIOLOGICAL_DISPOSITION_DUPLICATE_EVIDENCE_REF",
            invalid="BIOLOGICAL_DISPOSITION_EVIDENCE_REF_INVALID",
            required=True,
        )
        if not disposition.scope_note.strip():
            raise ValueError("BIOLOGICAL_DISPOSITION_SCOPE_REQUIRED")

    for echo in profile.behavioral_echoes:
        _validate_id(echo.echo_id, "BEHAVIORAL_ECHO_ID_INVALID")
        if echo.echo_id in ids:
            raise ValueError("COGNITIVE_DRIFT_DUPLICATE_SIGNAL_ID")
        ids.add(echo.echo_id)
        _validate_strength(echo.signed_strength, MAX_BEHAVIORAL_ECHO_STRENGTH, "BEHAVIORAL_ECHO_STRENGTH")
        _validate_tags(echo.trigger_tags, duplicate="BEHAVIORAL_ECHO_DUPLICATE_TRIGGER", invalid="BEHAVIORAL_ECHO_TRIGGER_INVALID")
        _validate_refs(
            echo.biological_disposition_refs,
            duplicate="BEHAVIORAL_ECHO_DUPLICATE_BIO_REF",
            invalid="BEHAVIORAL_ECHO_BIO_REF_INVALID",
            required=True,
        )
        _validate_refs(
            echo.culture_anchor_refs,
            duplicate="BEHAVIORAL_ECHO_DUPLICATE_CULTURE_REF",
            invalid="BEHAVIORAL_ECHO_CULTURE_REF_INVALID",
            required=True,
        )
        _validate_refs(
            echo.evidence_refs,
            duplicate="BEHAVIORAL_ECHO_DUPLICATE_EVIDENCE_REF",
            invalid="BEHAVIORAL_ECHO_EVIDENCE_REF_INVALID",
            required=True,
        )
        missing = set(echo.biological_disposition_refs) - disposition_ids
        if missing:
            raise ValueError(f"BEHAVIORAL_ECHO_UNKNOWN_BIO_DISPOSITION:{','.join(sorted(missing))}")
        if not echo.scope_note.strip():
            raise ValueError("BEHAVIORAL_ECHO_SCOPE_REQUIRED")


def validate_influence_context(context: InfluenceContext) -> None:
    all_ids: set[str] = set()
    for field_name, expected_layer in _CONTEXT_LAYER_FOR_FIELD.items():
        values: Tuple[ContextInfluence, ...] = getattr(context, field_name)
        for signal in values:
            _validate_id(signal.signal_id, "CONTEXT_INFLUENCE_ID_INVALID")
            if signal.signal_id in all_ids:
                raise ValueError("CONTEXT_INFLUENCE_DUPLICATE_ID")
            all_ids.add(signal.signal_id)
            if signal.layer != expected_layer:
                raise ValueError(f"CONTEXT_LAYER_MISMATCH:{field_name}:{signal.layer.value}")
            if not (-1.0 <= signal.signed_strength <= 1.0) or signal.signed_strength == 0:
                raise ValueError("CONTEXT_INFLUENCE_STRENGTH_INVALID")
            _validate_refs(
                signal.evidence_refs,
                duplicate="CONTEXT_INFLUENCE_DUPLICATE_EVIDENCE_REF",
                invalid="CONTEXT_INFLUENCE_EVIDENCE_REF_INVALID",
                required=True,
            )
            if not signal.scope_note.strip():
                raise ValueError("CONTEXT_INFLUENCE_SCOPE_REQUIRED")
    _validate_tags(context.situation_tags, duplicate="CONTEXT_DUPLICATE_SITUATION_TAG", invalid="CONTEXT_SITUATION_TAG_INVALID")


def _active(trigger_tags: Tuple[str, ...], situation_tags: set[str]) -> bool:
    return set(trigger_tags).issubset(situation_tags)


def _contribution(
    contribution_id: str,
    layer: InfluenceLayer,
    domain: CognitiveDomain,
    response_layer: ResponseLayer,
    strength: float,
    source_refs: Iterable[str],
    rationale_code: str,
) -> InfluenceContribution:
    return InfluenceContribution(
        contribution_id=contribution_id,
        layer=layer,
        domain=domain,
        response_layer=response_layer,
        signed_strength=strength,
        source_refs=tuple(sorted(set(source_refs))),
        rationale_code=rationale_code,
    )


def evaluate_influence_envelope(
    lineage: GenelineRecord,
    profile: CognitiveDriftProfile,
    origin_registry: OriginPackageRegistry,
    context: InfluenceContext,
) -> InfluenceEnvelope:
    """Return pressures and conflicts only; never choose an action or preference.

    Causal order is preserved as distinct source layers:
    biology -> culture/history -> individual psychology/values -> situation.
    The output retains every contribution, including opposing signals.
    """
    validate_cognitive_drift_profile(lineage, profile, origin_registry)
    validate_influence_context(context)

    situation_tags = set(context.situation_tags)
    contributions: list[InfluenceContribution] = []

    active_bio_ids: set[str] = set()
    for signal in profile.biological_dispositions:
        if _active(signal.trigger_tags, situation_tags):
            active_bio_ids.add(signal.disposition_id)
            contributions.append(
                _contribution(
                    signal.disposition_id,
                    InfluenceLayer.BIOLOGICAL_DISPOSITION,
                    signal.domain,
                    signal.response_layer,
                    signal.signed_strength,
                    signal.evidence_refs,
                    "BIOLOGICAL_DISPOSITION_ACTIVE",
                )
            )

    culture_ids = {signal.signal_id for signal in context.culture_history}
    for echo in profile.behavioral_echoes:
        if not _active(echo.trigger_tags, situation_tags):
            continue
        if not set(echo.biological_disposition_refs).issubset(active_bio_ids):
            continue
        if not set(echo.culture_anchor_refs).issubset(culture_ids):
            continue
        contributions.append(
            _contribution(
                echo.echo_id,
                InfluenceLayer.BEHAVIORAL_ECHO,
                echo.domain,
                echo.response_layer,
                echo.signed_strength,
                (*echo.biological_disposition_refs, *echo.culture_anchor_refs, *echo.evidence_refs),
                "BIO_CULTURAL_BEHAVIORAL_ECHO_ACTIVE",
            )
        )

    for values in (context.culture_history, context.individual_psychology, context.current_situation):
        for signal in values:
            contributions.append(
                _contribution(
                    signal.signal_id,
                    signal.layer,
                    signal.domain,
                    signal.response_layer,
                    signal.signed_strength,
                    signal.evidence_refs,
                    f"{signal.layer.value}_CONTEXT_ACTIVE",
                )
            )

    # Deterministic ordering without collapsing source information.
    layer_order = {layer: i for i, layer in enumerate(InfluenceLayer)}
    contributions.sort(key=lambda item: (item.domain.value, item.response_layer.value, layer_order[item.layer], item.contribution_id))

    grouped: dict[tuple[CognitiveDomain, ResponseLayer], list[InfluenceContribution]] = {}
    for contribution in contributions:
        grouped.setdefault((contribution.domain, contribution.response_layer), []).append(contribution)

    pressures: list[DomainPressure] = []
    conflicts: list[str] = []
    for (domain, response_layer), items in sorted(grouped.items(), key=lambda item: (item[0][0].value, item[0][1].value)):
        raw = sum(item.signed_strength for item in items)
        net = max(-1.0, min(1.0, raw))
        has_positive = any(item.signed_strength > 0 for item in items)
        has_negative = any(item.signed_strength < 0 for item in items)
        conflict = has_positive and has_negative
        ids = tuple(item.contribution_id for item in items)
        if conflict:
            conflicts.append(f"{domain.value}:{response_layer.value}")
        pressures.append(DomainPressure(domain, response_layer, net, conflict, ids))

    return InfluenceEnvelope(
        lineage_id=lineage.lineage_id,
        contributions=tuple(contributions),
        domain_pressures=tuple(pressures),
        unresolved_conflicts=tuple(conflicts),
    )


class CognitiveDriftRegistry:
    def __init__(self) -> None:
        self._records: dict[str, CognitiveDriftProfile] = {}

    def register(
        self,
        lineage: GenelineRecord,
        profile: CognitiveDriftProfile,
        origin_registry: OriginPackageRegistry,
    ) -> None:
        if lineage.lineage_id in self._records:
            raise ValueError(f"COGNITIVE_DRIFT_PROFILE_DUPLICATE_LINEAGE:{lineage.lineage_id}")
        validate_cognitive_drift_profile(lineage, profile, origin_registry)
        self._records[lineage.lineage_id] = profile

    def get(self, lineage_id: str) -> CognitiveDriftProfile:
        try:
            return self._records[lineage_id]
        except KeyError as exc:
            raise KeyError(f"COGNITIVE_DRIFT_PROFILE_NOT_FOUND:{lineage_id}") from exc

    def ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._records))

    def canonical_payload(self) -> list[dict]:
        payload: list[dict] = []
        for lineage_id in self.ids():
            profile = self._records[lineage_id]
            normalized = replace(
                profile,
                biological_dispositions=tuple(
                    sorted(
                        (
                            replace(
                                item,
                                trigger_tags=tuple(sorted(item.trigger_tags)),
                                evidence_refs=tuple(sorted(item.evidence_refs)),
                            )
                            for item in profile.biological_dispositions
                        ),
                        key=lambda item: item.disposition_id,
                    )
                ),
                behavioral_echoes=tuple(
                    sorted(
                        (
                            replace(
                                item,
                                trigger_tags=tuple(sorted(item.trigger_tags)),
                                biological_disposition_refs=tuple(sorted(item.biological_disposition_refs)),
                                culture_anchor_refs=tuple(sorted(item.culture_anchor_refs)),
                                evidence_refs=tuple(sorted(item.evidence_refs)),
                            )
                            for item in profile.behavioral_echoes
                        ),
                        key=lambda item: item.echo_id,
                    )
                ),
                provenance=replace(profile.provenance, source_refs=tuple(sorted(profile.provenance.source_refs))),
            )
            payload.append(asdict(normalized))
        return payload

    def canonical_digest(self) -> str:
        raw = json.dumps(self.canonical_payload(), sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def __len__(self) -> int:
        return len(self._records)
