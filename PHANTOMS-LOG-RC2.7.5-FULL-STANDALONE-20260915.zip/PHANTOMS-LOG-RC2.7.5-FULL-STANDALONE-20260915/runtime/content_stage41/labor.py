
def job_offer(employer_id, worker_actor_id, job_type, contract_type, wage_rate, offered_at):
    if not employer_id or not worker_actor_id or not job_type or not contract_type:
        return None
    return {"kind":"JOB_OFFER","employer_id":employer_id,"worker_actor_id":worker_actor_id,
            "job_type":job_type,"contract_type":contract_type,"wage_rate":max(0,float(wage_rate)),
            "offered_at":int(offered_at),"accepted":False}

def accept_job(offer, actor_id, causal_event_id):
    if not offer or actor_id != offer.get("worker_actor_id"):
        return None
    out=dict(offer)
    out.update({"accepted":True,"kind":"EMPLOYMENT_ACCEPTANCE_CANDIDATE",
                "causal_event_id":causal_event_id,"authority_required":True})
    return out

def wage_entitlement(contract_type, wage_rate, hours_worked=0, task_complete=False, period_due=False):
    rate=max(0,float(wage_rate))
    if contract_type=="CONTRACT_HOURLY": return max(0.0,float(hours_worked))*rate
    if contract_type=="CONTRACT_TASK": return rate if task_complete else 0.0
    if contract_type=="CONTRACT_SALARY": return rate if period_due else 0.0
    if contract_type=="CONTRACT_APPRENTICE": return max(0.0,float(hours_worked))*rate
    return 0.0

def payroll_proposal(employer_id,worker_actor_id,amount,available_funds,basis_ref,causal_event_id):
    amount=max(0,float(amount)); funds=max(0,float(available_funds))
    if amount<=0 or amount>funds: return None
    return {"kind":"PAYROLL_PAYMENT_PROPOSAL","employer_id":employer_id,"worker_actor_id":worker_actor_id,
            "amount":amount,"basis_ref":basis_ref,"causal_event_id":causal_event_id,"authority_required":True}

def unemployment_state(has_active_contract, seeking_work):
    if has_active_contract: return "EMPLOYED"
    return "UNEMPLOYED" if seeking_work else "OUT_OF_LABOR_FORCE"

def workplace_order(issuer_actor_id,target_actor_id,role_authority,required_authority,action,causal_event_id):
    if int(role_authority) < int(required_authority): return None
    return {"kind":"WORKPLACE_ORDER_REQUEST","issuer_actor_id":issuer_actor_id,
            "target_actor_id":target_actor_id,"action":action,
            "requires_actor_decision":True,"causal_event_id":causal_event_id}

def labor_record(worker_actor_id,workplace_id,hours,task_ref,performed_at):
    if not worker_actor_id or not workplace_id or float(hours)<0: return None
    return {"worker_actor_id":worker_actor_id,"workplace_id":workplace_id,"hours":float(hours),
            "task_ref":task_ref,"performed_at":int(performed_at)}
