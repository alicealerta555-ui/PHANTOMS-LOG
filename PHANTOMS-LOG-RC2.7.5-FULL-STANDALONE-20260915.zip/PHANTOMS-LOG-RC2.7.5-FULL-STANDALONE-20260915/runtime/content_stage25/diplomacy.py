
def clamp(v,a,b): return max(a,min(b,v))

def relation_delta(current, delta):
    bounds={
        "trust":(-100,100),"hostility":(-100,100),"trade_dependency":(0,100),
        "grievance":(0,100),"fear":(0,100),"respect":(-100,100)
    }
    out=dict(current)
    for k,v in delta.items():
        lo,hi=bounds.get(k,(-100,100))
        out[k]=clamp(int(out.get(k,0))+int(v),lo,hi)
    return out

def treaty_offer(treaty_id, treaty_type, party_a, party_b, terms, offered_at):
    return {
        "kind":"TREATY_OFFER",
        "treaty_id":treaty_id,
        "treaty_type":treaty_type,
        "party_a":party_a,
        "party_b":party_b,
        "terms":dict(terms or {}),
        "accepted_by_a":False,
        "accepted_by_b":False,
        "offered_at":int(offered_at)
    }

def treaty_accept(offer, party_id, effective_time):
    if party_id not in (offer.get("party_a"),offer.get("party_b")):
        return None
    out=dict(offer)
    if party_id==out["party_a"]:
        out["accepted_by_a"]=True
    else:
        out["accepted_by_b"]=True
    out["effective_time"]=int(effective_time)
    out["active"]=bool(out["accepted_by_a"] and out["accepted_by_b"])
    out["authority_required"]=True
    return out

def war_candidate(party_a, party_b, trigger, causal_event_id):
    if not party_a or not party_b or party_a==party_b or not trigger:
        return None
    return {
        "kind":"WAR_STATE_CANDIDATE",
        "party_a":party_a,
        "party_b":party_b,
        "trigger":trigger,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def ceasefire_candidate(party_a, party_b, scope, effective_time, expiry_time, causal_event_id):
    if not party_a or not party_b or party_a==party_b or not scope:
        return None
    return {
        "kind":"CEASEFIRE_CANDIDATE",
        "party_a":party_a,
        "party_b":party_b,
        "scope":scope,
        "effective_time":int(effective_time),
        "expiry_time":None if expiry_time is None else int(expiry_time),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def diplomatic_state(current_state, treaty_active=False, war_committed=False, ceasefire_active=False):
    if war_committed and ceasefire_active:
        return "CEASEFIRE"
    if war_committed:
        return "WAR"
    if treaty_active and current_state in ("COOPERATIVE","ALLIED"):
        return current_state
    if treaty_active:
        return "COOPERATIVE"
    return current_state
