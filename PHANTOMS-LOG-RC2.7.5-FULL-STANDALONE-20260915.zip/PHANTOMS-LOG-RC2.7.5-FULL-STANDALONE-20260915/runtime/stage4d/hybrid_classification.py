# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import asdict, dataclass, fields, replace
from enum import Enum
import hashlib
import json
from typing import Iterable, Tuple

from runtime.stage4a import assert_process_allowed_in_epoch
from runtime.stage4a.biology_timeline import BiologicalProcess
from runtime.stage4b import (
    STAGE5_DETAIL_FIELDS,
    STAGE6_DETAIL_FIELDS,
    GenelineRecord,
    HybridizationProfile,
    LinkStatus,
)
from runtime.stage4c import OriginPackageRegistry, validate_origin_bound_geneline


class HybridClass(str, Enum):
    MONO = "MONO"
    MULTI = "MULTI"
    POLY = "POLY"


class IntegrationMode(str, Enum):
    DIRECTED_HYBRIDIZATION = "DIRECTED_HYBRIDIZATION"
    REPEATED_MIXING = "REPEATED_MIXING"


class CoherenceStatus(str, Enum):
    UNASSESSED = "UNASSESSED"
    COHERENT = "COHERENT"
    CONTEXT_DEPENDENT = "CONTEXT_DEPENDENT"
    CONFLICTED = "CONFLICTED"


@dataclass(frozen=True, order=True)
class HybridSourceComponent:
    component_id: str
    source_lineage_ref: str
    origin_package_refs: Tuple[str, ...]


@dataclass(frozen=True)
class IntegrationNode:
    node_id: str
    phase_id: str
    epoch_id: str
    mode: IntegrationMode
    input_refs: Tuple[str, ...]


@dataclass(frozen=True, order=True)
class TraitCandidateRef:
    """Source-qualified Stage-4C candidate reference.

    This is an expression-space reference only. `latent` here does not encode
    germline inheritance, alleles, penetrance or Stage-6 mechanics.
    """

    component_id: str
    package_id: str
    contribution_id: str


@dataclass(frozen=True)
class ExpressionPartition:
    active_candidate_refs: Tuple[TraitCandidateRef, ...] = ()
    latent_candidate_refs: Tuple[TraitCandidateRef, ...] = ()
    conditional_candidate_refs: Tuple[TraitCandidateRef, ...] = ()


@dataclass(frozen=True)
class CoherenceAssessment:
    status: CoherenceStatus = CoherenceStatus.UNASSESSED
    evidence_refs: Tuple[str, ...] = ()
    conflict_refs: Tuple[str, ...] = ()


@dataclass(frozen=True)
class HybridCompositionProvenance:
    source_refs: Tuple[str, ...]
    authority_domain: str = "WORLD_TRUTH"


@dataclass(frozen=True)
class HybridCompositionRecord:
    lineage_id: str
    components: Tuple[HybridSourceComponent, ...]
    integration_nodes: Tuple[IntegrationNode, ...]
    root_ref: str
    expression: ExpressionPartition
    coherence: CoherenceAssessment
    provenance: HybridCompositionProvenance


@dataclass(frozen=True)
class HybridClassification:
    lineage_id: str
    hybrid_class: HybridClass
    independent_source_count: int
    integration_depth: int
    root_ref: str
    active_candidate_count: int
    latent_candidate_count: int
    conditional_candidate_count: int
    unassigned_candidate_count: int
    coherence_status: CoherenceStatus
    rationale_codes: Tuple[str, ...]


_MODE_PROCESS = {
    IntegrationMode.DIRECTED_HYBRIDIZATION: BiologicalProcess.DIRECTED_HYBRIDIZATION,
    IntegrationMode.REPEATED_MIXING: BiologicalProcess.REPEATED_MIXING,
}
_MODE_PHASE = {
    IntegrationMode.DIRECTED_HYBRIDIZATION: "B2",
    IntegrationMode.REPEATED_MIXING: "B3",
}
_PHASE_ORDER = {"B2": 2, "B3": 3}


def _validate_id(value: str, code: str) -> None:
    if not value or value.strip() != value or any(ch.isspace() for ch in value):
        raise ValueError(code)


def _validate_ref_tuple(values: Tuple[str, ...], duplicate_code: str, invalid_code: str) -> None:
    if len(values) != len(set(values)):
        raise ValueError(duplicate_code)
    for value in values:
        _validate_id(value, invalid_code)


def _candidate_refs_for_component(
    component: HybridSourceComponent,
    registry: OriginPackageRegistry,
) -> set[TraitCandidateRef]:
    refs: set[TraitCandidateRef] = set()
    for package_id in component.origin_package_refs:
        package = registry.get(package_id)
        for contribution in package.contributions:
            refs.add(TraitCandidateRef(component.component_id, package_id, contribution.contribution_id))
    return refs


def _all_candidate_refs(
    composition: HybridCompositionRecord,
    registry: OriginPackageRegistry,
) -> set[TraitCandidateRef]:
    refs: set[TraitCandidateRef] = set()
    for component in composition.components:
        refs.update(_candidate_refs_for_component(component, registry))
    return refs


def _validate_coherence(value: CoherenceAssessment) -> None:
    _validate_ref_tuple(value.evidence_refs, "HYBRID_COHERENCE_DUPLICATE_EVIDENCE_REF", "HYBRID_COHERENCE_EVIDENCE_REF_INVALID")
    _validate_ref_tuple(value.conflict_refs, "HYBRID_COHERENCE_DUPLICATE_CONFLICT_REF", "HYBRID_COHERENCE_CONFLICT_REF_INVALID")
    if value.status == CoherenceStatus.UNASSESSED and (value.evidence_refs or value.conflict_refs):
        raise ValueError("HYBRID_COHERENCE_UNASSESSED_WITH_EVIDENCE")
    if value.status == CoherenceStatus.COHERENT:
        if not value.evidence_refs:
            raise ValueError("HYBRID_COHERENCE_COHERENT_REQUIRES_EVIDENCE")
        if value.conflict_refs:
            raise ValueError("HYBRID_COHERENCE_COHERENT_WITH_CONFLICTS")
    if value.status == CoherenceStatus.CONTEXT_DEPENDENT and not (value.evidence_refs and value.conflict_refs):
        raise ValueError("HYBRID_COHERENCE_CONTEXT_DEPENDENT_REQUIRES_BOTH")
    if value.status == CoherenceStatus.CONFLICTED and not value.conflict_refs:
        raise ValueError("HYBRID_COHERENCE_CONFLICTED_REQUIRES_CONFLICT")


def _validate_expression(
    composition: HybridCompositionRecord,
    registry: OriginPackageRegistry,
) -> int:
    possible = _all_candidate_refs(composition, registry)
    partitions = (
        composition.expression.active_candidate_refs,
        composition.expression.latent_candidate_refs,
        composition.expression.conditional_candidate_refs,
    )
    for values in partitions:
        if len(values) != len(set(values)):
            raise ValueError("HYBRID_EXPRESSION_DUPLICATE_CANDIDATE")
        unknown = set(values) - possible
        if unknown:
            raise ValueError(f"HYBRID_EXPRESSION_UNKNOWN_CANDIDATE:{sorted(unknown)}")
    active, latent, conditional = map(set, partitions)
    if active & latent or active & conditional or latent & conditional:
        raise ValueError("HYBRID_EXPRESSION_PARTITIONS_OVERLAP")
    return len(possible - active - latent - conditional)


def _graph_metrics(composition: HybridCompositionRecord) -> tuple[int, set[str], set[str]]:
    component_ids = {item.component_id for item in composition.components}
    nodes = {item.node_id: item for item in composition.integration_nodes}
    namespace = component_ids | set(nodes)
    if composition.root_ref not in namespace:
        raise ValueError("HYBRID_ROOT_REF_UNKNOWN")

    visiting: set[str] = set()
    visited_nodes: set[str] = set()
    reachable_components: set[str] = set()

    def walk(ref: str) -> int:
        if ref in component_ids:
            reachable_components.add(ref)
            return 0
        if ref in visiting:
            raise ValueError("HYBRID_INTEGRATION_GRAPH_CYCLE")
        node = nodes.get(ref)
        if node is None:
            raise ValueError(f"HYBRID_INTEGRATION_INPUT_UNKNOWN:{ref}")
        visiting.add(ref)
        depths = [walk(child) for child in node.input_refs]
        visiting.remove(ref)
        visited_nodes.add(ref)
        return 1 + max(depths)

    depth = walk(composition.root_ref)
    orphan_components = component_ids - reachable_components
    orphan_nodes = set(nodes) - visited_nodes
    if orphan_components:
        raise ValueError(f"HYBRID_ORPHAN_SOURCE_COMPONENT:{sorted(orphan_components)}")
    if orphan_nodes:
        raise ValueError(f"HYBRID_ORPHAN_INTEGRATION_NODE:{sorted(orphan_nodes)}")
    return depth, reachable_components, visited_nodes


def validate_hybrid_composition(
    lineage: GenelineRecord,
    composition: HybridCompositionRecord,
    registry: OriginPackageRegistry,
) -> None:
    validate_origin_bound_geneline(lineage, registry)
    if composition.lineage_id != lineage.lineage_id:
        raise ValueError("HYBRID_COMPOSITION_LINEAGE_MISMATCH")
    if composition.provenance.authority_domain != "WORLD_TRUTH":
        raise ValueError("HYBRID_COMPOSITION_PROVENANCE_MUST_BE_WORLD_TRUTH")
    if not composition.provenance.source_refs:
        raise ValueError("HYBRID_COMPOSITION_PROVENANCE_SOURCE_REQUIRED")
    _validate_ref_tuple(composition.provenance.source_refs, "HYBRID_PROVENANCE_DUPLICATE_SOURCE_REF", "HYBRID_PROVENANCE_SOURCE_REF_INVALID")

    if not composition.components:
        raise ValueError("HYBRID_SOURCE_COMPONENT_REQUIRED")
    component_ids = [item.component_id for item in composition.components]
    source_refs = [item.source_lineage_ref for item in composition.components]
    if len(component_ids) != len(set(component_ids)):
        raise ValueError("HYBRID_DUPLICATE_COMPONENT_ID")
    if len(source_refs) != len(set(source_refs)):
        raise ValueError("HYBRID_DUPLICATE_SOURCE_LINEAGE")

    bound_packages = set(lineage.origin_packages.package_refs)
    component_package_union: set[str] = set()
    for component in composition.components:
        _validate_id(component.component_id, "HYBRID_COMPONENT_ID_INVALID")
        _validate_id(component.source_lineage_ref, "HYBRID_SOURCE_LINEAGE_REF_INVALID")
        if component.source_lineage_ref == lineage.lineage_id:
            raise ValueError("HYBRID_LINEAGE_CANNOT_BE_ITS_OWN_SOURCE")
        if not component.origin_package_refs:
            raise ValueError("HYBRID_COMPONENT_ORIGIN_PACKAGE_REQUIRED")
        if len(component.origin_package_refs) != len(set(component.origin_package_refs)):
            raise ValueError("HYBRID_COMPONENT_DUPLICATE_PACKAGE_REF")
        for package_ref in component.origin_package_refs:
            registry.get(package_ref)
            if package_ref not in bound_packages:
                raise ValueError(f"HYBRID_COMPONENT_PACKAGE_NOT_BOUND:{package_ref}")
            component_package_union.add(package_ref)

    if component_package_union != bound_packages:
        missing = sorted(bound_packages - component_package_union)
        extra = sorted(component_package_union - bound_packages)
        raise ValueError(f"HYBRID_COMPONENT_PACKAGE_COVERAGE_MISMATCH:missing={missing}:extra={extra}")

    existing_sources = set(lineage.hybridization.source_lineage_refs)
    composition_sources = set(source_refs)
    if existing_sources and existing_sources != composition_sources:
        raise ValueError("HYBRID_SOURCE_LINEAGE_SET_MISMATCH")

    node_ids = [item.node_id for item in composition.integration_nodes]
    if len(node_ids) != len(set(node_ids)):
        raise ValueError("HYBRID_DUPLICATE_INTEGRATION_NODE_ID")
    if set(node_ids) & set(component_ids):
        raise ValueError("HYBRID_GRAPH_NAMESPACE_COLLISION")
    namespace = set(component_ids) | set(node_ids)
    node_by_id = {item.node_id: item for item in composition.integration_nodes}
    for node in composition.integration_nodes:
        _validate_id(node.node_id, "HYBRID_INTEGRATION_NODE_ID_INVALID")
        if len(node.input_refs) < 2:
            raise ValueError("HYBRID_INTEGRATION_REQUIRES_TWO_INPUTS")
        if len(node.input_refs) != len(set(node.input_refs)):
            raise ValueError("HYBRID_INTEGRATION_DUPLICATE_INPUT")
        if node.node_id in node.input_refs:
            raise ValueError("HYBRID_INTEGRATION_SELF_REFERENCE")
        for ref in node.input_refs:
            if ref not in namespace:
                raise ValueError(f"HYBRID_INTEGRATION_INPUT_UNKNOWN:{ref}")
        expected_phase = _MODE_PHASE[node.mode]
        if node.phase_id != expected_phase:
            raise ValueError(f"HYBRID_INTEGRATION_MODE_PHASE_MISMATCH:{node.node_id}")
        assert_process_allowed_in_epoch(_MODE_PROCESS[node.mode], node.epoch_id)
        if node.mode == IntegrationMode.DIRECTED_HYBRIDIZATION and any(ref in node_by_id for ref in node.input_refs):
            raise ValueError("DIRECTED_HYBRIDIZATION_CANNOT_USE_COMPOSITE_INPUT")

    # Child integration events cannot happen after the event that consumes them.
    for node in composition.integration_nodes:
        for ref in node.input_refs:
            child = node_by_id.get(ref)
            if child and _PHASE_ORDER[child.phase_id] > _PHASE_ORDER[node.phase_id]:
                raise ValueError("HYBRID_INTEGRATION_CHRONOLOGY_REVERSED")

    depth, _, _ = _graph_metrics(composition)
    if depth >= 2:
        root_node = node_by_id.get(composition.root_ref)
        if root_node is None or root_node.mode != IntegrationMode.REPEATED_MIXING:
            raise ValueError("NESTED_HYBRIDIZATION_REQUIRES_REPEATED_MIXING_ROOT")

    _validate_expression(composition, registry)
    _validate_coherence(composition.coherence)

    # Stage 4D must not acquire Stage-5/6 owned schema by stealth.
    names = {f.name for f in fields(HybridCompositionRecord)}
    forbidden = set(STAGE5_DETAIL_FIELDS) | set(STAGE6_DETAIL_FIELDS)
    if names & forbidden:
        raise ValueError("HYBRID_COMPOSITION_SCHEMA_STAGE_BOUNDARY_VIOLATION")


def classify_hybrid(
    lineage: GenelineRecord,
    composition: HybridCompositionRecord,
    registry: OriginPackageRegistry,
) -> HybridClassification:
    validate_hybrid_composition(lineage, composition, registry)
    depth, reachable_components, _ = _graph_metrics(composition)
    source_count = len(reachable_components)

    if source_count == 1:
        hybrid_class = HybridClass.MONO
        rationale = ("SINGLE_INDEPENDENT_SOURCE_COMPLEX",)
    elif source_count >= 3 and depth >= 2:
        hybrid_class = HybridClass.POLY
        rationale = (
            "MULTIPLE_INDEPENDENT_SOURCE_COMPLEXES",
            "NESTED_COMPOSITE_ANCESTRY",
        )
    else:
        hybrid_class = HybridClass.MULTI
        rationale = (
            "MULTIPLE_INDEPENDENT_SOURCE_COMPLEXES",
            "NO_POLY_NESTED_ANCESTRY_THRESHOLD",
        )

    unassigned = _validate_expression(composition, registry)
    return HybridClassification(
        lineage_id=lineage.lineage_id,
        hybrid_class=hybrid_class,
        independent_source_count=source_count,
        integration_depth=depth,
        root_ref=composition.root_ref,
        active_candidate_count=len(composition.expression.active_candidate_refs),
        latent_candidate_count=len(composition.expression.latent_candidate_refs),
        conditional_candidate_count=len(composition.expression.conditional_candidate_refs),
        unassigned_candidate_count=unassigned,
        coherence_status=composition.coherence.status,
        rationale_codes=rationale,
    )


def apply_hybrid_composition(
    lineage: GenelineRecord,
    composition: HybridCompositionRecord,
    registry: OriginPackageRegistry,
) -> tuple[GenelineRecord, HybridClassification]:
    classification = classify_hybrid(lineage, composition, registry)
    source_refs = tuple(sorted(item.source_lineage_ref for item in composition.components))
    updated = replace(
        lineage,
        hybridization=HybridizationProfile(
            source_lineage_refs=source_refs,
            integration_depth_hint=classification.integration_depth,
            classification_owner="STAGE_4D",
        ),
    )
    return updated, classification


class HybridCompositionRegistry:
    def __init__(self) -> None:
        self._records: dict[str, tuple[HybridCompositionRecord, HybridClassification]] = {}

    def register(
        self,
        lineage: GenelineRecord,
        composition: HybridCompositionRecord,
        origin_registry: OriginPackageRegistry,
    ) -> HybridClassification:
        if lineage.lineage_id in self._records:
            raise ValueError(f"HYBRID_COMPOSITION_DUPLICATE_LINEAGE:{lineage.lineage_id}")
        _, classification = apply_hybrid_composition(lineage, composition, origin_registry)
        self._records[lineage.lineage_id] = (composition, classification)
        return classification

    def get(self, lineage_id: str) -> tuple[HybridCompositionRecord, HybridClassification]:
        try:
            return self._records[lineage_id]
        except KeyError as exc:
            raise KeyError(f"HYBRID_COMPOSITION_NOT_FOUND:{lineage_id}") from exc

    def ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._records))

    def canonical_payload(self) -> list[dict]:
        payload: list[dict] = []
        for key in self.ids():
            composition, classification = self._records[key]
            normalized = replace(
                composition,
                components=tuple(sorted(
                    (replace(c, origin_package_refs=tuple(sorted(c.origin_package_refs))) for c in composition.components),
                    key=lambda c: c.component_id,
                )),
                integration_nodes=tuple(sorted(
                    (replace(n, input_refs=tuple(sorted(n.input_refs))) for n in composition.integration_nodes),
                    key=lambda n: n.node_id,
                )),
                expression=ExpressionPartition(
                    tuple(sorted(composition.expression.active_candidate_refs)),
                    tuple(sorted(composition.expression.latent_candidate_refs)),
                    tuple(sorted(composition.expression.conditional_candidate_refs)),
                ),
                coherence=CoherenceAssessment(
                    composition.coherence.status,
                    tuple(sorted(composition.coherence.evidence_refs)),
                    tuple(sorted(composition.coherence.conflict_refs)),
                ),
                provenance=HybridCompositionProvenance(
                    tuple(sorted(composition.provenance.source_refs)),
                    composition.provenance.authority_domain,
                ),
            )
            payload.append({"composition": asdict(normalized), "classification": asdict(classification)})
        return payload

    def canonical_digest(self) -> str:
        raw = json.dumps(self.canonical_payload(), sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def __len__(self) -> int:
        return len(self._records)
