
def ownership_record(property_id, holder_actor_id, basis, acquired_at):
    return {
        "property_id":property_id,
        "holder_actor_id":holder_actor_id,
        "basis":basis,
        "acquired_at":int(acquired_at)
    }

def access_allowed(actor_id, ownership, permissions, required_rights=None):
    rights=set(required_rights or ["OWNER","TENANT","GUEST","EMPLOYEE","LICENSED","AUTHORIZED_OFFICIAL"])
    if ownership and ownership.get("holder_actor_id")==actor_id and "OWNER" in rights:
        return True
    for p in permissions or []:
        if p.get("actor_id")==actor_id and p.get("right") in rights and p.get("active",True):
            return True
    return False

def occupancy_candidate(property_id, actor_id, state, causal_event_id):
    return {
        "kind":"OCCUPANCY_CANDIDATE",
        "property_id":property_id,
        "actor_id":actor_id,
        "state":state,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def trespass_candidate(property_id, actor_id, protected, permission_valid, presence_committed, causal_event_id):
    actionable=bool(protected) and (not bool(permission_valid)) and bool(presence_committed)
    return {
        "kind":"TRESPASS_CANDIDATE",
        "property_id":property_id,
        "actor_id":actor_id,
        "actionable":actionable,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def transfer_proposal(property_id, from_actor_id, to_actor_id, transfer_type, causal_event_id, consideration=None, authority_basis=None):
    if not property_id or not from_actor_id or not to_actor_id or from_actor_id==to_actor_id:
        return None
    return {
        "kind":"PROPERTY_TRANSFER_PROPOSAL",
        "property_id":property_id,
        "from_actor_id":from_actor_id,
        "to_actor_id":to_actor_id,
        "transfer_type":transfer_type,
        "consideration":consideration,
        "authority_basis":authority_basis,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def access_revocation_proposal(property_id, actor_id, reason, causal_event_id, authority_basis=None):
    if not reason:
        return None
    return {
        "kind":"ACCESS_REVOCATION_PROPOSAL",
        "property_id":property_id,
        "actor_id":actor_id,
        "reason":reason,
        "authority_basis":authority_basis,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }
