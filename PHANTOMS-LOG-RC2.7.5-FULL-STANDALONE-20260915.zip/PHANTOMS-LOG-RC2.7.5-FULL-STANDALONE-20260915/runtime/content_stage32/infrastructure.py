
def clamp(v,a,b): return max(a,min(b,v))

def materials_sufficient(required, available):
    for item,qty in required.items():
        if int(available.get(item,0)) < int(qty):
            return False
    return True

def project_progress(current_progress, labor_hours_added, labor_hours_required, materials_ok, elapsed_min):
    if not materials_ok or int(elapsed_min)<=0 or float(labor_hours_added)<=0 or float(labor_hours_required)<=0:
        return clamp(int(current_progress),0,100)
    gain=int(round(float(labor_hours_added)/float(labor_hours_required)*100))
    return clamp(int(current_progress)+gain,0,100)

def construction_candidate(project_id, project_type, site_location_id, sponsor_id, progress, causal_event_id):
    if not project_id or not project_type or not site_location_id:
        return None
    return {
        "kind":"CONSTRUCTION_PROGRESS_CANDIDATE",
        "project_id":project_id,
        "project_type":project_type,
        "site_location_id":site_location_id,
        "sponsor_id":sponsor_id,
        "progress":clamp(int(progress),0,100),
        "completed":int(progress)>=100,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def utility_service(capacity, demand, condition):
    cap=max(0,int(capacity))*clamp(int(condition),0,100)//100
    dem=max(0,int(demand))
    served=min(cap,dem)
    shortage=max(0,dem-served)
    return {"effective_capacity":cap,"served":served,"shortage":shortage}

def decay_projection(condition, decay_per_day, elapsed_min):
    if int(elapsed_min)<=0:
        return clamp(int(condition),0,100)
    days=max(0,int(elapsed_min))/1440.0
    loss=int(round(float(decay_per_day)*days))
    return clamp(int(condition)-loss,0,100)

def maintenance_candidate(asset_id, profile, current_condition, resources_available, causal_event_id):
    if not bool(resources_available):
        return None
    restored=clamp(int(current_condition)+int(profile["restore_condition"]),0,100)
    return {
        "kind":"MAINTENANCE_CANDIDATE",
        "asset_id":asset_id,
        "profile_id":profile["id"],
        "condition_before":clamp(int(current_condition),0,100),
        "condition_after":restored,
        "duration_min":int(profile["duration_min"]),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def infrastructure_state(condition):
    c=clamp(int(condition),0,100)
    if c<=0: return "DESTROYED"
    if c<20: return "FAILED"
    if c<60: return "DEGRADED"
    return "OPERATIONAL"
