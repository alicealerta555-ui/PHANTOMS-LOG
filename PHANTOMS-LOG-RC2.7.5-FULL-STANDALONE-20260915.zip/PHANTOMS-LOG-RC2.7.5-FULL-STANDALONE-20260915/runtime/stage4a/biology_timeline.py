# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Mapping, Tuple

from runtime.core.chronology import CANONICAL_EPOCHS, CRY_T0


SUPEREVOLUTION_MIN_LEAD_YEARS = 2_000
SUPEREVOLUTION_LATEST_START_CRY = CRY_T0 - SUPEREVOLUTION_MIN_LEAD_YEARS


class BiologicalProcess(str, Enum):
    THERAPEUTIC_MODIFICATION = "THERAPEUTIC_MODIFICATION"
    DIRECTED_ADAPTATION = "DIRECTED_ADAPTATION"
    DIRECTED_HYBRIDIZATION = "DIRECTED_HYBRIDIZATION"
    REPEATED_MIXING = "REPEATED_MIXING"
    DISTRIBUTED_SURVIVAL_SELECTION = "DISTRIBUTED_SURVIVAL_SELECTION"
    FREE_DRIFT = "FREE_DRIFT"
    STABLE_SUBLINEAGE_FORMATION = "STABLE_SUBLINEAGE_FORMATION"


@dataclass(frozen=True)
class BiologicalPhase:
    phase_id: str
    order: int
    title: str
    canonical_epochs: Tuple[str, ...]
    processes: Tuple[BiologicalProcess, ...]
    prerequisites: Tuple[str, ...] = ()
    causal_rule: str = ""
    allows_divergent_lineages: bool = False
    requires_control_failure: bool = False


# Stage 4A refines the Stage-2 causal spine; it does not replace it and it does not
# assign exact dates that the current canon has not established.
SUPEREVOLUTION_PHASES: Tuple[BiologicalPhase, ...] = (
    BiologicalPhase(
        "B0",
        0,
        "Bounded therapeutic precursors",
        ("E0", "E1"),
        (BiologicalProcess.THERAPEUTIC_MODIFICATION,),
        causal_rule="Biotechnology first exists as bounded intervention before broad lineage engineering.",
    ),
    BiologicalPhase(
        "B1",
        1,
        "Directed adaptation",
        ("E1",),
        (BiologicalProcess.DIRECTED_ADAPTATION,),
        ("B0",),
        causal_rule="Engineered adaptation expands only after precursor capability exists.",
    ),
    BiologicalPhase(
        "B2",
        2,
        "Directed hybridization",
        ("E2",),
        (BiologicalProcess.DIRECTED_HYBRIDIZATION,),
        ("B1",),
        causal_rule="Deliberate cross-lineage construction belongs to expanded Gen-Slicing, not the precursor era.",
    ),
    BiologicalPhase(
        "B3",
        3,
        "Repeated and distributed mixing",
        ("E2", "E3"),
        (BiologicalProcess.REPEATED_MIXING,),
        ("B2",),
        causal_rule="Repeated mixing becomes possible after hybridization spreads through populations and institutions.",
    ),
    BiologicalPhase(
        "B4",
        4,
        "Distributed survival selection",
        ("E3", "E4"),
        (BiologicalProcess.DISTRIBUTED_SURVIVAL_SELECTION,),
        ("B3",),
        causal_rule="Loss of comprehensive registration/control permits long-lived populations to diverge under local pressures.",
        allows_divergent_lineages=True,
        requires_control_failure=True,
    ),
    BiologicalPhase(
        "B5",
        5,
        "Free drift and local divergence",
        ("E4", "E5"),
        (BiologicalProcess.FREE_DRIFT,),
        ("B4",),
        causal_rule="Free drift follows persistent uncaptured populations and environmental/social separation.",
        allows_divergent_lineages=True,
        requires_control_failure=True,
    ),
    BiologicalPhase(
        "B6",
        6,
        "Stable sublineage formation",
        ("E5",),
        (BiologicalProcess.STABLE_SUBLINEAGE_FORMATION,),
        ("B5",),
        causal_rule="Stable later lineages can emerge after prolonged isolation, mixing and drift; stability is not retroactive ancestry.",
        allows_divergent_lineages=True,
        requires_control_failure=True,
    ),
)


NON_DETERMINISM_RULES: Tuple[str, ...] = (
    "biology_may_constrain_capability_cost_or_need",
    "biology_does_not_assign_morality",
    "biology_does_not_assign_profession",
    "biology_does_not_assign_dominance_or_submission",
    "biology_does_not_assign_attraction_or_consent",
    "biology_does_not_assign_personality",
    "physiological_response_is_not_a_decision",
    "public_belief_about_a_lineage_is_not_biological_truth",
)


def phase_map(phases: Tuple[BiologicalPhase, ...] = SUPEREVOLUTION_PHASES) -> Mapping[str, BiologicalPhase]:
    return {phase.phase_id: phase for phase in phases}


def validate_superevolution_timeline(phases: Tuple[BiologicalPhase, ...] = SUPEREVOLUTION_PHASES) -> None:
    if not phases:
        raise ValueError("BIOLOGICAL_TIMELINE_EMPTY")

    ids = [p.phase_id for p in phases]
    if len(ids) != len(set(ids)):
        raise ValueError("DUPLICATE_BIOLOGICAL_PHASE_ID")
    if [p.order for p in phases] != list(range(len(phases))):
        raise ValueError("BIOLOGICAL_PHASE_ORDER_NOT_CONTIGUOUS")

    epoch_ids = {e.epoch_id for e in CANONICAL_EPOCHS}
    epoch_order = {e.epoch_id: e.order for e in CANONICAL_EPOCHS}
    seen: set[str] = set()
    prior_max_epoch_order = -1

    for phase in phases:
        if not phase.canonical_epochs:
            raise ValueError(f"BIOLOGICAL_PHASE_WITHOUT_EPOCH:{phase.phase_id}")
        if any(epoch not in epoch_ids for epoch in phase.canonical_epochs):
            raise ValueError(f"UNKNOWN_CANONICAL_EPOCH:{phase.phase_id}")
        if any(req not in seen for req in phase.prerequisites):
            raise ValueError(f"BIOLOGICAL_PREREQUISITE_NOT_PRIOR:{phase.phase_id}")

        orders = [epoch_order[e] for e in phase.canonical_epochs]
        if orders != sorted(orders):
            raise ValueError(f"BIOLOGICAL_EPOCH_ORDER_INVALID:{phase.phase_id}")
        if orders[0] < prior_max_epoch_order - 1:
            raise ValueError(f"BIOLOGICAL_TIMELINE_BACKJUMP:{phase.phase_id}")
        prior_max_epoch_order = max(prior_max_epoch_order, orders[-1])
        seen.add(phase.phase_id)

    by_id = phase_map(phases)
    if by_id["B0"].canonical_epochs[0] != "E0":
        raise ValueError("BIOLOGICAL_PRECURSOR_MUST_BEGIN_IN_E0")
    if "E2" not in by_id["B2"].canonical_epochs:
        raise ValueError("DIRECTED_HYBRIDIZATION_MUST_MAP_TO_E2")
    if not by_id["B4"].requires_control_failure or "E3" not in by_id["B4"].canonical_epochs:
        raise ValueError("DISTRIBUTED_SELECTION_REQUIRES_E3_CONTROL_FAILURE")
    if not by_id["B5"].requires_control_failure or "E4" not in by_id["B5"].canonical_epochs:
        raise ValueError("FREE_DRIFT_REQUIRES_POST_CONTROL_FAILURE_POPULATIONS")
    if "E5" not in by_id["B6"].canonical_epochs:
        raise ValueError("STABLE_SUBLINEAGES_MUST_MAP_TO_E5")

    processes = [process for phase in phases for process in phase.processes]
    required = set(BiologicalProcess)
    if set(processes) != required:
        missing = sorted(p.value for p in required - set(processes))
        extra = sorted(p.value for p in set(processes) - required)
        raise ValueError(f"BIOLOGICAL_PROCESS_COVERAGE_INVALID:missing={missing}:extra={extra}")

    if SUPEREVOLUTION_LATEST_START_CRY > CRY_T0 - 2_000:
        raise ValueError("SUPEREVOLUTION_START_TOO_LATE")


def biological_phase_for_process(process: BiologicalProcess) -> BiologicalPhase:
    matches = [phase for phase in SUPEREVOLUTION_PHASES if process in phase.processes]
    if len(matches) != 1:
        raise ValueError(f"BIOLOGICAL_PROCESS_PHASE_AMBIGUOUS:{process.value}")
    return matches[0]


def assert_process_allowed_in_epoch(process: BiologicalProcess, epoch_id: str) -> None:
    phase = biological_phase_for_process(process)
    if epoch_id not in phase.canonical_epochs:
        raise ValueError(f"BIOLOGICAL_PROCESS_NOT_ALLOWED_IN_EPOCH:{process.value}:{epoch_id}")
