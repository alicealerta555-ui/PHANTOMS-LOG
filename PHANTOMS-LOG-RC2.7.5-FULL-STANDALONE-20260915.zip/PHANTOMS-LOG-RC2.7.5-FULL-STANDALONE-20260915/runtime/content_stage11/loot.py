import hashlib

def weighted_pick(entries, seed):
    if not entries:
        raise ValueError("empty loot table")
    total=sum(max(0,int(w)) for _,w in entries)
    if total<=0:
        raise ValueError("invalid weights")
    h=int(hashlib.sha256(str(seed).encode()).hexdigest()[:16],16)%total
    n=0
    for item,w in entries:
        n+=max(0,int(w))
        if h<n:
            return item

def resolve_loot_ref(ref, world_catalog, artifacts=()):
    """Resolve a loot-table reference into a concrete player-facing record.

    Canonical item refs are looked up in world_catalog.item_definitions. Artifact
    refs are looked up in the stage-11 artifact list. Unknown/legacy aggregate
    refs fail closed instead of leaking an internal token into narration.
    """
    ref=str(ref)
    if ref.startswith("item_def:"):
        items=world_catalog.get("item_definitions",[]) if isinstance(world_catalog,dict) else []
        item=next((x for x in items if x.get("item_definition_id")==ref),None)
        if item is None:
            raise KeyError(f"unknown item definition: {ref}")
        return {
            "kind":"item",
            "ref":ref,
            "display_name":str(item.get("display_name") or "").strip(),
            "item_kind":item.get("kind"),
        }
    artifact=next((x for x in artifacts if x.get("id")==ref),None)
    if artifact is not None:
        return {
            "kind":"artifact",
            "ref":ref,
            "display_name":str(artifact.get("name") or "").strip(),
            "rarity":artifact.get("rarity"),
        }
    if ref in {"ITEM_PARTS","ITEM_WATER","ITEM_FOOD"}:
        raise KeyError(f"legacy aggregate loot alias forbidden: {ref}")
    raise KeyError(f"unknown loot ref: {ref}")

def resolve_weighted_loot(entries, seed, world_catalog, artifacts=()):
    return resolve_loot_ref(weighted_pick(entries,seed),world_catalog,artifacts)

def provenance_record(artifact, source_location_id, discovered_at, discovered_by):
    return {"artifact_id":artifact["id"],"origin_id":artifact["origin_id"],"source_location_id":source_location_id,
            "discovered_at":int(discovered_at),"discovered_by":discovered_by}

def can_spawn(artifact, existing_unique_ids):
    return not artifact.get("unique",False) or artifact["id"] not in set(existing_unique_ids)

def power_site_candidate(site, artifact):
    tags=set(artifact.get("tags",[]))
    if not set(site.get("required_tags",[])).issubset(tags): return None
    return {"kind":"POWER_SITE_EFFECT_PROPOSAL","site_id":site["id"],"artifact_id":artifact["id"],
            "authority_required":True,"domain":site["effect_domain"],"bounded":bool(site.get("bounded",False))}

def validate_provenance(r):
    req={"artifact_id","origin_id","source_location_id","discovered_at","discovered_by"}
    return req.issubset(r) and all(r[k] not in (None,"") for k in req if k!="discovered_at")
