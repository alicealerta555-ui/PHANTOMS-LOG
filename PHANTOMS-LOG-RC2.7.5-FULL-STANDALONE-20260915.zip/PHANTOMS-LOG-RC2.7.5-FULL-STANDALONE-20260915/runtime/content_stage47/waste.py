
def clamp(v,a,b): return max(a,min(b,v))
def collection(uncollected, capacity):
    take=min(max(0,int(uncollected)),max(0,int(capacity)))
    return {"collected":take,"remaining":max(0,int(uncollected)-take)}
def recycle(amount,recovery_bp):
    a=max(0,int(amount)); rec=a*clamp(int(recovery_bp),0,10000)//10000
    return {"recovered":rec,"residue":a-rec}
def sewage_overflow(inflow,network_capacity):
    return max(0,int(inflow)-max(0,int(network_capacity)))
def pollution_accumulate(current,release,decay=0):
    return max(0,int(current)+max(0,int(release))-max(0,int(decay)))
def remediation_candidate(site_id,amount,resources_ok,elapsed_min,causal_event_id):
    if not site_id or int(amount)<=0 or not resources_ok or int(elapsed_min)<=0: return None
    return {"kind":"REMEDIATION_CANDIDATE","site_id":site_id,"amount":int(amount),"elapsed_min":int(elapsed_min),
            "causal_event_id":causal_event_id,"authority_required":True}
def disposal_candidate(waste_ref,method,amount,causal_event_id):
    if not waste_ref or not method or int(amount)<=0: return None
    return {"kind":"WASTE_DISPOSAL_CANDIDATE","waste_ref":waste_ref,"method":method,"amount":int(amount),
            "causal_event_id":causal_event_id,"authority_required":True}
