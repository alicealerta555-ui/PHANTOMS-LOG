
def clamp(v,a,b): return max(a,min(b,v))

def membership_record(organization_id, actor_id, rank_id, joined_at, active=True):
    return {
        "organization_id":organization_id,
        "actor_id":actor_id,
        "rank_id":rank_id,
        "joined_at":int(joined_at),
        "active":bool(active)
    }

def authority_score(rank_level, office_bonus=0, legitimacy_bp=10000):
    raw=int(rank_level)+int(office_bonus)
    raw=raw*max(0,int(legitimacy_bp))//10000
    return clamp(raw,0,100)

def hierarchical_order(organization_id, issuer_actor_id, target_actor_id, action, authority_score_value, causal_event_id):
    return {
        "kind":"HIERARCHICAL_ORDER_REQUEST",
        "organization_id":organization_id,
        "issuer_actor_id":issuer_actor_id,
        "target_actor_id":target_actor_id,
        "requested_action":action,
        "authority_score":clamp(int(authority_score_value),0,100),
        "requires_actor_decision":True,
        "causal_event_id":causal_event_id
    }

def succession_candidate(organization_id, office_id, prior_holder_id, candidate_actor_id, method_id, support_score, threshold, causal_event_id):
    return {
        "kind":"SUCCESSION_CANDIDATE",
        "organization_id":organization_id,
        "office_id":office_id,
        "prior_holder_actor_id":prior_holder_id,
        "candidate_actor_id":candidate_actor_id,
        "method_id":method_id,
        "support_score":int(support_score),
        "threshold":int(threshold),
        "successful":int(support_score)>=int(threshold),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def internal_bloc_pressure(support, opposition, resource_bp=0, legitimacy_bp=0):
    raw=int(support)-int(opposition)
    raw += int(resource_bp)//1000
    raw += int(legitimacy_bp)//1000
    return clamp(raw,-100,100)

def office_change_proposal(organization_id, office_id, from_actor_id, to_actor_id, basis, causal_event_id):
    if not organization_id or not office_id or not to_actor_id:
        return None
    if from_actor_id==to_actor_id:
        return None
    return {
        "kind":"OFFICE_CHANGE_PROPOSAL",
        "organization_id":organization_id,
        "office_id":office_id,
        "from_actor_id":from_actor_id,
        "to_actor_id":to_actor_id,
        "basis":basis,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }
