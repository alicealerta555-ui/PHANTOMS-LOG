
def clamp(v,a,b): return max(a,min(b,v))

def population_projection(current_count, carrying_capacity, growth_bp_per_day, elapsed_min, pressure_bp=0):
    current=max(0,int(current_count))
    cap=max(0,int(carrying_capacity))
    if cap<=0:
        return 0
    days=max(0,int(elapsed_min))/1440.0
    room=max(0,cap-current)
    growth=int(round(current*(int(growth_bp_per_day)/10000.0)*days))
    growth=min(growth,room)
    loss=int(round(current*(max(0,int(pressure_bp))/10000.0)*days))
    return clamp(current+growth-loss,0,cap)

def resource_regeneration(current_stock, max_stock, regen_per_day, elapsed_min, environment_modifier_bp=10000):
    if int(elapsed_min)<=0:
        return clamp(int(current_stock),0,int(max_stock))
    days=max(0,int(elapsed_min))/1440.0
    regen=int(round(float(regen_per_day)*days))
    regen=regen*max(0,int(environment_modifier_bp))//10000
    return clamp(int(current_stock)+regen,0,int(max_stock))

def predator_prey_pressure(predator_count, prey_count, base_pressure_bp=1000):
    if int(predator_count)<=0 or int(prey_count)<=0:
        return 0
    ratio=min(10.0, float(predator_count)/max(1.0,float(prey_count)))
    return clamp(int(round(int(base_pressure_bp)*(1.0+ratio))),0,10000)

def migration_candidate(population_id, origin_region_id, destination_region_id, route_id, count, started_at, causal_event_id):
    if not population_id or not origin_region_id or not destination_region_id or not route_id:
        return None
    if origin_region_id==destination_region_id or int(count)<=0:
        return None
    return {
        "kind":"MIGRATION_CANDIDATE",
        "population_id":population_id,
        "origin_region_id":origin_region_id,
        "destination_region_id":destination_region_id,
        "route_id":route_id,
        "count":int(count),
        "started_at":int(started_at),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def environmental_change_proposal(region_id, pressure, magnitude, elapsed_min, causal_event_id):
    if not region_id or not pressure or int(elapsed_min)<=0:
        return None
    return {
        "kind":"ENVIRONMENTAL_CHANGE_PROPOSAL",
        "region_id":region_id,
        "pressure":pressure,
        "magnitude":clamp(int(magnitude),0,100),
        "elapsed_min":int(elapsed_min),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def extinction_state(count):
    return "EXTINCT_LOCAL" if int(count)<=0 else "PRESENT"
