# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import dataclass
import copy
from typing import Any, Iterable, Mapping, Optional, Sequence, Tuple

from .kernel import (
    Authority,
    CommitKernel,
    CommitRecord,
    Delta,
    Domain,
    Mode,
    NarrationGate,
    Proposal,
    Stage3AError,
    ValidationResult,
)


@dataclass(frozen=True)
class RuntimeDelta:
    """Strict bridge type for deltas produced by existing PH4NT0M5-L0G runtime systems."""

    domain: str
    key: str
    value: Any
    producer: str
    cause: str
    actor_id: Optional[str] = None
    provenance: Optional[str] = None
    epistemic: Optional[Mapping[str, Any]] = None


DOMAIN_MAP = {d.value: d for d in Domain}
PRODUCER_MAP = {
    "WORLD_RESOLVER": Authority.WORLD_RESOLVER,
    "RULE_KERNEL": Authority.RULE_KERNEL,
    "KNOWLEDGE_ROUTER": Authority.KNOWLEDGE_ROUTER,
    "SYSTEM_INIT": Authority.SYSTEM_INIT,
}


class RuntimeAuthorityBridge:
    """
    Additive integration boundary for the existing fixed-phase/delta-buffer runtime.

    Existing systems may calculate outcomes and emit candidate deltas. They do not get
    direct state mutation. The bridge maps only explicit domains/producers and fails closed
    on unknown names; it never guesses whether a legacy `WORLD_STATE` key means truth,
    knowledge, or mutable runtime state.
    """

    def __init__(self, kernel: CommitKernel):
        self.kernel = kernel

    @staticmethod
    def _map_delta(item: RuntimeDelta, event_id: str) -> Delta:
        try:
            domain = DOMAIN_MAP[item.domain]
        except KeyError as exc:
            raise Stage3AError(f"UNMAPPED_RUNTIME_DOMAIN:{item.domain}") from exc
        try:
            writer = PRODUCER_MAP[item.producer]
        except KeyError as exc:
            raise Stage3AError(f"UNMAPPED_RUNTIME_PRODUCER:{item.producer}") from exc
        return Delta(
            domain=domain,
            key=item.key,
            value=copy.deepcopy(item.value),
            writer=writer,
            cause=item.cause,
            source_event_id=event_id,
            actor_id=item.actor_id,
            provenance=item.provenance,
            epistemic=copy.deepcopy(dict(item.epistemic)) if item.epistemic is not None else None,
        )

    def commit_runtime_event(
        self,
        *,
        event_id: str,
        cause: str,
        deltas: Iterable[RuntimeDelta],
        expected_state_revision: Optional[int] = None,
    ) -> CommitRecord | ValidationResult:
        mapped = tuple(self._map_delta(d, event_id) for d in deltas)
        proposal = Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id=event_id,
            cause=cause,
            deltas=mapped,
            expected_state_revision=expected_state_revision,
        )
        return self.kernel.process(proposal)

    def query_player_text(self, text: str, *, suggestion: Any = None) -> ValidationResult:
        result = self.kernel.process(Proposal(
            mode=Mode.QUERY,
            source=Authority.PLAYER_INPUT,
            query_text=text,
            player_suggestion=suggestion,
        ))
        assert isinstance(result, ValidationResult)
        return result

    def resolve_unknown(
        self,
        key: str,
        *,
        event_id: Optional[str] = None,
        cause: str = "UNKNOWN_GROUND_TRUTH_RESOLUTION",
        player_suggestion: Any = None,
    ) -> CommitRecord | ValidationResult:
        return self.kernel.process(Proposal(
            mode=Mode.RESOLVE,
            source=Authority.WORLD_RESOLVER,
            resolution_key=key,
            event_id=event_id,
            cause=cause,
            player_suggestion=player_suggestion,
        ))

    def project_actor_context(
        self,
        actor_id: str,
        *,
        knowledge_keys: Sequence[str],
        runtime_keys: Sequence[str] = (),
    ) -> dict:
        """Context projector for an NPC/agent. WORLD_TRUTH is never returned directly."""
        knowledge = {}
        for key in knowledge_keys:
            record = self.kernel.read(Authority.KNOWLEDGE_ROUTER, Domain.ACTOR_KNOWLEDGE, key, actor_id=actor_id)
            if record is not None:
                knowledge[key] = copy.deepcopy(record.get("value") if isinstance(record, dict) else record)
        runtime = {}
        for key in runtime_keys:
            value = self.kernel.read(Authority.KNOWLEDGE_ROUTER, Domain.RUNTIME_STATE, key)
            if value is not None:
                runtime[key] = value
        return {
            "ACTOR_ID": actor_id,
            "ACTOR_KNOWLEDGE": knowledge,
            "RUNTIME_CONTEXT": runtime,
            "revision": self.kernel.store.revision,
        }

    def project_player_narration(self, *, runtime_keys: Sequence[str] = ()) -> dict:
        gate = NarrationGate(self.kernel.store)
        view = gate.committed_view(runtime_keys=runtime_keys)
        gate.assert_projection_safe(view)
        return view


class FixedPhaseCommitBuffer:
    """
    Compatibility helper for the established P0-P9 world-sim contract.

    It does not implement Stage 3B scheduling. It only prevents phase code from mutating
    committed state directly: phases submit explicit RuntimeDelta objects, then the existing
    orchestrator calls commit_once() at its already-defined atomic commit point.
    """

    PHASES: Tuple[str, ...] = tuple(f"P{i}" for i in range(10))

    def __init__(self, bridge: RuntimeAuthorityBridge, event_id: str, cause: str):
        self.bridge = bridge
        self.event_id = event_id
        self.cause = cause
        self._buffer: list[RuntimeDelta] = []
        self._closed = False

    def add(self, phase: str, delta: RuntimeDelta) -> None:
        if self._closed:
            raise Stage3AError("PHASE_BUFFER_ALREADY_CLOSED")
        if phase not in self.PHASES:
            raise Stage3AError(f"UNKNOWN_FIXED_PHASE:{phase}")
        self._buffer.append(delta)

    def commit_once(self) -> CommitRecord | ValidationResult:
        if self._closed:
            raise Stage3AError("PHASE_BUFFER_ALREADY_CLOSED")
        self._closed = True
        return self.bridge.commit_runtime_event(
            event_id=self.event_id,
            cause=self.cause,
            deltas=tuple(self._buffer),
        )
