# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum
from hashlib import sha256
import copy
import json
import random
import re
from typing import Any, Dict, Mapping, Optional, Protocol, Sequence, Tuple


class Domain(str, Enum):
    WORLD_TRUTH = "WORLD_TRUTH"
    ACTOR_KNOWLEDGE = "ACTOR_KNOWLEDGE"
    PLAYER_KNOWLEDGE = "PLAYER_KNOWLEDGE"
    UNRESOLVED_WORLD = "UNRESOLVED_WORLD"
    RUNTIME_STATE = "RUNTIME_STATE"


class Mode(str, Enum):
    GENERATE = "GENERATE"
    QUERY = "QUERY"
    RESOLVE = "RESOLVE"
    COMMIT = "COMMIT"
    HOLD = "HOLD"
    REJECT = "REJECT"


class Authority(str, Enum):
    PLAYER_INPUT = "PLAYER_INPUT"
    LLM_PROPOSAL = "LLM_PROPOSAL"
    WORLD_RESOLVER = "WORLD_RESOLVER"
    RULE_KERNEL = "RULE_KERNEL"
    KNOWLEDGE_ROUTER = "KNOWLEDGE_ROUTER"
    COMMIT_KERNEL = "COMMIT_KERNEL"
    SYSTEM_INIT = "SYSTEM_INIT"
    NARRATOR = "NARRATOR"
    # Stage-9 canonical world-time producer. It may only request the reserved
    # world-time RuntimeState key; CommitKernel remains the sole state writer.
    WORLD_TIME = "WORLD_TIME"
    # Stage-9 canonical scheduler producer. It may only request the reserved
    # scheduler RuntimeState key; CommitKernel remains the sole state writer.
    SCHEDULER = "SCHEDULER"
    # Stage-9 actor-belief producer. Beliefs are distinct from actor knowledge and
    # may only update the reserved belief RuntimeState namespace.
    BELIEF_ROUTER = "BELIEF_ROUTER"


class Verdict(str, Enum):
    PASS = "PASS"
    HOLD = "HOLD"
    REJECT = "REJECT"


class Stage3AError(RuntimeError):
    pass


_STAGE9_IDEMPOTENCY_KEY = "__stage9_idempotency__"
_STAGE9_WORLD_TIME_KEY = "__stage9_world_time__"
_STAGE9_SCHEDULER_KEY = "__stage9_scheduler__"
_STAGE9_BELIEF_KEY = "__stage9_actor_beliefs__"
_STAGE9_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,191}$")


def _ensure_json_value(value: Any, error_code: str = "NONDETERMINISTIC_VALUE") -> None:
    """Reject values that cannot be deterministically represented in JSON."""
    try:
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise Stage3AError(error_code) from exc




def _validate_epistemic_metadata(meta: Any, key: str) -> None:
    """Validate the Stage-3D knowledge stamp without importing the Stage-3D engine.

    Runtime knowledge written by KNOWLEDGE_ROUTER must carry a causal source, origin,
    acquisition time, explicit path, confidence and distortion record. SYSTEM_INIT is
    intentionally exempt so static bootstrap fixtures can exist without pretending they
    were learned during runtime.
    """
    if not isinstance(meta, Mapping):
        raise Stage3AError(f"KNOWLEDGE_EPISTEMIC_METADATA_REQUIRED:{key}")
    required = {
        "source_type", "source_id", "origin_location", "learned_at", "path",
        "confidence_ppm", "distortions",
    }
    missing = required.difference(meta.keys())
    if missing:
        raise Stage3AError(f"KNOWLEDGE_EPISTEMIC_FIELDS_MISSING:{key}:{','.join(sorted(missing))}")
    for field_name in ("source_type", "source_id", "origin_location"):
        if not isinstance(meta[field_name], str) or not meta[field_name].strip():
            raise Stage3AError(f"KNOWLEDGE_EPISTEMIC_FIELD_INVALID:{key}:{field_name}")
    if not isinstance(meta["learned_at"], int) or meta["learned_at"] < 0:
        raise Stage3AError(f"KNOWLEDGE_EPISTEMIC_TIME_INVALID:{key}")
    confidence = meta["confidence_ppm"]
    if not isinstance(confidence, int) or not 0 <= confidence <= 1_000_000:
        raise Stage3AError(f"KNOWLEDGE_EPISTEMIC_CONFIDENCE_INVALID:{key}")
    path = meta["path"]
    if not isinstance(path, (list, tuple)):
        raise Stage3AError(f"KNOWLEDGE_EPISTEMIC_PATH_INVALID:{key}")
    for hop in path:
        if not isinstance(hop, Mapping):
            raise Stage3AError(f"KNOWLEDGE_EPISTEMIC_HOP_INVALID:{key}")
        hop_required = {"edge_id", "from", "to", "channel", "depart_at", "arrive_at"}
        if not hop_required.issubset(hop.keys()):
            raise Stage3AError(f"KNOWLEDGE_EPISTEMIC_HOP_FIELDS_MISSING:{key}")
        if not all(isinstance(hop[x], str) and hop[x] for x in ("edge_id", "from", "to", "channel")):
            raise Stage3AError(f"KNOWLEDGE_EPISTEMIC_HOP_TEXT_INVALID:{key}")
        if not isinstance(hop["depart_at"], int) or not isinstance(hop["arrive_at"], int):
            raise Stage3AError(f"KNOWLEDGE_EPISTEMIC_HOP_TIME_INVALID:{key}")
        if hop["depart_at"] < 0 or hop["arrive_at"] < hop["depart_at"]:
            raise Stage3AError(f"KNOWLEDGE_EPISTEMIC_HOP_TIME_INVALID:{key}")
    distortions = meta["distortions"]
    if not isinstance(distortions, (list, tuple)) or not all(isinstance(x, str) and x for x in distortions):
        raise Stage3AError(f"KNOWLEDGE_EPISTEMIC_DISTORTIONS_INVALID:{key}")
    _ensure_json_value(dict(meta), "KNOWLEDGE_EPISTEMIC_NOT_JSON_SAFE")


@dataclass(frozen=True)
class WeightedOption:
    value: Any
    weight: int


@dataclass(frozen=True)
class UnresolvedSpec:
    key: str
    options: Tuple[WeightedOption, ...]
    seed_salt: str = ""
    immutable_after_resolution: bool = True

    def validate(self) -> None:
        if not self.key:
            raise Stage3AError("UNRESOLVED_KEY_EMPTY")
        if not self.options:
            raise Stage3AError("UNRESOLVED_OPTIONS_EMPTY")
        if any(o.weight <= 0 for o in self.options):
            raise Stage3AError("UNRESOLVED_WEIGHT_NONPOSITIVE")
        for option in self.options:
            _ensure_json_value(option.value, "UNRESOLVED_OPTION_NOT_JSON_SAFE")


@dataclass(frozen=True)
class Delta:
    domain: Domain
    key: str
    value: Any
    writer: Authority
    cause: str
    mode: Mode = Mode.COMMIT
    source_event_id: Optional[str] = None
    actor_id: Optional[str] = None
    provenance: Optional[str] = None
    epistemic: Optional[Mapping[str, Any]] = None


@dataclass(frozen=True)
class Proposal:
    mode: Mode
    source: Authority
    deltas: Tuple[Delta, ...] = ()
    query_text: Optional[str] = None
    player_suggestion: Any = None
    resolution_key: Optional[str] = None
    event_id: Optional[str] = None
    cause: Optional[str] = None
    # Stage-9 commit-boundary guard. Legacy callers may omit this; Stage-9
    # authoritative commits must carry the revision approved by StateAuthority.
    expected_state_revision: Optional[int] = None
    # Stage-9 9A008 idempotency. Legacy callers may omit both fields. Stage-9
    # authoritative commits bind one stable commit_id to one or more semantic effect_ids.
    commit_id: Optional[str] = None
    effect_ids: Tuple[str, ...] = ()


@dataclass(frozen=True)
class ValidationResult:
    verdict: Verdict
    reasons: Tuple[str, ...] = ()
    normalized_deltas: Tuple[Delta, ...] = ()


@dataclass(frozen=True)
class CommitRecord:
    event_id: str
    cause: str
    deltas: Tuple[Delta, ...]
    before_hash: str
    after_hash: str
    revision: int
    commit_id: Optional[str] = None
    effect_ids: Tuple[str, ...] = ()


class PreCommitGuard(Protocol):
    """Optional global guard executed after structural validation and before mutation."""

    def verify_proposal(
        self,
        *,
        proposal: Proposal,
        deltas: Sequence[Delta],
        store: "StateStore",
    ) -> ValidationResult:
        ...


WRITE_MATRIX: Mapping[Domain, frozenset[Authority]] = {
    Domain.WORLD_TRUTH: frozenset({Authority.WORLD_RESOLVER, Authority.RULE_KERNEL, Authority.SYSTEM_INIT}),
    Domain.ACTOR_KNOWLEDGE: frozenset({Authority.KNOWLEDGE_ROUTER, Authority.SYSTEM_INIT}),
    Domain.PLAYER_KNOWLEDGE: frozenset({Authority.KNOWLEDGE_ROUTER, Authority.SYSTEM_INIT}),
    Domain.UNRESOLVED_WORLD: frozenset({Authority.SYSTEM_INIT, Authority.WORLD_RESOLVER}),
    Domain.RUNTIME_STATE: frozenset({Authority.RULE_KERNEL, Authority.SYSTEM_INIT, Authority.WORLD_TIME, Authority.SCHEDULER, Authority.BELIEF_ROUTER}),
}

NO_WRITE_AUTHORITIES = frozenset({Authority.PLAYER_INPUT, Authority.LLM_PROPOSAL, Authority.NARRATOR})

READ_MATRIX: Mapping[Domain, frozenset[Authority]] = {
    Domain.WORLD_TRUTH: frozenset({
        Authority.WORLD_RESOLVER, Authority.RULE_KERNEL, Authority.KNOWLEDGE_ROUTER,
        Authority.COMMIT_KERNEL, Authority.SYSTEM_INIT,
    }),
    Domain.ACTOR_KNOWLEDGE: frozenset({
        Authority.KNOWLEDGE_ROUTER, Authority.COMMIT_KERNEL, Authority.SYSTEM_INIT,
    }),
    Domain.PLAYER_KNOWLEDGE: frozenset({
        Authority.KNOWLEDGE_ROUTER, Authority.COMMIT_KERNEL, Authority.SYSTEM_INIT,
    }),
    Domain.UNRESOLVED_WORLD: frozenset({
        Authority.WORLD_RESOLVER, Authority.COMMIT_KERNEL, Authority.SYSTEM_INIT,
    }),
    Domain.RUNTIME_STATE: frozenset({
        Authority.RULE_KERNEL, Authority.KNOWLEDGE_ROUTER, Authority.COMMIT_KERNEL,
        Authority.SYSTEM_INIT,
    }),
}


@dataclass
class StateStore:
    world_truth: Dict[str, Any] = field(default_factory=dict)
    actor_knowledge: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    player_knowledge: Dict[str, Any] = field(default_factory=dict)
    unresolved_world: Dict[str, UnresolvedSpec] = field(default_factory=dict)
    runtime_state: Dict[str, Any] = field(default_factory=dict)
    event_ledger: Dict[str, CommitRecord] = field(default_factory=dict)
    revision: int = 0

    def snapshot(self) -> dict:
        return {
            "WORLD_TRUTH": copy.deepcopy(self.world_truth),
            "ACTOR_KNOWLEDGE": copy.deepcopy(self.actor_knowledge),
            "PLAYER_KNOWLEDGE": copy.deepcopy(self.player_knowledge),
            "UNRESOLVED_WORLD": {
                k: {
                    "key": v.key,
                    "options": [(copy.deepcopy(o.value), o.weight) for o in v.options],
                    "seed_salt": v.seed_salt,
                    "immutable_after_resolution": v.immutable_after_resolution,
                }
                for k, v in self.unresolved_world.items()
            },
            "RUNTIME_STATE": copy.deepcopy(self.runtime_state),
            "revision": self.revision,
        }

    def state_hash(self) -> str:
        # Hash committed state without deep-copying the entire store. Values are never
        # exposed mutably through CommitKernel.read(), so serialization is safe here.
        payload = {
            "WORLD_TRUTH": self.world_truth,
            "ACTOR_KNOWLEDGE": self.actor_knowledge,
            "PLAYER_KNOWLEDGE": self.player_knowledge,
            "UNRESOLVED_WORLD": {
                k: {
                    "key": v.key,
                    "options": [(o.value, o.weight) for o in v.options],
                    "seed_salt": v.seed_salt,
                    "immutable_after_resolution": v.immutable_after_resolution,
                }
                for k, v in self.unresolved_world.items()
            },
            "RUNTIME_STATE": self.runtime_state,
            "revision": self.revision,
        }
        raw = json.dumps(
            payload, sort_keys=True, separators=(",", ":"),
            ensure_ascii=False, allow_nan=False,
        ).encode("utf-8")
        return sha256(raw).hexdigest()

    def contains(self, domain: Domain, key: str, actor_id: Optional[str] = None) -> bool:
        if domain == Domain.WORLD_TRUTH:
            return key in self.world_truth
        if domain == Domain.ACTOR_KNOWLEDGE:
            if not actor_id:
                raise Stage3AError("ACTOR_ID_REQUIRED")
            return key in self.actor_knowledge.get(actor_id, {})
        if domain == Domain.PLAYER_KNOWLEDGE:
            return key in self.player_knowledge
        if domain == Domain.UNRESOLVED_WORLD:
            return key in self.unresolved_world
        if domain == Domain.RUNTIME_STATE:
            return key in self.runtime_state
        raise Stage3AError("UNKNOWN_DOMAIN")

    def get(self, domain: Domain, key: str, actor_id: Optional[str] = None) -> Any:
        if domain == Domain.WORLD_TRUTH:
            return self.world_truth.get(key)
        if domain == Domain.ACTOR_KNOWLEDGE:
            if not actor_id:
                raise Stage3AError("ACTOR_ID_REQUIRED")
            return self.actor_knowledge.get(actor_id, {}).get(key)
        if domain == Domain.PLAYER_KNOWLEDGE:
            return self.player_knowledge.get(key)
        if domain == Domain.UNRESOLVED_WORLD:
            return self.unresolved_world.get(key)
        if domain == Domain.RUNTIME_STATE:
            return self.runtime_state.get(key)
        raise Stage3AError("UNKNOWN_DOMAIN")


class CommitKernel:
    def __init__(
        self,
        store: Optional[StateStore] = None,
        world_seed: int = 0,
        precommit_guard: Optional[PreCommitGuard] = None,
    ):
        self.store = store or StateStore()
        self.world_seed = int(world_seed)
        self.precommit_guard = precommit_guard

    def set_precommit_guard(self, guard: Optional[PreCommitGuard]) -> None:
        self.precommit_guard = guard

    @staticmethod
    def _validate_stage9_id(value: object, code: str) -> str:
        if not isinstance(value, str) or not value or value != value.strip() or not _STAGE9_ID_RE.fullmatch(value):
            raise Stage3AError(code)
        return value

    @staticmethod
    def _idempotency_value(value: Any) -> Any:
        if isinstance(value, UnresolvedSpec):
            return {
                "key": value.key,
                "options": [
                    {"value": CommitKernel._idempotency_value(o.value), "weight": o.weight}
                    for o in value.options
                ],
                "seed_salt": value.seed_salt,
                "immutable_after_resolution": value.immutable_after_resolution,
            }
        if isinstance(value, Mapping):
            return {str(k): CommitKernel._idempotency_value(v) for k, v in value.items()}
        if isinstance(value, tuple):
            return [CommitKernel._idempotency_value(v) for v in value]
        if isinstance(value, list):
            return [CommitKernel._idempotency_value(v) for v in value]
        return copy.deepcopy(value)

    @classmethod
    def _idempotency_fingerprint(cls, deltas: Sequence[Delta]) -> str:
        payload = []
        for d in deltas:
            payload.append({
                "domain": d.domain.value,
                "key": d.key,
                "value": cls._idempotency_value(d.value),
                "writer": d.writer.value,
                "cause": d.cause,
                "mode": d.mode.value,
                "actor_id": d.actor_id,
                "provenance": d.provenance,
                "epistemic": cls._idempotency_value(d.epistemic),
            })
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")
        return sha256(raw).hexdigest()

    @staticmethod
    def _idempotency_registry(store: "StateStore") -> dict[str, Any]:
        raw = store.runtime_state.get(_STAGE9_IDEMPOTENCY_KEY)
        if raw is None:
            return {"commits": {}, "effects": {}}
        if not isinstance(raw, Mapping):
            raise Stage3AError("IDEMPOTENCY_REGISTRY_CORRUPT")
        commits = raw.get("commits")
        effects = raw.get("effects")
        if not isinstance(commits, Mapping) or not isinstance(effects, Mapping):
            raise Stage3AError("IDEMPOTENCY_REGISTRY_CORRUPT")
        return {"commits": copy.deepcopy(dict(commits)), "effects": copy.deepcopy(dict(effects))}

    def _check_stage9_idempotency(
        self, proposal: Proposal, deltas: Sequence[Delta]
    ) -> Optional[ValidationResult]:
        if proposal.commit_id is None and not proposal.effect_ids:
            return None
        if proposal.commit_id is None:
            return ValidationResult(Verdict.REJECT, ("COMMIT_ID_REQUIRED_FOR_EFFECT_IDS",), ())
        if not proposal.effect_ids:
            return ValidationResult(Verdict.REJECT, ("EFFECT_IDS_REQUIRED_FOR_COMMIT_ID",), ())
        try:
            commit_id = self._validate_stage9_id(proposal.commit_id, "COMMIT_ID_INVALID")
            effect_ids = tuple(self._validate_stage9_id(x, "EFFECT_ID_INVALID") for x in proposal.effect_ids)
        except Stage3AError as exc:
            return ValidationResult(Verdict.REJECT, (str(exc),), ())
        if len(set(effect_ids)) != len(effect_ids):
            return ValidationResult(Verdict.REJECT, ("EFFECT_ID_DUPLICATE_IN_PROPOSAL",), ())

        fingerprint = self._idempotency_fingerprint(deltas)
        registry = self._idempotency_registry(self.store)
        existing_commit = registry["commits"].get(commit_id)
        if existing_commit is not None:
            if not isinstance(existing_commit, Mapping):
                raise Stage3AError("IDEMPOTENCY_REGISTRY_CORRUPT")
            same_effects = tuple(existing_commit.get("effect_ids", ())) == effect_ids
            same_fp = existing_commit.get("fingerprint") == fingerprint
            if same_effects and same_fp:
                return ValidationResult(Verdict.HOLD, ("DUPLICATE_COMMIT_IDEMPOTENT_SKIP",), ())
            return ValidationResult(Verdict.REJECT, ("COMMIT_ID_REUSE_CONFLICT",), ())

        for effect_id in effect_ids:
            existing_effect = registry["effects"].get(effect_id)
            if existing_effect is None:
                continue
            if not isinstance(existing_effect, Mapping):
                raise Stage3AError("IDEMPOTENCY_REGISTRY_CORRUPT")
            same_commit = existing_effect.get("commit_id") == commit_id
            same_fp = existing_effect.get("fingerprint") == fingerprint
            if same_commit and same_fp:
                return ValidationResult(Verdict.HOLD, (f"DUPLICATE_EFFECT_IDEMPOTENT_SKIP:{effect_id}",), ())
            return ValidationResult(Verdict.REJECT, (f"EFFECT_ID_REUSE_CONFLICT:{effect_id}",), ())
        return None

    def _record_stage9_idempotency(
        self, staged: "StateStore", proposal: Proposal, deltas: Sequence[Delta]
    ) -> None:
        if proposal.commit_id is None and not proposal.effect_ids:
            return
        assert proposal.commit_id is not None and proposal.effect_ids
        fingerprint = self._idempotency_fingerprint(deltas)
        registry = self._idempotency_registry(staged)
        commit_id = proposal.commit_id
        effect_ids = tuple(proposal.effect_ids)
        registry["commits"][commit_id] = {
            "effect_ids": list(effect_ids),
            "fingerprint": fingerprint,
            "event_id": proposal.event_id,
        }
        for effect_id in effect_ids:
            registry["effects"][effect_id] = {
                "commit_id": commit_id,
                "fingerprint": fingerprint,
                "event_id": proposal.event_id,
            }
        staged.runtime_state[_STAGE9_IDEMPOTENCY_KEY] = registry

    def _run_precommit_guard(self, proposal: Proposal, deltas: Sequence[Delta]) -> ValidationResult:
        if self.precommit_guard is None:
            return ValidationResult(Verdict.PASS, (), tuple(deltas))
        result = self.precommit_guard.verify_proposal(
            proposal=proposal, deltas=tuple(deltas), store=self.store,
        )
        if not isinstance(result, ValidationResult):
            raise Stage3AError("PRECOMMIT_GUARD_RETURN_TYPE_INVALID")
        return result

    def read(self, authority: Authority, domain: Domain, key: str, actor_id: Optional[str] = None) -> Any:
        allowed = READ_MATRIX.get(domain, frozenset())
        if authority not in allowed:
            raise Stage3AError(f"READ_AUTHORITY_DENIED:{domain.value}:{authority.value}")
        return copy.deepcopy(self.store.get(domain, key, actor_id=actor_id))

    def exists(self, authority: Authority, domain: Domain, key: str, actor_id: Optional[str] = None) -> bool:
        allowed = READ_MATRIX.get(domain, frozenset())
        if authority not in allowed:
            raise Stage3AError(f"READ_AUTHORITY_DENIED:{domain.value}:{authority.value}")
        return self.store.contains(domain, key, actor_id=actor_id)

    def read_actor_knowledge_snapshot(self, authority: Authority, actor_id: str) -> dict[str, Any]:
        """Return a deep-copied snapshot of exactly one actor's knowledge namespace.

        Stage-9 ActorDecisionContext projection needs enumeration of one actor's own
        knowledge without taking a whole StateStore snapshot (which would also contain
        hidden World Truth and other actors).  The normal ACTOR_KNOWLEDGE read matrix
        still applies and the returned mapping is detached from canonical state.
        """
        allowed = READ_MATRIX.get(Domain.ACTOR_KNOWLEDGE, frozenset())
        if authority not in allowed:
            raise Stage3AError(
                f"READ_AUTHORITY_DENIED:{Domain.ACTOR_KNOWLEDGE.value}:{authority.value}"
            )
        if not isinstance(actor_id, str) or not actor_id:
            raise Stage3AError("ACTOR_ID_REQUIRED")
        return copy.deepcopy(self.store.actor_knowledge.get(actor_id, {}))

    def register_unresolved(
        self,
        spec: UnresolvedSpec,
        *,
        writer: Authority = Authority.SYSTEM_INIT,
        event_id: Optional[str] = None,
        cause: str = "REGISTER_UNRESOLVED_GROUND_TRUTH",
    ) -> CommitRecord | ValidationResult:
        """Register possibility space through the same atomic commit path as all persistent state."""
        spec.validate()
        if spec.key in self.store.world_truth:
            raise Stage3AError("GROUND_TRUTH_ALREADY_RESOLVED")
        if spec.key in self.store.unresolved_world:
            raise Stage3AError("UNRESOLVED_ALREADY_REGISTERED")
        eid = event_id or f"INIT_UNRESOLVED:{spec.key}"
        delta = Delta(
            domain=Domain.UNRESOLVED_WORLD,
            key=spec.key,
            value=spec,
            writer=writer,
            cause=cause,
            source_event_id=eid,
            provenance="STATIC_ALLOWED_POSSIBILITY_SPACE",
        )
        return self.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            deltas=(delta,),
            event_id=eid,
            cause=cause,
        ))

    def process(self, proposal: Proposal) -> ValidationResult | CommitRecord:
        if proposal.mode == Mode.QUERY:
            return self._query(proposal)
        if proposal.mode == Mode.GENERATE:
            return ValidationResult(Verdict.HOLD, ("GENERATED_DRAFT_NONAUTHORITATIVE",), proposal.deltas)
        if proposal.mode == Mode.HOLD:
            return ValidationResult(Verdict.HOLD, ("EXPLICIT_HOLD",), proposal.deltas)
        if proposal.mode == Mode.REJECT:
            return ValidationResult(Verdict.REJECT, ("EXPLICIT_REJECT",), ())
        if proposal.mode == Mode.RESOLVE:
            return self._resolve(proposal)
        if proposal.mode == Mode.COMMIT:
            result = self.validate(proposal)
            if result.verdict != Verdict.PASS:
                return result
            guard = self._run_precommit_guard(proposal, result.normalized_deltas)
            if guard.verdict != Verdict.PASS:
                return guard
            return self._commit(proposal, result.normalized_deltas)
        raise Stage3AError("UNKNOWN_MODE")

    def _query(self, proposal: Proposal) -> ValidationResult:
        reasons = ["EPHEMERAL_QUERY_NO_COMMIT"]
        if proposal.deltas:
            reasons.append("QUERY_DELTAS_IGNORED")
        return ValidationResult(Verdict.HOLD, tuple(reasons), ())

    def _resolve(self, proposal: Proposal) -> CommitRecord | ValidationResult:
        if proposal.source not in {Authority.WORLD_RESOLVER, Authority.COMMIT_KERNEL}:
            return ValidationResult(Verdict.REJECT, ("RESOLVE_AUTHORITY_DENIED",), ())
        key = proposal.resolution_key
        if not key:
            return ValidationResult(Verdict.REJECT, ("RESOLUTION_KEY_REQUIRED",), ())
        if key in self.store.world_truth:
            return ValidationResult(Verdict.HOLD, ("ALREADY_RESOLVED_NO_REROLL",), ())
        spec = self.store.unresolved_world.get(key)
        if spec is None:
            return ValidationResult(Verdict.REJECT, ("UNKNOWN_UNRESOLVED_KEY",), ())
        spec.validate()

        # Anti-suggestion: player_suggestion is deliberately excluded from seed material and weights.
        material = f"{self.world_seed}|{spec.key}|{spec.seed_salt}".encode("utf-8")
        derived_seed = int.from_bytes(sha256(material).digest()[:8], "big")
        rng = random.Random(derived_seed)
        values = [o.value for o in spec.options]
        weights = [o.weight for o in spec.options]
        chosen = rng.choices(values, weights=weights, k=1)[0]
        event_id = proposal.event_id or f"RESOLVE:{spec.key}:{derived_seed:016x}"
        cause = proposal.cause or "UNKNOWN_GROUND_TRUTH_RESOLUTION"
        delta = Delta(
            domain=Domain.WORLD_TRUTH,
            key=spec.key,
            value=chosen,
            writer=Authority.WORLD_RESOLVER,
            cause=cause,
            mode=Mode.COMMIT,
            source_event_id=event_id,
            provenance=f"UNRESOLVED:{spec.key}",
        )
        commit_proposal = Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            deltas=(delta,),
            event_id=event_id,
            cause=cause,
        )
        result = self.validate(commit_proposal)
        if result.verdict != Verdict.PASS:
            return result
        guard = self._run_precommit_guard(commit_proposal, result.normalized_deltas)
        if guard.verdict != Verdict.PASS:
            return guard
        return self._commit(commit_proposal, result.normalized_deltas, consume_unresolved_key=spec.key)

    def validate(self, proposal: Proposal) -> ValidationResult:
        reasons = []
        # Some semantic guards (currently world-time monotonicity) must run after
        # Stage-9 idempotency recognition so an exact retry can HOLD rather than be
        # mistaken for a new backwards/equal-time mutation.
        post_idempotency_reasons = []
        normalized = []

        # One active commit authority: producers propose deltas; only COMMIT_KERNEL applies them.
        if proposal.source != Authority.COMMIT_KERNEL:
            return ValidationResult(Verdict.REJECT, ("COMMIT_SOURCE_NOT_COMMIT_KERNEL",), ())
        if not proposal.event_id:
            reasons.append("EVENT_ID_REQUIRED")
        if not proposal.cause:
            reasons.append("CAUSE_REQUIRED")
        stage9_idempotency = proposal.commit_id is not None or bool(proposal.effect_ids)
        if proposal.event_id and proposal.event_id in self.store.event_ledger and not stage9_idempotency:
            return ValidationResult(Verdict.HOLD, ("DUPLICATE_EVENT_IDEMPOTENT_SKIP",), ())
        if not proposal.deltas:
            reasons.append("EMPTY_COMMIT")
        if proposal.expected_state_revision is not None:
            expected_revision = proposal.expected_state_revision
            if isinstance(expected_revision, bool) or not isinstance(expected_revision, int) or expected_revision < 0:
                reasons.append("EXPECTED_STATE_REVISION_INVALID")

        for d in proposal.deltas:
            if d.mode != Mode.COMMIT:
                reasons.append(f"DELTA_MODE_NOT_COMMIT:{d.key}")
                continue
            if not d.key:
                reasons.append("DELTA_KEY_EMPTY")
                continue
            if d.domain == Domain.RUNTIME_STATE and d.key == _STAGE9_IDEMPOTENCY_KEY:
                reasons.append("RESERVED_RUNTIME_STATE_KEY")
                continue
            if d.domain == Domain.RUNTIME_STATE and d.writer == Authority.SCHEDULER and d.key != _STAGE9_SCHEDULER_KEY:
                reasons.append("SCHEDULER_RESERVED_KEY_ONLY")
                continue
            if d.domain == Domain.RUNTIME_STATE and d.key == _STAGE9_SCHEDULER_KEY:
                if d.writer != Authority.SCHEDULER:
                    reasons.append("SCHEDULER_WRITER_REQUIRED")
                    continue
                if not isinstance(d.value, Mapping):
                    reasons.append("SCHEDULER_VALUE_INVALID")
                    continue
                if set(d.value.keys()) != {"run_uuid", "events"}:
                    reasons.append("SCHEDULER_VALUE_SCHEMA_INVALID")
                    continue
                run_uuid = d.value.get("run_uuid")
                events = d.value.get("events")
                if not isinstance(run_uuid, str) or not run_uuid:
                    reasons.append("SCHEDULER_RUN_UUID_INVALID")
                    continue
                if not isinstance(events, Mapping):
                    reasons.append("SCHEDULER_EVENTS_INVALID")
                    continue
                scheduler_invalid = False
                for scheduled_event_id, record in events.items():
                    if (
                        not isinstance(scheduled_event_id, str) or not scheduled_event_id
                        or scheduled_event_id != scheduled_event_id.strip()
                        or not _STAGE9_ID_RE.fullmatch(scheduled_event_id)
                    ):
                        reasons.append("SCHEDULED_EVENT_ID_INVALID")
                        scheduler_invalid = True
                        break
                    if not isinstance(record, Mapping):
                        reasons.append(f"SCHEDULED_EVENT_RECORD_INVALID:{scheduled_event_id}")
                        scheduler_invalid = True
                        break
                    if set(record.keys()) != {"scheduled_event_id", "event_type", "due_world_time", "sequence_key", "payload"}:
                        reasons.append(f"SCHEDULED_EVENT_SCHEMA_INVALID:{scheduled_event_id}")
                        scheduler_invalid = True
                        break
                    if record.get("scheduled_event_id") != scheduled_event_id:
                        reasons.append(f"SCHEDULED_EVENT_KEY_MISMATCH:{scheduled_event_id}")
                        scheduler_invalid = True
                        break
                    event_type = record.get("event_type")
                    due = record.get("due_world_time")
                    sequence_key = record.get("sequence_key")
                    payload = record.get("payload")
                    if not isinstance(event_type, str) or not event_type:
                        reasons.append(f"SCHEDULED_EVENT_TYPE_INVALID:{scheduled_event_id}")
                        scheduler_invalid = True
                        break
                    if isinstance(due, bool) or not isinstance(due, int) or due < 0:
                        reasons.append(f"SCHEDULED_EVENT_DUE_TIME_INVALID:{scheduled_event_id}")
                        scheduler_invalid = True
                        break
                    if not isinstance(sequence_key, str) or not sequence_key:
                        reasons.append(f"SCHEDULED_EVENT_SEQUENCE_KEY_INVALID:{scheduled_event_id}")
                        scheduler_invalid = True
                        break
                    if not isinstance(payload, Mapping):
                        reasons.append(f"SCHEDULED_EVENT_PAYLOAD_INVALID:{scheduled_event_id}")
                        scheduler_invalid = True
                        break
                    try:
                        _ensure_json_value(dict(payload), "SCHEDULED_EVENT_PAYLOAD_NOT_JSON_SAFE")
                    except Stage3AError as exc:
                        reasons.append(f"{exc}:{scheduled_event_id}")
                        scheduler_invalid = True
                        break
                if scheduler_invalid:
                    continue
                current_scheduler = self.store.runtime_state.get(_STAGE9_SCHEDULER_KEY)
                if current_scheduler is not None:
                    if not isinstance(current_scheduler, Mapping) or current_scheduler.get("run_uuid") != run_uuid:
                        reasons.append("SCHEDULER_RUN_MISMATCH")
                        continue
            if d.domain == Domain.RUNTIME_STATE and d.writer == Authority.BELIEF_ROUTER and d.key != _STAGE9_BELIEF_KEY:
                reasons.append("BELIEF_RESERVED_KEY_ONLY")
                continue
            if d.domain == Domain.RUNTIME_STATE and d.key == _STAGE9_BELIEF_KEY:
                if d.writer != Authority.BELIEF_ROUTER:
                    reasons.append("BELIEF_WRITER_REQUIRED")
                    continue
                if not isinstance(d.value, Mapping) or set(d.value.keys()) != {"run_uuid", "actors"}:
                    reasons.append("BELIEF_VALUE_SCHEMA_INVALID")
                    continue
                run_uuid = d.value.get("run_uuid")
                actors = d.value.get("actors")
                if not isinstance(run_uuid, str) or not run_uuid or not isinstance(actors, Mapping):
                    reasons.append("BELIEF_VALUE_INVALID")
                    continue
                belief_invalid = False
                for actor_id, beliefs in actors.items():
                    if not isinstance(actor_id, str) or not actor_id or not isinstance(beliefs, Mapping):
                        belief_invalid = True; break
                    for belief_key, record in beliefs.items():
                        if not isinstance(belief_key, str) or not belief_key or not isinstance(record, Mapping):
                            belief_invalid = True; break
                        if set(record.keys()) != {"value", "provenance", "confidence_ppm"}:
                            belief_invalid = True; break
                        if not isinstance(record.get("provenance"), str) or not record.get("provenance"):
                            belief_invalid = True; break
                        confidence = record.get("confidence_ppm")
                        if isinstance(confidence, bool) or not isinstance(confidence, int) or not 0 <= confidence <= 1_000_000:
                            belief_invalid = True; break
                        try:
                            _ensure_json_value(record.get("value"), "BELIEF_VALUE_NOT_JSON_SAFE")
                        except Stage3AError:
                            belief_invalid = True; break
                    if belief_invalid: break
                if belief_invalid:
                    reasons.append("BELIEF_VALUE_INVALID")
                    continue
                current_beliefs = self.store.runtime_state.get(_STAGE9_BELIEF_KEY)
                if current_beliefs is not None:
                    if not isinstance(current_beliefs, Mapping) or current_beliefs.get("run_uuid") != run_uuid:
                        reasons.append("BELIEF_RUN_MISMATCH")
                        continue
            if d.domain == Domain.RUNTIME_STATE and d.key == _STAGE9_WORLD_TIME_KEY:
                if d.writer != Authority.WORLD_TIME:
                    reasons.append("WORLD_TIME_WRITER_REQUIRED")
                    continue
                if not isinstance(d.value, Mapping):
                    reasons.append("WORLD_TIME_VALUE_INVALID")
                    continue
                if set(d.value.keys()) != {"run_uuid", "seconds"}:
                    reasons.append("WORLD_TIME_VALUE_SCHEMA_INVALID")
                    continue
                run_uuid = d.value.get("run_uuid")
                seconds = d.value.get("seconds")
                if not isinstance(run_uuid, str) or not run_uuid:
                    reasons.append("WORLD_TIME_RUN_UUID_INVALID")
                    continue
                if isinstance(seconds, bool) or not isinstance(seconds, int) or seconds <= 0:
                    reasons.append("WORLD_TIME_SECONDS_INVALID")
                    continue
                current = self.store.runtime_state.get(_STAGE9_WORLD_TIME_KEY)
                if current is not None:
                    if not isinstance(current, Mapping):
                        reasons.append("WORLD_TIME_STATE_CORRUPT")
                        continue
                    current_run = current.get("run_uuid")
                    current_seconds = current.get("seconds")
                    if (
                        not isinstance(current_run, str) or not current_run
                        or isinstance(current_seconds, bool) or not isinstance(current_seconds, int)
                        or current_seconds < 0
                    ):
                        reasons.append("WORLD_TIME_STATE_CORRUPT")
                        continue
                    if run_uuid != current_run:
                        reasons.append("WORLD_TIME_RUN_MISMATCH")
                        continue
                    if seconds <= current_seconds:
                        post_idempotency_reasons.append("WORLD_TIME_NOT_MONOTONIC")
            allowed = WRITE_MATRIX.get(d.domain, frozenset())
            if d.writer not in allowed:
                reasons.append(f"WRITE_AUTHORITY_DENIED:{d.domain.value}:{d.writer.value}:{d.key}")
                continue
            if d.writer in NO_WRITE_AUTHORITIES:
                reasons.append(f"NO_WRITE_AUTHORITY:{d.writer.value}:{d.key}")
                continue
            if not d.cause:
                reasons.append(f"DELTA_CAUSE_REQUIRED:{d.key}")
                continue
            if d.source_event_id and proposal.event_id and d.source_event_id != proposal.event_id:
                reasons.append(f"SOURCE_EVENT_MISMATCH:{d.key}")
                continue

            if d.domain == Domain.ACTOR_KNOWLEDGE:
                if not d.actor_id:
                    reasons.append(f"ACTOR_ID_REQUIRED:{d.key}")
                    continue
                if not d.provenance:
                    reasons.append(f"KNOWLEDGE_PROVENANCE_REQUIRED:{d.key}")
                    continue
                if d.writer == Authority.KNOWLEDGE_ROUTER:
                    try:
                        _validate_epistemic_metadata(d.epistemic, d.key)
                    except Stage3AError as exc:
                        reasons.append(str(exc))
                        continue
            if d.domain == Domain.PLAYER_KNOWLEDGE:
                if not d.provenance:
                    reasons.append(f"KNOWLEDGE_PROVENANCE_REQUIRED:{d.key}")
                    continue
                if d.writer == Authority.KNOWLEDGE_ROUTER:
                    try:
                        _validate_epistemic_metadata(d.epistemic, d.key)
                    except Stage3AError as exc:
                        reasons.append(str(exc))
                        continue

            if d.domain == Domain.UNRESOLVED_WORLD:
                if not isinstance(d.value, UnresolvedSpec):
                    reasons.append(f"UNRESOLVED_VALUE_MUST_BE_SPEC:{d.key}")
                    continue
                try:
                    d.value.validate()
                except Stage3AError as exc:
                    reasons.append(f"{exc}:{d.key}")
                    continue
                if d.key != d.value.key:
                    reasons.append(f"UNRESOLVED_KEY_MISMATCH:{d.key}")
                    continue
                if d.key in self.store.world_truth:
                    reasons.append(f"CANNOT_MARK_RESOLVED_TRUTH_UNRESOLVED:{d.key}")
                    continue
                if d.key in self.store.unresolved_world:
                    reasons.append(f"UNRESOLVED_ALREADY_REGISTERED:{d.key}")
                    continue
            else:
                try:
                    _ensure_json_value(d.value)
                except Stage3AError as exc:
                    reasons.append(f"{exc}:{d.key}")
                    continue

            if d.domain == Domain.WORLD_TRUTH:
                if d.key in self.store.world_truth and d.writer == Authority.WORLD_RESOLVER:
                    reasons.append(f"NO_REROLL_OR_RESOLVE_OVERWRITE:{d.key}")
                    continue

            normalized.append(replace(d, source_event_id=proposal.event_id))

        if reasons:
            return ValidationResult(Verdict.REJECT, tuple(reasons), ())
        normalized_tuple = tuple(normalized)
        if stage9_idempotency:
            idem = self._check_stage9_idempotency(proposal, normalized_tuple)
            if idem is not None:
                return idem
            if proposal.event_id and proposal.event_id in self.store.event_ledger:
                return ValidationResult(Verdict.HOLD, ("DUPLICATE_EVENT_IDEMPOTENT_SKIP",), ())
        if post_idempotency_reasons:
            return ValidationResult(Verdict.REJECT, tuple(post_idempotency_reasons), ())
        return ValidationResult(Verdict.PASS, (), normalized_tuple)

    def _commit(
        self,
        proposal: Proposal,
        deltas: Sequence[Delta],
        consume_unresolved_key: Optional[str] = None,
    ) -> CommitRecord | ValidationResult:
        assert proposal.event_id and proposal.cause
        if proposal.event_id in self.store.event_ledger and proposal.commit_id is None and not proposal.effect_ids:
            return self.store.event_ledger[proposal.event_id]

        # Stage-9 9A008: re-check commit/effect idempotency at the final mutation
        # boundary. This protects the validate->commit window and makes retry safe
        # even when the retry arrives under a different legacy event_id.
        idem = self._check_stage9_idempotency(proposal, deltas)
        if idem is not None:
            return idem
        if proposal.event_id in self.store.event_ledger:
            return self.store.event_ledger[proposal.event_id]

        # Stage-9 9A007: re-check the Authority-approved revision at the final
        # commit boundary, after structural/precommit validation and immediately
        # before any staged mutation is created. This closes the authority->commit
        # TOCTOU window while keeping legacy callers backward compatible.
        if (
            proposal.expected_state_revision is not None
            and proposal.expected_state_revision != self.store.revision
        ):
            return ValidationResult(Verdict.REJECT, ("STALE_STATE_REVISION",), ())

        before_hash = self.store.state_hash()

        # Copy-on-write staging: copy domain maps, not the full immutable ledger/history.
        # Stored values are replaced (never mutated in place) by _apply().
        staged = StateStore(
            world_truth=dict(self.store.world_truth),
            actor_knowledge={actor: dict(values) for actor, values in self.store.actor_knowledge.items()},
            player_knowledge=dict(self.store.player_knowledge),
            unresolved_world=dict(self.store.unresolved_world),
            runtime_state=dict(self.store.runtime_state),
            event_ledger=self.store.event_ledger,  # read-only during staging
            revision=self.store.revision,
        )
        try:
            for d in deltas:
                self._apply(staged, d)
            if consume_unresolved_key is not None:
                if consume_unresolved_key not in staged.unresolved_world:
                    raise Stage3AError("UNRESOLVED_CONSUME_MISSING")
                staged.unresolved_world.pop(consume_unresolved_key)
            self._record_stage9_idempotency(staged, proposal, deltas)
            staged.revision += 1
            after_hash = staged.state_hash()
            record = CommitRecord(
                event_id=proposal.event_id,
                cause=proposal.cause,
                deltas=tuple(deltas),
                before_hash=before_hash,
                after_hash=after_hash,
                revision=staged.revision,
                commit_id=proposal.commit_id,
                effect_ids=tuple(proposal.effect_ids),
            )
        except Exception as exc:
            raise Stage3AError(f"ATOMIC_COMMIT_ABORT:{exc}") from exc

        # All potentially failing work is finished. These assignments cannot partially
        # validate a rejected transaction; the ledger append is the final commit marker.
        self.store.world_truth = staged.world_truth
        self.store.actor_knowledge = staged.actor_knowledge
        self.store.player_knowledge = staged.player_knowledge
        self.store.unresolved_world = staged.unresolved_world
        self.store.runtime_state = staged.runtime_state
        self.store.revision = staged.revision
        self.store.event_ledger[proposal.event_id] = record
        return record

    @staticmethod
    def _apply(store: StateStore, d: Delta) -> None:
        if d.domain == Domain.WORLD_TRUTH:
            store.world_truth[d.key] = copy.deepcopy(d.value)
            return
        if d.domain == Domain.ACTOR_KNOWLEDGE:
            assert d.actor_id
            store.actor_knowledge.setdefault(d.actor_id, {})[d.key] = {
                "value": copy.deepcopy(d.value),
                "provenance": d.provenance,
                "source_event_id": d.source_event_id,
                "epistemic": copy.deepcopy(dict(d.epistemic)) if d.epistemic is not None else None,
            }
            return
        if d.domain == Domain.PLAYER_KNOWLEDGE:
            store.player_knowledge[d.key] = {
                "value": copy.deepcopy(d.value),
                "provenance": d.provenance,
                "source_event_id": d.source_event_id,
                "epistemic": copy.deepcopy(dict(d.epistemic)) if d.epistemic is not None else None,
            }
            return
        if d.domain == Domain.UNRESOLVED_WORLD:
            if not isinstance(d.value, UnresolvedSpec):
                raise Stage3AError("UNRESOLVED_VALUE_MUST_BE_SPEC")
            d.value.validate()
            if d.key in store.world_truth:
                raise Stage3AError("CANNOT_MARK_RESOLVED_TRUTH_UNRESOLVED")
            if d.key in store.unresolved_world:
                raise Stage3AError("UNRESOLVED_ALREADY_REGISTERED")
            store.unresolved_world[d.key] = copy.deepcopy(d.value)
            return
        if d.domain == Domain.RUNTIME_STATE:
            store.runtime_state[d.key] = copy.deepcopy(d.value)
            return
        raise Stage3AError("UNKNOWN_DOMAIN")


class NarrationGate:
    """Presentation bridge. It returns an explicit player-facing projection, never WORLD_TRUTH."""

    def __init__(self, store: StateStore):
        self._store = store

    def committed_view(self, runtime_keys: Sequence[str] = ()) -> dict:
        player_view: Dict[str, Any] = {}
        for key, record in self._store.player_knowledge.items():
            if isinstance(record, dict) and "value" in record:
                player_view[key] = copy.deepcopy(record["value"])
            else:
                player_view[key] = copy.deepcopy(record)

        runtime_view = {
            key: copy.deepcopy(self._store.runtime_state[key])
            for key in runtime_keys
            if key in self._store.runtime_state
        }
        return {
            "PLAYER_KNOWLEDGE": player_view,
            "PRESENTATION_RUNTIME": runtime_view,
            "revision": self._store.revision,
        }

    @staticmethod
    def assert_projection_safe(view: Mapping[str, Any]) -> None:
        forbidden = {"WORLD_TRUTH", "ACTOR_KNOWLEDGE", "UNRESOLVED_WORLD"}
        leaked = forbidden.intersection(view.keys())
        if leaked:
            raise Stage3AError(f"NARRATION_PROJECTION_LEAK:{','.join(sorted(leaked))}")

    def assert_no_state_change(self, before_hash: str) -> None:
        if self._store.state_hash() != before_hash:
            raise Stage3AError("NARRATION_STATE_MUTATION_DETECTED")
