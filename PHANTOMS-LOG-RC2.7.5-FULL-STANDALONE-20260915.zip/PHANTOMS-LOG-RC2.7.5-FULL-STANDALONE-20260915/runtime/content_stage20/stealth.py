
def clamp(v,a,b): return max(a,min(b,v))

def concealment_score(base_bp, visibility_bp=0, noise_bp=0, movement_bp=0):
    # Higher = harder to detect.
    return clamp(int(base_bp)+int(visibility_bp)-int(noise_bp)-int(movement_bp),0,10000)

def detection_score(observer_perception, target_concealment_bp, distance_penalty_bp=0, channel_quality_bp=10000):
    raw=int(observer_perception)*100
    raw += max(0,int(channel_quality_bp)-5000)//5
    raw -= int(target_concealment_bp)
    raw -= int(distance_penalty_bp)
    return clamp(raw,0,10000)

def detection_candidate(observer_id,target_id,location_id,channel,score,threshold,causal_event_id):
    success=int(score)>=int(threshold)
    return {
        "kind":"DETECTION_CANDIDATE",
        "observer_actor_id":observer_id,
        "target_actor_id":target_id,
        "location_id":location_id,
        "perception_channel":channel,
        "success":success,
        "score":int(score),
        "threshold":int(threshold),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def trace_record(trace_type,source_actor_id,location_id,created_at,confidence,event_id):
    return {
        "trace_type":trace_type,
        "source_actor_id":source_actor_id,
        "location_id":location_id,
        "created_at":int(created_at),
        "confidence":clamp(int(confidence),0,100),
        "event_id":event_id
    }

def trace_freshness(trace, now, decay_min):
    age=max(0,int(now)-int(trace["created_at"]))
    if int(decay_min)<=0: return 0
    return clamp(100 - (age*100//int(decay_min)),0,100)

def tracking_candidate(observer_id, trace, now, decay_min, minimum_confidence=25):
    freshness=trace_freshness(trace,now,decay_min)
    effective=int(trace.get("confidence",0))*freshness//100
    return {
        "kind":"TRACKING_CANDIDATE",
        "observer_actor_id":observer_id,
        "source_actor_id":trace["source_actor_id"],
        "location_id":trace["location_id"],
        "effective_confidence":effective,
        "usable":effective>=int(minimum_confidence),
        "event_id":trace.get("event_id"),
        "authority_required":True
    }

def pursuit_transition(current_state, detection_success=None, usable_track=None):
    if detection_success is True: return "DIRECT_CONTACT"
    if current_state=="DIRECT_CONTACT" and detection_success is False:
        return "LOST_CONTACT"
    if usable_track is True: return "TRACKING"
    if usable_track is False and current_state in ("TRACKING","SUSPECTED","LOST_CONTACT"):
        return "LOST_CONTACT"
    return current_state

def pursuit_move_proposal(pursuer_id,target_id,from_location,to_location,route_id,causal_event_id):
    if not route_id or from_location==to_location:
        return None
    return {
        "kind":"PURSUIT_MOVE_PROPOSAL",
        "pursuer_actor_id":pursuer_id,
        "target_actor_id":target_id,
        "from_location_id":from_location,
        "to_location_id":to_location,
        "route_id":route_id,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }
