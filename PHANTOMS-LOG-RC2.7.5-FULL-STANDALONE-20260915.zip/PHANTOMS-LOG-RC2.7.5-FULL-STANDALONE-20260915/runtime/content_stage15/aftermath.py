
def clamp(v,a,b): return max(a,min(b,v))
def injury_proposal(template, actor_id, causal_event_id):
    return {"kind":"INJURY_PROPOSAL","injury_id":template["id"],"actor_id":actor_id,
            "severity":int(template["severity"]),"effects":dict(template.get("effects",{})),
            "recovery_min":int(template["recovery_min"]),"causal_event_id":causal_event_id,"authority_required":True}
def condition_from_vitals(vital, conscious=True):
    v=int(vital)
    if v<=0:return "DEAD"
    if not conscious:return "UNCONSCIOUS"
    if v<=15:return "INCAPACITATED"
    if v<=55:return "IMPAIRED"
    return "ACTIVE"
def recovery_progress(elapsed_min, recovery_min, safe=True, treated=False):
    if recovery_min<=0:return 10000
    mult=10000 if safe else 6000
    if treated: mult=mult*14000//10000
    return clamp(int(elapsed_min)*10000*mult//(int(recovery_min)*10000),0,10000)
def death_proposal(actor_id, causal_event_id, vital):
    if int(vital)>0:return None
    return {"kind":"DEATH_PROPOSAL","actor_id":actor_id,"causal_event_id":causal_event_id,
            "permadeath":True,"authority_required":True}
def aftermath_proposals(actor_id, causal_event_id, domains):
    return [{"kind":"AFTERMATH_PROPOSAL","domain":d,"actor_id":actor_id,"causal_event_id":causal_event_id,
             "authority_required":True} for d in domains]
