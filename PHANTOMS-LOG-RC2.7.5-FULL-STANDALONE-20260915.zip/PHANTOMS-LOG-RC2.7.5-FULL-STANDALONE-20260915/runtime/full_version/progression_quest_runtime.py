from __future__ import annotations
import copy
from hashlib import sha256
from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.full_version.progression_quest_content import ProgressionQuestContent, ProgressionQuestContentError

class ProgressionQuestRuntimeError(RuntimeError): pass

class ProgressionQuestRuntime:
    """World-bound lifecycle for class chains, legend capstones and persistent quest groups.
    Content never fabricates prerequisites: callers must provide committed world references/evidence.
    """
    def __init__(self,catalog,session):
        self.catalog=catalog; self.session=session; self.content=ProgressionQuestContent(catalog.root)
    def _read(self,key): return self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
    def _commit(self,key,rec,event,cause):
        r=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(Delta(Domain.RUNTIME_STATE,key,rec,Authority.RULE_KERNEL,cause,source_event_id=event,provenance='PROGRESSION_QUEST_RUNTIME'),),event_id=event,cause=cause,expected_state_revision=self.session.store.revision))
        if not isinstance(r,CommitRecord): raise ProgressionQuestRuntimeError(cause+'_COMMIT_REJECTED')
        return rec
    def _require_world_ref(self,ref):
        if not ref or self._read(str(ref)) is None: raise ProgressionQuestRuntimeError('WORLD_BINDING_REQUIRED')
    def materialize_class_quest(self,quest_id,*,actor_id,world_ref,evidence_ref,specialization=None,mastery_path=None):
        q=self.content.class_nodes.get(str(quest_id));
        if not q: raise ProgressionQuestRuntimeError('CLASS_QUEST_UNKNOWN')
        self._require_world_ref(world_ref); self._require_world_ref(evidence_ref)
        actor=self._read(actor_id)
        if not isinstance(actor,dict) or actor.get('start_class')!=q['requirements'].get('start_class',actor.get('start_class')): raise ProgressionQuestRuntimeError('CLASS_QUEST_CLASS_MISMATCH')
        req=q.get('requirements',{})
        if req.get('specialization') and req['specialization']!=specialization: raise ProgressionQuestRuntimeError('CLASS_QUEST_SPECIALIZATION_MISMATCH')
        if req.get('mastery_path') and req['mastery_path']!=mastery_path: raise ProgressionQuestRuntimeError('CLASS_QUEST_MASTERY_MISMATCH')
        iid='quest:class:'+sha256(f"{self.session.identity.run_uuid}|{quest_id}|{world_ref}".encode()).hexdigest()[:20]
        old=self._read(iid)
        if isinstance(old,dict): return iid,old
        rec={'run_uuid':self.session.identity.run_uuid,'kind':'quest','quest_kind':'CLASS_PROGRESSION','template_id':quest_id,'state':'AVAILABLE','offeree_actor_id':actor_id,'world_ref':world_ref,'evidence_refs':[evidence_ref],'stage':q['stage'],'title':q['title'],'failure_allowed':True,'attempts':[]}
        return iid,self._commit(iid,rec,'CLASS_QUEST_MATERIALIZE:'+iid,'CLASS_QUEST_MATERIALIZE')
    def materialize_legend(self,scenario_id,*,actor_id,world_refs,evidence_refs,end_path):
        q=self.content.legend_scenarios.get(str(scenario_id));
        if not q or q['path_id']!=end_path: raise ProgressionQuestRuntimeError('LEGEND_SCENARIO_MISMATCH')
        if not world_refs or not evidence_refs: raise ProgressionQuestRuntimeError('LEGEND_WORLD_BINDING_REQUIRED')
        for ref in tuple(world_refs)+tuple(evidence_refs): self._require_world_ref(ref)
        iid='quest:legend:'+sha256(f"{self.session.identity.run_uuid}|{scenario_id}|{'|'.join(world_refs)}".encode()).hexdigest()[:20]
        old=self._read(iid)
        if isinstance(old,dict): return iid,old
        rec={'run_uuid':self.session.identity.run_uuid,'kind':'quest','quest_kind':'LEGEND_CAPSTONE','template_id':scenario_id,'path_id':end_path,'state':'AVAILABLE','offeree_actor_id':actor_id,'world_refs':list(world_refs),'evidence_refs':list(evidence_refs),'frame':q['frame'],'failure_allowed':True,'path_revocation_on_failure':False,'attempts':[]}
        return iid,self._commit(iid,rec,'LEGEND_MATERIALIZE:'+iid,'LEGEND_MATERIALIZE')
    def resolve(self,iid,*,outcome,evidence_ref):
        rec=copy.deepcopy(self._read(iid)); self._require_world_ref(evidence_ref)
        if not isinstance(rec,dict): raise ProgressionQuestRuntimeError('PROGRESSION_QUEST_MISSING')
        if outcome not in {'FULL_SUCCESS','SUCCESS_WITH_COST','PARTIAL_SUCCESS','FAILURE','CRITICAL_FAILURE'}: raise ProgressionQuestRuntimeError('PROGRESSION_OUTCOME_INVALID')
        rec['attempts'].append({'outcome':outcome,'evidence_ref':evidence_ref}); rec['state']='COMPLETED' if outcome=='FULL_SUCCESS' else ('RESOLVED' if outcome in {'SUCCESS_WITH_COST','PARTIAL_SUCCESS'} else 'FAILED')
        return self._commit(iid,rec,'PROGRESSION_QUEST_RESOLVE:'+iid+':'+str(len(rec['attempts'])),'PROGRESSION_QUEST_RESOLVE')

class PersistentQuestGroupRuntime:
    def __init__(self,catalog,session): self.catalog=catalog; self.session=session; self.content=ProgressionQuestContent(catalog.root)
    def _read(self,key): return self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
    def _commit(self,key,rec,event):
        r=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(Delta(Domain.RUNTIME_STATE,key,rec,Authority.RULE_KERNEL,'QUEST_GROUP_UPDATE',source_event_id=event,provenance='QUEST_GROUP_RUNTIME'),),event_id=event,cause='QUEST_GROUP_UPDATE',expected_state_revision=self.session.store.revision))
        if not isinstance(r,CommitRecord): raise ProgressionQuestRuntimeError('QUEST_GROUP_COMMIT_REJECTED')
        return rec
    def ensure(self,group_id,*,location_ref,evidence_ref):
        p=self.content.quest_groups.get(group_id)
        if not p: raise ProgressionQuestRuntimeError('QUEST_GROUP_UNKNOWN')
        if self._read(location_ref) is None or self._read(evidence_ref) is None: raise ProgressionQuestRuntimeError('QUEST_GROUP_WORLD_BINDING_REQUIRED')
        key='quest_group:'+group_id; old=self._read(key)
        if isinstance(old,dict): return key,old
        rec={'run_uuid':self.session.identity.run_uuid,'kind':'quest_group','group_id':group_id,'name':p['name'],'role':p['role'],'temperament':p['temperament'],'location_ref':location_ref,'state':'travel','members':[],'experience':0,'reputation':0,'relations':{},'history':[{'event':'CREATED','evidence_ref':evidence_ref}]}
        return key,self._commit(key,rec,'QUEST_GROUP_CREATE:'+group_id)
    def update(self,group_id,*,state=None,location_ref=None,experience_delta=0,reputation_delta=0,evidence_ref):
        key='quest_group:'+group_id; rec=copy.deepcopy(self._read(key))
        if not isinstance(rec,dict): raise ProgressionQuestRuntimeError('QUEST_GROUP_NOT_MATERIALIZED')
        if self._read(evidence_ref) is None: raise ProgressionQuestRuntimeError('QUEST_GROUP_EVIDENCE_REQUIRED')
        if location_ref is not None:
            if self._read(location_ref) is None: raise ProgressionQuestRuntimeError('QUEST_GROUP_LOCATION_UNKNOWN')
            rec['location_ref']=location_ref
        if state is not None:
            allowed=set(self.content.quest_groups[group_id]['encounter_states'])
            if state not in allowed: raise ProgressionQuestRuntimeError('QUEST_GROUP_STATE_INVALID')
            rec['state']=state
        rec['experience']=max(0,int(rec['experience'])+int(experience_delta)); rec['reputation']=int(rec['reputation'])+int(reputation_delta)
        rec['history'].append({'event':'UPDATE','state':rec['state'],'location_ref':rec['location_ref'],'evidence_ref':evidence_ref})
        return self._commit(key,rec,'QUEST_GROUP_UPDATE:'+group_id+':'+str(len(rec['history'])))
