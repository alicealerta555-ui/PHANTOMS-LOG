from __future__ import annotations

"""Crew, delegation and organization-capability layer.

This module deliberately coordinates existing systems instead of replacing them.
It owns only run-scoped organization membership, team definitions and operation
orders. NPC consent, combat, loot, travel, production and dungeon consequences
remain authoritative in their existing subsystems.
"""

from copy import deepcopy
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage9.world_time import WorldClock
from runtime.full_version.bootstrap import PLAYER_ACTOR_INSTANCE_ID
from runtime.content_stage17.companions import recruitment_offer, recruitment_decision, order_request
from runtime.content_stage24.organizations import membership_record, hierarchical_order

ORG_STATE_KEY = "__crew_organization_runtime__"
ORG_SCHEMA = "PH4NT0M5_CREW_ORGANIZATION_RUNTIME_V1"


class OrganizationRuntimeError(RuntimeError):
    pass


def _clamp(v: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, int(v)))


def _axis_average(skills: Mapping[str, int], ids: Sequence[str]) -> float:
    if not ids:
        return 0.0
    return sum(_clamp(int(skills.get(x, 0)), 0, 10) for x in ids) / float(len(ids))


def _lerp_curve(level: int, anchors: Sequence[int], values: Sequence[int]) -> float:
    lv=_clamp(int(level), int(anchors[0]), int(anchors[-1]))
    if lv <= anchors[0]: return float(values[0])
    if lv >= anchors[-1]: return float(values[-1])
    for i in range(1,len(anchors)):
        if lv <= anchors[i]:
            a,b=int(anchors[i-1]),int(anchors[i]); av,bv=float(values[i-1]),float(values[i])
            t=(lv-a)/float(b-a)
            return av+(bv-av)*t
    return float(values[-1])


@dataclass(frozen=True, slots=True)
class CapacityProfile:
    start_class: str
    class_identity: str
    level: int
    direct_crew: int
    command_units: int
    organization_members: int
    machine_bandwidth: int
    cell_slots: int
    delegation_tier: str
    specialization: str | None
    mastery_path: str | None
    end_path: str | None
    favored_operation_kinds: tuple[str, ...]
    narrow_core_skills: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        return {
            "start_class":self.start_class,
            "class_identity":self.class_identity,
            "level":self.level,
            "direct_crew":self.direct_crew,
            "command_units":self.command_units,
            "organization_members":self.organization_members,
            "machine_bandwidth":self.machine_bandwidth,
            "cell_slots":self.cell_slots,
            "delegation_tier":self.delegation_tier,
            "specialization":self.specialization,
            "mastery_path":self.mastery_path,
            "end_path":self.end_path,
            "favored_operation_kinds":list(self.favored_operation_kinds),
            "narrow_core_skills":list(self.narrow_core_skills),
        }


def derive_capacity(tables: Mapping[str, Any], *, start_class: str, level: int,
                    skills: Mapping[str, int], specialization: str | None=None,
                    mastery_path: str | None=None, end_path: str | None=None) -> CapacityProfile:
    cls=str(start_class or "").upper()
    curves=tables["class_curves"]
    if cls not in curves:
        raise OrganizationRuntimeError("ORGANIZATION_CLASS_INVALID")
    anchors=[int(x) for x in tables["level_anchors"]]
    level=_clamp(int(level),1,50)
    base=curves[cls]
    axes=tables["skill_axes"]
    social=_axis_average(skills,axes["social"])
    command=_axis_average(skills,axes["command"])
    machine=_axis_average(skills,axes["machine"])
    field=_axis_average(skills,axes["field"])

    # Skills scale the class curve but do not erase class identity. A character can
    # cross-train into another play style, yet doing so costs actual skill investment.
    social_factor=0.70+(social/10.0)*0.65
    command_factor=0.75+(command/10.0)*0.50
    machine_factor=0.65+(machine/10.0)*0.75
    field_factor=0.80+(field/10.0)*0.40

    direct=max(1,round(_lerp_curve(level,anchors,base["direct_crew"])*field_factor))
    command_units=max(1,round(_lerp_curve(level,anchors,base["command_units"])*command_factor))
    org=max(direct,round(_lerp_curve(level,anchors,base["organization_members"])*social_factor))
    machines=max(0,round(_lerp_curve(level,anchors,base["machine_bandwidth"])*machine_factor))
    cells=max(1,round(_lerp_curve(level,anchors,base["cell_slots"])*(0.85+field/20.0)))

    def apply_modifier(mod: Mapping[str, Any] | None):
        nonlocal direct,command_units,org,machines,cells
        if not mod:return
        direct+=int(mod.get("direct_crew",0)); command_units+=int(mod.get("command_units",0))
        org+=int(mod.get("organization_members",0)); machines+=int(mod.get("machine_bandwidth",0)); cells+=int(mod.get("cell_slots",0))

    apply_modifier(tables.get("specialization_modifiers",{}).get(str(specialization or "").upper()))
    apply_modifier(tables.get("end_path_modifiers",{}).get(str(end_path or "").upper()))

    # Hierarchical scale is impossible without actual command span. This keeps large
    # organizations dependent on delegation rather than turning Social into magic.
    if level < 10 or command_units < 2: tier="DIRECT"
    elif level < 20 or command_units < 4: tier="TEAM"
    elif level < 30 or command_units < 6: tier="MULTI_TEAM"
    elif level < 40 or command_units < 8: tier="NETWORK"
    else: tier="ORGANIZATION"

    # A player cannot meaningfully maintain more members than their hierarchy can
    # represent. This is a ceiling, not forced loyalty or obedience.
    delegation_ceiling={"DIRECT":max(direct,12),"TEAM":max(direct*4,30),"MULTI_TEAM":max(direct*10,80),"NETWORK":max(direct*24,180),"ORGANIZATION":1000}[tier]
    org=min(org,delegation_ceiling)

    favored=tuple(sorted({t["kind"] for t in tables["team_templates"].values() if cls in t.get("favored",[])}))
    narrow=tables.get("narrow_specialization_lines",{}).get(str(specialization or "").upper(),{})
    return CapacityProfile(cls,str(base["identity"]),level,direct,command_units,org,machines,cells,tier,
                           specialization,mastery_path,end_path,favored,tuple(narrow.get("core_skills",())))


class OrganizationCapabilityRuntime:
    def __init__(self, catalog, session, actor_registry, progression_runtime):
        self.catalog=catalog; self.session=session; self.actor_registry=actor_registry; self.progression_runtime=progression_runtime
        root=Path(catalog.root)/"content/full_version"
        self.tables=json.loads((root/"organization_capability_tables.json").read_text(encoding="utf-8"))
        self.companion_tables=json.loads((root/"stage17_companions.json").read_text(encoding="utf-8"))
        self.organization_tables=json.loads((root/"stage24_organizations.json").read_text(encoding="utf-8"))
        if self.tables.get("schema")!="PH4NT0M5_CREW_ORGANIZATION_TABLES_V1":
            raise OrganizationRuntimeError("ORGANIZATION_TABLE_SCHEMA_INVALID")
        self.valid_role_ids={str(x["id"]) for x in self.companion_tables.get("crew_roles",[])}
        self.valid_rank_ids={str(x["id"]) for x in self.organization_tables.get("rank_schema",[])}
        self.valid_archetype_ids={str(x["id"]) for x in self.organization_tables.get("organization_archetypes",[])}

    def _state(self) -> dict[str, Any]:
        raw=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,ORG_STATE_KEY)
        if raw is None:
            return {"schema":ORG_SCHEMA,"run_uuid":self.session.identity.run_uuid,"organization":None,
                    "members":{},"teams":{},"operations":{},"pending_recruitment":{},"warehouses":{},"facilities":{},"supply_chains":{},"resource_ledger":[],"production_reservations":{}}
        if not isinstance(raw,dict) or raw.get("schema")!=ORG_SCHEMA or raw.get("run_uuid")!=self.session.identity.run_uuid:
            raise OrganizationRuntimeError("ORGANIZATION_STATE_INVALID")
        state=deepcopy(raw)
        # Backward-compatible expansion: old saves gain empty organization-economy
        # containers without fabricating stock, facilities or routes.
        state.setdefault("warehouses",{})
        state.setdefault("facilities",{})
        state.setdefault("supply_chains",{})
        state.setdefault("resource_ledger",[])
        state.setdefault("production_reservations",{})
        return state

    def _commit(self,state: dict[str,Any],cause: str) -> CommitRecord:
        event=f"{cause}:{self.session.store.revision}"
        result=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,
            event_id=event,cause=cause,expected_state_revision=self.session.store.revision,
            deltas=(Delta(Domain.RUNTIME_STATE,ORG_STATE_KEY,state,Authority.RULE_KERNEL,cause,
                          source_event_id=event,provenance="CREW_ORGANIZATION_RUNTIME"),)))
        if not isinstance(result,CommitRecord): raise OrganizationRuntimeError(cause+"_COMMIT_REJECTED")
        return result

    def capacity(self) -> CapacityProfile:
        actor=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,PLAYER_ACTOR_INSTANCE_ID)
        if not isinstance(actor,dict) or not isinstance(actor.get("character_profile"),dict):
            raise OrganizationRuntimeError("ORGANIZATION_CHARACTER_REQUIRED")
        char=actor["character_profile"]
        prog=self.progression_runtime.snapshot().get("progression",{})
        return derive_capacity(self.tables,start_class=str(actor.get("start_class") or ""),level=int(prog.get("level",1)),
            skills=char.get("skills",{}),specialization=prog.get("specialization"),mastery_path=prog.get("mastery_path"),end_path=prog.get("end_path"))

    def _rank_authority(self, rank_id: str) -> int:
        rec=next((x for x in self.organization_tables.get("rank_schema",[]) if x.get("id")==str(rank_id)),None)
        return int(rec.get("authority_level",0)) if rec else 0

    def _staffed_member_capacity(self, state: Mapping[str,Any], profile: CapacityProfile | None=None) -> int:
        c=profile or self.capacity()
        # Direct crew can be coordinated by the player personally. Larger structures
        # require real intermediate ranks; theoretical Social capacity alone cannot
        # substitute for delegation.
        cap=int(c.direct_crew)
        leverage={"RANK_SENIOR":4,"RANK_OFFICER":10,"RANK_DEPUTY":25,"RANK_LEADER":40}
        for actor_id,rec in state.get("members",{}).items():
            if actor_id==PLAYER_ACTOR_INSTANCE_ID or not isinstance(rec,Mapping) or not rec.get("active",True): continue
            cap+=int(leverage.get(str(rec.get("rank_id")),0))
        return min(int(c.organization_members),max(int(c.direct_crew),cap))

    def staffed_member_capacity(self) -> int:
        s=self._state(); return self._staffed_member_capacity(s,self.capacity())

    def visible_profile(self) -> dict[str,Any]:
        c=self.capacity(); s=self._state()
        return {**c.as_dict(),"organization":deepcopy(s.get("organization")),"member_count":sum(1 for x in s.get("members",{}) if x!=PLAYER_ACTOR_INSTANCE_ID),
                "staffed_member_capacity":self._staffed_member_capacity(s,c),
                "team_count":len(s.get("teams",{})),"active_operations":sum(1 for x in s.get("operations",{}).values() if x.get("status")=="ACTIVE")}

    def team_templates(self) -> tuple[dict[str,Any],...]:
        c=self.capacity(); out=[]
        for tid,t in sorted(self.tables["team_templates"].items()):
            out.append({"template_id":tid,"label":t["label"],"kind":t["kind"],"min_humans":int(t["min_humans"]),
                        "max_humans":int(t["max_humans"]),"integration":list(t["integration"]),"favored":c.start_class in t.get("favored",[])})
        return tuple(out)

    def create_organization(self, display_name: str, archetype_id: str="ORG_GUILD") -> dict[str,Any]:
        name=str(display_name or "").strip()
        if not name or len(name)>96: raise OrganizationRuntimeError("ORGANIZATION_NAME_INVALID")
        archetype_id=str(archetype_id or "").upper()
        if archetype_id not in self.valid_archetype_ids: raise OrganizationRuntimeError("ORGANIZATION_ARCHETYPE_INVALID")
        state=self._state()
        if state.get("organization") is not None: raise OrganizationRuntimeError("ORGANIZATION_ALREADY_EXISTS")
        now=WorldClock(self.session).seconds; oid=f"org:player:{self.session.identity.run_uuid}"
        state["organization"]={"organization_id":oid,"display_name":name,"archetype_id":archetype_id,"created_at":now,"leader_actor_id":PLAYER_ACTOR_INSTANCE_ID}
        leader=membership_record(oid,PLAYER_ACTOR_INSTANCE_ID,"RANK_LEADER",now,True); leader["crew_role_id"]=None
        state["members"][PLAYER_ACTOR_INSTANCE_ID]=leader
        self._commit(state,"ORGANIZATION_CREATE")
        return deepcopy(state["organization"])

    def offer_recruitment(self, npc_actor_id: str, role_id: str, *, terms=(), expires_seconds: int=86400) -> dict[str,Any]:
        state=self._state(); org=state.get("organization")
        if not isinstance(org,dict): raise OrganizationRuntimeError("ORGANIZATION_REQUIRED")
        if sum(1 for x in state["members"] if x!=PLAYER_ACTOR_INSTANCE_ID)>=self._staffed_member_capacity(state): raise OrganizationRuntimeError("ORGANIZATION_STAFFED_CAPACITY_REACHED")
        role_id=str(role_id).upper()
        if role_id not in self.valid_role_ids: raise OrganizationRuntimeError("CREW_ROLE_INVALID")
        npc=str(npc_actor_id); self.actor_registry.get(npc)
        if npc==PLAYER_ACTOR_INSTANCE_ID: raise OrganizationRuntimeError("CANNOT_RECRUIT_PLAYER")
        if npc in state["members"]: raise OrganizationRuntimeError("ACTOR_ALREADY_MEMBER")
        now=WorldClock(self.session).seconds
        offer=recruitment_offer(npc,PLAYER_ACTOR_INSTANCE_ID,role_id,terms,now,now+max(60,int(expires_seconds)))
        offer_id=f"recruit:{npc}:{now}:{self.session.store.revision}"
        offer["offer_id"]=offer_id; offer["organization_id"]=org["organization_id"]
        state["pending_recruitment"][offer_id]=offer; self._commit(state,"ORGANIZATION_RECRUITMENT_OFFER")
        return deepcopy(offer)

    def resolve_recruitment(self, offer_id: str, candidate_actor_id: str, decision: str) -> dict[str,Any]:
        state=self._state(); offer=state["pending_recruitment"].get(str(offer_id))
        if not isinstance(offer,dict): raise OrganizationRuntimeError("RECRUITMENT_OFFER_NOT_FOUND")
        decided=recruitment_decision(offer,str(candidate_actor_id),str(decision).upper(),WorldClock(self.session).seconds)
        if decided is None: raise OrganizationRuntimeError("RECRUITMENT_DECISION_INVALID")
        state["pending_recruitment"][str(offer_id)]=decided
        if decided["status"]=="ACCEPTED":
            if sum(1 for x in state["members"] if x!=PLAYER_ACTOR_INSTANCE_ID)>=self._staffed_member_capacity(state): raise OrganizationRuntimeError("ORGANIZATION_STAFFED_CAPACITY_REACHED")
            oid=state["organization"]["organization_id"]
            rec=membership_record(oid,str(candidate_actor_id),"RANK_MEMBER",WorldClock(self.session).seconds,True)
            rec["crew_role_id"]=str(offer["role_id"]); state["members"][str(candidate_actor_id)]=rec
        self._commit(state,"ORGANIZATION_RECRUITMENT_DECISION")
        return deepcopy(decided)

    def apply_rank_assignment(self, actor_id: str, rank_id: str, *, authority_result_ref: str) -> dict[str,Any]:
        state=self._state(); actor=str(actor_id); rank=str(rank_id).upper()
        if actor==PLAYER_ACTOR_INSTANCE_ID: raise OrganizationRuntimeError("PLAYER_LEADER_RANK_FIXED")
        if actor not in state["members"]: raise OrganizationRuntimeError("ORGANIZATION_MEMBER_NOT_FOUND")
        if rank not in self.valid_rank_ids or rank=="RANK_LEADER": raise OrganizationRuntimeError("ORGANIZATION_RANK_INVALID")
        if not str(authority_result_ref).strip(): raise OrganizationRuntimeError("AUTHORITATIVE_RANK_RESULT_REF_REQUIRED")
        state["members"][actor]["rank_id"]=rank
        state["members"][actor]["rank_basis_ref"]=str(authority_result_ref)
        state["members"][actor]["rank_changed_at"]=WorldClock(self.session).seconds
        self._commit(state,"ORGANIZATION_RANK_ASSIGNMENT")
        return deepcopy(state["members"][actor])

    def create_team(self, team_id: str, template_id: str, member_ids: Sequence[str], *, leader_actor_id: str, machine_units: int=0, machine_profiles: Mapping[str,int] | None=None, display_name: str="") -> dict[str,Any]:
        state=self._state(); c=self.capacity(); tid=str(team_id).strip(); template_id=str(template_id).upper()
        if not tid or len(tid)>96 or tid in state["teams"]: raise OrganizationRuntimeError("TEAM_ID_INVALID_OR_EXISTS")
        template=self.tables["team_templates"].get(template_id)
        if not template: raise OrganizationRuntimeError("TEAM_TEMPLATE_UNKNOWN")
        members=list(dict.fromkeys(str(x) for x in member_ids))
        if not members: raise OrganizationRuntimeError("TEAM_REQUIRES_MEMBERS")
        if str(leader_actor_id) not in members: raise OrganizationRuntimeError("TEAM_LEADER_MUST_BE_MEMBER")
        unknown=[x for x in members if x not in state["members"]]
        if unknown: raise OrganizationRuntimeError("TEAM_MEMBER_NOT_IN_ORGANIZATION:"+",".join(unknown))
        if len(members)<int(template["min_humans"]) or len(members)>int(template["max_humans"]): raise OrganizationRuntimeError("TEAM_SIZE_OUTSIDE_TEMPLATE")
        if template["kind"]=="INTELLIGENCE":
            existing_cells=sum(1 for x in state["teams"].values() if self.tables["team_templates"].get(x.get("template_id"),{}).get("kind")=="INTELLIGENCE")
            if existing_cells>=c.cell_slots: raise OrganizationRuntimeError("CELL_SLOT_CAPACITY_EXCEEDED")
        profiles={str(k).upper():max(0,int(v)) for k,v in dict(machine_profiles or {}).items() if int(v)>0}
        unknown_profiles=[k for k in profiles if k not in self.tables.get("machine_unit_profiles",{})]
        if unknown_profiles: raise OrganizationRuntimeError("MACHINE_PROFILE_UNKNOWN:"+",".join(unknown_profiles))
        profile_units=sum(profiles.values())
        machines=max(0,int(machine_units))
        if profiles:
            if machines not in {0,profile_units}: raise OrganizationRuntimeError("MACHINE_PROFILE_COUNT_MISMATCH")
            machines=profile_units
        elif machines>0:
            profiles={"DRONE_GENERAL":machines}
        if machines>c.machine_bandwidth: raise OrganizationRuntimeError("MACHINE_BANDWIDTH_EXCEEDED")
        machine_functions=sorted({fn for pid,count in profiles.items() if count>0 for fn in self.tables["machine_unit_profiles"][pid]["functions"]})
        if leader_actor_id==PLAYER_ACTOR_INSTANCE_ID and sum(1 for x in members if x!=PLAYER_ACTOR_INSTANCE_ID)>c.direct_crew: raise OrganizationRuntimeError("DIRECT_CREW_CAPACITY_EXCEEDED")
        if leader_actor_id!=PLAYER_ACTOR_INSTANCE_ID:
            rank_id=str(state["members"][str(leader_actor_id)].get("rank_id",""))
            if self._rank_authority(rank_id)<30: raise OrganizationRuntimeError("TEAM_LEADER_RANK_TOO_LOW")
            rank_team_limit={30:4,50:8,70:16,90:int(template["max_humans"])}
            allowed=max(v for k,v in rank_team_limit.items() if self._rank_authority(rank_id)>=k)
            if len(members)>allowed: raise OrganizationRuntimeError("TEAM_LEADER_SPAN_EXCEEDED")
        team={"team_id":tid,"template_id":template_id,"display_name":str(display_name or template["label"]),"leader_actor_id":str(leader_actor_id),
              "member_ids":members,"machine_units":machines,"machine_profiles":profiles,"machine_functions":machine_functions,"status":"AVAILABLE","created_at":WorldClock(self.session).seconds}
        state["teams"][tid]=team; self._commit(state,"ORGANIZATION_TEAM_CREATE"); return deepcopy(team)

    def dispatch_operation(self, operation_id: str, team_ids: Sequence[str], *, target_ref: str, objective: str) -> dict[str,Any]:
        state=self._state(); c=self.capacity(); oid=str(operation_id).strip(); teams=list(dict.fromkeys(str(x) for x in team_ids))
        if not oid or oid in state["operations"]: raise OrganizationRuntimeError("OPERATION_ID_INVALID_OR_EXISTS")
        if not teams: raise OrganizationRuntimeError("OPERATION_REQUIRES_TEAM")
        active_teams=sum(len(x.get("team_ids",[])) for x in state["operations"].values() if x.get("status")=="ACTIVE")
        if active_teams+len(teams)>c.command_units: raise OrganizationRuntimeError("COMMAND_SPAN_EXCEEDED")
        selected=[]
        for tid in teams:
            team=state["teams"].get(tid)
            if not isinstance(team,dict): raise OrganizationRuntimeError("TEAM_NOT_FOUND:"+tid)
            if team.get("status")!="AVAILABLE": raise OrganizationRuntimeError("TEAM_NOT_AVAILABLE:"+tid)
            selected.append(team)
        human_ids=list(dict.fromkeys(x for t in selected for x in t["member_ids"]))
        machine_units=sum(int(t.get("machine_units",0)) for t in selected)
        machine_functions=sorted({fn for t in selected for fn in t.get("machine_functions",[])})
        if sum(1 for x in human_ids if x!=PLAYER_ACTOR_INSTANCE_ID)>c.organization_members: raise OrganizationRuntimeError("ORGANIZATION_MEMBER_CAPACITY_EXCEEDED")
        if machine_units>c.machine_bandwidth: raise OrganizationRuntimeError("MACHINE_BANDWIDTH_EXCEEDED")
        required_acceptance=[x for x in human_ids if x!=PLAYER_ACTOR_INSTANCE_ID]
        orders=[]
        for t in selected:
            action={"operation_id":oid,"template_id":t["template_id"],"target_ref":str(target_ref),"objective":str(objective)}
            for actor_id in t["member_ids"]:
                if actor_id==PLAYER_ACTOR_INSTANCE_ID: continue
                if t["leader_actor_id"]==PLAYER_ACTOR_INSTANCE_ID:
                    orders.append(order_request(PLAYER_ACTOR_INSTANCE_ID,actor_id,action,oid))
                else:
                    rank_id=str(state["members"][t["leader_actor_id"]].get("rank_id",""))
                    orders.append(hierarchical_order(state["organization"]["organization_id"],t["leader_actor_id"],actor_id,action,self._rank_authority(rank_id),oid))
        integrations=sorted({ref for t in selected for ref in self.tables["team_templates"][t["template_id"]]["integration"]})
        op={"operation_id":oid,"team_ids":teams,"target_ref":str(target_ref),"objective":str(objective),"status":"AWAITING_ACCEPTANCE" if required_acceptance else "READY",
            "required_actor_acceptance":required_acceptance,"accepted_actor_ids":[],"orders":orders,"integration_targets":integrations,
            "machine_units":machine_units,"machine_functions":machine_functions,"created_at":WorldClock(self.session).seconds,"result_ref":None}
        state["operations"][oid]=op
        for t in selected: state["teams"][t["team_id"]]["status"]="ASSIGNED"
        self._commit(state,"ORGANIZATION_OPERATION_DISPATCH")
        return deepcopy(op)

    def record_operation_decision(self, operation_id: str, actor_id: str, accepted: bool) -> dict[str,Any]:
        state=self._state(); op=state["operations"].get(str(operation_id))
        if not isinstance(op,dict) or op.get("status") not in {"AWAITING_ACCEPTANCE","READY"}: raise OrganizationRuntimeError("OPERATION_NOT_AWAITING_DECISION")
        actor=str(actor_id)
        if actor not in op.get("required_actor_acceptance",[]): raise OrganizationRuntimeError("ACTOR_NOT_REQUIRED_FOR_OPERATION")
        if not accepted:
            op["status"]="DECLINED"; op["declined_by"]=actor
            for tid in op["team_ids"]: state["teams"][tid]["status"]="AVAILABLE"
        else:
            if actor not in op["accepted_actor_ids"]: op["accepted_actor_ids"].append(actor)
            if set(op["required_actor_acceptance"]).issubset(set(op["accepted_actor_ids"])): op["status"]="READY"
        self._commit(state,"ORGANIZATION_OPERATION_ACTOR_DECISION"); return deepcopy(op)

    def activate_operation(self, operation_id: str) -> dict[str,Any]:
        state=self._state(); op=state["operations"].get(str(operation_id))
        if not isinstance(op,dict) or op.get("status")!="READY": raise OrganizationRuntimeError("OPERATION_NOT_READY")
        active_count=sum(len(x.get("team_ids",[])) for x in state["operations"].values() if x.get("status")=="ACTIVE")
        if active_count+len(op["team_ids"])>self.capacity().command_units: raise OrganizationRuntimeError("COMMAND_SPAN_EXCEEDED")
        op["status"]="ACTIVE"; op["activated_at"]=WorldClock(self.session).seconds
        self._commit(state,"ORGANIZATION_OPERATION_ACTIVATE"); return deepcopy(op)

    def operation_handoff(self, operation_id: str) -> dict[str,Any]:
        state=self._state(); op=state["operations"].get(str(operation_id))
        if not isinstance(op,dict) or op.get("status") not in {"READY","ACTIVE"}: raise OrganizationRuntimeError("OPERATION_NOT_READY_FOR_HANDOFF")
        actor_ids=[]
        for tid in op["team_ids"]:
            actor_ids.extend(state["teams"][tid]["member_ids"])
        return {
            "kind":"GROUP_OPERATION_HANDOFF",
            "operation_id":op["operation_id"],
            "target_ref":op["target_ref"],
            "objective":op["objective"],
            "actor_ids":list(dict.fromkeys(actor_ids)),
            "machine_units":int(op.get("machine_units",0)),
            "machine_functions":list(op.get("machine_functions",[])),
            "integration_targets":list(op.get("integration_targets",[])),
            "authority_required":True,
            "auto_resolve_forbidden":True,
        }

    def resolve_delegated_operation(self, operation_id: str, *, team_snapshots: Sequence[Mapping[str,Any]], difficulty: int=5, danger: int=0, time_pressure: int=0, preparation_bonus: int=0, logistics_bonus: int=0) -> dict[str,Any]:
        from runtime.full_version.delegated_operation_resolution import DelegatedOperationResolver
        state=self._state(); op=state["operations"].get(str(operation_id))
        if not isinstance(op,dict) or op.get("status")!="ACTIVE": raise OrganizationRuntimeError("OPERATION_NOT_ACTIVE")
        result=DelegatedOperationResolver().resolve(operation_id=str(operation_id),team_snapshots=team_snapshots,difficulty=difficulty,danger=danger,time_pressure=time_pressure,preparation_bonus=preparation_bonus,logistics_bonus=logistics_bonus,seed=self.session.identity.run_uuid)
        record={"outcome":result.outcome,"score":result.score,"target":result.target,"roll":result.roll,"team_power":result.team_power,"readiness":result.readiness,"resolved_at":WorldClock(self.session).seconds,"authoritative_consequences_required":result.outcome!="FULL_SUCCESS"}
        op.setdefault("resolution_attempts",[]).append(record)
        op["last_resolution"]=record
        self._commit(state,"ORGANIZATION_OPERATION_RESOLUTION")
        return deepcopy(record)

    def complete_operation(self, operation_id: str, *, result_ref: str) -> dict[str,Any]:
        state=self._state(); op=state["operations"].get(str(operation_id))
        if not isinstance(op,dict) or op.get("status")!="ACTIVE": raise OrganizationRuntimeError("OPERATION_NOT_ACTIVE")
        if not str(result_ref).strip(): raise OrganizationRuntimeError("AUTHORITATIVE_RESULT_REF_REQUIRED")
        op["status"]="COMPLETE"; op["result_ref"]=str(result_ref); op["completed_at"]=WorldClock(self.session).seconds
        for tid in op["team_ids"]: state["teams"][tid]["status"]="AVAILABLE"
        self._commit(state,"ORGANIZATION_OPERATION_COMPLETE"); return deepcopy(op)

    def create_warehouse(self, warehouse_id: str, *, location_id: str, display_name: str, capacity_units: int, authority_ref: str) -> dict[str,Any]:
        state=self._state(); wid=str(warehouse_id).strip(); loc=str(location_id).strip(); name=str(display_name).strip()
        if not isinstance(state.get("organization"),dict): raise OrganizationRuntimeError("ORGANIZATION_REQUIRED")
        if not wid or wid in state["warehouses"]: raise OrganizationRuntimeError("WAREHOUSE_ID_INVALID_OR_EXISTS")
        if not loc: raise OrganizationRuntimeError("WAREHOUSE_LOCATION_REQUIRED")
        if not name or len(name)>96: raise OrganizationRuntimeError("WAREHOUSE_NAME_INVALID")
        if isinstance(capacity_units,bool) or int(capacity_units)<=0: raise OrganizationRuntimeError("WAREHOUSE_CAPACITY_INVALID")
        if not str(authority_ref).strip(): raise OrganizationRuntimeError("AUTHORITATIVE_WAREHOUSE_REF_REQUIRED")
        rec={"warehouse_id":wid,"location_id":loc,"display_name":name,"capacity_units":int(capacity_units),
             "stock":{},"created_at":WorldClock(self.session).seconds,"authority_ref":str(authority_ref),"status":"ACTIVE"}
        state["warehouses"][wid]=rec; self._commit(state,"ORGANIZATION_WAREHOUSE_CREATE"); return deepcopy(rec)

    def record_warehouse_flow(self, warehouse_id: str, *, direction: str, resource_ref: str, quantity: int, evidence_ref: str, operation_id: str | None=None) -> dict[str,Any]:
        state=self._state(); wh=state["warehouses"].get(str(warehouse_id)); d=str(direction).upper(); resource=str(resource_ref).strip()
        if not isinstance(wh,dict): raise OrganizationRuntimeError("WAREHOUSE_NOT_FOUND")
        if d not in {"IN","OUT"}: raise OrganizationRuntimeError("WAREHOUSE_FLOW_DIRECTION_INVALID")
        if not resource: raise OrganizationRuntimeError("WAREHOUSE_RESOURCE_REQUIRED")
        if isinstance(quantity,bool) or int(quantity)<=0: raise OrganizationRuntimeError("WAREHOUSE_QUANTITY_INVALID")
        if not str(evidence_ref).strip(): raise OrganizationRuntimeError("WAREHOUSE_EVIDENCE_REQUIRED")
        qty=int(quantity); current=int(wh["stock"].get(resource,0)); total=sum(int(v) for v in wh["stock"].values())
        if d=="IN" and total+qty>int(wh["capacity_units"]): raise OrganizationRuntimeError("WAREHOUSE_CAPACITY_EXCEEDED")
        if d=="OUT" and current<qty: raise OrganizationRuntimeError("WAREHOUSE_STOCK_INSUFFICIENT")
        after=current+qty if d=="IN" else current-qty
        if after: wh["stock"][resource]=after
        else: wh["stock"].pop(resource,None)
        entry={"warehouse_id":str(warehouse_id),"direction":d,"resource_ref":resource,"quantity":qty,"evidence_ref":str(evidence_ref),
               "operation_id":str(operation_id or ""),"world_time":WorldClock(self.session).seconds}
        state["resource_ledger"].append(entry); self._commit(state,"ORGANIZATION_WAREHOUSE_FLOW"); return deepcopy(entry)

    def create_facility(self, facility_id: str, *, facility_kind: str, location_id: str, input_warehouse_id: str, output_warehouse_id: str, authority_ref: str) -> dict[str,Any]:
        state=self._state(); fid=str(facility_id).strip(); kind=str(facility_kind).upper(); loc=str(location_id).strip()
        if not fid or fid in state["facilities"]: raise OrganizationRuntimeError("FACILITY_ID_INVALID_OR_EXISTS")
        if kind not in {"WORKSHOP","PROCESSOR","FABRICATION","FARM","MEDICAL","POWER","WATER"}: raise OrganizationRuntimeError("FACILITY_KIND_INVALID")
        if not loc: raise OrganizationRuntimeError("FACILITY_LOCATION_REQUIRED")
        if input_warehouse_id not in state["warehouses"] or output_warehouse_id not in state["warehouses"]: raise OrganizationRuntimeError("FACILITY_WAREHOUSE_REQUIRED")
        if not str(authority_ref).strip(): raise OrganizationRuntimeError("AUTHORITATIVE_FACILITY_REF_REQUIRED")
        rec={"facility_id":fid,"facility_kind":kind,"location_id":loc,"input_warehouse_id":str(input_warehouse_id),"output_warehouse_id":str(output_warehouse_id),
             "status":"ACTIVE","authority_ref":str(authority_ref),"created_at":WorldClock(self.session).seconds,"production_runs":[],"specialization_level":1}
        state["facilities"][fid]=rec; self._commit(state,"ORGANIZATION_FACILITY_CREATE"); return deepcopy(rec)

    def set_facility_specialization_level(self, facility_id: str, level: int, *, authority_ref: str) -> dict[str,Any]:
        state=self._state(); fac=state["facilities"].get(str(facility_id))
        if not isinstance(fac,dict): raise OrganizationRuntimeError("FACILITY_NOT_FOUND")
        if not str(authority_ref).strip(): raise OrganizationRuntimeError("FACILITY_UPGRADE_AUTHORITY_REQUIRED")
        from runtime.full_version.organization_production_recipes import ProductionRecipeCatalog
        cfg=ProductionRecipeCatalog(self.catalog).facility_kinds.get(str(fac.get("facility_kind")),{})
        lv=int(level); max_lv=int(cfg.get("max_specialization_level",3))
        if lv<1 or lv>max_lv: raise OrganizationRuntimeError("FACILITY_SPECIALIZATION_LEVEL_INVALID")
        fac["specialization_level"]=lv; fac["specialization_authority_ref"]=str(authority_ref)
        self._commit(state,"ORGANIZATION_FACILITY_SPECIALIZE"); return deepcopy(fac)

    def start_production_run(self, facility_id: str, run_id: str, *, input_facts: Sequence[Mapping[str,Any]], duration_seconds: int, start_evidence_ref: str, recipe_id: str | None=None) -> dict[str,Any]:
        from runtime.full_version.organization_resource_flows import OrganizationResourceFlowPlanner
        state=self._state(); fac=state["facilities"].get(str(facility_id)); rid=str(run_id).strip()
        if not isinstance(fac,dict) or fac.get("status")!="ACTIVE": raise OrganizationRuntimeError("FACILITY_NOT_ACTIVE")
        if not rid or rid in state["production_reservations"]: raise OrganizationRuntimeError("PRODUCTION_RUN_ID_INVALID_OR_EXISTS")
        if isinstance(duration_seconds,bool) or int(duration_seconds)<0: raise OrganizationRuntimeError("PRODUCTION_DURATION_INVALID")
        if not str(start_evidence_ref).strip(): raise OrganizationRuntimeError("PRODUCTION_START_EVIDENCE_REQUIRED")
        plan=OrganizationResourceFlowPlanner().plan(operation_kind="PRODUCTION_CHAIN",outcome="FULL_SUCCESS",input_facts=input_facts,output_facts=())
        if "REAL_INPUTS_REQUIRED" in plan.unresolved: raise OrganizationRuntimeError("PRODUCTION_FLOW_UNRESOLVED:REAL_INPUTS_REQUIRED")
        recipe=None; recipe_batches=None
        if recipe_id:
            from runtime.full_version.organization_production_recipes import ProductionRecipeCatalog, ProductionRecipeError
            try:
                recipe=ProductionRecipeCatalog(self.catalog).validate_facility(fac,str(recipe_id))
                recipe_batches=ProductionRecipeCatalog(self.catalog).validate_inputs(recipe,plan.accepted_inputs)
            except ProductionRecipeError as exc:
                raise OrganizationRuntimeError(str(exc)) from exc
            duration_seconds=max(int(duration_seconds),int(recipe.get("base_duration_seconds",0))*int(recipe_batches))
        wh=state["warehouses"][fac["input_warehouse_id"]]
        required={}
        for fact in plan.accepted_inputs:
            required[fact["resource_ref"]]=required.get(fact["resource_ref"],0)+int(fact["quantity"])
        for resource,qty in required.items():
            if int(wh["stock"].get(resource,0))<qty: raise OrganizationRuntimeError("WAREHOUSE_STOCK_INSUFFICIENT")
        # Reservation removes inputs from free stock immediately, preventing double-spend.
        for resource,qty in required.items():
            left=int(wh["stock"].get(resource,0))-qty
            if left: wh["stock"][resource]=left
            else: wh["stock"].pop(resource,None)
        now=WorldClock(self.session).seconds
        run={"run_id":rid,"facility_id":str(facility_id),"status":"IN_PROGRESS","input_facts":[dict(x) for x in plan.accepted_inputs],
             "reserved_inputs":required,"started_at":now,"ready_at":now+int(duration_seconds),"start_evidence_ref":str(start_evidence_ref),"resolution":None,"recipe_id":str(recipe_id or ""),"recipe_batches":recipe_batches}
        state["production_reservations"][rid]=run
        state["resource_ledger"].append({"facility_id":str(facility_id),"run_id":rid,"direction":"RESERVE","resources":deepcopy(required),"evidence_ref":str(start_evidence_ref),"world_time":now})
        self._commit(state,"ORGANIZATION_PRODUCTION_START"); return deepcopy(run)

    def resolve_production_run_with_team(self, run_id: str, *, team_snapshots: Sequence[Mapping[str,Any]], difficulty: int=5, danger: int=0, time_pressure: int=0, preparation_bonus: int=0, logistics_bonus: int=0, output_facts: Sequence[Mapping[str,Any]]=(), result_ref: str) -> dict[str,Any]:
        """Resolve production from authoritative workforce snapshots.

        Class/profession never locks production. Skills, equipment, condition,
        machines, preparation and logistics affect success. Output remains
        fact-bound and is never fabricated from the success roll.
        """
        from runtime.full_version.delegated_operation_resolution import DelegatedOperationResolver, DelegatedOperationResolutionError
        state=self._state(); rid=str(run_id); run=state["production_reservations"].get(rid)
        if not isinstance(run,dict): raise OrganizationRuntimeError("PRODUCTION_RUN_NOT_FOUND")
        if run.get("status")!="IN_PROGRESS": raise OrganizationRuntimeError("PRODUCTION_RUN_ALREADY_RESOLVED")
        fac=state["facilities"].get(run.get("facility_id"))
        if not isinstance(fac,dict) or fac.get("status")!="ACTIVE": raise OrganizationRuntimeError("FACILITY_NOT_ACTIVE")
        try:
            result=DelegatedOperationResolver().resolve(operation_id="production:"+rid,team_snapshots=team_snapshots,difficulty=difficulty,danger=danger,time_pressure=time_pressure,preparation_bonus=preparation_bonus,logistics_bonus=logistics_bonus,seed=self.session.identity.run_uuid)
        except DelegatedOperationResolutionError as exc:
            raise OrganizationRuntimeError("PRODUCTION_TEAM_RESOLUTION_INVALID:"+str(exc)) from exc
        run["workforce_resolution"]={"outcome":result.outcome,"score":result.score,"target":result.target,"roll":result.roll,"team_power":result.team_power,"readiness":result.readiness,"difficulty":int(difficulty),"danger":int(danger),"time_pressure":int(time_pressure),"preparation_bonus":int(preparation_bonus),"logistics_bonus":int(logistics_bonus),"evidence_refs":[str(x.get("evidence_ref")) for x in team_snapshots]}
        self._commit(state,"ORGANIZATION_PRODUCTION_WORKFORCE_RESOLUTION")
        return self.resolve_production_run(rid,outcome=result.outcome,output_facts=output_facts,result_ref=result_ref)

    def resolve_production_run(self, run_id: str, *, outcome: str, output_facts: Sequence[Mapping[str,Any]]=(), result_ref: str) -> dict[str,Any]:
        from runtime.full_version.organization_resource_flows import OrganizationResourceFlowPlanner
        state=self._state(); rid=str(run_id); run=state["production_reservations"].get(rid)
        if not isinstance(run,dict): raise OrganizationRuntimeError("PRODUCTION_RUN_NOT_FOUND")
        if run.get("status")!="IN_PROGRESS": raise OrganizationRuntimeError("PRODUCTION_RUN_ALREADY_RESOLVED")
        if not str(result_ref).strip(): raise OrganizationRuntimeError("AUTHORITATIVE_PRODUCTION_RESULT_REF_REQUIRED")
        now=WorldClock(self.session).seconds
        if now<int(run["ready_at"]): raise OrganizationRuntimeError("PRODUCTION_RUN_NOT_READY")
        result=str(outcome).upper()
        if result not in {"FULL_SUCCESS","SUCCESS_WITH_COST","PARTIAL_SUCCESS","FAILURE","CRITICAL_FAILURE"}: raise OrganizationRuntimeError("PRODUCTION_OUTCOME_INVALID")
        fac=state["facilities"].get(run["facility_id"])
        if not isinstance(fac,dict): raise OrganizationRuntimeError("FACILITY_NOT_FOUND")
        plan=OrganizationResourceFlowPlanner().plan(operation_kind="PRODUCTION_CHAIN",outcome=result,input_facts=run["input_facts"],output_facts=output_facts)
        if run.get("recipe_id"):
            from runtime.full_version.organization_production_recipes import ProductionRecipeCatalog, ProductionRecipeError
            try:
                rc=ProductionRecipeCatalog(self.catalog); recipe=rc.validate_facility(fac,run["recipe_id"]); rc.validate_outputs(recipe,plan.proposed_outputs,int(run.get("recipe_batches") or 1))
            except ProductionRecipeError as exc:
                raise OrganizationRuntimeError(str(exc)) from exc
        out_wh=state["warehouses"][fac["output_warehouse_id"]]
        output_totals={}
        for fact in plan.proposed_outputs:
            output_totals[fact["resource_ref"]]=output_totals.get(fact["resource_ref"],0)+int(fact["quantity"])
        if sum(int(v) for v in out_wh["stock"].values())+sum(output_totals.values())>int(out_wh["capacity_units"]): raise OrganizationRuntimeError("WAREHOUSE_CAPACITY_EXCEEDED")
        # Reserved inputs are consumed on all resolved outcomes. Outputs exist only when
        # an authoritative production result explicitly supplies them.
        for resource,qty in output_totals.items(): out_wh["stock"][resource]=int(out_wh["stock"].get(resource,0))+qty
        run["status"]="RESOLVED"; run["resolution"]={"outcome":result,"result_ref":str(result_ref),"output_facts":[dict(x) for x in plan.proposed_outputs],"resolved_at":now}
        fac["production_runs"].append(deepcopy(run))
        state["resource_ledger"].append({"facility_id":run["facility_id"],"run_id":rid,"direction":"CONSUME_RESERVED","resources":deepcopy(run["reserved_inputs"]),"evidence_ref":str(result_ref),"world_time":now})
        if output_totals: state["resource_ledger"].append({"facility_id":run["facility_id"],"run_id":rid,"direction":"PRODUCE","resources":deepcopy(output_totals),"evidence_ref":str(result_ref),"world_time":now})
        self._commit(state,"ORGANIZATION_PRODUCTION_RESOLVE"); return deepcopy(run)

    def cancel_production_run(self, run_id: str, *, cancellation_ref: str, return_reserved_inputs: bool=False) -> dict[str,Any]:
        state=self._state(); rid=str(run_id); run=state["production_reservations"].get(rid)
        if not isinstance(run,dict): raise OrganizationRuntimeError("PRODUCTION_RUN_NOT_FOUND")
        if run.get("status")!="IN_PROGRESS": raise OrganizationRuntimeError("PRODUCTION_RUN_ALREADY_RESOLVED")
        if not str(cancellation_ref).strip(): raise OrganizationRuntimeError("PRODUCTION_CANCELLATION_REF_REQUIRED")
        if return_reserved_inputs:
            fac=state["facilities"][run["facility_id"]]; wh=state["warehouses"][fac["input_warehouse_id"]]
            if sum(int(v) for v in wh["stock"].values())+sum(int(v) for v in run["reserved_inputs"].values())>int(wh["capacity_units"]): raise OrganizationRuntimeError("WAREHOUSE_CAPACITY_EXCEEDED")
            for resource,qty in run["reserved_inputs"].items(): wh["stock"][resource]=int(wh["stock"].get(resource,0))+int(qty)
        run["status"]="CANCELLED"; run["cancellation_ref"]=str(cancellation_ref); run["reserved_inputs_returned"]=bool(return_reserved_inputs); run["cancelled_at"]=WorldClock(self.session).seconds
        self._commit(state,"ORGANIZATION_PRODUCTION_CANCEL"); return deepcopy(run)

    def record_production_run(self, facility_id: str, *, input_facts: Sequence[Mapping[str,Any]], output_facts: Sequence[Mapping[str,Any]], result_ref: str) -> dict[str,Any]:
        """Compatibility recorder for externally resolved production facts.

        It records authoritative facts but intentionally does not mutate warehouse
        stock. New runtime production should use start_production_run/resolve_production_run.
        """
        from runtime.full_version.organization_resource_flows import OrganizationResourceFlowPlanner
        state=self._state(); fac=state["facilities"].get(str(facility_id))
        if not isinstance(fac,dict) or fac.get("status")!="ACTIVE": raise OrganizationRuntimeError("FACILITY_NOT_ACTIVE")
        if not str(result_ref).strip(): raise OrganizationRuntimeError("AUTHORITATIVE_PRODUCTION_RESULT_REF_REQUIRED")
        plan=OrganizationResourceFlowPlanner().plan(operation_kind="PRODUCTION_CHAIN",outcome="FULL_SUCCESS",input_facts=input_facts,output_facts=output_facts)
        if plan.unresolved: raise OrganizationRuntimeError("PRODUCTION_FLOW_UNRESOLVED:"+",".join(plan.unresolved))
        run={"result_ref":str(result_ref),"input_facts":[dict(x) for x in plan.accepted_inputs],"output_facts":[dict(x) for x in plan.proposed_outputs],"world_time":WorldClock(self.session).seconds,"legacy_external_record":True}
        fac["production_runs"].append(run); self._commit(state,"ORGANIZATION_PRODUCTION_RECORD"); return deepcopy(run)

    def create_supply_chain(self, chain_id: str, *, source_warehouse_id: str, destination_warehouse_id: str, resource_ref: str, team_id: str, authority_ref: str) -> dict[str,Any]:
        state=self._state(); cid=str(chain_id).strip(); resource=str(resource_ref).strip()
        if not cid or cid in state["supply_chains"]: raise OrganizationRuntimeError("SUPPLY_CHAIN_ID_INVALID_OR_EXISTS")
        if source_warehouse_id not in state["warehouses"] or destination_warehouse_id not in state["warehouses"]: raise OrganizationRuntimeError("SUPPLY_CHAIN_WAREHOUSE_REQUIRED")
        if source_warehouse_id==destination_warehouse_id: raise OrganizationRuntimeError("SUPPLY_CHAIN_DISTINCT_WAREHOUSES_REQUIRED")
        if team_id not in state["teams"]: raise OrganizationRuntimeError("SUPPLY_CHAIN_TEAM_REQUIRED")
        if not resource: raise OrganizationRuntimeError("SUPPLY_CHAIN_RESOURCE_REQUIRED")
        if not str(authority_ref).strip(): raise OrganizationRuntimeError("AUTHORITATIVE_SUPPLY_CHAIN_REF_REQUIRED")
        rec={"chain_id":cid,"source_warehouse_id":str(source_warehouse_id),"destination_warehouse_id":str(destination_warehouse_id),"resource_ref":resource,
             "team_id":str(team_id),"status":"ACTIVE","authority_ref":str(authority_ref),"created_at":WorldClock(self.session).seconds,"shipments":[]}
        state["supply_chains"][cid]=rec; self._commit(state,"ORGANIZATION_SUPPLY_CHAIN_CREATE"); return deepcopy(rec)

    def record_supply_shipment(self, chain_id: str, *, quantity: int, departure_evidence_ref: str, arrival_evidence_ref: str | None=None) -> dict[str,Any]:
        state=self._state(); chain=state["supply_chains"].get(str(chain_id))
        if not isinstance(chain,dict) or chain.get("status")!="ACTIVE": raise OrganizationRuntimeError("SUPPLY_CHAIN_NOT_ACTIVE")
        if isinstance(quantity,bool) or int(quantity)<=0: raise OrganizationRuntimeError("SUPPLY_CHAIN_QUANTITY_INVALID")
        if not str(departure_evidence_ref).strip(): raise OrganizationRuntimeError("SUPPLY_CHAIN_DEPARTURE_EVIDENCE_REQUIRED")
        qty=int(quantity); src=state["warehouses"][chain["source_warehouse_id"]]; dst=state["warehouses"][chain["destination_warehouse_id"]]; resource=chain["resource_ref"]
        if int(src["stock"].get(resource,0))<qty: raise OrganizationRuntimeError("WAREHOUSE_STOCK_INSUFFICIENT")
        shipment={"quantity":qty,"resource_ref":resource,"departure_evidence_ref":str(departure_evidence_ref),"arrival_evidence_ref":str(arrival_evidence_ref or ""),
                  "status":"DELIVERED" if arrival_evidence_ref else "IN_TRANSIT","departed_at":WorldClock(self.session).seconds}
        src["stock"][resource]-=qty
        if src["stock"][resource]==0: src["stock"].pop(resource,None)
        if arrival_evidence_ref:
            if sum(int(v) for v in dst["stock"].values())+qty>int(dst["capacity_units"]): raise OrganizationRuntimeError("WAREHOUSE_CAPACITY_EXCEEDED")
            dst["stock"][resource]=int(dst["stock"].get(resource,0))+qty
        chain["shipments"].append(shipment); state["resource_ledger"].append({"chain_id":str(chain_id),**shipment})
        self._commit(state,"ORGANIZATION_SUPPLY_SHIPMENT"); return deepcopy(shipment)

    def state_view(self) -> dict[str,Any]:
        s=self._state(); return {"organization":deepcopy(s["organization"]),"members":deepcopy(s["members"]),"teams":deepcopy(s["teams"]),"operations":deepcopy(s["operations"]),
            "warehouses":deepcopy(s["warehouses"]),"facilities":deepcopy(s["facilities"]),"supply_chains":deepcopy(s["supply_chains"]),"resource_ledger":deepcopy(s["resource_ledger"]),"production_reservations":deepcopy(s["production_reservations"])}
