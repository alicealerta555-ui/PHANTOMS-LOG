from __future__ import annotations
from dataclasses import dataclass
import copy, json
from hashlib import sha256

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage9.world_time import WorldClock
from runtime.full_version.bootstrap import PLAYER_ACTOR_INSTANCE_ID
from runtime.full_version.mission_resolution import MissionResolver

class QuestRuntimeError(RuntimeError): pass

@dataclass(frozen=True,slots=True)
class QuestOffer:
    quest_instance_id:str; template_id:str; issuer_actor_id:str; kind:str; objectives:tuple[str,...]


def _hash(text: str) -> int:
    return int.from_bytes(sha256(text.encode('utf-8')).digest()[:8],'big')


class QuestRuntime:
    def __init__(self,catalog,session):
        self.catalog=catalog; self.session=session
        raw=json.loads((catalog.root/'content/full_version/stage12_quests_contracts.json').read_text(encoding='utf-8'))
        self.templates={x['id']:x for x in raw['quest_templates']}
        self.consequences={x['trigger']:x for x in raw.get('consequence_chains',[])}
        self.aliases=catalog.npc_runtime_tables['quest_role_aliases']
        bindings=json.loads((catalog.root/'content/full_version/quest_playable_bindings.json').read_text(encoding='utf-8'))
        if bindings.get('schema')!='PH4NT0M5_QUEST_PLAYABLE_BINDINGS_V1': raise QuestRuntimeError('QUEST_BINDINGS_SCHEMA_INVALID')
        self.bindings=bindings['bindings']
        self.mission_resolver=MissionResolver(catalog)

    def _knowledge_has(self,actor_id,key):
        return self.session.kernel.read(Authority.KNOWLEDGE_ROUTER,Domain.ACTOR_KNOWLEDGE,key,actor_id=actor_id) is not None

    def _commit(self,deltas,event,cause):
        result=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=tuple(deltas),event_id=event,cause=cause,expected_state_revision=self.session.store.revision))
        if not isinstance(result,CommitRecord): raise QuestRuntimeError(cause+'_COMMIT_REJECTED')
        return result

    def _target_location(self, template_id: str, qid: str, issuer_location: str) -> str:
        binding=self.bindings[template_id]
        cats=set(binding['target_categories'])
        options=sorted(x['location_id'] for x in self.catalog.world['locations'] if x['primary_category'] in cats and x['location_id']!=issuer_location)
        if not options:
            options=sorted(x['location_id'] for x in self.catalog.world['locations'] if x['primary_category'] in cats)
        if not options: raise QuestRuntimeError('QUEST_TARGET_CATEGORY_EMPTY')
        return options[_hash(f'{self.session.identity.run_uuid}|{qid}|target')%len(options)]

    def eligible(self,npc_id,actor_id=PLAYER_ACTOR_INSTANCE_ID):
        npc=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,npc_id)
        actor=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,actor_id)
        if not isinstance(npc,dict) or not isinstance(actor,dict) or npc.get('location_ref')!=actor.get('location_ref'): return []
        out=[]
        for t in self.templates.values():
            if npc.get('role') not in self.aliases.get(t['issuer_role'],[]): continue
            if all(self._knowledge_has(actor_id,k) for k in t.get('prerequisites',[])): out.append(t)
        return out

    def offer_for_npc(self,npc_id,actor_id=PLAYER_ACTOR_INSTANCE_ID):
        offers=[]; now=WorldClock(self.session).seconds
        npc=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,npc_id)
        if not isinstance(npc,dict): return offers
        for t in self.eligible(npc_id,actor_id):
            qid='quest:'+sha256(f'{self.session.identity.run_uuid}|{t["id"]}|{npc_id}'.encode()).hexdigest()[:20]
            rec=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
            if rec is None:
                binding=copy.deepcopy(self.bindings[t['id']])
                target=self._target_location(t['id'],qid,str(npc['location_ref']))
                asset_id='item:quest:'+sha256(f'{qid}|asset'.encode()).hexdigest()[:20]
                grant=bool(binding.get('grant_on_accept'))
                asset={
                    'run_uuid':self.session.identity.run_uuid,'kind':'item',
                    'item_definition_id':binding['asset_item_definition_id'],
                    'location_ref':f'inventory:{npc_id}' if grant else target,
                    'owner_actor_instance_id':npc_id if grant else None,
                    'condition':35 if binding.get('requires_repair') else 100,'max_condition':100,
                    'hidden':False if grant else bool(binding.get('search_reveals_asset')),
                    'merchant_stock':False,'quest_instance_id':qid,'provenance':'QUEST_BINDING'
                }
                if asset['owner_actor_instance_id'] is None: asset.pop('owner_actor_instance_id')
                rec={
                    'run_uuid':self.session.identity.run_uuid,'kind':'quest','template_id':t['id'],'state':'AVAILABLE',
                    'issuer_actor_id':npc_id,'offeree_actor_id':actor_id,'offered_at':now,
                    'objectives':list(t.get('objectives',[])),'outcomes':list(t.get('outcomes',[])),
                    'target_location_id':target,'asset_item_id':asset_id,'binding':binding,'progress':{},
                }
                if grant: rec['accept_grant_item_id']=asset_id
                event='QUEST_OFFER:'+qid
                self._commit((
                    Delta(Domain.RUNTIME_STATE,qid,rec,Authority.RULE_KERNEL,'QUEST_OFFER',source_event_id=event,provenance='QUEST_TEMPLATE'),
                    Delta(Domain.RUNTIME_STATE,asset_id,asset,Authority.RULE_KERNEL,'QUEST_ASSET_MATERIALIZE',source_event_id=event,provenance='QUEST_PLAYABLE_BINDING'),
                ),event,'QUEST_OFFER')
            rec=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
            if isinstance(rec,dict) and rec.get('state')=='AVAILABLE':
                offers.append(QuestOffer(qid,t['id'],npc_id,t['kind'],tuple(t.get('objectives',[]))))
        return offers

    def active(self,actor_id=PLAYER_ACTOR_INSTANCE_ID):
        out=[]
        for key in self.session.store.runtime_state:
            if not str(key).startswith('quest:'): continue
            rec=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
            if isinstance(rec,dict) and rec.get('offeree_actor_id')==actor_id: out.append((key,rec))
        return out


    def materialize_dynamic_seed(self, seed: dict, actor_id=PLAYER_ACTOR_INSTANCE_ID):
        """Turn a discovered persistent-world seed into a normal authoritative quest record."""
        if not isinstance(seed,dict) or not seed.get('seed_id') or not seed.get('kind'):
            raise QuestRuntimeError('DYNAMIC_QUEST_SEED_INVALID')
        seed_id=str(seed['seed_id']); kind=str(seed['kind']); loc=str(seed.get('location_id',''))
        qid='quest:dynamic:'+sha256(f"{self.session.identity.run_uuid}|{seed_id}".encode()).hexdigest()[:20]
        existing=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
        if isinstance(existing,dict): return qid,existing
        payload=copy.deepcopy(seed.get('payload') or {})
        definitions={
            'REBUILD':('Wiederaufbau','Stabilisiere und repariere die beschädigte Infrastruktur.',('infrastructure_rebuilt',)),
            'CORPSE_INVESTIGATION':('Todesfall untersuchen','Untersuche die aufgefundene Leiche und sichere den Befund.',('corpse_investigated',)),
            'EVENT_INVESTIGATION':('Ereignis untersuchen','Untersuche die sichtbaren Folgen des Ereignisses vor Ort.',('event_investigated',)),
        }
        if kind not in definitions: raise QuestRuntimeError('DYNAMIC_QUEST_KIND_UNKNOWN')
        title,objective,outcomes=definitions[kind]
        rec={
            'run_uuid':self.session.identity.run_uuid,'kind':'quest','template_id':'dynamic:'+kind.lower(),
            'dynamic_kind':kind,'state':'AVAILABLE','issuer_actor_id':str(seed.get('source_id') or seed_id),
            'offeree_actor_id':actor_id,'offered_at':WorldClock(self.session).seconds,
            'objectives':[objective],'outcomes':list(outcomes),'target_location_id':loc,
            'binding':{'completion':'dynamic'},'progress':{},'dynamic_payload':payload,
            'source_seed_id':seed_id,'display_name':title,
        }
        event='DYNAMIC_QUEST_OFFER:'+qid
        self._commit((Delta(Domain.RUNTIME_STATE,qid,rec,Authority.RULE_KERNEL,'DYNAMIC_QUEST_OFFER',source_event_id=event,provenance='PERSISTENT_WORLD_QUEST_SEED'),),event,'DYNAMIC_QUEST_OFFER')
        return qid,self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)

    def _complete_dynamic(self,qid: str, outcome: str, **progress):
        q=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
        if not isinstance(q,dict) or q.get('state')!='ACTIVE' or not q.get('dynamic_kind'): return False
        if outcome not in q.get('outcomes',[]): raise QuestRuntimeError('DYNAMIC_QUEST_OUTCOME_INVALID')
        q=copy.deepcopy(q); q.setdefault('progress',{}).update(progress); q['state']='COMPLETED'; q['completed_at']=WorldClock(self.session).seconds; q['final_outcome']=outcome
        event=f'DYNAMIC_QUEST_COMPLETE:{qid}:{outcome}'
        self._commit((Delta(Domain.RUNTIME_STATE,qid,q,Authority.RULE_KERNEL,'DYNAMIC_QUEST_COMPLETE',source_event_id=event,provenance='PERSISTENT_WORLD_QUEST'),),event,'DYNAMIC_QUEST_COMPLETE')
        return True

    def observe_dynamic_search(self, location_id: str, actor_id=PLAYER_ACTOR_INSTANCE_ID):
        completed=[]
        for qid,q in list(self.active(actor_id)):
            if q.get('state')=='ACTIVE' and q.get('dynamic_kind')=='EVENT_INVESTIGATION' and q.get('target_location_id')==location_id:
                if self._complete_dynamic(qid,'event_investigated',searched_target=True): completed.append(qid)
        return completed

    def observe_corpse_investigation(self, corpse_id: str, actor_id=PLAYER_ACTOR_INSTANCE_ID):
        completed=[]
        for qid,q in list(self.active(actor_id)):
            if q.get('state')!='ACTIVE' or q.get('dynamic_kind')!='CORPSE_INVESTIGATION': continue
            if str((q.get('dynamic_payload') or {}).get('corpse_id'))!=str(corpse_id): continue
            if self._complete_dynamic(qid,'corpse_investigated',corpse_investigated=True): completed.append(qid)
        return completed

    def observe_rebuild(self, location_id: str, *, infrastructure_state: str, integrity: int, actor_id=PLAYER_ACTOR_INSTANCE_ID):
        completed=[]
        if str(infrastructure_state) not in {'INTACT','DEGRADED'} and int(integrity)<90: return completed
        for qid,q in list(self.active(actor_id)):
            if q.get('state')=='ACTIVE' and q.get('dynamic_kind')=='REBUILD' and q.get('target_location_id')==location_id:
                if self._complete_dynamic(qid,'infrastructure_rebuilt',integrity=int(integrity)): completed.append(qid)
        return completed

    def resolve_mission_attempt(self, qid: str, *, actor_id=PLAYER_ACTOR_INSTANCE_ID, difficulty: int=5, equipment_bonus: int=0, preparation_bonus: int=0, crew_bonus: int=0, situation_modifier: int=0, danger: int=0, time_pressure: int=0):
        q=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
        if not isinstance(q,dict) or q.get('kind')!='quest': raise QuestRuntimeError('MISSION_QUEST_REQUIRED')
        if q.get('state')!='ACTIVE': raise QuestRuntimeError('MISSION_QUEST_NOT_ACTIVE')
        if q.get('offeree_actor_id')!=actor_id: raise QuestRuntimeError('MISSION_ACTOR_MISMATCH')
        family=q.get('mission_family')
        if not family: raise QuestRuntimeError('MISSION_FAMILY_REQUIRED')
        actor=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,actor_id)
        if not isinstance(actor,dict): raise QuestRuntimeError('MISSION_ACTOR_REQUIRED')
        attempts=list(q.get('mission_attempts') or [])
        result=self.mission_resolver.resolve(actor=actor,mission_family=family,difficulty=difficulty,attempt_no=len(attempts)+1,equipment_bonus=equipment_bonus,preparation_bonus=preparation_bonus,crew_bonus=crew_bonus,situation_modifier=situation_modifier,danger=danger,time_pressure=time_pressure,seed=f'{self.session.identity.run_uuid}|{qid}')
        entry={'attempt_no':len(attempts)+1,'at':WorldClock(self.session).seconds,'outcome':result.outcome,'score':result.score,'difficulty':result.difficulty,'roll':result.roll,'primary_skill':result.primary_skill,'primary_value':result.primary_value,'inputs':{'equipment_bonus':int(equipment_bonus),'preparation_bonus':int(preparation_bonus),'crew_bonus':int(crew_bonus),'situation_modifier':int(situation_modifier),'danger':int(danger),'time_pressure':int(time_pressure)}}
        q=copy.deepcopy(q); q.setdefault('mission_attempts',[]).append(entry); q['last_mission_outcome']=result.outcome
        if result.outcome in {'FAILURE','CRITICAL_FAILURE','SUCCESS_WITH_COST','PARTIAL_SUCCESS'}:
            cid=f'mission_consequence:{qid.split(":",1)[1]}:{entry["attempt_no"]}'
            candidate={'run_uuid':self.session.identity.run_uuid,'kind':'mission_consequence_candidate','quest_instance_id':qid,'mission_family':family,'attempt_no':entry['attempt_no'],'outcome':result.outcome,'state':'PROPOSED','effects':[],'note':'No world effect is invented by mission resolution; authoritative evidence is required.'}
            event=f'MISSION_ATTEMPT:{qid}:{entry["attempt_no"]}'
            self._commit((Delta(Domain.RUNTIME_STATE,qid,q,Authority.RULE_KERNEL,'MISSION_ATTEMPT',source_event_id=event,provenance='MISSION_RESOLUTION'),Delta(Domain.RUNTIME_STATE,cid,candidate,Authority.RULE_KERNEL,'MISSION_CONSEQUENCE_PROPOSAL',source_event_id=event,provenance='MISSION_RESOLUTION')),event,'MISSION_ATTEMPT')
        else:
            event=f'MISSION_ATTEMPT:{qid}:{entry["attempt_no"]}'
            self._commit((Delta(Domain.RUNTIME_STATE,qid,q,Authority.RULE_KERNEL,'MISSION_ATTEMPT',source_event_id=event,provenance='MISSION_RESOLUTION'),),event,'MISSION_ATTEMPT')
        return entry

    def reveal_for_search(self, location_id: str, actor_id=PLAYER_ACTOR_INSTANCE_ID) -> list[dict]:
        found=[]
        for qid,q in self.active(actor_id):
            if q.get('state')!='ACTIVE' or q.get('target_location_id')!=location_id: continue
            b=q.get('binding') or {}
            if not b.get('search_reveals_asset'): continue
            iid=q.get('asset_item_id'); item=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
            if not isinstance(item,dict) or not item.get('hidden'): continue
            item=copy.deepcopy(item); item['hidden']=False
            q=copy.deepcopy(q); q.setdefault('progress',{})['searched_target']=True; q['progress']['asset_revealed']=True
            event=f'QUEST_SEARCH_REVEAL:{qid}'
            self._commit((
                Delta(Domain.RUNTIME_STATE,iid,item,Authority.RULE_KERNEL,'QUEST_SEARCH_REVEAL',source_event_id=event,provenance='QUEST_PLAYABLE_BINDING'),
                Delta(Domain.RUNTIME_STATE,qid,q,Authority.RULE_KERNEL,'QUEST_PROGRESS',source_event_id=event,provenance='QUEST_PLAYABLE_BINDING'),
            ),event,'QUEST_SEARCH_REVEAL')
            found.append({'instance_id':iid,'item_definition_id':item['item_definition_id'],'display_name':self.catalog.item_definition(item['item_definition_id'])['display_name'],'quest_instance_id':qid})
        return found

    def _mark(self, qid: str, **progress) -> None:
        q=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
        if not isinstance(q,dict) or q.get('state')!='ACTIVE': return
        q=copy.deepcopy(q); q.setdefault('progress',{}).update(progress)
        event=f'QUEST_PROGRESS:{qid}:{self.session.store.revision}'
        self._commit((Delta(Domain.RUNTIME_STATE,qid,q,Authority.RULE_KERNEL,'QUEST_PROGRESS',source_event_id=event,provenance='QUEST_PLAYABLE_EVENT'),),event,'QUEST_PROGRESS')

    def observe_take(self,item_id: str,actor_id=PLAYER_ACTOR_INSTANCE_ID):
        for qid,q in self.active(actor_id):
            if q.get('state')=='ACTIVE' and q.get('asset_item_id')==item_id: self._mark(qid,asset_acquired=True)

    def observe_read(self,item_id: str,actor_id=PLAYER_ACTOR_INSTANCE_ID):
        for qid,q in self.active(actor_id):
            if q.get('state')=='ACTIVE' and q.get('asset_item_id')==item_id: self._mark(qid,data_read=True)

    def observe_repair(self,item_id: str,actor_id=PLAYER_ACTOR_INSTANCE_ID):
        for qid,q in self.active(actor_id):
            if q.get('state')=='ACTIVE' and q.get('asset_item_id')==item_id: self._mark(qid,repaired=True)

    def observe_move(self,location_id: str,actor_id=PLAYER_ACTOR_INSTANCE_ID):
        for qid,q in list(self.active(actor_id)):
            if q.get('state')!='ACTIVE' or q.get('target_location_id')!=location_id: continue
            self._mark(qid,reached_target=True)
            q=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
            b=q.get('binding') or {}
            if b.get('completion')=='deliver_at_target':
                iid=q.get('asset_item_id'); item=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
                if isinstance(item,dict) and item.get('location_ref')==f'inventory:{actor_id}':
                    self._complete(qid,b.get('success_outcome','delivered'),deliver_item=True)

    def turn_in_for_npc(self,npc_id: str,actor_id=PLAYER_ACTOR_INSTANCE_ID) -> list[tuple[str,str]]:
        completed=[]
        for qid,q in list(self.active(actor_id)):
            if q.get('state')!='ACTIVE' or q.get('issuer_actor_id')!=npc_id: continue
            b=q.get('binding') or {}; p=q.get('progress') or {}; iid=q.get('asset_item_id')
            item=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
            mode=b.get('completion')
            ready=False; return_item=False
            if mode=='return_to_issuer':
                ready=isinstance(item,dict) and item.get('location_ref')==f'inventory:{actor_id}'
                if b.get('requires_data_read'): ready=ready and bool(p.get('data_read'))
                return_item=ready
            elif mode=='report_to_issuer':
                ready=bool(p.get('repaired'))
            if ready:
                outcome=b.get('success_outcome')
                self._complete(qid,outcome,return_item=return_item)
                completed.append((qid,outcome))
        return completed

    def _complete(self,qid: str,outcome: str,*,return_item=False,deliver_item=False):
        q=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
        if not isinstance(q,dict) or q.get('state')!='ACTIVE': return
        if outcome not in q.get('outcomes',[]): raise QuestRuntimeError('QUEST_OUTCOME_NOT_ALLOWED')
        q=copy.deepcopy(q); q['state']='COMPLETED'; q['completed_at']=WorldClock(self.session).seconds; q['final_outcome']=outcome
        deltas=[]; event=f'QUEST_COMPLETE:{qid}:{outcome}'
        iid=q.get('asset_item_id')
        if return_item or deliver_item:
            item=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
            if isinstance(item,dict):
                item=copy.deepcopy(item)
                if return_item:
                    item['location_ref']=f'inventory:{q["issuer_actor_id"]}'; item['owner_actor_instance_id']=q['issuer_actor_id']
                else:
                    item['location_ref']=f'delivered:{qid}'; item.pop('owner_actor_instance_id',None)
                item['merchant_stock']=False
                deltas.append(Delta(Domain.RUNTIME_STATE,iid,item,Authority.RULE_KERNEL,'QUEST_ASSET_DELIVERY',source_event_id=event,provenance='QUEST_COMPLETION'))
        deltas.append(Delta(Domain.RUNTIME_STATE,qid,q,Authority.RULE_KERNEL,'QUEST_COMPLETE',source_event_id=event,provenance='QUEST_PLAYABLE_BINDING'))
        chain=self.consequences.get(q['template_id'])
        if chain and outcome in chain.get('branches',{}):
            cid='quest_consequence:'+qid.split(':',1)[1]
            candidate={'run_uuid':self.session.identity.run_uuid,'kind':'quest_consequence_candidate','quest_instance_id':qid,'outcome':outcome,'effects':copy.deepcopy(chain['branches'][outcome]),'state':'PROPOSED','note':'Effects remain authority-owned and are not narration commits.'}
            deltas.append(Delta(Domain.RUNTIME_STATE,cid,candidate,Authority.RULE_KERNEL,'QUEST_CONSEQUENCE_PROPOSAL',source_event_id=event,provenance='STAGE12_CONSEQUENCE_CHAIN'))
        self._commit(tuple(deltas),event,'QUEST_COMPLETE')
