from __future__ import annotations
import copy,json
from runtime.stage3a.kernel import Authority,CommitRecord,Delta,Domain,Mode,Proposal
from runtime.stage9.world_time import WorldClock
from runtime.stage7.needs import STAGE7_RUNTIME_KEY

EMBODIED_STATE_KEY="__embodied_needs_runtime__"
class EmbodiedNeedsRuntime:
    def __init__(self,catalog,session):
        self.catalog=catalog; self.session=session
        self.t=json.loads((catalog.root/"content/full_version/embodied_needs_tables.json").read_text())
        if self.t.get("schema")!="PH4NT0M5_EMBODIED_NEEDS_V1": raise RuntimeError("EMBODIED_NEEDS_SCHEMA_INVALID")
    def _root(self):
        x=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,EMBODIED_STATE_KEY)
        if x is None:return {"run_uuid":self.session.identity.run_uuid,"actors":{}}
        if not isinstance(x,dict) or x.get("run_uuid")!=self.session.identity.run_uuid:raise RuntimeError("EMBODIED_RUN_MISMATCH")
        return copy.deepcopy(x)
    def _stage7(self):
        x=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,STAGE7_RUNTIME_KEY)
        if not isinstance(x,dict) or x.get("run_uuid")!=self.session.identity.run_uuid:raise RuntimeError("STAGE7_NEEDS_INVALID")
        return copy.deepcopy(x)
    @staticmethod
    def _mul(a,b): return (int(a)*int(b))//1_000_000
    def band(self,key,value):
        out=self.t["needs"][key]["bands"][0][1]
        for threshold,label in self.t["needs"][key]["bands"]:
            if int(value)>=int(threshold):out=label
        return out
    def actor_packet(self,actor_id):
        s7=self._stage7(); pressures=(s7.get("actors",{}).get(actor_id,{}) or {}).get("pressures_ppm",{})
        e=self._root().get("actors",{}).get(actor_id,{})
        out={"actor_id":actor_id,"needs":{}}
        for k in ("hydration","nutrition","rest","climate_fit"):
            v=int(pressures.get(k,0)); b=self.band(k,v)
            out["needs"][k]={"pressure_ppm":v,"band":b,"symptoms":list(self.t["symptoms"].get(k,{}).get(b,[]))}
        out["last_context"]=e.get("last_context",{})
        return out
    def advance(self,seconds,*,activity="light",climate="temperate",situation="normal",actor_ids=None,climate_exposure_ppm=1_000_000):
        if seconds<=0:return 0
        s7=self._stage7(); eroot=self._root(); actors=s7.setdefault("actors",{})
        ids=list(actor_ids or actors.keys()); global_mult=int(self.t["situation"].get(situation,self.t["situation"]["normal"])["global_multiplier_ppm"])
        for aid in ids:
            rec=actors.get(aid)
            if not isinstance(rec,dict):continue
            p=rec.setdefault("pressures_ppm",{})
            for key in ("hydration","nutrition","rest"):
                cfg=self.t["needs"][key]; rate=int(cfg["base_ppm_per_hour"])
                rate=self._mul(rate,int(cfg["activity"].get(activity,1_000_000)))
                if key=="hydration":rate=self._mul(rate,int(cfg.get("climate",{}).get(climate,1_000_000)))
                rate=self._mul(rate,global_mult)
                p[key]=max(0,min(1_000_000,int(p.get(key,0))+(rate*int(seconds))//3600))
            # climate is situational, not a simple countdown
            if isinstance(climate_exposure_ppm,bool) or not isinstance(climate_exposure_ppm,int) or not 0<=climate_exposure_ppm<=1_000_000:
                raise RuntimeError("CLIMATE_EXPOSURE_INVALID")
            climate_push={"cold":19000,"temperate":-12000,"hot":30000,"extreme_heat":70000}.get(climate,0)
            if climate_push>0:
                climate_push=self._mul(climate_push,climate_exposure_ppm)
            # Recovery toward comfort is allowed indoors too; hazardous gain is shelter-bounded.
            p["climate_fit"]=max(0,min(1_000_000,int(p.get("climate_fit",0))+(climate_push*int(seconds))//3600))
            rec["last_cause_ref"]="EMBODIED_NEEDS_ADVANCE"
            eroot.setdefault("actors",{})[aid]={"last_context":{"activity":activity,"climate":climate,"situation":situation,"seconds":int(seconds)}}
        event=f"EMBODIED_ADVANCE:{WorldClock(self.session).seconds}:{self.session.store.revision}"
        r=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(
          Delta(Domain.RUNTIME_STATE,STAGE7_RUNTIME_KEY,s7,Authority.RULE_KERNEL,"EMBODIED_NEEDS_ADVANCE",source_event_id=event,provenance="EMBODIED_NEEDS"),
          Delta(Domain.RUNTIME_STATE,EMBODIED_STATE_KEY,eroot,Authority.RULE_KERNEL,"EMBODIED_NEEDS_CONTEXT",source_event_id=event,provenance="EMBODIED_NEEDS"),
        ),event_id=event,cause="EMBODIED_NEEDS_ADVANCE",expected_state_revision=self.session.store.revision))
        if not isinstance(r,CommitRecord):raise RuntimeError("EMBODIED_NEEDS_COMMIT_REJECTED")
        return seconds
    def advance_contexts(self,seconds,contexts):
        """Advance heterogeneous actor groups in one authoritative commit."""
        if seconds<=0:return 0
        s7=self._stage7(); eroot=self._root(); actors=s7.setdefault("actors",{})
        touched=set()
        for ctx in contexts:
            ids=list(ctx.get("actor_ids") or ())
            activity=str(ctx.get("activity","light")); climate=str(ctx.get("climate","temperate")); situation=str(ctx.get("situation","normal"))
            exposure=int(ctx.get("climate_exposure_ppm",1_000_000))
            if not 0<=exposure<=1_000_000: raise RuntimeError("CLIMATE_EXPOSURE_INVALID")
            global_mult=int(self.t["situation"].get(situation,self.t["situation"]["normal"])["global_multiplier_ppm"])
            for aid in ids:
                if aid in touched: raise RuntimeError("EMBODIED_ACTOR_CONTEXT_DUPLICATE")
                rec=actors.get(aid)
                if not isinstance(rec,dict): continue
                touched.add(aid); p=rec.setdefault("pressures_ppm",{})
                for key in ("hydration","nutrition","rest"):
                    cfg=self.t["needs"][key]; rate=int(cfg["base_ppm_per_hour"])
                    rate=self._mul(rate,int(cfg["activity"].get(activity,1_000_000)))
                    if key=="hydration": rate=self._mul(rate,int(cfg.get("climate",{}).get(climate,1_000_000)))
                    rate=self._mul(rate,global_mult)
                    p[key]=max(0,min(1_000_000,int(p.get(key,0))+(rate*int(seconds))//3600))
                climate_push={"cold":19000,"temperate":-12000,"hot":30000,"extreme_heat":70000}.get(climate,0)
                if climate_push>0: climate_push=self._mul(climate_push,exposure)
                p["climate_fit"]=max(0,min(1_000_000,int(p.get("climate_fit",0))+(climate_push*int(seconds))//3600))
                rec["last_cause_ref"]="EMBODIED_NEEDS_ADVANCE"
                eroot.setdefault("actors",{})[aid]={"last_context":{"activity":activity,"climate":climate,"situation":situation,"seconds":int(seconds),"climate_exposure_ppm":exposure}}
        if not touched:return 0
        event=f"EMBODIED_BATCH_ADVANCE:{WorldClock(self.session).seconds}:{self.session.store.revision}"
        r=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(
          Delta(Domain.RUNTIME_STATE,STAGE7_RUNTIME_KEY,s7,Authority.RULE_KERNEL,"EMBODIED_NEEDS_BATCH_ADVANCE",source_event_id=event,provenance="EMBODIED_NEEDS"),
          Delta(Domain.RUNTIME_STATE,EMBODIED_STATE_KEY,eroot,Authority.RULE_KERNEL,"EMBODIED_NEEDS_BATCH_CONTEXT",source_event_id=event,provenance="EMBODIED_NEEDS"),
        ),event_id=event,cause="EMBODIED_NEEDS_BATCH_ADVANCE",expected_state_revision=self.session.store.revision))
        if not isinstance(r,CommitRecord):raise RuntimeError("EMBODIED_NEEDS_COMMIT_REJECTED")
        return seconds

    def recover(self,actor_id,event_type):
        effects=self.t["recovery"].get(event_type)
        if not effects:raise RuntimeError("RECOVERY_EVENT_UNKNOWN")
        s7=self._stage7(); rec=s7["actors"][actor_id]; p=rec["pressures_ppm"]
        for k,d in effects.items():p[k]=max(0,min(1_000_000,int(p.get(k,0))+int(d)))
        rec["last_cause_ref"]="EMBODIED_RECOVERY:"+event_type
        event=f"EMBODIED_RECOVERY:{actor_id}:{event_type}:{self.session.store.revision}"
        r=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(
          Delta(Domain.RUNTIME_STATE,STAGE7_RUNTIME_KEY,s7,Authority.RULE_KERNEL,"EMBODIED_RECOVERY",source_event_id=event,provenance="EMBODIED_NEEDS"),
        ),event_id=event,cause="EMBODIED_RECOVERY",expected_state_revision=self.session.store.revision))
        if not isinstance(r,CommitRecord):raise RuntimeError("EMBODIED_RECOVERY_REJECTED")
    def lived_description(self,actor_id):
        p=self.actor_packet(actor_id); phrases=[]
        for k,v in p["needs"].items():
            sy=v["symptoms"]
            if sy:phrases.append(sy[0])
        if not phrases:return "Du fühlst dich körperlich unauffällig und ausreichend versorgt."
        return "Körpergefühl: "+", ".join(phrases)+"."

    def sync_actor_status_flags(self, actor_id, flags):
        """Commit derived embodied-status flags outside the presentation/game shell."""
        actor=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,actor_id)
        if not isinstance(actor,dict): raise RuntimeError("EMBODIED_ACTOR_REQUIRED")
        actor=copy.deepcopy(actor)
        actor["status_flags"]=sorted(set(str(x) for x in flags))
        actor.pop("survival_critical_seconds",None)
        event=f"SURVIVAL_STATUS:{WorldClock(self.session).seconds}:{self.session.store.revision}"
        r=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(
            Delta(Domain.RUNTIME_STATE,actor_id,actor,Authority.RULE_KERNEL,"SURVIVAL_STATUS",source_event_id=event,provenance="EMBODIED_NEEDS"),
        ),event_id=event,cause="SURVIVAL_STATUS",expected_state_revision=self.session.store.revision))
        if not isinstance(r,CommitRecord): raise RuntimeError("SURVIVAL_STATUS_COMMIT_REJECTED")
        return r
