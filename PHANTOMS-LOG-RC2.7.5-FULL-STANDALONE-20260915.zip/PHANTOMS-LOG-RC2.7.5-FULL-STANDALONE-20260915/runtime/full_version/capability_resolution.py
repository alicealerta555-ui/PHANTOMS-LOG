from __future__ import annotations

"""Deterministic capability-zone assessment.

Dice never create possibility.  This module only establishes whether a
requested method is reliable, uncertain, extreme, physically impossible or not
available to the character.  The actual EDGE/EXTREME roll stays in the normal
resolver.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Mapping, Tuple

from .capability_catalog import SKILLS, TALENTS


class CapabilityZone(str, Enum):
    SAFE = "SAFE"
    EDGE = "EDGE"
    EXTREME = "EXTREME"
    HARD_LIMIT = "HARD_LIMIT"
    INACCESSIBLE = "INACCESSIBLE"


@dataclass(frozen=True, slots=True)
class StageDemand:
    stage: str
    stat_minimums: Mapping[str, int]
    difficulty: int = 5


@dataclass(frozen=True, slots=True)
class StageResult:
    stage: str
    zone: CapabilityZone
    reason: str
    passed_information: bool


@dataclass(frozen=True, slots=True)
class CapabilityResult:
    zone: CapabilityZone
    stages: Tuple[StageResult, ...]
    failure_stage: str | None
    explanation_key: str


def _skill_score(character: Mapping, skill_id: str) -> int:
    return int((character.get("skills") or {}).get(skill_id, 0))


def _effective_stat(character: Mapping, stat_id: str) -> int:
    base = int((character.get("stats") or {}).get(stat_id, 0))
    penalty = int((character.get("stat_penalties") or {}).get(stat_id, 0))
    return max(0, base - penalty)


def assess_skill(character: Mapping, skill_id: str, demands: Tuple[StageDemand, ...], *,
                 expertise_bonus: int = 0, situational_bonus: int = 0,
                 opposition_penalty: int = 0) -> CapabilityResult:
    if skill_id not in SKILLS:
        return CapabilityResult(CapabilityZone.INACCESSIBLE,(),None,"UNKNOWN_SKILL")
    score=_skill_score(character, skill_id)
    if score <= 0:
        return CapabilityResult(CapabilityZone.INACCESSIBLE,(),None,"SKILL_NOT_LEARNED")
    out=[]
    overall=CapabilityZone.SAFE
    for demand in demands:
        # Natural/current limits are checked before skill, talent, expertise or luck.
        for stat_id, minimum in demand.stat_minimums.items():
            if _effective_stat(character, stat_id) < int(minimum):
                out.append(StageResult(demand.stage,CapabilityZone.HARD_LIMIT,
                                       f"STAT_BELOW_HARD_MIN:{stat_id}",False))
                return CapabilityResult(CapabilityZone.HARD_LIMIT,tuple(out),demand.stage,
                                        "KNOWN_HARD_LIMIT")
        stat_values=[_effective_stat(character,s) for s in demand.stat_minimums]
        stat_floor=min(stat_values) if stat_values else 5
        # Expertise and tools improve reliability, never the checked hard minimum.
        reliability=(stat_floor + score//2 + int(expertise_bonus) + int(situational_bonus)
                     - int(opposition_penalty) - int(demand.difficulty))
        if reliability >= 4:
            zone=CapabilityZone.SAFE
        elif reliability >= 1:
            zone=CapabilityZone.EDGE
        else:
            zone=CapabilityZone.EXTREME
        out.append(StageResult(demand.stage,zone,"WITHIN_NATURAL_LIMIT",True))
        if zone == CapabilityZone.EXTREME:
            overall=CapabilityZone.EXTREME
        elif zone == CapabilityZone.EDGE and overall == CapabilityZone.SAFE:
            overall=CapabilityZone.EDGE
    return CapabilityResult(overall,tuple(out),None,"CAPABILITY_ASSESSED")


def assess_talent(character: Mapping, talent_id: str, demands: Tuple[StageDemand, ...], *,
                  expertise_bonus: int = 0, situational_bonus: int = 0,
                  opposition_penalty: int = 0) -> CapabilityResult:
    talent=TALENTS.get(talent_id)
    if talent is None:
        return CapabilityResult(CapabilityZone.INACCESSIBLE,(),None,"UNKNOWN_TALENT")
    if talent_id not in set(character.get("talents") or ()):
        return CapabilityResult(CapabilityZone.INACCESSIBLE,(),None,"TALENT_NOT_LEARNED")
    for skill_id in talent.required_skills:
        if _skill_score(character, skill_id) <= 0:
            return CapabilityResult(CapabilityZone.INACCESSIBLE,(),None,f"REQUIRED_SKILL_MISSING:{skill_id}")
    # Assess against the first required skill as the application carrier; all prerequisite
    # skills are still mandatory above.  Method-specific resolvers may provide richer mixes.
    return assess_skill(character, talent.required_skills[0], demands,
                        expertise_bonus=expertise_bonus, situational_bonus=situational_bonus,
                        opposition_penalty=opposition_penalty)
