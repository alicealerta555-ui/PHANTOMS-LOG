"""Canonical character creation over the CommitKernel.

Character authority is PLAYABLE-CAPABILITY-2.0:
    Stats -> Skills -> Talents -> Expertises
Classes specialize that tree; they do not provide a second character model.
"""
from copy import deepcopy
from dataclasses import dataclass

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.playable_character.character_creation import validate_character_input
from runtime.full_version.capability_catalog import (
    SCHEMA_ID, STATS, SKILLS, TALENTS, CLASS_TALENTS, validate_talent_prerequisites,
)
from .bootstrap import PLAYER_ACTOR_INSTANCE_ID, FULL_VERSION_INIT_KEY
from .lifetime_start import LIFETIME_STATE_KEY, LIFETIME_SCHEMA, canonical_origin_label
from .class_tutorial import CLASS_TUTORIAL_STATE_KEY, build_class_tutorial_state

PROFILE_FIELD='character_profile'
CHOICE_FIELDS=frozenset({'name','sex','age','origin','role','stats','skills','talents'})


class CharacterCreationError(ValueError): pass


@dataclass(frozen=True)
class CharacterCreationAuthority:
    catalog: object
    session: object
    registry: object

    def authorize(self, choices: dict) -> dict:
        self.registry.get(PLAYER_ACTOR_INSTANCE_ID)
        if self.registry.run_identity != self.session.identity: raise CharacterCreationError('CHARACTER_RUN_MISMATCH')
        kernel=self.session.kernel
        if kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,FULL_VERSION_INIT_KEY) is not True:
            raise CharacterCreationError('FULL_VERSION_RUN_REQUIRED')
        actor=kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,PLAYER_ACTOR_INSTANCE_ID)
        if not isinstance(actor,dict) or actor.get('run_uuid')!=self.session.identity.run_uuid:
            raise CharacterCreationError('CHARACTER_ACTOR_INVALID')
        if actor.get(PROFILE_FIELD) is not None: raise CharacterCreationError('CHARACTER_ALREADY_CREATED')
        if not isinstance(choices,dict) or set(choices)-CHOICE_FIELDS:
            raise CharacterCreationError('CHARACTER_CHOICES_ONLY_NO_STATE_PATCH')
        data=deepcopy(choices)
        lifetime=kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,LIFETIME_STATE_KEY)
        if not isinstance(lifetime,dict) or lifetime.get('schema') != LIFETIME_SCHEMA:
            raise CharacterCreationError('LIFETIME_STATE_REQUIRED_FOR_CHARACTER_CREATION')
        expected_origin=canonical_origin_label(lifetime)
        if str(data.get('origin') or '').strip() != expected_origin:
            raise CharacterCreationError('CHARACTER_ORIGIN_MUST_MATCH_LIFETIME_START')
        data['origin']=expected_origin
        for key in ('name','sex','origin','role'):
            if not isinstance(data.get(key),str) or not data[key].strip() or len(data[key])>160:
                raise CharacterCreationError('CHARACTER_FIELD_INVALID:'+key)
            data[key]=data[key].strip()
        if type(data.get('age')) is not int or data['age']<18: raise CharacterCreationError('CHARACTER_AGE_MUST_BE_AT_LEAST_18')
        if not isinstance(data.get('stats'),dict) or set(data['stats'])!=set(STATS):
            raise CharacterCreationError('CHARACTER_STATS_REQUIRE_CANONICAL_SET')
        if not isinstance(data.get('skills'),dict) or set(data['skills'])!=set(SKILLS):
            raise CharacterCreationError('CHARACTER_SKILLS_REQUIRE_CANONICAL_SET')
        for key in ('stats','skills'):
            if any(type(value) is not int for value in data[key].values()):
                raise CharacterCreationError('CHARACTER_VALUES_MUST_BE_INTEGERS')
        talents=data.get('talents')
        if not isinstance(talents,list) or len(talents)>20 or any(not isinstance(x,str) or not x.strip() for x in talents):
            raise CharacterCreationError('CHARACTER_TALENTS_INVALID')
        data['talents']=list(dict.fromkeys(x.strip().upper() for x in talents))
        if len(data['talents']) != 2:
            raise CharacterCreationError('CHARACTER_START_TALENTS_REQUIRE_EXACTLY_TWO')
        unknown=[x for x in data['talents'] if x not in TALENTS]
        if unknown: raise CharacterCreationError('CHARACTER_TALENT_UNKNOWN:'+','.join(unknown))
        start_class=str(actor['start_class']).upper()
        bad_class=[x for x in data['talents'] if x not in set(CLASS_TALENTS[start_class])]
        if bad_class: raise CharacterCreationError('CHARACTER_TALENT_CLASS_MISMATCH:'+','.join(bad_class))
        prereq=validate_talent_prerequisites(start_class,data['skills'],data['talents'])
        if prereq: raise CharacterCreationError('|'.join(prereq))
        check=validate_character_input({**data,'location_id':actor['location_ref']})
        if not check['ok']: raise CharacterCreationError(','.join(check['errors']))
        data.update(schema=SCHEMA_ID,player_uuid=self.session.identity.player_uuid,run_uuid=self.session.identity.run_uuid,
                    character_id=PLAYER_ACTOR_INSTANCE_ID,character_creation_complete=True,class_abilities=[],expertises={})
        return data

    def commit(self, choices: dict) -> CommitRecord:
        revision=self.session.store.revision; profile=self.authorize(choices); kernel=self.session.kernel
        actor=kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,PLAYER_ACTOR_INSTANCE_ID)
        event='PLAYER_CHARACTER_CREATE:'+self.session.identity.run_uuid
        profile['creation_commit_id']=event; actor[PROFILE_FIELD]=profile
        # Lifetime origin is authoritative for location, belongings and initial motivation.
        # The selected class only specializes the capability tree.
        tutorial_state=build_class_tutorial_state(str(actor['start_class']),profile['talents'])
        deltas=[
            Delta(Domain.RUNTIME_STATE,PLAYER_ACTOR_INSTANCE_ID,actor,Authority.SYSTEM_INIT,'PLAYER_CHARACTER_CREATION',source_event_id=event,provenance='EXPLICIT_PLAYER_CREATION'),
            Delta(Domain.RUNTIME_STATE,CLASS_TUTORIAL_STATE_KEY,tutorial_state,Authority.SYSTEM_INIT,'CLASS_TUTORIAL_INITIALIZE',source_event_id=event,provenance='EXPLICIT_PLAYER_CREATION'),
        ]
        result=kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=tuple(deltas),event_id=event,cause='EXPLICIT_PLAYER_CREATION',expected_state_revision=revision))
        if not isinstance(result,CommitRecord): raise CharacterCreationError('CHARACTER_CREATION_COMMIT_REJECTED:'+','.join(result.reasons))
        return result


def character_view(session) -> dict | None:
    actor=session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,PLAYER_ACTOR_INSTANCE_ID)
    if not isinstance(actor,dict) or not isinstance(actor.get(PROFILE_FIELD),dict): return None
    profile=deepcopy(actor[PROFILE_FIELD])
    if profile.get('schema') != SCHEMA_ID: raise CharacterCreationError('LEGACY_CHARACTER_SCHEMA_UNSUPPORTED')
    profile.update(location_id=actor['location_ref'],hp=actor['hp'],max_hp=actor['max_hp'])
    profile['status']={'alive':actor['hp']>0,'character_creation_complete':True}
    profile['inventory']=[]
    for key in session.store.runtime_state:
        if not key.startswith('item:'): continue
        record=session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
        if isinstance(record,dict) and record.get('location_ref')=='inventory:'+PLAYER_ACTOR_INSTANCE_ID:
            profile['inventory'].append({**record,'instance_id':key})
    return profile
