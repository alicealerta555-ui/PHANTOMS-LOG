from __future__ import annotations

"""Named scenario matrix for every canonical talent.

The matrix is finite by *mechanical situation class*, not by player wording.  Free
language may describe infinitely many scenes, but each mechanically distinct case
must normalize into one of these scenario classes before resolution.
"""

from dataclasses import dataclass
from typing import Tuple

from .capability_catalog import TALENTS
from .capability_resolution import CapabilityZone


@dataclass(frozen=True, slots=True)
class TalentScenario:
    scenario_id: str
    talent_id: str
    situation: str
    case: str
    expected_zone: CapabilityZone
    meaning: str


CASE_DEFINITIONS = (
    ("SAFE_ROUTINE", CapabilityZone.SAFE, "Innerhalb der zuverlässig beherrschten Anwendung."),
    ("EDGE_UNCERTAIN", CapabilityZone.EDGE, "Grundsätzlich möglich, Ausgang aber tatsächlich unsicher."),
    ("EXTREME_RISK", CapabilityZone.EXTREME, "Möglich, aber deutlich außerhalb der sicheren Anwendung; Warnung erforderlich."),
    ("HARD_LIMIT", CapabilityZone.HARD_LIMIT, "Zwingende natürliche oder aktuell verfügbare Grenze unterschritten."),
    ("INACCESSIBLE_TALENT", CapabilityZone.INACCESSIBLE, "Talent selbst ist nicht gelernt/verfügbar."),
    ("INACCESSIBLE_SKILL", CapabilityZone.INACCESSIBLE, "Mindestens ein erforderlicher Skill fehlt."),
    ("STATE_IMPAIRMENT", CapabilityZone.HARD_LIMIT, "Verletzung/Erschöpfung reduziert die aktuell nutzbare Fähigkeit unter die Grenze."),
    ("AIDED_METHOD", CapabilityZone.SAFE, "Werkzeug/Hilfe verbessert die Methode und verschiebt Zuverlässigkeit, nicht den Basisstat."),
    ("EXPERTISE_APPLIED", CapabilityZone.SAFE, "Erfahrung verbessert Zuverlässigkeit innerhalb der natürlichen Grenze."),
    ("ACTIVE_OPPOSITION", CapabilityZone.EDGE, "Aktive Gegenwehr verschiebt eine sonst sichere Anwendung in echte Unsicherheit."),
    ("PARTIAL_SUCCESS_LATE_LIMIT", CapabilityZone.HARD_LIMIT, "Frühere Teilstufen gelingen; eine spätere zwingende Stufe erreicht die Grenze nicht."),
)


def talent_scenarios() -> Tuple[TalentScenario, ...]:
    rows=[]
    for talent in TALENTS.values():
        for situation in talent.situations:
            slug=situation.lower().replace(" ","_").replace("/","_")
            for case,zone,meaning in CASE_DEFINITIONS:
                rows.append(TalentScenario(
                    f"{talent.talent_id}:{slug}:{case}", talent.talent_id, situation,
                    case, zone, meaning,
                ))
    return tuple(rows)
