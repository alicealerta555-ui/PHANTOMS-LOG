from __future__ import annotations

"""Canonical PHANTOMS-LOG character capability catalog.

Authority order:
    stats -> skills -> talents -> expertises

Classes specialize this tree; they do not replace it.  IDs are intentionally
namespaced so narration synonyms never become rules by accident.
"""

from dataclasses import dataclass
from typing import Mapping, Tuple

SCHEMA_ID = "PLAYABLE-CAPABILITY-2.0"

STAGE_INPUT = "INPUT"
STAGE_INTERPRET = "INTERPRET"
STAGE_SETUP = "SETUP"
STAGE_EXECUTE = "EXECUTE"
STAGE_CONTROL = "CONTROL"
STAGES = (STAGE_INPUT, STAGE_INTERPRET, STAGE_SETUP, STAGE_EXECUTE, STAGE_CONTROL)


@dataclass(frozen=True, slots=True)
class StatDef:
    stat_id: str
    name: str
    meaning: str


@dataclass(frozen=True, slots=True)
class SkillStage:
    stage: str
    stats: Tuple[str, ...]
    purpose: str


@dataclass(frozen=True, slots=True)
class SkillDef:
    skill_id: str
    name: str
    stages: Tuple[SkillStage, ...]
    situations: Tuple[str, ...]
    expertise_examples: Tuple[str, ...]

    @property
    def stats(self) -> Tuple[str, ...]:
        out=[]
        for stage in self.stages:
            for stat in stage.stats:
                if stat not in out:
                    out.append(stat)
        return tuple(out)


@dataclass(frozen=True, slots=True)
class TalentDef:
    talent_id: str
    name: str
    owner_class: str
    required_skills: Tuple[str, ...]
    required_stats: Tuple[str, ...]
    modifies_stages: Tuple[str, ...]
    situations: Tuple[str, ...]
    description: str


STATS: Mapping[str, StatDef] = {
    "STAT_STR": StatDef("STAT_STR", "Kraft", "Natürliche mechanische Kraftgrenze."),
    "STAT_END": StatDef("STAT_END", "Ausdauer", "Belastung, Ermüdung und körperliche Dauerleistung."),
    "STAT_MOB": StatDef("STAT_MOB", "Beweglichkeit", "Grobmotorik, Bewegungsumfang und Körperpositionierung."),
    "STAT_DEX": StatDef("STAT_DEX", "Präzision", "Feinmotorik und exakte kontrollierte Bewegung."),
    "STAT_REA": StatDef("STAT_REA", "Reaktion", "Zeitgerechte Auswahl und Einleitung einer Handlung."),
    "STAT_PER": StatDef("STAT_PER", "Wahrnehmung", "Qualität der sensorischen Informationsaufnahme."),
    "STAT_COG": StatDef("STAT_COG", "Kognition", "Verarbeitung, Gedächtnis, Schlussfolgern und Planung."),
    "STAT_WIL": StatDef("STAT_WIL", "Selbstkontrolle", "Fokus, Stresskontrolle und willentliche Stabilität."),
    "STAT_SOC": StatDef("STAT_SOC", "Sozialwahrnehmung", "Erfassen und Verarbeiten sozialer Signale."),
    "STAT_RES": StatDef("STAT_RES", "Resonanz", "Natürliche Kopplungsgrenze an die übernatürliche Resonanzebene."),
}


def _s(stage: str, stats: Tuple[str, ...], purpose: str) -> SkillStage:
    return SkillStage(stage, stats, purpose)


SKILLS: Mapping[str, SkillDef] = {
    "SKILL_ATHLETICS": SkillDef("SKILL_ATHLETICS", "Athletik", (
        _s(STAGE_SETUP,("STAT_MOB",),"Körperposition und Bewegungsansatz herstellen."),
        _s(STAGE_EXECUTE,("STAT_STR","STAT_MOB"),"Laufen, springen, klettern oder schwimmen ausführen."),
        _s(STAGE_CONTROL,("STAT_END",),"Bewegungsleistung unter Belastung stabil halten."),),
        ("klettern","springen","rennen","schwimmen","hindernisse überwinden"),
        ("Trümmerklettern","Langstreckenlauf","enge Schächte","nasse Oberflächen")),
    "SKILL_FORCE_APPLICATION": SkillDef("SKILL_FORCE_APPLICATION", "Kraftanwendung", (
        _s(STAGE_INPUT,("STAT_PER",),"Last, Widerstand und Ansatzpunkt erfassen."),
        _s(STAGE_SETUP,("STAT_MOB","STAT_COG"),"Stand, Griff und Hebel sinnvoll setzen."),
        _s(STAGE_EXECUTE,("STAT_STR",),"Erforderliche mechanische Kraft erzeugen."),
        _s(STAGE_CONTROL,("STAT_END",),"Kraft kontrolliert halten oder nachführen."),),
        ("heben","drücken","ziehen","halten","aufbrechen","schwere lasten bewegen"),
        ("schwere Lasten","Hebelarbeit","verklemmte Türen","Bergung")),
    "SKILL_LOAD_CONTROL": SkillDef("SKILL_LOAD_CONTROL", "Belastungskontrolle", (
        _s(STAGE_INPUT,("STAT_END",),"Eigene Belastung und Ermüdung wahrnehmen."),
        _s(STAGE_SETUP,("STAT_WIL",),"Atem und Tempo bewusst ordnen."),
        _s(STAGE_CONTROL,("STAT_END","STAT_WIL"),"Leistung trotz anhaltender Belastung stabilisieren."),),
        ("lange belastung","atemkontrolle","marsch","schmerz unter kontrolle","erschöpfung managen"),
        ("Höhenmarsch","Hitze","Atemrhythmus","Schmerzmanagement")),
    "SKILL_BALANCE": SkillDef("SKILL_BALANCE", "Balance", (
        _s(STAGE_INPUT,("STAT_PER",),"Untergrund und Körperlage erfassen."),
        _s(STAGE_EXECUTE,("STAT_MOB",),"Schwerpunkt korrekt verlagern."),
        _s(STAGE_CONTROL,("STAT_DEX","STAT_REA"),"Kleine Korrekturbewegungen rechtzeitig ausführen."),),
        ("schmale flächen","rutschiger boden","instabile konstruktionen","gleichgewicht halten"),
        ("Metallstreben","Dächer","Schiffsdecks","Geröll")),
    "SKILL_ACROBATICS": SkillDef("SKILL_ACROBATICS", "Akrobatik", (
        _s(STAGE_INPUT,("STAT_PER",),"Raum, Distanz und Bewegungsbahn erfassen."),
        _s(STAGE_SETUP,("STAT_MOB",),"Körper für komplexe Bewegung ausrichten."),
        _s(STAGE_EXECUTE,("STAT_MOB","STAT_REA"),"Komplexe Ganzkörperbewegung ausführen."),
        _s(STAGE_CONTROL,("STAT_DEX",),"Landung und Endposition kontrollieren."),),
        ("rollen","vault","komplexe sprünge","abfangen","enge bewegungen"),
        ("Parkour","Fensterdurchstieg","Sturzrollen","Leiterwechsel")),
    "SKILL_STEALTH": SkillDef("SKILL_STEALTH", "Schleichen", (
        _s(STAGE_INPUT,("STAT_PER",),"Leise Wege, Beobachter und Geräuschquellen erkennen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Route und Timing aus den Signalen ableiten."),
        _s(STAGE_EXECUTE,("STAT_MOB","STAT_DEX"),"Bewegung geräuscharm ausführen."),
        _s(STAGE_CONTROL,("STAT_REA",),"Balance- und Timingfehler korrigieren."),),
        ("schleichen","versteckt bewegen","geräusche vermeiden","sichtlinien meiden"),
        ("Metallböden","Laub","Menschenmengen","Industriehallen")),
    "SKILL_AIM_CONTROL": SkillDef("SKILL_AIM_CONTROL", "Zielkontrolle", (
        _s(STAGE_INPUT,("STAT_PER",),"Ziel, Distanz und Bewegung erfassen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Vorhalt und geeigneten Zeitpunkt bestimmen."),
        _s(STAGE_EXECUTE,("STAT_DEX","STAT_REA"),"Gezielte Bewegung im richtigen Moment ausführen."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Zielbild unter Druck stabil halten."),),
        ("werfen","schießen","präzise angriffe","bewegte ziele"),
        ("Kurzdistanzen","bewegte Ziele","schlechte Sicht","enge Schussfenster")),
    "SKILL_FINE_MECHANICS": SkillDef("SKILL_FINE_MECHANICS", "Feinmechanik", (
        _s(STAGE_INPUT,("STAT_PER",),"Kleine Bauteile und Lage erkennen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Funktionsbeziehungen verstehen."),
        _s(STAGE_EXECUTE,("STAT_DEX",),"Kleine Komponenten präzise manipulieren."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Feinarbeit ruhig und wiederholbar halten."),),
        ("kleinteile","schlösser","kontakte","feine werkzeuge","präzisionsmontage"),
        ("Mikrostecker","Feinlager","Ventile","mechanische Schlösser")),
    "SKILL_TECHNOLOGY": SkillDef("SKILL_TECHNOLOGY", "Technik", (
        _s(STAGE_INPUT,("STAT_PER",),"Technischen Zustand und Symptome erfassen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Systemfunktion und Ursache verstehen."),
        _s(STAGE_SETUP,("STAT_COG","STAT_DEX"),"Reparatur- oder Eingriffsplan vorbereiten."),
        _s(STAGE_EXECUTE,("STAT_DEX",),"Technische Arbeit ausführen."),),
        ("maschinen","mechanik","reparatur","wartung","technische manipulation"),
        ("Hydraulik","Antriebe","Pumpen","Industrieanlagen")),
    "SKILL_ELECTRONICS": SkillDef("SKILL_ELECTRONICS", "Elektronik", (
        _s(STAGE_INPUT,("STAT_PER",),"Elektrische Zustände und sichtbare Hinweise erfassen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Schaltung und Signalfluss verstehen."),
        _s(STAGE_EXECUTE,("STAT_DEX",),"Elektrische Komponenten präzise bearbeiten."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Sichere Arbeitsfolge einhalten."),),
        ("schaltungen","sensoren","verkabelung","stromversorgung","elektronische reparatur"),
        ("Sensorbusse","Leistungsstufen","Platinen","Feldverkabelung")),
    "SKILL_NETWORKS": SkillDef("SKILL_NETWORKS", "Netzwerke", (
        _s(STAGE_INPUT,("STAT_PER",),"Schnittstellen und sichtbare Netzwerkzustände erfassen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Protokoll, Topologie und Sicherheitslage verstehen."),
        _s(STAGE_SETUP,("STAT_COG",),"Zugriff oder Diagnosefolge planen."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Fehler und unerwünschte Seiteneffekte vermeiden."),),
        ("netzwerke","datenzugriff","protokolle","schnittstellen","signalpfade"),
        ("Industrieprotokolle","Mesh-Netze","alte Bussysteme","gesicherte Terminals")),
    "SKILL_DIAGNOSTICS": SkillDef("SKILL_DIAGNOSTICS", "Diagnostik", (
        _s(STAGE_INPUT,("STAT_PER",),"Symptome und Messwerte aufnehmen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Ursachen gegeneinander abgrenzen."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Diagnose gegen voreilige Schlussfolgerung stabil halten."),),
        ("fehleranalyse","ursachen finden","zustand bewerten","vergleich von symptomen"),
        ("Maschinenfehler","Sensorfehler","Mehrfachausfälle","intermittierende Fehler")),
    "SKILL_MEDICINE": SkillDef("SKILL_MEDICINE", "Medizin", (
        _s(STAGE_INPUT,("STAT_PER",),"Verletzungen und Vitalzeichen erfassen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Medizinische Lage einordnen."),
        _s(STAGE_SETUP,("STAT_COG",),"Behandlung priorisieren und vorbereiten."),
        _s(STAGE_EXECUTE,("STAT_DEX",),"Behandlung technisch ausführen."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Unter Stress sauber weiterarbeiten."),),
        ("erste hilfe","trauma","stabilisierung","behandlung","medizinische diagnose"),
        ("Traumaversorgung","Blutungen","Atemweg","Feldmedizin")),
    "SKILL_ATTENTION": SkillDef("SKILL_ATTENTION", "Aufmerksamkeit", (
        _s(STAGE_INPUT,("STAT_PER",),"Relevante Signale überhaupt aufnehmen."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Aufmerksamkeit trotz Ablenkung aufrechterhalten."),),
        ("wache halten","signal filtern","lange beobachten","mehrere reize"),
        ("Maschinenlärm","Nachtwache","Menschenmengen","Sensorüberwachung")),
    "SKILL_OBSERVATION": SkillDef("SKILL_OBSERVATION", "Observation", (
        _s(STAGE_INPUT,("STAT_PER",),"Details und Veränderungen sehen oder hören."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Details zu einem sinnvollen Muster verbinden."),),
        ("spuren","details","beobachten","umgebung lesen","veränderungen erkennen"),
        ("Tatorte","Mikrobewegungen","Werkspuren","Patrouillenmuster")),
    "SKILL_ORIENTATION": SkillDef("SKILL_ORIENTATION", "Orientierung", (
        _s(STAGE_INPUT,("STAT_PER",),"Räumliche Bezugspunkte aufnehmen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Position, Richtung und Route ableiten."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Orientierung trotz Stress oder Reizarmut halten."),),
        ("navigation","karten","wegesuche","raumlage","zurückfinden"),
        ("Tunnel","Ruinen","Großstadt","Wildnis")),
    "SKILL_PEOPLE_READING": SkillDef("SKILL_PEOPLE_READING", "Menschenkenntnis", (
        _s(STAGE_INPUT,("STAT_PER","STAT_SOC"),"Soziale und körperliche Signale erfassen."),
        _s(STAGE_INTERPRET,("STAT_COG","STAT_SOC"),"Mögliche Emotionen und Absichten einordnen."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Eigene Projektionen und Vorurteile begrenzen."),),
        ("emotionen lesen","täuschung erkennen","absichten einschätzen","soziale lage"),
        ("Mikroexpressionen","Verhandlung","Angstreaktionen","Gruppendynamik")),
    "SKILL_COMMUNICATION": SkillDef("SKILL_COMMUNICATION", "Kommunikation", (
        _s(STAGE_INPUT,("STAT_SOC","STAT_PER"),"Gegenüber und Gesprächslage wahrnehmen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Botschaft und Strategie wählen."),
        _s(STAGE_EXECUTE,("STAT_SOC",),"Botschaft passend ausdrücken."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Gespräch trotz Widerstand stabil führen."),),
        ("erklären","verhandeln","überzeugen","deeskalieren","koordinieren"),
        ("Techniker erklären","Krisengespräch","Handel","Führung")),
    "SKILL_SELF_CONTROL": SkillDef("SKILL_SELF_CONTROL", "Selbstbeherrschung", (
        _s(STAGE_INPUT,("STAT_PER",),"Eigenen Stress- und Körperzustand erkennen."),
        _s(STAGE_SETUP,("STAT_WIL",),"Bewusste Regulationsstrategie wählen."),
        _s(STAGE_CONTROL,("STAT_WIL","STAT_END"),"Angst, Schmerz oder Impuls kontrollieren."),),
        ("angst","schmerz","stress","provokation","panik vermeiden"),
        ("Schmerz","Verhör","Panik","Sensorische Überlastung")),
    "SKILL_RESONANCE_SENSE": SkillDef("SKILL_RESONANCE_SENSE", "Resonanzwahrnehmung", (
        _s(STAGE_INPUT,("STAT_RES","STAT_PER"),"Resonanzsignal aufnehmen."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Signal vom Eigenrauschen trennen."),),
        ("präsenz spüren","felder erkennen","anomalien wahrnehmen","resonanz lokalisieren"),
        ("Entitätssignaturen","Artefaktfelder","Ortsresonanzen","schwache Echos")),
    "SKILL_RESONANCE_CONTROL": SkillDef("SKILL_RESONANCE_CONTROL", "Resonanzkontrolle", (
        _s(STAGE_INPUT,("STAT_RES",),"Eigene und fremde Resonanzlage erfassen."),
        _s(STAGE_SETUP,("STAT_WIL",),"Resonanzfokus aufbauen."),
        _s(STAGE_EXECUTE,("STAT_RES",),"Kopplung oder Leitung herstellen."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Kopplung stabil halten."),),
        ("fokussieren","koppeln","abschirmen","resonanz halten"),
        ("Entitätskontakt","Feldstabilisierung","Artefaktkopplung","Abschirmung")),
    "SKILL_RESONANCE_PROJECTION": SkillDef("SKILL_RESONANCE_PROJECTION", "Resonanzprojektion", (
        _s(STAGE_SETUP,("STAT_WIL",),"Projektionsrichtung und Intensität fokussieren."),
        _s(STAGE_EXECUTE,("STAT_RES",),"Resonanz nach außen übertragen."),
        _s(STAGE_CONTROL,("STAT_WIL","STAT_END"),"Projektion ohne Kontrollverlust halten."),),
        ("resonanz senden","feldwirkung","impuls","resonante projektion"),
        ("Druckimpulse","Ward-Verstärkung","Signalgebung","Feldprojektion")),
    "SKILL_OCCULT_KNOWLEDGE": SkillDef("SKILL_OCCULT_KNOWLEDGE", "Okkultes Wissen", (
        _s(STAGE_INPUT,("STAT_PER",),"Symbole, Phänomene und relevante Zeichen erfassen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Tradition, Entität oder Mechanismus einordnen."),),
        ("dämonologie","rituale verstehen","entitäten klassifizieren","okkulte symbole"),
        ("Dämonologie","Schutzzeichen","Kultsysteme","Entitätsregeln")),
    "SKILL_RITUAL_TECHNIQUE": SkillDef("SKILL_RITUAL_TECHNIQUE", "Ritualtechnik", (
        _s(STAGE_INTERPRET,("STAT_COG",),"Ritualstruktur und Reihenfolge verstehen."),
        _s(STAGE_SETUP,("STAT_COG","STAT_DEX"),"Symbole, Medien und Geometrie vorbereiten."),
        _s(STAGE_EXECUTE,("STAT_DEX","STAT_RES"),"Rituelle Struktur korrekt aktivieren."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Ablauf und Kopplung stabil halten."),),
        ("siegel","schutzkreis","bindung","ritual","artefaktaktivierung"),
        ("Schutzsiegel","Bindungskreise","Artefaktrituale","Beschwörungsgeometrie")),
    "SKILL_ASTRAL_NAVIGATION": SkillDef("SKILL_ASTRAL_NAVIGATION", "Astrale Navigation", (
        _s(STAGE_INPUT,("STAT_RES","STAT_PER"),"Nichtnormale räumliche Hinweise aufnehmen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Resonanzraum und Richtung einordnen."),
        _s(STAGE_EXECUTE,("STAT_RES",),"Wahrnehmungsfokus entlang der Route bewegen."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Orientierung und Rückbindung erhalten."),),
        ("astrale räume","schwellen","resonanzpfade","fernsondierung"),
        ("Schwellenräume","Traumpfade","Entitätsräume","Fernsondierung")),
    "SKILL_RESONANCE_CONCEALMENT": SkillDef("SKILL_RESONANCE_CONCEALMENT", "Resonanzverschleierung", (
        _s(STAGE_INPUT,("STAT_RES","STAT_PER"),"Eigene erkennbare Resonanzanteile wahrnehmen."),
        _s(STAGE_SETUP,("STAT_WIL",),"Verschleierungsstrategie fokussieren."),
        _s(STAGE_EXECUTE,("STAT_RES",),"Signatur gezielt dämpfen oder angleichen."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Maskierung während Handlung stabil halten."),),
        ("signatur verbergen","resonant schleichen","okkulte tarnung","feld dämpfen"),
        ("Entitäten umgehen","Artefaktsensoren","Wards","Resonanzjagd")),
    "SKILL_ENTITY_CONTACT": SkillDef("SKILL_ENTITY_CONTACT", "Entitätskontakt", (
        _s(STAGE_INPUT,("STAT_RES","STAT_PER"),"Kontaktfähige Präsenz differenzieren."),
        _s(STAGE_INTERPRET,("STAT_SOC","STAT_COG"),"Signal als mögliche Kommunikation einordnen."),
        _s(STAGE_SETUP,("STAT_WIL",),"Kontaktgrenze und Ziel definieren."),
        _s(STAGE_EXECUTE,("STAT_RES","STAT_SOC"),"Resonante Kommunikationskopplung herstellen."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Eigen- und Fremdsignal getrennt halten."),),
        ("geistkontakt","entität ansprechen","mediumismus","nichtmenschliche kommunikation"),
        ("Gebundene Entitäten","Ortsgeister","Restmuster","fremde Signaturen")),
    "SKILL_BANISHING": SkillDef("SKILL_BANISHING", "Bannung", (
        _s(STAGE_INPUT,("STAT_RES","STAT_PER"),"Bindung und Resonanzquelle erkennen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Angriffspunkt der Bindung bestimmen."),
        _s(STAGE_SETUP,("STAT_WIL",),"Eigene Resonanz gegen Rückwirkung stabilisieren."),
        _s(STAGE_EXECUTE,("STAT_RES",),"Bindung resonant unterbrechen oder zurückdrängen."),
        _s(STAGE_CONTROL,("STAT_WIL","STAT_END"),"Bannung gegen Gegenwehr halten."),),
        ("fluch brechen","besessenheit lösen","entität bannen","bindung zerstören"),
        ("Besessenheitsbindungen","Fluchknoten","Entitätsanker","Artefaktbindungen")),
    "SKILL_ECHO_ANALYSIS": SkillDef("SKILL_ECHO_ANALYSIS", "Echoanalyse", (
        _s(STAGE_INPUT,("STAT_RES","STAT_PER"),"Resonanzreste an Objekt oder Ort aufnehmen."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Eigenrauschen und Überlagerungen begrenzen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Fragmente zu belastbaren Mustern ordnen."),),
        ("objektspuren","ortsechos","resonanzreste","ereignisfragmente"),
        ("Tatort-Echos","Besitzerreste","Traumaorte","Artefaktgeschichte")),
    "SKILL_DIVINATION": SkillDef("SKILL_DIVINATION", "Divination", (
        _s(STAGE_INPUT,("STAT_RES","STAT_PER"),"Schwache symbolische oder resonante Hinweise aufnehmen."),
        _s(STAGE_INTERPRET,("STAT_COG",),"Mehrdeutige Muster ohne Gewissheit interpretieren."),
        _s(STAGE_CONTROL,("STAT_WIL",),"Wunschdenken und Überinterpretation begrenzen."),),
        ("vorzeichen","symboldeutung","präkognitive fragmente","muster lesen"),
        ("Traumbilder","Orakelmedien","Gefahrenvorahnungen","Wahrscheinlichkeitsmuster")),
}


TALENTS: Mapping[str, TalentDef] = {
    # Breaker
    "TALENT_FORCE_LINE": TalentDef("TALENT_FORCE_LINE","Kraftlinie","BREAKER",("SKILL_FORCE_APPLICATION",),
        ("STAT_STR","STAT_MOB"),(STAGE_SETUP,STAGE_EXECUTE),("heben","brechen","schieben","ringen"),
        "Optimiert Stand und Kraftübertragung, ohne die natürliche Kraftgrenze zu erhöhen."),
    "TALENT_UNYIELDING": TalentDef("TALENT_UNYIELDING","Unnachgiebig","BREAKER",("SKILL_LOAD_CONTROL","SKILL_SELF_CONTROL"),
        ("STAT_END","STAT_WIL"),(STAGE_CONTROL,),("schmerz","erschöpfung","halten","schutz"),
        "Hält eine bereits mögliche Handlung unter Belastung länger kohärent."),
    "TALENT_IMPACT_CONTROL": TalentDef("TALENT_IMPACT_CONTROL","Impact Control","BREAKER",("SKILL_FORCE_APPLICATION","SKILL_AIM_CONTROL"),
        ("STAT_STR","STAT_REA"),(STAGE_EXECUTE,STAGE_CONTROL),("stoß","schlag","breach","kontrollierte gewalt"),
        "Verbindet explosive Kraft mit kontrollierter Zielwirkung."),
    "TALENT_RESONANCE_ARMOR": TalentDef("TALENT_RESONANCE_ARMOR","Resonanzpanzer","BREAKER",("SKILL_RESONANCE_CONTROL","SKILL_SELF_CONTROL"),
        ("STAT_RES","STAT_WIL"),(STAGE_SETUP,STAGE_CONTROL),("resonanzdruck","fluchkontakt","entitätsnähe"),
        "Dämpft begrenzte eingehende Resonanz, ohne Unverwundbarkeit zu erzeugen."),
    "TALENT_BANISHING_STRIKE": TalentDef("TALENT_BANISHING_STRIKE","Bannschlag","BREAKER",("SKILL_BANISHING","SKILL_FORCE_APPLICATION"),
        ("STAT_RES","STAT_STR"),(STAGE_EXECUTE,),("manifestation","gebundene entität","fluchanker"),
        "Koppelt einen physischen Impuls an eine bereits mögliche Bannwirkung."),
    "TALENT_ANCHOR": TalentDef("TALENT_ANCHOR","Anker","BREAKER",("SKILL_SELF_CONTROL","SKILL_RESONANCE_CONTROL"),
        ("STAT_END","STAT_WIL","STAT_RES"),(STAGE_CONTROL,),("besessenheit","forced movement","resonanzzug"),
        "Stabilisiert Körper und Selbstbild gegen äußere Verdrängung oder resonante Zugkräfte."),
    # Ghost
    "TALENT_PHANTOM_STEP": TalentDef("TALENT_PHANTOM_STEP","Phantom Step","GHOST",("SKILL_STEALTH","SKILL_BALANCE"),
        ("STAT_MOB","STAT_DEX"),(STAGE_EXECUTE,STAGE_CONTROL),("leise bewegung","schmale wege","beobachter umgehen"),
        "Verbindet leise Trittplanung mit präziser Gewichtsverlagerung."),
    "TALENT_BLIND_MOVEMENT": TalentDef("TALENT_BLIND_MOVEMENT","Blind Movement","GHOST",("SKILL_BALANCE","SKILL_ORIENTATION"),
        ("STAT_MOB","STAT_PER"),(STAGE_INPUT,STAGE_CONTROL),("dunkelheit","rauch","blendung","enge räume"),
        "Nutzt propriozeptive und räumliche Hinweise bei eingeschränkter Sicht."),
    "TALENT_ECHO_TRACKING": TalentDef("TALENT_ECHO_TRACKING","Echo Tracking","GHOST",("SKILL_OBSERVATION","SKILL_ECHO_ANALYSIS"),
        ("STAT_PER","STAT_RES"),(STAGE_INPUT,STAGE_INTERPRET),("spuren","resonanzreste","verfolgung"),
        "Verbindet physische Spuren mit vorhandenen resonanten Restinformationen."),
    "TALENT_VEIL": TalentDef("TALENT_VEIL","Veil","GHOST",("SKILL_RESONANCE_CONCEALMENT","SKILL_STEALTH"),
        ("STAT_RES","STAT_WIL"),(STAGE_SETUP,STAGE_CONTROL),("resonanzsensoren","entitäten umgehen","tarnung"),
        "Dämpft die eigene Resonanzsignatur parallel zu physischer Tarnung."),
    "TALENT_ASTRAL_TRACE": TalentDef("TALENT_ASTRAL_TRACE","Astral Trace","GHOST",("SKILL_ASTRAL_NAVIGATION","SKILL_OBSERVATION"),
        ("STAT_RES","STAT_PER"),(STAGE_INPUT,STAGE_INTERPRET),("schwellen","resonanzpfade","fernspuren"),
        "Verfolgt tatsächlich vorhandene nichtphysische Spuren ohne verborgenes Wissen zu erzeugen."),
    "TALENT_GLAMOUR": TalentDef("TALENT_GLAMOUR","Glamour","GHOST",("SKILL_RESONANCE_CONCEALMENT","SKILL_COMMUNICATION"),
        ("STAT_RES","STAT_SOC"),(STAGE_EXECUTE,STAGE_CONTROL),("aufmerksamkeit umlenken","soziale tarnung","fehlwahrnehmung"),
        "Beeinflusst Salienz und Aufmerksamkeit subtil; erzwingt weder Glauben noch Gehorsam."),
    # Operator
    "TALENT_MACHINEWORK": TalentDef("TALENT_MACHINEWORK","Maschinenwerk","OPERATOR",("SKILL_TECHNOLOGY","SKILL_DIAGNOSTICS"),
        ("STAT_COG","STAT_DEX"),(STAGE_INTERPRET,STAGE_EXECUTE),("maschinen","reparatur","wartung","störungsanalyse"),
        "Verbindet Diagnose und technische Ausführung bei komplexen Maschinen."),
    "TALENT_SYSTEM_VIEW": TalentDef("TALENT_SYSTEM_VIEW","Systemblick","OPERATOR",("SKILL_DIAGNOSTICS","SKILL_ATTENTION"),
        ("STAT_COG","STAT_PER"),(STAGE_INPUT,STAGE_INTERPRET),("systemfehler","mehrfachausfälle","infrastruktur"),
        "Erkennt Abhängigkeiten und Fehlerketten in komplexen Systemen."),
    "TALENT_FIELD_REPAIR": TalentDef("TALENT_FIELD_REPAIR","Field Repair","OPERATOR",("SKILL_TECHNOLOGY","SKILL_FINE_MECHANICS"),
        ("STAT_DEX","STAT_COG"),(STAGE_SETUP,STAGE_EXECUTE),("improvisierte reparatur","zeitdruck","fehlende teile"),
        "Erlaubt begrenzte improvisierte Wiederherstellung mit vorhandenen Mitteln."),
    "TALENT_SIGILCRAFT": TalentDef("TALENT_SIGILCRAFT","Sigilcraft","OPERATOR",("SKILL_RITUAL_TECHNIQUE","SKILL_OCCULT_KNOWLEDGE"),
        ("STAT_COG","STAT_DEX","STAT_RES"),(STAGE_INTERPRET,STAGE_SETUP,STAGE_EXECUTE),("siegel","wards","ritualstruktur"),
        "Konstruiert und verändert bekannte symbolische Resonanzstrukturen."),
    "TALENT_CONTAINMENT": TalentDef("TALENT_CONTAINMENT","Containment","OPERATOR",("SKILL_RITUAL_TECHNIQUE","SKILL_DIAGNOSTICS"),
        ("STAT_COG","STAT_RES"),(STAGE_SETUP,STAGE_CONTROL),("anomalie eindämmen","entität binden","feld stabilisieren"),
        "Entwirft begrenzte technische oder rituelle Eindämmung auf Basis erkannter Eigenschaften."),
    "TALENT_ARTIFACT_ENGINEERING": TalentDef("TALENT_ARTIFACT_ENGINEERING","Artifact Engineering","OPERATOR",("SKILL_TECHNOLOGY","SKILL_RITUAL_TECHNIQUE"),
        ("STAT_COG","STAT_DEX","STAT_RES"),(STAGE_INTERPRET,STAGE_EXECUTE),("artefakt","resonanzkern","hybridsystem"),
        "Verbindet technische und resonante Komponenten, ohne deren Grenzen zu ignorieren."),
    # Resonant
    "TALENT_AURA_READING": TalentDef("TALENT_AURA_READING","Aura Reading","RESONANT",("SKILL_RESONANCE_SENSE","SKILL_PEOPLE_READING"),
        ("STAT_RES","STAT_PER","STAT_SOC"),(STAGE_INPUT,STAGE_INTERPRET),("aura","affekt","resonanzzustand"),
        "Differenziert wahrgenommene Resonanz- und Sozialsignale, ohne Gedankenlesen."),
    "TALENT_PSYCHOMETRY": TalentDef("TALENT_PSYCHOMETRY","Psychometrie","RESONANT",("SKILL_ECHO_ANALYSIS","SKILL_RESONANCE_CONTROL"),
        ("STAT_RES","STAT_PER","STAT_WIL"),(STAGE_INPUT,STAGE_CONTROL,STAGE_INTERPRET),("objekte","orte","ereignisechos"),
        "Erlaubt gezielte Echoanalyse über direkten Kontakt mit Objekt oder Ort."),
    "TALENT_TELEPATHIC_LINK": TalentDef("TALENT_TELEPATHIC_LINK","Telepathische Kopplung","RESONANT",("SKILL_ENTITY_CONTACT","SKILL_RESONANCE_CONTROL"),
        ("STAT_RES","STAT_SOC","STAT_WIL"),(STAGE_SETUP,STAGE_EXECUTE,STAGE_CONTROL),("mentale impulse","kontakt","resonante kommunikation"),
        "Stellt eine begrenzte mentale Resonanzkopplung her; keine automatische Informationsentnahme."),
    "TALENT_CLAIRVOYANCE": TalentDef("TALENT_CLAIRVOYANCE","Clairvoyance","RESONANT",("SKILL_RESONANCE_SENSE","SKILL_ASTRAL_NAVIGATION"),
        ("STAT_RES","STAT_PER","STAT_WIL"),(STAGE_INPUT,STAGE_CONTROL),("verborgene resonanz","fernwahrnehmung","schwellen"),
        "Erweitert Resonanzwahrnehmung über normale Sichtbezüge, bleibt aber signal- und reichweitengebunden."),
    "TALENT_RETROCOGNITION": TalentDef("TALENT_RETROCOGNITION","Retrokognition","RESONANT",("SKILL_ECHO_ANALYSIS","SKILL_DIVINATION"),
        ("STAT_RES","STAT_COG"),(STAGE_INPUT,STAGE_INTERPRET),("vergangenheitsechos","tatorte","ereignisreste"),
        "Rekonstruiert mögliche vergangene Fragmente aus vorhandenen Echos, nicht aus allwissendem Zugriff."),
    "TALENT_PRECOGNITIVE_RESONANCE": TalentDef("TALENT_PRECOGNITIVE_RESONANCE","Präkognitive Resonanz","RESONANT",("SKILL_DIVINATION","SKILL_ATTENTION"),
        ("STAT_RES","STAT_PER","STAT_WIL"),(STAGE_INPUT,STAGE_INTERPRET,STAGE_CONTROL),("gefahr","mögliche nächste ereignisse","vorahnung"),
        "Erfasst mehrdeutige kurzfristige Wahrscheinlichkeitsfragmente statt garantierter Zukunft."),
    "TALENT_MEDIUMSHIP": TalentDef("TALENT_MEDIUMSHIP","Mediumismus","RESONANT",("SKILL_ENTITY_CONTACT","SKILL_SELF_CONTROL"),
        ("STAT_RES","STAT_SOC","STAT_WIL"),(STAGE_INPUT,STAGE_EXECUTE,STAGE_CONTROL),("geister","entitäten","restbewusstsein"),
        "Erlaubt kontrollierteren Kontakt mit nichtnormalen Bewusstseins- oder Restmustern."),
    "TALENT_ASTRAL_PROJECTION": TalentDef("TALENT_ASTRAL_PROJECTION","Astralprojektion","RESONANT",("SKILL_ASTRAL_NAVIGATION","SKILL_RESONANCE_CONTROL"),
        ("STAT_RES","STAT_WIL","STAT_COG"),(STAGE_SETUP,STAGE_EXECUTE,STAGE_CONTROL),("fernsondierung","schwellenraum","projektion"),
        "Verlagert den Wahrnehmungsfokus unter Rückbindungs- und Reichweitengrenzen."),
}

CLASS_TALENTS = {
    cls: tuple(t.talent_id for t in TALENTS.values() if t.owner_class == cls)
    for cls in ("BREAKER","GHOST","OPERATOR","RESONANT")
}


def validate_catalog() -> Tuple[str, ...]:
    errors=[]
    if len(STATS) != 10: errors.append(f"STAT_COUNT:{len(STATS)}")
    if len(SKILLS) != 30: errors.append(f"SKILL_COUNT:{len(SKILLS)}")
    if len(TALENTS) != 26: errors.append(f"TALENT_COUNT:{len(TALENTS)}")
    for skill in SKILLS.values():
        if not skill.stages: errors.append(f"SKILL_NO_STAGES:{skill.skill_id}")
        for stage in skill.stages:
            if stage.stage not in STAGES: errors.append(f"SKILL_BAD_STAGE:{skill.skill_id}:{stage.stage}")
            for stat in stage.stats:
                if stat not in STATS: errors.append(f"SKILL_BAD_STAT:{skill.skill_id}:{stat}")
    for talent in TALENTS.values():
        for skill in talent.required_skills:
            if skill not in SKILLS: errors.append(f"TALENT_BAD_SKILL:{talent.talent_id}:{skill}")
        for stat in talent.required_stats:
            if stat not in STATS: errors.append(f"TALENT_BAD_STAT:{talent.talent_id}:{stat}")
        if not talent.situations: errors.append(f"TALENT_NO_SITUATIONS:{talent.talent_id}")
        if not talent.modifies_stages: errors.append(f"TALENT_NO_STAGE:{talent.talent_id}")
    return tuple(errors)

# Class start calibration. All characters share the same human capability tree;
# these values only set starting emphasis, never different physical laws.
_CLASS_STAT_OVERRIDES = {
    "BREAKER": {"STAT_STR":7,"STAT_END":7,"STAT_MOB":6,"STAT_REA":6,"STAT_WIL":6,"STAT_RES":4},
    "GHOST": {"STAT_MOB":7,"STAT_DEX":7,"STAT_REA":7,"STAT_PER":6,"STAT_WIL":6,"STAT_RES":4},
    "OPERATOR": {"STAT_COG":8,"STAT_DEX":7,"STAT_PER":6,"STAT_WIL":6,"STAT_RES":4},
    "RESONANT": {"STAT_RES":8,"STAT_PER":7,"STAT_WIL":7,"STAT_SOC":6,"STAT_COG":6},
}

_CLASS_SKILL_OVERRIDES = {
    "BREAKER": {
        "SKILL_ATHLETICS":5,"SKILL_FORCE_APPLICATION":6,"SKILL_LOAD_CONTROL":5,
        "SKILL_AIM_CONTROL":4,"SKILL_SELF_CONTROL":5,"SKILL_RESONANCE_CONTROL":3,
        "SKILL_BANISHING":3,"SKILL_BALANCE":3,
    },
    "GHOST": {
        "SKILL_BALANCE":6,"SKILL_ACROBATICS":5,"SKILL_STEALTH":6,"SKILL_AIM_CONTROL":5,
        "SKILL_ATTENTION":5,"SKILL_OBSERVATION":5,"SKILL_ORIENTATION":5,
        "SKILL_RESONANCE_CONCEALMENT":3,"SKILL_ASTRAL_NAVIGATION":3,
    },
    "OPERATOR": {
        "SKILL_FINE_MECHANICS":6,"SKILL_TECHNOLOGY":6,"SKILL_ELECTRONICS":5,
        "SKILL_NETWORKS":5,"SKILL_DIAGNOSTICS":6,"SKILL_MEDICINE":4,
        "SKILL_ATTENTION":5,"SKILL_COMMUNICATION":4,"SKILL_OCCULT_KNOWLEDGE":3,
        "SKILL_RITUAL_TECHNIQUE":3,
    },
    "RESONANT": {
        "SKILL_ATTENTION":5,"SKILL_PEOPLE_READING":5,"SKILL_SELF_CONTROL":5,
        "SKILL_RESONANCE_SENSE":6,"SKILL_RESONANCE_CONTROL":5,"SKILL_RESONANCE_PROJECTION":4,
        "SKILL_OCCULT_KNOWLEDGE":4,"SKILL_ASTRAL_NAVIGATION":4,"SKILL_ENTITY_CONTACT":4,
        "SKILL_ECHO_ANALYSIS":5,"SKILL_DIVINATION":4,
    },
}

_CLASS_START_TALENTS = {
    "BREAKER": ("TALENT_FORCE_LINE", "TALENT_UNYIELDING"),
    "GHOST": ("TALENT_PHANTOM_STEP", "TALENT_BLIND_MOVEMENT"),
    "OPERATOR": ("TALENT_MACHINEWORK", "TALENT_SYSTEM_VIEW"),
    "RESONANT": ("TALENT_AURA_READING", "TALENT_PSYCHOMETRY"),
}


def class_start_stats(start_class: str) -> dict[str,int]:
    cls=str(start_class or '').upper()
    if cls not in CLASS_TALENTS: raise ValueError('START_CLASS_INVALID')
    values={sid:5 for sid in STATS}
    values.update(_CLASS_STAT_OVERRIDES[cls])
    return values


def class_start_skills(start_class: str) -> dict[str,int]:
    cls=str(start_class or '').upper()
    if cls not in CLASS_TALENTS: raise ValueError('START_CLASS_INVALID')
    values={sid:1 for sid in SKILLS}
    values.update(_CLASS_SKILL_OVERRIDES[cls])
    return values


def class_start_talents(start_class: str) -> list[str]:
    cls=str(start_class or '').upper()
    if cls not in CLASS_TALENTS: raise ValueError('START_CLASS_INVALID')
    return list(_CLASS_START_TALENTS[cls])


def validate_talent_prerequisites(start_class: str, skills: Mapping[str,int], talents: Tuple[str,...] | list[str]) -> Tuple[str,...]:
    cls=str(start_class or '').upper(); errors=[]
    allowed=set(CLASS_TALENTS.get(cls,()))
    for talent_id in talents:
        if talent_id not in TALENTS:
            errors.append('TALENT_UNKNOWN:'+str(talent_id)); continue
        t=TALENTS[talent_id]
        if talent_id not in allowed or t.owner_class != cls:
            errors.append('TALENT_CLASS_MISMATCH:'+talent_id); continue
        missing=[s for s in t.required_skills if int(skills.get(s,0)) <= 0]
        if missing: errors.append('TALENT_SKILL_PREREQUISITE:'+talent_id+':' + ','.join(missing))
    return tuple(errors)
