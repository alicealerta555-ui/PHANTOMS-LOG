from __future__ import annotations
from dataclasses import dataclass
import hashlib
import json
from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage9.world_time import WORLD_TIME_RUNTIME_KEY, WorldClock
from runtime.full_version.bootstrap import PLAYER_ACTOR_INSTANCE_ID
from runtime.full_version.content_distribution import ContentDistributionResolver
from runtime.full_version.capability_runtime import assess_action, deterministic_uncertain_success

class DataTerminalError(RuntimeError): pass
@dataclass(frozen=True,slots=True)
class DataReadResult:
    content_id:str; subject:str; summary:str; seconds:int
    title:str = ""
    document_type:str = ""
    canonical_facts:tuple[str,...] = ()
    variation_index:int = 0
    variation_seed:str = ""
    capability_zone:str = "SAFE"
    capability_explanation:str = ""
    capability_roll:int|None = None
    capability_target:int|None = None

class DataTerminalRuntime:
    def __init__(self,catalog,session):
        self.catalog=catalog; self.session=session
        content=catalog.root/'content/full_version'
        raw=json.loads((content/'data_item_contents.json').read_text(encoding='utf-8'))
        if raw.get('schema') not in {'PH4NT0M5_DATA_ITEM_CONTENTS_V1','PH4NT0M5_DATA_ITEM_CONTENTS_V2'}: raise DataTerminalError('DATA_CONTENT_SCHEMA_INVALID')
        self.contents={x['item_definition_id']:x for x in raw['entries']}
        inter=json.loads((content/'location_interactables.json').read_text(encoding='utf-8'))
        if inter.get('schema')!='PH4NT0M5_LOCATION_INTERACTABLES_V1': raise DataTerminalError('INTERACTABLE_SCHEMA_INVALID')
        self.objects={x['location_id']:x['objects'] for x in inter['locations']}
        self.distribution=ContentDistributionResolver(catalog)
    def terminals(self,location_id): return [x for x in self.objects.get(location_id,[]) if x.get('kind')=='terminal']
    def _presentation(self, content:dict, location_id:str='') -> tuple[str,int,str,dict]:
        variants=tuple(str(x) for x in content.get('presentation_variants',()) if str(x).strip())
        distribution=self.distribution.resolve(content['item_definition_id'],location_id,run_uuid=self.session.identity.run_uuid) if location_id else None
        if not variants:
            return str(content['summary']),0,'',distribution.to_dict() if distribution else {}
        allowed=list(distribution.allowed_variant_indexes) if distribution and distribution.allowed_variant_indexes else list(range(len(variants)))
        allowed=[i for i in allowed if 0 <= i < len(variants)] or list(range(len(variants)))
        seed_material=f"{self.session.identity.run_uuid}|{content['content_id']}|{location_id}|CONTENT_PRESENTATION_V2"
        digest=hashlib.blake2b(seed_material.encode('utf-8'),digest_size=16).hexdigest()
        index=allowed[int(digest,16)%len(allowed)]
        return variants[index],index,digest,distribution.to_dict() if distribution else {}
    def presentation_packet(self, item_definition_id:str, location_id:str='') -> dict:
        content=self.contents.get(item_definition_id)
        if not content: raise DataTerminalError('DATA_CONTENT_MISSING')
        summary,index,seed,distribution=self._presentation(content,location_id)
        return {
            'content_id':content['content_id'],
            'title':content.get('title',''),
            'document_type':content.get('document_type',content.get('subject','data')),
            'canonical_facts':list(content.get('canonical_facts',())),
            'selected_variant':summary,
            'variation_index':index,
            'variation_seed':seed,
            'variation_policy':content.get('variation_policy','presentation_only'),
            'distribution_packet':distribution,
        }
    def read(self,item_id:str,actor_id:str=PLAYER_ACTOR_INSTANCE_ID)->DataReadResult:
        k=self.session.kernel; actor=k.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,actor_id)
        item=k.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,item_id)
        if not isinstance(actor,dict) or not isinstance(item,dict): raise DataTerminalError('DATA_ENTITY_MISSING')
        if item.get('location_ref')!='inventory:'+actor_id: raise DataTerminalError('DATA_ITEM_NOT_OWNED')
        definition=self.catalog.item_definition(item.get('item_definition_id'))
        if definition.get('kind')!='data': raise DataTerminalError('DATA_ITEM_REQUIRED')
        content=self.contents.get(item['item_definition_id'])
        if not content: raise DataTerminalError('DATA_CONTENT_MISSING')
        location=str(actor['location_ref'])
        if content.get('terminal_required') and not self.terminals(location): raise DataTerminalError('DATA_TERMINAL_REQUIRED_HERE')
        cap=None; cap_roll=None; cap_target=None
        if content.get('encrypted'):
            difficulty=int(content.get('difficulty',0))
            cap=assess_action(actor,'SKILL_NETWORKS',difficulty,context_tags=('data','encrypted','terminal','network'))
            if cap.blocked:
                raise DataTerminalError(f'DATA_CAPABILITY_BLOCKED:{cap.zone.value}:{cap.failure_stage or ""}:{cap.explanation}')
            ok,cap_roll,cap_target=deterministic_uncertain_success(cap,f'{self.session.identity.run_uuid}|data|{item_id}|{content["content_id"]}|{self.session.store.revision}')
            if not ok:
                raise DataTerminalError(f'DATA_CAPABILITY_CHECK_FAILED:{cap.zone.value}:{cap_roll}/{cap_target}:{cap.explanation}')
        summary,variation_index,variation_seed,distribution=self._presentation(content,location)
        title=str(content.get('title','')); document_type=str(content.get('document_type',content.get('subject','data')))
        canonical_facts=tuple(str(x) for x in content.get('canonical_facts',()))
        key='data_read:'+content['content_id']; now=WorldClock(self.session).seconds
        if k.read(Authority.KNOWLEDGE_ROUTER,Domain.ACTOR_KNOWLEDGE,key,actor_id=actor_id) is not None:
            return DataReadResult(content['content_id'],content['subject'],summary,0,title,document_type,canonical_facts,variation_index,variation_seed,cap.zone.value if cap else 'SAFE',cap.explanation if cap else '',cap_roll,cap_target)
        event=f'DATA_READ:{self.session.identity.run_uuid}:{content["content_id"]}'
        epi={'source_type':'DATA_ACCESS','source_id':item_id,'origin_location':location,'learned_at':now,'path':[],'confidence_ppm':1000000,'distortions':[]}
        value={'content_id':content['content_id'],'subject':content['subject'],'summary':summary,'canonical_facts':list(canonical_facts),'title':title,'document_type':document_type,'variation_index':variation_index,'variation_seed':variation_seed,'distribution_packet':distribution,'item_instance_id':item_id,'encrypted':bool(content.get('encrypted'))}
        seconds=12 if content.get('encrypted') else 6
        deltas=(
            Delta(Domain.ACTOR_KNOWLEDGE,key,value,Authority.KNOWLEDGE_ROUTER,'DATA_TERMINAL_READ',actor_id=actor_id,source_event_id=event,provenance='DATA_ITEM_CONTENT',epistemic=epi),
            Delta(Domain.RUNTIME_STATE,WORLD_TIME_RUNTIME_KEY,{'run_uuid':self.session.identity.run_uuid,'seconds':now+seconds},Authority.WORLD_TIME,'STAGE9_ADVANCE_WORLD_TIME',source_event_id=event,provenance='DATA_TERMINAL_READ'),
        )
        result=k.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=deltas,event_id=event,cause='DATA_TERMINAL_READ',expected_state_revision=self.session.store.revision))
        if not isinstance(result,CommitRecord): raise DataTerminalError('DATA_READ_COMMIT_REJECTED')
        return DataReadResult(content['content_id'],content['subject'],summary,seconds,title,document_type,canonical_facts,variation_index,variation_seed,cap.zone.value if cap else 'SAFE',cap.explanation if cap else '',cap_roll,cap_target)
