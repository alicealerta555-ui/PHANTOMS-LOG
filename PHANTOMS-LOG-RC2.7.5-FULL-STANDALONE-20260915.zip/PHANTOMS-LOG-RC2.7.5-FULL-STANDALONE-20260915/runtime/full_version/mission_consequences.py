from __future__ import annotations
import copy
import json
from dataclasses import dataclass
from hashlib import sha256
from typing import Mapping
from pathlib import Path

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import StateAuthority, AuthorityStatus
from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType
from runtime.stage9.gameplay import SemanticCommitAdapter
from runtime.stage8.world import Stage8MigrationEngine, Stage8WorldView, Stage8CommitAdapter
from runtime.stage10.state import Stage10CommitAdapter


class MissionConsequenceError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class AppliedMissionConsequence:
    candidate_id: str
    effect_type: str
    commit_revision: int


class MissionConsequenceRouter:
    """Apply only evidence-backed, closed semantic consequences.

    Mission resolution may propose a consequence candidate, but it cannot invent a
    mutation.  A caller must supply an already-resolved fact with an evidence_ref.
    This router translates the small supported fact vocabulary into Stage-9 semantic
    effects and therefore keeps the CommitKernel as the only state writer.
    """

    FACT_EFFECTS = {
        "WORLD_TIME_LOSS": (EffectType.ADVANCE_WORLD_TIME, AuthorityDomain.WORLD_TIME),
        "RESOURCE_DELTA": (EffectType.RESOURCE_DELTA, AuthorityDomain.RESOURCE),
        "ACTOR_DAMAGE": (EffectType.DAMAGE, AuthorityDomain.COMBAT),
        "INFRASTRUCTURE_STATE_CHANGE": (EffectType.INFRASTRUCTURE_STATE_CHANGE, AuthorityDomain.REGION),
        "ECOLOGY_RESOURCE_DELTA": (EffectType.ECOLOGY_RESOURCE_DELTA, AuthorityDomain.ECOLOGY),
        "ECOLOGY_POPULATION_DELTA": (EffectType.ECOLOGY_POPULATION_DELTA, AuthorityDomain.ECOLOGY),
    }

    def __init__(self, session, catalog=None):
        self.session = session
        self.catalog = catalog
        self.profiles = {}
        root = catalog.root if catalog is not None else Path(__file__).resolve().parents[2]
        profile_path = root / "content/full_version/mission_consequence_profiles.json"
        if profile_path.exists():
            raw = json.loads(profile_path.read_text(encoding="utf-8"))
            if raw.get("schema") != "PH4NT0M5_MISSION_CONSEQUENCE_PROFILES_V1":
                raise MissionConsequenceError("MISSION_CONSEQUENCE_PROFILE_SCHEMA_INVALID")
            self.profiles = {str(k): frozenset(map(str, v)) for k, v in raw.get("families", {}).items()}
        self.registry = RunActorRegistry(session)
        self.authority = StateAuthority(session, actor_registry=self.registry)
        self.adapter = SemanticCommitAdapter(session, self.registry)

    def _read(self, key):
        return self.session.kernel.read(Authority.COMMIT_KERNEL, Domain.RUNTIME_STATE, key)

    def _fact_to_proposal(self, candidate_id: str, fact: Mapping[str, object]) -> EffectProposal:
        ftype = str(fact.get("fact_type") or "")
        if ftype not in self.FACT_EFFECTS:
            raise MissionConsequenceError("MISSION_CONSEQUENCE_FACT_UNSUPPORTED")
        evidence_ref = str(fact.get("evidence_ref") or "")
        if not evidence_ref:
            raise MissionConsequenceError("MISSION_CONSEQUENCE_EVIDENCE_REQUIRED")
        if self._read(evidence_ref) is None:
            raise MissionConsequenceError("MISSION_CONSEQUENCE_EVIDENCE_NOT_FOUND")

        effect_type, domain = self.FACT_EFFECTS[ftype]
        target_ref = None
        if ftype == "WORLD_TIME_LOSS":
            seconds = fact.get("seconds")
            if isinstance(seconds, bool) or not isinstance(seconds, int) or seconds <= 0:
                raise MissionConsequenceError("MISSION_CONSEQUENCE_SECONDS_INVALID")
            payload = {"seconds": seconds}
        elif ftype == "RESOURCE_DELTA":
            owner_ref = str(fact.get("owner_ref") or "")
            resource_key = str(fact.get("resource_key") or "")
            delta = fact.get("delta")
            if not owner_ref or self._read(owner_ref) is None:
                raise MissionConsequenceError("MISSION_CONSEQUENCE_OWNER_NOT_FOUND")
            if not resource_key or isinstance(delta, bool) or not isinstance(delta, int) or delta == 0:
                raise MissionConsequenceError("MISSION_CONSEQUENCE_RESOURCE_INVALID")
            target_ref = owner_ref
            payload = {"owner_ref": owner_ref, "resource_key": resource_key, "delta": delta}
        elif ftype == "ACTOR_DAMAGE":
            actor_id = str(fact.get("actor_instance_id") or "")
            amount = fact.get("amount")
            damage_type = str(fact.get("damage_type") or "")
            if not actor_id:
                raise MissionConsequenceError("MISSION_CONSEQUENCE_ACTOR_REQUIRED")
            self.registry.get(actor_id)
            if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0 or not damage_type:
                raise MissionConsequenceError("MISSION_CONSEQUENCE_DAMAGE_INVALID")
            target_ref = actor_id
            payload = {"target_actor_instance_id": actor_id, "amount": amount, "damage_type": damage_type}
        elif ftype == "INFRASTRUCTURE_STATE_CHANGE":
            infrastructure_id = str(fact.get("infrastructure_id") or "")
            new_state = str(fact.get("new_state") or "")
            if self.catalog is None or infrastructure_id not in self.catalog.stage8_world.infrastructure:
                raise MissionConsequenceError("MISSION_CONSEQUENCE_INFRASTRUCTURE_NOT_FOUND")
            if new_state not in {"ACTIVE", "DEGRADED", "OFFLINE", "BLOCKED"}:
                raise MissionConsequenceError("MISSION_CONSEQUENCE_INFRASTRUCTURE_STATE_INVALID")
            target_ref = infrastructure_id
            payload = {"infrastructure_id": infrastructure_id, "new_state": new_state, "cause_ref": evidence_ref}
        else:
            site_id = str(fact.get("site_id") or "")
            delta = fact.get("delta")
            known_sites = {str(x.get("dungeon_id")) for x in getattr(self.catalog, "dungeons", ())} if self.catalog is not None else set()
            if not site_id or site_id not in known_sites:
                raise MissionConsequenceError("MISSION_CONSEQUENCE_ECOLOGY_SITE_NOT_FOUND")
            if isinstance(delta, bool) or not isinstance(delta, int) or delta == 0:
                raise MissionConsequenceError("MISSION_CONSEQUENCE_ECOLOGY_DELTA_INVALID")
            target_ref = site_id
            if ftype == "ECOLOGY_RESOURCE_DELTA":
                resource_key = str(fact.get("resource_key") or "")
                if not resource_key:
                    raise MissionConsequenceError("MISSION_CONSEQUENCE_ECOLOGY_RESOURCE_REQUIRED")
                payload = {"site_id": site_id, "resource_key": resource_key, "delta": delta, "cause_ref": evidence_ref}
            else:
                population_id = str(fact.get("population_id") or "")
                if not population_id or self.catalog is None or population_id not in set(self.catalog.creature_registry.ids()):
                    raise MissionConsequenceError("MISSION_CONSEQUENCE_ECOLOGY_POPULATION_NOT_FOUND")
                # A negative mission consequence may only affect a population that is already present.
                snap = Stage10CommitAdapter(self.session, dungeon_definitions=self.catalog.dungeons).view.snapshot()
                current = int(snap.ecology.get(site_id).populations.get(population_id, 0)) if site_id in snap.ecology else 0
                if delta < 0 and current <= 0:
                    raise MissionConsequenceError("MISSION_CONSEQUENCE_ECOLOGY_POPULATION_NOT_PRESENT")
                payload = {"site_id": site_id, "population_id": population_id, "delta": delta, "cause_ref": evidence_ref}

        digest = sha256(f"{candidate_id}|{evidence_ref}|{ftype}".encode()).hexdigest()[:20]
        return EffectProposal(
            effect_id=f"effect:mission:{digest}",
            run_uuid=self.session.identity.run_uuid,
            resolution_id=f"resolution:mission:{digest}",
            source_action_id=f"mission:{digest}",
            effect_type=effect_type,
            target_ref=target_ref,
            payload=payload,
            authority_domain=domain,
            expected_state_revision=self.session.store.revision,
        )

    def _validate_profile(self, candidate: Mapping[str, object], fact: Mapping[str, object]) -> None:
        ftype = str(fact.get("fact_type") or "")
        if ftype not in self.FACT_EFFECTS:
            raise MissionConsequenceError("MISSION_CONSEQUENCE_FACT_UNSUPPORTED")
        family = str(candidate.get("mission_family") or "")
        if not family:
            raise MissionConsequenceError("MISSION_CONSEQUENCE_FAMILY_REQUIRED")
        allowed = self.profiles.get(family)
        if allowed is None:
            raise MissionConsequenceError("MISSION_CONSEQUENCE_PROFILE_NOT_FOUND")
        if ftype not in allowed:
            raise MissionConsequenceError("MISSION_CONSEQUENCE_FACT_NOT_ALLOWED_FOR_FAMILY")

    def apply_fact(self, candidate_id: str, fact: Mapping[str, object]) -> AppliedMissionConsequence:
        candidate = self._read(candidate_id)
        if not isinstance(candidate, dict) or candidate.get("kind") != "mission_consequence_candidate":
            raise MissionConsequenceError("MISSION_CONSEQUENCE_CANDIDATE_REQUIRED")
        if candidate.get("run_uuid") != self.session.identity.run_uuid:
            raise MissionConsequenceError("MISSION_CONSEQUENCE_RUN_MISMATCH")
        if candidate.get("state") != "PROPOSED":
            raise MissionConsequenceError("MISSION_CONSEQUENCE_ALREADY_RESOLVED")
        self._validate_profile(candidate, fact)

        proposal = self._fact_to_proposal(candidate_id, fact)
        decision = self.authority.authorize(proposal)
        if decision.status != AuthorityStatus.ALLOW:
            raise MissionConsequenceError("MISSION_CONSEQUENCE_AUTHORITY_REJECTED:" + ",".join(decision.reason_codes))
        digest = proposal.effect_id.split(":")[-1]
        event_id = f"MISSION_CONSEQUENCE_APPLY:{digest}"
        if proposal.authority_domain == AuthorityDomain.REGION:
            if self.catalog is None:
                raise MissionConsequenceError("MISSION_CONSEQUENCE_CATALOG_REQUIRED")
            result = Stage8CommitAdapter(self.session, self.catalog.stage8_world).apply_many(
                (decision,), commit_id=f"commit:mission:{digest}", event_id=event_id)
        elif proposal.authority_domain == AuthorityDomain.ECOLOGY:
            if self.catalog is None:
                raise MissionConsequenceError("MISSION_CONSEQUENCE_CATALOG_REQUIRED")
            result = Stage10CommitAdapter(self.session, dungeon_definitions=self.catalog.dungeons).apply_many(
                (decision,), commit_id=f"commit:mission:{digest}", event_id=event_id)
        else:
            plan = self.adapter.prepare_many((decision,), commit_id=f"commit:mission:{digest}", event_id=event_id)
            result = self.adapter.commit(plan)
        if not isinstance(result, CommitRecord):
            raise MissionConsequenceError("MISSION_CONSEQUENCE_COMMIT_REJECTED")

        # Record provenance only after the authoritative semantic commit succeeded.
        updated = copy.deepcopy(candidate)
        updated["state"] = "APPLIED"
        updated["effects"] = [{
            "effect_id": proposal.effect_id,
            "effect_type": proposal.effect_type.value,
            "evidence_ref": str(fact["evidence_ref"]),
            "semantic_commit_revision": result.revision,
        }]
        updated["applied_fact"] = copy.deepcopy(dict(fact))
        record_event = event_id + ":record"
        mark = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            deltas=(Delta(Domain.RUNTIME_STATE, candidate_id, updated, Authority.RULE_KERNEL,
                          "MISSION_CONSEQUENCE_APPLIED", source_event_id=record_event,
                          provenance="MISSION_CONSEQUENCE_ROUTER"),),
            event_id=record_event,
            cause="MISSION_CONSEQUENCE_APPLIED",
            expected_state_revision=self.session.store.revision,
        ))
        if not isinstance(mark, CommitRecord):
            raise MissionConsequenceError("MISSION_CONSEQUENCE_RECORD_REJECTED")
        return AppliedMissionConsequence(candidate_id, proposal.effect_type.value, mark.revision)
