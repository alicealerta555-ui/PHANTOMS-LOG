from __future__ import annotations

from dataclasses import dataclass
from hashlib import blake2b
import json


@dataclass(frozen=True, slots=True)
class PopulationSurface:
    location_id: str
    region_id: str
    settlement_type: str
    density_factor_ppm: int
    presence_mix_ppm: dict[str, int]
    culture_mix_ppm: dict[str, int]
    occupation_bias: tuple[str, ...]
    household_bias: tuple[str, ...]
    public_mix: str

    def to_dict(self) -> dict:
        return {
            'location_id': self.location_id,
            'region_id': self.region_id,
            'settlement_type': self.settlement_type,
            'density_factor_ppm': self.density_factor_ppm,
            'presence_mix_ppm': dict(self.presence_mix_ppm),
            'culture_mix_ppm': dict(self.culture_mix_ppm),
            'occupation_bias': list(self.occupation_bias),
            'household_bias': list(self.household_bias),
            'public_mix': self.public_mix,
        }


class PopulationResolver:
    """Static priors + run-stable social assignments.

    Culture is social/cultural metadata only. This resolver never infers biological lineage,
    ancestry, species, or kinship from a name, role, clothing, location, or culture.
    """
    def __init__(self, catalog):
        self.catalog = catalog
        path = catalog.root/'content/full_version/population_settlement_tables.json'
        raw = json.loads(path.read_text(encoding='utf-8'))
        if raw.get('schema') != 'PH4NT0M5_POPULATION_SETTLEMENT_TABLES_V1':
            raise ValueError('POPULATION_SETTLEMENT_SCHEMA_INVALID')
        self.raw = raw

    @staticmethod
    def _u64(seed: str) -> int:
        return int.from_bytes(blake2b(seed.encode('utf-8'), digest_size=8).digest(), 'big')

    @classmethod
    def _weighted_pick(cls, weights: dict[str, int], seed: str) -> str:
        valid = [(k, int(v)) for k, v in weights.items() if int(v) > 0]
        if not valid:
            raise ValueError('POPULATION_WEIGHT_TABLE_EMPTY')
        total = sum(v for _, v in valid)
        n = cls._u64(seed) % total
        cursor = 0
        for key, weight in valid:
            cursor += weight
            if n < cursor:
                return key
        return valid[-1][0]

    def location_surface(self, location_id: str) -> PopulationSurface:
        try:
            p = self.raw['location_profiles'][location_id]
        except KeyError as exc:
            raise ValueError('POPULATION_LOCATION_UNKNOWN:'+str(location_id)) from exc
        return PopulationSurface(
            location_id=location_id,
            region_id=str(p['region_id']),
            settlement_type=str(p['settlement_type']),
            density_factor_ppm=int(p['density_factor_ppm']),
            presence_mix_ppm={str(k):int(v) for k,v in p['presence_mix_ppm'].items()},
            culture_mix_ppm={str(k):int(v) for k,v in p['culture_mix_ppm'].items()},
            occupation_bias=tuple(str(x) for x in p.get('occupation_bias',())),
            household_bias=tuple(str(x) for x in p.get('household_bias',())),
            public_mix=str(p.get('public_mix','')),
        )

    def assign_npc(self, *, npc_id: str, role: str, home_location_id: str, run_uuid: str) -> dict:
        loc = self.location_surface(home_location_id)
        region = self.raw['region_profiles'][loc.region_id]
        mobility = self._weighted_pick(region['mobility_modes_ppm'], f'{run_uuid}|{npc_id}|mobility')
        household = self._weighted_pick(region['household_mix_ppm'], f'{run_uuid}|{npc_id}|household')
        culture = self._weighted_pick(loc.culture_mix_ppm, f'{run_uuid}|{npc_id}|culture')
        traveler_origin = loc.region_id
        if mobility in {'trader_traveler','transient','migrant_newcomer','regional_commuter'}:
            traveler_origin = self._weighted_pick(
                self.raw['traveler_origin_matrix_ppm'][loc.region_id],
                f'{run_uuid}|{npc_id}|origin'
            )
        household_bucket = self._u64(f'{run_uuid}|{home_location_id}|{household}|{npc_id}|household_ref') % 7
        household_ref = f'household:{home_location_id.rsplit(":",1)[-1]}:{household}:{household_bucket:02d}'
        return {
            'culture_id': culture,
            'mobility_type': mobility,
            'mobility_label': self.raw['mobility_types'][mobility]['label'],
            'household_type': household,
            'household_label': self.raw['household_types'][household]['label'],
            'household_ref': household_ref,
            'home_region_id': loc.region_id,
            'origin_region_id': traveler_origin,
            'occupation_type': role if role in self.raw['occupation_types'] else 'service_worker',
            'settlement_type': loc.settlement_type,
            'public_mix': loc.public_mix,
        }

    def population_summary(self, location_id: str) -> dict:
        loc = self.location_surface(location_id)
        region = self.raw['region_profiles'][loc.region_id]
        return {
            **loc.to_dict(),
            'region_label': region['label'],
            'region_settlement_archetype': region['settlement_archetype'],
            'population_density': region['population_density'],
            'region_occupation_mix_ppm': dict(region['occupation_mix_ppm']),
            'region_household_mix_ppm': dict(region['household_mix_ppm']),
            'region_mobility_mix_ppm': dict(region['mobility_modes_ppm']),
            'expected_present_band': list(self.raw['location_profiles'][location_id].get('expected_present_band',())),
            'population_signal': str(self.raw['location_profiles'][location_id].get('population_signal','')),
        }
