from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
import copy

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal, ValidationResult, Verdict
from runtime.stage9.world_time import WORLD_TIME_RUNTIME_KEY, WorldClock
from runtime.full_version.bootstrap import PLAYER_ACTOR_INSTANCE_ID
from runtime.stage9.actor_context import ACTOR_VISIBLE_RUNTIME_KEY
from runtime.full_version.capability_runtime import assess_action, deterministic_uncertain_success

class CraftRepairError(RuntimeError): pass

@dataclass(frozen=True,slots=True)
class CraftRepairResult:
    outcome: str
    output_instance_id: str|None
    target_instance_id: str|None
    seconds: int
    capability_zone: str = "SAFE"
    capability_explanation: str = ""
    capability_roll: int|None = None
    capability_target: int|None = None

class CraftRepairRuntime:
    def __init__(self,catalog,session): self.catalog=catalog; self.session=session

    def _actor(self,actor_id):
        rec=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,actor_id)
        if not isinstance(rec,dict): raise CraftRepairError('CRAFT_ACTOR_MISSING')
        return rec

    def _inventory(self,actor_id):
        out=[]; prefix='inventory:'+actor_id
        for key in self.session.store.runtime_state:
            if not str(key).startswith('item:'): continue
            rec=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
            if isinstance(rec,dict) and rec.get('location_ref')==prefix: out.append((key,rec))
        return out

    def _capability(self, actor, spec, *, action: str, seed: str):
        skill=str(spec.get('required_skill','SKILL_TECHNOLOGY')).upper()
        difficulty=int(spec.get('difficulty',0))
        tags={'craft':('craft','fertigen','herstellen'),'repair':('repair','reparatur','maschinen','wartung'),'treat':('treat','behandlung','medizin')}.get(action,(action,)) + (skill.replace('SKILL_','').lower(),)
        cap=assess_action(actor,skill,difficulty,context_tags=tags)
        if cap.blocked:
            raise CraftRepairError(f"{action.upper()}_CAPABILITY_BLOCKED:{cap.zone.value}:{cap.failure_stage or ''}:{cap.explanation}")
        ok,roll,target=deterministic_uncertain_success(cap,seed)
        if not ok:
            raise CraftRepairError(f"{action.upper()}_CAPABILITY_CHECK_FAILED:{cap.zone.value}:{roll}/{target}:{cap.explanation}")
        return cap,roll,target

    def craft(self,operation_id:str,actor_id:str=PLAYER_ACTOR_INSTANCE_ID)->CraftRepairResult:
        op=self.catalog.operation(operation_id)
        spec=self.catalog.playable_operations['craft'].get(operation_id)
        if op['kind']!='craft' or not spec: raise CraftRepairError('CRAFT_OPERATION_REQUIRED')
        actor=self._actor(actor_id)
        inv=self._inventory(actor_id); used=[]
        for needed in op['inputs']:
            hit=next(((iid,r) for iid,r in inv if r.get('item_definition_id')==needed and iid not in {x[0] for x in used}),None)
            if not hit: raise CraftRepairError('CRAFT_INPUT_MISSING:'+needed)
            used.append(hit)
        cap,cap_roll,cap_target=self._capability(actor,spec,action='craft',seed=f'{self.session.identity.run_uuid}|craft|{operation_id}|{self.session.store.revision}')
        event=f'CRAFT:{self.session.identity.run_uuid}:{operation_id}:{self.session.store.revision}'
        deltas=[]
        for iid,rec in used:
            updated=copy.deepcopy(rec); updated['location_ref']='consumed:'+event; updated.pop('owner_actor_instance_id',None); updated['consumed_by_operation']=operation_id
            deltas.append(Delta(Domain.RUNTIME_STATE,iid,updated,Authority.RULE_KERNEL,'PLAYABLE_CRAFT_CONSUME',source_event_id=event,provenance='CRAFT_OPERATION'))
        output_def=spec['output_item_definition_id']; outid='item:crafted:'+sha256(event.encode()).hexdigest()[:20]
        outrec={'run_uuid':self.session.identity.run_uuid,'kind':'item','item_definition_id':output_def,'location_ref':'inventory:'+actor_id,'owner_actor_instance_id':actor_id,'condition':100,'max_condition':100,'provenance':'CRAFT_OPERATION','operation_id':operation_id,'input_sources':[x[0] for x in used]}
        deltas.append(Delta(Domain.RUNTIME_STATE,outid,outrec,Authority.RULE_KERNEL,'PLAYABLE_CRAFT_OUTPUT',source_event_id=event,provenance='CRAFT_OPERATION'))
        before=WorldClock(self.session).seconds; seconds=int(op['world_time_cost'])
        deltas.append(Delta(Domain.RUNTIME_STATE,WORLD_TIME_RUNTIME_KEY,{'run_uuid':self.session.identity.run_uuid,'seconds':before+seconds},Authority.WORLD_TIME,'STAGE9_ADVANCE_WORLD_TIME',source_event_id=event,provenance='CRAFT_OPERATION'))
        result=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=tuple(deltas),event_id=event,cause='PLAYABLE_CRAFT',expected_state_revision=self.session.store.revision))
        if not isinstance(result,CommitRecord): raise CraftRepairError('CRAFT_COMMIT_REJECTED:'+','.join(getattr(result,'reasons',())))
        return CraftRepairResult('CRAFT_OK',outid,None,seconds,cap.zone.value,cap.explanation,cap_roll,cap_target)

    def repair(self,operation_id:str,target_id:str,actor_id:str=PLAYER_ACTOR_INSTANCE_ID)->CraftRepairResult:
        op=self.catalog.operation(operation_id); spec=self.catalog.playable_operations['repair'].get(operation_id)
        if op['kind']!='repair' or not spec: raise CraftRepairError('REPAIR_OPERATION_REQUIRED')
        actor=self._actor(actor_id)
        inv=dict(self._inventory(actor_id)); target=inv.get(target_id)
        if not isinstance(target,dict): raise CraftRepairError('REPAIR_TARGET_NOT_OWNED')
        current=int(target.get('condition',100)); maximum=int(target.get('max_condition',100))
        if current>=maximum: raise CraftRepairError('REPAIR_NOT_NEEDED')
        used=[]
        for needed in op['inputs']:
            hit=next(((iid,r) for iid,r in inv.items() if r.get('item_definition_id')==needed and iid!=target_id and iid not in {x[0] for x in used}),None)
            if not hit: raise CraftRepairError('REPAIR_INPUT_MISSING:'+needed)
            used.append(hit)
        cap,cap_roll,cap_target=self._capability(actor,spec,action='repair',seed=f'{self.session.identity.run_uuid}|repair|{operation_id}|{target_id}|{self.session.store.revision}')
        event=f'REPAIR:{self.session.identity.run_uuid}:{operation_id}:{target_id}:{self.session.store.revision}'
        deltas=[]
        for iid,rec in used:
            updated=copy.deepcopy(rec); updated['location_ref']='consumed:'+event; updated.pop('owner_actor_instance_id',None); updated['consumed_by_operation']=operation_id
            deltas.append(Delta(Domain.RUNTIME_STATE,iid,updated,Authority.RULE_KERNEL,'PLAYABLE_REPAIR_CONSUME',source_event_id=event,provenance='REPAIR_OPERATION'))
        fixed=copy.deepcopy(target); fixed['condition']=min(maximum,current+int(spec['restore'])); fixed['last_repair_operation']=operation_id
        deltas.append(Delta(Domain.RUNTIME_STATE,target_id,fixed,Authority.RULE_KERNEL,'PLAYABLE_REPAIR_TARGET',source_event_id=event,provenance='REPAIR_OPERATION'))
        before=WorldClock(self.session).seconds; seconds=int(op['world_time_cost'])
        deltas.append(Delta(Domain.RUNTIME_STATE,WORLD_TIME_RUNTIME_KEY,{'run_uuid':self.session.identity.run_uuid,'seconds':before+seconds},Authority.WORLD_TIME,'STAGE9_ADVANCE_WORLD_TIME',source_event_id=event,provenance='REPAIR_OPERATION'))
        result=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=tuple(deltas),event_id=event,cause='PLAYABLE_REPAIR',expected_state_revision=self.session.store.revision))
        if not isinstance(result,CommitRecord): raise CraftRepairError('REPAIR_COMMIT_REJECTED:'+','.join(getattr(result,'reasons',())))
        return CraftRepairResult('REPAIR_OK',None,target_id,seconds,cap.zone.value,cap.explanation,cap_roll,cap_target)
    def treat(self,operation_id:str,target_actor_id:str=PLAYER_ACTOR_INSTANCE_ID,actor_id:str=PLAYER_ACTOR_INSTANCE_ID)->CraftRepairResult:
        op=self.catalog.operation(operation_id); spec=self.catalog.playable_operations.get('treat',{}).get(operation_id)
        if op['kind']!='treat' or not spec: raise CraftRepairError('TREAT_OPERATION_REQUIRED')
        actor=self._actor(actor_id); target=self._actor(target_actor_id)
        if target_actor_id!=actor_id and target.get('location_ref')!=actor.get('location_ref'): raise CraftRepairError('TREAT_TARGET_NOT_PRESENT')
        hp=int(target.get('hp',0)); maximum=int(target.get('max_hp',hp))
        if hp>=maximum: raise CraftRepairError('TREAT_NOT_NEEDED')
        inv=self._inventory(actor_id); used=[]
        for needed in op['inputs']:
            hit=next(((iid,r) for iid,r in inv if r.get('item_definition_id')==needed and iid not in {x[0] for x in used}),None)
            if not hit: raise CraftRepairError('TREAT_INPUT_MISSING:'+needed)
            used.append(hit)
        cap,cap_roll,cap_target=self._capability(actor,spec,action='treat',seed=f'{self.session.identity.run_uuid}|treat|{operation_id}|{target_actor_id}|{self.session.store.revision}')
        event=f'TREAT:{self.session.identity.run_uuid}:{operation_id}:{target_actor_id}:{self.session.store.revision}'
        deltas=[]
        for iid,rec in used:
            updated=copy.deepcopy(rec); updated['location_ref']='consumed:'+event; updated.pop('owner_actor_instance_id',None); updated['consumed_by_operation']=operation_id
            deltas.append(Delta(Domain.RUNTIME_STATE,iid,updated,Authority.RULE_KERNEL,'PLAYABLE_TREAT_CONSUME',source_event_id=event,provenance='TREAT_OPERATION'))
        healed=copy.deepcopy(target); healed['hp']=min(maximum,hp+int(spec['heal'])); healed['last_treat_operation']=operation_id
        deltas.append(Delta(Domain.RUNTIME_STATE,target_actor_id,healed,Authority.RULE_KERNEL,'PLAYABLE_TREAT_TARGET',source_event_id=event,provenance='TREAT_OPERATION'))
        visible=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,ACTOR_VISIBLE_RUNTIME_KEY)
        if isinstance(visible,dict) and target_actor_id in visible.get('actors',{}):
            visible=copy.deepcopy(visible); visible['actors'][target_actor_id]['health_state']=f"hp:{healed['hp']}/{maximum}"
            deltas.append(Delta(Domain.RUNTIME_STATE,ACTOR_VISIBLE_RUNTIME_KEY,visible,Authority.RULE_KERNEL,'PLAYABLE_TREAT_VISIBLE',source_event_id=event,provenance='TREAT_OPERATION'))
        before=WorldClock(self.session).seconds; seconds=int(op['world_time_cost'])
        deltas.append(Delta(Domain.RUNTIME_STATE,WORLD_TIME_RUNTIME_KEY,{'run_uuid':self.session.identity.run_uuid,'seconds':before+seconds},Authority.WORLD_TIME,'STAGE9_ADVANCE_WORLD_TIME',source_event_id=event,provenance='TREAT_OPERATION'))
        result=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=tuple(deltas),event_id=event,cause='PLAYABLE_TREAT',expected_state_revision=self.session.store.revision))
        if not isinstance(result,CommitRecord): raise CraftRepairError('TREAT_COMMIT_REJECTED:'+','.join(getattr(result,'reasons',())))
        return CraftRepairResult('TREAT_OK',None,target_actor_id,seconds,cap.zone.value,cap.explanation,cap_roll,cap_target)

