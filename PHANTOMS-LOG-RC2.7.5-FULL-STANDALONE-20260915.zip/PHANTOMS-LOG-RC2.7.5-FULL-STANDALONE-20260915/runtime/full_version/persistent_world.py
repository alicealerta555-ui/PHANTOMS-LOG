from __future__ import annotations

import copy
import json
from hashlib import blake2b

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage9.world_time import WorldClock
from runtime.stage9.actor_context import ACTOR_VISIBLE_RUNTIME_KEY

PERSISTENT_WORLD_STATE_KEY = "__persistent_world_consequences__"


class PersistentWorldError(RuntimeError):
    pass


def _h(text: str) -> int:
    return int.from_bytes(blake2b(text.encode("utf-8"), digest_size=8).digest(), "big")


class PersistentWorldRuntime:
    """Persistent consequences that outlive a scene or dynamic-event presentation.

    This runtime deliberately separates canonical state (damage/death/environment drift)
    from narration.  Every mutation is run-scoped and committed through CommitKernel.
    """

    def __init__(self, catalog, session):
        self.catalog = catalog
        self.session = session
        self.cfg = json.loads((catalog.root / "content/full_version/persistent_world_consequence_tables.json").read_text(encoding="utf-8"))
        if self.cfg.get("schema") != "PH4NT0M5_PERSISTENT_WORLD_CONSEQUENCES_V1":
            raise PersistentWorldError("PERSISTENT_WORLD_SCHEMA_INVALID")

    def _state(self) -> dict:
        raw = self.session.kernel.read(Authority.COMMIT_KERNEL, Domain.RUNTIME_STATE, PERSISTENT_WORLD_STATE_KEY)
        if raw is None:
            return {
                "run_uuid": self.session.identity.run_uuid,
                "processed_events": {},
                "infrastructure": {},
                "corpses": {},
                "dynamic_quest_seeds": {},
                "environment": {},
            }
        if not isinstance(raw, dict) or raw.get("run_uuid") != self.session.identity.run_uuid:
            raise PersistentWorldError("PERSISTENT_WORLD_RUN_MISMATCH")
        return copy.deepcopy(raw)

    def _commit(self, state: dict, cause: str, extra_deltas=(), *, event_id: str | None = None):
        event = event_id or f"{cause}:{WorldClock(self.session).seconds}:{self.session.store.revision}"
        deltas = list(extra_deltas)
        deltas.append(Delta(
            Domain.RUNTIME_STATE, PERSISTENT_WORLD_STATE_KEY, state,
            Authority.RULE_KERNEL, cause, source_event_id=event,
            provenance="PERSISTENT_WORLD_CONSEQUENCES",
        ))
        result = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, deltas=tuple(deltas),
            event_id=event, cause=cause, expected_state_revision=self.session.store.revision,
        ))
        if not isinstance(result, CommitRecord):
            raise PersistentWorldError(cause + "_COMMIT_REJECTED")
        return result

    def _infra_state_name(self, integrity: int) -> str:
        n = max(0, min(100, int(integrity)))
        for threshold, name in self.cfg["infrastructure"]["state_thresholds"]:
            if n >= int(threshold):
                return str(name)
        return "DESTROYED"

    def infrastructure(self, location_id: str) -> dict:
        self.catalog.location(location_id)
        state = self._state()
        rec = state["infrastructure"].get(location_id)
        if not isinstance(rec, dict):
            integrity = int(self.cfg["infrastructure"]["initial_integrity"])
            return {
                "location_id": location_id,
                "integrity": integrity,
                "state": self._infra_state_name(integrity),
                "last_changed_at": 0,
                "damage_history": [],
                "rebuild_history": [],
            }
        return copy.deepcopy(rec)

    def _ensure_infra(self, state: dict, location_id: str) -> dict:
        rec = state["infrastructure"].get(location_id)
        if not isinstance(rec, dict):
            rec = self.infrastructure(location_id)
            state["infrastructure"][location_id] = rec
        return rec

    def damage_infrastructure(self, location_id: str, amount: int, *, source_event_id: str, cause: str) -> dict:
        if int(amount) <= 0:
            return self.infrastructure(location_id)
        state = self._state()
        rec = self._ensure_infra(state, location_id)
        before = int(rec["integrity"])
        after = max(0, before - int(amount))
        if after == before:
            return copy.deepcopy(rec)
        now = WorldClock(self.session).seconds
        rec["integrity"] = after
        rec["state"] = self._infra_state_name(after)
        rec["last_changed_at"] = now
        rec.setdefault("damage_history", []).append({
            "source_event_id": str(source_event_id), "cause": str(cause),
            "at": now, "amount": int(amount), "before": before, "after": after,
        })
        self._commit(state, "PERSISTENT_INFRASTRUCTURE_DAMAGE")
        return copy.deepcopy(rec)

    def rebuild_infrastructure(self, location_id: str, amount: int, *, source_id: str, method: str) -> dict:
        if int(amount) <= 0:
            return self.infrastructure(location_id)
        state = self._state()
        rec = self._ensure_infra(state, location_id)
        before = int(rec["integrity"])
        after = min(100, before + int(amount))
        if after == before:
            return copy.deepcopy(rec)
        now = WorldClock(self.session).seconds
        rec["integrity"] = after
        rec["state"] = self._infra_state_name(after)
        rec["last_changed_at"] = now
        rec.setdefault("rebuild_history", []).append({
            "source_id": str(source_id), "method": str(method), "at": now,
            "amount": int(amount), "before": before, "after": after,
        })
        self._commit(state, "PERSISTENT_INFRASTRUCTURE_REBUILD")
        return copy.deepcopy(rec)

    def corpses_at(self, location_id: str, *, include_expired: bool = False) -> tuple[dict, ...]:
        now = WorldClock(self.session).seconds
        ttl = int(self.cfg["offscreen_mortality"]["corpse_persistence_seconds"])
        out = []
        for rec in self._state()["corpses"].values():
            if rec.get("location_id") != location_id:
                continue
            if not include_expired and now - int(rec.get("death_world_time", now)) > ttl:
                continue
            out.append(copy.deepcopy(rec))
        return tuple(sorted(out, key=lambda x: (int(x.get("death_world_time", 0)), str(x.get("corpse_id", "")))))

    def mark_corpse_discovered(self, corpse_id: str, *, actor_id: str) -> dict | None:
        state = self._state()
        rec = state["corpses"].get(str(corpse_id))
        if not isinstance(rec, dict):
            return None
        found = rec.setdefault("discovered_by", [])
        if actor_id not in found:
            found.append(actor_id)
            rec["discovered_at"] = WorldClock(self.session).seconds
            self._commit(state, "CORPSE_DISCOVERY")
        return copy.deepcopy(rec)

    def investigate_corpse(self, corpse_id: str, *, actor_id: str) -> dict:
        state = self._state()
        rec = state["corpses"].get(str(corpse_id))
        if not isinstance(rec, dict):
            raise PersistentWorldError("CORPSE_UNKNOWN")
        rec.setdefault("discovered_by", [])
        if actor_id not in rec["discovered_by"]:
            rec["discovered_by"].append(actor_id)
        rec.setdefault("investigated_by", [])
        if actor_id not in rec["investigated_by"]:
            rec["investigated_by"].append(actor_id)
            rec["investigated_at"] = WorldClock(self.session).seconds
            self._commit(state, "CORPSE_INVESTIGATION")
        return copy.deepcopy(rec)

    def dynamic_quest_seeds(self, *, location_id: str | None = None) -> tuple[dict, ...]:
        vals = []
        for rec in self._state()["dynamic_quest_seeds"].values():
            if location_id is not None and rec.get("location_id") != location_id:
                continue
            vals.append(copy.deepcopy(rec))
        return tuple(sorted(vals, key=lambda x: str(x.get("seed_id", ""))))

    def mark_quest_seed_materialized(self, seed_id: str, quest_id: str) -> None:
        state = self._state()
        rec = state["dynamic_quest_seeds"].get(seed_id)
        if not isinstance(rec, dict) or rec.get("quest_instance_id") == quest_id:
            return
        rec["quest_instance_id"] = quest_id
        rec["materialized_at"] = WorldClock(self.session).seconds
        self._commit(state, "DYNAMIC_QUEST_SEED_MATERIALIZED")

    def _seed(self, state: dict, *, seed_id: str, kind: str, location_id: str, source_id: str, payload: dict) -> None:
        if seed_id in state["dynamic_quest_seeds"]:
            return
        state["dynamic_quest_seeds"][seed_id] = {
            "seed_id": seed_id, "kind": kind, "location_id": location_id,
            "source_id": source_id, "created_at": WorldClock(self.session).seconds,
            "quest_instance_id": None, "payload": copy.deepcopy(payload),
        }

    def _kill_named_npc(self, state: dict, npc_id: str, npc: dict, *, event: dict) -> bool:
        if npc.get("life_state") == "DEAD" or int(npc.get("hp", 1)) <= 0:
            return False
        corpse_id = "corpse:" + blake2b(f"{self.session.identity.run_uuid}|{event['event_id']}|{npc_id}".encode(), digest_size=10).hexdigest()
        if corpse_id in state["corpses"]:
            return False
        dead = copy.deepcopy(npc)
        dead["hp"] = 0
        dead["life_state"] = "DEAD"
        dead["death_world_time"] = WorldClock(self.session).seconds
        dead["death_event_id"] = event["event_id"]
        corpse = {
            "corpse_id": corpse_id, "npc_actor_id": npc_id,
            "display_name": str(npc.get("display_name", npc_id)),
            "location_id": str(npc.get("location_ref")),
            "death_world_time": WorldClock(self.session).seconds,
            "cause_event_id": str(event["event_id"]),
            "cause_event_type": str(event["event_type"]),
            "discovered_by": [], "investigated_by": [],
        }
        state["corpses"][corpse_id] = corpse
        if self.cfg["dynamic_quests"].get("corpse_investigation", True):
            self._seed(
                state, seed_id="quest_seed:corpse:" + corpse_id.split(":", 1)[1],
                kind="CORPSE_INVESTIGATION", location_id=corpse["location_id"],
                source_id=corpse_id, payload={"corpse_id": corpse_id, "npc_actor_id": npc_id},
            )
        event_id = f"OFFSCREEN_NPC_DEATH:{event['event_id']}:{npc_id}"
        deltas=[Delta(
            Domain.RUNTIME_STATE, npc_id, dead, Authority.RULE_KERNEL,
            "OFFSCREEN_NPC_DEATH", source_event_id=event_id,
            provenance="PERSISTENT_WORLD_CONSEQUENCES",
        )]
        visible=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,ACTOR_VISIBLE_RUNTIME_KEY)
        if isinstance(visible,dict) and npc_id in (visible.get('actors') or {}):
            visible=copy.deepcopy(visible); visible.get('actors',{}).pop(npc_id,None)
            deltas.append(Delta(Domain.RUNTIME_STATE,ACTOR_VISIBLE_RUNTIME_KEY,visible,Authority.RULE_KERNEL,
                "OFFSCREEN_NPC_DEATH_VISIBLE_REMOVE",source_event_id=event_id,provenance="PERSISTENT_WORLD_CONSEQUENCES"))
        self._commit(state, "OFFSCREEN_NPC_DEATH", extra_deltas=tuple(deltas), event_id=event_id)
        return True

    def sync_from_dynamic_events(self, events: dict, *, actors_by_location: dict[str, list[tuple[str, dict]]]) -> dict:
        """Apply persistent consequences once per event, idempotently.

        Named-NPC mortality is deliberately conservative: only real persistent NPCs
        physically present at the event location are candidates, and only event types
        with an explicit risk can kill them.
        """
        state = self._state()
        processed = state["processed_events"]
        changes = {"damaged": [], "deaths": [], "quest_seeds": []}
        infra_cfg = self.cfg["infrastructure"]
        mort_cfg = self.cfg["offscreen_mortality"]
        now = WorldClock(self.session).seconds
        dirty = False
        death_committed = False
        for eid, event in sorted(events.items()):
            if not isinstance(event, dict) or event.get("status") not in {"ACTIVE", "AFTERMATH", "EXPIRED"}:
                continue
            marker = processed.setdefault(eid, {})
            loc = str(event.get("location_id", ""))
            etype = str(event.get("event_type", ""))
            if not marker.get("persistent_damage_applied"):
                amount = max(0, int(infra_cfg.get("event_damage", {}).get(etype, 0)))
                if amount:
                    rec = self._ensure_infra(state, loc)
                    before = int(rec["integrity"]); after = max(0, before - amount)
                    rec["integrity"] = after; rec["state"] = self._infra_state_name(after); rec["last_changed_at"] = now
                    rec.setdefault("damage_history", []).append({
                        "source_event_id": eid, "cause": etype, "at": now,
                        "amount": amount, "before": before, "after": after,
                    })
                    changes["damaged"].append({"location_id": loc, "before": before, "after": after, "state": rec["state"]})
                    if rec["state"] in set(self.cfg["dynamic_quests"]["rebuild_states"]):
                        seed_id = "quest_seed:rebuild:" + blake2b(f"{self.session.identity.run_uuid}|{loc}|{eid}".encode(), digest_size=10).hexdigest()
                        self._seed(state, seed_id=seed_id, kind="REBUILD", location_id=loc, source_id=eid,
                                   payload={"source_event_id": eid, "infrastructure_state": rec["state"]})
                marker["persistent_damage_applied"] = True; dirty = True
            if not marker.get("mortality_resolved"):
                risk = max(0, min(1_000_000, int(mort_cfg.get("event_risk_ppm", {}).get(etype, 0))))
                candidates = [(nid, n) for nid, n in actors_by_location.get(loc, []) if isinstance(n, dict) and n.get("life_state") != "DEAD" and int(n.get("hp", 1)) > 0]
                deaths = 0
                if risk > 0:
                    for nid, npc in sorted(candidates):
                        if deaths >= int(mort_cfg.get("max_named_npc_deaths_per_event", 1)):
                            break
                        roll = _h(f"{self.session.identity.run_uuid}|{eid}|{nid}|mortality") % 1_000_000
                        if roll < risk:
                            # Commit immediately so the actor mutation and corpse record are atomic.
                            state["processed_events"][eid]["mortality_resolved"] = True
                            if dirty:
                                self._commit(state, "PERSISTENT_EVENT_CONSEQUENCE_SYNC")
                                state = self._state(); dirty = False
                            if self._kill_named_npc(state, nid, npc, event=event):
                                changes["deaths"].append(nid); deaths += 1; death_committed = True
                                state = self._state()
                            break
                state["processed_events"].setdefault(eid, {})["mortality_resolved"] = True
                dirty = True
            if str(event.get("severity")) in set(self.cfg["dynamic_quests"]["investigation_event_severities"]):
                seed_id = "quest_seed:event:" + blake2b(f"{self.session.identity.run_uuid}|{eid}".encode(), digest_size=10).hexdigest()
                before_n = len(state["dynamic_quest_seeds"])
                self._seed(state, seed_id=seed_id, kind="EVENT_INVESTIGATION", location_id=loc, source_id=eid,
                           payload={"event_id": eid, "event_type": etype, "severity": event.get("severity")})
                if len(state["dynamic_quest_seeds"]) != before_n:
                    changes["quest_seeds"].append(seed_id); dirty = True
        if dirty:
            self._commit(state, "PERSISTENT_EVENT_CONSEQUENCE_SYNC")
        return changes

    def npc_rebuild_tick(self, *, elapsed_seconds: int, living_actors_by_location: dict[str, list[tuple[str, dict]]], service_capacity_by_location: dict[str, int]) -> list[dict]:
        if elapsed_seconds <= 0:
            return []
        state = self._state(); cfg = self.cfg["infrastructure"]["npc_rebuild"]
        roles = set(cfg["eligible_roles"]); now = WorldClock(self.session).seconds; changed=[]; dirty=False
        for loc, rec in sorted(state["infrastructure"].items()):
            if int(rec.get("integrity", 100)) >= 100:
                continue
            if now - int(rec.get("last_changed_at", now)) < int(cfg["minimum_delay_seconds"]):
                continue
            service = int(service_capacity_by_location.get(loc, 1_000_000))
            if service < int(cfg["service_capacity_floor_ppm"]):
                continue
            workers = [nid for nid, npc in living_actors_by_location.get(loc, []) if str(npc.get("role", "")) in roles]
            if not workers:
                continue
            rate = int(cfg["destroyed_integrity_per_worker_hour"] if rec.get("state") == "DESTROYED" else cfg["integrity_per_worker_hour"])
            raw = (len(workers) * rate * int(elapsed_seconds) * service) // (3600 * 1_000_000)
            gain = min(int(cfg["max_integrity_per_pulse"]), max(0, raw))
            if gain <= 0:
                continue
            before=int(rec["integrity"]); after=min(100,before+gain)
            rec["integrity"]=after; rec["state"]=self._infra_state_name(after); rec["last_changed_at"]=now
            rec.setdefault("rebuild_history",[]).append({"source_id":workers[0],"method":"NPC_REBUILD","at":now,"amount":gain,"before":before,"after":after})
            changed.append({"location_id":loc,"before":before,"after":after,"workers":tuple(workers)}); dirty=True
        if dirty:
            self._commit(state,"NPC_INFRASTRUCTURE_REBUILD")
        return changed

    def apply_environment_shift(self, region_id: str, *, cause_id: str, elapsed_seconds: int, ecology_delta_ppm: int = 0, climate_offset_millic: int = 0) -> dict:
        """Rate-limited long-term change: stable worlds do not drift without a cause."""
        cfg = self.cfg["environment_stability"]
        if cfg.get("requires_explicit_cause") and not str(cause_id):
            raise PersistentWorldError("ENVIRONMENT_CAUSE_REQUIRED")
        if int(elapsed_seconds) < int(cfg["minimum_causal_duration_seconds"]):
            raise PersistentWorldError("ENVIRONMENT_CAUSAL_DURATION_TOO_SHORT")
        state=self._state(); rec=state["environment"].setdefault(str(region_id),{"ecology_shift_ppm":0,"climate_offset_millic":0,"history":[]})
        eco_cap=(int(cfg["max_ecology_shift_ppm_per_30_days"])*int(elapsed_seconds))//(30*86400)
        climate_cap=(int(cfg["max_climate_offset_millic_per_365_days"])*int(elapsed_seconds))//(365*86400)
        eco=max(-eco_cap,min(eco_cap,int(ecology_delta_ppm))); clim=max(-climate_cap,min(climate_cap,int(climate_offset_millic)))
        rec["ecology_shift_ppm"] += eco; rec["climate_offset_millic"] += clim
        rec["history"].append({"cause_id":str(cause_id),"elapsed_seconds":int(elapsed_seconds),"ecology_delta_ppm":eco,"climate_offset_millic":clim,"at":WorldClock(self.session).seconds})
        self._commit(state,"LONG_TERM_ENVIRONMENT_SHIFT")
        return copy.deepcopy(rec)
