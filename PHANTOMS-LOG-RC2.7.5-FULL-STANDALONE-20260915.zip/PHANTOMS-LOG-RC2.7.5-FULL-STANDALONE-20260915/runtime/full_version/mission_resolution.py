from __future__ import annotations
import json
from dataclasses import dataclass
from hashlib import sha256
from runtime.full_version.capability_runtime import assess_action, opposed_zone_modifier

class MissionResolutionError(RuntimeError): pass

@dataclass(frozen=True, slots=True)
class MissionResolution:
    outcome: str
    score: float
    difficulty: float
    roll: int
    primary_skill: str
    primary_value: int

class MissionResolver:
    OUTCOMES=("FULL_SUCCESS","SUCCESS_WITH_COST","PARTIAL_SUCCESS","FAILURE","CRITICAL_FAILURE")
    def __init__(self,catalog):
        raw=json.loads((catalog.root/'content/full_version/mission_resolution_policy.json').read_text(encoding='utf-8'))
        if raw.get('schema')!='PH4NT0M5_MISSION_RESOLUTION_POLICY_V1': raise MissionResolutionError('MISSION_RESOLUTION_SCHEMA_INVALID')
        self.policy=raw; self.families=raw['families']

    def resolve(self, *, actor: dict, mission_family: str, difficulty: int=5, attempt_no: int=1,
                equipment_bonus: int=0, preparation_bonus: int=0, crew_bonus: int=0,
                situation_modifier: int=0, danger: int=0, time_pressure: int=0, seed: str='') -> MissionResolution:
        fam=str(mission_family)
        skills=self.families.get(fam)
        if not skills: raise MissionResolutionError('MISSION_FAMILY_UNSUPPORTED')
        # All effective capability reads go through the canonical capability bridge.
        # Mission family changes which skills are useful, never whether the mission is accessible.
        assessed=[]
        for skill_id in skills:
            cap=assess_action(actor,skill_id,int(difficulty),context_tags=('mission',fam.casefold()),tool_bonus=int(equipment_bonus)+int(preparation_bonus),opposition_penalty=int(danger)+int(time_pressure))
            assessed.append((skill_id,opposed_zone_modifier(cap),cap))
        assessed.sort(key=lambda x:(x[1],x[0]),reverse=True)
        primary, zone_mod, primary_cap=assessed[0]
        pv=zone_mod
        support=sum(max(-4,m) for _,m,_ in assessed[1:])/max(1,len(assessed)-1)
        capability=5.0 + zone_mod + 0.25*support + int(crew_bonus)+int(situation_modifier)
        target=5.0 + 0.25*int(danger) + 0.25*int(time_pressure)
        h=sha256(f'{seed}|{fam}|{attempt_no}'.encode()).digest()
        roll=(int.from_bytes(h[:4],'big') % 101)-50  # -50..50
        score=capability-target+(roll/20.0)
        if score>=4: outcome='FULL_SUCCESS'
        elif score>=2: outcome='SUCCESS_WITH_COST'
        elif score>=0: outcome='PARTIAL_SUCCESS'
        elif score<=-5: outcome='CRITICAL_FAILURE'
        else: outcome='FAILURE'
        return MissionResolution(outcome,round(score,3),target,roll,primary,pv)
