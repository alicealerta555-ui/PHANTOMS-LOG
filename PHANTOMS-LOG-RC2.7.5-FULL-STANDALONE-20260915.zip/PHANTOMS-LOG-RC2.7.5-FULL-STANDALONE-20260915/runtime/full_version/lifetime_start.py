from __future__ import annotations

"""Lifetime-origin start layer for a new PHANTOMS-LOG run.

The lifetime layer is deliberately class-independent.  It provides a small family
history, household obligations, a diary clue, a surviving relative and hidden
parental estate.  Exact hidden-world information is kept in runtime state and is
only projected to actor knowledge after in-world discovery.
"""

from copy import deepcopy
from dataclasses import dataclass
from hashlib import sha256
import json
from typing import Any, Mapping

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage9.world_time import WorldClock


LIFETIME_SCHEMA = "PHANTOMS_LIFETIME_START_V1"
LIFETIME_STATE_KEY = "__lifetime_start__"
LIFETIME_DIARY_ITEM_ID = "item:lifetime:journal"
LIFETIME_FAMILY_ACTOR_ID = "actor:lifetime:family"
LIFETIME_LOCAL_ACTOR_IDS = ("actor:lifetime:local:01", "actor:lifetime:local:02")
LIFETIME_ESTATE_ITEM_PREFIX = "item:lifetime:estate:"
LIFETIME_ESTATE_KNOWLEDGE_KEY = "lifetime:parent_estate_location"
PLAYER_ACTOR_ID = "actor:player"

_START_REGION = "region:04"
_START_CATEGORY = "perimeter_outskirts"
_REMOTE_CATEGORIES = frozenset({
    "underground_dungeon", "industrial_maintenance", "wilderness_routes",
    "civic_social_infrastructure", "perimeter_outskirts",
})
_PARENT_ROLES = (
    ("mechanic", "Wartungshelfer"),
    ("hauler", "Transportarbeiter"),
    ("technician", "Feldtechniker"),
    ("farmer", "Versorgungsarbeiter"),
    ("scout", "Routenhelfer"),
    ("medic", "Sanitätshelfer"),
    ("archivist", "Lager- und Dokumentationskraft"),
)
_SURVIVING_RELATIONS = ("Mutter", "Vater", "ältere Schwester", "älterer Bruder", "Tante", "Onkel")
_CAUSES = (
    "bei einem technischen Unfall während eines Routineeinsatzes",
    "bei einem Einsturz während einer gewöhnlichen Bergungsarbeit",
    "bei einem Versorgungsunfall auf einer bezahlten Außenmission",
    "bei einer fehlgeschlagenen Rückkehr von einem normalen Arbeitsauftrag",
    "durch einen Unfall während einer wenig prestigeträchtigen Erkundungsarbeit",
)
_CHILDHOODS = (
    "Du bist in einem kleinen Haushalt am Rand größerer Siedlungsräume aufgewachsen und kennst Arbeit, Tausch und gegenseitige Hilfe eher aus dem Alltag als aus großen Institutionen.",
    "Deine Kindheit verlief überwiegend in einer kleinen Randsiedlung. Reparaturen, Botengänge und gemeinschaftliche Pflichten waren normaler als Abenteuer oder Ruhm.",
    "Du bist in einfachen Verhältnissen außerhalb der großen Zentren groß geworden. Der Haushalt lebte von gewöhnlicher Arbeit und gelegentlichen Aufträgen.",
)
_CHILDHOOD_DUTIES = (
    ("household_repairs", "Du hast früh bei einfachen Reparaturen, Materialpflege und dem Ordnen gemeinsamer Vorräte mitgeholfen."),
    ("errands", "Botengänge, Abholen von Teilen und kurze Wege zwischen Werkstätten und Haushalten gehörten zu deinen regelmäßigen Pflichten."),
    ("care_and_supply", "Du hast häufig bei Versorgung, Kochen, Wasserholen und der Unterstützung anderer Haushaltsmitglieder geholfen."),
    ("route_help", "Du hast schon früh bei sicheren lokalen Wegen, Tragearbeiten und der Vorbereitung kleiner Fahrten mitgeholfen."),
)
_EDUCATION_PATHS = (
    ("local_basic", "örtliche Grundausbildung", "Lesen, Rechnen, Sicherheitsregeln und praktische Alltagskenntnisse standen im Vordergrund; ein besonderer Abschluss war damit nicht verbunden."),
    ("household_practical", "überwiegend praktische Unterweisung im Haushalt", "Du hast Grundlagen vor allem durch Mitmachen, Wiederholen und Korrigieren gelernt; formale Theorie blieb begrenzt."),
    ("mixed_instruction", "gemischte lokale Unterweisung", "Ein Teil deiner Ausbildung war organisiert, ein Teil kam aus Werkstätten, Nachbarschaft und Familie. Sie gab dir Orientierung, aber keine automatische Berufsqualifikation."),
    ("workshop_intro", "frühe Werkstatt- und Versorgungsunterweisung", "Du hast grundlegende Arbeitsabläufe, Werkzeugdisziplin und Sicherheitsroutinen kennengelernt, ohne dadurch bereits Fachkraft zu sein."),
)
_EARLY_WORK = (
    ("helper_repairs", "Aushilfe bei Reparatur- und Wartungsarbeiten", "Du hast einfache, kontrollierte Hilfsarbeiten übernommen und gelernt, Anweisungen und Sicherheitsgrenzen ernst zu nehmen."),
    ("helper_supply", "Aushilfe in Versorgung und Lagerung", "Du hast bei Sortierung, Transport und Ausgabe geholfen; Verantwortung blieb bei erfahreneren Leuten."),
    ("helper_routes", "Aushilfe bei lokalen Transport- und Routendiensten", "Du kennst Vorbereitung und Nachbereitung kleiner Transporte, aber keine gefährlichen Fernrouten aus eigener Verantwortung."),
    ("helper_care", "Aushilfe bei einfachen Versorgungs- und Betreuungsaufgaben", "Du hast alltägliche Unterstützung geleistet, ohne medizinische oder professionelle Zuständigkeit vorzutäuschen."),
    ("odd_jobs", "wechselnde kleine Hilfsarbeiten", "Du hast dort mit angepackt, wo kurzfristig Hände gebraucht wurden. Das brachte Alltagserfahrung, aber keinen festen Beruf."),
)
_FORMATIVE_EVENTS = (
    ("shortage", "Eine knappe Versorgungsphase hat dir gezeigt, wie schnell kleine Haushalte von funktionierenden Wegen, Vorräten und gegenseitiger Hilfe abhängen."),
    ("repair_failure", "Ein misslungener Reparaturversuch in der Nachbarschaft hat dir früh beigebracht, dass Improvisation Grenzen hat und Fehler reale Kosten verursachen."),
    ("route_delay", "Eine länger als erwartete Unterbrechung eines lokalen Transportwegs hat dir gezeigt, wie abhängig Randorte von verlässlicher Logistik sind."),
    ("family_loss", "Der Tod deines Elternteils hat aus normalen Haushaltspflichten plötzlich dauerhafte Verantwortung gemacht, ohne daraus eine Heldengeschichte zu machen."),
)
_HOUSEHOLD_PATTERNS = (
    ("close_practical", "eng und praktisch verbunden", {"trust": 32, "respect": 18, "affection": 28, "fear": 0, "grievance": 0, "debt": 0, "loyalty": 30}),
    ("strained_reliable", "angespannt, aber verlässlich", {"trust": 20, "respect": 20, "affection": 12, "fear": 0, "grievance": 8, "debt": 0, "loyalty": 24}),
    ("protective", "gegenseitig beschützend", {"trust": 28, "respect": 14, "affection": 32, "fear": 2, "grievance": 0, "debt": 0, "loyalty": 34}),
    ("reserved", "zurückhaltend, aber pflichtbewusst", {"trust": 22, "respect": 24, "affection": 10, "fear": 0, "grievance": 3, "debt": 0, "loyalty": 26}),
)
_SITE_ARCHETYPES = {
    "underground_dungeon": ("Dungeon", "Bunker", "Tunnelanlage", "Höhlensystem", "Kultstätte", "versunkene Anlage"),
    "industrial_maintenance": ("verlassene Fabrik", "Labor", "Forschungsstation", "stillgelegtes Kraftwerk", "unterirdischer Versorgungskomplex"),
    "wilderness_routes": ("abgestürztes Transportwrack", "verlassener Hof", "zerstörter Außenposten", "abgelegene Bergungsstelle"),
    "perimeter_outskirts": ("alte Militäranlage", "Lagerhaus", "verlassener Transitknoten", "zerstörter Außenposten"),
    "civic_social_infrastructure": ("alte Klinik", "Quarantänestation", "aufgegebener Bahnhof", "stillgelegte Verwaltungsanlage"),
}


def _score(seed: str) -> int:
    return int.from_bytes(sha256(seed.encode("utf-8")).digest()[:8], "big")


def _pick(seq, seed: str):
    seq = tuple(seq)
    if not seq:
        raise ValueError("LIFETIME_EMPTY_SELECTION_POOL")
    return seq[_score(seed) % len(seq)]


def _graph_distances(world: Mapping[str, Any], start: str) -> dict[str, int]:
    by_id = {x["location_id"]: x for x in world["locations"]}
    distance = {start: 0}
    queue = [start]
    while queue:
        current = queue.pop(0)
        for nxt in by_id[current].get("connections", ()):  # validated by catalog
            if nxt not in distance:
                distance[nxt] = distance[current] + 1
                queue.append(nxt)
    return distance


def resolve_lifetime_start_location(world: Mapping[str, Any], run_uuid: str) -> str:
    """Small class-independent start location in the Randmark."""
    preferred_names = {"Perimeterhof", "Außenposten", "Randstation", "Vorwerk"}
    candidates = [
        x for x in world["locations"]
        if x.get("enterable")
        and x.get("region_id") == _START_REGION
        and x.get("primary_category") == _START_CATEGORY
        and x.get("display_name") in preferred_names
    ]
    if not candidates:
        candidates = [
            x for x in world["locations"]
            if x.get("enterable") and x.get("primary_category") in {"perimeter_outskirts", "residential_domestic"}
        ]
    return str(_pick(candidates, f"{run_uuid}|lifetime|start-location")["location_id"])


def canonical_origin_label(state: Mapping[str, Any]) -> str:
    """Canonical player origin label derived from the immutable lifetime start."""
    start = state.get("start") if isinstance(state, Mapping) else None
    if not isinstance(start, Mapping):
        raise LifetimeStartError("LIFETIME_ORIGIN_START_MISSING")
    location = str(start.get("location_name") or "").strip()
    region = str(start.get("region_label") or "").strip()
    if not location or not region:
        raise LifetimeStartError("LIFETIME_ORIGIN_START_INVALID")
    return f"{region} – {location}"


def _estate_site(world: Mapping[str, Any], run_uuid: str, start_location_id: str) -> Mapping[str, Any]:
    dist = _graph_distances(world, start_location_id)
    start_region = next(x["region_id"] for x in world["locations"] if x["location_id"] == start_location_id)
    candidates = [
        x for x in world["locations"]
        if x.get("enterable")
        and x["location_id"] != start_location_id
        and x.get("primary_category") in _REMOTE_CATEGORIES
        and x.get("region_id") != start_region
        and dist.get(x["location_id"], 0) >= 4
    ]
    if not candidates:
        candidates = [
            x for x in world["locations"]
            if x.get("enterable") and x["location_id"] != start_location_id and x.get("primary_category") in _REMOTE_CATEGORIES
        ]
    return _pick(candidates, f"{run_uuid}|lifetime|estate-site")


def _estate_item_definitions(world: Mapping[str, Any], run_uuid: str) -> tuple[str, ...]:
    by_kind: dict[str, list[str]] = {}
    for item in world["item_definitions"]:
        if item.get("kind") in {"tool", "clothing", "component", "medical"}:
            by_kind.setdefault(str(item["kind"]), []).append(str(item["item_definition_id"]))
    kinds = ("tool", "clothing", "component")
    out = []
    for i, kind in enumerate(kinds):
        values = sorted(by_kind.get(kind, ()))
        if values:
            out.append(_pick(values, f"{run_uuid}|lifetime|estate-item|{i}|{kind}"))
    return tuple(out)


def _regional_context(region_id: str, region_profiles: Mapping[str, Any] | None) -> dict[str, Any]:
    profile = dict((region_profiles or {}).get(region_id) or {})
    occupations = profile.get("occupation_mix_ppm") if isinstance(profile.get("occupation_mix_ppm"), Mapping) else {}
    common = [str(k) for k, _ in sorted(occupations.items(), key=lambda kv: (-int(kv[1]), str(kv[0])))[:4]]
    return {
        "region_id": region_id,
        "settlement_archetype": str(profile.get("settlement_archetype") or "Rand- und Kleinsiedlungsumfeld"),
        "population_density": str(profile.get("population_density") or "unbekannt"),
        "common_occupation_types": common,
    }


def _build_life_history(run_uuid: str, *, start_region: str, region_profiles: Mapping[str, Any] | None) -> dict[str, Any]:
    duty_id, duty_text = _pick(_CHILDHOOD_DUTIES, f"{run_uuid}|lifetime|childhood-duty")
    education_id, education_label, education_text = _pick(_EDUCATION_PATHS, f"{run_uuid}|lifetime|education")
    work_id, work_label, work_text = _pick(_EARLY_WORK, f"{run_uuid}|lifetime|early-work")
    event_id, event_text = _pick(_FORMATIVE_EVENTS, f"{run_uuid}|lifetime|formative-event")
    household_id, household_label, relationship_seed = _pick(_HOUSEHOLD_PATTERNS, f"{run_uuid}|lifetime|household-pattern")
    return {
        "schema": "PHANTOMS_LIFE_HISTORY_V1",
        "household_pattern": {"id": household_id, "label": household_label},
        "childhood_duty": {"id": duty_id, "summary": duty_text},
        "education": {"id": education_id, "label": education_label, "summary": education_text, "grants_skill_points": False},
        "early_work": {"id": work_id, "label": work_label, "summary": work_text, "grants_skill_points": False},
        "formative_event": {"id": event_id, "summary": event_text},
        "regional_context": _regional_context(start_region, region_profiles),
        "relationship_seed": dict(relationship_seed),
        "mechanical_modifiers": {},
        "knowledge_policy": "AUTOBIOGRAPHICAL_ONLY_NO_HIDDEN_WORLD_FACTS",
    }


def build_lifetime_start(world: Mapping[str, Any], run_uuid: str, *, region_labels: Mapping[str, str] | None = None, region_profiles: Mapping[str, Any] | None = None) -> dict[str, Any]:
    start_location_id = resolve_lifetime_start_location(world, run_uuid)
    start_loc = next(x for x in world["locations"] if x["location_id"] == start_location_id)
    target = _estate_site(world, run_uuid, start_location_id)
    role_id, role_label = _pick(_PARENT_ROLES, f"{run_uuid}|lifetime|parent-role")
    relation = _pick(_SURVIVING_RELATIONS, f"{run_uuid}|lifetime|survivor")
    survivor_role_id, survivor_role_label = _pick(_PARENT_ROLES, f"{run_uuid}|lifetime|survivor-role")
    local_role_ids = [
        _pick(tuple(x[0] for x in _PARENT_ROLES), f"{run_uuid}|lifetime|local-role|{i}")
        for i in range(2)
    ]
    cause = _pick(_CAUSES, f"{run_uuid}|lifetime|death-cause")
    childhood = _pick(_CHILDHOODS, f"{run_uuid}|lifetime|childhood")
    category = str(target["primary_category"])
    site_archetype = _pick(_SITE_ARCHETYPES[category], f"{run_uuid}|lifetime|site-archetype")
    debt = 180 + (_score(f"{run_uuid}|lifetime|debt") % 43) * 10
    target_region = str(target["region_id"])
    labels = dict(region_labels or {})
    target_region_label = labels.get(target_region, target_region)
    start_region = str(start_loc["region_id"])
    start_region_label = labels.get(start_region, start_region)
    estate_defs = _estate_item_definitions(world, run_uuid)
    estate_ids = tuple(f"{LIFETIME_ESTATE_ITEM_PREFIX}{i:02d}" for i in range(1, len(estate_defs) + 1))
    life_history = _build_life_history(run_uuid, start_region=start_region, region_profiles=region_profiles)
    return {
        "schema": LIFETIME_SCHEMA,
        "run_uuid": run_uuid,
        "start": {
            "location_id": start_location_id,
            "location_name": str(start_loc["display_name"]),
            "region_id": start_region,
            "region_label": start_region_label,
            "settlement_scale": "SMALL_OUTSKIRT_SETTLEMENT",
            "class_independent": True,
        },
        "origin": {
            "childhood": childhood,
            "deceased_parent": {
                "ordinary_role_id": role_id,
                "ordinary_role_label": role_label,
                "exceptional_status": False,
                "death_cause": cause,
            },
            "surviving_family_relation": relation,
            "surviving_family_role_id": survivor_role_id,
            "surviving_family_role_label": survivor_role_label,
        },
        "life_history": life_history,
        "family": {
            "surviving_actor_id": LIFETIME_FAMILY_ACTOR_ID,
            "local_actor_ids": list(LIFETIME_LOCAL_ACTOR_IDS),
            "local_role_ids": local_role_ids,
            "household_ref": "household:lifetime:" + sha256(run_uuid.encode("utf-8")).hexdigest()[:12],
        },
        "obligations": {
            "initial_debt_credits": debt,
            "current_debt_credits": debt,
            "employment_needed": True,
            "employment_state": "SEEKING",
            "debt_origin": "HOUSEHOLD_INHERITANCE",
        },
        "diary": {
            "item_instance_id": LIFETIME_DIARY_ITEM_ID,
            "target_region_id": target_region,
            "target_region_label": target_region_label,
            "site_archetype": site_archetype,
            "exact_location_known": False,
            "note": (
                f"Die letzten Notizen nennen eine {site_archetype} im Bereich {target_region_label}. "
                "Der genaue Ort ist aus den Einträgen nicht eindeutig rekonstruierbar. Dort könnte noch Habe des verstorbenen Elternteils liegen."
            ),
        },
        "estate": {
            "target_location_id": str(target["location_id"]),  # world truth, never projected before discovery
            "target_region_id": target_region,
            "site_archetype": site_archetype,
            "item_instance_ids": list(estate_ids),
            "item_definition_ids": list(estate_defs),
            "clue_locations": [],
            "discovered_location_id": None,
            "revealed_item_ids": [],
        },
        "generation_policy": {
            "descendant_inheritance_enabled": True,
            "inherits": ["assets", "debts", "diaries", "contacts", "reputation", "open_obligations", "unresolved_traces"],
            "player_hint": "Wenn du später selbst Kinder hast, können dein Besitz, deine Schulden, Aufzeichnungen und offenen Spuren nach denselben Regeln Teil ihres Starts werden.",
        },
    }


class LifetimeStartError(RuntimeError):
    pass


@dataclass(slots=True)
class LifetimeStartRuntime:
    catalog: Any
    session: Any
    actor_id: str = PLAYER_ACTOR_ID

    def state(self) -> dict[str, Any]:
        state = self.session.kernel.read(Authority.COMMIT_KERNEL, Domain.RUNTIME_STATE, LIFETIME_STATE_KEY)
        if not isinstance(state, dict) or state.get("schema") != LIFETIME_SCHEMA or state.get("run_uuid") != self.session.identity.run_uuid:
            raise LifetimeStartError("LIFETIME_STATE_MISSING_OR_INVALID")
        return deepcopy(state)

    def is_diary(self, item_id: str) -> bool:
        return str(item_id) == LIFETIME_DIARY_ITEM_ID

    def origin_text(self) -> str:
        state = self.state(); origin = state["origin"]; parent = origin["deceased_parent"]; start = state["start"]
        return (
            f"{origin['childhood']}\n"
            f"Dein verstorbenes Elternteil arbeitete als {parent['ordinary_role_label']} und galt nicht als außergewöhnlich begabt. "
            f"Es starb {parent['death_cause']}.\n"
            f"Du lebst mit deinem verbliebenen Familienmitglied ({origin['surviving_family_relation']}) in/bei {start['location_name']} ({start['region_label']}).\n"
            + state["generation_policy"]["player_hint"]
        )

    def life_history_text(self) -> str:
        state = self.state(); history = state.get("life_history") or {}
        if history.get("schema") != "PHANTOMS_LIFE_HISTORY_V1":
            return "Lebenslauf: Für diesen älteren Run liegt noch kein vertiefter Lebenslauf vor."
        regional = history["regional_context"]
        occupations = ", ".join(regional.get("common_occupation_types") or ()) or "keine belastbare Häufung"
        return (
            "Lebenslauf vor Spielstart:\n"
            f"- Haushalt: {history['household_pattern']['label']}.\n"
            f"- Frühe Pflichten: {history['childhood_duty']['summary']}\n"
            f"- Ausbildung: {history['education']['label']}. {history['education']['summary']}\n"
            f"- Erste Arbeitserfahrung: {history['early_work']['label']}. {history['early_work']['summary']}\n"
            f"- Prägendes Ereignis: {history['formative_event']['summary']}\n"
            f"- Regionaler Kontext: {regional['settlement_archetype']}; Bevölkerungsdichte {regional['population_density']}; häufige Tätigkeiten: {occupations}.\n"
            "Diese Vorgeschichte beschreibt gelebte Erfahrung. Sie vergibt keine verdeckten Stat-, Skill- oder Talentpunkte und enthält keine geheimen Weltfakten."
        )

    def journal_text(self) -> str:
        state = self.state()
        return "Familientagebuch: " + state["diary"]["note"]

    def inheritance_text(self) -> str:
        state = self.state(); estate = state["estate"]; diary = state["diary"]
        exact = estate.get("discovered_location_id")
        location_line = (
            f"Der genaue Ort ist inzwischen bekannt: {self.catalog.location(exact)['display_name']} [{exact}]."
            if exact else
            f"Bekannt ist nur: {diary['site_archetype']} im Bereich {diary['target_region_label']}. Der genaue Ort ist noch unklar."
        )
        statuses=[]
        for iid in estate["item_instance_ids"]:
            rec=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
            if not isinstance(rec,dict):
                statuses.append(f"{iid}: fehlt")
            elif rec.get("location_ref") == f"inventory:{self.actor_id}":
                statuses.append(f"{iid}: geborgen")
            elif rec.get("hidden"):
                statuses.append(f"{iid}: noch nicht gefunden")
            else:
                statuses.append(f"{iid}: gefunden, noch nicht aufgenommen")
        return "Erbspur: "+location_line+"\n"+" | ".join(statuses)

    def obligations_text(self) -> str:
        state=self.state(); o=state["obligations"]
        return (
            f"Offene Haushaltsschuld: {int(o['current_debt_credits'])} Cr (ursprünglich {int(o['initial_debt_credits'])} Cr). "
            f"Arbeitssuche: {o['employment_state']}. Die Verpflichtung erzeugt Druck, aber keinen Zwangsauftrag."
        )

    def work_text(self) -> str:
        state=self.state(); here=str(self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,self.actor_id).get("location_ref"))
        leads=[]
        for key in self.session.store.runtime_state:
            if not str(key).startswith("actor:") or key==self.actor_id: continue
            rec=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
            if not isinstance(rec,dict) or rec.get("kind")!="actor" or rec.get("location_ref")!=here: continue
            if rec.get("role") in {"merchant","mechanic","technician","hauler","farmer","medic","archivist","guard"}:
                leads.append(str(key))
        if not leads:
            return "Du brauchst Beschäftigung, kennst hier aber noch keinen konkreten Auftraggeber. Gespräche, Dienste und lokale Aufträge können neue Möglichkeiten eröffnen."
        return "Mögliche lokale Ansprechpartner für Arbeit oder Aufträge: "+", ".join(sorted(leads))+". Ein Gespräch garantiert noch keinen Auftrag."

    def pay_debt(self, amount: int) -> dict[str, int]:
        if type(amount) is not int or amount <= 0:
            raise LifetimeStartError("DEBT_PAYMENT_MUST_BE_POSITIVE_INTEGER")
        state=self.state(); outstanding=int(state["obligations"]["current_debt_credits"])
        if outstanding <= 0:
            return {"paid":0,"remaining":0}
        actor=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,self.actor_id)
        if not isinstance(actor,dict): raise LifetimeStartError("PLAYER_ACTOR_MISSING")
        resources=deepcopy(actor.get("resources") or {}); credits=int(resources.get("credits",0))
        applied=min(amount,outstanding)
        if credits < applied: raise LifetimeStartError("DEBT_PAYMENT_INSUFFICIENT_CREDITS")
        resources["credits"]=credits-applied; actor=deepcopy(actor); actor["resources"]=resources
        state["obligations"]["current_debt_credits"]=outstanding-applied
        if state["obligations"]["current_debt_credits"]==0:
            state["obligations"]["employment_state"]="OPTIONAL"
        event=f"LIFETIME_DEBT_PAYMENT:{self.session.store.revision}"
        result=self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,event_id=event,cause="LIFETIME_DEBT_PAYMENT",
            expected_state_revision=self.session.store.revision,
            deltas=(
                Delta(Domain.RUNTIME_STATE,self.actor_id,actor,Authority.RULE_KERNEL,"LIFETIME_DEBT_PAYMENT",source_event_id=event,provenance="LIFETIME_FINANCE"),
                Delta(Domain.RUNTIME_STATE,LIFETIME_STATE_KEY,state,Authority.RULE_KERNEL,"LIFETIME_DEBT_PAYMENT",source_event_id=event,provenance="LIFETIME_FINANCE"),
            ),
        ))
        if not isinstance(result,CommitRecord): raise LifetimeStartError("DEBT_PAYMENT_COMMIT_REJECTED")
        return {"paid":applied,"remaining":int(state["obligations"]["current_debt_credits"])}


def lifetime_search_effects(catalog, session, location_id: str, *, actor_id: str, event_id: str) -> tuple[list[dict], list[dict], list[Delta]]:
    """Return search discoveries and deltas without committing them separately.

    This is called only after the normal SEARCH capability check succeeds so one
    CommitKernel proposal remains the single writer for the complete search action.
    """
    kernel=session.kernel
    state=kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,LIFETIME_STATE_KEY)
    if not isinstance(state,dict) or state.get("schema")!=LIFETIME_SCHEMA:
        return [],[],[]
    state=deepcopy(state); estate=state["estate"]; target=str(estate["target_location_id"])
    loc=catalog.location(location_id); found=[]; learned=[]; deltas=[]; changed=False

    if location_id == target:
        if estate.get("discovered_location_id") != target:
            estate["discovered_location_id"] = target
            state["diary"]["exact_location_known"] = True
            learned.append({"information_id":"lifetime:estate_site_confirmed","location_id":location_id,"text":f"Die Spuren passen zu den Tagebuchnotizen. Dies ist der gesuchte Einsatzort: {loc['display_name']}."})
            changed=True
        for iid in estate.get("item_instance_ids",()):
            item=kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
            if not isinstance(item,dict) or item.get("location_ref")!=target or not item.get("hidden"):
                continue
            item=deepcopy(item); item["hidden"]=False
            deltas.append(Delta(Domain.RUNTIME_STATE,iid,item,Authority.RULE_KERNEL,"LIFETIME_ESTATE_REVEAL",source_event_id=event_id,provenance="LIFETIME_PARENT_ESTATE_SEARCH"))
            if iid not in estate["revealed_item_ids"]: estate["revealed_item_ids"].append(iid)
            sv=item.get("surface_variant") if isinstance(item.get("surface_variant"),dict) else {}
            found.append({"instance_id":iid,"item_definition_id":item["item_definition_id"],"display_name":sv.get("display_name") or catalog.item_definition(item["item_definition_id"])["display_name"],"lifetime_estate":True})
            changed=True
    elif str(loc.get("region_id")) == str(estate.get("target_region_id")) and not estate.get("discovered_location_id"):
        clues=estate.setdefault("clue_locations",[])
        if location_id not in clues:
            clues.append(location_id); changed=True
        if len(clues)>=2:
            estate["discovered_location_id"] = target
            state["diary"]["exact_location_known"] = True
            tloc=catalog.location(target)
            learned.append({"information_id":"lifetime:estate_route_resolved","location_id":location_id,"text":f"Mehrere lokale Hinweise ergeben zusammen eine belastbare Spur: Der gesuchte Einsatzort dürfte {tloc['display_name']} sein."})
        else:
            learned.append({"information_id":"lifetime:estate_region_clue","location_id":location_id,"text":"Die lokalen Spuren passen zum Tagebuch. Du bist im richtigen Gebiet, aber der genaue Einsatzort bleibt noch unklar."})

    if changed:
        deltas.append(Delta(Domain.RUNTIME_STATE,LIFETIME_STATE_KEY,state,Authority.RULE_KERNEL,"LIFETIME_SEARCH_PROGRESS",source_event_id=event_id,provenance="LIFETIME_SEARCH"))
    if estate.get("discovered_location_id") == target:
        if kernel.read(Authority.KNOWLEDGE_ROUTER,Domain.ACTOR_KNOWLEDGE,LIFETIME_ESTATE_KNOWLEDGE_KEY,actor_id=actor_id) is None:
            tloc=catalog.location(target)
            epistemic={"source_type":"DIRECT_OBSERVATION","source_id":"lifetime_estate_trace","origin_location":location_id,"learned_at":WorldClock(session).seconds,"path":[],"confidence_ppm":950000,"distortions":[]}
            deltas.append(Delta(Domain.ACTOR_KNOWLEDGE,LIFETIME_ESTATE_KNOWLEDGE_KEY,{"location_id":target,"display_name":tloc["display_name"],"source":"lifetime_search"},Authority.KNOWLEDGE_ROUTER,"LIFETIME_ESTATE_DISCOVERY",actor_id=actor_id,source_event_id=event_id,provenance="LIFETIME_SEARCH",epistemic=epistemic))
    return found,learned,deltas
