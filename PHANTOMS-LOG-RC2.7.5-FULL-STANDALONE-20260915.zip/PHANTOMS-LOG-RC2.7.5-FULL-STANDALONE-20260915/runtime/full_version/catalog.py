# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any, Mapping

from runtime.stage10.creatures import CreatureProfileRegistry
from runtime.stage6.biology import Stage6BiologyCatalog
from runtime.stage7.needs import Stage7NeedCatalog
from runtime.stage8.world import Stage8WorldCatalog


class FullVersionContractError(ValueError): pass


@dataclass(frozen=True, slots=True)
class FullVersionCatalog:
    root: Path
    world: Mapping[str, Any]
    creature_registry: CreatureProfileRegistry
    dungeons: tuple[Mapping[str, Any], ...]
    stage6_biology: Stage6BiologyCatalog
    stage7_needs: Stage7NeedCatalog
    stage8_world: Stage8WorldCatalog
    search_tables: Mapping[str, Any]
    npc_runtime_tables: Mapping[str, Any]
    playable_operations: Mapping[str, Any]
    _locations: Mapping[str, Mapping[str, Any]] = field(init=False, repr=False, compare=False)
    _class_starts: Mapping[str, Mapping[str, Any]] = field(init=False, repr=False, compare=False)
    _items: Mapping[str, Mapping[str, Any]] = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        # Per-catalog indexes only. No global cache of mutable player/run objects.
        object.__setattr__(self, '_locations', {x['location_id']: x for x in self.world['locations']})
        object.__setattr__(self, '_class_starts', {x['start_class']: x for x in self.world['character_class_starts']})
        object.__setattr__(self, '_items', {x['item_definition_id']: x for x in self.world['item_definitions']})

    @classmethod
    def load(cls, root: Path) -> "FullVersionCatalog":
        root=Path(root).resolve(); content=root/'content'/'full_version'
        world=json.loads((content/'world_catalog.json').read_text(encoding='utf-8'))
        if world.get('schema')!='PH4NT0M5-L0G_FULL_WORLD_V1': raise FullVersionContractError('FULL_WORLD_SCHEMA_INVALID')
        d=json.loads((content/'dungeons.json').read_text(encoding='utf-8'))
        if d.get('schema')!='PH4NT0M5-L0G_DUNGEONS_V1': raise FullVersionContractError('DUNGEON_SCHEMA_INVALID')
        creature_registry=CreatureProfileRegistry.from_json(content/'creature_profiles.json')
        stage6_biology=Stage6BiologyCatalog.load(content/'stage6_biology.json')
        stage7_needs=Stage7NeedCatalog.load(content/'stage7_needs.json')
        stage8_world=Stage8WorldCatalog.load(content/'stage8_world.json',world)
        search_tables=json.loads((content/'location_search_tables.json').read_text(encoding='utf-8'))
        npc_runtime_tables=json.loads((content/'npc_runtime_tables.json').read_text(encoding='utf-8'))
        playable_operations=json.loads((content/'playable_operations.json').read_text(encoding='utf-8'))
        obj=cls(root,world,creature_registry,tuple(d['dungeons']),stage6_biology,stage7_needs,stage8_world,search_tables,npc_runtime_tables,playable_operations)
        obj.validate()
        obj._validate_search_tables()
        obj._validate_npc_runtime_tables()
        obj._validate_playable_operations()
        obj._validate_population_tables()
        arrival=json.loads((content/'arrival_perception_profiles.json').read_text(encoding='utf-8'))
        if arrival.get('schema')!='PH4NT0M5_ARRIVAL_PERCEPTION_PROFILES_V1' or not isinstance(arrival.get('profiles'),dict):
            raise FullVersionContractError('ARRIVAL_PROFILE_SCHEMA_INVALID')
        missing={x['primary_category'] for x in world['locations']}-set(arrival['profiles'])
        if missing: raise FullVersionContractError('ARRIVAL_PROFILE_CATEGORY_MISSING:'+','.join(sorted(missing)))
        return obj

    def validate(self) -> None:
        locations=self.world.get('locations'); factions=self.world.get('factions'); npcs=self.world.get('npc_definitions'); items=self.world.get('item_definitions'); conflicts=self.world.get('conflicts'); ops=self.world.get('craft_repair_operations'); starts=self.world.get('character_class_starts')
        if not isinstance(locations,list) or len(locations)<100: raise FullVersionContractError('FULL_WORLD_LOCATION_MINIMUM')
        ids=[x.get('location_id') for x in locations]
        if len(ids)!=len(set(ids)): raise FullVersionContractError('FULL_WORLD_LOCATION_DUPLICATE')
        known=set(ids)
        for x in locations:
            if not x.get('enterable'): raise FullVersionContractError('FULL_WORLD_LOCATION_NOT_ENTERABLE')
            if len(x.get('gameplay_hooks',()))<2: raise FullVersionContractError('FULL_WORLD_LOCATION_HOOK_MINIMUM')
            if not set(x.get('connections',())) <= known: raise FullVersionContractError('FULL_WORLD_CONNECTION_UNKNOWN')
        underground=[x for x in locations if x.get('primary_category')=='underground_dungeon']
        checks=[(factions,5,'FACTION'),(npcs,45,'NPC'),(items,80,'ITEM'),(conflicts,10,'CONFLICT'),(ops,15,'OPERATION'),(list(self.creature_registry.ids()),10,'CREATURE'),(list(self.dungeons),15,'DUNGEON'),(starts,4,'CHARACTER_CLASS_START')]
        if len(underground)<15: raise FullVersionContractError('FULL_WORLD_UNDERGROUND_MINIMUM')
        for value,minimum,label in checks:
            if not isinstance(value,list) or len(value)<minimum: raise FullVersionContractError(f'FULL_WORLD_{label}_MINIMUM')
        item_ids={x.get('item_definition_id') for x in items if isinstance(x,dict)}
        if None in item_ids or len(item_ids)!=len(items): raise FullVersionContractError('FULL_WORLD_ITEM_ID_INVALID')
        for op in ops:
            op_id=op.get('operation_id') if isinstance(op,dict) else None
            if not op_id: raise FullVersionContractError('FULL_WORLD_OPERATION_ID_INVALID')
            inputs=op.get('inputs',())
            if not isinstance(inputs,list) or not inputs: raise FullVersionContractError(f'FULL_WORLD_OPERATION_INPUTS_INVALID:{op_id}')
            unknown=[item_id for item_id in inputs if item_id not in item_ids]
            if unknown: raise FullVersionContractError(f'FULL_WORLD_OPERATION_ITEM_UNKNOWN:{op_id}:{unknown[0]}')
        start_ids={x.get('start_class') for x in starts if isinstance(x,dict)}
        if start_ids != {'BREAKER','GHOST','OPERATOR','RESONANT'}: raise FullVersionContractError('FULL_WORLD_CHARACTER_CLASS_STARTS_INVALID')
        for start in starts:
            # Class records are capability specializations only.  Start location, belongings,
            # knowledge and motivation belong exclusively to the Lifetime start layer.
            forbidden={'start_categories','starting_item_groups','starting_knowledge','starter_impulses'} & set(start)
            if forbidden:
                raise FullVersionContractError('FULL_WORLD_CLASS_START_LEGACY_FIELDS:'+','.join(sorted(forbidden)))
            if not isinstance(start.get('display_name'),str) or not start['display_name'].strip():
                raise FullVersionContractError(f'FULL_WORLD_CLASS_DISPLAY_NAME_INVALID:{start.get("start_class")}')
        dungeon_ids=set()
        for dungeon in self.dungeons:
            did=dungeon.get('dungeon_id')
            if not did or did in dungeon_ids: raise FullVersionContractError('FULL_WORLD_DUNGEON_ID_INVALID')
            dungeon_ids.add(did)
            locs=dungeon.get('location_ids',())
            if not isinstance(locs,list) or not locs or not set(locs) <= known:
                raise FullVersionContractError(f'FULL_WORLD_DUNGEON_LOCATION_UNKNOWN:{did}')
        creature_lineages={self.creature_registry.get(cid).lineage_id for cid in self.creature_registry.ids()}
        if not creature_lineages <= set(self.stage6_biology.raw.get('lineages',())):
            raise FullVersionContractError('STAGE6_CREATURE_LINEAGE_COVERAGE_INVALID')
        for cid in self.creature_registry.ids():
            profile=self.creature_registry.get(cid)
            self.stage7_needs.profile_for_branch(profile.branch_classes[0].value)
            for need_key in profile.needs:
                if self.stage7_needs.normalize_need_key(need_key) not in self.stage7_needs.need_keys:
                    raise FullVersionContractError(f'STAGE7_CREATURE_NEED_UNMAPPED:{cid}:{need_key}')
        if set(self.stage8_world.locations)!=known:
            raise FullVersionContractError('STAGE8_WORLD_LOCATION_COVERAGE_INVALID')
        if any('demo' in str(v).lower() for v in ids): raise FullVersionContractError('FULL_WORLD_DEMO_ID_FORBIDDEN')


    def _validate_search_tables(self) -> None:
        data=self.search_tables
        if not isinstance(data,dict) or data.get('schema')!='PH4NT0M5_LOCATION_SEARCH_TABLES_V1':
            raise FullVersionContractError('LOCATION_SEARCH_SCHEMA_INVALID')
        profiles=data.get('profiles'); rules=data.get('rules')
        if not isinstance(profiles,dict) or not isinstance(rules,dict):
            raise FullVersionContractError('LOCATION_SEARCH_TABLE_INVALID')
        categories={x['primary_category'] for x in self.world['locations']}
        if not categories <= set(profiles):
            raise FullVersionContractError('LOCATION_SEARCH_CATEGORY_MISSING')
        item_ids=set(self._items)
        for category in categories:
            profile=profiles[category]
            resources=profile.get('resource_candidates'); infos=profile.get('information_candidates')
            if not isinstance(resources,list) or not resources or not isinstance(infos,list) or not infos:
                raise FullVersionContractError('LOCATION_SEARCH_PROFILE_EMPTY:'+category)
            for entry in resources:
                if entry.get('item_definition_id') not in item_ids:
                    raise FullVersionContractError('LOCATION_SEARCH_ITEM_UNKNOWN:'+str(entry.get('item_definition_id')))
                if type(entry.get('weight')) is not int or entry['weight']<=0 or type(entry.get('chance_ppm')) is not int or not 0<=entry['chance_ppm']<=1000000:
                    raise FullVersionContractError('LOCATION_SEARCH_RESOURCE_INVALID:'+category)
            for entry in infos:
                if not isinstance(entry.get('information_id'),str) or not entry['information_id'] or not isinstance(entry.get('text'),str) or not entry['text'] or type(entry.get('weight')) is not int or entry['weight']<=0:
                    raise FullVersionContractError('LOCATION_SEARCH_INFORMATION_INVALID:'+category)
        local=data.get('location_profiles')
        if not isinstance(local,dict) or set(local)!=set(self._locations):
            raise FullVersionContractError('LOCATION_SEARCH_LOCATION_PROFILE_COVERAGE_INVALID')
        for lid,profile in local.items():
            if not isinstance(profile,dict) or not profile.get('resource_candidates') or not profile.get('information_candidates'):
                raise FullVersionContractError('LOCATION_SEARCH_LOCATION_PROFILE_INVALID:'+lid)
            for entry in profile['resource_candidates']:
                if entry.get('item_definition_id') not in self._items:
                    raise FullVersionContractError('LOCATION_SEARCH_LOCATION_ITEM_UNKNOWN:'+lid)



    def _validate_population_tables(self) -> None:
        path=self.root/'content/full_version/population_settlement_tables.json'
        try:
            data=json.loads(path.read_text(encoding='utf-8'))
        except (OSError,json.JSONDecodeError) as exc:
            raise FullVersionContractError('POPULATION_SETTLEMENT_TABLE_READ_INVALID') from exc
        if data.get('schema')!='PH4NT0M5_POPULATION_SETTLEMENT_TABLES_V1':
            raise FullVersionContractError('POPULATION_SETTLEMENT_SCHEMA_INVALID')
        regions=data.get('region_profiles'); settlements=data.get('settlement_profiles'); locations=data.get('location_profiles')
        if not isinstance(regions,dict) or len(regions)!=5:
            raise FullVersionContractError('POPULATION_REGION_TABLE_INVALID')
        categories={x['primary_category'] for x in self.world['locations']}
        if not isinstance(settlements,dict) or set(settlements)!=categories:
            raise FullVersionContractError('POPULATION_SETTLEMENT_CATEGORY_COVERAGE_INVALID')
        if not isinstance(locations,dict) or set(locations)!=set(self._locations):
            raise FullVersionContractError('POPULATION_LOCATION_COVERAGE_INVALID')
        culture_data=json.loads((self.root/'content/full_version/content_distribution_profiles.json').read_text(encoding='utf-8'))
        known_cultures={x['culture_id'] for x in culture_data.get('cultures',())}
        for region_id,profile in regions.items():
            if region_id not in {x['region_id'] for x in self.world['locations']}:
                raise FullVersionContractError('POPULATION_REGION_UNKNOWN:'+region_id)
            for key in ('culture_mix_ppm','occupation_mix_ppm','household_mix_ppm','mobility_modes_ppm'):
                table=profile.get(key)
                if not isinstance(table,dict) or not table or sum(int(v) for v in table.values())!=1_000_000:
                    raise FullVersionContractError('POPULATION_PPM_SUM_INVALID:'+region_id+':'+key)
            if not set(profile['culture_mix_ppm']) <= known_cultures:
                raise FullVersionContractError('POPULATION_CULTURE_UNKNOWN:'+region_id)
            if sum(int(profile[k]) for k in ('resident_share_ppm','commuter_share_ppm','traveler_share_ppm'))!=1_000_000:
                raise FullVersionContractError('POPULATION_PRESENCE_SUM_INVALID:'+region_id)
        for location_id,profile in locations.items():
            loc=self._locations[location_id]
            if profile.get('region_id')!=loc['region_id'] or profile.get('category')!=loc['primary_category']:
                raise FullVersionContractError('POPULATION_LOCATION_PROFILE_MISMATCH:'+location_id)
            presence=profile.get('presence_mix_ppm')
            if not isinstance(presence,dict) or sum(int(v) for v in presence.values())!=1_000_000:
                raise FullVersionContractError('POPULATION_LOCATION_PRESENCE_INVALID:'+location_id)
            if not set(profile.get('culture_mix_ppm',{})) <= known_cultures:
                raise FullVersionContractError('POPULATION_LOCATION_CULTURE_UNKNOWN:'+location_id)
        if set(data.get('traveler_origin_matrix_ppm',{}))!=set(regions):
            raise FullVersionContractError('POPULATION_TRAVEL_MATRIX_REGION_COVERAGE_INVALID')
        for origin,row in data['traveler_origin_matrix_ppm'].items():
            if set(row)!=set(regions) or sum(int(v) for v in row.values())!=1_000_000:
                raise FullVersionContractError('POPULATION_TRAVEL_MATRIX_INVALID:'+origin)

    def _validate_playable_operations(self) -> None:
        data=self.playable_operations
        if not isinstance(data,dict) or data.get('schema')!='PH4NT0M5_PLAYABLE_OPERATIONS_V1':
            raise FullVersionContractError('PLAYABLE_OPERATIONS_SCHEMA_INVALID')
        ops={x['operation_id']:x for x in self.world['craft_repair_operations']}
        for op_id,spec in data.get('craft',{}).items():
            if op_id not in ops or ops[op_id]['kind']!='craft' or spec.get('output_item_definition_id') not in self._items:
                raise FullVersionContractError('PLAYABLE_CRAFT_OPERATION_INVALID:'+op_id)
        for op_id,spec in data.get('repair',{}).items():
            if op_id not in ops or ops[op_id]['kind']!='repair' or type(spec.get('restore')) is not int or spec['restore']<=0:
                raise FullVersionContractError('PLAYABLE_REPAIR_OPERATION_INVALID:'+op_id)
        for op_id,spec in data.get('treat',{}).items():
            if op_id not in ops or ops[op_id]['kind']!='treat' or type(spec.get('heal')) is not int or spec['heal']<=0:
                raise FullVersionContractError('PLAYABLE_TREAT_OPERATION_INVALID:'+op_id)

    def operation(self, operation_id: str) -> Mapping[str, Any]:
        for value in self.world['craft_repair_operations']:
            if value['operation_id']==operation_id: return value
        raise FullVersionContractError('FULL_WORLD_OPERATION_UNKNOWN:'+str(operation_id))
    def _validate_npc_runtime_tables(self) -> None:
        data=self.npc_runtime_tables
        if not isinstance(data,dict) or data.get('schema')!='PH4NT0M5_NPC_RUNTIME_TABLES_V1':
            raise FullVersionContractError('NPC_RUNTIME_SCHEMA_INVALID')
        roles={x['role'] for x in self.world['npc_definitions']}
        role_inventory=data.get('role_inventory')
        if not isinstance(role_inventory,dict) or not roles <= set(role_inventory):
            raise FullVersionContractError('NPC_RUNTIME_ROLE_INVENTORY_MISSING')
        item_ids=set(self._items)
        for role,items in role_inventory.items():
            if not isinstance(items,list) or not items or any(x not in item_ids for x in items):
                raise FullVersionContractError('NPC_RUNTIME_ROLE_ITEMS_INVALID:'+role)
        stock=data.get('merchant_stock')
        if not isinstance(stock,list) or not stock or any(x not in item_ids for x in stock):
            raise FullVersionContractError('NPC_RUNTIME_MERCHANT_STOCK_INVALID')
        prices=data.get('price_by_kind')
        kinds={x['kind'] for x in self.world['item_definitions']}
        if not isinstance(prices,dict) or not kinds <= set(prices) or any(type(prices[k]) is not int or prices[k]<=0 for k in kinds):
            raise FullVersionContractError('NPC_RUNTIME_PRICES_INVALID')

    def npc_definition(self, actor_definition_id: str) -> Mapping[str, Any]:
        for value in self.world['npc_definitions']:
            if value['actor_definition_id']==actor_definition_id: return value
        raise FullVersionContractError('NPC_DEFINITION_UNKNOWN:'+str(actor_definition_id))
    def search_profile(self, category: str, location_id: str | None=None) -> Mapping[str, Any]:
        try:
            if location_id is not None:
                return self.search_tables['location_profiles'][location_id]
            return self.search_tables['profiles'][category]
        except KeyError as exc: raise FullVersionContractError('LOCATION_SEARCH_PROFILE_UNKNOWN:'+str(location_id or category)) from exc

    def item_definition(self, item_definition_id: str) -> Mapping[str, Any]:
        try: return self._items[item_definition_id]
        except KeyError as exc: raise FullVersionContractError('FULL_WORLD_ITEM_UNKNOWN:'+str(item_definition_id)) from exc
    def location(self, location_id: str) -> Mapping[str, Any]:
        try:
            return self._locations[location_id]
        except KeyError:
            raise FullVersionContractError(f'LOCATION_NOT_FOUND:{location_id}') from None

    def class_start(self, start_class: str) -> Mapping[str, Any]:
        key=str(start_class).upper()
        try:
            return self._class_starts[key]
        except KeyError:
            raise FullVersionContractError(f'START_CLASS_NOT_FOUND:{key}') from None
