from __future__ import annotations

from dataclasses import dataclass

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.full_version.bootstrap import PLAYER_ACTOR_INSTANCE_ID
from runtime.player_progression.gameplay_hooks import GameplayLearningBridge, ResolvedGameplayEvent
from runtime.player_progression.livehooks import PlayerDevelopmentCoordinator
from runtime.player_progression.model import PlayerProgressionState
from runtime.player_progression.pipeline import PlayerLearningRuntime

PROGRESSION_RUNTIME_KEY = '__player_progression__'


class PlayableProgressionError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class ProgressionUpdate:
    applied: bool
    insight_messages: tuple[dict, ...]
    habit_messages: tuple[dict, ...]


class PlayableProgressionRuntime:
    """Host bridge from committed playable actions to hidden player development.

    The bridge accepts semantic, already-resolved action facts only.  It never
    parses prose and never receives hidden world truth.  The resulting adaptive
    state is persisted per run under a dedicated runtime key.
    """

    def __init__(self, catalog, session, *, actor_id: str = PLAYER_ACTOR_INSTANCE_ID):
        self.catalog = catalog
        self.session = session
        self.actor_id = actor_id

    def _load(self) -> PlayerLearningRuntime:
        raw = self.session.kernel.read(Authority.COMMIT_KERNEL, Domain.RUNTIME_STATE, PROGRESSION_RUNTIME_KEY)
        if raw is None:
            actor = self.session.kernel.read(Authority.COMMIT_KERNEL, Domain.RUNTIME_STATE, self.actor_id)
            if not isinstance(actor, dict):
                raise PlayableProgressionError('PROGRESSION_ACTOR_MISSING')
            state = PlayerProgressionState(
                player_uuid=self.session.identity.player_uuid,
                run_uuid=self.session.identity.run_uuid,
                start_class=str(actor.get('start_class') or ''),
            )
            return PlayerLearningRuntime(state)
        if not isinstance(raw, dict) or raw.get('run_uuid') != self.session.identity.run_uuid:
            raise PlayableProgressionError('PROGRESSION_STATE_INVALID')
        payload = raw.get('payload')
        if not isinstance(payload, dict):
            raise PlayableProgressionError('PROGRESSION_PAYLOAD_INVALID')
        return PlayerLearningRuntime.from_dict(payload)

    def _save(self, runtime: PlayerLearningRuntime, *, event_id: str) -> None:
        record = {
            'run_uuid': self.session.identity.run_uuid,
            'player_uuid': self.session.identity.player_uuid,
            'payload': runtime.to_dict(),
        }
        result = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            deltas=(Delta(
                Domain.RUNTIME_STATE,
                PROGRESSION_RUNTIME_KEY,
                record,
                Authority.RULE_KERNEL,
                'PLAYER_PROGRESSION_UPDATE',
                source_event_id=event_id,
                provenance='COMMITTED_GAMEPLAY_EVENT',
            ),),
            event_id=event_id,
            cause='PLAYER_PROGRESSION_UPDATE',
            expected_state_revision=self.session.store.revision,
        ))
        if not isinstance(result, CommitRecord):
            raise PlayableProgressionError('PROGRESSION_COMMIT_REJECTED')

    def observe(self, *, domain: str, action_family: str, location_id: str = '',
                target_kind: str = '', tool_kind: str = '', outcome: str = 'success',
                visible_context_tags=(), risk_tags=(), difficulty_hint: float = 1.0,
                consequence_hint: float = 1.0, intentionality_hint: float = 1.0,
                affinity_overrides=None, situation_family: str = '', choice_key: str = '',
                decision_category: str = 'micro_routine', reversible: bool = True,
                high_stakes: bool = False, irreversible: bool = False,
                moral_or_story_choice: bool = False) -> ProgressionUpdate:
        runtime = self._load()
        bridge = GameplayLearningBridge(PlayerDevelopmentCoordinator(runtime))
        result = bridge.after_resolution(ResolvedGameplayEvent(
            domain=domain,
            action_family=action_family,
            committed=True,
            actor_is_player=True,
            location_id=location_id,
            target_kind=target_kind,
            tool_kind=tool_kind,
            outcome=outcome,
            visible_context_tags=tuple(visible_context_tags),
            risk_tags=tuple(risk_tags),
            difficulty_hint=float(difficulty_hint),
            consequence_hint=float(consequence_hint),
            intentionality_hint=float(intentionality_hint),
            affinity_overrides=dict(affinity_overrides or {}),
            situation_family=situation_family,
            choice_key=choice_key,
            decision_category=decision_category,
            reversible=bool(reversible),
            high_stakes=bool(high_stakes),
            irreversible=bool(irreversible),
            moral_or_story_choice=bool(moral_or_story_choice),
        ))
        event_id = f'PROGRESSION:{self.session.store.revision}:{action_family}'
        self._save(runtime, event_id=event_id)
        return ProgressionUpdate(
            applied=result.applied_action_learning,
            insight_messages=tuple(result.insight_messages),
            habit_messages=tuple(result.habit_messages),
        )

    def snapshot(self) -> dict:
        return self._load().to_dict()
