from __future__ import annotations
import copy,json
from hashlib import blake2b
from runtime.stage3a.kernel import Authority,CommitRecord,Delta,Domain,Mode,Proposal
from runtime.stage9.world_time import WorldClock

WEATHER_STATE_KEY="__regional_weather_runtime__"

class RegionalWeatherRuntime:
    def __init__(self,catalog,session):
        self.catalog=catalog; self.session=session
        self.cfg=json.loads((catalog.root/"content/full_version/regional_weather_tables.json").read_text())
        self.s19=json.loads((catalog.root/"content/full_version/stage19_survival.json").read_text())
        if self.cfg.get("schema")!="PH4NT0M5_REGIONAL_WEATHER_V1": raise RuntimeError("WEATHER_SCHEMA_INVALID")
        self.profiles={x["id"]:x for x in self.s19["weather_profiles"]}
        self.adj=self._region_adjacency()
    def _region_adjacency(self):
        out={r:set() for r in self.cfg["regions"]}
        byloc={x["location_id"]:x for x in self.catalog.world["locations"]}
        for loc in self.catalog.world["locations"]:
            r=loc["region_id"]
            for nxt in loc.get("connections",[]):
                rr=byloc[nxt]["region_id"]
                if rr!=r: out[r].add(rr)
        return {k:tuple(sorted(v)) for k,v in out.items()}
    @staticmethod
    def _hash(text):
        return int.from_bytes(blake2b(text.encode(),digest_size=8).digest(),"big")
    def _weighted(self,mapping,seed):
        items=[(k,int(v)) for k,v in mapping.items() if int(v)>0]
        total=sum(v for _,v in items); roll=self._hash(seed)%total
        for k,v in items:
            if roll<v:return k
            roll-=v
        return items[-1][0]
    def _initial_region(self,region):
        cfg=self.cfg["regions"][region]
        wid=self._weighted(cfg["weights"],f"{self.session.identity.run_uuid}|{region}|weather:init")
        p=self.profiles[wid]
        return {"weather_id":wid,"temperature_c":int(round((cfg["baseline_temp_c"]+p["temperature_c"])/2)),
                "humidity":int(cfg["baseline_humidity"]),"wind":max(0,int(p["wind"])),
                "precipitation":int(p["precipitation"]),"exposure_bp":int(p["exposure_bp"]),
                "changed_at":0,"source":"INITIAL"}
    def _state(self):
        raw=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,WEATHER_STATE_KEY)
        if raw is None:
            return {"run_uuid":self.session.identity.run_uuid,"last_tick":0,
                    "regions":{r:self._initial_region(r) for r in sorted(self.cfg["regions"])},
                    "fronts":{}}
        if not isinstance(raw,dict) or raw.get("run_uuid")!=self.session.identity.run_uuid: raise RuntimeError("WEATHER_RUN_MISMATCH")
        return copy.deepcopy(raw)
    def ensure_initialized(self):
        raw=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,WEATHER_STATE_KEY)
        if raw is not None:
            if not isinstance(raw,dict) or raw.get("run_uuid")!=self.session.identity.run_uuid:
                raise RuntimeError("WEATHER_RUN_MISMATCH")
            return False
        st={"run_uuid":self.session.identity.run_uuid,"last_tick":0,
            "regions":{r:self._initial_region(r) for r in sorted(self.cfg["regions"])},
            "fronts":{}}
        ev=f"WEATHER_INIT:{self.session.store.revision}"
        r=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(
            Delta(Domain.RUNTIME_STATE,WEATHER_STATE_KEY,st,Authority.SYSTEM_INIT,"REGIONAL_WEATHER_INIT",
                  source_event_id=ev,provenance="REGIONAL_WEATHER_RUNTIME"),
        ),event_id=ev,cause="REGIONAL_WEATHER_INIT",expected_state_revision=self.session.store.revision))
        if not isinstance(r,CommitRecord): raise RuntimeError("WEATHER_INIT_REJECTED")
        return True

    def snapshot(self,region):
        st=self._state()
        if region not in st["regions"]: raise RuntimeError("WEATHER_REGION_UNKNOWN")
        return copy.deepcopy(st["regions"][region])
    def for_location(self,location_id):
        return self.snapshot(self.catalog.location(location_id)["region_id"])
    def climate_key_for_location(self,location_id):
        return self.cfg["weather_to_physiology"][self.for_location(location_id)["weather_id"]]
    def pressure_tags_for_location(self,location_id):
        wid=self.for_location(location_id)["weather_id"]
        return tuple(self.cfg["weather_pressures"].get(wid,()))
    def _front_weather(self,st,region):
        candidates=[f for f in st["fronts"].values() if f["region_id"]==region]
        if not candidates:return None
        candidates.sort(key=lambda x:(-int(x["strength"]),x["front_id"]))
        return candidates[0]["weather_id"]
    def _relax(self,current,target,inertia_ppm):
        return int((int(current)*int(inertia_ppm)+int(target)*(1_000_000-int(inertia_ppm)))//1_000_000)
    def tick(self):
        now=WorldClock(self.session).seconds; st=self._state()
        tick_seconds=int(self.cfg["tick_seconds"])
        prior_slot=int(st["last_tick"])//tick_seconds
        current_slot=now//tick_seconds
        if current_slot<=prior_slot:return []
        changes=[]
        max_ticks=max(1,int(self.cfg.get("max_catchup_ticks",168)))
        # Very large imported/offscreen time jumps are bounded. Weather is a current
        # regional condition, not an obligation to replay years of hourly history.
        # The tail window remains deterministic for run+world-time and preserves
        # adjacency/front rules without pathological catch-up cost.
        start_slot=max(prior_slot+1,current_slot-max_ticks+1)
        if start_slot>prior_slot+1:
            st["fast_forwarded_ticks"]=int(st.get("fast_forwarded_ticks",0))+(start_slot-(prior_slot+1))
        for slot in range(start_slot,current_slot+1):
            t=slot*tick_seconds
            # Move existing fronts over real adjacency only, at a slower cadence.
            if t%int(self.cfg["front_move_interval_seconds"])==0:
                for fid in sorted(list(st["fronts"])):
                    f=st["fronts"][fid]
                    options=self.adj.get(f["region_id"],())
                    if options:
                        idx=self._hash(f"{self.session.identity.run_uuid}|{fid}|{t}|move")%len(options)
                        f["region_id"]=options[idx]; f["moved_at"]=t
                    f["strength"]=int(f["strength"])-1
                    if f["strength"]<=0: st["fronts"].pop(fid,None)
            # Rare deterministic front spawn.
            if len(st["fronts"])<int(self.cfg["fronts"]["max_active"]):
                roll=self._hash(f"{self.session.identity.run_uuid}|frontspawn|{slot}")%1_000_000
                if roll<int(self.cfg["fronts"]["spawn_chance_ppm_per_tick"]):
                    kinds=sorted(self.cfg["fronts"]["types"])
                    kind=kinds[self._hash(f"{self.session.identity.run_uuid}|frontkind|{slot}")%len(kinds)]
                    regions=sorted(self.cfg["regions"])
                    reg=regions[self._hash(f"{self.session.identity.run_uuid}|frontregion|{slot}")%len(regions)]
                    spec=self.cfg["fronts"]["types"][kind]
                    fid=f"front:{slot}:{kind}:{reg}"
                    st["fronts"][fid]={"front_id":fid,"kind":kind,"weather_id":spec["weather_id"],"strength":int(spec["strength"]),
                                      "region_id":reg,"spawned_at":t,"moved_at":t}
            # Region state transitions.
            for region in sorted(st["regions"]):
                cur=st["regions"][region]
                forced=self._front_weather(st,region)
                if forced:
                    wid=forced; source="FRONT"
                else:
                    base=self.cfg["transition_weights"][cur["weather_id"]].copy()
                    # Blend prior-state transition weights with regional climate preference.
                    rw=self.cfg["regions"][region]["weights"]
                    merged={k:max(0,int(base.get(k,0))*2+int(rw.get(k,0))) for k in set(base)|set(rw)}
                    wid=self._weighted(merged,f"{self.session.identity.run_uuid}|{region}|{slot}|transition")
                    source="TRANSITION"
                prof=self.profiles[wid]; regcfg=self.cfg["regions"][region]; inertia=self.cfg["physical_adjustment"]
                target_temp=(int(regcfg["baseline_temp_c"])+int(prof["temperature_c"]))//2
                target_humidity=max(10,min(100,int(regcfg["baseline_humidity"])+(int(prof["precipitation"])//4)))
                target_wind=max(int(regcfg["baseline_wind"]),int(prof["wind"]))
                nxt={"weather_id":wid,
                     "temperature_c":self._relax(cur["temperature_c"],target_temp,inertia["temperature_inertia_ppm"]),
                     "humidity":self._relax(cur["humidity"],target_humidity,inertia["humidity_inertia_ppm"]),
                     "wind":self._relax(cur["wind"],target_wind,inertia["wind_inertia_ppm"]),
                     "precipitation":int(prof["precipitation"]),"exposure_bp":int(prof["exposure_bp"]),
                     "changed_at":t if wid!=cur["weather_id"] else int(cur.get("changed_at",0)),"source":source}
                if nxt["weather_id"]!=cur["weather_id"]:
                    changes.append({"region_id":region,"from":cur["weather_id"],"to":wid,"at":t,"source":source})
                st["regions"][region]=nxt
            st["last_tick"]=t
        ev=f"WEATHER_TICK:{current_slot}:{self.session.store.revision}"
        r=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(
            Delta(Domain.RUNTIME_STATE,WEATHER_STATE_KEY,st,Authority.RULE_KERNEL,"REGIONAL_WEATHER_TICK",
                  source_event_id=ev,provenance="REGIONAL_WEATHER_RUNTIME"),
        ),event_id=ev,cause="REGIONAL_WEATHER_TICK",expected_state_revision=self.session.store.revision))
        if not isinstance(r,CommitRecord): raise RuntimeError("WEATHER_COMMIT_REJECTED")
        return changes
