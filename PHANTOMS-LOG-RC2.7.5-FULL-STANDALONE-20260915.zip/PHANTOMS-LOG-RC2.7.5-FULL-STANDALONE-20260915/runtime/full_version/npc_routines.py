from __future__ import annotations

from collections import deque
from hashlib import sha256
import copy, json

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage9.world_time import WORLD_TIME_RUNTIME_KEY, WorldClock
from runtime.stage9.actor_context import ACTOR_VISIBLE_RUNTIME_KEY

ROUTINE_STATE_KEY='__npc_routines__'

class NPCRoutineError(RuntimeError): pass


def _hash(text: str) -> int:
    return int.from_bytes(sha256(text.encode('utf-8')).digest()[:8], 'big')


class NPCRoutineRuntime:
    def __init__(self,catalog,session):
        self.catalog=catalog; self.session=session
        self.tables=json.loads((catalog.root/'content/full_version/npc_schedule_tables.json').read_text(encoding='utf-8'))
        if self.tables.get('schema')!='PH4NT0M5_NPC_SCHEDULE_TABLES_V1': raise NPCRoutineError('NPC_SCHEDULE_SCHEMA_INVALID')

    def _phase(self, second_of_day: int) -> str:
        for p in self.tables['phases']:
            if int(p['start']) <= second_of_day < int(p['end']): return p['phase_id']
        return 'rest'

    def _target_categories(self, role: str, phase: str) -> list[str]:
        if phase in {'night','rest'}: return ['__HOME__']
        rec=self.tables['role_targets'].get(role,self.tables['default_targets'])
        return list(rec.get(phase) or self.tables['default_targets'].get(phase) or [])

    def _choose_target(self, npc: dict, npc_id: str, *, phase: str, day: int) -> str:
        cats=self._target_categories(str(npc.get('role','')),phase)
        if cats==['__HOME__']: return str(npc.get('home_location_id') or npc.get('location_ref'))
        home_id=str(npc.get('home_location_id') or npc.get('location_ref'))
        home_region=str(self.catalog.location(home_id)['region_id'])
        social=npc.get('social_profile') if isinstance(npc.get('social_profile'),dict) else {}
        mobility=str(social.get('mobility_type','local_resident'))
        allowed_regions=None
        if mobility in {'local_resident','district_commuter','migrant_newcomer'}:
            allowed_regions={home_region}
        elif mobility=='regional_commuter':
            # Adjacent regions are derived from actual world-graph edges, never invented geography.
            allowed_regions={home_region}
            for loc in self.catalog.world['locations']:
                if loc['region_id']!=home_region: continue
                for ref in loc.get('connections',()):
                    allowed_regions.add(str(self.catalog.location(ref)['region_id']))
        options=[x['location_id'] for x in self.catalog.world['locations'] if x['primary_category'] in cats and (allowed_regions is None or x['region_id'] in allowed_regions)]
        if not options: return home_id
        options=sorted(options)
        return options[_hash(f'{self.session.identity.run_uuid}|{npc_id}|{day}|{phase}')%len(options)]

    def _next_step(self,start: str,target: str) -> str:
        if start==target: return start
        q=deque([(start,None)]); seen={start}; parent={}
        found=False
        while q:
            cur,_=q.popleft()
            for nxt in self.catalog.location(cur)['connections']:
                if nxt in seen: continue
                seen.add(nxt); parent[nxt]=cur
                if nxt==target: found=True; q.clear(); break
                q.append((nxt,cur))
        if not found: return start
        cur=target
        while parent.get(cur)!=start:
            cur=parent.get(cur)
            if cur is None: return start
        return cur

    def tick(self) -> int:
        now=WorldClock(self.session).seconds
        slot_seconds=int(self.tables['slot_seconds']); current_slot=now//slot_seconds
        prior=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,ROUTINE_STATE_KEY)
        if prior is None: prior={'run_uuid':self.session.identity.run_uuid,'processed_slot':-1,'targets':{}}
        if not isinstance(prior,dict) or prior.get('run_uuid')!=self.session.identity.run_uuid: raise NPCRoutineError('NPC_ROUTINE_STATE_INVALID')
        last=int(prior.get('processed_slot',current_slot))
        if current_slot<=last: return 0
        # Catch up deterministically, but cap pathological imported time jumps.
        slots=range(last+1,min(current_slot,last+96)+1)
        actors={k:self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,k) for k in list(self.session.store.runtime_state) if str(k).startswith('actor:npc:')}
        actors={k:copy.deepcopy(v) for k,v in actors.items() if isinstance(v,dict) and v.get('life_state')!='DEAD' and int(v.get('hp',1))>0}
        targets=copy.deepcopy(prior.get('targets') or {}); moves=0
        for slot in slots:
            t=slot*slot_seconds; day=t//int(self.tables['day_seconds']); sod=t%int(self.tables['day_seconds']); phase=self._phase(sod)
            for npc_id in sorted(actors):
                npc=actors[npc_id]
                target=self._choose_target(npc,npc_id,phase=phase,day=day)
                targets[npc_id]={'phase':phase,'target_location_id':target,'day':day}
                cur=str(npc.get('location_ref') or '')
                nxt=self._next_step(cur,target)
                if nxt!=cur:
                    npc['location_ref']=nxt; moves+=1
        deltas=[]; event=f'NPC_ROUTINE_TICK:{current_slot}:{self.session.store.revision}'
        visible=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,ACTOR_VISIBLE_RUNTIME_KEY)
        visible=copy.deepcopy(visible) if isinstance(visible,dict) else {'run_uuid':self.session.identity.run_uuid,'actors':{}}
        visible_dirty=False
        for npc_id,npc in actors.items():
            old=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,npc_id)
            if old!=npc:
                deltas.append(Delta(Domain.RUNTIME_STATE,npc_id,npc,Authority.RULE_KERNEL,'NPC_ROUTINE_MOVE',source_event_id=event,provenance='NPC_SCHEDULE'))
                if npc_id in visible.get('actors',{}):
                    visible['actors'][npc_id]['location_ref']=npc['location_ref']; visible_dirty=True
        if visible_dirty:
            deltas.append(Delta(Domain.RUNTIME_STATE,ACTOR_VISIBLE_RUNTIME_KEY,visible,Authority.RULE_KERNEL,'NPC_ROUTINE_VISIBLE_MIRROR',source_event_id=event,provenance='NPC_SCHEDULE'))
        state={'run_uuid':self.session.identity.run_uuid,'processed_slot':current_slot,'targets':targets}
        deltas.append(Delta(Domain.RUNTIME_STATE,ROUTINE_STATE_KEY,state,Authority.RULE_KERNEL,'NPC_ROUTINE_STATE',source_event_id=event,provenance='NPC_SCHEDULE'))
        result=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=tuple(deltas),event_id=event,cause='NPC_ROUTINE_TICK',expected_state_revision=self.session.store.revision))
        if not isinstance(result,CommitRecord): raise NPCRoutineError('NPC_ROUTINE_COMMIT_REJECTED')
        return moves

    def seek_home_for_shelter(self, npc_ids) -> int:
        """Move exposed NPCs one committed graph step toward their established home."""
        ids=sorted(set(str(x) for x in npc_ids))
        if not ids: return 0
        actors={}
        moves=0
        for npc_id in ids:
            rec=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,npc_id)
            if not isinstance(rec,dict) or rec.get('kind')!='actor' or rec.get('life_state')=='DEAD' or int(rec.get('hp',1))<=0: continue
            home=str(rec.get('home_location_id') or rec.get('location_ref') or '')
            cur=str(rec.get('location_ref') or '')
            if not home or not cur or home==cur: continue
            nxt=self._next_step(cur,home)
            if nxt!=cur:
                rec=copy.deepcopy(rec); rec['location_ref']=nxt; actors[npc_id]=rec; moves+=1
        if not actors: return 0
        event=f'NPC_SHELTER_SEEK:{WorldClock(self.session).seconds}:{self.session.store.revision}'
        visible=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,ACTOR_VISIBLE_RUNTIME_KEY)
        visible=copy.deepcopy(visible) if isinstance(visible,dict) else {'run_uuid':self.session.identity.run_uuid,'actors':{}}
        deltas=[]
        vis_dirty=False
        for npc_id,rec in actors.items():
            deltas.append(Delta(Domain.RUNTIME_STATE,npc_id,rec,Authority.RULE_KERNEL,'NPC_WEATHER_SHELTER_MOVE',source_event_id=event,provenance='NPC_NEEDS_WEATHER_RESPONSE'))
            if npc_id in visible.get('actors',{}):
                visible['actors'][npc_id]['location_ref']=rec['location_ref']; vis_dirty=True
        if vis_dirty:
            deltas.append(Delta(Domain.RUNTIME_STATE,ACTOR_VISIBLE_RUNTIME_KEY,visible,Authority.RULE_KERNEL,'NPC_WEATHER_SHELTER_VISIBLE',source_event_id=event,provenance='NPC_NEEDS_WEATHER_RESPONSE'))
        result=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=tuple(deltas),event_id=event,cause='NPC_WEATHER_SHELTER_MOVE',expected_state_revision=self.session.store.revision))
        if not isinstance(result,CommitRecord): raise NPCRoutineError('NPC_SHELTER_COMMIT_REJECTED')
        return moves

    def wait(self, seconds: int) -> int:
        if isinstance(seconds,bool) or not isinstance(seconds,int) or seconds<=0 or seconds>86400: raise NPCRoutineError('WAIT_SECONDS_INVALID')
        before=WorldClock(self.session).seconds; event=f'WAIT:{before}:{seconds}:{self.session.store.revision}'
        result=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(Delta(Domain.RUNTIME_STATE,WORLD_TIME_RUNTIME_KEY,{'run_uuid':self.session.identity.run_uuid,'seconds':before+seconds},Authority.WORLD_TIME,'STAGE9_ADVANCE_WORLD_TIME',source_event_id=event,provenance='PLAYER_WAIT'),),event_id=event,cause='PLAYER_WAIT',expected_state_revision=self.session.store.revision))
        if not isinstance(result,CommitRecord): raise NPCRoutineError('WAIT_COMMIT_REJECTED')
        self.tick(); return seconds
