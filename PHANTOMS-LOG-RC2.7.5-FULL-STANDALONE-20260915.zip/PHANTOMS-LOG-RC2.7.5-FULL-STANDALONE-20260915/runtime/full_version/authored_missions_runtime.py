from __future__ import annotations
import copy, json
from hashlib import sha256
from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage9.world_time import WorldClock
from runtime.full_version.bootstrap import PLAYER_ACTOR_INSTANCE_ID

class AuthoredMissionRuntimeError(RuntimeError): pass

class AuthoredMissionRuntime:
    def __init__(self,catalog,session):
        self.catalog=catalog; self.session=session
        self.templates={}
        for path in sorted((catalog.root/'content/full_version').glob('authored_missions_*.json')):
            raw=json.loads(path.read_text(encoding='utf-8'))
            if raw.get('schema')!='PH4NT0M5_AUTHORED_MISSIONS_V1':
                raise AuthoredMissionRuntimeError('AUTHORED_MISSION_SCHEMA_INVALID')
            for mission in raw.get('missions', []):
                mid=str(mission.get('id') or '')
                if not mid:
                    raise AuthoredMissionRuntimeError('AUTHORED_MISSION_ID_REQUIRED')
                if mid in self.templates:
                    raise AuthoredMissionRuntimeError('AUTHORED_MISSION_ID_DUPLICATE')
                self.templates[mid]=mission

    def _commit(self,deltas,event,cause):
        result=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=tuple(deltas),event_id=event,cause=cause,expected_state_revision=self.session.store.revision))
        if not isinstance(result,CommitRecord): raise AuthoredMissionRuntimeError(cause+'_COMMIT_REJECTED')
        return result

    def materialize(self,template_id,*,source_ref,location_id,actor_id=PLAYER_ACTOR_INSTANCE_ID,issuer_actor_id=None):
        if template_id not in self.templates: raise AuthoredMissionRuntimeError('AUTHORED_MISSION_TEMPLATE_UNKNOWN')
        if not source_ref or not location_id: raise AuthoredMissionRuntimeError('AUTHORED_MISSION_WORLD_REFERENCE_REQUIRED')
        source=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,str(source_ref))
        if not isinstance(source,dict): raise AuthoredMissionRuntimeError('AUTHORED_MISSION_SOURCE_NOT_FOUND')
        try: self.catalog.location(str(location_id))
        except Exception as exc: raise AuthoredMissionRuntimeError('AUTHORED_MISSION_LOCATION_NOT_FOUND') from exc
        t=self.templates[template_id]
        qid='quest:authored:'+sha256(f'{self.session.identity.run_uuid}|{template_id}|{source_ref}|{location_id}'.encode()).hexdigest()[:20]
        existing=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
        if isinstance(existing,dict): return qid,existing
        rec={'run_uuid':self.session.identity.run_uuid,'kind':'quest','template_id':template_id,'mission_family':t['mission_family'],'state':'AVAILABLE','issuer_actor_id':str(issuer_actor_id or source_ref),'offeree_actor_id':actor_id,'offered_at':WorldClock(self.session).seconds,'target_location_id':str(location_id),'source_ref':str(source_ref),'display_name':t['title'],'objectives':[],'outcomes':['full_success','success_with_cost','partial_success','failure','critical_failure'],'progress':{},'mission_attempts':[],'authored_mission':True,'class_lock':False,'profession_lock':False}
        event='AUTHORED_MISSION_OFFER:'+qid
        self._commit((Delta(Domain.RUNTIME_STATE,qid,rec,Authority.RULE_KERNEL,'AUTHORED_MISSION_OFFER',source_event_id=event,provenance='AUTHORED_MISSION_CONTENT'),),event,'AUTHORED_MISSION_OFFER')
        return qid,self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
