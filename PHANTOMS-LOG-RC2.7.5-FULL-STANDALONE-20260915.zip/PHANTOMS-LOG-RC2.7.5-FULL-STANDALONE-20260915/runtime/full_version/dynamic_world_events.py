from __future__ import annotations
import copy,json
from hashlib import blake2b

from runtime.stage3a.kernel import Authority,CommitRecord,Delta,Domain,Mode,Proposal
from runtime.stage9.world_time import WorldClock,WORLD_TIME_RUNTIME_KEY
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.effects import EffectProposal,EffectType,AuthorityDomain
from runtime.stage9.authority import StateAuthority,AuthorityStatus
from runtime.stage9.scheduler import SchedulerCommitAdapter,SchedulerQueue

EVENT_STATE_KEY="__dynamic_world_events__"
LIFECYCLE_EVENT_TYPE="DYNAMIC_WORLD_LIFECYCLE"


class DynamicWorldEventRuntime:
    """Run-bound dynamic-event director plus read-only consequence projection.

    Event generation and lifecycle remain canonical runtime state.  Presentation never
    mutates state and receives only observable consequence records, never causal tags,
    hidden preconditions or director data.
    """
    def __init__(self,catalog,session):
        self.catalog=catalog; self.session=session
        self.t=json.loads((catalog.root/"content/full_version/dynamic_world_event_tables.json").read_text())
        if self.t.get("schema")!="PH4NT0M5_DYNAMIC_WORLD_EVENTS_V1": raise RuntimeError("DYNAMIC_EVENT_SCHEMA_INVALID")
        types={str(x["id"]) for x in self.t.get("event_types",())}
        profiles=self.t.get("consequence_profiles")
        if not isinstance(profiles,dict) or set(profiles)!=types:
            raise RuntimeError("DYNAMIC_EVENT_CONSEQUENCE_PROFILE_COVERAGE_INVALID")
        self.registry=RunActorRegistry(session)
        self.authority=StateAuthority(session,actor_registry=self.registry)
        self.scheduler=SchedulerCommitAdapter(session)
        self.queue=SchedulerQueue(session)

    def _state(self):
        x=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,EVENT_STATE_KEY)
        if x is None:return {"run_uuid":self.session.identity.run_uuid,"last_tick":0,"budget":100,"last_event_time":-10**9,"events":{}}
        if not isinstance(x,dict) or x.get("run_uuid")!=self.session.identity.run_uuid:raise RuntimeError("DYNAMIC_EVENT_RUN_MISMATCH")
        return copy.deepcopy(x)

    def _h(self,s):return int.from_bytes(blake2b(s.encode(),digest_size=8).digest(),"big")

    def _tags(self,loc):
        rec=self.catalog.location(loc); return set(self.t["category_tags"].get(rec["primary_category"],[]))

    def eligible(self,loc,pressures=(),population_context=None):
        tags=self._tags(loc)|set(pressures)
        # Static location categories describe where people may normally be found, but
        # the playable director can supply a real population context.  When present,
        # that context owns the population_present precondition.
        pop_tag=str(self.t.get("population_preconditions",{}).get("population_tag","population_present"))
        if population_context is not None:
            tags.discard(pop_tag)
            expected=int(population_context.get("expected_present",0))
            living=int(population_context.get("explicit_living_npcs",0))
            mult=int(population_context.get("population_presence_ppm",1_000_000))
            cfg=self.t.get("population_preconditions",{})
            baseline_ok=bool(cfg.get("allow_expected_population_without_named_npc",True)) and expected>=int(cfg.get("minimum_expected_present",1))
            named_ok=living>=int(cfg.get("minimum_explicit_living_npcs",1))
            if mult>0 and (baseline_ok or named_ok): tags.add(pop_tag)
        out=[]
        for e in self.t["event_types"]:
            req=set(e["requires"])
            if req<=tags:out.append(e)
        return out

    def _profile(self,event_type):
        p=self.t["consequence_profiles"].get(str(event_type))
        if not isinstance(p,dict): raise RuntimeError("DYNAMIC_EVENT_CONSEQUENCE_PROFILE_MISSING")
        return p

    def _schedule_marker(self,event_id,phase,due_world_time):
        sid=f"scheduled:{event_id}:{phase}"
        payload={
            "scheduled_event_id":sid,
            "event_type":LIFECYCLE_EVENT_TYPE,
            "due_world_time":int(due_world_time),
            "sequence_key":sid,
            "payload":{"world_event_id":event_id,"phase":phase},
        }
        prop=EffectProposal(
            effect_id=f"effect:{sid}",run_uuid=self.session.identity.run_uuid,
            resolution_id=f"resolution:{sid}",source_action_id=f"dynamic-world:{event_id}",
            effect_type=EffectType.SCHEDULE_EVENT,target_ref=sid,payload=payload,
            authority_domain=AuthorityDomain.SCHEDULER,expected_state_revision=self.session.store.revision,
        )
        dec=self.authority.authorize(prop)
        if dec.status!=AuthorityStatus.ALLOW: raise RuntimeError("DYNAMIC_EVENT_SCHEDULE_AUTHORITY_REJECTED")
        result=self.scheduler.apply(dec,commit_id=f"commit:{sid}",event_id=f"schedule:{sid}")
        if not isinstance(result,CommitRecord): raise RuntimeError("DYNAMIC_EVENT_SCHEDULE_COMMIT_REJECTED")
        return sid

    def _cancel_marker(self,sid):
        if self.queue.get(sid) is None:return
        prop=EffectProposal(
            effect_id=f"effect:cancel:{sid}",run_uuid=self.session.identity.run_uuid,
            resolution_id=f"resolution:cancel:{sid}",source_action_id=f"dynamic-world-cancel:{sid}",
            effect_type=EffectType.CANCEL_EVENT,target_ref=sid,payload={"scheduled_event_id":sid},
            authority_domain=AuthorityDomain.SCHEDULER,expected_state_revision=self.session.store.revision,
        )
        dec=self.authority.authorize(prop)
        if dec.status!=AuthorityStatus.ALLOW: raise RuntimeError("DYNAMIC_EVENT_CANCEL_AUTHORITY_REJECTED")
        result=self.scheduler.apply(dec,commit_id=f"commit:cancel:{sid}",event_id=f"cancel:{sid}")
        if not isinstance(result,CommitRecord): raise RuntimeError("DYNAMIC_EVENT_CANCEL_COMMIT_REJECTED")

    def _commit_state(self,st,cause):
        # Bound terminal history so long-running saves do not grow without limit.
        expired=[(int(v.get("expired_world_time",0)),k) for k,v in st.get("events",{}).items() if isinstance(v,dict) and v.get("status")=="EXPIRED"]
        keep=int(self.t.get("lifecycle",{}).get("max_retained_expired",128))
        for _,key in sorted(expired)[:-keep] if len(expired)>keep else ():
            st["events"].pop(key,None)
        event=f"{cause}:{WorldClock(self.session).seconds}:{self.session.store.revision}"
        r=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(
            Delta(Domain.RUNTIME_STATE,EVENT_STATE_KEY,st,Authority.RULE_KERNEL,cause,source_event_id=event,provenance="DYNAMIC_WORLD_EVENTS"),
        ),event_id=event,cause=cause,expected_state_revision=self.session.store.revision))
        if not isinstance(r,CommitRecord):raise RuntimeError("DYNAMIC_WORLD_EVENT_COMMIT_REJECTED")
        return r

    def _set_consequence_phase(self,rec,phase,now):
        profile=self._profile(rec["event_type"])
        prior=rec.get("consequence_state") if isinstance(rec.get("consequence_state"),dict) else {}
        seeded=bool(prior.get("rumor_seeded",False))
        if phase=="ACTIVE":
            state={
                "phase":"ACTIVE","phase_world_time":int(now),
                "visual_trace":str(profile.get("active_visual",'')),
                "audio_trace":str(profile.get("active_audio",'')),
                "effects":copy.deepcopy(profile.get("active_effects",{})),
                "rumor_seeded":seeded,
            }
        elif phase=="AFTERMATH":
            state={
                "phase":"AFTERMATH","phase_world_time":int(now),
                "visual_trace":str(profile.get("aftermath_visual",'')),
                "audio_trace":"",
                "effects":copy.deepcopy(profile.get("aftermath_effects",{})),
                "rumor_seeded":seeded,
            }
        elif phase=="EXPIRED":
            residual=max(0,int(profile.get("residual_seconds",0)))
            state={
                "phase":"RESIDUAL","phase_world_time":int(now),
                "visual_trace":str(profile.get("residual_visual",'')),
                "audio_trace":"","effects":{},
                "residual_until":int(now)+residual,
                "rumor_seeded":seeded,
            }
        else:
            raise RuntimeError("DYNAMIC_EVENT_CONSEQUENCE_PHASE_INVALID")
        rec["consequence_state"]=state

    def process_due_lifecycle(self):
        due=[e for e in self.queue.dispatch_due().events if e.event_type==LIFECYCLE_EVENT_TYPE]
        processed=[]
        for marker in due:
            wid=str(marker.payload.get("world_event_id","")); phase=str(marker.payload.get("phase",""))
            st=self._state(); rec=st["events"].get(wid)
            if not isinstance(rec,dict):
                self._cancel_marker(marker.scheduled_event_id); continue
            now=WorldClock(self.session).seconds
            sev=rec["severity"]
            if phase=="ACTIVE" and rec.get("status")=="MATERIALIZED":
                rec["status"]="ACTIVE"; rec["activated_world_time"]=now
                self._set_consequence_phase(rec,"ACTIVE",now)
                self._commit_state(st,"DYNAMIC_WORLD_EVENT_ACTIVE")
                self._cancel_marker(marker.scheduled_event_id)
                self._schedule_marker(wid,"AFTERMATH",now+int(self.t["lifecycle"]["active_seconds_by_severity"][sev]))
                processed.append((wid,"ACTIVE"))
            elif phase=="AFTERMATH" and rec.get("status")=="ACTIVE":
                rec["status"]="AFTERMATH"; rec["aftermath_world_time"]=now
                self._set_consequence_phase(rec,"AFTERMATH",now)
                self._commit_state(st,"DYNAMIC_WORLD_EVENT_AFTERMATH")
                self._cancel_marker(marker.scheduled_event_id)
                self._schedule_marker(wid,"EXPIRED",now+int(self.t["lifecycle"]["aftermath_seconds_by_severity"][sev]))
                processed.append((wid,"AFTERMATH"))
            elif phase=="EXPIRED" and rec.get("status")=="AFTERMATH":
                rec["status"]="EXPIRED"; rec["expired_world_time"]=now
                self._set_consequence_phase(rec,"EXPIRED",now)
                self._commit_state(st,"DYNAMIC_WORLD_EVENT_EXPIRED")
                self._cancel_marker(marker.scheduled_event_id)
                processed.append((wid,"EXPIRED"))
            else:
                self._cancel_marker(marker.scheduled_event_id)
        return processed

    def tick(self,*,pressures_by_location=None,population_by_location=None,player_crisis=False):
        self.process_due_lifecycle()
        now=WorldClock(self.session).seconds; st=self._state()
        interval=max(1,int(self.t["director"].get("evaluation_interval_seconds",900)))
        if now//interval<=int(st["last_tick"])//interval:return []
        elapsed=max(0,now-int(st["last_tick"])); st["budget"]=min(200,int(st["budget"])+(elapsed*self.t["director"]["quiet_gain_per_hour"])//3600)
        created=[]
        locations=sorted(x["location_id"] for x in self.catalog.world["locations"])
        start=self._h(f"{self.session.identity.run_uuid}|{now//1800}")%len(locations)
        locations=locations[start:]+locations[:start]
        for loc in locations:
            if len(created)>=self.t["director"]["max_materialized_per_tick"]:break
            raw_pressure=(pressures_by_location or {}).get(loc,())
            if isinstance(raw_pressure,dict):
                ps=set(raw_pressure.get("tags",()))
                parents_by_tag={str(k):tuple(str(x) for x in v) for k,v in (raw_pressure.get("parents_by_tag") or {}).items()}
            else:
                ps=set(raw_pressure); parents_by_tag={}
            popctx=(population_by_location or {}).get(loc) if population_by_location is not None else None
            candidates=self.eligible(loc,ps,population_context=popctx)
            if not candidates:continue
            candidates=sorted(candidates,key=lambda e:e["id"])
            total=sum(int(e["weight"]) for e in candidates)
            roll=self._h(f"{self.session.identity.run_uuid}|{loc}|{now//1800}|event")%max(1,total)
            chosen=None
            for e in candidates:
                roll-=int(e["weight"])
                if roll<0:chosen=e;break
            sev=chosen["severity"]; cost=int(self.t["director"]["event_cost"][sev])
            if player_crisis and sev in {"major","critical"}: cost=(cost*1_000_000)//self.t["director"]["recent_player_crisis_multiplier_ppm"]
            breath=int(self.t["director"]["breather_seconds"][sev])
            if st["budget"]<cost or now-int(st["last_event_time"])<breath:continue
            parent_candidates=[]
            for tag in chosen.get("requires",()): parent_candidates.extend(parents_by_tag.get(str(tag),()))
            parent_candidates=sorted(set(parent_candidates))
            parent_id=parent_candidates[0] if parent_candidates else None
            chain_depth=0; root_id=None
            if parent_id:
                parent=st["events"].get(parent_id)
                if not isinstance(parent,dict): parent_id=None
                else:
                    chain_depth=int(parent.get("chain_depth",0))+1
                    root_id=str(parent.get("root_event_id") or parent_id)
                    if chain_depth>int(self.t["director"].get("max_chain_depth",4)): continue
                    children=[x for x in st["events"].values() if isinstance(x,dict) and x.get("parent_event_id")==parent_id and x.get("status")!="EXPIRED"]
                    if len(children)>=int(self.t["director"].get("max_children_per_parent",2)): continue
                    if any(x.get("event_type")==chosen["id"] for x in children): continue
            eid=f"world_event:{now}:{loc}:{chosen['id']}"
            st["events"][eid]={"event_id":eid,"event_type":chosen["id"],"severity":sev,"location_id":loc,
              "created_world_time":now,"status":"MATERIALIZED","causal_tags":sorted(self._tags(loc)|ps),
              "parent_event_id":parent_id,"root_event_id":root_id or eid,"chain_depth":chain_depth,
              "player_targeted":False,"presentation":"UNSEEN"}
            st["budget"]-=cost; st["last_event_time"]=now; created.append(copy.deepcopy(st["events"][eid]))
        st["last_tick"]=now
        self._commit_state(st,"DYNAMIC_WORLD_EVENT_TICK")
        for rec in created:
            self._schedule_marker(rec["event_id"],"ACTIVE",now+int(self.t["lifecycle"]["activation_delay_seconds"]))
        return created

    def events_at(self,location_id,*,include_expired=False):
        vals=[v for v in self._state()["events"].values() if v["location_id"]==location_id]
        if not include_expired: vals=[v for v in vals if v.get("status")!="EXPIRED"]
        return tuple(vals)

    def _weather_masks(self,weather_id):
        cfg=self.t.get("perception_conditions",{})
        am=int(cfg.get("weather_audio_mask",{}).get(str(weather_id),0))
        vm=int(cfg.get("weather_visual_mask",{}).get(str(weather_id),0))
        margin=max(0,int(cfg.get("minimum_detect_margin",1)))
        return am,vm,margin

    def perceived_consequences_at(self,location_id,*,weather_id="WX_CLEAR",detail=False):
        """Return only same-location, physically observable consequence projections."""
        now=WorldClock(self.session).seconds
        audio_mask,visual_mask,margin=self._weather_masks(weather_id)
        out=[]
        for rec in sorted(self.events_at(location_id,include_expired=True),key=lambda x:(int(x.get("created_world_time",0)),x.get("event_id",""))):
            status=str(rec.get("status",""))
            state=rec.get("consequence_state") if isinstance(rec.get("consequence_state"),dict) else None
            if not state: continue
            if status=="EXPIRED" and now>int(state.get("residual_until",-1)): continue
            profile=self._profile(rec["event_type"])
            visual=str(state.get("visual_trace",''))
            audio=str(state.get("audio_trace",''))
            if int(profile.get("visual_prominence",0))-visual_mask<margin: visual=""
            if int(profile.get("audio_loudness",0))-audio_mask<margin: audio=""
            if status!="ACTIVE": audio=""
            if not visual and not audio: continue
            projected={
                "event_id":str(rec["event_id"]),"phase":str(state.get("phase",status)),
                "severity":str(rec.get("severity","ambient")),"visual":visual,"audio":audio,
                "age_seconds":max(0,now-int(state.get("phase_world_time",now))),
            }
            if detail:
                projected["effects_visible"]={k:int(v) for k,v in state.get("effects",{}).items() if k in {"route_delay_seconds","route_capacity_ppm","market_price_multiplier_ppm","service_capacity_ppm","security_presence_ppm","population_presence_ppm","social_tension_ppm"}}
            out.append(projected)
        cap=int(self.t.get("perception_conditions",{}).get("look_max_traces" if detail else "arrival_max_traces",6 if detail else 3))
        return tuple(out[:max(0,cap)])

    def effects_at(self,location_id):
        """Aggregate canonical active/aftermath mechanical consequences for one location."""
        agg={
            "market_price_multiplier_ppm":1_000_000,"service_capacity_ppm":1_000_000,
            "route_capacity_ppm":1_000_000,"route_delay_seconds":0,
            "security_presence_ppm":1_000_000,"population_presence_ppm":1_000_000,
            "social_tension_ppm":1_000_000,
        }
        for rec in self.events_at(location_id):
            state=rec.get("consequence_state") if isinstance(rec.get("consequence_state"),dict) else None
            if not state or state.get("phase") not in {"ACTIVE","AFTERMATH"}: continue
            for key,value in state.get("effects",{}).items():
                if key not in agg: continue
                iv=int(value)
                if key=="route_delay_seconds": agg[key]=max(agg[key],max(0,iv))
                else: agg[key]=max(250_000,min(3_000_000,(agg[key]*iv)//1_000_000))
        return agg


    def secondary_pressure_context(self,location_id):
        """Derive bounded causal pressure tags from active/aftermath event effects.

        The returned parent mapping lets newly materialized events retain provenance
        instead of becoming unexplained recursive noise.
        """
        thresholds=self.t.get("secondary_pressure_thresholds",{})
        tags=set(); parents_by_tag={}
        for rec in self.events_at(location_id):
            state=rec.get("consequence_state") if isinstance(rec.get("consequence_state"),dict) else None
            if not state or state.get("phase") not in {"ACTIVE","AFTERMATH"}: continue
            effects=state.get("effects",{})
            for key,rule in thresholds.items():
                if key not in effects: continue
                value=int(effects[key]); qualifies=True
                if "gte" in rule: qualifies=qualifies and value>=int(rule["gte"])
                if "lte" in rule: qualifies=qualifies and value<=int(rule["lte"])
                if not qualifies: continue
                for tag in rule.get("tags",()):
                    tag=str(tag); tags.add(tag); parents_by_tag.setdefault(tag,[]).append(str(rec["event_id"]))
        return {"tags":tuple(sorted(tags)),"parents_by_tag":{k:tuple(sorted(set(v))) for k,v in parents_by_tag.items()}}

    def service_capacity_ppm(self,location_id):
        return int(self.effects_at(location_id)["service_capacity_ppm"])

    def security_presence_ppm(self,location_id):
        return int(self.effects_at(location_id)["security_presence_ppm"])

    def population_presence_ppm(self,location_id):
        return int(self.effects_at(location_id)["population_presence_ppm"])

    def social_tension_ppm(self,location_id):
        return int(self.effects_at(location_id)["social_tension_ppm"])

    def market_price_multiplier_ppm(self,location_id):
        return int(self.effects_at(location_id)["market_price_multiplier_ppm"])

    def route_delay_seconds(self,location_id):
        return int(self.effects_at(location_id)["route_delay_seconds"])

    def apply_route_delay(self,origin_location_id,destination_location_id):
        """Advance canonical world time for an actually traversed disrupted route."""
        seconds=max(self.route_delay_seconds(origin_location_id),self.route_delay_seconds(destination_location_id))
        if seconds<=0: return 0
        before=WorldClock(self.session).seconds
        event=f"DYNAMIC_ROUTE_DELAY:{origin_location_id}:{destination_location_id}:{before}:{self.session.store.revision}"
        r=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(
            Delta(Domain.RUNTIME_STATE,WORLD_TIME_RUNTIME_KEY,{"run_uuid":self.session.identity.run_uuid,"seconds":before+seconds},
                  Authority.WORLD_TIME,"DYNAMIC_WORLD_ROUTE_DELAY",source_event_id=event,provenance="DYNAMIC_WORLD_EVENTS"),
        ),event_id=event,cause="DYNAMIC_WORLD_ROUTE_DELAY",expected_state_revision=self.session.store.revision))
        if not isinstance(r,CommitRecord): raise RuntimeError("DYNAMIC_ROUTE_DELAY_COMMIT_REJECTED")
        return seconds

    def seedable_rumors(self):
        """Public rumor seeds only for events that have physically begun and are not expired."""
        out=[]
        for rec in self._state()["events"].values():
            if rec.get("status") not in {"ACTIVE","AFTERMATH"}: continue
            state=rec.get("consequence_state") if isinstance(rec.get("consequence_state"),dict) else None
            if not state or state.get("rumor_seeded"): continue
            text=str(self._profile(rec["event_type"]).get("rumor_text","")).strip()
            if text:
                out.append({"event_id":rec["event_id"],"location_id":rec["location_id"],"text":text,"severity":rec["severity"]})
        return tuple(sorted(out,key=lambda x:x["event_id"]))

    def mark_rumor_seeded(self,event_id):
        st=self._state(); rec=st.get("events",{}).get(str(event_id))
        if not isinstance(rec,dict): raise RuntimeError("DYNAMIC_EVENT_UNKNOWN")
        state=rec.get("consequence_state") if isinstance(rec.get("consequence_state"),dict) else None
        if not state: raise RuntimeError("DYNAMIC_EVENT_CONSEQUENCE_NOT_ACTIVE")
        if state.get("rumor_seeded"): return False
        state["rumor_seeded"]=True
        self._commit_state(st,"DYNAMIC_WORLD_EVENT_RUMOR_SEEDED")
        return True
