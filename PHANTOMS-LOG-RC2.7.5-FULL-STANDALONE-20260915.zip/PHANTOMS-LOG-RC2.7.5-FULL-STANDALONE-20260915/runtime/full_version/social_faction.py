from __future__ import annotations
import copy, json
from hashlib import sha256
from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage9.world_time import WorldClock

SOCIAL_STATE_KEY="__social_faction_runtime__"

def _clamp(v,a=-100,b=100): return max(a,min(b,int(v)))
def _h(s): return int.from_bytes(sha256(s.encode("utf-8")).digest()[:8],"big")

class SocialFactionRuntime:
    def __init__(self,catalog,session):
        self.catalog=catalog; self.session=session
        self.tables=json.loads((catalog.root/"content/full_version/social_faction_tables.json").read_text(encoding="utf-8"))
        if self.tables.get("schema")!="PH4NT0M5_SOCIAL_FACTION_TABLES_V1": raise RuntimeError("SOCIAL_FACTION_SCHEMA_INVALID")

    def state(self):
        s=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,SOCIAL_STATE_KEY)
        if s is None:
            return {"run_uuid":self.session.identity.run_uuid,"relationships":{},"reputation":{"npc":{},"household":{},"faction":{},"region":{}},"rumors":{},"legal_events":[]}
        if not isinstance(s,dict) or s.get("run_uuid")!=self.session.identity.run_uuid: raise RuntimeError("SOCIAL_FACTION_STATE_INVALID")
        return copy.deepcopy(s)

    def _commit(self,s,cause):
        ev=f"{cause}:{self.session.store.revision}"
        r=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,
          deltas=(Delta(Domain.RUNTIME_STATE,SOCIAL_STATE_KEY,s,Authority.RULE_KERNEL,cause,source_event_id=ev,provenance="SOCIAL_FACTION_RUNTIME"),),
          event_id=ev,cause=cause,expected_state_revision=self.session.store.revision))
        if not isinstance(r,CommitRecord): raise RuntimeError("SOCIAL_FACTION_COMMIT_REJECTED")
        return r

    def relationship(self,a,b):
        s=self.state(); key="|".join(sorted((str(a),str(b))))
        return copy.deepcopy(s["relationships"].get(key,self.tables["relationship_types"]["stranger"]))

    def apply_event(self,actor_id,target_id,event_type,*,region_id="",household_id="",faction_id="",event_id=""):
        s=self.state(); key="|".join(sorted((str(actor_id),str(target_id))))
        cur=copy.deepcopy(s["relationships"].get(key,self.tables["relationship_types"]["stranger"]))
        effect=self.tables["event_effects"].get(str(event_type),{})
        for k,v in effect.items(): cur[k]=_clamp(cur.get(k,0)+int(v))
        s["relationships"][key]=cur
        # Reputation consequences are bounded and scoped; NPC is strongest, wider scopes attenuate.
        mapping={"npc":target_id,"household":household_id,"faction":faction_id,"region":region_id}
        rep_delta={"standing":int(effect.get("respect",0)),"trust":int(effect.get("trust",0)),"fear":int(effect.get("fear",0)),"notoriety":abs(int(effect.get("grievance",0)))//3}
        for scope,ref in mapping.items():
            if not ref: continue
            rec=copy.deepcopy(s["reputation"][scope].get(str(ref),{"standing":0,"trust":0,"fear":0,"notoriety":0}))
            divisor={"npc":1,"household":2,"faction":3,"region":4}[scope]
            for k,v in rep_delta.items(): rec[k]=_clamp(rec.get(k,0)+(v//divisor))
            s["reputation"][scope][str(ref)]=rec
        self._commit(s,"SOCIAL_EVENT")
        return cur

    def reputation(self,scope,ref):
        return copy.deepcopy(self.state()["reputation"].get(scope,{}).get(str(ref),{"standing":0,"trust":0,"fear":0,"notoriety":0}))

    def can_trade(self,npc_id):
        r=self.relationship("actor:player",npc_id); th=self.tables["service_thresholds"]
        return not (int(r.get("trust",0))<=int(th["trade_refusal_trust"]) or int(r.get("grievance",0))>=int(th["trade_refusal_grievance"]))

    def price_multiplier_ppm(self,npc_id):
        r=self.relationship("actor:player",npc_id); trust=int(r.get("trust",0)); grievance=int(r.get("grievance",0))
        return max(750000,min(1500000,1000000-trust*3500+grievance*4500))

    def seed_rumor(self,rumor_id,source_actor_id,text,confidence=70):
        s=self.state()
        s["rumors"][str(rumor_id)]={"text":str(text),"holders":{str(source_actor_id):{"confidence":max(0,min(100,int(confidence))),"hop":0,"received_at":WorldClock(self.session).seconds}}}
        self._commit(s,"RUMOR_SEED")

    def rumors_for(self,actor_id):
        out=[]
        for rid,r in self.state()["rumors"].items():
            h=r.get("holders",{}).get(str(actor_id))
            if h: out.append({"rumor_id":rid,"text":r.get("text",""),**h})
        return out

    def propagate_here(self,actors,*,social_tension_ppm=1_000_000):
        actors=[x for x in actors if isinstance(x,dict) and x.get("actor_instance_id")]
        if len(actors)<2: return 0
        s=self.state(); changed=0; rules=self.tables["rumor"]
        for rid,rum in s["rumors"].items():
            holders=rum.setdefault("holders",{})
            for src in actors:
                sid=src["actor_instance_id"]
                if sid not in holders: continue
                sh=holders[sid]; hop=int(sh.get("hop",0))
                # A freshly received rumor cannot be retransmitted in the same 15-minute contact window.
                bucket_start=(WorldClock(self.session).seconds//900)*900
                if int(sh.get("received_at",0))>=bucket_start: continue
                if hop>=int(rules["max_hops"]): continue
                for dst in actors:
                    did=dst["actor_instance_id"]
                    if did==sid or did in holders: continue
                    chance=int(rules["base_transfer_ppm"])
                    tension=max(500_000,min(2_000_000,int(social_tension_ppm)))
                    chance=(chance*tension)//1_000_000
                    ss=src.get("social_profile") or {}; ds=dst.get("social_profile") or {}
                    if ss.get("household_ref") and ss.get("household_ref")==ds.get("household_ref"): chance+=int(rules["same_household_bonus_ppm"])
                    if src.get("faction_id") and src.get("faction_id")==dst.get("faction_id"): chance+=int(rules["same_faction_bonus_ppm"])
                    rel=self.relationship(sid,did)
                    if int(rel.get("trust",0))>=25: chance+=int(rules["friend_bonus_ppm"])
                    roll=_h(f"{self.session.identity.run_uuid}|{rid}|{sid}|{did}|{WorldClock(self.session).seconds//900}")%1000000
                    if roll<min(1000000,chance):
                        conf=max(int(rules["minimum_confidence"]),int(sh["confidence"])-(hop+1)*int(rules["decay_ppm_per_hop"])//10000)
                        holders[did]={"confidence":max(0,min(100,conf)),"hop":hop+1,"received_at":WorldClock(self.session).seconds,"source_actor_id":sid}
                        changed+=1
        if changed: self._commit(s,"RUMOR_PROPAGATION")
        return changed

    def record_legal_event(self,event_type,accused_actor_id,region_id,witness_ids,event_id,*,security_presence_ppm=1_000_000):
        law=self.tables["legal_event_map"].get(str(event_type))
        if not law: return None
        s=self.state()
        security=max(250_000,min(3_000_000,int(security_presence_ppm)))
        witnesses=list(dict.fromkeys(witness_ids))
        rec={"event_type":event_type,"law_id":law,"accused_actor_id":accused_actor_id,"region_id":region_id,
             "witness_ids":witnesses,"event_id":event_id,"observed_at":WorldClock(self.session).seconds,
             "security_presence_ppm":security,
             "status":("SECURITY_ALERTED" if witnesses and security>=1_250_000 else ("EVIDENCE_ONLY" if witnesses else "UNOBSERVED"))}
        s["legal_events"].append(rec); self._commit(s,"LEGAL_EVENT_RECORD"); return rec
