from __future__ import annotations

"""Runtime bridge from canonical character capabilities to gameplay actions.

This module is deliberately small and deterministic.  It does not decide world
truth or mutate state.  It answers one question before a gameplay resolver is
allowed to act: *is this method currently reliable, uncertain, extreme,
physically impossible, or unavailable to this character?*

Natural/current stat limits are checked before skills, talents, expertise,
tools or luck.  SAFE never means an opposed action automatically succeeds; it
only means the actor can execute their own part reliably.
"""

from dataclasses import dataclass
from hashlib import sha256
from typing import Iterable, Mapping

from .capability_catalog import SKILLS, STATS, TALENTS
from .capability_resolution import CapabilityResult, CapabilityZone, StageDemand, assess_skill
from .effective_stats import effective_skill, effective_stat


@dataclass(frozen=True, slots=True)
class ActionCapability:
    skill_id: str
    difficulty: int
    result: CapabilityResult
    talent_id: str | None
    expertise_bonus: int
    situational_bonus: int
    opposition_penalty: int

    @property
    def zone(self) -> CapabilityZone:
        return self.result.zone

    @property
    def roll_required(self) -> bool:
        return self.zone in {CapabilityZone.EDGE, CapabilityZone.EXTREME}

    @property
    def blocked(self) -> bool:
        return self.zone in {CapabilityZone.HARD_LIMIT, CapabilityZone.INACCESSIBLE}

    @property
    def completed_stages(self) -> tuple[str, ...]:
        return tuple(x.stage for x in self.result.stages if x.passed_information and x.zone != CapabilityZone.HARD_LIMIT)

    @property
    def failure_stage(self) -> str | None:
        return self.result.failure_stage

    @property
    def explanation(self) -> str:
        return explain_capability(self)


def _difficulty_hard_minimum(difficulty: int) -> int:
    """Conservative hard-limit floor for generic gameplay tasks.

    Difficulty measures how demanding the *application* is.  It must not turn
    directly into a stat check, otherwise skill difficulty would silently
    rewrite biology.  The mapping is intentionally coarse and low; specific
    actions may pass an explicit hard minimum when physics requires one.
    """
    d=max(0,int(difficulty))
    if d <= 1: return 1
    if d <= 3: return 2
    if d <= 5: return 3
    if d <= 7: return 4
    if d <= 9: return 5
    return 6


def demands_for_skill(skill_id: str, difficulty: int, *,
                      hard_minimum: int | None = None,
                      stage_difficulty: Mapping[str,int] | None = None,
                      stage_hard_minimums: Mapping[str,int] | None = None) -> tuple[StageDemand, ...]:
    skill_id=str(skill_id).upper()
    skill=SKILLS.get(skill_id)
    if skill is None:
        return ()
    base_hard=_difficulty_hard_minimum(difficulty) if hard_minimum is None else max(0,int(hard_minimum))
    stage_difficulty=stage_difficulty or {}
    stage_hard_minimums=stage_hard_minimums or {}
    out=[]
    for stage in skill.stages:
        minimum=max(0,int(stage_hard_minimums.get(stage.stage,base_hard)))
        out.append(StageDemand(
            stage=stage.stage,
            stat_minimums={stat_id:minimum for stat_id in stage.stats},
            difficulty=max(0,int(stage_difficulty.get(stage.stage,difficulty))),
        ))
    return tuple(out)


def _profile(actor: Mapping) -> Mapping:
    profile=actor.get('character_profile') if isinstance(actor,Mapping) else None
    return profile if isinstance(profile,Mapping) else {}


def effective_character(actor: Mapping) -> dict:
    """Flatten an actor into the canonical shape expected by capability_resolution."""
    profile=_profile(actor)
    return {
        'stats': {sid: effective_stat(dict(actor),sid) for sid in profile.get('stats',{}) if sid in STATS},
        'skills': {sid: effective_skill(dict(actor),sid) for sid in profile.get('skills',{}) if sid in SKILLS},
        'talents': list(profile.get('talents') or ()),
        'expertises': dict(profile.get('expertises') or {}),
    }


def _normalise_tags(tags: Iterable[str]) -> set[str]:
    out=set()
    for tag in tags:
        text=str(tag or '').strip().casefold()
        if not text: continue
        out.add(text)
        out.update(part for part in text.replace('_',' ').replace('-',' ').split() if part)
    return out


def applicable_talent(actor: Mapping, skill_id: str, context_tags: Iterable[str]=()) -> str | None:
    owned=set(str(x).upper() for x in (_profile(actor).get('talents') or ()))
    tags=_normalise_tags(context_tags)
    candidates=[]
    for tid in sorted(owned):
        talent=TALENTS.get(tid)
        if talent is None or skill_id not in talent.required_skills:
            continue
        situation_words=_normalise_tags(talent.situations)
        overlap=len(tags & situation_words)
        candidates.append((overlap,tid))
    if not candidates:
        return None
    candidates.sort(key=lambda x:(x[0],x[1]),reverse=True)
    # Talents are specialized applications, not passive bonuses to every use of
    # a prerequisite skill. They apply only when the situation actually matches.
    return candidates[0][1] if candidates[0][0] > 0 else None


def expertise_bonus(actor: Mapping, skill_id: str, context_tags: Iterable[str]=()) -> int:
    """Read validated-use expertises without allowing them to raise hard limits.

    Supported entries are intentionally simple and forward compatible:
      {"SKILL_TECHNOLOGY": 2}
      {"Hydraulik": {"level": 2, "skill_id": "SKILL_TECHNOLOGY", "tags": ["repair"]}}
    The bonus is capped; expertise is reliability, not superhuman potential.
    """
    exp=_profile(actor).get('expertises') or {}
    if not isinstance(exp,Mapping): return 0
    tags=_normalise_tags(context_tags)
    best=0
    for key,value in exp.items():
        if isinstance(value,(int,float)):
            if str(key).upper()==skill_id:
                best=max(best,int(value))
            continue
        if not isinstance(value,Mapping):
            continue
        exp_skill=str(value.get('skill_id') or '').upper()
        exp_tags=_normalise_tags(value.get('tags') or (str(key),))
        if exp_skill and exp_skill!=skill_id:
            continue
        if tags and exp_tags and not (tags & exp_tags):
            continue
        best=max(best,int(value.get('level',value.get('value',0)) or 0))
    return max(0,min(3,best))


def assess_action(actor: Mapping, skill_id: str, difficulty: int, *,
                  context_tags: Iterable[str]=(), tool_bonus: int=0,
                  opposition_penalty: int=0, hard_minimum: int | None=None,
                  stage_difficulty: Mapping[str,int] | None=None,
                  stage_hard_minimums: Mapping[str,int] | None=None) -> ActionCapability:
    skill_id=str(skill_id).upper()
    demands=demands_for_skill(skill_id,difficulty,hard_minimum=hard_minimum,
                              stage_difficulty=stage_difficulty,
                              stage_hard_minimums=stage_hard_minimums)
    if not demands:
        result=CapabilityResult(CapabilityZone.INACCESSIBLE,(),None,'UNKNOWN_SKILL')
        return ActionCapability(skill_id,int(difficulty),result,None,0,int(tool_bonus),int(opposition_penalty))
    snapshot=effective_character(actor)
    exp=expertise_bonus(actor,skill_id,context_tags)
    talent=applicable_talent(actor,skill_id,context_tags)
    talent_bonus=1 if talent else 0
    result=assess_skill(snapshot,skill_id,demands,
                        expertise_bonus=exp,
                        situational_bonus=int(tool_bonus)+talent_bonus,
                        opposition_penalty=int(opposition_penalty))
    return ActionCapability(skill_id,int(difficulty),result,talent,exp,int(tool_bonus)+talent_bonus,int(opposition_penalty))


def deterministic_uncertain_success(capability: ActionCapability, seed: str) -> tuple[bool,int,int]:
    """Resolve only the uncertainty inside EDGE/EXTREME.

    SAFE succeeds for unopposed execution. HARD_LIMIT/INACCESSIBLE never roll.
    Opposed actions should use the zone as a modifier in their own resolver.
    """
    if capability.zone == CapabilityZone.SAFE:
        return True,20,0
    if capability.blocked:
        return False,0,99
    roll=(int.from_bytes(sha256(str(seed).encode('utf-8')).digest()[:8],'big')%20)+1
    target=10 if capability.zone == CapabilityZone.EDGE else 16
    return roll>=target,roll,target


def opposed_zone_modifier(capability: ActionCapability) -> int:
    """Modifier for a separate opposed resolver; SAFE is not auto-success."""
    return {
        CapabilityZone.SAFE: 2,
        CapabilityZone.EDGE: 0,
        CapabilityZone.EXTREME: -4,
        CapabilityZone.HARD_LIMIT: -99,
        CapabilityZone.INACCESSIBLE: -99,
    }[capability.zone]


def explain_capability(capability: ActionCapability) -> str:
    result=capability.result
    if result.zone == CapabilityZone.INACCESSIBLE:
        if result.explanation_key == 'SKILL_NOT_LEARNED':
            return 'Dir fehlt die erlernte Technik für diese Anwendung.'
        return 'Diese Anwendung ist dir derzeit nicht zugänglich.'
    if result.zone == CapabilityZone.HARD_LIMIT:
        stage=result.failure_stage or 'EXECUTE'
        reason=result.stages[-1].reason if result.stages else result.explanation_key
        stat=reason.split(':',1)[1] if reason.startswith('STAT_BELOW_HARD_MIN:') else ''
        suffix=f' ({stat})' if stat else ''
        if result.stages[:-1]:
            return f'Die bisherigen Schritte gelingen, aber bei {stage} liegt die Aufgabe außerhalb deiner aktuellen natürlichen Leistungsgrenze{suffix}.'
        return f'Diese Aufgabe überfordert deine aktuelle natürliche Leistungsgrenze bei {stage}{suffix}.'
    if result.zone == CapabilityZone.EXTREME:
        return 'Die Handlung ist grundsätzlich möglich, liegt aber weit außerhalb deiner sicheren Anwendung. Ein Fehlschlag ist sehr wahrscheinlich.'
    if result.zone == CapabilityZone.EDGE:
        return 'Die Handlung liegt an deiner aktuellen Leistungsgrenze. Der Ausgang ist unsicher.'
    return 'Die Handlung liegt innerhalb deiner derzeit zuverlässig beherrschten Anwendung.'
