from __future__ import annotations

from dataclasses import dataclass
from hashlib import blake2b
import json

from .content_distribution import ContentDistributionResolver


@dataclass(frozen=True, slots=True)
class WorldSurface:
    location_id: str
    region_id: str
    category: str
    culture_id: str
    hybrid_culture: bool
    architecture: str
    material: str
    food_signal: str
    services: tuple[str, ...]
    language_register: str
    culture_architecture: str
    culture_food: str
    culture_speech: str
    trade_streams: tuple[str, ...]

    def to_dict(self) -> dict:
        return {
            'location_id': self.location_id,
            'region_id': self.region_id,
            'category': self.category,
            'culture_id': self.culture_id,
            'hybrid_culture': self.hybrid_culture,
            'architecture': self.architecture,
            'material': self.material,
            'food_signal': self.food_signal,
            'services': list(self.services),
            'language_register': self.language_register,
            'culture_architecture': self.culture_architecture,
            'culture_food': self.culture_food,
            'culture_speech': self.culture_speech,
            'trade_streams': list(self.trade_streams),
        }


class WorldSurfaceResolver:
    """Deterministic presentation surface derived only from static profiles + run/location.

    It does not create hidden facts, actor intentions or biological lineage. Culture is an
    explicit generated world-surface affiliation, not an inference about ancestry.
    """
    def __init__(self, catalog):
        self.catalog=catalog
        raw=json.loads((catalog.root/'content/full_version/world_surface_profiles.json').read_text(encoding='utf-8'))
        if raw.get('schema')!='PH4NT0M5_WORLD_SURFACE_PROFILES_V1':
            raise ValueError('WORLD_SURFACE_SCHEMA_INVALID')
        self.raw=raw
        self.categories=raw['category_profiles']
        self.overlays=raw['culture_overlays']
        self.role_attire=raw['role_attire']
        self.trade_streams=raw['trade_streams']
        self.distribution=ContentDistributionResolver(catalog)

    @staticmethod
    def _choose(values, seed: str):
        if not values: return ''
        n=int.from_bytes(blake2b(seed.encode('utf-8'),digest_size=8).digest(),'big')%len(values)
        return values[n]

    def resolve(self, location_id: str, *, run_uuid: str='') -> WorldSurface:
        loc=self.catalog.location(location_id)
        category=str(loc['primary_category']); region=str(loc['region_id'])
        base=self.categories[category]
        culture_id=self.distribution.dominant_culture_for_location(location_id,run_uuid)
        culture=self.distribution.cultures.get(culture_id,{})
        overlay=self.overlays.get(culture_id,{})
        seed=f'{run_uuid}|{location_id}|WORLD_SURFACE_V1'
        trade=tuple(self.trade_streams.get(region,{}).get('labels',()))
        return WorldSurface(
            location_id,region,category,culture_id,bool(culture.get('hybrid_of')),
            self._choose(base['architecture'],seed+'|architecture'),
            self._choose(base['materials'],seed+'|material'),
            self._choose(base['food_signals'],seed+'|food'),
            tuple(base.get('services',())),
            self._choose(base['language_registers'],seed+'|language'),
            self._choose(overlay.get('architecture',()),seed+'|culture_architecture'),
            self._choose(overlay.get('food',()),seed+'|culture_food'),
            self._choose(overlay.get('speech',()),seed+'|culture_speech'),
            trade,
        )

    def npc_surface(self, role: str, home_location_id: str, *, run_uuid: str='', npc_id: str='', culture_id: str | None=None) -> dict:
        world=self.resolve(home_location_id,run_uuid=run_uuid)
        selected_culture=culture_id or world.culture_id
        culture_record=self.distribution.cultures.get(selected_culture,{})
        overlay=self.overlays.get(selected_culture,{})
        attire=self._choose(overlay.get('attire',()),f'{run_uuid}|{npc_id}|attire')
        return {
            'culture_id':selected_culture,
            'hybrid_culture':bool(culture_record.get('hybrid_of')),
            'speech_register':world.culture_speech or world.language_register,
            'attire_style':attire,
            'role_attire':self.role_attire.get(role,''),
            'home_region_id':world.region_id,
        }

    def market_flow_multiplier_ppm(self, item_kind: str, location_id: str) -> int:
        loc=self.catalog.location(location_id)
        region=str(loc['region_id']); category=str(loc['primary_category'])
        base=int(self.categories.get(category,{}).get('trade_flow_ppm_by_kind',{}).get(item_kind,1_000_000))
        flow=self.trade_streams.get(region,{})
        if item_kind in flow.get('export_kinds',()): base=(base*1_120_000)//1_000_000
        if item_kind in flow.get('import_kinds',()): base=(base*1_080_000)//1_000_000
        return max(650_000,min(1_450_000,base))
