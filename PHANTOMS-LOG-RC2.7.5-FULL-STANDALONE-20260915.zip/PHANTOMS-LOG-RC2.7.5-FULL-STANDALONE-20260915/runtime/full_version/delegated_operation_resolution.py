from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from typing import Any, Mapping, Sequence

class DelegatedOperationResolutionError(RuntimeError): pass

@dataclass(frozen=True, slots=True)
class DelegatedOperationResult:
    outcome: str
    score: float
    target: float
    roll: int
    team_power: float
    readiness: float

class DelegatedOperationResolver:
    """Resolve off-screen organization work from authoritative snapshots only.

    It never invents NPC skills, equipment, casualties, loot, travel or world facts.
    Those must be supplied by their owning systems and consequences remain external.
    """
    OUTCOMES=("FULL_SUCCESS","SUCCESS_WITH_COST","PARTIAL_SUCCESS","FAILURE","CRITICAL_FAILURE")

    def resolve(self, *, operation_id: str, team_snapshots: Sequence[Mapping[str,Any]],
                difficulty: int=5, danger: int=0, time_pressure: int=0,
                preparation_bonus: int=0, logistics_bonus: int=0,
                seed: str="") -> DelegatedOperationResult:
        if not team_snapshots: raise DelegatedOperationResolutionError("TEAM_SNAPSHOT_REQUIRED")
        powers=[]; readiness=[]
        for snap in team_snapshots:
            if not str(snap.get("evidence_ref","")).strip():
                raise DelegatedOperationResolutionError("AUTHORITATIVE_TEAM_EVIDENCE_REQUIRED")
            skills=snap.get("relevant_skill_values")
            if not isinstance(skills,Mapping) or not skills:
                raise DelegatedOperationResolutionError("RELEVANT_SKILL_VALUES_REQUIRED")
            vals=[max(0,min(10,int(v))) for v in skills.values()]
            skill=max(vals)+0.25*(sum(vals)-max(vals))/max(1,len(vals)-1)
            equip=max(-3,min(3,int(snap.get("equipment_modifier",0))))
            condition=max(-3,min(3,int(snap.get("condition_modifier",0))))
            machines=max(0,min(4,int(snap.get("machine_support",0))))
            powers.append(skill+equip+condition+0.5*machines)
            readiness.append(max(0.0,min(1.0,float(snap.get("readiness",1.0)))))
        # More teams improve coverage/delegation, but with diminishing returns.
        team_power=max(powers)+(sum(powers)-max(powers))*0.20/max(1,len(powers)-1)
        ready=sum(readiness)/len(readiness)
        capability=team_power*ready+int(preparation_bonus)+int(logistics_bonus)
        target=float(difficulty)+0.5*int(danger)+0.5*int(time_pressure)
        h=sha256(f"{seed}|{operation_id}|{len(team_snapshots)}".encode()).digest()
        roll=(int.from_bytes(h[:4],"big")%101)-50
        score=capability-target+(roll/20.0)
        if score>=4: outcome="FULL_SUCCESS"
        elif score>=2: outcome="SUCCESS_WITH_COST"
        elif score>=0: outcome="PARTIAL_SUCCESS"
        elif score<=-5: outcome="CRITICAL_FAILURE"
        else: outcome="FAILURE"
        return DelegatedOperationResult(outcome,round(score,3),target,roll,round(team_power,3),round(ready,3))
