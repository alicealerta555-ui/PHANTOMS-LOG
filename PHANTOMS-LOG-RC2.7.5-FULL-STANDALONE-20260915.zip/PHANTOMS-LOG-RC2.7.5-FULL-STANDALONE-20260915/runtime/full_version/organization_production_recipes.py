from __future__ import annotations
import json
from typing import Any, Mapping

class ProductionRecipeError(RuntimeError): pass

class ProductionRecipeCatalog:
    def __init__(self,catalog):
        raw=json.loads((catalog.root/'content/full_version/organization_production_recipes.json').read_text(encoding='utf-8'))
        if raw.get('schema')!='PH4NT0M5_ORGANIZATION_PRODUCTION_RECIPES_V1': raise ProductionRecipeError('PRODUCTION_RECIPE_SCHEMA_INVALID')
        self.facility_kinds=dict(raw.get('facility_kinds',{})); self.recipes={str(x['id']):dict(x) for x in raw.get('recipes',[])}
        if len(self.recipes)!=len(raw.get('recipes',[])): raise ProductionRecipeError('PRODUCTION_RECIPE_ID_DUPLICATE')
    def recipe(self,recipe_id:str)->dict[str,Any]:
        rec=self.recipes.get(str(recipe_id))
        if not rec: raise ProductionRecipeError('PRODUCTION_RECIPE_NOT_FOUND')
        return dict(rec)
    def validate_facility(self,facility:Mapping[str,Any],recipe_id:str)->dict[str,Any]:
        rec=self.recipe(recipe_id); kind=str(facility.get('facility_kind','')).upper(); level=int(facility.get('specialization_level',1))
        if kind!=str(rec['facility_kind']).upper(): raise ProductionRecipeError('PRODUCTION_RECIPE_FACILITY_MISMATCH')
        if level<int(rec.get('min_specialization_level',1)): raise ProductionRecipeError('PRODUCTION_RECIPE_SPECIALIZATION_TOO_LOW')
        return rec
    def validate_inputs(self,recipe:Mapping[str,Any],facts)->int:
        totals={}
        for fact in facts: totals[str(fact.get('resource_ref',''))]=totals.get(str(fact.get('resource_ref','')),0)+int(fact.get('quantity',0))
        req={str(k):int(v) for k,v in recipe.get('inputs',{}).items()}
        if set(totals)!=set(req): raise ProductionRecipeError('PRODUCTION_RECIPE_INPUT_MISMATCH')
        batches=[]
        for resource,qty in req.items():
            if qty<=0 or totals[resource]%qty: raise ProductionRecipeError('PRODUCTION_RECIPE_INPUT_BATCH_INVALID')
            batches.append(totals[resource]//qty)
        if not batches or len(set(batches))!=1 or batches[0]<=0: raise ProductionRecipeError('PRODUCTION_RECIPE_INPUT_BATCH_INVALID')
        return batches[0]
    def validate_outputs(self,recipe:Mapping[str,Any],facts,batches:int)->None:
        allowed={str(k):int(v)*int(batches) for k,v in recipe.get('outputs',{}).items()}
        totals={}
        for fact in facts: totals[str(fact.get('resource_ref',''))]=totals.get(str(fact.get('resource_ref','')),0)+int(fact.get('quantity',0))
        for resource,qty in totals.items():
            if resource not in allowed: raise ProductionRecipeError('PRODUCTION_RECIPE_OUTPUT_MISMATCH')
            if qty>allowed[resource]: raise ProductionRecipeError('PRODUCTION_RECIPE_OUTPUT_EXCEEDS_BATCH')
