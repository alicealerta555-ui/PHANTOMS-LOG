from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import copy

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal, ValidationResult, Verdict
from runtime.stage9.world_time import WORLD_TIME_RUNTIME_KEY, WorldClock
from runtime.full_version.bootstrap import PLAYER_ACTOR_INSTANCE_ID
from runtime.full_version.quests_runtime import QuestRuntime
from runtime.full_version.content_distribution import ContentDistributionResolver
from runtime.full_version.item_surface import ItemSurfaceResolver
from runtime.full_version.capability_runtime import assess_action, deterministic_uncertain_success
from runtime.full_version.lifetime_start import lifetime_search_effects

SEARCH_STATE_PREFIX='__location_search__:'

class SearchError(RuntimeError): pass

def _score(seed: str) -> int:
    return int.from_bytes(sha256(seed.encode('utf-8')).digest()[:8],'big')

def _weighted(entries: list[dict], seed: str, weight_key='weight') -> dict | None:
    if not entries: return None
    total=sum(max(0,int(x.get(weight_key,0))) for x in entries)
    if total <= 0: return None
    n=_score(seed)%total
    cur=0
    for x in entries:
        cur+=max(0,int(x.get(weight_key,0)))
        if n < cur: return x
    return entries[-1]

@dataclass(frozen=True, slots=True)
class SearchResult:
    outcome: str
    location_id: str
    found_items: tuple[dict,...]
    learned_information: tuple[dict,...]
    world_time_seconds: int
    capability_zone: str = "SAFE"
    capability_explanation: str = ""
    capability_roll: int|None = None
    capability_target: int|None = None

class LocationSearchRuntime:
    def __init__(self,catalog,session):
        self.catalog=catalog; self.session=session
        self.distribution=ContentDistributionResolver(catalog)
        self.item_surface=ItemSurfaceResolver(catalog)

    def search(self, *, actor_id: str=PLAYER_ACTOR_INSTANCE_ID) -> SearchResult:
        kernel=self.session.kernel
        actor=kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,actor_id)
        if not isinstance(actor,dict): raise SearchError('SEARCH_ACTOR_MISSING')
        location_id=str(actor.get('location_ref') or '')
        loc=self.catalog.location(location_id)
        table=self.catalog.search_profile(loc['primary_category'],location_id)
        rules=self.catalog.search_tables['rules']
        cap=assess_action(actor,'SKILL_OBSERVATION',1,context_tags=('search','observation','routine',str(loc.get('primary_category',''))))
        if cap.blocked:
            raise SearchError(f'SEARCH_CAPABILITY_BLOCKED:{cap.zone.value}:{cap.failure_stage or ""}:{cap.explanation}')
        quest_found=QuestRuntime(self.catalog,self.session).reveal_for_search(location_id,actor_id)
        state_key=SEARCH_STATE_PREFIX+location_id
        prior=kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,state_key)
        if prior is None:
            prior={'run_uuid':self.session.identity.run_uuid,'location_id':location_id,'resource_finds':[],'information_finds':[],'search_count':0}
        if not isinstance(prior,dict) or prior.get('run_uuid')!=self.session.identity.run_uuid: raise SearchError('SEARCH_STATE_INVALID')
        state=copy.deepcopy(prior); search_index=int(state.get('search_count',0)); state['search_count']=search_index+1
        found=[]; learned=[]; deltas=[]
        run=self.session.identity.run_uuid
        cap_ok,cap_roll,cap_target=deterministic_uncertain_success(cap,f'{run}|search-capability|{location_id}|{search_index}')
        if cap_ok:
            found.extend(quest_found)
            lf_found,lf_learned,lf_deltas=lifetime_search_effects(self.catalog,self.session,location_id,actor_id=actor_id,event_id=f'SEARCH:{location_id}:{search_index}')
            found.extend(lf_found); learned.extend(lf_learned); deltas.extend(lf_deltas)

        # Resource: select only definitions not already found here, bounded per location.
        used_defs=set(state.get('resource_finds',()))
        if cap_ok and len(used_defs) < int(rules['max_resource_finds_per_location']):
            candidates=[self.distribution.adjusted_search_entry(x,location_id,run_uuid=run) for x in table['resource_candidates'] if x['item_definition_id'] not in used_defs]
            pick=_weighted(candidates,f'{run}|{location_id}|resource|{search_index}')
            guarantee_after=max(1,int(rules.get('guaranteed_resource_find_after_searches',3)))
            forced=bool(pick is not None and search_index+1>=guarantee_after and not used_defs)
            if forced and candidates:
                pick=max(candidates,key=lambda x:(int(x.get('chance_ppm',0)),int(x.get('weight',0)),str(x.get('item_definition_id',''))))
            if pick is not None and (forced or (_score(f'{run}|{location_id}|chance|{search_index}')%1_000_000) < int(pick['chance_ppm'])):
                item_def=pick['item_definition_id']
                iid='item:found:'+sha256(f'{run}|{location_id}|{item_def}'.encode()).hexdigest()[:20]
                existing=kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
                if existing is None:
                    condition=55+(_score(f'{run}|{location_id}|condition|{item_def}')%31)
                    dist=pick.get('_distribution',{})
                    surface=self.item_surface.resolve(item_def,location_id,run_uuid=run,instance_id=iid).to_dict()
                    item_rec={'run_uuid':run,'kind':'item','item_definition_id':item_def,'location_ref':location_id,'condition':condition,'max_condition':100,'provenance':'LOCATION_SEARCH','source_location_id':location_id,'distribution_context':dist,'surface_variant':surface}
                    deltas.append(Delta(Domain.RUNTIME_STATE,iid,item_rec,Authority.RULE_KERNEL,'LOCATION_SEARCH_RESOURCE',source_event_id=f'SEARCH:{location_id}:{search_index}',provenance='LOCATION_SEARCH_TABLE'))
                    found.append({'instance_id':iid,'item_definition_id':item_def,'display_name':surface['display_name']})
                    state.setdefault('resource_finds',[]).append(item_def)

        # Information: observable local information only, written through KnowledgeRouter authority.
        used_info=set(state.get('information_finds',()))
        if cap_ok and len(used_info) < int(rules['max_information_finds_per_location']):
            candidates=[x for x in table['information_candidates'] if x['information_id'] not in used_info]
            pick=_weighted(candidates,f'{run}|{location_id}|information|{search_index}')
            if pick is not None:
                info_id=pick['information_id']; key=f'local_observation:{location_id}:{info_id}'
                if kernel.read(Authority.KNOWLEDGE_ROUTER,Domain.ACTOR_KNOWLEDGE,key,actor_id=actor_id) is None:
                    now=WorldClock(self.session).seconds
                    epistemic={'source_type':'DIRECT_OBSERVATION','source_id':f'search:{location_id}','origin_location':location_id,'learned_at':now,'path':[],'confidence_ppm':900000,'distortions':[]}
                    value={'information_id':info_id,'location_id':location_id,'text':pick['text']}
                    deltas.append(Delta(Domain.ACTOR_KNOWLEDGE,key,value,Authority.KNOWLEDGE_ROUTER,'LOCATION_SEARCH_INFORMATION',actor_id=actor_id,source_event_id=f'SEARCH:{location_id}:{search_index}',provenance='DIRECT_SEARCH',epistemic=epistemic))
                    learned.append(value); state.setdefault('information_finds',[]).append(info_id)
                    discovery_key=pick.get('discovery_key')
                    if isinstance(discovery_key,str) and discovery_key and kernel.read(Authority.KNOWLEDGE_ROUTER,Domain.ACTOR_KNOWLEDGE,discovery_key,actor_id=actor_id) is None:
                        deltas.append(Delta(Domain.ACTOR_KNOWLEDGE,discovery_key,{'source':'location_search','location_id':location_id,'information_id':info_id,'truth_status':'UNVERIFIED'},Authority.KNOWLEDGE_ROUTER,'MISSION_DISCOVERY',actor_id=actor_id,source_event_id=f'SEARCH:{location_id}:{search_index}',provenance='SEARCH_DISCOVERY',epistemic=epistemic))

        deltas.append(Delta(Domain.RUNTIME_STATE,state_key,state,Authority.RULE_KERNEL,'LOCATION_SEARCH_STATE',source_event_id=f'SEARCH:{location_id}:{search_index}',provenance='LOCATION_SEARCH'))
        before=WorldClock(self.session).seconds
        seconds=int(rules['search_time_seconds'] if (found or learned) else rules['repeat_search_time_seconds'])
        deltas.append(Delta(Domain.RUNTIME_STATE,WORLD_TIME_RUNTIME_KEY,{'run_uuid':run,'seconds':before+seconds},Authority.WORLD_TIME,'STAGE9_ADVANCE_WORLD_TIME',source_event_id=f'SEARCH:{location_id}:{search_index}',provenance='LOCATION_SEARCH'))
        result=kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=tuple(deltas),event_id=f'SEARCH:{location_id}:{search_index}',cause='LOCATION_SEARCH',expected_state_revision=self.session.store.revision))
        if isinstance(result,ValidationResult) and result.verdict not in {Verdict.HOLD,Verdict.PASS}:
            raise SearchError('SEARCH_COMMIT_REJECTED:'+','.join(result.reasons))
        outcome=('SEARCH_FOUND' if (found or learned) else ('SEARCH_CHECK_FAILED' if not cap_ok else 'SEARCH_EXHAUSTED'))
        return SearchResult(outcome,location_id,tuple(found),tuple(learned),seconds,cap.zone.value,cap.explanation,cap_roll,cap_target)
