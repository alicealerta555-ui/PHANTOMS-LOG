from __future__ import annotations
from hashlib import sha256
from typing import Iterable, Mapping, Sequence

class DynamicMissionGeneratorError(RuntimeError): pass

class DynamicMissionGenerator:
    """Deterministic weighted selector over *already world-authorized* mission candidates.

    It never creates a world problem, target, actor, location, injury, creature, item or
    mission prerequisite. Callers must supply candidate ids that are already plausible.
    """
    def choose(self, eligible_template_ids: Sequence[str], *, run_uuid: str, context_key: str,
               weights: Mapping[str, float] | None = None) -> str:
        ids=tuple(dict.fromkeys(str(x) for x in eligible_template_ids if str(x)))
        if not ids: raise DynamicMissionGeneratorError('NO_WORLD_AUTHORIZED_MISSION_CANDIDATES')
        w=weights or {}
        weighted=[]
        for mid in ids:
            value=float(w.get(mid,1.0))
            if value<=0: continue
            weighted.append((mid,value))
        if not weighted: raise DynamicMissionGeneratorError('NO_POSITIVE_MISSION_WEIGHT')
        total=sum(v for _,v in weighted)
        raw=int.from_bytes(sha256(f'{run_uuid}|{context_key}|mission-choice'.encode()).digest()[:8],'big')
        point=(raw/(2**64))*total
        cursor=0.0
        for mid,value in weighted:
            cursor+=value
            if point < cursor: return mid
        return weighted[-1][0]
