from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

class OrganizationResourceFlowError(RuntimeError): pass

@dataclass(frozen=True, slots=True)
class ResourceFlowPlan:
    operation_kind: str
    outcome: str
    accepted_inputs: tuple[dict[str,Any], ...]
    proposed_outputs: tuple[dict[str,Any], ...]
    unresolved: tuple[str, ...]

class OrganizationResourceFlowPlanner:
    """Plan organization material flows without inventing loot or production.

    Inputs/outputs must already be authoritative facts with evidence refs.  The
    planner only filters what a delegated result is allowed to forward. Actual
    inventory/economy commits remain owned by their existing authorities.
    """
    KINDS={"DUNGEON_FARM","SALVAGE_RECOVERY","PRODUCTION_CHAIN","SUPPLY_CHAIN"}
    OUTCOMES={"FULL_SUCCESS","SUCCESS_WITH_COST","PARTIAL_SUCCESS","FAILURE","CRITICAL_FAILURE"}

    def plan(self, *, operation_kind:str, outcome:str,
             input_facts:Sequence[Mapping[str,Any]]=(), output_facts:Sequence[Mapping[str,Any]]=()) -> ResourceFlowPlan:
        kind=str(operation_kind).upper(); result=str(outcome).upper()
        if kind not in self.KINDS: raise OrganizationResourceFlowError("OPERATION_KIND_UNSUPPORTED")
        if result not in self.OUTCOMES: raise OrganizationResourceFlowError("OUTCOME_INVALID")
        ins=tuple(self._fact(x,"INPUT") for x in input_facts)
        outs=tuple(self._fact(x,"OUTPUT") for x in output_facts)
        unresolved=[]
        # Failure never fabricates rewards. Pre-existing authoritative recovery can
        # still be forwarded, e.g. a partial retreat with already-secured salvage.
        if result in {"FAILURE","CRITICAL_FAILURE"} and not outs:
            unresolved.append("NO_AUTHORITATIVE_OUTPUT")
        if kind=="PRODUCTION_CHAIN" and not ins:
            unresolved.append("REAL_INPUTS_REQUIRED")
        if kind=="SUPPLY_CHAIN" and not ins:
            unresolved.append("REAL_CARGO_REQUIRED")
        return ResourceFlowPlan(kind,result,ins,outs,tuple(unresolved))

    def _fact(self, fact:Mapping[str,Any], direction:str)->dict[str,Any]:
        if not isinstance(fact,Mapping): raise OrganizationResourceFlowError(direction+"_FACT_INVALID")
        ev=str(fact.get("evidence_ref") or "").strip()
        item=str(fact.get("resource_ref") or fact.get("item_definition_id") or "").strip()
        qty=fact.get("quantity")
        if not ev: raise OrganizationResourceFlowError(direction+"_EVIDENCE_REQUIRED")
        if not item: raise OrganizationResourceFlowError(direction+"_RESOURCE_REF_REQUIRED")
        if isinstance(qty,bool) or not isinstance(qty,int) or qty<=0: raise OrganizationResourceFlowError(direction+"_QUANTITY_INVALID")
        return {"evidence_ref":ev,"resource_ref":item,"quantity":qty,"owner_ref":str(fact.get("owner_ref") or ""),"location_id":str(fact.get("location_id") or "")}
