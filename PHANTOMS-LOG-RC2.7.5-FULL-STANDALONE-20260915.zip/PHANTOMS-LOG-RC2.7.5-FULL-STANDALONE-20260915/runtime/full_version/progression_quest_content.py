from __future__ import annotations
import json
from pathlib import Path

class ProgressionQuestContentError(RuntimeError): pass

class ProgressionQuestContent:
    """Validated authored progression content. Runtime activation still requires a real world binding."""
    def __init__(self, root: Path):
        self.root=Path(root)
        c=self.root/'content/full_version'
        self.class_data=json.loads((c/'class_quest_chains.json').read_text(encoding='utf8'))
        self.legend_data=json.loads((c/'legend_capstones.json').read_text(encoding='utf8'))
        self.group_data=json.loads((c/'quest_groups_persistent.json').read_text(encoding='utf8'))
        self.class_nodes={q['quest_id']:q for nodes in self.class_data['chains'].values() for q in nodes}
        self.legend_scenarios={q['scenario_id']:q for q in self.legend_data['scenarios']}
        self.quest_groups={q['group_id']:q for q in self.group_data['profiles']}
        if len(self.legend_scenarios)!=48 or len(self.quest_groups)!=12: raise ProgressionQuestContentError('PROGRESSION_CONTENT_INCOMPLETE')
    def class_candidates(self,start_class:str,*,specialization:str|None=None,mastery_path:str|None=None):
        out=[]
        for q in self.class_data['chains'].get(start_class,[]):
            req=q.get('requirements',{})
            if req.get('specialization') and req['specialization']!=specialization: continue
            if req.get('mastery_path') and req['mastery_path']!=mastery_path: continue
            out.append(q)
        return out
    def legend_candidates(self,path_id:str):
        return [q for q in self.legend_scenarios.values() if q['path_id']==path_id]
