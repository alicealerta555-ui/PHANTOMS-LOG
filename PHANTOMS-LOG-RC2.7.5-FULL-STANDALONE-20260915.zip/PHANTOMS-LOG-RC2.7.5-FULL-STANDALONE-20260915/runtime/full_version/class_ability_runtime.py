from __future__ import annotations

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal


class ClassAbilityRuntimeError(RuntimeError):
    pass


class ClassAbilityRuntime:
    """Authoritative persistence adapter for learned class abilities.

    Visibility/path/prerequisite policy remains with the caller/character-tree rules;
    the playable shell never writes canonical state directly.
    """
    def __init__(self, session):
        self.session=session

    def commit_learn(self, actor_id: str, ability_id: str) -> CommitRecord:
        actor=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,actor_id)
        if not isinstance(actor,dict): raise ClassAbilityRuntimeError("ABILITY_ACTOR_REQUIRED")
        profile=dict(actor.get("character_profile") or {})
        owned=list(profile.get("class_abilities") or [])
        if ability_id not in owned:
            owned.append(ability_id)
        profile["class_abilities"]=owned
        actor=dict(actor); actor["character_profile"]=profile
        event=f"CLASS_ABILITY_LEARN:{self.session.identity.run_uuid}:{ability_id}:{self.session.store.revision}"
        result=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,
            deltas=(Delta(Domain.RUNTIME_STATE,actor_id,actor,Authority.RULE_KERNEL,"CLASS_ABILITY_LEARN",source_event_id=event,provenance="PLAYER_CLASS_PROGRESSION"),),
            event_id=event,cause="CLASS_ABILITY_LEARN",expected_state_revision=self.session.store.revision))
        if not isinstance(result,CommitRecord):
            raise ClassAbilityRuntimeError("CLASS_ABILITY_COMMIT_REJECTED")
        return result
