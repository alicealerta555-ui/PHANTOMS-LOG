from __future__ import annotations

"""Declared capability policy for active playable action families.

Every active action is either:
- ROUTINE_SAFE: no meaningful uncertainty exists after affordance/authority checks,
- SKILL: resolved through the canonical capability tree,
- DYNAMIC_SKILL: its canonical skill roots come from runtime data (class abilities,
  recipe/operation definitions, etc.).

This prevents accidental reintroduction of ad-hoc skill checks.
"""

from dataclasses import dataclass
from typing import Mapping

from .capability_catalog import SKILLS

ROUTINE_SAFE = "ROUTINE_SAFE"
SKILL = "SKILL"
DYNAMIC_SKILL = "DYNAMIC_SKILL"


@dataclass(frozen=True, slots=True)
class ActionCapabilityPolicy:
    action_id: str
    mode: str
    skill_id: str | None = None
    note: str = ""


ACTION_CAPABILITY_POLICIES: Mapping[str, ActionCapabilityPolicy] = {
    # Stage-9 semantic actions. These are routine only after hard world/authority
    # preconditions (presence, ownership, route, role, etc.) have passed.
    "LOOK": ActionCapabilityPolicy("LOOK", ROUTINE_SAFE, note="Ordinary visible-scene observation; hidden-detail search uses SEARCH."),
    "TAKE": ActionCapabilityPolicy("TAKE", ROUTINE_SAFE, note="Picking up an already discovered, reachable item."),
    "OPEN": ActionCapabilityPolicy("OPEN", ROUTINE_SAFE, note="Opening an ordinary unlocked door. Forced/bypassed opening is a different method."),
    "MOVE": ActionCapabilityPolicy("MOVE", ROUTINE_SAFE, note="Normal travel over an established connected route."),
    "TALK": ActionCapabilityPolicy("TALK", ROUTINE_SAFE, note="Starting ordinary conversation; persuasion/deception require their own skillful methods."),
    "TRADE_BUY": ActionCapabilityPolicy("TRADE_BUY", ROUTINE_SAFE, note="Normal role-conforming merchant transaction."),
    "TRADE_SELL": ActionCapabilityPolicy("TRADE_SELL", ROUTINE_SAFE, note="Normal role-conforming merchant transaction."),
    "QUEST_ACCEPT": ActionCapabilityPolicy("QUEST_ACCEPT", ROUTINE_SAFE, note="Player consent to accept an available quest."),
    "ATTACK": ActionCapabilityPolicy("ATTACK", SKILL, "SKILL_AIM_CONTROL", "Own execution uses capability zones; target opposition still resolves combat."),

    # Full-version action families.
    "SEARCH": ActionCapabilityPolicy("SEARCH", SKILL, "SKILL_OBSERVATION", "Routine search is low difficulty; hidden targets may define harder detection demands."),
    "CRAFT": ActionCapabilityPolicy("CRAFT", DYNAMIC_SKILL, note="Skill and difficulty come from the operation definition."),
    "REPAIR": ActionCapabilityPolicy("REPAIR", DYNAMIC_SKILL, note="Skill and difficulty come from the operation definition."),
    "TREAT": ActionCapabilityPolicy("TREAT", DYNAMIC_SKILL, note="Skill and difficulty come from the operation definition."),
    "DATA_READ": ActionCapabilityPolicy("DATA_READ", DYNAMIC_SKILL, note="Unencrypted reading is routine; encrypted access uses SKILL_NETWORKS."),
    "REBUILD": ActionCapabilityPolicy("REBUILD", SKILL, "SKILL_TECHNOLOGY", "Infrastructure restoration difficulty follows damage state."),
    "CORPSE_INVESTIGATION": ActionCapabilityPolicy("CORPSE_INVESTIGATION", SKILL, "SKILL_MEDICINE", "Visible features may survive as partial result when interpretation fails."),
    "CLASS_ABILITY": ActionCapabilityPolicy("CLASS_ABILITY", DYNAMIC_SKILL, note="Every class ability resolves through its required_skills roots."),
}


def validate_action_capability_policy() -> tuple[str, ...]:
    errors=[]
    allowed_modes={ROUTINE_SAFE,SKILL,DYNAMIC_SKILL}
    for action_id,policy in ACTION_CAPABILITY_POLICIES.items():
        if action_id != policy.action_id:
            errors.append(f"ACTION_POLICY_KEY_MISMATCH:{action_id}:{policy.action_id}")
        if policy.mode not in allowed_modes:
            errors.append(f"ACTION_POLICY_MODE_INVALID:{action_id}:{policy.mode}")
        if policy.mode == SKILL:
            if not policy.skill_id or policy.skill_id not in SKILLS:
                errors.append(f"ACTION_POLICY_SKILL_INVALID:{action_id}:{policy.skill_id}")
        elif policy.skill_id is not None:
            errors.append(f"ACTION_POLICY_UNEXPECTED_SKILL:{action_id}:{policy.skill_id}")
    return tuple(errors)
