from __future__ import annotations

from dataclasses import dataclass
from hashlib import blake2b
import json
from collections import deque


class ContentDistributionError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class DistributionResult:
    item_definition_id: str
    location_id: str
    rarity_tier: str
    graph_hops: int
    distance_band: str
    availability_ppm: int
    biome_match: bool
    culture_id: str
    culture_match: bool
    hybrid_culture: bool
    lineage_id: str
    lineage_match: bool
    explanation_codes: tuple[str, ...]
    allowed_variant_indexes: tuple[int, ...]

    def to_dict(self) -> dict:
        return {
            'item_definition_id': self.item_definition_id,
            'location_id': self.location_id,
            'rarity_tier': self.rarity_tier,
            'graph_hops': self.graph_hops,
            'distance_band': self.distance_band,
            'availability_ppm': self.availability_ppm,
            'biome_match': self.biome_match,
            'culture_id': self.culture_id,
            'culture_match': self.culture_match,
            'hybrid_culture': self.hybrid_culture,
            'lineage_id': self.lineage_id,
            'lineage_match': self.lineage_match,
            'explanation_codes': list(self.explanation_codes),
            'allowed_variant_indexes': list(self.allowed_variant_indexes),
        }


class ContentDistributionResolver:
    def __init__(self, catalog):
        self.catalog = catalog
        path = catalog.root / 'content/full_version/content_distribution_profiles.json'
        raw = json.loads(path.read_text(encoding='utf-8'))
        if raw.get('schema') != 'PH4NT0M5_CONTENT_DISTRIBUTION_V1':
            raise ContentDistributionError('CONTENT_DISTRIBUTION_SCHEMA_INVALID')
        self.raw = raw
        self.rules = raw['rules']
        self.rarity = raw['rarity_tiers']
        self.cultures = {x['culture_id']: x for x in raw['cultures']}
        self.profiles = {x['item_definition_id']: x for x in raw['item_profiles']}
        self._locations = {x['location_id']: x for x in catalog.world['locations']}
        surface_path = catalog.root / 'content/full_version/world_surface_profiles.json'
        self.world_surface = json.loads(surface_path.read_text(encoding='utf-8')) if surface_path.exists() else {}
        self._by_region = {}
        for loc in self._locations.values():
            self._by_region.setdefault(loc['region_id'], []).append(loc['location_id'])

    def _hops_to_regions(self, location_id: str, origin_regions: list[str]) -> int:
        if location_id not in self._locations:
            raise ContentDistributionError('CONTENT_DISTRIBUTION_LOCATION_UNKNOWN:'+location_id)
        targets = {lid for r in origin_regions for lid in self._by_region.get(r, ())}
        if not targets:
            return 99
        if location_id in targets:
            return 0
        seen = {location_id}; q = deque([(location_id,0)])
        while q:
            node, d = q.popleft()
            for nxt in self._locations[node].get('connections', ()):
                if nxt in seen: continue
                if nxt in targets: return d+1
                seen.add(nxt); q.append((nxt,d+1))
        return 99

    def _distance_band(self, hops: int) -> str:
        bands=list(self.rules['distance_band_hops']); labels=list(self.rules['distance_labels'])
        for i,limit in enumerate(bands):
            if hops <= int(limit): return labels[i]
        return labels[-1]

    def dominant_culture_for_location(self, location_id: str, run_uuid: str='') -> str:
        loc=self._locations[location_id]; region=loc['region_id']; category=loc['primary_category']
        candidates=[]
        for c in self.cultures.values():
            if region not in c.get('home_regions', ()): continue
            score=int(c.get('prevalence_ppm',0))
            if category in c.get('preferred_categories', ()): score += 180000
            candidates.append((score,c['culture_id']))
        if not candidates: return ''
        candidates.sort(reverse=True)
        # Allow a rarer hybrid culture to surface deterministically where it belongs.
        weighted=[]
        for score,cid in candidates:
            c=self.cultures[cid]
            weighted.append((max(1,int(c.get('prevalence_ppm',score))),cid))
        total=sum(w for w,_ in weighted)
        digest=blake2b(f'{run_uuid}|{location_id}|CULTURE_DISTRIBUTION_V1'.encode(),digest_size=8).digest()
        n=int.from_bytes(digest,'big')%total
        cur=0
        for w,cid in weighted:
            cur += w
            if n < cur: return cid
        return weighted[-1][1]

    @staticmethod
    def _mul_ppm(value: int, multiplier_ppm: int) -> int:
        return max(0, (int(value) * int(multiplier_ppm)) // 1_000_000)

    def resolve(self, item_definition_id: str, location_id: str, *, run_uuid: str='', culture_id: str='', lineage_id: str='') -> DistributionResult:
        profile=self.profiles.get(item_definition_id)
        if profile is None:
            return DistributionResult(item_definition_id,location_id,'UNSPECIFIED',0,'local',1_000_000,True,culture_id,False,False,lineage_id,False,('NO_SPECIAL_DISTRIBUTION_PROFILE',),())
        loc=self._locations[location_id]
        tier=str(profile['rarity_tier'])
        value=int(self.rarity[tier])
        hops=self._hops_to_regions(location_id,list(profile.get('origin_regions',())))
        decay=int(profile.get('distance_decay_ppm',self.rules['default_distance_decay_ppm']))
        for _ in range(min(hops,30)):
            value=self._mul_ppm(value,decay)
        category=loc['primary_category']; biome_match=category in profile.get('preferred_categories',())
        value=self._mul_ppm(value,int(self.rules['default_native_biome_multiplier_ppm'] if biome_match else self.rules['default_off_biome_multiplier_ppm']))
        culture_id=culture_id or self.dominant_culture_for_location(location_id,run_uuid)
        culture=self.cultures.get(culture_id,{})
        culture_mult=int(profile.get('culture_affinities',{}).get(culture_id,self.rules['unknown_culture_multiplier_ppm']))
        culture_match=culture_id in profile.get('culture_affinities',{})
        value=self._mul_ppm(value,culture_mult)
        hybrid=bool(culture.get('hybrid_of'))
        lineage_mult=int(profile.get('lineage_affinities',{}).get(lineage_id,self.rules['unknown_lineage_multiplier_ppm'])) if lineage_id else int(self.rules['unknown_lineage_multiplier_ppm'])
        lineage_match=bool(lineage_id and lineage_id in profile.get('lineage_affinities',{}))
        value=self._mul_ppm(value,lineage_mult)
        floor=int(self.rules['availability_floor_ppm']) if self.rules.get('never_zero_from_distance_alone') else 0
        value=max(floor,min(1_000_000,value))
        reasons=[f'RARITY_{tier}',f'DISTANCE_{self._distance_band(hops).upper()}', 'BIOME_NATIVE' if biome_match else 'BIOME_FOREIGN']
        if culture_id: reasons.append('HYBRID_CULTURE' if hybrid else 'CULTURE_LOCAL')
        if culture_match: reasons.append('CULTURE_AFFINITY')
        if lineage_match: reasons.append('LINEAGE_AFFINITY')
        allowed=tuple(int(i) for i in profile.get('variant_by_culture',{}).get(culture_id,()))
        return DistributionResult(item_definition_id,location_id,tier,hops,self._distance_band(hops),value,biome_match,culture_id,culture_match,hybrid,lineage_id,lineage_match,tuple(reasons),allowed)


    def market_flow_multiplier_ppm(self, item_definition_id: str, location_id: str) -> int:
        """Regional/biome trade flow modifier; never changes canonical item mechanics."""
        if not self.world_surface:
            return 1_000_000
        try:
            kind=str(self.catalog.item_definition(item_definition_id)['kind'])
            loc=self._locations[location_id]
            cat=self.world_surface.get('category_profiles',{}).get(loc['primary_category'],{})
            mult=int(cat.get('trade_flow_ppm_by_kind',{}).get(kind,1_000_000))
            flow=self.world_surface.get('trade_streams',{}).get(loc['region_id'],{})
            if kind in flow.get('export_kinds',()): mult=(mult*1_120_000)//1_000_000
            if kind in flow.get('import_kinds',()): mult=(mult*1_080_000)//1_000_000
            return max(650_000,min(1_450_000,mult))
        except Exception:
            return 1_000_000

    def market_price_multiplier_ppm(self, result: DistributionResult) -> int:
        """Scarcity premium/discount derived only from committed distribution inputs."""
        availability=max(0,min(1_000_000,int(result.availability_ppm)))
        # 0.85x when ubiquitous; approaches 2.50x when exceptionally scarce.
        return max(850_000,min(2_500_000,850_000 + ((1_000_000-availability)*1_650_000)//1_000_000))

    def merchant_offer(self, item_definition_id: str, location_id: str, *, run_uuid: str='', merchant_id: str='') -> tuple[bool, DistributionResult, int]:
        result=self.resolve(item_definition_id,location_id,run_uuid=run_uuid)
        seed=f'{run_uuid}|{merchant_id}|{location_id}|{item_definition_id}|MERCHANT_DISTRIBUTION_V1'
        roll=int.from_bytes(blake2b(seed.encode(),digest_size=8).digest(),'big')%1_000_000
        # Preserve some long-distance trade without making every remote item globally stocked.
        offer_floor=int(self.rules.get('merchant_offer_floor_ppm',45_000))
        flow_mult=self.market_flow_multiplier_ppm(item_definition_id,location_id)
        effective=max(1,min(1_000_000,self._mul_ppm(int(result.availability_ppm),flow_mult)))
        threshold=max(offer_floor,min(950_000,effective))
        scarcity=max(850_000,min(2_500_000,850_000 + ((1_000_000-effective)*1_650_000)//1_000_000))
        return roll < threshold, result, scarcity

    def adjusted_search_entry(self, entry: dict, location_id: str, *, run_uuid: str='') -> dict:
        out=dict(entry)
        result=self.resolve(str(entry['item_definition_id']),location_id,run_uuid=run_uuid)
        out['weight']=max(1,self._mul_ppm(int(out.get('weight',1)),result.availability_ppm))
        out['chance_ppm']=min(1_000_000,self._mul_ppm(int(out.get('chance_ppm',1_000_000)),result.availability_ppm))
        out['_distribution']=result.to_dict()
        return out
