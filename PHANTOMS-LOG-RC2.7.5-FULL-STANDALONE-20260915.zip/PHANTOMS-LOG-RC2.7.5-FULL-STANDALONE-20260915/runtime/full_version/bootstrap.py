# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

"""Full-version new-run bootstrap. Never used during rehydration/load."""

from dataclasses import dataclass
import copy

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal, ValidationResult, Verdict
from runtime.stage3c.isolation import RunSession
from runtime.stage9.actor_context import ACTOR_VISIBLE_RUNTIME_KEY
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.identity import RuntimeIdentity
from .catalog import FullVersionCatalog
from runtime.stage7.needs import STAGE7_RUNTIME_KEY
from .lifetime_start import (
    build_lifetime_start, LIFETIME_STATE_KEY, LIFETIME_DIARY_ITEM_ID,
    LIFETIME_FAMILY_ACTOR_ID, LIFETIME_LOCAL_ACTOR_IDS,
)
from .item_surface import ItemSurfaceResolver
from .content_distribution import ContentDistributionResolver
from .world_surface import WorldSurfaceResolver
from .population_runtime import PopulationResolver
from .social_faction import SOCIAL_STATE_KEY
from runtime.player_progression.npc_naming import NPCNameGenerator, NameRequest


PLAYER_ACTOR_INSTANCE_ID='actor:player'
FULL_VERSION_INIT_KEY='__full_version_initialized__'


class FullVersionBootstrapError(RuntimeError): pass


@dataclass(frozen=True, slots=True)
class FullVersionBootstrap:
    catalog: FullVersionCatalog

    def initialize_new_run(self, session: RunSession, registry: RunActorRegistry, *, start_class: str, player_actor_id: str=PLAYER_ACTOR_INSTANCE_ID) -> CommitRecord | ValidationResult:
        if session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,FULL_VERSION_INIT_KEY) is True:
            raise FullVersionBootstrapError('FULL_VERSION_ALREADY_INITIALIZED')
        start_class=str(start_class).upper(); self.catalog.class_start(start_class)
        run=session.identity.run_uuid; event=f'FULL_VERSION_INIT:{run}'
        item_surface=ItemSurfaceResolver(self.catalog)
        distribution=ContentDistributionResolver(self.catalog)
        world_surface=WorldSurfaceResolver(self.catalog)
        population=PopulationResolver(self.catalog)
        region_labels={str(k):str(v.get('label',k)) for k,v in population.raw.get('region_profiles',{}).items()}
        lifetime=build_lifetime_start(self.catalog.world,run,region_labels=region_labels,region_profiles=population.raw.get('region_profiles',{}))
        start_location_id=str(lifetime['start']['location_id'])
        registry.register(RuntimeIdentity(session.identity.player_uuid,session.identity.run_uuid,player_actor_id),actor_definition_id='full.player')
        economy=self.catalog.npc_runtime_tables['economy']
        actor={"run_uuid":run,"kind":"actor","location_ref":start_location_id,"hp":10,"max_hp":10,"status_flags":[],"resources":{"stamina":10,"hunger":0,"hydration":0,"credits":int(economy['player_start_credits'])},"start_class":start_class,
               "social_profile":{"household_ref":lifetime['family']['household_ref'],"household_type":"family","home_region_id":lifetime['start']['region_id'],"occupation_type":"unassigned"}}
        visible={"run_uuid":run,"actors":{player_actor_id:{"location_ref":start_location_id,"health_state":"hp:10/10","status_flags":[],"equipped_refs":[]}}}
        need_profile=self.catalog.stage7_needs.profile('needs:player_default')
        stage7_needs={"run_uuid":run,"actors":{player_actor_id:{"profile_id":"needs:player_default","pressures_ppm":copy.deepcopy(dict(need_profile['initial_pressure_ppm'])),"last_cause_ref":"FULL_VERSION_NEW_RUN"}}}
        social_state={"run_uuid":run,"relationships":{},"reputation":{"npc":{},"household":{},"faction":{},"region":{}},"rumors":{},"legal_events":[]}
        family_rel_key='|'.join(sorted((player_actor_id,LIFETIME_FAMILY_ACTOR_ID)))
        social_state['relationships'][family_rel_key]=copy.deepcopy(lifetime['life_history']['relationship_seed'])
        deltas=[
            Delta(Domain.RUNTIME_STATE,FULL_VERSION_INIT_KEY,True,Authority.SYSTEM_INIT,'FULL_VERSION_INIT',source_event_id=event,provenance='FULL_VERSION_NEW_RUN'),
            Delta(Domain.RUNTIME_STATE,SOCIAL_STATE_KEY,social_state,Authority.SYSTEM_INIT,'FULL_VERSION_INIT',source_event_id=event,provenance='FULL_VERSION_NEW_RUN'),
            Delta(Domain.RUNTIME_STATE,LIFETIME_STATE_KEY,lifetime,Authority.SYSTEM_INIT,'LIFETIME_START_INIT',source_event_id=event,provenance='LIFETIME_START'),
            Delta(Domain.RUNTIME_STATE,player_actor_id,actor,Authority.SYSTEM_INIT,'FULL_VERSION_INIT',source_event_id=event,provenance='FULL_VERSION_NEW_RUN'),
            Delta(Domain.RUNTIME_STATE,STAGE7_RUNTIME_KEY,stage7_needs,Authority.SYSTEM_INIT,'FULL_VERSION_INIT',source_event_id=event,provenance='FULL_VERSION_NEW_RUN'),
        ]
        # Persistent runtime NPCs: static definitions remain immutable; identity, position and inventory are run state.
        namegen=NPCNameGenerator(seed='NPC_RUNTIME:'+run)
        role_inventory=self.catalog.npc_runtime_tables['role_inventory']
        merchant_stock=self.catalog.npc_runtime_tables['merchant_stock']
        merchant_essential_stock=self.catalog.npc_runtime_tables.get('merchant_essential_stock',[])
        default_species=self.catalog.npc_runtime_tables['default_species_profile']
        for npc_def in self.catalog.world['npc_definitions']:
            suffix=npc_def['actor_definition_id'].rsplit(':',1)[-1]
            npc_id=f'actor:npc:{suffix}'
            registry.register(RuntimeIdentity(session.identity.player_uuid,session.identity.run_uuid,npc_id),actor_definition_id=npc_def['actor_definition_id'])
            generated=namegen.generate(NameRequest(npc_id=npc_id,species_profile=default_species,known_to_player=True))
            role=npc_def['role']; credits=int(economy['merchant_start_credits'] if role=='merchant' else economy['other_npc_start_credits'])
            social_profile=population.assign_npc(npc_id=npc_id,role=role,home_location_id=npc_def['home_location_id'],run_uuid=run)
            cultural_surface=world_surface.npc_surface(role,npc_def['home_location_id'],run_uuid=run,npc_id=npc_id,culture_id=social_profile['culture_id'])
            npc={"run_uuid":run,"kind":"actor","actor_definition_id":npc_def['actor_definition_id'],"location_ref":npc_def['home_location_id'],"home_location_id":npc_def['home_location_id'],"hp":10,"max_hp":10,"status_flags":[],"resources":{"credits":credits},"role":role,"faction_id":npc_def['faction_id'],"display_name":generated.full_name,"name_record":generated.to_dict(),"goals":copy.deepcopy(npc_def.get('goals',[])),"cultural_surface":cultural_surface,"social_profile":social_profile}
            deltas.append(Delta(Domain.RUNTIME_STATE,npc_id,npc,Authority.SYSTEM_INIT,'FULL_VERSION_NPC_INIT',source_event_id=event,provenance='STATIC_NPC_DEFINITION'))
            npc_need_profile=self.catalog.stage7_needs.profile('needs:sapient_default')
            stage7_needs['actors'][npc_id]={"profile_id":"needs:sapient_default","pressures_ppm":copy.deepcopy(dict(npc_need_profile['initial_pressure_ppm'])),"last_cause_ref":"FULL_VERSION_NPC_INIT"}
            visible['actors'][npc_id]={"location_ref":npc_def['home_location_id'],"health_state":"hp:10/10","status_flags":[],"equipped_refs":[]}
            defs=list(role_inventory[role])
            extra_market=[]
            market_meta={}
            if role=='merchant':
                ranked=[]
                for item_def in merchant_stock:
                    offered,dist,price_mult=distribution.merchant_offer(item_def,npc_def['home_location_id'],run_uuid=run,merchant_id=npc_id)
                    ranked.append((int(dist.availability_ppm),item_def,dist,price_mult,offered))
                    if offered:
                        extra_market.append(item_def); market_meta[item_def]=(dist,price_mult)
                min_extra=int(distribution.rules.get('merchant_min_extra_stock',2))
                if len(extra_market)<min_extra:
                    for _,item_def,dist,price_mult,_ in sorted(ranked,reverse=True):
                        if item_def not in extra_market:
                            extra_market.append(item_def); market_meta[item_def]=(dist,price_mult)
                        if len(extra_market)>=min_extra: break
                defs.extend(extra_market)
                defs.extend(merchant_essential_stock)
            for j,item_def in enumerate(dict.fromkeys(defs),1):
                iid=f'item:npc:{suffix}:{j:02d}'
                item_kind=self.catalog.item_definition(item_def)['kind']
                surface=item_surface.resolve(item_def,npc_def['home_location_id'],run_uuid=run,instance_id=iid).to_dict()
                unit_price=int(self.catalog.npc_runtime_tables['price_by_kind'][item_kind])
                dist_context=None
                if role=='merchant':
                    if item_def in market_meta:
                        dist,price_mult=market_meta[item_def]
                    else:
                        dist=distribution.resolve(item_def,npc_def['home_location_id'],run_uuid=run)
                        price_mult=distribution.market_price_multiplier_ppm(dist)
                    unit_price=max(1,(unit_price*int(price_mult))//1_000_000)
                    dist_context=dist.to_dict()
                rec={"run_uuid":run,"kind":"item","item_definition_id":item_def,"location_ref":f'inventory:{npc_id}',"owner_actor_instance_id":npc_id,"merchant_stock":role=='merchant',"unit_price":unit_price,"condition":100,"max_condition":100,"provenance":"NPC_RUNTIME_INVENTORY","surface_origin_location_id":npc_def['home_location_id'],"surface_variant":surface}
                if dist_context is not None: rec['distribution_context']=dist_context
                deltas.append(Delta(Domain.RUNTIME_STATE,iid,rec,Authority.SYSTEM_INIT,'FULL_VERSION_NPC_INIT',source_event_id=event,provenance='NPC_RUNTIME_TABLE'))

        # Lifetime start actors: one known household member and two ordinary locals.
        lifetime_actor_specs=[
            (LIFETIME_FAMILY_ACTOR_ID,str(lifetime['origin']['surviving_family_role_id']),True,lifetime['family']['household_ref'],'LIFETIME_FAMILY'),
            (LIFETIME_LOCAL_ACTOR_IDS[0],str(lifetime['family']['local_role_ids'][0]),False,'','LIFETIME_LOCAL'),
            (LIFETIME_LOCAL_ACTOR_IDS[1],str(lifetime['family']['local_role_ids'][1]),False,'','LIFETIME_LOCAL'),
        ]
        for npc_id,role,known,household_override,provenance in lifetime_actor_specs:
            registry.register(RuntimeIdentity(session.identity.player_uuid,session.identity.run_uuid,npc_id),actor_definition_id=None)
            generated=namegen.generate(NameRequest(npc_id=npc_id,species_profile=default_species,known_to_player=known,social_context=('household' if known else 'local')))
            social_profile=population.assign_npc(npc_id=npc_id,role=role,home_location_id=start_location_id,run_uuid=run)
            if household_override:
                social_profile=dict(social_profile); social_profile['household_ref']=household_override; social_profile['household_type']='family'
            cultural_surface=world_surface.npc_surface(role,start_location_id,run_uuid=run,npc_id=npc_id,culture_id=social_profile['culture_id'])
            npc={"run_uuid":run,"kind":"actor","actor_definition_id":None,"location_ref":start_location_id,"home_location_id":start_location_id,"hp":10,"max_hp":10,"status_flags":[],"resources":{"credits":int(economy['other_npc_start_credits'])},"role":role,"faction_id":"","display_name":generated.full_name,"name_record":generated.to_dict(),"goals":["maintain_household" if known else "maintain_livelihood"],"cultural_surface":cultural_surface,"social_profile":social_profile,"lifetime_origin":provenance}
            deltas.append(Delta(Domain.RUNTIME_STATE,npc_id,npc,Authority.SYSTEM_INIT,'LIFETIME_NPC_INIT',source_event_id=event,provenance=provenance))
            npc_need_profile=self.catalog.stage7_needs.profile('needs:sapient_default')
            stage7_needs['actors'][npc_id]={"profile_id":"needs:sapient_default","pressures_ppm":copy.deepcopy(dict(npc_need_profile['initial_pressure_ppm'])),"last_cause_ref":"LIFETIME_NPC_INIT"}
            visible['actors'][npc_id]={"location_ref":start_location_id,"health_state":"hp:10/10","status_flags":[],"equipped_refs":[]}
            if known:
                epi={"source_type":"LIFETIME_MEMORY","source_id":npc_id,"origin_location":start_location_id,"learned_at":0,"path":[],"confidence_ppm":1000000,"distortions":[]}
                deltas.append(Delta(Domain.ACTOR_KNOWLEDGE,f'npc_identity:{npc_id}',{"npc_id":npc_id,"name":generated.full_name,"role":role,"relation":lifetime['origin']['surviving_family_relation']},Authority.SYSTEM_INIT,'LIFETIME_FAMILY_KNOWN',actor_id=player_actor_id,source_event_id=event,provenance='LIFETIME_START',epistemic=epi))

        # The only guaranteed personal start item is the inherited family diary.
        diary_def='item_def:data:008'
        diary_surface=item_surface.resolve(diary_def,start_location_id,run_uuid=run,instance_id=LIFETIME_DIARY_ITEM_ID).to_dict()
        diary_surface.update(display_name='Familientagebuch',base_name='Familientagebuch',surface_description='Ein kleines, abgegriffenes persönliches Tagebuch mit Arbeitsnotizen, offenen Verpflichtungen und unvollständigen Ortsangaben.')
        diary={"run_uuid":run,"kind":"item","item_definition_id":diary_def,"location_ref":f'inventory:{player_actor_id}',"owner_actor_instance_id":player_actor_id,"condition":82,"max_condition":100,"provenance":"LIFETIME_INHERITANCE","surface_origin_location_id":start_location_id,"surface_variant":diary_surface,"lifetime_document":True}
        deltas.append(Delta(Domain.RUNTIME_STATE,LIFETIME_DIARY_ITEM_ID,diary,Authority.SYSTEM_INIT,'LIFETIME_DIARY_INIT',source_event_id=event,provenance='LIFETIME_START'))

        # The remaining parental estate physically exists elsewhere and begins hidden.
        target_location=str(lifetime['estate']['target_location_id'])
        for iid,item_def in zip(lifetime['estate']['item_instance_ids'],lifetime['estate']['item_definition_ids']):
            surface=item_surface.resolve(item_def,target_location,run_uuid=run,instance_id=iid).to_dict()
            rec={"run_uuid":run,"kind":"item","item_definition_id":item_def,"location_ref":target_location,"condition":55+(int(iid.rsplit(':',1)[-1])%3)*10,"max_condition":100,"provenance":"LIFETIME_PARENT_ESTATE","surface_origin_location_id":target_location,"surface_variant":surface,"hidden":True,"inheritance_household_ref":lifetime['family']['household_ref']}
            deltas.append(Delta(Domain.RUNTIME_STATE,iid,rec,Authority.SYSTEM_INIT,'LIFETIME_ESTATE_INIT',source_event_id=event,provenance='LIFETIME_PARENT_ESTATE'))

        deltas.append(Delta(Domain.RUNTIME_STATE,ACTOR_VISIBLE_RUNTIME_KEY,visible,Authority.SYSTEM_INIT,'FULL_VERSION_INIT',source_event_id=event,provenance='FULL_VERSION_NEW_RUN'))
        result=session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=tuple(deltas),event_id=event,cause='FULL_VERSION_NEW_RUN_INIT'))
        if isinstance(result,ValidationResult) and result.verdict not in {Verdict.HOLD,Verdict.PASS}: raise FullVersionBootstrapError('FULL_VERSION_INIT_REJECTED')
        return result
