from __future__ import annotations

"""Current-condition modifiers for the canonical capability character tree.

Stored stats and skills are immutable character potential. Temporary survival
conditions only reduce what can currently be used. Talents may mitigate a
matching temporary penalty, but can never raise an effective value above the
stored base and can never erase a hard capability limit.
"""

from runtime.full_version.capability_catalog import SCHEMA_ID, SKILLS, STATS

SKILL_FLOOR = 0
STAT_FLOOR = 1
TOTAL_SURVIVAL_PENALTY_CAP = 4

_NEED_FLAGS = {
    "hydration": ("SURV_DEHYDRATION_IMPAIRED", "SURV_DEHYDRATION_CRITICAL"),
    "nutrition": ("SURV_STARVATION_IMPAIRED", "SURV_STARVATION_CRITICAL"),
    "rest": ("SURV_EXHAUSTION_IMPAIRED", "SURV_EXHAUSTION_CRITICAL"),
    "climate_fit": ("SURV_EXPOSURE_IMPAIRED", "SURV_EXPOSURE_CRITICAL"),
}

_SKILL_AFFECTED = {
    "hydration": frozenset({
        "SKILL_ATHLETICS", "SKILL_FORCE_APPLICATION", "SKILL_LOAD_CONTROL",
        "SKILL_BALANCE", "SKILL_ACROBATICS", "SKILL_STEALTH",
        "SKILL_AIM_CONTROL", "SKILL_FINE_MECHANICS", "SKILL_TECHNOLOGY",
        "SKILL_ELECTRONICS", "SKILL_MEDICINE", "SKILL_ATTENTION",
        "SKILL_OBSERVATION", "SKILL_SELF_CONTROL", "SKILL_RESONANCE_CONTROL",
        "SKILL_RESONANCE_PROJECTION",
    }),
    "nutrition": frozenset({
        "SKILL_ATHLETICS", "SKILL_FORCE_APPLICATION", "SKILL_LOAD_CONTROL",
        "SKILL_BALANCE", "SKILL_ACROBATICS",
    }),
    "rest": frozenset({
        "SKILL_ATHLETICS", "SKILL_LOAD_CONTROL", "SKILL_BALANCE", "SKILL_ACROBATICS", "SKILL_STEALTH",
        "SKILL_AIM_CONTROL", "SKILL_FINE_MECHANICS", "SKILL_TECHNOLOGY",
        "SKILL_ELECTRONICS", "SKILL_NETWORKS", "SKILL_DIAGNOSTICS",
        "SKILL_MEDICINE", "SKILL_ATTENTION", "SKILL_OBSERVATION",
        "SKILL_ORIENTATION", "SKILL_PEOPLE_READING", "SKILL_COMMUNICATION",
        "SKILL_SELF_CONTROL", "SKILL_RESONANCE_SENSE", "SKILL_RESONANCE_CONTROL",
        "SKILL_RESONANCE_PROJECTION", "SKILL_OCCULT_KNOWLEDGE",
        "SKILL_RITUAL_TECHNIQUE", "SKILL_ASTRAL_NAVIGATION",
        "SKILL_RESONANCE_CONCEALMENT", "SKILL_ENTITY_CONTACT", "SKILL_BANISHING",
        "SKILL_ECHO_ANALYSIS", "SKILL_DIVINATION",
    }),
    "climate_fit": frozenset({
        "SKILL_ATHLETICS", "SKILL_LOAD_CONTROL", "SKILL_BALANCE", "SKILL_STEALTH",
        "SKILL_ATTENTION", "SKILL_OBSERVATION", "SKILL_ORIENTATION",
        "SKILL_SELF_CONTROL", "SKILL_RESONANCE_SENSE", "SKILL_RESONANCE_CONTROL",
    }),
}

_STAT_AFFECTED = {
    "hydration": frozenset({"STAT_STR", "STAT_END", "STAT_MOB", "STAT_DEX", "STAT_REA", "STAT_PER", "STAT_WIL", "STAT_RES"}),
    "nutrition": frozenset({"STAT_STR", "STAT_END", "STAT_MOB"}),
    "rest": frozenset({"STAT_END", "STAT_DEX", "STAT_REA", "STAT_PER", "STAT_COG", "STAT_WIL", "STAT_SOC", "STAT_RES"}),
    "climate_fit": frozenset({"STAT_END", "STAT_MOB", "STAT_PER", "STAT_WIL", "STAT_RES"}),
}

# Domain expertise can make a trained action more robust under a temporary
# condition. It never alters the stored stat/skill or raises current output above
# that base value.
_TALENT_SKILL_MITIGATION = {
    "TALENT_UNYIELDING": frozenset({"SKILL_LOAD_CONTROL", "SKILL_SELF_CONTROL"}),
    "TALENT_FORCE_LINE": frozenset({"SKILL_FORCE_APPLICATION"}),
    "TALENT_PHANTOM_STEP": frozenset({"SKILL_STEALTH", "SKILL_BALANCE"}),
    "TALENT_BLIND_MOVEMENT": frozenset({"SKILL_BALANCE", "SKILL_ORIENTATION"}),
    "TALENT_MACHINEWORK": frozenset({"SKILL_TECHNOLOGY", "SKILL_DIAGNOSTICS", "SKILL_FINE_MECHANICS"}),
    "TALENT_FIELD_REPAIR": frozenset({"SKILL_TECHNOLOGY", "SKILL_DIAGNOSTICS"}),
    "TALENT_AURA_READING": frozenset({"SKILL_RESONANCE_SENSE", "SKILL_ATTENTION"}),
    "TALENT_MEDIUMSHIP": frozenset({"SKILL_ENTITY_CONTACT", "SKILL_RESONANCE_CONTROL", "SKILL_SELF_CONTROL"}),
}

_TALENT_STAT_MITIGATION = {
    "TALENT_UNYIELDING": frozenset({"STAT_END", "STAT_WIL"}),
    "TALENT_FORCE_LINE": frozenset({"STAT_STR", "STAT_MOB"}),
    "TALENT_PHANTOM_STEP": frozenset({"STAT_MOB", "STAT_DEX"}),
    "TALENT_BLIND_MOVEMENT": frozenset({"STAT_MOB", "STAT_PER"}),
    "TALENT_MACHINEWORK": frozenset({"STAT_COG", "STAT_DEX"}),
    "TALENT_FIELD_REPAIR": frozenset({"STAT_COG", "STAT_DEX", "STAT_WIL"}),
    "TALENT_AURA_READING": frozenset({"STAT_RES", "STAT_PER"}),
    "TALENT_MEDIUMSHIP": frozenset({"STAT_RES", "STAT_WIL", "STAT_SOC"}),
}


def _profile(actor: dict) -> dict:
    profile = actor.get("character_profile", {}) if isinstance(actor, dict) else {}
    if profile and profile.get("schema") != SCHEMA_ID:
        raise ValueError("LEGACY_CHARACTER_SCHEMA_UNSUPPORTED")
    return profile


def _severity(flags: set[str], need: str) -> int:
    impaired, critical = _NEED_FLAGS[need]
    if critical in flags:
        return 2
    if impaired in flags:
        return 1
    return 0


def _raw_penalty(actor: dict, capability_id: str, *, kind: str) -> int:
    flags = set(actor.get("status_flags", ())) if isinstance(actor, dict) else set()
    affected = _SKILL_AFFECTED if kind == "skill" else _STAT_AFFECTED
    total = 0
    for need in _NEED_FLAGS:
        if capability_id in affected[need]:
            total += _severity(flags, need)
    return min(TOTAL_SURVIVAL_PENALTY_CAP, total)


def _talent_mitigation(actor: dict, capability_id: str, *, kind: str, penalty: int) -> int:
    if penalty <= 0:
        return 0
    talents = set(str(x).upper() for x in (_profile(actor).get("talents") or ()))
    mapping = _TALENT_SKILL_MITIGATION if kind == "skill" else _TALENT_STAT_MITIGATION
    mitigation = sum(1 for talent in talents if capability_id in mapping.get(talent, ()))
    return min(penalty, mitigation)


def effective_skill(actor: dict, skill_id: str) -> int:
    skill_id = str(skill_id).upper()
    if skill_id not in SKILLS:
        raise KeyError(f"UNKNOWN_SKILL:{skill_id}")
    base = int((_profile(actor).get("skills") or {}).get(skill_id, SKILL_FLOOR))
    penalty = _raw_penalty(actor, skill_id, kind="skill")
    mitigation = _talent_mitigation(actor, skill_id, kind="skill", penalty=penalty)
    return min(base, max(SKILL_FLOOR, base - penalty + mitigation))


def effective_stat(actor: dict, stat_id: str) -> int:
    stat_id = str(stat_id).upper()
    if stat_id not in STATS:
        raise KeyError(f"UNKNOWN_STAT:{stat_id}")
    base = int((_profile(actor).get("stats") or {}).get(stat_id, STAT_FLOOR))
    penalty = _raw_penalty(actor, stat_id, kind="stat")
    mitigation = _talent_mitigation(actor, stat_id, kind="stat", penalty=penalty)
    return min(base, max(STAT_FLOOR, base - penalty + mitigation))


def stat_breakdown(actor: dict, capability_id: str, *, kind: str) -> dict:
    capability_id = str(capability_id).upper()
    if kind == "skill":
        if capability_id not in SKILLS:
            raise KeyError(f"UNKNOWN_SKILL:{capability_id}")
        base_map = _profile(actor).get("skills") or {}
        floor = SKILL_FLOOR
    elif kind == "stat":
        if capability_id not in STATS:
            raise KeyError(f"UNKNOWN_STAT:{capability_id}")
        base_map = _profile(actor).get("stats") or {}
        floor = STAT_FLOOR
    else:
        raise ValueError("KIND_MUST_BE_SKILL_OR_STAT")
    base = int(base_map.get(capability_id, floor))
    penalty = _raw_penalty(actor, capability_id, kind=kind)
    mitigation = _talent_mitigation(actor, capability_id, kind=kind, penalty=penalty)
    effective = min(base, max(floor, base - penalty + mitigation))
    return {"base": base, "survival_penalty": penalty, "talent_mitigation": mitigation, "effective": effective}
