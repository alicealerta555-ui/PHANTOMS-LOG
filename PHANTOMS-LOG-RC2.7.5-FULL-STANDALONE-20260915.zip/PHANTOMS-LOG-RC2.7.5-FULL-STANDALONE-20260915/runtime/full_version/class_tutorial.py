from __future__ import annotations

"""Diegetic class tutorial for newly created characters.

The tutorial is deliberately bounded: it demonstrates the player's *selected*
starting talents against safe calibration tasks, but never grants XP, items,
knowledge, credits, stats, skills, talents, or class abilities.  It writes only
its own tutorial progress record through the CommitKernel.
"""

from copy import deepcopy
from dataclasses import dataclass
import re
from typing import Any, Mapping

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.full_version.capability_catalog import TALENTS, SKILLS
from runtime.full_version.capability_runtime import assess_action, deterministic_uncertain_success

CLASS_TUTORIAL_SCHEMA = "PHANTOMS_CLASS_TUTORIAL_V1"
CLASS_TUTORIAL_STATE_KEY = "__class_tutorial__"
PLAYER_ACTOR_ID = "actor:player"

_CLASS_FRAMES = {
    "BREAKER": "Ein robuster Übungsbereich stellt Gewicht, Widerstand und kontrollierte Kraft bereit.",
    "GHOST": "Ein kurzer Parcours kombiniert Sichtlinien, schmale Wege, Geräuschquellen und wechselnde Deckung.",
    "OPERATOR": "Ein Wartungsstand enthält ein absichtlich fehlerhaftes Testsystem mit ungefährlichen Diagnose- und Reparaturpunkten.",
    "RESONANT": "Ein abgeschirmter Kalibrierraum erzeugt schwache, kontrollierte Resonanz-, Echo- und Kontaktsignale.",
}

# Natural-language cues for the canonical skills.  These are input recognition
# hints only; the canonical skill/talent IDs remain the rules authority.
_SKILL_CUES = {
    "SKILL_ATHLETICS": (("laufe","springe","klettere","bewege"), "Ich überwinde das Hindernis kontrolliert."),
    "SKILL_FORCE_APPLICATION": (("drücke","druecke","ziehe","hebe","breche","kraft"), "Ich drücke die markierte Platte kontrolliert gegen den Widerstand."),
    "SKILL_LOAD_CONTROL": (("halte","belastung","erschöpfung","erschoepfung","atem"), "Ich halte die Belastung und ordne meinen Atem."),
    "SKILL_BALANCE": (("balanciere","gleichgewicht","steg","schmal"), "Ich balanciere kontrolliert über den schmalen Steg."),
    "SKILL_ACROBATICS": (("rolle","vault","sprung","akrobat"), "Ich überwinde das Hindernis mit einer kontrollierten Rolle."),
    "SKILL_STEALTH": (("schleiche","leise","ungesehen","deckung","sichtlinie"), "Ich schleiche leise durch die markierte Sichtlücke."),
    "SKILL_AIM_CONTROL": (("ziele","schlage","treffe","präzise","praezise"), "Ich setze den kontrollierten Treffer auf die markierte Fläche."),
    "SKILL_FINE_MECHANICS": (("feinmechanik","kontakt","kleinteil","justiere","montiere"), "Ich justiere die kleine Testmechanik vorsichtig."),
    "SKILL_TECHNOLOGY": (("repariere","maschine","technik","wartung","fixe"), "Ich repariere den markierten Testfehler mit den vorhandenen Mitteln."),
    "SKILL_ELECTRONICS": (("schaltung","elektronik","verkabelung","strom","sensor"), "Ich prüfe und korrigiere die markierte Testschaltung."),
    "SKILL_NETWORKS": (("netzwerk","signal","schnittstelle","protokoll","zugriff"), "Ich prüfe den freigegebenen Testzugang und verfolge den Signalpfad."),
    "SKILL_DIAGNOSTICS": (("diagnostiziere","diagnose","fehler","ursache","system"), "Ich diagnostiziere die Ursache des absichtlich gesetzten Systemfehlers."),
    "SKILL_MEDICINE": (("behandle","stabilisiere","verband","medizin","verletzung"), "Ich stabilisiere die ungefährliche Trainingsverletzung am Dummy."),
    "SKILL_ATTENTION": (("beobachte","achte","signal","aufmerksam","überwache","ueberwache"), "Ich beobachte die Anzeigen und filtere das relevante Signal heraus."),
    "SKILL_OBSERVATION": (("untersuche","spuren","beobachte","details","suche"), "Ich untersuche die markierten Spuren und ordne die Details."),
    "SKILL_ORIENTATION": (("orientiere","route","weg","richtung","zurück","zurueck"), "Ich orientiere mich im abgedunkelten Abschnitt und bestimme den Rückweg."),
    "SKILL_PEOPLE_READING": (("lese","haltung","anspannung","emotion","absicht"), "Ich lese Haltung und Anspannung der Übungsperson, ohne Gedanken zu unterstellen."),
    "SKILL_COMMUNICATION": (("spreche","rede","erkläre","erklaere","lenke","überzeuge","ueberzeuge"), "Ich erkläre der Übungsperson ruhig, was ich von ihr brauche."),
    "SKILL_SELF_CONTROL": (("konzentriere","fokussiere","ruhe","kontrolliere","atem"), "Ich stabilisiere Atmung und Fokus trotz des Störreizes."),
    "SKILL_RESONANCE_SENSE": (("spüre","spuere","resonanz","fühle","fuehle","signal"), "Ich spüre nach dem schwachen Testsignal und trenne es vom Hintergrund."),
    "SKILL_RESONANCE_CONTROL": (("kopple","resonanz","stabilisiere","abschirme","fokussiere"), "Ich fokussiere die Resonanz und halte die Testkopplung stabil."),
    "SKILL_RESONANCE_PROJECTION": (("projiziere","impuls","resonanz","druck","sende"), "Ich sende einen schwachen kontrollierten Resonanzimpuls auf das Testziel."),
    "SKILL_OCCULT_KNOWLEDGE": (("deute","symbol","okkult","ritual","zeichen"), "Ich deute die bekannte Symbolstruktur des ungefährlichen Übungsmusters."),
    "SKILL_RITUAL_TECHNIQUE": (("siegel","ritual","kreis","struktur","aktiviere"), "Ich setze die bekannte Übungsstruktur in der korrekten Reihenfolge."),
    "SKILL_ASTRAL_NAVIGATION": (("resonanzpfad","schwelle","astral","verfolge","sondiere"), "Ich verfolge den schwachen markierten Resonanzpfad und halte die Rückbindung."),
    "SKILL_RESONANCE_CONCEALMENT": (("dämpfe","daempfe","verschleiere","signatur","tarne"), "Ich dämpfe meine Resonanzsignatur innerhalb des Testfelds."),
    "SKILL_ENTITY_CONTACT": (("kontakt","verbinde","entität","entitaet","impuls"), "Ich stelle eine begrenzte Testkopplung her und halte Eigen- und Fremdsignal getrennt."),
    "SKILL_BANISHING": (("banne","bannung","fluch","anker","zurückdränge","zurueckdraenge"), "Ich löse den markierten Übungsanker mit einer kontrollierten Bannsequenz."),
    "SKILL_ECHO_ANALYSIS": (("echo","resonanzrest","analysiere","objektspur","ereignis"), "Ich analysiere die schwachen Resonanzreste am markierten Testobjekt."),
    "SKILL_DIVINATION": (("deute","vorzeichen","muster","vorahnung","wahrscheinlichkeit"), "Ich deute das mehrdeutige Testmuster, ohne Gewissheit daraus zu machen."),
}


def _cue_for_skill(skill_id: str) -> tuple[tuple[str, ...], str]:
    if skill_id in _SKILL_CUES:
        return _SKILL_CUES[skill_id]
    skill=SKILLS[skill_id]
    return ((skill.name.casefold(),), f"Ich setze {skill.name} kontrolliert an der markierten Übungssituation ein.")


def build_class_tutorial_state(start_class: str, talents: list[str] | tuple[str, ...]) -> dict[str, Any]:
    cls=str(start_class or "").upper()
    selected=[str(x).upper() for x in talents]
    steps=[]
    for tid in selected:
        talent=TALENTS[tid]
        primary=talent.required_skills[0]
        _,hint=_cue_for_skill(primary)
        steps.append({
            "talent_id":tid,
            "skill_id":primary,
            "situation_tags":list(talent.situations),
            "hint":hint,
            "completed":False,
        })
    return {
        "schema":CLASS_TUTORIAL_SCHEMA,
        "start_class":cls,
        "status":"ACTIVE" if steps else "COMPLETE",
        "step_index":0,
        "steps":steps,
        "attempts":[],
        "rewards":{},
        "world_mutation_allowed":False,
    }


class ClassTutorialError(RuntimeError):
    pass


@dataclass
class ClassTutorialRuntime:
    session: Any
    actor_id: str = PLAYER_ACTOR_ID

    def state(self) -> dict[str, Any] | None:
        state=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,CLASS_TUTORIAL_STATE_KEY)
        if state is None:
            return None
        if not isinstance(state,dict) or state.get("schema")!=CLASS_TUTORIAL_SCHEMA:
            raise ClassTutorialError("CLASS_TUTORIAL_STATE_INVALID")
        return deepcopy(state)

    def active(self) -> bool:
        state=self.state()
        return bool(state and state.get("status")=="ACTIVE")

    def _current(self, state: Mapping[str, Any]) -> Mapping[str, Any] | None:
        index=int(state.get("step_index",0))
        steps=state.get("steps") or []
        return steps[index] if 0 <= index < len(steps) else None

    def text(self) -> str:
        state=self.state()
        if not state:
            return "Für diesen älteren Run ist keine Klassen-Tutorialrunde gespeichert."
        if state.get("status")=="SKIPPED":
            return "Klassen-Tutorial wurde übersprungen."
        if state.get("status")=="COMPLETE":
            return "Klassen-Tutorial abgeschlossen. Alle gewählten Starttalente wurden mindestens einmal in einer sicheren Kalibrierung angewendet."
        step=self._current(state)
        if not step:
            return "Klassen-Tutorial abgeschlossen."
        talent=TALENTS[step["talent_id"]]
        frame=_CLASS_FRAMES.get(state["start_class"],"Ein kurzer Kalibrierbereich prüft deine gewählten Starttalente.")
        n=int(state["step_index"])+1; total=len(state["steps"])
        situations=", ".join(talent.situations[:3])
        return (
            f"Klassen-Tutorial — {state['start_class']} — Schritt {n}/{total}\n"
            f"{frame}\n"
            f"Jetzt: {talent.name} — {talent.description}\n"
            f"Geeignete Situation: {situations}.\n"
            f"Formuliere die Handlung frei. Beispiel: {step['hint']}\n"
            "Die Kalibrierung vergibt keine XP, Items, Credits, Stats, Skills oder zusätzlichen Talente. /tutorial überspringen beendet sie ohne Belohnung."
        )

    def _matches(self, raw: str, step: Mapping[str, Any]) -> bool:
        text=str(raw or "").casefold()
        cues,_=_cue_for_skill(str(step["skill_id"]))
        if any(cue.casefold() in text for cue in cues):
            return True
        # Talent situation tags are additional natural-language cues.  Ignore
        # very short tokens to avoid accidental matches on articles/prepositions.
        for tag in step.get("situation_tags") or ():
            for word in re.findall(r"[\wäöüß]+",str(tag).casefold()):
                if len(word)>=5 and re.search(r"(?<!\w)"+re.escape(word)+r"(?!\w)",text):
                    return True
        return False

    def attempt(self, raw: str) -> tuple[str, bool]:
        state=self.state()
        if not state or state.get("status")!="ACTIVE":
            return self.text(), True
        step=self._current(state)
        if not step:
            return self.text(), True
        if not self._matches(raw,step):
            return "Die Handlung demonstriert das aktuelle Talent noch nicht eindeutig.\n"+self.text(), False
        actor=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,self.actor_id)
        if not isinstance(actor,dict):
            raise ClassTutorialError("CLASS_TUTORIAL_PLAYER_MISSING")
        tid=str(step["talent_id"]); skill_id=str(step["skill_id"])
        talent=TALENTS[tid]
        cap=assess_action(actor,skill_id,1,context_tags=tuple(talent.situations)+("tutorial",state["start_class"]))
        if cap.talent_id != tid:
            raise ClassTutorialError("CLASS_TUTORIAL_TALENT_NOT_APPLIED:"+tid)
        success,roll,target=deterministic_uncertain_success(cap,f"{self.session.identity.run_uuid}|tutorial|{tid}|{len(state['attempts'])}")
        attempt={
            "talent_id":tid,"skill_id":skill_id,"zone":cap.zone.value,"talent_applied":cap.talent_id,
            "success":bool(success),"roll":int(roll),"target":int(target),"raw":str(raw)[:240],
        }
        state["attempts"].append(attempt)
        if success:
            index=int(state["step_index"])
            state["steps"][index]["completed"]=True
            state["step_index"]=index+1
            if state["step_index"]>=len(state["steps"]):
                state["status"]="COMPLETE"
        self._commit(state,"CLASS_TUTORIAL_ATTEMPT")
        if not success:
            return f"{talent.name} wurde tatsächlich angesetzt, aber die Probe scheitert ({cap.zone.value}; Wurf {roll}/{target}). Versuche es erneut.\n"+self.text(), False
        if state["status"]=="COMPLETE":
            return f"{talent.name} angewendet — {cap.zone.value}. Klassen-Tutorial abgeschlossen.", True
        return f"{talent.name} angewendet — {cap.zone.value}.\n\n"+self.text(), False

    def skip(self) -> str:
        state=self.state()
        if not state:
            return "Für diesen Run existiert keine Tutorialrunde."
        if state.get("status")!="ACTIVE":
            return self.text()
        state["status"]="SKIPPED"
        self._commit(state,"CLASS_TUTORIAL_SKIP")
        return "Klassen-Tutorial übersprungen. Es wurden keine Belohnungen oder Charakterwerte verändert."

    def _commit(self, state: dict[str, Any], cause: str) -> None:
        event=f"{cause}:{self.session.store.revision}"
        result=self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,event_id=event,cause=cause,
            expected_state_revision=self.session.store.revision,
            deltas=(Delta(Domain.RUNTIME_STATE,CLASS_TUTORIAL_STATE_KEY,state,Authority.RULE_KERNEL,cause,
                          source_event_id=event,provenance="CLASS_TUTORIAL_PROGRESS"),),
        ))
        if not isinstance(result,CommitRecord):
            raise ClassTutorialError(cause+"_COMMIT_REJECTED")
