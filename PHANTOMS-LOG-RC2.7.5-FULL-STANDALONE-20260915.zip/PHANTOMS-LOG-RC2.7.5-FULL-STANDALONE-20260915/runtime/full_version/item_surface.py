from __future__ import annotations

from dataclasses import dataclass
from hashlib import blake2b
import json

from .content_distribution import ContentDistributionResolver


@dataclass(frozen=True, slots=True)
class ItemSurface:
    display_name: str
    base_name: str
    culture_id: str
    culture_suffix: str
    surface_description: str
    hybrid_culture: bool
    location_id: str
    variant_key: str

    def to_dict(self) -> dict:
        return {
            'display_name': self.display_name,
            'base_name': self.base_name,
            'culture_id': self.culture_id,
            'culture_suffix': self.culture_suffix,
            'surface_description': self.surface_description,
            'hybrid_culture': self.hybrid_culture,
            'location_id': self.location_id,
            'variant_key': self.variant_key,
        }


class ItemSurfaceResolver:
    """Presentation/provenance resolver for concrete item instances.

    It may alter only the surface label/description of an instance. Canonical item
    definition, mechanics and authority state remain untouched.
    """
    def __init__(self, catalog):
        self.catalog = catalog
        raw = json.loads((catalog.root/'content/full_version/item_surface_variants.json').read_text(encoding='utf-8'))
        if raw.get('schema') != 'PH4NT0M5_ITEM_SURFACE_VARIANTS_V1':
            raise ValueError('ITEM_SURFACE_VARIANT_SCHEMA_INVALID')
        self.raw = raw
        self.cultures = raw['cultures']
        self.overrides = raw.get('item_overrides', {})
        self.distribution = ContentDistributionResolver(catalog)

    def resolve(self, item_definition_id: str, location_id: str, *, run_uuid: str='', instance_id: str='', culture_id: str='', lineage_id: str='') -> ItemSurface:
        idef = self.catalog.item_definition(item_definition_id)
        base = str(idef['display_name'])
        kind = str(idef['kind'])
        dist = self.distribution.resolve(item_definition_id, location_id, run_uuid=run_uuid, culture_id=culture_id, lineage_id=lineage_id)
        cid = dist.culture_id
        style = self.cultures.get(cid)
        if not style:
            return ItemSurface(base, base, cid, '', '', False, location_id, 'canonical')
        override = self.overrides.get(item_definition_id, {}).get(cid)
        suffix = str(style.get('suffix','')).strip()
        display = str(override or (f'{base} – {suffix}' if suffix else base))
        desc = str(style.get(kind, '')).strip()
        # variant_key is stable and lets saves/audits compare the chosen surface.
        seed = f'{run_uuid}|{instance_id}|{item_definition_id}|{location_id}|{cid}|ITEM_SURFACE_V1'
        digest = blake2b(seed.encode('utf-8'), digest_size=8).hexdigest()
        return ItemSurface(display, base, cid, suffix, desc, dist.hybrid_culture, location_id, digest)

    def display_for_instance(self, item_record: dict, *, fallback_location_id: str='', run_uuid: str='') -> str:
        saved = item_record.get('surface_variant')
        if isinstance(saved, dict) and saved.get('display_name'):
            return str(saved['display_name'])
        iid = str(item_record.get('item_definition_id',''))
        if not iid:
            return ''
        location = str(item_record.get('source_location_id') or item_record.get('surface_origin_location_id') or fallback_location_id)
        if location:
            try:
                return self.resolve(iid, location, run_uuid=run_uuid).display_name
            except Exception:
                pass
        return str(self.catalog.item_definition(iid)['display_name'])
