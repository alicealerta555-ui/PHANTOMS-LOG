# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

"""Full-version historical Stage 7: competing NEEDS as actor-local attractors.

NEEDS never authorize an action and never imply consent, desire, relationship or truth.
Persistent pressure changes follow semantic EffectProposal -> StateAuthority -> CommitKernel.
"""

from dataclasses import dataclass
import copy, json
from pathlib import Path
from typing import Any, Mapping, Sequence

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal, ValidationResult, Verdict
from runtime.stage3c.isolation import RunSession
from runtime.stage9.actors import RunActorRegistry, Stage9ActorError
from runtime.stage9.authority import AuthorityDecision, AuthorityStatus
from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType

STAGE7_RUNTIME_KEY="__content_stage7_needs__"

class Stage7NeedError(RuntimeError): pass

@dataclass(frozen=True, slots=True)
class NeedPressure:
    need_key:str
    pressure_ppm:int

@dataclass(frozen=True, slots=True)
class NeedSnapshot:
    run_uuid:str
    actor_instance_id:str
    pressures:tuple[NeedPressure,...]

class Stage7NeedCatalog:
    def __init__(self, raw:Mapping[str,Any]): self.raw=copy.deepcopy(dict(raw)); self.validate(); self._profiles={p['profile_id']:copy.deepcopy(p) for p in self.raw['profiles']}
    @classmethod
    def load(cls,path:Path)->"Stage7NeedCatalog": return cls(json.loads(Path(path).read_text(encoding='utf-8')))
    def validate(self)->None:
        if self.raw.get('schema')!='PH4NT0M5-L0G_STAGE7_NEEDS_V1': raise Stage7NeedError('STAGE7_SCHEMA_INVALID')
        keys=self.raw.get('need_keys')
        if not isinstance(keys,list) or not keys or len(keys)!=len(set(keys)): raise Stage7NeedError('STAGE7_NEED_KEYS_INVALID')
        for p in self.raw.get('profiles',[]):
            if set(p.get('initial_pressure_ppm',{}))!=set(keys) or set(p.get('hourly_delta_ppm',{}))!=set(keys): raise Stage7NeedError('STAGE7_PROFILE_INCOMPLETE')
            for value in p['initial_pressure_ppm'].values():
                if isinstance(value,bool) or not isinstance(value,int) or not 0<=value<=1_000_000: raise Stage7NeedError('STAGE7_INITIAL_PRESSURE_INVALID')
        for mods in self.raw.get('event_modifiers',{}).values():
            if not isinstance(mods,Mapping) or not set(mods)<=set(keys): raise Stage7NeedError('STAGE7_EVENT_MODIFIER_INVALID')
        aliases=self.raw.get('legacy_need_aliases',{})
        if not isinstance(aliases,Mapping) or not set(aliases.values())<=set(keys): raise Stage7NeedError('STAGE7_NEED_ALIAS_INVALID')
        profiles={p.get('profile_id') for p in self.raw.get('profiles',[])}
        branch_map=self.raw.get('branch_profile_map',{})
        if not isinstance(branch_map,Mapping) or not set(branch_map.values())<=profiles: raise Stage7NeedError('STAGE7_BRANCH_PROFILE_INVALID')
    @property
    def need_keys(self)->tuple[str,...]: return tuple(self.raw['need_keys'])
    def profile(self,profile_id:str)->Mapping[str,Any]:
        try:return copy.deepcopy(self._profiles[profile_id])
        except KeyError as exc: raise Stage7NeedError(f'NEED_PROFILE_UNKNOWN:{profile_id}') from exc
    def event_modifier(self,event_type:str)->Mapping[str,int]: return copy.deepcopy(dict(self.raw.get('event_modifiers',{}).get(event_type,{})))
    def normalize_need_key(self,need_key:str)->str:
        key=str(need_key); return str(self.raw.get('legacy_need_aliases',{}).get(key,key))
    def profile_for_branch(self,branch_class:str)->Mapping[str,Any]:
        try: profile_id=self.raw['branch_profile_map'][str(branch_class).upper()]
        except KeyError as exc: raise Stage7NeedError(f'NEED_BRANCH_UNKNOWN:{branch_class}') from exc
        return self.profile(profile_id)

class Stage7NeedReader:
    def __init__(self,session:RunSession,actor_registry:RunActorRegistry): self.session=session; self.registry=actor_registry
    def _root(self)->dict[str,Any]:
        raw=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,STAGE7_RUNTIME_KEY)
        if raw is None:return {'run_uuid':self.session.identity.run_uuid,'actors':{}}
        if not isinstance(raw,Mapping) or raw.get('run_uuid')!=self.session.identity.run_uuid or not isinstance(raw.get('actors'),Mapping): raise Stage7NeedError('STAGE7_STATE_CORRUPT')
        return copy.deepcopy(dict(raw))
    def snapshot_for_actor(self,actor_instance_id:str)->NeedSnapshot:
        try:self.registry.get(actor_instance_id)
        except Stage9ActorError as exc: raise Stage7NeedError(str(exc)) from exc
        root=self._root(); raw=dict(root['actors'].get(actor_instance_id,{})); pressures=[]
        for k,v in sorted(raw.get('pressures_ppm',{}).items()):
            if isinstance(v,bool) or not isinstance(v,int) or not 0<=v<=1_000_000: raise Stage7NeedError('STAGE7_PRESSURE_CORRUPT')
            pressures.append(NeedPressure(k,v))
        return NeedSnapshot(self.session.identity.run_uuid,actor_instance_id,tuple(pressures))

class Stage7NeedEngine:
    def __init__(self,session:RunSession,actor_registry:RunActorRegistry,catalog:Stage7NeedCatalog): self.session=session; self.registry=actor_registry; self.catalog=catalog; self.reader=Stage7NeedReader(session,actor_registry)
    def initialization_map(self,profile_id:str)->Mapping[str,int]: return dict(self.catalog.profile(profile_id)['initial_pressure_ppm'])
    def time_deltas(self,profile_id:str,seconds:int)->Mapping[str,int]:
        if isinstance(seconds,bool) or not isinstance(seconds,int) or seconds<0: raise Stage7NeedError('NEED_TIME_INVALID')
        rates=self.catalog.profile(profile_id)['hourly_delta_ppm']; return {k:(int(v)*seconds)//3600 for k,v in rates.items() if (int(v)*seconds)//3600!=0}
    def event_deltas(self,event_type:str)->Mapping[str,int]: return self.catalog.event_modifier(event_type)
    def proposals(self,actor_instance_id:str,deltas:Mapping[str,int],*,cause_ref:str,resolution_id:str,source_action_id:str,effect_prefix:str)->tuple[EffectProposal,...]:
        try:self.registry.get(actor_instance_id)
        except Stage9ActorError as exc: raise Stage7NeedError(str(exc)) from exc
        known=set(self.catalog.need_keys); out=[]
        for idx,(key,delta) in enumerate(sorted(deltas.items()),1):
            if key not in known: raise Stage7NeedError(f'NEED_KEY_UNKNOWN:{key}')
            if isinstance(delta,bool) or not isinstance(delta,int) or delta==0: continue
            out.append(EffectProposal(effect_id=f'{effect_prefix}:{idx:02d}',run_uuid=self.session.identity.run_uuid,resolution_id=resolution_id,source_action_id=source_action_id,
                effect_type=EffectType.NEED_DELTA,target_ref=actor_instance_id,payload={'actor_instance_id':actor_instance_id,'need_key':key,'delta_ppm':delta,'cause_ref':cause_ref},
                authority_domain=AuthorityDomain.NEEDS,expected_state_revision=self.session.store.revision))
        return tuple(out)
    def ranked_pressures(self,actor_instance_id:str)->tuple[NeedPressure,...]:
        snap=self.reader.snapshot_for_actor(actor_instance_id)
        return tuple(sorted(snap.pressures,key=lambda x:(-x.pressure_ppm,x.need_key)))

class Stage7CommitAdapter:
    def __init__(self,session:RunSession,actor_registry:RunActorRegistry): self.session=session; self.registry=actor_registry; self.reader=Stage7NeedReader(session,actor_registry)
    def bootstrap_actor(self,actor_instance_id:str,pressures:Mapping[str,int],*,profile_id:str,event_id:str)->CommitRecord|ValidationResult:
        try:self.registry.get(actor_instance_id)
        except Stage9ActorError as exc: raise Stage7NeedError(str(exc)) from exc
        raw=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,STAGE7_RUNTIME_KEY)
        root=copy.deepcopy(dict(raw)) if isinstance(raw,Mapping) else {'run_uuid':self.session.identity.run_uuid,'actors':{}}
        if root.get('run_uuid')!=self.session.identity.run_uuid: raise Stage7NeedError('RUN_ISOLATION_VIOLATION')
        actors=copy.deepcopy(dict(root.get('actors',{})))
        if actor_instance_id in actors: raise Stage7NeedError('NEED_ACTOR_ALREADY_INITIALIZED')
        vals={}
        for k,v in pressures.items():
            if isinstance(v,bool) or not isinstance(v,int) or not 0<=v<=1_000_000: raise Stage7NeedError('NEED_BOOTSTRAP_PRESSURE_INVALID')
            vals[k]=v
        actors[actor_instance_id]={'profile_id':profile_id,'pressures_ppm':vals,'last_cause_ref':'BOOTSTRAP'}; root['actors']=actors
        rev=self.session.store.revision
        delta=Delta(Domain.RUNTIME_STATE,STAGE7_RUNTIME_KEY,root,Authority.SYSTEM_INIT,'CONTENT_S7_BOOTSTRAP',Mode.COMMIT,source_event_id=event_id,provenance='FULL_VERSION_NEEDS_BOOTSTRAP')
        return self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(delta,),event_id=event_id,cause='CONTENT_S7_BOOTSTRAP',expected_state_revision=rev))
    def apply_many(self,decisions:Sequence[AuthorityDecision],*,commit_id:str,event_id:str)->CommitRecord|ValidationResult:
        if not decisions: raise Stage7NeedError('STAGE7_DECISIONS_REQUIRED')
        revision=self.session.store.revision
        raw=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,STAGE7_RUNTIME_KEY)
        root=copy.deepcopy(dict(raw)) if isinstance(raw,Mapping) else {'run_uuid':self.session.identity.run_uuid,'actors':{}}
        if root.get('run_uuid')!=self.session.identity.run_uuid: raise Stage7NeedError('RUN_ISOLATION_VIOLATION')
        actors=copy.deepcopy(dict(root.get('actors',{}))); ids=[]
        for d in decisions:
            if d.status!=AuthorityStatus.ALLOW or d.commit_operation is None: raise Stage7NeedError('STAGE7_AUTHORITY_ALLOW_REQUIRED')
            op=d.commit_operation
            if op.approved_state_revision!=revision or op.authority_domain!=AuthorityDomain.NEEDS or op.effect_type!=EffectType.NEED_DELTA: raise Stage7NeedError('STAGE7_AUTHORITY_OR_EFFECT_INVALID')
            p=dict(op.payload); aid=p['actor_instance_id']
            try:self.registry.get(aid)
            except Stage9ActorError as exc: raise Stage7NeedError(str(exc)) from exc
            current=copy.deepcopy(dict(actors.get(aid,{'profile_id':'unassigned','pressures_ppm':{}}))); vals=copy.deepcopy(dict(current.get('pressures_ppm',{})))
            old=int(vals.get(p['need_key'],0)); vals[p['need_key']]=max(0,min(1_000_000,old+int(p['delta_ppm']))); current['pressures_ppm']=vals; current['last_cause_ref']=p['cause_ref']; actors[aid]=current; ids.append(op.effect_id)
        root['actors']=actors
        delta=Delta(Domain.RUNTIME_STATE,STAGE7_RUNTIME_KEY,root,Authority.RULE_KERNEL,'CONTENT_S7_MUTATION',Mode.COMMIT,source_event_id=event_id,provenance='|'.join(f'EFFECT:{x}' for x in ids))
        result=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(delta,),event_id=event_id,cause='CONTENT_S7_ATOMIC_COMMIT',expected_state_revision=revision,commit_id=commit_id,effect_ids=tuple(ids)))
        if isinstance(result,ValidationResult) and result.verdict not in {Verdict.HOLD,Verdict.PASS}: raise Stage7NeedError('STAGE7_COMMIT_REJECTED')
        return result
