
def clamp(v,a,b): return max(a,min(b,v))
def extraction(amount_requested, source_capacity, elapsed_days):
    if float(elapsed_days)<=0: return 0
    return max(0,min(int(amount_requested), int(source_capacity*float(elapsed_days))))
def treatment(raw_amount, capacity, efficiency_bp):
    processed=min(max(0,int(raw_amount)),max(0,int(capacity)))
    clean=processed*clamp(int(efficiency_bp),0,10000)//10000
    return {"processed":processed,"treated":clean,"residual":processed-clean}
def storage_add(current,incoming,capacity):
    cur=max(0,int(current)); inc=max(0,int(incoming)); cap=max(0,int(capacity))
    accepted=min(inc,max(0,cap-cur))
    return {"stored":cur+accepted,"accepted":accepted,"overflow":inc-accepted}
def distribution(supply,demand,line_capacity,loss_bp=0):
    sent=min(max(0,int(supply)),max(0,int(demand)),max(0,int(line_capacity)))
    loss=sent*clamp(int(loss_bp),0,10000)//10000
    return {"sent":sent,"loss":loss,"delivered":sent-loss,"unmet":max(0,int(demand)-(sent-loss))}
def contamination_candidate(water_ref, contaminant, severity, cause_ref, causal_event_id):
    if not water_ref or not contaminant or not cause_ref: return None
    return {"kind":"WATER_CONTAMINATION_CANDIDATE","water_ref":water_ref,"contaminant":contaminant,
            "severity":clamp(int(severity),0,100),"cause_ref":cause_ref,"causal_event_id":causal_event_id,
            "authority_required":True}
def purification_candidate(water_ref, amount, treatment_id, causal_event_id):
    if not water_ref or int(amount)<=0 or not treatment_id: return None
    return {"kind":"WATER_PURIFICATION_CANDIDATE","water_ref":water_ref,"amount":int(amount),
            "treatment_id":treatment_id,"causal_event_id":causal_event_id,"authority_required":True}
