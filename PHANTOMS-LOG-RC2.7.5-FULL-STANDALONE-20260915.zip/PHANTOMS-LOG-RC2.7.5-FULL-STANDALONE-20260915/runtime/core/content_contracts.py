# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional, Tuple


class MissionPersistence(str, Enum):
    RANDOM_EPHEMERAL = "RANDOM_EPHEMERAL"
    PERSISTENT_ECHO = "PERSISTENT_ECHO"
    PERSISTENT_WORLD_CHANGE = "PERSISTENT_WORLD_CHANGE"


class SolutionFamily(str, Enum):
    DIRECT = "DIRECT"
    STEALTH = "STEALTH"
    TECHNICAL = "TECHNICAL"


@dataclass(frozen=True)
class MissionContract:
    mission_id: str
    persistence: MissionPersistence
    solution_families: Tuple[SolutionFamily, ...]
    solvability_promised: bool = True

    def validate(self) -> None:
        if not self.mission_id:
            raise ValueError("MISSION_ID_REQUIRED")
        if self.solvability_promised and not self.solution_families:
            raise ValueError("PROMISED_SOLVABILITY_WITHOUT_REAL_PATH")
        if len(self.solution_families) != len(set(self.solution_families)):
            raise ValueError("DUPLICATE_SOLUTION_FAMILY")


@dataclass(frozen=True)
class CatalogEntryContract:
    item_id: str
    category: str
    provenance: str
    access_class: Optional[str] = None

    def validate(self) -> None:
        if not self.item_id or not self.category or not self.provenance:
            raise ValueError("CATALOG_ID_CATEGORY_PROVENANCE_REQUIRED")


@dataclass(frozen=True)
class BestiaryEntryContract:
    entity_id: str
    lineage: str
    habitat_tags: Tuple[str, ...]
    counterplay_tags: Tuple[str, ...]
    provenance: str

    def validate(self) -> None:
        if not self.entity_id or not self.lineage or not self.provenance:
            raise ValueError("BESTIARY_ID_LINEAGE_PROVENANCE_REQUIRED")
        if not self.counterplay_tags:
            raise ValueError("BESTIARY_COUNTERPLAY_REQUIRED")
