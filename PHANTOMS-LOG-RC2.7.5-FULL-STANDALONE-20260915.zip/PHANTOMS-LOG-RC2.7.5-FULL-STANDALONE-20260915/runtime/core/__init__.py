# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Static Stage-1/2 engine contracts reconstructed for the current PH4NT0M5-L0G master.

This package intentionally contains no concrete player/save/run state.
"""

from .contracts import CORE_LAWS, CoreLaw, assert_no_legacy_run_contamination
from .chronology import CANONICAL_EPOCHS, Epoch, validate_canonical_epochs
from .world_sim import (
    PHASES,
    RelevanceTier,
    SimulationCadence,
    SimulationEvent,
    SimulationResult,
    WorldSimOrchestrator,
)

__all__ = [
    "CORE_LAWS",
    "CoreLaw",
    "assert_no_legacy_run_contamination",
    "CANONICAL_EPOCHS",
    "Epoch",
    "validate_canonical_epochs",
    "PHASES",
    "RelevanceTier",
    "SimulationCadence",
    "SimulationEvent",
    "SimulationResult",
    "WorldSimOrchestrator",
]
