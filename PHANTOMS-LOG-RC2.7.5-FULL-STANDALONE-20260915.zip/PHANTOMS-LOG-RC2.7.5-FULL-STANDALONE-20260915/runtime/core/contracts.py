# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Iterable


class CoreLaw(str, Enum):
    WORLD_BEFORE_STORY = "WORLD_BEFORE_STORY"
    CAUSES_BEFORE_CONSEQUENCES = "CAUSES_BEFORE_CONSEQUENCES"
    RANDOMIZE_UNKNOWN_SIMULATE_KNOWN = "RANDOMIZE_UNKNOWN_SIMULATE_KNOWN"
    NO_REALITY_WRITE_FROM_QUERY = "NO_REALITY_WRITE_FROM_QUERY"
    NO_REROLL_RESOLVED_TRUTH = "NO_REROLL_RESOLVED_TRUTH"
    PLAYER_EXPECTATION_NOT_TRUTH = "PLAYER_EXPECTATION_NOT_TRUTH"
    NPC_KNOWLEDGE_REQUIRES_CAUSAL_SOURCE = "NPC_KNOWLEDGE_REQUIRES_CAUSAL_SOURCE"
    NARRATION_AFTER_COMMIT = "NARRATION_AFTER_COMMIT"
    PLAYER_RUN_STATE_EXTERNAL_TO_STATIC_CORE = "PLAYER_RUN_STATE_EXTERNAL_TO_STATIC_CORE"
    PLAYER_RUN_ISOLATION_REQUIRED = "PLAYER_RUN_ISOLATION_REQUIRED"
    NAMED_ACTORS_PERSIST = "NAMED_ACTORS_PERSIST"
    WORLD_CONTINUES_OFFSCREEN = "WORLD_CONTINUES_OFFSCREEN"
    PLAYER_PRESENCE_NOT_WORLD_CAUSE = "PLAYER_PRESENCE_NOT_WORLD_CAUSE"
    INFORMATION_REQUIRES_CHANNEL = "INFORMATION_REQUIRES_CHANNEL"
    FREEFORM_PLAYER_INPUT = "FREEFORM_PLAYER_INPUT"
    FAILURE_LOSS_DEATH_ARE_REAL = "FAILURE_LOSS_DEATH_ARE_REAL"


CORE_LAWS = frozenset(CoreLaw)

def assert_no_legacy_run_contamination(paths: Iterable[Path], markers: Iterable[str]) -> None:
    """Fail if caller-supplied concrete run-state markers leaked into static core files.

    Marker values intentionally live outside the static core so the audit implementation
    cannot contaminate the very tree it is checking.
    """
    clean_markers = tuple(m for m in markers if m)
    hits: list[str] = []
    for path in paths:
        if not path.is_file() or path.suffix.lower() not in {".py", ".json", ".md", ".toml", ".yaml", ".yml"}:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for marker in clean_markers:
            if marker in text:
                hits.append(f"{path}:{marker}")
    if hits:
        raise RuntimeError("LEGACY_RUN_CONTAMINATION:" + "|".join(hits))
