# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Callable, Mapping, Optional, Sequence, Tuple

from runtime.stage3a.integration import FixedPhaseCommitBuffer, RuntimeAuthorityBridge, RuntimeDelta
from runtime.stage3a.kernel import CommitRecord, ValidationResult


PHASES: Tuple[str, ...] = tuple(f"P{i}" for i in range(10))


class RelevanceTier(str, Enum):
    HOT = "HOT"
    WARM = "WARM"
    COLD = "COLD"


@dataclass(frozen=True)
class SimulationCadence:
    """Configurable multi-rate policy.

    No numeric cadence is canonical here. A world/configuration chooses positive tick
    intervals; the static core only enforces the HOT/WARM/COLD multi-rate contract.
    """

    hot_every: int
    warm_every: int
    cold_every: int

    def __post_init__(self) -> None:
        vals = (self.hot_every, self.warm_every, self.cold_every)
        if any(not isinstance(v, int) or v <= 0 for v in vals):
            raise ValueError("CADENCE_MUST_BE_POSITIVE_INT")
        if not (self.hot_every <= self.warm_every <= self.cold_every):
            raise ValueError("CADENCE_ORDER_INVALID")

    def interval(self, tier: RelevanceTier) -> int:
        return {
            RelevanceTier.HOT: self.hot_every,
            RelevanceTier.WARM: self.warm_every,
            RelevanceTier.COLD: self.cold_every,
        }[tier]


@dataclass(frozen=True)
class SimulationEvent:
    event_id: str
    cause: str
    seed_ref: str
    tier: RelevanceTier
    tick: int

    def validate(self) -> None:
        if not self.event_id or not self.cause or not self.seed_ref:
            raise ValueError("EVENT_ID_CAUSE_SEED_REQUIRED")
        if self.tick < 0:
            raise ValueError("EVENT_TICK_NEGATIVE")


@dataclass(frozen=True)
class PhaseContext:
    event: SimulationEvent
    phase: str


@dataclass(frozen=True)
class SimulationResult:
    processed: bool
    phase_order: Tuple[str, ...]
    commit: Optional[CommitRecord | ValidationResult]
    presentation: Optional[dict]


PhaseProducer = Callable[[PhaseContext], Sequence[RuntimeDelta]]


class WorldSimOrchestrator:
    """Reconstructed Stage-1 world-sim shell aligned to the current authority kernel.

    Guarantees:
    - fixed P0..P9 order;
    - event-driven + configurable multi-rate HOT/WARM/COLD scheduling;
    - phases only emit deltas;
    - exactly one atomic commit after all phases;
    - player-facing projection only after commit;
    - player presence is not a valid event cause by itself.

    Detailed subsystem semantics remain modular and are supplied as phase producers.
    """

    def __init__(
        self,
        bridge: RuntimeAuthorityBridge,
        *,
        cadence: SimulationCadence,
        producers: Optional[Mapping[str, PhaseProducer]] = None,
    ):
        self.bridge = bridge
        self.cadence = cadence
        self.producers = dict(producers or {})
        unknown = set(self.producers) - set(PHASES)
        if unknown:
            raise ValueError(f"UNKNOWN_PHASE_PRODUCER:{sorted(unknown)}")

    def due(self, event: SimulationEvent) -> bool:
        event.validate()
        return event.tick % self.cadence.interval(event.tier) == 0

    def run(
        self,
        event: SimulationEvent,
        *,
        narration_runtime_keys: Sequence[str] = (),
    ) -> SimulationResult:
        event.validate()
        if event.cause.strip().upper() in {"PLAYER_PRESENT", "PLAYER_PRESENCE", "PLAYER_IS_HERE"}:
            raise ValueError("PLAYER_PRESENCE_NOT_VALID_WORLD_CAUSE")
        if not self.due(event):
            return SimulationResult(False, (), None, None)

        buffer = FixedPhaseCommitBuffer(self.bridge, event.event_id, event.cause)
        executed: list[str] = []
        delta_count = 0
        for phase in PHASES:
            executed.append(phase)
            producer = self.producers.get(phase)
            if producer is None:
                continue
            for delta in tuple(producer(PhaseContext(event=event, phase=phase))):
                if not isinstance(delta, RuntimeDelta):
                    raise TypeError(f"PHASE_DELTA_TYPE_INVALID:{phase}")
                buffer.add(phase, delta)
                delta_count += 1

        # A due world tick with no state change is still a valid processed tick, but it
        # must not manufacture an empty ledger commit merely to advance revision.
        commit = buffer.commit_once() if delta_count else None
        presentation = self.bridge.project_player_narration(runtime_keys=narration_runtime_keys)
        return SimulationResult(True, tuple(executed), commit, presentation)
