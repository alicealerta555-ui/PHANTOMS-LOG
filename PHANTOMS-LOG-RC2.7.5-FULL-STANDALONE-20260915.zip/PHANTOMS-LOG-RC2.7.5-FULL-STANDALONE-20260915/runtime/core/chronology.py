# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple


CRY_MIN = 0
CRY_T0 = 10_000


@dataclass(frozen=True)
class Epoch:
    epoch_id: str
    order: int
    title: str
    causal_role: str
    prerequisites: Tuple[str, ...] = ()


# Stage-2 canonical causal spine. These are broad foundation epochs, not claims that all
# cultures share one public historical account. Public records may be incomplete or false.
CANONICAL_EPOCHS: Tuple[Epoch, ...] = (
    Epoch("E0", 0, "Pre-world biotechnology and automation", "establishes technical/biological precursor capacity"),
    Epoch("E1", 1, "Early Gen-Slicing", "moves modification from bounded therapy/adaptation toward wider engineered change", ("E0",)),
    Epoch("E2", 2, "Expanded Gen-Slicing and hybridization", "widens engineered lineages and social/technical dependence", ("E1",)),
    Epoch("E3", 3, "Failure of comprehensive registration/control", "breaks complete capture, governance and traceability of altered populations", ("E2",)),
    Epoch("E4", 4, "Feralization and distributed survival", "creates long-lived uncaptured populations and divergent survival pressures", ("E3",)),
    Epoch("E5", 5, "Isolation, drift and sublineages", "produces regionally divergent lineages, cultures and later hybrid societies", ("E4",)),
)


def validate_canonical_epochs(epochs: Tuple[Epoch, ...] = CANONICAL_EPOCHS) -> None:
    if not epochs:
        raise ValueError("EPOCHS_EMPTY")
    ids = [e.epoch_id for e in epochs]
    if len(ids) != len(set(ids)):
        raise ValueError("DUPLICATE_EPOCH_ID")
    if [e.order for e in epochs] != list(range(len(epochs))):
        raise ValueError("EPOCH_ORDER_NOT_CONTIGUOUS")
    seen: set[str] = set()
    for epoch in epochs:
        if any(req not in seen for req in epoch.prerequisites):
            raise ValueError(f"EPOCH_PREREQUISITE_NOT_PRIOR:{epoch.epoch_id}")
        seen.add(epoch.epoch_id)
    if CRY_MIN >= CRY_T0:
        raise ValueError("CANONICAL_TIME_AXIS_INVALID")
