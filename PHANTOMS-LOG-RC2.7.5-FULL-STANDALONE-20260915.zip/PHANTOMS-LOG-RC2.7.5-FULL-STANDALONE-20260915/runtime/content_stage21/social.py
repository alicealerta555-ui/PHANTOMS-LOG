
def clamp(v,a,b): return max(a,min(b,v))

def social_score(skill, relationship_bp=0, context_bp=0, pressure_bp=0):
    raw=int(skill)*100 + int(relationship_bp) + int(context_bp) + int(pressure_bp)
    return clamp(raw,0,10000)

def social_check_candidate(actor_id,target_id,action_id,score,threshold,causal_event_id):
    success=int(score)>=int(threshold)
    return {
        "kind":"SOCIAL_CHECK_CANDIDATE",
        "actor_id":actor_id,
        "target_actor_id":target_id,
        "action_id":action_id,
        "score":int(score),
        "threshold":int(threshold),
        "success":success,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def persuasion_influence(success, base_delta=10, conflict_bp=0):
    if not success:
        return {"respect":0,"trust":0,"decision_forced":False}
    reduction=max(0,min(10000,int(conflict_bp)))
    delta=max(0,int(base_delta)*(10000-reduction)//10000)
    return {"respect":delta,"trust":delta//2,"decision_forced":False}

def deception_candidate(success, claim, listener_knows_contradiction=False, plausibility_bp=5000):
    if not success:
        return {"belief_pressure":0,"claim":claim,"auto_belief":False}
    if listener_knows_contradiction:
        return {"belief_pressure":0,"claim":claim,"auto_belief":False}
    return {
        "belief_pressure":clamp(int(plausibility_bp),0,10000),
        "claim":claim,
        "auto_belief":False
    }

def intimidation_influence(success, magnitude=10):
    if not success:
        return {"fear":0,"hostility":0,"guaranteed_compliance":False}
    m=max(0,int(magnitude))
    return {
        "fear":clamp(m,0,100),
        "hostility":clamp(max(1,m//2),0,100),
        "guaranteed_compliance":False
    }

def influence_proposal(actor_id,target_id,action_id,deltas,causal_event_id):
    return {
        "kind":"SOCIAL_INFLUENCE_PROPOSAL",
        "actor_id":actor_id,
        "target_actor_id":target_id,
        "action_id":action_id,
        "deltas":dict(deltas),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }
