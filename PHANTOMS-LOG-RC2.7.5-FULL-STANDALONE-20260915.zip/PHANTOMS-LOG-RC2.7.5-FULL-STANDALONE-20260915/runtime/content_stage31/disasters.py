
def clamp(v,a,b): return max(a,min(b,v))

def disaster_event(disaster_type, source_location_id, trigger, started_at, intensity, causal_event_id):
    if not disaster_type or not source_location_id or not trigger:
        return None
    return {
        "kind":"DISASTER_EVENT_CANDIDATE",
        "disaster_type":disaster_type,
        "source_location_id":source_location_id,
        "trigger":trigger,
        "started_at":int(started_at),
        "intensity":clamp(int(intensity),0,100),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def propagate_intensity(current_intensity, spread_bp_per_hour, elapsed_min, resistance_bp=0):
    if int(elapsed_min)<=0:
        return clamp(int(current_intensity),0,100)
    hours=max(0,int(elapsed_min))/60.0
    growth=int(round(100*(int(spread_bp_per_hour)/10000.0)*hours))
    growth=growth*max(0,10000-int(resistance_bp))//10000
    return clamp(int(current_intensity)+growth,0,100)

def propagation_candidate(event_id, from_location_id, to_location_id, connection_id, elapsed_min, intensity, causal_event_id):
    if not event_id or not from_location_id or not to_location_id or not connection_id:
        return None
    if from_location_id==to_location_id or int(elapsed_min)<=0:
        return None
    return {
        "kind":"DISASTER_PROPAGATION_CANDIDATE",
        "event_id":event_id,
        "from_location_id":from_location_id,
        "to_location_id":to_location_id,
        "connection_id":connection_id,
        "elapsed_min":int(elapsed_min),
        "intensity":clamp(int(intensity),0,100),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def infrastructure_damage_state(condition):
    c=clamp(int(condition),0,100)
    if c<=0: return "DESTROYED"
    if c<20: return "FAILED"
    if c<50: return "DAMAGED"
    if c<80: return "DEGRADED"
    return "INTACT"

def cascade_candidate(parent_event_id, child_event_type, location_id, trigger_condition, created_at, causal_event_id):
    if not parent_event_id or not child_event_type or not location_id or not trigger_condition:
        return None
    return {
        "kind":"DISASTER_CASCADE_CANDIDATE",
        "parent_event_id":parent_event_id,
        "child_event_type":child_event_type,
        "location_id":location_id,
        "trigger_condition":trigger_condition,
        "created_at":int(created_at),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def evacuation_proposal(origin_location_id,destination_location_id,route_id,actor_ids,started_at,causal_event_id):
    if not origin_location_id or not destination_location_id or not route_id or not actor_ids:
        return None
    if origin_location_id==destination_location_id:
        return None
    return {
        "kind":"EVACUATION_PROPOSAL",
        "origin_location_id":origin_location_id,
        "destination_location_id":destination_location_id,
        "route_id":route_id,
        "actor_ids":list(actor_ids),
        "started_at":int(started_at),
        "success_guaranteed":False,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }
