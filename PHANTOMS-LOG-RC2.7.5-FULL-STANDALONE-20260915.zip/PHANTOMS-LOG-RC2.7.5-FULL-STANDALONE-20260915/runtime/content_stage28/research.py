
def clamp(v,a,b): return max(a,min(b,v))

def discovery_record(subject_id, observer_actor_id, location_id, observed_at, evidence):
    return {
        "subject_id":subject_id,
        "observer_actor_id":observer_actor_id,
        "location_id":location_id,
        "observed_at":int(observed_at),
        "evidence":list(evidence or []),
        "knowledge_state":"OBSERVED"
    }

def research_progress(current_progress, base_progress, skill_value, difficulty, elapsed_min):
    if int(elapsed_min)<=0:
        return int(current_progress)
    skill_factor=max(0,int(skill_value)-int(difficulty)+50)
    gain=max(0,int(base_progress))*skill_factor//50
    gain=gain*max(1,int(elapsed_min))//60
    return clamp(int(current_progress)+gain,0,100)

def knowledge_state_from_progress(progress):
    p=int(progress)
    if p<=0: return "UNKNOWN"
    if p<25: return "OBSERVED"
    if p<60: return "HYPOTHESIZED"
    if p<90: return "UNDERSTOOD"
    return "REPRODUCIBLE"

def reverse_engineering_candidate(artifact_id, actor_id, tool_ids, location_id, elapsed_min, skill_value, difficulty, causal_event_id):
    if not artifact_id or not actor_id or not location_id:
        return None
    if not tool_ids or int(elapsed_min)<=0:
        return None
    progress=research_progress(0,22,skill_value,difficulty,elapsed_min)
    return {
        "kind":"REVERSE_ENGINEERING_CANDIDATE",
        "artifact_id":artifact_id,
        "actor_id":actor_id,
        "tool_ids":list(tool_ids),
        "location_id":location_id,
        "elapsed_min":int(elapsed_min),
        "progress":progress,
        "knowledge_state":knowledge_state_from_progress(progress),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def knowledge_transfer_proposal(knowledge_id,sender_actor_id,receiver_actor_id,channel_id,content_scope,causal_event_id):
    if not knowledge_id or not sender_actor_id or not receiver_actor_id or not channel_id:
        return None
    if sender_actor_id==receiver_actor_id:
        return None
    return {
        "kind":"KNOWLEDGE_TRANSFER_PROPOSAL",
        "knowledge_id":knowledge_id,
        "sender_actor_id":sender_actor_id,
        "receiver_actor_id":receiver_actor_id,
        "channel_id":channel_id,
        "content_scope":content_scope,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def reproducibility_candidate(knowledge_state, tools_available, materials_available, infrastructure_available, causal_event_id):
    reproducible=(knowledge_state=="REPRODUCIBLE" and bool(tools_available) and bool(materials_available) and bool(infrastructure_available))
    return {
        "kind":"REPRODUCIBILITY_CANDIDATE",
        "reproducible":reproducible,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }
