from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Optional, Sequence

from .model import PlayerProgressionState
from .insights import InsightDefinition
from .paths import SpecializationDefinition, MasteryDefinition, EndPathDefinition
from .habits import HabitDefinition


# Player-facing language only. Internal affinity identifiers never leave this module.
_AFFINITY_VOICE: Dict[str, tuple[str, str]] = {
    "AFF_FORCE": (
        "Du gehst Hindernisse zunehmend direkt an und verlässt dich darauf, dass Entschlossenheit Raum schafft.",
        "Direktes Vorgehen wird für dich immer selbstverständlicher.",
    ),
    "AFF_ENDURANCE": (
        "Belastung bringt dich seltener aus deinem Rhythmus. Du hast gelernt, unter Druck weiterzuarbeiten.",
        "Du entwickelst eine bemerkenswerte Ruhe unter Belastung.",
    ),
    "AFF_PROTECTION": (
        "Du achtest immer häufiger darauf, wer neben dir gefährdet ist, und stellst dich instinktiv dazwischen.",
        "Andere profitieren zunehmend davon, dass du Verantwortung für ihre Sicherheit übernimmst.",
    ),
    "AFF_PRECISION": (
        "Du wartest lieber auf den richtigen Moment, statt eine gute Gelegenheit mit einem hastigen Versuch zu verschwenden.",
        "Deine Handlungen werden ruhiger, gezielter und bewusster.",
    ),
    "AFF_STEALTH": (
        "Du bewegst dich immer öfter so, dass andere erst spät bemerken, dass du überhaupt da warst.",
        "Unauffälligkeit wird für dich weniger Technik und mehr Gewohnheit.",
    ),
    "AFF_MOBILITY": (
        "Du denkst Räume zunehmend in Wegen, Winkeln und Bewegungsmöglichkeiten statt nur in Positionen.",
        "Bewegung wird zu einem festen Teil deiner Problemlösung.",
    ),
    "AFF_PERCEPTION": (
        "Kleine Veränderungen in Bewegung, Geräusch und Licht fallen dir früher auf als noch zu Beginn.",
        "Du liest Situationen zunehmend über Details, die andere leicht übersehen.",
    ),
    "AFF_TECH": (
        "Maschinen wirken auf dich immer weniger wie geschlossene Gehäuse und immer mehr wie verständliche Zusammenhänge.",
        "Technische Probleme beginnen dir vertraut vorzukommen.",
    ),
    "AFF_NETWORK": (
        "Digitale Systeme erscheinen dir zunehmend wie Räume mit Gewohnheiten, Zugängen und blinden Winkeln.",
        "Du erkennst in vernetzten Systemen schneller Muster und Schwachstellen.",
    ),
    "AFF_MACHINE": (
        "Du koordinierst Geräte immer selbstverständlicher, als wären sie zusätzliche Hände und Augen.",
        "Maschinen fügen sich zunehmend in deinen eigenen Handlungsrhythmus ein.",
    ),
    "AFF_MEDICAL": (
        "Bei Verletzten erkennst du schneller, was sofort wichtig ist und was warten kann.",
        "Dein Umgang mit Verletzungen wird ruhiger und sicherer.",
    ),
    "AFF_SURVIVAL": (
        "Du schaust auf eine Umgebung inzwischen auch danach, was dich hier morgen noch am Leben hält.",
        "Improvisation und Vorsorge werden zu festen Teilen deines Denkens.",
    ),
    "AFF_RESONANCE": (
        "Manche Veränderungen spürst du inzwischen, bevor du sie sauber erklären kannst.",
        "Dein Gespür für ungewöhnliche Zustände wird verlässlicher, ohne völlig berechenbar zu werden.",
    ),
    "AFF_SOCIAL": (
        "Du achtest stärker darauf, was Menschen sagen, was sie vermeiden und worauf sie tatsächlich reagieren.",
        "Gespräche werden für dich zunehmend zu etwas, das man lesen und lenken kann.",
    ),
    "AFF_COMMAND": (
        "Du denkst immer öfter darüber nach, wie mehrere Menschen gemeinsam besser handeln können als jeder für sich.",
        "Koordination wird für dich zu einer eigenen Form von Stärke.",
    ),
    "AFF_ADAPTATION": (
        "Wenn ein Plan scheitert, suchst du inzwischen schneller nach einer anderen brauchbaren Lösung statt nach dem ursprünglichen Weg.",
        "Ungewöhnliche Situationen bringen dich immer seltener aus dem Konzept.",
    ),
}

_CLASS_OPENING = {
    "BREAKER": "Du hast früh gelernt, dass manche Probleme nur nachgeben, wenn jemand bereit ist, den ersten Schritt durch sie hindurch zu machen.",
    "GHOST": "Du verlässt dich auf Bewegung, Timing und den Moment, in dem Aufmerksamkeit woanders liegt.",
    "OPERATOR": "Du behandelst Technik, Wissen und Vorbereitung nicht als Zubehör, sondern als eigentliche Waffen.",
    "RESONANT": "Du nimmst Veränderungen wahr, die sich nicht immer sofort in einfache Ursachen übersetzen lassen.",
}

_CLASS_TONE = {
    "BREAKER": "Dein Stil wird körperlicher und entschlossener, ohne deshalb eindimensional zu werden.",
    "GHOST": "Dein Stil wird leiser, präziser und schwerer vorhersehbar.",
    "OPERATOR": "Dein Stil wird vorbereiteter, vernetzter und lösungsorientierter.",
    "RESONANT": "Dein Stil wird intuitiver und stärker von feinen Zustandswechseln geprägt.",
}


@dataclass(frozen=True)
class PlayerMessage:
    kind: str
    title: str
    body: str
    detail: Optional[str] = None
    options: tuple[dict, ...] = ()

    def to_dict(self) -> dict:
        out = {"kind": self.kind, "title": self.title, "body": self.body}
        if self.detail:
            out["detail"] = self.detail
        if self.options:
            out["options"] = [dict(x) for x in self.options]
        return out


class DevelopmentPresenter:
    """The only canonical player-facing projection of hidden progression.

    Internal numbers, affinity keys, thresholds, scores and effect identifiers are
    intentionally stripped here. The runtime may calculate; the player receives
    meaning, identity and consequences in natural language.
    """

    def insight_unlock(self, d: InsightDefinition, *, context_line: Optional[str] = None) -> dict:
        body = context_line.strip() if context_line else self._insight_context(d)
        return PlayerMessage(
            kind="erkenntnis",
            title=d.name,
            body=body,
            detail=d.player_text,
        ).to_dict()

    def specialization_offer(self, defs: Sequence[SpecializationDefinition], state: PlayerProgressionState) -> dict:
        options = tuple({"name": d.name, "description": d.description} for d in defs)
        return PlayerMessage(
            kind="entwicklung",
            title="Dein Stil nimmt Form an",
            body=self._specialization_intro(state),
            detail="Nicht jeder Weg passt noch gleich gut zu dem, was du aus dir gemacht hast. Diese Richtungen fühlen sich inzwischen natürlich an.",
            options=options,
        ).to_dict()

    def specialization_committed(self, d: SpecializationDefinition) -> dict:
        return PlayerMessage(
            kind="spezialisierung",
            title=d.name,
            body=d.description,
            detail="Das ist keine Grenze. Es ist der Bereich, in dem deine bisherigen Erfahrungen am stärksten zusammenfinden.",
        ).to_dict()

    def mastery_reveal(self, d: MasteryDefinition) -> dict:
        return PlayerMessage(
            kind="meisterpfad",
            title=d.name,
            body=d.description,
            detail=f"Neue Signatur: {d.signature_name} — {d.signature_description}",
        ).to_dict()

    def end_path_reveal(self, d: EndPathDefinition) -> dict:
        return PlayerMessage(
            kind="endpfad",
            title=d.name,
            body=d.description,
            detail=f"Was einmal Technik war, ist Teil deiner Identität geworden. {d.signature_name}: {d.signature_description}",
        ).to_dict()

    def habit_transition(self, d: HabitDefinition, transition: str) -> dict:
        if transition == "formed":
            return PlayerMessage("gewohnheit", "Wird zur Gewohnheit", d.player_description,
                                 d.mild_drawback).to_dict() | {"name": d.name}
        if transition == "instinct":
            return PlayerMessage("instinkt", "Ist zum Instinkt geworden", d.instinct_description,
                                 d.mild_drawback).to_dict() | {"name": d.instinct_name}
        if transition == "fading":
            return PlayerMessage("gewohnheit", "Eine Gewohnheit verliert an Kraft",
                                 f"{d.name} bestimmt dein Handeln nicht mehr so selbstverständlich wie früher.").to_dict()
        if transition == "broken":
            return PlayerMessage("gewohnheit", "Gewohnheit abgelegt",
                                 f"{d.name} gehört nicht mehr zu deinen automatischen Routinen.").to_dict()
        return PlayerMessage("gewohnheit", "Dein Stil verändert sich", d.player_description).to_dict()

    def habit_snapshot(self, records) -> dict:
        items = []
        for d, rec in records:
            state_word = "Instinkt" if rec.stage == "instinct" else ("im Wandel" if rec.stage == "fading" else "Gewohnheit")
            text = d.instinct_description if rec.stage == "instinct" else d.player_description
            item = {"name": d.instinct_name if rec.stage == "instinct" else d.name, "status": state_word, "description": text}
            if d.mild_drawback:
                item["nuance"] = d.mild_drawback
            items.append(item)
        return {
            "kind": "gewohnheiten",
            "title": "Was dir in Fleisch und Blut übergeht",
            "summary": "Wiederholte Entscheidungen prägen deinen Charakter. Manche Routinen helfen, manche haben Ecken und Kanten, und nichts davon steht über deinem eigenen Entschluss.",
            "entries": items,
        }

    def instinct_action(self, choice_key: str, narrative_hint: str) -> dict:
        # choice_key is intentionally mapped to a host-facing opaque action field rather than explained numerically.
        return {"kind": "instinktaktion", "choice": choice_key, "narration": narrative_hint}

    def development_snapshot(self, state: PlayerProgressionState, *, max_traits: int = 4) -> dict:
        ranked = self._ranked_affinities(state)
        selected = [k for k, value in ranked if value > 0][:max_traits]
        if not selected:
            traits = ["Dein Stil ist noch offen. Erst wiederholte Entscheidungen werden zeigen, worauf du dich wirklich verlässt."]
        else:
            traits = [_AFFINITY_VOICE[k][0] for k in selected]

        return {
            "kind": "charakterentwicklung",
            "title": "Wie du dich entwickelt hast",
            "identity": _CLASS_OPENING[state.start_class],
            "summary": _CLASS_TONE[state.start_class],
            "observations": traits,
            "direction": self._direction_line(selected),
        }

    def soft_growth_hint(self, state: PlayerProgressionState) -> Optional[dict]:
        ranked = self._ranked_affinities(state)
        active = [k for k, value in ranked if value > 0]
        if not active:
            return None
        key = active[0]
        return PlayerMessage(
            kind="entwicklungshinweis",
            title="Etwas wird zur Gewohnheit",
            body=_AFFINITY_VOICE[key][1],
        ).to_dict()

    @staticmethod
    def _ranked_affinities(state: PlayerProgressionState) -> List[tuple[str, float]]:
        # Deterministic internal order; numeric values are never copied to output.
        return sorted(state.affinities.items(), key=lambda kv: (-kv[1], kv[0]))

    @staticmethod
    def _direction_line(selected: Sequence[str]) -> str:
        s = set(selected)
        if {"AFF_STEALTH", "AFF_TECH"} <= s or {"AFF_STEALTH", "AFF_NETWORK"} <= s:
            return "Dein Weg verbindet unauffälliges Vorgehen zunehmend mit technischer Kontrolle."
        if {"AFF_FORCE", "AFF_PROTECTION"} <= s:
            return "Du setzt Kraft immer häufiger ein, um Raum und Sicherheit für andere zu schaffen."
        if {"AFF_TECH", "AFF_RESONANCE"} <= s or {"AFF_MACHINE", "AFF_RESONANCE"} <= s:
            return "Technisches Verständnis und dein Gespür für ungewöhnliche Zustände beginnen ineinanderzugreifen."
        if {"AFF_MOBILITY", "AFF_PRECISION"} <= s:
            return "Bewegung und Präzision verschmelzen zunehmend zu einem einzigen Kampfrhythmus."
        if {"AFF_MEDICAL", "AFF_PROTECTION"} <= s:
            return "Du entwickelst dich zu jemandem, der Gefahr nicht nur übersteht, sondern ihre Folgen für andere begrenzt."
        if {"AFF_SOCIAL", "AFF_COMMAND"} <= s:
            return "Deine Stärke verlagert sich zunehmend darauf, Menschen zu lesen und gemeinsames Handeln zu formen."
        if not selected:
            return "Noch hat sich keine Richtung fest genug eingeprägt, um deinen Weg sinnvoll zu benennen."
        return "Dein Weg wird klarer, ohne dich auf eine einzige Art zu handeln festzulegen."

    @staticmethod
    def _specialization_intro(state: PlayerProgressionState) -> str:
        ranked = [k for k, v in DevelopmentPresenter._ranked_affinities(state) if v > 0][:2]
        if not ranked:
            return "Du hast genug erlebt, um zu merken, welche Art von Entscheidungen dir liegt."
        lines = [_AFFINITY_VOICE[k][1] for k in ranked]
        return " ".join(lines)

    @staticmethod
    def _insight_context(d: InsightDefinition) -> str:
        families = set(d.action_families)
        if families & {"repair", "craft", "mod", "salvage"}:
            return "Du bemerkst, dass deine Hände den nächsten Schritt schon vorbereiten, bevor du ihn bewusst formulierst."
        if families & {"stealth", "move", "climb", "escape"}:
            return "Eine Bewegung, die früher Konzentration verlangt hätte, fühlt sich plötzlich selbstverständlich an."
        if families & {"heal", "stabilize", "treat"}:
            return "Inmitten des Drucks erkennst du, dass du nicht mehr suchen musst, was zuerst getan werden muss."
        if families & {"aim", "ranged_attack", "shoot"}:
            return "Der richtige Augenblick wirkt für einen Moment nicht wie eine Entscheidung, sondern wie etwas Offensichtliches."
        if families & {"protect", "rescue", "command"}:
            return "Du handelst, bevor du darüber nachdenkst, wer geschützt werden muss und wo du dafür stehen solltest."
        if families & {"hack", "scan_network", "remote_control", "drone"}:
            return "Das System vor dir wirkt plötzlich weniger wie eine Oberfläche und mehr wie ein Ablauf, dessen Gewohnheiten du kennst."
        if families & {"resonate", "sense", "observe"}:
            return "Etwas an der Situation kommt dir bekannt vor, obwohl du es nicht auf einen einzelnen Hinweis reduzieren kannst."
        return "Du erkennst im eigenen Handeln ein Muster, das inzwischen mehr ist als bloße Übung."


def assert_player_payload_clean(payload: object) -> None:
    """Fail closed if hidden progression implementation details leak to UI payloads."""
    forbidden_keys = {
        "score", "threshold", "readiness", "affinity", "affinities", "effect_key",
        "pattern_evidence", "requirements", "required", "weight", "weights",
    }
    hidden_tokens = {
        "AFF_FORCE", "AFF_ENDURANCE", "AFF_PROTECTION", "AFF_PRECISION", "AFF_STEALTH", "AFF_MOBILITY",
        "AFF_PERCEPTION", "AFF_TECH", "AFF_NETWORK", "AFF_MACHINE", "AFF_MEDICAL", "AFF_SURVIVAL",
        "AFF_RESONANCE", "AFF_SOCIAL", "AFF_COMMAND", "AFF_ADAPTATION",
    }

    def walk(x: object) -> None:
        if isinstance(x, Mapping):
            for k, v in x.items():
                if str(k).lower() in forbidden_keys:
                    raise ValueError(f"hidden progression key leaked: {k}")
                walk(v)
        elif isinstance(x, (list, tuple)):
            for item in x:
                walk(item)
        elif isinstance(x, (int, float)) and not isinstance(x, bool):
            raise ValueError("numeric progression value leaked to player payload")
        elif isinstance(x, str):
            # Internal uppercase affinity names are never valid player-facing copy.
            words = set(x.replace("/", " ").replace("-", " ").split())
            leaked = words & hidden_tokens
            if leaked:
                raise ValueError(f"hidden affinity token leaked: {sorted(leaked)[0]}")

    walk(payload)
