from __future__ import annotations

from dataclasses import dataclass, field, asdict
from hashlib import sha256
import random
from typing import Dict, Iterable, Mapping, Optional, Sequence


@dataclass(frozen=True)
class NamingProfile:
    profile_id: str
    onsets: tuple[str, ...]
    nuclei: tuple[str, ...]
    codas: tuple[str, ...]
    separators: tuple[str, ...] = ("", "-", "'")
    min_syllables: int = 1
    max_syllables: int = 3
    double_chance: float = 0.08
    rhyme_chance: float = 0.10
    mirror_chance: float = 0.08
    echo_chance: float = 0.10
    chain_chance: float = 0.10
    alien_transcription_chance: float = 0.0
    callsign_bridge_chance: float = 0.0
    preferred_marks: tuple[str, ...] = ()
    human_readable_bias: float = 1.0


@dataclass(frozen=True)
class NameRequest:
    npc_id: str
    species_profile: str
    culture_profile: Optional[str] = None
    given_name_hint: Optional[str] = None
    family_name_hint: Optional[str] = None
    allow_callsign: bool = True
    force_callsign: bool = False
    social_context: str = "unknown"
    known_to_player: bool = False


@dataclass(frozen=True)
class GeneratedNPCName:
    npc_id: str
    canonical_given: str
    family_or_line: Optional[str]
    callsign: Optional[str]
    full_name: str
    display_name: str
    species_profile: str
    culture_profile: Optional[str]
    transcription_note: Optional[str] = None
    callsign_origin: Optional[str] = None
    phonetic_pattern: Optional[str] = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class NPCNameRegistry:
    names: Dict[str, GeneratedNPCName] = field(default_factory=dict)
    used_full_names: set[str] = field(default_factory=set)
    schema_version: int = 1

    def register(self, value: GeneratedNPCName) -> None:
        self.names[value.npc_id] = value
        self.used_full_names.add(value.full_name)

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "names": {k: v.to_dict() for k, v in self.names.items()},
            "used_full_names": sorted(self.used_full_names),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "NPCNameRegistry":
        obj = cls(schema_version=int(data.get("schema_version", 1)))
        for key, raw in dict(data.get("names", {})).items():
            obj.names[key] = GeneratedNPCName(**raw)
        obj.used_full_names = set(data.get("used_full_names", []))
        if not obj.used_full_names:
            obj.used_full_names = {x.full_name for x in obj.names.values()}
        return obj


CALLSIGNS = (
    "Switch", "Rook", "Moth", "Patch", "Latch", "Ash", "Glass", "Null",
    "Echo", "Rattle", "Clack", "Needle", "Wisp", "Moss", "Jaw", "Knell",
    "Wire", "Static", "Pale", "Spoke", "Hush", "Flint", "Relay", "Vex",
)

HUMAN_GIVEN = (
    "Mara", "Samira", "Daniel", "Karel", "Min-jun", "Amina", "Ilyan", "Tessa",
    "Leonie", "Ravi", "Nadia", "Tariq", "Mika", "Elena", "Noah", "Yuna",
)
HUMAN_FAMILY = (
    "Vuković", "Okafor", "Krämer", "Idris", "Nguyen", "Serrano", "Omura",
    "Darzi", "Becker", "Kovács", "Park", "Mensah", "Rahman", "Novak",
)

PROFILES: Mapping[str, NamingProfile] = {
    "baseline_human": NamingProfile(
        "baseline_human", ("",), ("a",), ("",), separators=("",),
        min_syllables=1, max_syllables=1, human_readable_bias=1.0,
    ),
    "genmorph": NamingProfile(
        "genmorph",
        ("n", "m", "l", "v", "s", "r", "k", "t", "ae", "zh"),
        ("a", "e", "i", "o", "u", "ae", "ei"),
        ("n", "r", "s", "l", "m", "v", "k", ""),
        separators=("", "-", "'"), min_syllables=2, max_syllables=3,
        double_chance=.10, rhyme_chance=.08, mirror_chance=.05, echo_chance=.08,
        chain_chance=.08, callsign_bridge_chance=.15,
    ),
    "chimera": NamingProfile(
        "chimera",
        ("kh", "gh", "tz", "vr", "kr", "sh", "rh", "qh", "k", "v"),
        ("a", "aa", "u", "uu", "e", "ae", "o"),
        ("rr", "kk", "zh", "th", "n", "r", "k", ""),
        separators=("", "-", "'", "·"), min_syllables=1, max_syllables=3,
        double_chance=.28, rhyme_chance=.18, mirror_chance=.16, echo_chance=.18,
        chain_chance=.20, alien_transcription_chance=.15, callsign_bridge_chance=.45,
        preferred_marks=("'", "-", "·"), human_readable_bias=.55,
    ),
    "ferrite": NamingProfile(
        "ferrite",
        ("kk", "k", "t", "d", "dr", "vr", "q", "x", "g", "gr"),
        ("a", "aa", "o", "u", "e"),
        ("rr", "kk", "tt", "g", "r", "k", "x", ""),
        separators=("-", "'", "·", ""), min_syllables=1, max_syllables=3,
        double_chance=.38, rhyme_chance=.16, mirror_chance=.18, echo_chance=.14,
        chain_chance=.24, alien_transcription_chance=.12, callsign_bridge_chance=.50,
        preferred_marks=("-", "'", "·"), human_readable_bias=.45,
    ),
    "silicier": NamingProfile(
        "silicier",
        ("s", "ss", "z", "zz", "x", "v", "q", "l", "n"),
        ("i", "ii", "e", "ae", "ei", "a"),
        ("l", "n", "r", "x", "q", "v", ""),
        separators=(":", "·", "-", "'", ""), min_syllables=1, max_syllables=3,
        double_chance=.25, rhyme_chance=.14, mirror_chance=.26, echo_chance=.20,
        chain_chance=.18, alien_transcription_chance=.12, callsign_bridge_chance=.40,
        preferred_marks=(":", "·"), human_readable_bias=.55,
    ),
    "mycelial": NamingProfile(
        "mycelial",
        ("m", "mm", "n", "nn", "l", "vh", "hh", "mh", "nh"),
        ("a", "aa", "ae", "ou", "uu", "oo", "e"),
        ("m", "n", "l", "r", "vh", "h", ""),
        separators=("'", "·", "-", ""), min_syllables=1, max_syllables=3,
        double_chance=.30, rhyme_chance=.25, mirror_chance=.14, echo_chance=.26,
        chain_chance=.18, alien_transcription_chance=.18, callsign_bridge_chance=.38,
        preferred_marks=("'", "·"), human_readable_bias=.50,
    ),
    "mimetic": NamingProfile(
        "mimetic",
        ("m", "j", "v", "s", "an", "sa", "jo", "ma"),
        ("a", "o", "i", "e", "aa"),
        ("r", "n", "m", "k", ""),
        separators=("-", ":", "//", "'", ""), min_syllables=1, max_syllables=3,
        double_chance=.16, rhyme_chance=.12, mirror_chance=.22, echo_chance=.28,
        chain_chance=.16, alien_transcription_chance=.10, callsign_bridge_chance=.30,
        preferred_marks=("//", ":", "-"), human_readable_bias=.65,
    ),
    "swarm": NamingProfile(
        "swarm",
        ("k", "t", "s", "ss", "n", "h", "kh", "tek", "nar"),
        ("a", "e", "u", "aa", "uu"),
        ("k", "n", "r", "sh", "th", ""),
        separators=("-", "·", "//", "'"), min_syllables=1, max_syllables=3,
        double_chance=.22, rhyme_chance=.18, mirror_chance=.22, echo_chance=.34,
        chain_chance=.40, alien_transcription_chance=.25, callsign_bridge_chance=.62,
        preferred_marks=("·", "//", "-"), human_readable_bias=.30,
    ),
    "thresholdborn": NamingProfile(
        "thresholdborn",
        ("qh", "qhh", "tz", "tzh", "ss", "rrh", "vlh", "kth", "ghr", "nkh", "khh"),
        ("aa", "aae", "ii", "uu", "ae", "ë", "oa", "eo"),
        ("rr", "rrh", "ll", "tz", "q", "kh", "nh", ""),
        separators=("'", "·", "-", ":", "//", "~"), min_syllables=1, max_syllables=4,
        double_chance=.42, rhyme_chance=.26, mirror_chance=.35, echo_chance=.35,
        chain_chance=.34, alien_transcription_chance=.62, callsign_bridge_chance=.72,
        preferred_marks=("'", "·", "~", ":"), human_readable_bias=.10,
    ),
}


class NPCNameGenerator:
    """Deterministic, persistent NPC naming with species/culture phonotactics.

    Species provides physical/phonetic affordances. Culture may override style.
    Generated names are deterministic by npc_id + seed and MUST be persisted once
    established so later encounters never silently rename an NPC.
    """

    def __init__(self, registry: Optional[NPCNameRegistry] = None, seed: str = "PH4NT0M5-L0G"):
        self.registry = registry or NPCNameRegistry()
        self.seed = seed

    def _rng(self, request: NameRequest, salt: str = "") -> random.Random:
        raw = f"{self.seed}|{request.npc_id}|{request.species_profile}|{request.culture_profile or ''}|{salt}"
        return random.Random(int(sha256(raw.encode("utf-8")).hexdigest(), 16))

    @staticmethod
    def _cap(token: str) -> str:
        if not token:
            return token
        return token[0].upper() + token[1:]

    @staticmethod
    def _mirror(text: str) -> str:
        clean = "".join(ch for ch in text.lower() if ch.isalpha())
        if len(clean) < 2:
            return text
        rev = clean[::-1]
        return NPCNameGenerator._cap(rev)

    def _syllable(self, p: NamingProfile, rng: random.Random) -> str:
        return rng.choice(p.onsets) + rng.choice(p.nuclei) + rng.choice(p.codas)

    def _base_word(self, p: NamingProfile, rng: random.Random) -> str:
        n = rng.randint(p.min_syllables, p.max_syllables)
        bits = [self._syllable(p, rng) for _ in range(n)]
        word = "".join(bits)
        if rng.random() < p.double_chance and len(word) >= 3:
            idx = rng.randrange(1, len(word))
            if word[idx-1].isalpha():
                word = word[:idx] + word[idx-1] + word[idx:]
        return self._cap(word)

    def _patterned_name(self, p: NamingProfile, rng: random.Random) -> tuple[str, str]:
        base = self._base_word(p, rng)
        roll = rng.random()
        cuts = [
            (p.mirror_chance, "mirror"),
            (p.rhyme_chance, "rhyme"),
            (p.echo_chance, "echo"),
            (p.chain_chance, "chain"),
        ]
        total = sum(x[0] for x in cuts)
        if total <= 0 or roll >= min(total, .92):
            return base, "normal"
        cursor = 0.0
        for chance, label in cuts:
            cursor += chance
            if roll < cursor:
                sep = rng.choice(p.preferred_marks or p.separators)
                if label == "mirror":
                    return f"{base}{sep}{self._mirror(base)}", label
                if label == "rhyme":
                    second = self._base_word(p, rng)
                    # Force a shared tail without requiring perfect human phonology.
                    tail = ''.join(ch for ch in base[-2:] if ch.isalpha()) or base[-1:]
                    second = (second[:-len(tail)] if len(second) > len(tail) else second) + tail
                    return f"{base}{sep}{self._cap(second)}", label
                if label == "echo":
                    echo = base[-max(2, len(base)//3):]
                    return f"{base}{sep}{self._cap(echo)}", label
                if label == "chain":
                    count = rng.choice((2, 3))
                    parts = [base] + [self._base_word(p, rng) for _ in range(count-1)]
                    return sep.join(parts), label
        return base, "normal"

    def _culture_override(self, request: NameRequest) -> Optional[NamingProfile]:
        if request.culture_profile and request.culture_profile in PROFILES:
            return PROFILES[request.culture_profile]
        return None

    def _human_name(self, request: NameRequest, rng: random.Random) -> tuple[str, str]:
        given = request.given_name_hint or rng.choice(HUMAN_GIVEN)
        family = request.family_name_hint or rng.choice(HUMAN_FAMILY)
        return given, family

    def _callsign(self, rng: random.Random, phonetic_pattern: str, given: str) -> tuple[str, str]:
        if phonetic_pattern in {"echo", "mirror", "chain"}:
            preferred = ["Echo", "Rattle", "Clack", "Hush", "Static", "Relay"]
            value = rng.choice(preferred)
            return value, "derived from the name's sound or repetition pattern"
        value = rng.choice(CALLSIGNS)
        return value, "social callsign retained as part of the NPC's persistent identity"

    def generate(self, request: NameRequest) -> GeneratedNPCName:
        existing = self.registry.names.get(request.npc_id)
        if existing:
            return existing

        rng = self._rng(request)
        species = PROFILES.get(request.species_profile)
        if not species:
            raise KeyError(f"Unknown species naming profile: {request.species_profile}")
        profile = self._culture_override(request) or species

        if profile.profile_id == "baseline_human":
            given, family = self._human_name(request, rng)
            pattern = "human"
        else:
            given = request.given_name_hint or self._patterned_name(profile, rng)[0]
            _, pattern = self._patterned_name(profile, self._rng(request, "pattern"))
            family = request.family_name_hint
            if family is None:
                family, _ = self._patterned_name(profile, self._rng(request, "family"))

        # Hybrid raised in a human culture may fully inherit the human naming system.
        if request.culture_profile == "baseline_human":
            given, family = self._human_name(request, rng)
            pattern = "human_culture_override"

        callsign = None
        callsign_origin = None
        want_callsign = request.allow_callsign and (
            request.force_callsign or rng.random() < max(profile.callsign_bridge_chance, .22)
        )
        if want_callsign:
            callsign, callsign_origin = self._callsign(rng, pattern, given)

        transcription_note = None
        if profile.profile_id != "baseline_human" and rng.random() < profile.alien_transcription_chance:
            transcription_note = "Approximate human transcription; original pronunciation may contain non-human or unresolved phonetic elements."

        parts = [given]
        if callsign:
            parts.append(f'“{callsign}”')
        if family:
            parts.append(family)
        full = " ".join(parts)

        # Deterministic collision repair without changing established identities.
        if full in self.registry.used_full_names:
            suffix = self._rng(request, "collision").choice(("II", "·2", "-Ka", "'R"))
            family = f"{family or given}{suffix}"
            parts = [given] + ([f'“{callsign}”'] if callsign else []) + [family]
            full = " ".join(parts)

        display = full if request.known_to_player else "Unbekannte Person"
        value = GeneratedNPCName(
            npc_id=request.npc_id,
            canonical_given=given,
            family_or_line=family,
            callsign=callsign,
            full_name=full,
            display_name=display,
            species_profile=request.species_profile,
            culture_profile=request.culture_profile,
            transcription_note=transcription_note,
            callsign_origin=callsign_origin,
            phonetic_pattern=pattern,
        )
        self.registry.register(value)
        return value

    def reveal(self, npc_id: str, level: str = "callsign") -> str:
        value = self.registry.names[npc_id]
        if level == "unknown":
            return "Unbekannte Person"
        if level == "given":
            return value.canonical_given
        if level == "callsign" and value.callsign:
            return f"{value.canonical_given} “{value.callsign}”"
        return value.full_name
