from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple

from runtime.full_version.capability_catalog import SKILLS, TALENTS

@dataclass(frozen=True, slots=True)
class ClassAbility:
    ability_id: str
    name: str
    owner: str
    tier: int
    pool_id: str
    kind: str
    contexts: Tuple[str, ...]
    description: str
    check_bonus: int = 1
    npc_policy: str = "NO_FORCED_COMPLIANCE"
    required_stats: Tuple[str, ...] = ()
    required_skills: Tuple[str, ...] = ()
    talent_roots: Tuple[str, ...] = ()

# Class abilities are specializations of the canonical character capability tree.
# They never replace Stats/Skills/Talents and cannot bypass natural capability limits.
# A run only receives definitions reachable from its selected start class and committed path.

_BASE = {
 'BREAKER': [
  ('Impact Read','Reads stance, momentum and structural weak points before committing force.'),
  ('Brace','Turns posture and footing into resistance against forced movement.'),
  ('Pressure Step','Advances through danger without surrendering initiative.'),
  ('Guard Break','Uses timing and leverage to open a defended line.'),
  ('Pain Gate','Keeps a chosen action coherent while under acute pain.'),
  ('Hard Entry','Creates a controlled opening through a physical obstruction.'),
  ('Threat Posture','Signals credible readiness without automatically escalating to violence.'),
  ('Body Shield','Places the body between an immediate threat and another person.'),
  ('Kinetic Follow','Carries useful momentum from movement into the next physical action.'),
  ('Load Sense','Judges whether a surface, door or support can take force.'),
  ('Shock Control','Recovers faster from sudden impact, noise or physical surprise.'),
  ('Grip Lock','Maintains hold on tools, ledges or contested objects.'),
  ('Crowd Wedge','Finds a safe line through dense bodies or unstable movement.'),
  ('Breach Angle','Identifies the least wasteful angle for forcing an obstacle.'),
  ('Protective Advance','Moves while preserving cover for someone nearby.'),
  ('Force Reserve','Avoids spending maximum effort before it is necessary.'),
  ('Combat Read','Reads immediate hostile body language and attack preparation.'),
  ('Hold Ground','Resists panic-driven retreat when staying is still rational.'),
  ('Controlled Impact','Limits collateral damage when applying force.'),
  ('Last Push','Produces one bounded burst of physical effort at a cost in fatigue.'),
 ],
 'GHOST': [
  ('Peripheral Map','Builds a quiet map of exits, sightlines and observers.'),
  ('Noise Mask','Times movement inside existing environmental noise.'),
  ('Stillness','Reduces involuntary movement while hiding or observing.'),
  ('Shadow Route','Prefers paths that minimize exposure rather than distance.'),
  ('Attention Read','Notices where people are actually looking and what they ignore.'),
  ('Soft Step','Controls foot placement on unstable or noisy surfaces.'),
  ('Exit Memory','Retains escape routes after only brief observation.'),
  ('Blind Angle','Recognizes temporary gaps in another observer’s coverage.'),
  ('Motion Break','Interrupts predictable movement to become harder to track.'),
  ('Trace Sense','Notices subtle signs that someone recently passed through.'),
  ('Quiet Hands','Manipulates small objects with reduced accidental noise.'),
  ('Cover Blend','Uses ordinary clutter and posture instead of impossible invisibility.'),
  ('Distance Feel','Estimates range and timing without obvious measurement.'),
  ('Pursuit Read','Recognizes whether movement behind them is random or following.'),
  ('Low Profile','Reduces social salience through controlled, ordinary behavior.'),
  ('Window Watch','Observes a location without fixating on a single point.'),
  ('Route Pivot','Changes path cleanly when a planned route becomes exposed.'),
  ('Patient Aim','Improves precision when there is time to wait for the right moment.'),
  ('Silent Signal','Communicates simple intent with gesture and eye line.'),
  ('Disappear From Routine','Uses predictable routines to leave attention without magical concealment.'),
 ],
 'OPERATOR': [
  ('Diagnostic Sweep','Performs a fast, non-destructive first pass over a technical system.'),
  ('Fault Sound','Recognizes mechanical faults from vibration and sound.'),
  ('Safe Bypass','Identifies a bounded way around a failed component without pretending risk is gone.'),
  ('Field Repair','Restores limited function with available tools and parts.'),
  ('Power Trace','Follows energy flow through a device or local infrastructure.'),
  ('Interface Read','Identifies likely controls, ports and status indicators.'),
  ('Tool Economy','Chooses the smallest adequate tool set for a job.'),
  ('System Map','Builds a mental model of connected technical components.'),
  ('Failure Forecast','Recognizes signs that a machine is approaching a fault state.'),
  ('Signal Trace','Follows a visible or authorized signal path without granting hidden access.'),
  ('Patch Logic','Builds a temporary procedural workaround for a known failure.'),
  ('Machine Etiquette','Handles unfamiliar machinery conservatively to avoid needless damage.'),
  ('Sensor Check','Distinguishes sensor failure from a real environmental change.'),
  ('Improvised Fixture','Creates a temporary mechanical support or mount.'),
  ('Network Caution','Recognizes obvious access, logging and security risks before connecting.'),
  ('Maintenance Memory','Retains recurring fault patterns and service sequences.'),
  ('Remote Handling','Controls a linked device while preserving attention to local hazards.'),
  ('Resource Salvage','Identifies reusable components without assuming everything is compatible.'),
  ('Technical Explain','Explains a technical problem to an NPC in role-appropriate terms.'),
  ('Controlled Overdrive','Pushes a machine briefly beyond normal output with explicit risk.'),
 ],
 'RESONANT': [
  ('Resonance Sense','Passively notices unusual vibration, field, pressure or bio-signal patterns.'),
  ('Resonance Pulse','Actively probes nearby space for a coarse change in resonant response.'),
  ('Echo Touch','Reads residual vibration or field disturbance through direct contact.'),
  ('Inner Anchor','Maintains self-control during sensory overload or anomalous input.'),
  ('Pattern Memory','Recognizes a resonant pattern encountered before.'),
  ('Field Reading','Distinguishes stable background from meaningful local disturbance.'),
  ('Harmonic Ward','Dampens a bounded incoming resonant disturbance around the user.'),
  ('Resonant Mark','Memorizes a specific signal pattern for later comparison.'),
  ('Pressure Sense','Notices unusual pressure gradients, pulses or moving air masses.'),
  ('Vibration Sense','Reads movement transmitted through a contacted surface.'),
  ('Magnetic Sense','Notices strong or changing magnetic-field structure and ferrous disturbance.'),
  ('Bioelectric Sense','Detects coarse living electrical activity at close range; it is not thought reading.'),
  ('Spectrum Awareness','Notices anomalous light, heat or electromagnetic changes outside ordinary focus.'),
  ('Vestibular Read','Recognizes balance, orientation and motion disturbances in self or nearby movement.'),
  ('Emotional Echo','Notices strong stress or affect shifts without learning private thoughts.'),
  ('Resonant Push','Projects a short, low-power pressure/vibration impulse.'),
  ('Frequency Damping','Reduces one narrow band of local vibration or sound for a moment.'),
  ('Static Nudge','Produces a small controlled electrostatic disturbance.'),
  ('Harmonic Presence','Deliberately steadies voice, timing and bodily rhythm during tense conversation.'),
  ('Deep Attunement','Focuses intensely on one visible signal source at the cost of higher sensory load.'),
 ]
}

_SPEC_THEME = {
 'RAVAGER':('impact','momentum','pain','pressure'), 'BULWARK':('guard','protection','line','intercept'),
 'BREACHER':('breach','structure','shock','entry'), 'HUNTER':('trail','prey','terrain','pursuit'),
 'SHADE':('shadow','attention','silence','misdirection'), 'DEADEYE':('precision','range','weakpoint','timing'),
 'RUNNER':('momentum','route','vault','escape'), 'STALKER':('trace','habit','pursuit','ambush'),
 'GEARSMITH':('repair','fabrication','tool','mechanism'), 'NETSPIDER':('network','signal','access','trace'),
 'FIELD_MEDIC':('trauma','stabilize','triage','protection'), 'CONTROLLER':('drone','mesh','command','sensor'),
 'MENDER':('biofield','stabilize','healing','shield'), 'SEER':('echo','intent','prediction','pattern'),
 'FLUX':('magnetic','electric','frequency','adaptation'), 'VOIDCALLER':('null','damping','silence','absence'),
}

_MASTERY_THEME = {
 'BREAKER_TO_BREAKER':('dread','advance','armor','impact'), 'BREAKER_TO_GHOST':('razor','angle','precision','momentum'),
 'BREAKER_TO_OPERATOR':('iron','servo','weapon','machine'), 'BREAKER_TO_RESONANT':('warsaint','resonance','guard','force'),
 'GHOST_TO_BREAKER':('predator','ambush','force','hunt'), 'GHOST_TO_GHOST':('wraith','absence','shadow','motion'),
 'GHOST_TO_OPERATOR':('spectre','sensor','network','stealth'), 'GHOST_TO_RESONANT':('phase','echo','veil','motion'),
 'OPERATOR_TO_BREAKER':('wartech','armor','overdrive','impact'), 'OPERATOR_TO_GHOST':('nightwire','signal','stealth','intrusion'),
 'OPERATOR_TO_OPERATOR':('architect','system','fabrication','command'), 'OPERATOR_TO_RESONANT':('technomancer','field','machine','resonance'),
 'RESONANT_TO_BREAKER':('warprophet','impact','premonition','resonance'), 'RESONANT_TO_GHOST':('veilwalker','silence','phase','echo'),
 'RESONANT_TO_OPERATOR':('biosynth','bioelectric','machine','pattern'), 'RESONANT_TO_RESONANT':('ascendant','harmonic','field','perception'),
}

_END_THEME = {
 'THE_BASTION':('bastion','protection','command','endurance'), 'THE_DREADNOUGHT':('dreadnought','force','armor','machine'),
 'THE_LAST_HUNTER':('hunter','trail','precision','survival'), 'THE_GHOSTLINE':('ghostline','absence','mobility','perception'),
 'THE_ZERO':('zero','precision','stillness','adaptation'), 'THE_RUNNER':('runner','motion','endurance','route'),
 'THE_ARCHITECT':('architect','system','machine','network'), 'THE_BLACK_SIGNAL':('black signal','network','stealth','adaptation'),
 'THE_LIFELINE':('lifeline','medical','protection','command'), 'THE_SWARM':('swarm','machine','command','sensor'),
 'THE_FORGE':('forge','tech','survival','fabrication'), 'THE_SIGNAL':('signal','resonance','perception','social'),
 'THE_NULL':('null','damping','endurance','absence'), 'THE_MACHINE_ORACLE':('oracle','machine','resonance','prediction'),
 'THE_WARSAINT':('warsaint','resonance','protection','force'), 'THE_ADAPTIVE':('adaptive','survival','social','change'),
}

_PATTERNS = (
 ('Sense','passive',('perception','quest','npc_reaction'), 'Detects a useful {a} pattern before acting.'),
 ('Focus','active',('perception','quest'), 'Narrows attention onto {a} while accepting reduced awareness elsewhere.'),
 ('Ward','reaction',('combat','quest'), 'Creates a bounded defensive response using {a}.'),
 ('Pulse','active',('combat','perception','quest'), 'Projects a short controlled {a} pulse; outcome still depends on the scene and check.'),
 ('Read','passive',('dialogue','npc_reaction','quest'), 'Reads visible {a} cues without granting hidden knowledge or mind reading.'),
 ('Shift','active',('exploration','quest','combat'), 'Changes {a} conditions briefly to open a different approach.'),
 ('Trace','active',('perception','quest'), 'Follows a recent {a} trace from evidence actually present.'),
 ('Anchor','reaction',('dialogue','combat','survival'), 'Keeps the user stable against disruption related to {a}.'),
 ('Field','active',('combat','exploration','quest'), 'Shapes a small local {a} field with explicit limits and consequences.'),
 ('Counter','reaction',('combat','dialogue','quest'), 'Counters one incoming {a}-related pressure without canceling all consequences.'),
 ('Link','active',('dialogue','npc_reaction','quest'), 'Establishes a controlled {a} link; the NPC retains agency and knowledge limits.'),
 ('Map','active',('perception','exploration','quest'), 'Builds a coarse {a} map from observable signals.'),
 ('Break','active',('combat','quest'), 'Uses {a} to disrupt an obstacle or hostile action, subject to normal checks.'),
 ('Mask','active',('stealth','dialogue','quest'), 'Reduces a specific {a} signature instead of creating perfect invisibility.'),
 ('Surge','active',('combat','survival','quest'), 'Produces a stronger {a} effect at increased fatigue or exposure.'),
 ('Control','active',('combat','quest','exploration'), 'Applies fine control over {a} within the ability’s local scope.'),
 ('Empathy','passive',('dialogue','npc_reaction'), 'Improves interpretation of {a} cues but never forces agreement.'),
 ('Override','active',('quest','combat','tech'), 'Attempts a risky {a} override; security and resistance still apply.'),
 ('Storm','active',('combat','quest'), 'Creates a chaotic localized {a} storm as an advanced area-control option.'),
 ('Mastery','passive',('dialogue','quest','combat','perception'), 'Integrates {a} with trained judgment across several contexts.'),
)

def _generated_pool(owner: str, tier: int, theme: Tuple[str,...], pool_id: str) -> List[ClassAbility]:
    out=[]
    for idx,(suffix,kind,contexts,text) in enumerate(_PATTERNS):
        a=theme[idx%len(theme)]
        aid=f"{pool_id.lower()}_{idx+1:02d}"
        name=(a.title()+" "+suffix).replace('  ',' ')
        bonus=2 if idx in {8,14,18,19} and tier>=30 else 1
        out.append(ClassAbility(aid,name,owner,tier,pool_id,kind,tuple(contexts),text.format(a=a),bonus))
    return out

ABILITIES: Dict[str, ClassAbility] = {}
POOLS: Dict[str, Tuple[str,...]] = {}

_ROOT_PROFILE = {
    "BREAKER": ("SKILL_ATHLETICS","SKILL_FORCE_APPLICATION","SKILL_LOAD_CONTROL","SKILL_AIM_CONTROL","SKILL_SELF_CONTROL","SKILL_RESONANCE_CONTROL","SKILL_BANISHING"),
    "GHOST": ("SKILL_BALANCE","SKILL_ACROBATICS","SKILL_STEALTH","SKILL_AIM_CONTROL","SKILL_ATTENTION","SKILL_OBSERVATION","SKILL_ORIENTATION","SKILL_RESONANCE_CONCEALMENT","SKILL_ASTRAL_NAVIGATION"),
    "OPERATOR": ("SKILL_FINE_MECHANICS","SKILL_TECHNOLOGY","SKILL_ELECTRONICS","SKILL_NETWORKS","SKILL_DIAGNOSTICS","SKILL_MEDICINE","SKILL_ATTENTION","SKILL_COMMUNICATION","SKILL_OCCULT_KNOWLEDGE","SKILL_RITUAL_TECHNIQUE"),
    "RESONANT": ("SKILL_ATTENTION","SKILL_PEOPLE_READING","SKILL_SELF_CONTROL","SKILL_RESONANCE_SENSE","SKILL_RESONANCE_CONTROL","SKILL_RESONANCE_PROJECTION","SKILL_OCCULT_KNOWLEDGE","SKILL_ASTRAL_NAVIGATION","SKILL_ENTITY_CONTACT","SKILL_ECHO_ANALYSIS","SKILL_DIVINATION"),
}

_SPECIALIZATION_ROOT = {
    "RAVAGER":"BREAKER","BULWARK":"BREAKER","BREACHER":"BREAKER","HUNTER":"BREAKER",
    "SHADE":"GHOST","DEADEYE":"GHOST","RUNNER":"GHOST","STALKER":"GHOST",
    "GEARSMITH":"OPERATOR","NETSPIDER":"OPERATOR","FIELD_MEDIC":"OPERATOR","CONTROLLER":"OPERATOR",
    "MENDER":"RESONANT","SEER":"RESONANT","FLUX":"RESONANT","VOIDCALLER":"RESONANT",
}

_KEYWORD_SKILLS = {
    "impact":("SKILL_FORCE_APPLICATION","SKILL_AIM_CONTROL"),
    "force":("SKILL_FORCE_APPLICATION","SKILL_LOAD_CONTROL"),
    "breach":("SKILL_FORCE_APPLICATION","SKILL_DIAGNOSTICS"),
    "guard":("SKILL_LOAD_CONTROL","SKILL_SELF_CONTROL"),
    "protection":("SKILL_SELF_CONTROL","SKILL_RESONANCE_CONTROL"),
    "armor":("SKILL_LOAD_CONTROL","SKILL_RESONANCE_CONTROL"),
    "stealth":("SKILL_STEALTH","SKILL_ATTENTION"),
    "shadow":("SKILL_STEALTH","SKILL_RESONANCE_CONCEALMENT"),
    "silence":("SKILL_STEALTH","SKILL_RESONANCE_CONCEALMENT"),
    "absence":("SKILL_RESONANCE_CONCEALMENT","SKILL_STEALTH"),
    "precision":("SKILL_AIM_CONTROL","SKILL_ATTENTION"),
    "range":("SKILL_AIM_CONTROL","SKILL_OBSERVATION"),
    "weakpoint":("SKILL_OBSERVATION","SKILL_AIM_CONTROL"),
    "motion":("SKILL_ACROBATICS","SKILL_BALANCE"),
    "mobility":("SKILL_ATHLETICS","SKILL_ACROBATICS"),
    "route":("SKILL_ORIENTATION","SKILL_OBSERVATION"),
    "vault":("SKILL_ACROBATICS","SKILL_ATHLETICS"),
    "escape":("SKILL_ORIENTATION","SKILL_ATHLETICS"),
    "trail":("SKILL_OBSERVATION","SKILL_ORIENTATION"),
    "hunt":("SKILL_OBSERVATION","SKILL_AIM_CONTROL"),
    "pursuit":("SKILL_OBSERVATION","SKILL_ORIENTATION"),
    "trace":("SKILL_OBSERVATION","SKILL_DIAGNOSTICS"),
    "repair":("SKILL_TECHNOLOGY","SKILL_FINE_MECHANICS"),
    "fabrication":("SKILL_TECHNOLOGY","SKILL_FINE_MECHANICS"),
    "tool":("SKILL_FINE_MECHANICS","SKILL_TECHNOLOGY"),
    "mechanism":("SKILL_TECHNOLOGY","SKILL_DIAGNOSTICS"),
    "machine":("SKILL_TECHNOLOGY","SKILL_DIAGNOSTICS"),
    "system":("SKILL_DIAGNOSTICS","SKILL_TECHNOLOGY"),
    "servo":("SKILL_ELECTRONICS","SKILL_TECHNOLOGY"),
    "network":("SKILL_NETWORKS","SKILL_ELECTRONICS"),
    "signal":("SKILL_NETWORKS","SKILL_ATTENTION"),
    "access":("SKILL_NETWORKS","SKILL_ATTENTION"),
    "intrusion":("SKILL_NETWORKS","SKILL_ELECTRONICS"),
    "trauma":("SKILL_MEDICINE","SKILL_DIAGNOSTICS"),
    "stabilize":("SKILL_MEDICINE","SKILL_SELF_CONTROL"),
    "healing":("SKILL_MEDICINE","SKILL_RESONANCE_CONTROL"),
    "medical":("SKILL_MEDICINE","SKILL_DIAGNOSTICS"),
    "biofield":("SKILL_MEDICINE","SKILL_RESONANCE_SENSE"),
    "drone":("SKILL_NETWORKS","SKILL_ELECTRONICS"),
    "sensor":("SKILL_ELECTRONICS","SKILL_ATTENTION"),
    "resonance":("SKILL_RESONANCE_SENSE","SKILL_RESONANCE_CONTROL"),
    "harmonic":("SKILL_RESONANCE_CONTROL","SKILL_RESONANCE_PROJECTION"),
    "field":("SKILL_RESONANCE_SENSE","SKILL_RESONANCE_CONTROL"),
    "echo":("SKILL_ECHO_ANALYSIS","SKILL_RESONANCE_SENSE"),
    "premonition":("SKILL_DIVINATION","SKILL_ATTENTION"),
    "oracle":("SKILL_DIVINATION","SKILL_ECHO_ANALYSIS"),
    "prediction":("SKILL_DIVINATION","SKILL_ATTENTION"),
    "magnetic":("SKILL_RESONANCE_PROJECTION","SKILL_ELECTRONICS"),
    "electric":("SKILL_RESONANCE_PROJECTION","SKILL_ELECTRONICS"),
    "frequency":("SKILL_RESONANCE_PROJECTION","SKILL_RESONANCE_CONTROL"),
    "null":("SKILL_BANISHING","SKILL_RESONANCE_CONCEALMENT"),
    "damping":("SKILL_BANISHING","SKILL_RESONANCE_CONTROL"),
    "social":("SKILL_PEOPLE_READING","SKILL_COMMUNICATION"),
    "command":("SKILL_COMMUNICATION","SKILL_ATTENTION"),
    "survival":("SKILL_LOAD_CONTROL","SKILL_ORIENTATION"),
}

def _root_class(owner: str) -> str:
    owner=str(owner).upper()
    if owner in _ROOT_PROFILE: return owner
    if owner in _SPECIALIZATION_ROOT: return _SPECIALIZATION_ROOT[owner]
    if "_TO_" in owner:
        head=owner.split("_TO_",1)[0]
        if head in _ROOT_PROFILE: return head
    # End paths are intentionally cross-class; derive them from semantics below.
    return ""

def _capability_bind(d: ClassAbility) -> ClassAbility:
    text=(d.name+" "+d.description+" "+d.pool_id).lower()
    picked=[]
    for token, skills in _KEYWORD_SKILLS.items():
        if token in text:
            for skill in skills:
                if skill in SKILLS and skill not in picked: picked.append(skill)
    root=_root_class(d.owner)
    if root:
        profile=_ROOT_PROFILE[root]
        # Rotate fallback skills by ability id so the whole character tree feeds the
        # class tree instead of always selecting the first four profile entries.
        offset=sum(ord(ch) for ch in d.ability_id) % len(profile)
        rotated=profile[offset:]+profile[:offset]
        for skill in rotated:
            if skill not in picked: picked.append(skill)
            if len(picked) >= 4: break
    # Keep each ability focused while preserving broad tree coverage across a pool.
    picked=picked[:4]
    if not picked:
        picked=["SKILL_ATTENTION"]
    stats=[]
    for skill_id in picked:
        for stat_id in SKILLS[skill_id].stats:
            if stat_id not in stats: stats.append(stat_id)
    talent_roots=[]
    for talent in TALENTS.values():
        if root and talent.owner_class != root: continue
        if any(skill in picked for skill in talent.required_skills):
            talent_roots.append(talent.talent_id)
    return ClassAbility(d.ability_id,d.name,d.owner,d.tier,d.pool_id,d.kind,d.contexts,d.description,
                        d.check_bonus,d.npc_policy,tuple(stats[:5]),tuple(picked),tuple(talent_roots[:4]))

def _register(pool_id: str, defs: Iterable[ClassAbility]):
    ids=[]
    for d in defs:
        if d.ability_id in ABILITIES: raise RuntimeError('duplicate ability:'+d.ability_id)
        d=_capability_bind(d)
        ABILITIES[d.ability_id]=d; ids.append(d.ability_id)
    POOLS[pool_id]=tuple(ids)

for cls, rows in _BASE.items():
    defs=[]
    kinds=('passive','active','active','reaction','passive','active','dialogue','reaction','passive','perception',
           'reaction','active','perception','perception','dialogue','active','active','active','dialogue','active')
    contexts=(('perception','quest'),('perception','quest'),('perception','quest'),('survival','combat'),('perception','quest'),
              ('perception','quest'),('combat','dialogue','npc_reaction'),('combat','quest'),('combat','exploration'),('perception','quest'),
              ('survival','combat'),('quest','exploration'),('combat','perception'),('perception','quest'),('dialogue','npc_reaction'),
              ('combat','quest'),('combat','perception'),('survival','quest'),('dialogue','npc_reaction'),('combat','quest'))
    for i,(name,desc) in enumerate(rows):
        defs.append(ClassAbility(f'{cls.lower()}_base_{i+1:02d}',name,cls,1,f'{cls}:BASE',kinds[i],tuple(contexts[i]),desc,1))
    _register(f'{cls}:BASE',defs)

for spec,theme in _SPEC_THEME.items():
    _register(f'{spec}:T10',_generated_pool(spec,10,theme,f'{spec}:T10'))
    _register(f'{spec}:T20',_generated_pool(spec,20,tuple(reversed(theme)),f'{spec}:T20'))
for path,theme in _MASTERY_THEME.items():
    _register(f'{path}:T30',_generated_pool(path,30,theme,f'{path}:T30'))
    _register(f'{path}:T40',_generated_pool(path,40,tuple(reversed(theme)),f'{path}:T40'))
for path,theme in _END_THEME.items():
    _register(f'{path}:T50',_generated_pool(path,50,theme,f'{path}:T50'))


def visible_pool_ids(start_class: str, level: int, specialization: str|None=None,
                     mastery_path: str|None=None, end_path: str|None=None) -> Tuple[str,...]:
    cls=str(start_class or '').upper(); level=max(1,int(level or 1)); out=[]
    base=f'{cls}:BASE'
    if base in POOLS: out.append(base)
    if specialization:
        spec=str(specialization).upper()
        if level>=10 and f'{spec}:T10' in POOLS: out.append(f'{spec}:T10')
        if level>=20 and f'{spec}:T20' in POOLS: out.append(f'{spec}:T20')
    if mastery_path:
        mp=str(mastery_path).upper()
        if level>=30 and f'{mp}:T30' in POOLS: out.append(f'{mp}:T30')
        if level>=40 and f'{mp}:T40' in POOLS: out.append(f'{mp}:T40')
    if end_path and level>=50:
        ep=str(end_path).upper()
        if f'{ep}:T50' in POOLS: out.append(f'{ep}:T50')
    return tuple(out)


def visible_abilities(start_class: str, level: int, specialization: str|None=None,
                      mastery_path: str|None=None, end_path: str|None=None) -> List[ClassAbility]:
    return [ABILITIES[aid] for pool in visible_pool_ids(start_class,level,specialization,mastery_path,end_path) for aid in POOLS[pool]]


def ability_payload(d: ClassAbility) -> dict:
    return {'id':d.ability_id,'name':d.name,'owner':d.owner,'tier':d.tier,'pool_id':d.pool_id,
            'kind':d.kind,'contexts':list(d.contexts),'description':d.description,'check_bonus':d.check_bonus,
            'npc_policy':d.npc_policy,'required_stats':list(d.required_stats),
            'required_skills':list(d.required_skills),'talent_roots':list(d.talent_roots)}


def context_abilities(owned: Iterable[str], context: str) -> List[ClassAbility]:
    c=str(context).lower()
    return [ABILITIES[x] for x in owned if x in ABILITIES and c in ABILITIES[x].contexts]


def bounded_context_bonus(owned: Iterable[str], context: str) -> int:
    # Multiple abilities create options, not runaway stacking. Highest applicable bonus only.
    vals=[d.check_bonus for d in context_abilities(owned,context)]
    return max(vals, default=0)
