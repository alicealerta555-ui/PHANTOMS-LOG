from .model import PlayerProgressionState, START_CLASSES, AFFINITIES
from .engine import BehaviorEvent, HiddenAffinityEngine
from .behavior import RawActionEvent, BehaviorTrackerState, BehaviorTracker
from .insights import InsightDefinition, InsightResolver, INSIGHTS
from .pipeline import PlayerLearningRuntime
from .habits import (DecisionEvent, HabitDefinition, HabitRecord, HabitRuntimeState, HabitEngine,
                     HabitAutomation, HabitTransition, HABITS, HABIT_BY_ID)
from .identity import HabitIdentityBridge, IdentitySignal, HABIT_AFFINITY_HINTS
from .predictive import PredictiveRoutineEngine, PredictiveRoutineState, RoutineContext, PredictedRoutine
from .paths import (PathResolver, SpecializationDefinition, MasteryDefinition, EndPathDefinition,
                    SPECIALIZATIONS, MASTERY, END_PATHS)

__all__ = [
    "PlayerProgressionState", "START_CLASSES", "AFFINITIES",
    "BehaviorEvent", "HiddenAffinityEngine",
    "RawActionEvent", "BehaviorTrackerState", "BehaviorTracker",
    "InsightDefinition", "InsightResolver", "INSIGHTS",
    "PlayerLearningRuntime",
    "DecisionEvent", "HabitDefinition", "HabitRecord", "HabitRuntimeState", "HabitEngine",
    "HabitAutomation", "HabitTransition", "HABITS", "HABIT_BY_ID",
    "HabitIdentityBridge", "IdentitySignal", "HABIT_AFFINITY_HINTS",
    "PredictiveRoutineEngine", "PredictiveRoutineState", "RoutineContext", "PredictedRoutine",
    "PathResolver", "SpecializationDefinition", "MasteryDefinition", "EndPathDefinition",
    "SPECIALIZATIONS", "MASTERY", "END_PATHS",
    "DevelopmentPresenter", "PlayerMessage", "assert_player_payload_clean",
]

from .presentation import DevelopmentPresenter, PlayerMessage, assert_player_payload_clean
from .livehooks import PlayerDevelopmentCoordinator, LiveContext, LiveHookResult
__all__ += ["PlayerDevelopmentCoordinator", "LiveContext", "LiveHookResult"]

from .gameplay_hooks import GameplayLearningBridge, ResolvedGameplayEvent

from .npc_learning import (
    NPCActorSnapshot, NPCWitnessContext, NPCPatternRecord, NPCObservationState,
    NPCReaction, NPCObservationEngine, NPCObservationalLearningBridge,
)
__all__ += [
    "NPCActorSnapshot", "NPCWitnessContext", "NPCPatternRecord", "NPCObservationState",
    "NPCReaction", "NPCObservationEngine", "NPCObservationalLearningBridge",
]
from .adaptive_runtime import AdaptiveGameplayRuntime, AdaptiveResolutionResult
__all__ += ["AdaptiveGameplayRuntime", "AdaptiveResolutionResult"]
from .npc_naming import (
    NamingProfile, NameRequest, GeneratedNPCName, NPCNameRegistry,
    NPCNameGenerator, PROFILES as NPC_NAMING_PROFILES,
)
__all__ += [
    "NamingProfile", "NameRequest", "GeneratedNPCName", "NPCNameRegistry",
    "NPCNameGenerator", "NPC_NAMING_PROFILES",
]

from .npc_encounter import (
    NPCVisualSnapshot, NPCEncounterContext, NPCPresentationProfile,
    NPCPlayerKnowledge, NPCEncounterRegistry, NPCFirstContactResult,
    NPCFirstContactEngine,
)

# Etappe 15 social knowledge
from .npc_social import NPCSocialKnowledgeEngine, NPCSocialRegistry, NPCSocialKnowledge, SocialSource, SocialClaim, SocialUpdateResult

from .npc_lifelike import (NPCLivedExperienceEngine, NPCLifeSnapshot, SocialMomentContext, ConversationTopic, LifelikeSocialResult, SocialAction)
__all__ += ["NPCLivedExperienceEngine", "NPCLifeSnapshot", "SocialMomentContext", "ConversationTopic", "LifelikeSocialResult", "SocialAction"]
from .npc_psychology import PsychologicalSnapshot, SupportContext, RecoveryTheme, NPCPsychologyState, SupportResult, NPCPsychologyEngine
__all__ += ["PsychologicalSnapshot","SupportContext","RecoveryTheme","NPCPsychologyState","SupportResult","NPCPsychologyEngine"]
from .npc_memory import MemoryEvent, MemoryRecord, NPCMemoryState, NPCMemoryBudgetEngine
__all__ += ["MemoryEvent","MemoryRecord","NPCMemoryState","NPCMemoryBudgetEngine"]
from .npc_social_life import NPCSocialActor, RelationshipEdge, NPCSocialWorldState, SocialLifeContext, NPCToNPCResult, NPCSocialLifeEngine
__all__ += ["NPCSocialActor","RelationshipEdge","NPCSocialWorldState","SocialLifeContext","NPCToNPCResult","NPCSocialLifeEngine"]
