from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Optional, Sequence

from .behavior import RawActionEvent
from .habits import DecisionEvent
from .pipeline import PlayerLearningRuntime


@dataclass(frozen=True)
class LiveContext:
    """Coarse host-facing context for one playable moment.

    Only visible/known state belongs here. Hidden world facts are forbidden.
    """
    situation_family: str
    context_tags: tuple[str, ...] = ()
    reversible: bool = True
    high_stakes: bool = False
    explicit_player_order: bool = False


@dataclass
class LiveHookResult:
    """Single normalized result bundle returned to the host runtime."""
    applied_action_learning: bool = False
    insight_messages: list[dict] = field(default_factory=list)
    habit_messages: list[dict] = field(default_factory=list)
    predicted_routine: Optional[dict] = None
    identity_note: Optional[dict] = None


class PlayerDevelopmentCoordinator:
    """One integration surface for all adaptive player-development systems.

    The host runtime should prefer this class over calling individual engines.
    This keeps action learning, habits, prediction, presentation and path identity
    in a deterministic order and preserves player authority.
    """

    def __init__(self, runtime: PlayerLearningRuntime):
        self.runtime = runtime

    def on_action(self, event: RawActionEvent) -> LiveHookResult:
        applied = self.runtime.observe(event)
        return LiveHookResult(
            applied_action_learning=applied,
            insight_messages=self.runtime.drain_unlocks(),
            habit_messages=self.runtime.drain_habit_messages(),
        )

    def on_decision(self, event: DecisionEvent) -> LiveHookResult:
        messages = self.runtime.observe_decision(event)
        return LiveHookResult(
            habit_messages=list(messages),
            insight_messages=self.runtime.drain_unlocks(),
            identity_note=self.runtime.visible_identity_note(),
        )

    def before_player_prompt(self, context: LiveContext) -> LiveHookResult:
        """Offer only safe, learned micro-routines before a new player decision.

        Explicit player orders, high-stakes moments and irreversible situations are
        always authoritative vetoes. If no safe prediction exists, returns None.
        """
        prediction = self.runtime.predict_routine(
            context.situation_family,
            context.context_tags,
            reversible=context.reversible,
            player_has_explicit_order=context.explicit_player_order,
            high_stakes=context.high_stakes,
        )
        return LiveHookResult(
            predicted_routine=prediction,
            identity_note=self.runtime.visible_identity_note(),
        )

    def on_prediction_accepted(self) -> None:
        self.runtime.confirm_predicted_routine()

    def on_prediction_overridden(self, habit_id: str | None = None) -> None:
        self.runtime.override_predicted_routine(habit_id)

    def request_retraining(self, habit_id: str, replacement_choice: str | None = None) -> dict | None:
        return self.runtime.request_habit_retraining(habit_id, replacement_choice)

    def snapshot_for_save(self) -> dict:
        return self.runtime.to_dict()

    @classmethod
    def from_save(cls, payload: dict) -> "PlayerDevelopmentCoordinator":
        return cls(PlayerLearningRuntime.from_dict(payload))
