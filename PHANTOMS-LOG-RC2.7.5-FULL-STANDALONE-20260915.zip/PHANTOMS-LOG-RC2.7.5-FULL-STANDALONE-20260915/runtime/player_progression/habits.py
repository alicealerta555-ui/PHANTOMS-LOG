from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field
from typing import Deque, Dict, Iterable, Mapping, Optional, Sequence, Tuple


SAFE_AUTOMATION_CATEGORIES = {
    "micro_routine", "preparation", "perception", "positioning", "maintenance", "triage_scan"
}
FORBIDDEN_AUTOMATION_CATEGORIES = {
    "moral", "dialogue_commitment", "kill", "betrayal", "faction", "irreversible",
    "major_resource", "story_choice", "crew_sacrifice"
}


@dataclass(frozen=True)
class DecisionEvent:
    """A meaningful player decision in a recurring situation.

    choice_key is an internal canonical action, e.g. ``use_cover`` or ``check_bleeding``.
    situation_family groups comparable contexts, e.g. ``room_entry`` or ``injured_ally``.
    Only player decisions are learnable. The host may emit irreversible decisions for
    personality evidence, but those can never become automatic routines.
    """

    situation_family: str
    choice_key: str
    category: str = "micro_routine"
    context_tags: Tuple[str, ...] = field(default_factory=tuple)
    outcome: str = "success"
    consequence_hint: float = 1.0
    risk_hint: float = 1.0
    reversible: bool = True
    actor_is_player: bool = True


@dataclass(frozen=True)
class HabitDefinition:
    habit_id: str
    name: str
    situation_family: str
    choice_key: str
    tone: str  # helpful | neutral | double_edged
    player_description: str
    instinct_name: str
    instinct_description: str
    automation_category: str = "micro_routine"
    safe_to_automate: bool = True
    mild_drawback: Optional[str] = None
    required_tags: Tuple[str, ...] = ()


@dataclass
class HabitRecord:
    habit_id: str
    stage: str = "forming"  # forming | habit | instinct | fading
    strength: float = 0.0
    contrary_evidence: float = 0.0
    autonomy_enabled: bool = True  # legacy save compatibility; no player-facing kill switch
    retraining_requested: bool = False
    retraining_choice: Optional[str] = None
    times_automated: int = 0
    times_overridden: int = 0

    def to_dict(self) -> dict:
        return {
            "habit_id": self.habit_id,
            "stage": self.stage,
            "strength": self.strength,
            "contrary_evidence": self.contrary_evidence,
            "autonomy_enabled": self.autonomy_enabled,
            "retraining_requested": self.retraining_requested,
            "retraining_choice": self.retraining_choice,
            "times_automated": self.times_automated,
            "times_overridden": self.times_overridden,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, object]) -> "HabitRecord":
        return cls(
            habit_id=str(data.get("habit_id") or ""),
            stage=str(data.get("stage") or "forming"),
            strength=max(0.0, float(data.get("strength", 0.0) or 0.0)),
            contrary_evidence=max(0.0, float(data.get("contrary_evidence", 0.0) or 0.0)),
            autonomy_enabled=True,  # old disabled flags are intentionally not honored anymore
            retraining_requested=bool(data.get("retraining_requested", False)),
            retraining_choice=(str(data.get("retraining_choice")) if data.get("retraining_choice") else None),
            times_automated=max(0, int(data.get("times_automated", 0) or 0)),
            times_overridden=max(0, int(data.get("times_overridden", 0) or 0)),
        )


@dataclass
class HabitRuntimeState:
    decision_counts: Counter = field(default_factory=Counter)
    situation_counts: Counter = field(default_factory=Counter)
    context_counts: Counter = field(default_factory=Counter)
    recent_choices: Deque[str] = field(default_factory=lambda: deque(maxlen=64))
    habits: Dict[str, HabitRecord] = field(default_factory=dict)
    ignored_non_player: int = 0

    def to_dict(self) -> dict:
        return {
            "decision_counts": dict(self.decision_counts),
            "situation_counts": dict(self.situation_counts),
            "context_counts": dict(self.context_counts),
            "recent_choices": list(self.recent_choices),
            "habits": {k: v.to_dict() for k, v in self.habits.items()},
            "ignored_non_player": self.ignored_non_player,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, object] | None) -> "HabitRuntimeState":
        data = data or {}
        s = cls()
        s.decision_counts.update(data.get("decision_counts", {}) or {})
        s.situation_counts.update(data.get("situation_counts", {}) or {})
        s.context_counts.update(data.get("context_counts", {}) or {})
        s.recent_choices.extend(data.get("recent_choices", []) or [])
        raw_habits = data.get("habits", {}) or {}
        for k, v in dict(raw_habits).items():
            rec = HabitRecord.from_dict(v or {})
            if rec.habit_id:
                s.habits[str(k)] = rec
        s.ignored_non_player = max(0, int(data.get("ignored_non_player", 0) or 0))
        return s


@dataclass(frozen=True)
class HabitTransition:
    habit_id: str
    transition: str  # formed | instinct | fading | broken | adapted


@dataclass(frozen=True)
class HabitAutomation:
    habit_id: str
    choice_key: str
    category: str
    narrative_hint: str


HABITS: Tuple[HabitDefinition, ...] = (
    HabitDefinition("cover_entry", "Deckung zuerst", "room_entry", "use_cover", "helpful",
                    "Beim Betreten unbekannter Räume suchst du fast automatisch eine sichere Linie.",
                    "Deckungsreflex", "Dein Körper nimmt beim Eintritt wie selbstverständlich eine geschützte Position ein.", "positioning"),
    HabitDefinition("motion_check", "Bewegung zuerst", "room_entry", "scan_motion", "helpful",
                    "Dein Blick sucht beim Betreten eines Ortes zuerst nach Bewegung.",
                    "Bewegungsreflex", "Bewegungen springen dir ins Auge, noch bevor du bewusst danach suchst.", "perception"),
    HabitDefinition("quiet_entry", "Leiser Eintritt", "room_entry", "enter_quietly", "helpful",
                    "Du vermeidest beim Eintreten unnötige Geräusche, ohne darüber nachdenken zu müssen.",
                    "Stiller Eintritt", "Leises Öffnen und Eintreten ist Teil deines Bewegungsrhythmus geworden."),
    HabitDefinition("exit_memory", "Fluchtweg merken", "room_entry", "mark_exit", "helpful",
                    "Du merkst dir beim Eintritt unbewusst, wie du wieder hinauskommst.",
                    "Rückweginstinkt", "Ein möglicher Rückweg bleibt in deinem Kopf präsent, ohne Aufmerksamkeit zu binden.", "perception"),
    HabitDefinition("field_check", "Ausrüstungscheck", "travel_departure", "check_gear", "helpful",
                    "Vor dem Aufbruch gehst du deine wichtigsten Dinge inzwischen beiläufig durch.",
                    "Feldroutine", "Waffe, Energie, Werkzeug und Funk werden vor dem Aufbruch automatisch geprüft.", "preparation"),
    HabitDefinition("ammo_check", "Magazin-Gefühl", "combat_pause", "check_ammo", "helpful",
                    "Du prüfst Munition in ruhigen Sekunden fast nebenbei.",
                    "Munitionsreflex", "Du hast ein gutes Gefühl dafür, wann eine Waffe Aufmerksamkeit braucht.", "preparation"),
    HabitDefinition("reload_cover", "Nachladen in Deckung", "combat_pause", "reload_in_cover", "helpful",
                    "Wenn du nachlädst, suchst du dabei automatisch Schutz.",
                    "Geschütztes Nachladen", "Nachladen und Positionieren laufen bei dir inzwischen als ein Ablauf.", "positioning"),
    HabitDefinition("wounded_scan", "Erster Blick auf Blutung", "injured_ally", "check_bleeding", "helpful",
                    "Bei Verwundeten fällt dein Blick zuerst auf akute Blutungen.",
                    "Triage-Reflex", "Du erkennst sehr schnell, was bei einem Verwundeten zuerst Aufmerksamkeit braucht.", "triage_scan"),
    HabitDefinition("drone_first", "Drohne voraus", "unknown_corridor", "send_drone", "helpful",
                    "Unübersichtliche Wege prüfst du bevorzugt aus der Distanz.",
                    "Vorausauge", "Wenn eine Drohne verfügbar ist, nutzt du sie bei unklaren Wegen beinahe selbstverständlich.", "preparation"),
    HabitDefinition("salvage_scan", "Brauchbares sehen", "machine_aftermath", "scan_salvage", "helpful",
                    "Nach technischen Zwischenfällen erkennst du schneller, was noch brauchbar sein könnte.",
                    "Bergungsblick", "Verwertbare Teile fallen dir auf, ohne dass du jedes Wrack vollständig zerlegen musst.", "perception"),
    HabitDefinition("lock_after_rest", "Eingang sichern", "make_camp", "secure_entry", "helpful",
                    "Beim Einrichten eines Ruheplatzes kümmerst du dich zuerst um den Zugang.",
                    "Schlafsicherung", "Bevor du zur Ruhe kommst, ist der wichtigste Zugang gewöhnlich bereits gesichert.", "preparation"),
    HabitDefinition("light_discipline", "Lichtdisziplin", "stealth_travel", "reduce_light", "helpful",
                    "In unsicheren Gebieten gehst du sparsam mit sichtbarem Licht um.",
                    "Dunkelroutine", "Lichtquellen werden von dir automatisch so genutzt, dass sie dich möglichst wenig verraten."),
    HabitDefinition("overcautious_entry", "Übervorsicht", "room_entry", "extended_check", "double_edged",
                    "Du sicherst unbekannte Räume gründlicher ab als die meisten.",
                    "Sicherheitsritual", "Deine Absicherung läuft fast automatisch ab, kostet aber manchmal einen Moment mehr.", "perception", True,
                    "Unter starkem Zeitdruck kann die zusätzliche Absicherung etwas Tempo kosten."),
    HabitDefinition("tunnel_target", "Tunnelblick", "combat_targeting", "focus_single_target", "double_edged",
                    "Wenn du dich auf ein Ziel festlegst, blendest du Nebensachen leichter aus.",
                    "Jägerfokus", "Ein gewähltes Ziel bindet deine Aufmerksamkeit sehr stark.", "micro_routine", True,
                    "Seitliche Veränderungen können dir etwas später auffallen, solange du ein Ziel hart fokussierst."),
    HabitDefinition("ammo_hungry", "Sicherheitsfeuer", "combat_pressure", "fire_extra", "double_edged",
                    "Unter Druck gibst du lieber einen Schuss mehr ab als einen zu wenig.",
                    "Feuerreflex", "Deine Reaktion unter Druck ist schnell und entschlossen, verbraucht aber gelegentlich mehr Munition.", "micro_routine", True,
                    "Du verbrauchst in hektischen Situationen gelegentlich etwas mehr Munition."),
    HabitDefinition("loot_compulsion", "Gründlicher Bergungsdrang", "post_encounter", "search_thoroughly", "double_edged",
                    "Du verlässt einen Ort ungern, bevor du nicht nach Brauchbarem gesehen hast.",
                    "Bergungsinstinkt", "Verwertbares entgeht dir selten, dafür bleibst du manchmal etwas länger am Ort.", "perception", True,
                    "Gründlichkeit kann Zeit kosten, wenn Eile wichtiger wäre."),
    HabitDefinition("pain_ignore", "Schmerz wegdrücken", "injured_self", "continue_action", "double_edged",
                    "Du hast dir angewöhnt, Schmerzen im entscheidenden Moment auszublenden.",
                    "Schmerzfilter", "Unter Druck bleibst du handlungsfähig, bemerkst die Folgen aber manchmal erst später.", "micro_routine", True,
                    "Verletzungen können subjektiv weniger dringlich wirken, bis der unmittelbare Druck vorbei ist."),
    HabitDefinition("do_it_self", "Selbst erledigen", "crew_task", "take_over", "double_edged",
                    "Wenn etwas wichtig ist, greifst du lieber selbst ein.",
                    "Eigenhandreflex", "Du übernimmst kritische Handgriffe sehr schnell selbst.", "micro_routine", True,
                    "Crewmitglieder bekommen bei solchen Aufgaben etwas seltener Gelegenheit, selbst Initiative zu zeigen."),
    HabitDefinition("early_exit", "Früher Rückzug", "combat_deteriorating", "prepare_retreat", "double_edged",
                    "Du wartest selten bis zum letzten Augenblick, bevor du einen Rückweg suchst.",
                    "Rückzugsinstinkt", "Wenn eine Lage kippt, hast du sehr schnell einen Rückzug im Kopf.", "positioning", True,
                    "Manchmal bereitest du den Rückzug schon vor, obwohl eine Lage noch zu retten wäre."),
    HabitDefinition("risk_appetite", "Risikohunger", "opportunity", "take_risk", "double_edged",
                    "Ungewöhnliche Chancen reizen dich stärker als sichere Lösungen.",
                    "Chancenreflex", "Du erkennst und ergreifst riskante Gelegenheiten sehr schnell.", "micro_routine", False,
                    "Die Gewohnheit darf niemals automatisch eine riskante oder irreversible Entscheidung treffen."),
    HabitDefinition("distrustful_check", "Misstrauische Prüfung", "new_contact", "verify_claim", "double_edged",
                    "Neue Aussagen akzeptierst du selten ungeprüft.",
                    "Prüfreflex", "Widersprüche und Lücken in Aussagen fallen dir schnell auf.", "perception", True,
                    "Vertrauen baut sich langsamer auf, wenn du jede neue Aussage zunächst prüfst."),
    HabitDefinition("deescalate_first", "Erst reden", "social_conflict", "deescalate", "helpful",
                    "In angespannten Situationen suchst du zuerst nach einem Ausweg ohne Eskalation.",
                    "Deeskalationsreflex", "Noch bevor die Lage kippt, suchst du nach Worten, Haltung oder Abstand, die Druck herausnehmen.", "micro_routine", False),
    HabitDefinition("command_spacing", "Crew verteilen", "combat_setup", "spread_crew", "helpful",
                    "Vor erwartbarem Ärger achtest du darauf, dass die Crew nicht auf einem Fleck steht.",
                    "Gefechtsordnung", "Die Crew bekommt von dir früh sinnvolle Positionen, bevor der erste Schuss fällt.", "positioning"),
    HabitDefinition("repair_before_replace", "Reparieren vor Ersetzen", "damaged_equipment", "repair_first", "neutral",
                    "Defekte Ausrüstung gibst du nicht vorschnell auf.",
                    "Werkstattinstinkt", "Bei Schäden suchst du automatisch zuerst nach einer brauchbaren Reparaturlösung.", "maintenance"),
)

HABIT_BY_ID = {h.habit_id: h for h in HABITS}
HABITS_BY_PATTERN: Dict[tuple[str, str], list[HabitDefinition]] = defaultdict(list)
for _h in HABITS:
    HABITS_BY_PATTERN[(_h.situation_family, _h.choice_key)].append(_h)


class HabitEngine:
    """Learns recurring player choices and turns them into mild habits/instincts.

    Hidden thresholds intentionally live here, never in presentation. Stable player
    preference matters more than raw counts, and explicit contrary choices weaken or
    replace habits over time. No major/irreversible decision can be automated.
    """

    HABIT_THRESHOLD = 5.8
    INSTINCT_THRESHOLD = 11.5
    MIN_STABILITY = 0.68

    @staticmethod
    def _context_key(event: DecisionEvent) -> str:
        return f"{event.situation_family}|{','.join(sorted(set(event.context_tags)))}"

    @staticmethod
    def _quality(event: DecisionEvent) -> float:
        outcome = {"success": 1.0, "partial": 0.72, "failure": 0.50, "abort": 0.15}.get(event.outcome, 0.5)
        consequence = max(0.2, min(1.6, float(event.consequence_hint)))
        risk = max(0.3, min(1.5, float(event.risk_hint)))
        # repeated decisions can teach even when outcomes vary, but meaningful contexts count more.
        return outcome * (0.55 + 0.25 * consequence + 0.20 * risk)

    def observe(self, state: HabitRuntimeState, event: DecisionEvent) -> list[HabitTransition]:
        if not event.actor_is_player:
            state.ignored_non_player += 1
            return []

        pattern = f"{event.situation_family}|{event.choice_key}"
        state.decision_counts[pattern] += 1
        state.situation_counts[event.situation_family] += 1
        state.context_counts[self._context_key(event)] += 1
        state.recent_choices.append(pattern)

        transitions: list[HabitTransition] = []
        matching = HABITS_BY_PATTERN.get((event.situation_family, event.choice_key), ())
        for definition in matching:
            if definition.required_tags and not set(definition.required_tags) <= set(event.context_tags):
                continue
            rec = state.habits.setdefault(definition.habit_id, HabitRecord(definition.habit_id))
            same = state.decision_counts[pattern]
            total = state.situation_counts[event.situation_family]
            stability = same / max(1, total)
            novelty = 1.0 / (1.0 + 0.06 * max(0, same - 1))
            rec.strength += self._quality(event) * novelty * (0.75 + 0.45 * stability)
            rec.contrary_evidence = max(0.0, rec.contrary_evidence - 0.25)

            old_stage = rec.stage
            if rec.strength >= self.INSTINCT_THRESHOLD and stability >= self.MIN_STABILITY:
                rec.stage = "instinct"
            elif rec.strength >= self.HABIT_THRESHOLD and stability >= self.MIN_STABILITY:
                rec.stage = "habit"
            elif rec.stage == "fading" and stability >= self.MIN_STABILITY:
                rec.stage = "habit"

            if rec.stage != old_stage:
                transition = "instinct" if rec.stage == "instinct" else "formed"
                transitions.append(HabitTransition(definition.habit_id, transition))

        # Contrary choices slowly weaken competing habits in the same situation.
        for definition in HABITS:
            if definition.situation_family != event.situation_family or definition.choice_key == event.choice_key:
                continue
            rec = state.habits.get(definition.habit_id)
            if not rec or rec.stage not in {"habit", "instinct", "fading"}:
                continue
            rec.contrary_evidence += self._quality(event)
            if rec.contrary_evidence >= 3.0:
                if rec.stage in {"habit", "instinct"}:
                    rec.stage = "fading"
                    transitions.append(HabitTransition(definition.habit_id, "fading"))
                rec.strength = max(0.0, rec.strength - 0.65 * rec.contrary_evidence)
            if rec.strength < self.HABIT_THRESHOLD * 0.55 and rec.contrary_evidence >= 6.0:
                rec.stage = "forming"
                rec.contrary_evidence = 0.0
                rec.retraining_requested = False
                rec.retraining_choice = None
                transitions.append(HabitTransition(definition.habit_id, "broken"))

        return transitions

    def automation_for(self, state: HabitRuntimeState, situation_family: str,
                       context_tags: Sequence[str] = ()) -> Optional[HabitAutomation]:
        candidates: list[tuple[float, HabitDefinition, HabitRecord]] = []
        for definition in HABITS:
            if definition.situation_family != situation_family:
                continue
            rec = state.habits.get(definition.habit_id)
            if not rec or rec.stage != "instinct":
                continue
            if not definition.safe_to_automate:
                continue
            if definition.automation_category not in SAFE_AUTOMATION_CATEGORIES:
                continue
            if definition.automation_category in FORBIDDEN_AUTOMATION_CATEGORIES:
                continue
            if definition.required_tags and not set(definition.required_tags) <= set(context_tags):
                continue
            candidates.append((rec.strength, definition, rec))
        if not candidates:
            return None
        _, definition, rec = max(candidates, key=lambda x: (x[0], x[1].habit_id))
        rec.times_automated += 1
        return HabitAutomation(
            habit_id=definition.habit_id,
            choice_key=definition.choice_key,
            category=definition.automation_category,
            narrative_hint=definition.instinct_description,
        )

    def override(self, state: HabitRuntimeState, habit_id: str) -> bool:
        """Override the instinct for one concrete situation.

        A single conscious override is evidence of resistance, not an off switch.
        Lasting change only comes from subsequently observed contrary decisions.
        """
        rec = state.habits.get(habit_id)
        if not rec:
            return False
        rec.times_overridden += 1
        rec.contrary_evidence += 0.12
        return True

    def request_retraining(self, state: HabitRuntimeState, habit_id: str, replacement_choice: Optional[str] = None) -> bool:
        """Mark that the player consciously wants to retrain a habit.

        This does not disable automation and does not reduce strength by itself.
        The character has to accumulate real contrary behavior in matching contexts.
        """
        rec = state.habits.get(habit_id)
        if not rec:
            return False
        rec.retraining_requested = True
        rec.retraining_choice = replacement_choice or None
        return True

    def active_records(self, state: HabitRuntimeState) -> Iterable[tuple[HabitDefinition, HabitRecord]]:
        for habit_id, rec in state.habits.items():
            if rec.stage in {"habit", "instinct", "fading"} and habit_id in HABIT_BY_ID:
                yield HABIT_BY_ID[habit_id], rec
