from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, Mapping, Optional, Sequence

from .gameplay_hooks import ResolvedGameplayEvent

# NOTE: This module does NOT define a second intelligence system.
# intelligence_grade must be supplied by the canonical Actor/NPC runtime.
# The values here are only consumed as an already-authoritative actor property.

HARD_REJECT_TAGS = {
    "self_destructive", "suicidal_routine", "catastrophic_waste",
    "obviously_nonsensical", "friendly_fire_pattern",
}
QUESTIONABLE_TAGS = {
    "absurd", "wasteful", "reckless", "obviously_unsafe", "counterproductive",
}

DOMAIN_COMPETENCE_KEYS = {
    "movement": "mobility",
    "combat": "combat",
    "interaction": "interaction",
    "medicine": "medicine",
    "tech": "tech",
    "hacking": "hacking",
    "dialogue": "social",
    "exploration": "exploration",
    "survival": "survival",
    "crafting": "crafting",
}


@dataclass(frozen=True)
class NPCActorSnapshot:
    """Read-only canonical actor data supplied by the host runtime.

    This object deliberately mirrors host facts rather than owning them.
    `intelligence_grade` is the already-implemented actor intelligence value.
    No progression in this module may alter it.
    """

    npc_id: str
    intelligence_grade: int
    trust_player: float = 0.5
    openness: float = 0.5
    stubbornness: float = 0.5
    self_interest: float = 0.5
    competencies: Mapping[str, float] = field(default_factory=dict)
    role_tags: tuple[str, ...] = ()
    value_tags: tuple[str, ...] = ()

    def __post_init__(self):
        if not self.npc_id:
            raise ValueError("npc_id required")
        if not (1 <= int(self.intelligence_grade) <= 10):
            raise ValueError("intelligence_grade must come from canonical 1..10 actor scale")


@dataclass(frozen=True)
class NPCWitnessContext:
    """What this specific NPC could actually perceive/know about the event."""

    witnessed: bool = True
    perceived_success: bool = True
    visible_tags: tuple[str, ...] = ()
    relationship_context: tuple[str, ...] = ()


@dataclass
class NPCPatternRecord:
    pattern_key: str
    domain: str
    action_family: str
    observations: int = 0
    successes_seen: int = 0
    failures_seen: int = 0
    contexts: list[str] = field(default_factory=list)
    stance: str = "observing"  # observing|adopted|rejected|adapted|counterproposed
    learned_variant: Optional[str] = None
    last_comment_observation: int = 0

    def context_diversity(self) -> int:
        return len(set(self.contexts))


@dataclass
class NPCObservationState:
    npc_id: str
    patterns: Dict[str, NPCPatternRecord] = field(default_factory=dict)
    learned_routines: list[str] = field(default_factory=list)
    rejected_routines: list[str] = field(default_factory=list)
    adapted_routines: list[str] = field(default_factory=list)
    suggestions_made: list[str] = field(default_factory=list)
    schema_version: int = 1

    def to_dict(self) -> dict:
        return {
            "npc_id": self.npc_id,
            "patterns": {k: asdict(v) for k, v in self.patterns.items()},
            "learned_routines": list(self.learned_routines),
            "rejected_routines": list(self.rejected_routines),
            "adapted_routines": list(self.adapted_routines),
            "suggestions_made": list(self.suggestions_made),
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "NPCObservationState":
        obj = cls(
            npc_id=data["npc_id"],
            learned_routines=list(data.get("learned_routines", [])),
            rejected_routines=list(data.get("rejected_routines", [])),
            adapted_routines=list(data.get("adapted_routines", [])),
            suggestions_made=list(data.get("suggestions_made", [])),
            schema_version=int(data.get("schema_version", 1)),
        )
        for k, rec in dict(data.get("patterns", {})).items():
            obj.patterns[k] = NPCPatternRecord(**rec)
        return obj


@dataclass(frozen=True)
class NPCReaction:
    npc_id: str
    reaction: str  # none|notice|ask|adopt|reject|adapt|suggest
    pattern_key: str
    dialogue_hook: Optional[str] = None
    memory_note: Optional[str] = None
    behavior_hint: Optional[str] = None
    suggested_alternative: Optional[str] = None

    def player_visible_payload(self) -> dict:
        # Intentionally qualitative: never expose intelligence grades, confidence,
        # observation counts, thresholds, or internal utility math.
        payload = {"npc_id": self.npc_id, "reaction": self.reaction}
        if self.dialogue_hook:
            payload["dialogue"] = self.dialogue_hook
        if self.suggested_alternative:
            payload["suggestion"] = self.suggested_alternative
        return payload


class NPCObservationEngine:
    """Observational learning for NPCs, distinct from Player Hidden Insights.

    NPCs can notice, discuss, copy, reject, adapt, or improve player routines.
    They never receive Player Insights, Player Habits, or Player End Paths.
    """

    def __init__(self, states: Optional[Mapping[str, NPCObservationState]] = None):
        self.states: Dict[str, NPCObservationState] = dict(states or {})

    @staticmethod
    def pattern_key(event: ResolvedGameplayEvent) -> str:
        decision = event.choice_key or event.action_family
        situation = event.situation_family or event.domain
        return f"{situation}|{decision}"

    def state_for(self, npc_id: str) -> NPCObservationState:
        if npc_id not in self.states:
            self.states[npc_id] = NPCObservationState(npc_id=npc_id)
        return self.states[npc_id]

    @staticmethod
    def _competence(actor: NPCActorSnapshot, domain: str) -> float:
        key = DOMAIN_COMPETENCE_KEYS.get(domain, domain)
        return float(actor.competencies.get(key, actor.competencies.get(domain, 0.0)))

    @staticmethod
    def _questionable(tags: set[str], event: ResolvedGameplayEvent) -> bool:
        return bool(tags & QUESTIONABLE_TAGS) or event.outcome in {"harmful", "catastrophic"}

    @staticmethod
    def _hard_reject(tags: set[str]) -> bool:
        return bool(tags & HARD_REJECT_TAGS)

    @staticmethod
    def _needed_observations(actor: NPCActorSnapshot) -> int:
        # Smarter actors need less repetition to identify a pattern; this is not
        # a new intelligence model, only consumption of the canonical grade.
        g = int(actor.intelligence_grade)
        if g >= 9:
            return 2
        if g >= 7:
            return 3
        if g >= 5:
            return 4
        if g >= 3:
            return 5
        return 6

    @staticmethod
    def _dialogue(action: str, event: ResolvedGameplayEvent, actor: NPCActorSnapshot) -> str:
        thing = event.action_family.replace("_", " ")
        if action == "notice":
            return f"Mir ist aufgefallen, dass du bei solchen Situationen oft auf {thing} setzt."
        if action == "ask":
            return f"Du machst das öfter so. Was ist der Gedanke hinter {thing}?"
        if action == "adopt":
            return f"Deine Methode mit {thing} funktioniert. Ich werde das künftig ähnlich versuchen."
        if action == "reject":
            return f"Ich sehe, warum du {thing} machst, aber für mich passt diese Methode nicht."
        if action == "adapt":
            return f"Deine Idee mit {thing} ist brauchbar. Ich würde sie etwas an meinen Stil anpassen."
        if action == "suggest":
            return f"{thing.capitalize()} funktioniert, aber ich kenne dafür eine sauberere Methode."
        return ""

    def observe(self, actor: NPCActorSnapshot, event: ResolvedGameplayEvent,
                witness: NPCWitnessContext = NPCWitnessContext()) -> NPCReaction:
        if not witness.witnessed or not event.committed or not event.actor_is_player:
            return NPCReaction(actor.npc_id, "none", self.pattern_key(event))

        state = self.state_for(actor.npc_id)
        key = self.pattern_key(event)
        rec = state.patterns.setdefault(key, NPCPatternRecord(
            pattern_key=key, domain=event.domain, action_family=event.action_family,
        ))
        rec.observations += 1
        if witness.perceived_success and event.outcome not in {"failure", "harmful", "catastrophic"}:
            rec.successes_seen += 1
        else:
            rec.failures_seen += 1
        rec.contexts.extend(witness.visible_tags or event.visible_context_tags)

        tags = set(witness.visible_tags) | set(event.visible_context_tags) | set(event.risk_tags)
        competence = self._competence(actor, event.domain)
        enough = rec.observations >= self._needed_observations(actor)
        diverse = rec.context_diversity() >= 2 or rec.observations >= self._needed_observations(actor) + 2
        questionable = self._questionable(tags, event)

        # Any actor may refuse catastrophically unsafe/nonsensical behavior.
        if self._hard_reject(tags):
            rec.stance = "rejected"
            if key not in state.rejected_routines:
                state.rejected_routines.append(key)
            return NPCReaction(actor.npc_id, "reject", key,
                               self._dialogue("reject", event, actor),
                               memory_note=f"Rejected clearly unsafe player routine: {key}")

        # Canonical actor intelligence matters: from competent/mid intelligence
        # upward, obviously absurd/counterproductive routines are not blindly copied.
        if questionable and actor.intelligence_grade >= 5:
            rec.stance = "rejected"
            if key not in state.rejected_routines:
                state.rejected_routines.append(key)
            alternative = None
            reaction = "reject"
            if actor.intelligence_grade >= 7 and competence >= 0.6:
                reaction = "suggest"
                alternative = f"Eine an {event.domain} angepasste, kontrolliertere Variante verwenden."
                rec.stance = "counterproposed"
                if key not in state.suggestions_made:
                    state.suggestions_made.append(key)
            return NPCReaction(actor.npc_id, reaction, key,
                               self._dialogue(reaction, event, actor),
                               memory_note=f"Evaluated and declined questionable player routine: {key}",
                               suggested_alternative=alternative)

        # Before a stable pattern exists, intelligent/curious actors may comment or ask.
        if not enough or not diverse:
            # Avoid dialogue spam: only surface on the second meaningful observation.
            if rec.observations == 2 and actor.openness >= 0.45:
                action = "ask" if actor.intelligence_grade >= 6 else "notice"
                return NPCReaction(actor.npc_id, action, key,
                                   self._dialogue(action, event, actor),
                                   memory_note=f"Noticed recurring player routine: {key}")
            return NPCReaction(actor.npc_id, "none", key)

        success_ratio = rec.successes_seen / max(1, rec.observations)
        utility_pull = success_ratio + actor.trust_player * 0.25 + actor.openness * 0.25
        resistance = (
            actor.stubbornness * 0.55
            + actor.self_interest * 0.20
            + (1.0 - actor.openness) * 0.20
        )

        # Highly competent/intelligent NPCs are more likely to improve than copy.
        if actor.intelligence_grade >= 9 and competence >= 0.75 and success_ratio >= 0.5:
            rec.stance = "counterproposed"
            rec.learned_variant = f"improved:{key}"
            if key not in state.suggestions_made:
                state.suggestions_made.append(key)
            return NPCReaction(
                actor.npc_id, "suggest", key, self._dialogue("suggest", event, actor),
                memory_note=f"Derived improved method from player routine: {key}",
                behavior_hint=f"May use improved variant of {key} when context fits.",
                suggested_alternative=f"Eine effizientere Variante von {event.action_family.replace('_',' ')}.",
            )

        if actor.intelligence_grade >= 7 and competence >= 0.45 and utility_pull > resistance + 0.45:
            rec.stance = "adapted"
            rec.learned_variant = f"adapted:{key}"
            if key not in state.adapted_routines:
                state.adapted_routines.append(key)
            return NPCReaction(
                actor.npc_id, "adapt", key, self._dialogue("adapt", event, actor),
                memory_note=f"Adapted observed player routine: {key}",
                behavior_hint=f"May use adapted form of {key} when consistent with actor goals.",
            )

        # Adoption remains personality-dependent; even a useful method can be refused.
        if utility_pull > resistance + 0.55 and success_ratio >= 0.55:
            rec.stance = "adopted"
            if key not in state.learned_routines:
                state.learned_routines.append(key)
            return NPCReaction(
                actor.npc_id, "adopt", key, self._dialogue("adopt", event, actor),
                memory_note=f"Learned ordinary routine from player: {key}",
                behavior_hint=f"May imitate {key} when perceived context is similar.",
            )

        rec.stance = "rejected"
        if key not in state.rejected_routines:
            state.rejected_routines.append(key)
        return NPCReaction(actor.npc_id, "reject", key,
                           self._dialogue("reject", event, actor),
                           memory_note=f"Consciously declined player routine: {key}")

    def discuss(self, actor: NPCActorSnapshot, pattern_key: str) -> NPCReaction:
        """Host hook when the player explicitly asks an NPC about a learned pattern."""
        state = self.state_for(actor.npc_id)
        rec = state.patterns.get(pattern_key)
        if rec is None:
            return NPCReaction(actor.npc_id, "none", pattern_key,
                               dialogue_hook="Darauf habe ich bisher nicht besonders geachtet.")
        text = {
            "adopted": "Ja. Ich habe mir davon etwas abgeschaut, weil es in der Praxis funktioniert hat.",
            "adapted": "Teilweise. Ich habe deine Methode übernommen, aber an meine eigene Arbeitsweise angepasst.",
            "counterproposed": "Ich habe mir das angesehen. Deine Idee ist brauchbar, aber ich würde sie anders lösen.",
            "rejected": "Ich kenne die Methode inzwischen, aber ich habe mich bewusst dagegen entschieden.",
            "observing": "Ich habe das bemerkt, bin mir aber noch nicht sicher, ob ich es übernehmen würde.",
        }.get(rec.stance, "Ich habe das beobachtet.")
        return NPCReaction(actor.npc_id, "notice", pattern_key, dialogue_hook=text)

    def to_dict(self) -> dict:
        return {"schema_version": 1, "states": {k: v.to_dict() for k, v in self.states.items()}}

    @classmethod
    def from_dict(cls, payload: dict) -> "NPCObservationEngine":
        states = {k: NPCObservationState.from_dict(v) for k, v in dict(payload.get("states", {})).items()}
        return cls(states)


class NPCObservationalLearningBridge:
    """Host-facing fan-out after a committed player gameplay event.

    The host determines which NPCs actually witnessed/perceived the action and
    supplies canonical actor snapshots. This bridge never grants Player Insights.
    """

    def __init__(self, engine: Optional[NPCObservationEngine] = None):
        self.engine = engine or NPCObservationEngine()

    def after_player_resolution(self, event: ResolvedGameplayEvent,
                                observers: Sequence[tuple[NPCActorSnapshot, NPCWitnessContext]]) -> list[NPCReaction]:
        if not event.committed or not event.actor_is_player:
            return []
        reactions: list[NPCReaction] = []
        for actor, witness in observers:
            r = self.engine.observe(actor, event, witness)
            if r.reaction != "none":
                reactions.append(r)
        return reactions

    def snapshot_for_save(self) -> dict:
        return self.engine.to_dict()

    @classmethod
    def from_save(cls, payload: dict) -> "NPCObservationalLearningBridge":
        return cls(NPCObservationEngine.from_dict(payload))
