from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from .model import PlayerProgressionState, START_CLASSES


@dataclass(frozen=True)
class SpecializationDefinition:
    spec_id: str
    start_class: str
    name: str
    affinities: Tuple[str, ...]
    insight_hints: Tuple[str, ...]
    description: str


@dataclass(frozen=True)
class MasteryDefinition:
    path_id: str
    primary_class: str
    secondary_class: str
    name: str
    description: str
    signature_name: str
    signature_description: str


@dataclass(frozen=True)
class EndPathDefinition:
    path_id: str
    name: str
    affinities: Tuple[str, ...]
    mastery_hints: Tuple[str, ...]
    description: str
    signature_name: str
    signature_description: str


SPECIALIZATIONS: Dict[str, SpecializationDefinition] = {}

def _spec(*args, **kwargs):
    d = SpecializationDefinition(*args, **kwargs)
    SPECIALIZATIONS[d.spec_id] = d


# BREAKER
_spec('RAVAGER','BREAKER','Ravager',('AFF_FORCE','AFF_ENDURANCE','AFF_MOBILITY'),('force_follow_through','end_pain_focus'),
      'Du hast gelernt, Druck nicht nur auszuhalten, sondern ihn in Vorwärtsbewegung zu verwandeln.')
_spec('BULWARK','BREAKER','Bulwark',('AFF_PROTECTION','AFF_ENDURANCE','AFF_COMMAND'),('prot_intercept','prot_hold_line'),
      'Andere beginnen sich darauf zu verlassen, dass du dort stehenbleibst, wo eine Linie sonst brechen würde.')
_spec('BREACHER','BREAKER','Breacher',('AFF_FORCE','AFF_TECH','AFF_ADAPTATION'),('force_shock_entry','tech_fault_sound'),
      'Du siehst Hindernisse immer seltener als Grenzen und immer häufiger als Konstruktionen mit einer Schwachstelle.')
_spec('HUNTER','BREAKER','Hunter',('AFF_SURVIVAL','AFF_PERCEPTION','AFF_FORCE'),('surv_route','perc_pattern'),
      'Du jagst nicht schneller. Du lässt deinem Ziel nur immer weniger gute Entscheidungen.')

# GHOST
_spec('SHADE','GHOST','Shade',('AFF_STEALTH','AFF_PERCEPTION','AFF_MOBILITY'),('stealth_noise_mask','stealth_lost_contact'),
      'Du verlässt dich nicht mehr darauf, ungesehen zu sein. Du kontrollierst zunehmend, was andere überhaupt wahrnehmen.')
_spec('DEADEYE','GHOST','Deadeye',('AFF_PRECISION','AFF_PERCEPTION','AFF_STEALTH'),('prec_range_feel','prec_weakpoint'),
      'Geduld, Distanz und der richtige Augenblick sind für dich zu einem einzigen Vorgang geworden.')
_spec('RUNNER','GHOST','Runner',('AFF_MOBILITY','AFF_ADAPTATION','AFF_ENDURANCE'),('mob_fast_vault','mob_flow'),
      'Bewegung ist für dich kein Weg zwischen Aktionen mehr. Sie ist selbst Teil jeder Aktion.')
_spec('STALKER','GHOST','Stalker',('AFF_PERCEPTION','AFF_SURVIVAL','AFF_STEALTH'),('perc_motion','perc_pattern'),
      'Du liest Räume über Bewegung, Gewohnheit und Abweichung, lange bevor andere wissen, wonach sie suchen sollen.')

# OPERATOR
_spec('GEARSMITH','OPERATOR','Gearsmith',('AFF_TECH','AFF_ADAPTATION','AFF_SURVIVAL'),('tech_fault_sound','tech_field_fab'),
      'Du reparierst nicht mehr nur Dinge. Du verstehst, welche Teile einer Lösung wirklich notwendig sind.')
_spec('NETSPIDER','OPERATOR','Netspider',('AFF_NETWORK','AFF_PERCEPTION','AFF_ADAPTATION'),('net_trace','net_ghost_access'),
      'Netze fühlen sich für dich weniger wie Menüs und mehr wie Räume mit Türen, Gewohnheiten und blinden Winkeln an.')
_spec('FIELD_MEDIC','OPERATOR','Field Medic',('AFF_MEDICAL','AFF_PROTECTION','AFF_ADAPTATION'),('med_trauma','med_adaptive'),
      'Unter Druck trennst du immer schneller zwischen dem, was schlimm aussieht, und dem, was jetzt wirklich zählt.')
_spec('CONTROLLER','OPERATOR','Controller',('AFF_MACHINE','AFF_COMMAND','AFF_NETWORK'),('mach_sensor_link','mach_mesh'),
      'Mehrere Geräte beginnen sich unter deiner Führung wie Teile desselben Körpers zu verhalten.')

# RESONANT
_spec('MENDER','RESONANT','Mender',('AFF_RESONANCE','AFF_MEDICAL','AFF_PROTECTION'),('res_grounding','hyb_resonant_guard'),
      'Du spürst immer deutlicher, wann ein Körper Unterstützung braucht und wann Eingreifen mehr schadet als hilft.')
_spec('SEER','RESONANT','Seer',('AFF_RESONANCE','AFF_PERCEPTION','AFF_SOCIAL'),('res_static','perc_pattern'),
      'Du bemerkst Zusammenhänge, bevor du sie vollständig erklären kannst, und hast gelernt, diesem Vorsprung vorsichtig zu vertrauen.')
_spec('FLUX','RESONANT','Flux',('AFF_RESONANCE','AFF_ADAPTATION','AFF_TECH'),('res_redirect','hyb_signal_empathy'),
      'Energie ist für dich immer weniger Zustand und immer mehr Bewegung, Richtung und Gelegenheit.')
_spec('VOIDCALLER','RESONANT','Voidcaller',('AFF_RESONANCE','AFF_ENDURANCE','AFF_PERCEPTION'),('res_grounding','res_redirect'),
      'Du hast aufgehört, jedes ungewöhnliche Phänomen sofort erklären zu wollen. Dadurch bemerkst du mehr davon.')


MASTERY: Dict[Tuple[str, str], MasteryDefinition] = {}

def _master(primary, secondary, name, desc, sig, sigdesc):
    pid = f'{primary}_TO_{secondary}'
    MASTERY[(primary, secondary)] = MasteryDefinition(pid, primary, secondary, name, desc, sig, sigdesc)

_master('BREAKER','BREAKER','Dreadnought','Dein Körper, deine Ausrüstung und dein Angriffsrhythmus sind zu einer einzigen Front geworden.',
        'Unbroken Advance','Wenn du dich zu einem Vorstoß entschieden hast, wird Unterbrechung selbst zu einer Ressource, die du überwinden kannst.')
_master('BREAKER','GHOST','Razor','Rohe Kraft hat gelernt, den richtigen Winkel und den richtigen Moment zu respektieren.',
        'Kinetic Execution','Bewegungsenergie und Nahkampf greifen so sauber ineinander, dass Positionierung selbst Schaden vorbereitet.')
_master('BREAKER','OPERATOR','Ironhand','Schwere Technik ordnet sich deinem Kampf an, statt dich zu verlangsamen.',
        'Combat Rig','Ausrüstung, Schutzsysteme und schwere Werkzeuge reagieren wie ein abgestimmtes Gefechtssystem.')
_master('BREAKER','RESONANT','Warsaint','Wille, Schmerz und Resonanz antworten zunehmend im selben Augenblick.',
        'Martyr Engine','Eigene Belastung kann in Schutz, Stabilität oder Entschlossenheit für andere übersetzt werden.')

_master('GHOST','BREAKER','Predator','Präzision hat gelernt, dass manchmal ein einziger entschlossener Vorstoß besser ist als zehn perfekte Positionen.',
        'Predator Clock','Du erkennst nicht nur eine Öffnung, sondern wann sie unausweichlich entstehen wird.')
_master('GHOST','GHOST','Wraith','Deine Bewegungen hinterlassen immer weniger verwertbare Gewissheit.',
        'Erase Route','Nach einem Positionswechsel fällt es Gegnern schwerer, aus deinem letzten Verhalten den nächsten Ort abzuleiten.')
_master('GHOST','OPERATOR','Spectre','Infiltration und Systeme greifen so ineinander, dass Sicherheit selten weiß, ob sie einen Menschen oder einen Fehler sucht.',
        'Blackout Entry','Mehrere Sicherheitsprobleme können zu einem einzigen kurzen, kontrollierten Eintrittsfenster verbunden werden.')
_master('GHOST','RESONANT','Phasewalker','Wahrnehmung und Bewegung beginnen Grenzen anders zu behandeln als andere Menschen.',
        'Phase Sense','Du erkennst Momente, in denen Sicht, Aufmerksamkeit und Resonanz gemeinsam einen unmöglichen Weg möglich machen.')

_master('OPERATOR','BREAKER','Wartech','Du baust nicht mehr für die Werkbank. Du baust dafür, dass Technik unter Gewalt weiterfunktioniert.',
        'Hardpoint Logic','Geräte und Ausrüstung können gezielt für extreme Belastung und aggressiven Einsatz abgestimmt werden.')
_master('OPERATOR','GHOST','Nightwire','Technik ist für dich am stärksten, wenn niemand merkt, dass sie überhaupt beteiligt war.',
        'Dead Circuit','Manipulationen können so ausgeführt werden, dass ein Ausfall wie gewöhnlicher Verschleiß oder Zufall wirkt.')
_master('OPERATOR','OPERATOR','Architect','Einzelne Systeme interessieren dich weniger als die Beziehungen zwischen ihnen.',
        'Living Network','Eigene Sensoren, Geräte, Drohnen und Automatik können wie ein verteiltes Gesamtsystem arbeiten.')
_master('OPERATOR','RESONANT','Technomancer','Du beginnst Maschinenzustände zu erfassen, bevor Diagnose und Intuition noch sauber voneinander zu trennen sind.',
        'Machine Communion','Technisches Wissen und Resonanz ergänzen sich zu einer unmittelbaren Wahrnehmung komplexer Systeme.')

_master('RESONANT','BREAKER','Warprophet','Was du spürst, bleibt nicht länger nur Warnung oder Ahnung. Du setzt es körperlich durch.',
        'Forefelt Impact','Resonante Vorahnung und entschlossene Kraft verschmelzen zu extrem frühen Reaktionen auf unmittelbare Gefahr.')
_master('RESONANT','GHOST','Veilwalker','Du bewegst dich zunehmend entlang dessen, was andere nicht beachten, statt nur entlang dessen, was sie nicht sehen.',
        'Between Attention','Du kannst kurze Wahrnehmungslücken erkennen und nutzen, bevor sie bewusst auffallen.')
_master('RESONANT','OPERATOR','Biosynth','Biologie, Technik und Resonanz erscheinen dir immer häufiger als verschiedene Oberflächen desselben Problems.',
        'Adaptive Interface','Behandlung, Implantate und technische Hilfsmittel können ungewöhnlich flexibel miteinander kombiniert werden.')
_master('RESONANT','RESONANT','Ascendant','Deine Resonanz ist keine einzelne Fähigkeit mehr, sondern eine Art, die Welt zu ordnen.',
        'Resonance Cascade','Ein sauber verstandener Resonanzzustand kann auf verbundene Ziele oder Systeme weitergeführt werden.')


END_PATHS: Dict[str, EndPathDefinition] = {}

def _end(path_id, name, affinities, mastery_hints, desc, sig, sigdesc):
    END_PATHS[path_id] = EndPathDefinition(path_id,name,tuple(affinities),tuple(mastery_hints),desc,sig,sigdesc)

# Legend identities are behavior-first. A mastery hint gives context, not exclusivity.
_end('THE_BASTION','The Bastion',('AFF_PROTECTION','AFF_ENDURANCE','AFF_COMMAND'),('BULWARK','WARSAINT','DREADNOUGHT'),
     'Du hast irgendwann aufgehört, Deckung zu suchen. Andere suchen sie bei dir.',
     'Nobody Falls','Solange du eine Linie bewusst hältst, profitieren Verbündete in deiner unmittelbaren Verantwortung von deiner Schutzroutine.')
_end('THE_DREADNOUGHT','The Dreadnought',('AFF_FORCE','AFF_ENDURANCE','AFF_TECH'),('DREADNOUGHT','IRONHAND','WARTECH'),
     'Widerstand ist für dich kein Stoppsignal mehr, sondern Information darüber, wie viel Kraft noch fehlt.',
     'Unstoppable Mass','Schwere Belastung und Widerstand unterbrechen deinen Vorstoß deutlich seltener vollständig.')
_end('THE_LAST_HUNTER','The Last Hunter',('AFF_SURVIVAL','AFF_PERCEPTION','AFF_PRECISION'),('HUNTER','PREDATOR','STALKER'),
     'Du jagst keine Spuren mehr. Du jagst Entscheidungen, die ein Ziel noch treffen kann.',
     'No Good Exit','Lange beobachtete oder verfolgte Ziele verlieren zunehmend sichere Rückzugsoptionen.')
_end('THE_GHOSTLINE','The Ghostline',('AFF_STEALTH','AFF_MOBILITY','AFF_PERCEPTION'),('SHADE','WRAITH','SPECTRE'),
     'Du hinterlässt keine Unsichtbarkeit. Du hinterlässt Widersprüche darüber, wo du gewesen sein könntest.',
     'You Never Saw Me','Sauber ausgeführte Infiltration reduziert verwertbare Hinweise auf Route und Methode.')
_end('THE_ZERO','The Zero',('AFF_PRECISION','AFF_PERCEPTION','AFF_ADAPTATION'),('DEADEYE','PREDATOR','RAZOR'),
     'Du brauchst immer weniger Chancen. Eine gute reicht.',
     'Single Answer','Lange vorbereitete erste Aktionen gegen ein verstandenes Ziel gewinnen außergewöhnliche Zuverlässigkeit.')
_end('THE_RUNNER','The Runner',('AFF_MOBILITY','AFF_ENDURANCE','AFF_ADAPTATION'),('RUNNER','PHASEWALKER','VEILWALKER'),
     'Stillstand fühlt sich für dich inzwischen gefährlicher an als Bewegung.',
     'Continuous Line','Gelungene Bewegungsentscheidungen können sich zu ungewöhnlich langen, flüssigen Aktionsketten verbinden.')
_end('THE_ARCHITECT','The Architect',('AFF_TECH','AFF_MACHINE','AFF_NETWORK'),('ARCHITECT','CONTROLLER','GEARSMITH'),
     'Du baust keine Geräte mehr. Du baust Beziehungen zwischen Systemen.',
     'Living Network','Deine verbundenen Systeme teilen Information und Aufgabe deutlich natürlicher miteinander.')
_end('THE_BLACK_SIGNAL','The Black Signal',('AFF_NETWORK','AFF_STEALTH','AFF_ADAPTATION'),('NETSPIDER','SPECTRE','NIGHTWIRE'),
     'Dein bester Eingriff ist der, dessen Existenz niemand beweisen kann.',
     'False Normal','Digitale Manipulationen können sich glaubwürdiger als normaler Systemzustand tarnen.')
_end('THE_LIFELINE','The Lifeline',('AFF_MEDICAL','AFF_PROTECTION','AFF_COMMAND'),('FIELD_MEDIC','BIOSYNTH','WARSAINT'),
     'Du siehst Verletzte nicht mehr als Fälle. Du siehst, was als Nächstes getan werden muss.',
     'Keep Them Here','Unter extremem Druck kannst du mehrere lebenswichtige Prioritäten zuverlässiger gleichzeitig koordinieren.')
_end('THE_SWARM','The Swarm',('AFF_MACHINE','AFF_COMMAND','AFF_PERCEPTION'),('CONTROLLER','ARCHITECT','TECHNOMANCER'),
     'Deine Geräte sind keine Begleiter mehr. Sie sind verteilte Aufmerksamkeit.',
     'Distributed Self','Mehrere autonome Systeme können Aufgaben mit weniger direkter Einzelsteuerung koordinieren.')
_end('THE_FORGE','The Forge',('AFF_TECH','AFF_SURVIVAL','AFF_ADAPTATION'),('GEARSMITH','WARTECH','IRONHAND'),
     'Mangel ist für dich inzwischen nur eine weitere Materialeigenschaft.',
     'Nothing Is Scrap','Unvollständige Komponenten können häufiger zu belastbaren Übergangslösungen kombiniert werden.')
_end('THE_SIGNAL','The Signal',('AFF_RESONANCE','AFF_PERCEPTION','AFF_SOCIAL'),('SEER','ASCENDANT','VEILWALKER'),
     'Du nimmst Muster wahr, bevor sie Namen haben.',
     'Resonant Forecast','Starke Veränderungen können sich dir als qualitative Vorzeichen zeigen, ohne sichere Zukunftsinformation zu liefern.')
_end('THE_NULL','The Null',('AFF_RESONANCE','AFF_ENDURANCE','AFF_ADAPTATION'),('VOIDCALLER','ASCENDANT','WARPROPHET'),
     'Du hast gelernt, dass manche Kräfte am verwundbarsten sind, wenn man ihnen nichts anbietet, woran sie greifen können.',
     'Dead Zone','Unter passenden Bedingungen kannst du störende Resonanzeinflüsse in einem begrenzten Bereich stark dämpfen.')
_end('THE_MACHINE_ORACLE','The Machine Oracle',('AFF_RESONANCE','AFF_TECH','AFF_MACHINE'),('TECHNOMANCER','BIOSYNTH','FLUX'),
     'Bei komplexen Maschinen ist Diagnose für dich manchmal nur noch die Bestätigung dessen, was du bereits gespürt hast.',
     'Machine Communion','Technische und resonante Wahrnehmung verschmelzen bei vertrauten Systemen zu außergewöhnlich früher Fehlererkennung.')
_end('THE_WARSAINT','The Warsaint',('AFF_RESONANCE','AFF_PROTECTION','AFF_FORCE'),('WARSAINT','WARPROPHET','MENDER'),
     'Du trägst Belastung nicht, weil sie dich nicht trifft, sondern weil du entschieden hast, wofür sie sich lohnt.',
     'Last Light','In einer extremen Schutzsituation kannst du trotz schwerer eigener Beeinträchtigung noch eine entscheidende Schutzhandlung ausführen.')
_end('THE_ADAPTIVE','The Adaptive',('AFF_ADAPTATION','AFF_SURVIVAL','AFF_SOCIAL'),('BREACHER','GEARSMITH','BIOSYNTH'),
     'Du hast keinen bevorzugten Plan mehr. Du hast bevorzugte Arten, neue Pläne zu finden.',
     'Third Option','Wenn zwei offensichtliche Lösungswege scheitern, steigt deine Chance, eine tragfähige improvisierte Alternative zu erkennen.')


CLASS_AFFINITY = {
    'BREAKER': ('AFF_FORCE','AFF_ENDURANCE','AFF_PROTECTION'),
    'GHOST': ('AFF_STEALTH','AFF_MOBILITY','AFF_PRECISION','AFF_PERCEPTION'),
    'OPERATOR': ('AFF_TECH','AFF_NETWORK','AFF_MACHINE','AFF_MEDICAL','AFF_COMMAND'),
    'RESONANT': ('AFF_RESONANCE','AFF_PERCEPTION','AFF_MEDICAL','AFF_SOCIAL'),
}


class PathResolver:
    """Hidden numeric resolver; outputs only qualitative player-facing payloads.

    The resolver never exposes affinity values, thresholds, ranks or percentages.
    Level 10: player chooses among style-supported candidates.
    Level 30: directed primary->secondary biography path.
    Level 50: behavior-first legend identity.
    """

    def _score_affinities(self, state: PlayerProgressionState, keys: Sequence[str]) -> float:
        return sum(float(state.affinities.get(k, 0.0)) for k in keys)

    def level10_candidates(self, state: PlayerProgressionState, limit: int = 2) -> List[SpecializationDefinition]:
        pool = [d for d in SPECIALIZATIONS.values() if d.start_class == state.start_class]
        scored = []
        for d in pool:
            score = self._score_affinities(state, d.affinities)
            # unlocked related insights are supporting evidence but never required.
            score += sum(1.0 for i in d.insight_hints if i in state.unlocked_insights) * 2.0
            scored.append((score, d.spec_id, d))
        scored.sort(key=lambda x: (-x[0], x[1]))
        # Even sparse/new characters get a meaningful choice, not a hard lockout.
        return [x[2] for x in scored[:max(1, limit)]]

    def choose_specialization(self, state: PlayerProgressionState, spec_id: str) -> SpecializationDefinition:
        if state.level < 10:
            raise ValueError('specialization is not available yet')
        if state.specialization:
            if state.specialization == spec_id:
                return SPECIALIZATIONS[spec_id]
            raise ValueError('specialization already committed')
        allowed = {d.spec_id for d in self.level10_candidates(state, limit=2)}
        if spec_id not in allowed:
            raise ValueError('specialization is not supported by current character development')
        d = SPECIALIZATIONS[spec_id]
        state.specialization = spec_id
        return d

    def secondary_class(self, state: PlayerProgressionState) -> str:
        # Start class remains biography-primary. Secondary is whichever class-family
        # the later behavior most strongly supports; ties prefer primary.
        scores = {c: self._score_affinities(state, keys) for c, keys in CLASS_AFFINITY.items()}
        primary = state.start_class
        ranked = sorted(scores, key=lambda c: (-scores[c], 0 if c == primary else 1, c))
        return ranked[0]

    def resolve_mastery(self, state: PlayerProgressionState) -> Optional[MasteryDefinition]:
        if state.level < 30 or not state.specialization:
            return None
        secondary = self.secondary_class(state)
        return MASTERY[(state.start_class, secondary)]

    def commit_mastery(self, state: PlayerProgressionState) -> MasteryDefinition:
        if state.mastery_path:
            return next(d for d in MASTERY.values() if d.path_id == state.mastery_path)
        d = self.resolve_mastery(state)
        if d is None:
            raise ValueError('mastery path is not available yet')
        state.mastery_path = d.path_id
        return d

    def end_path_candidates(self, state: PlayerProgressionState, limit: int = 3) -> List[EndPathDefinition]:
        mastery_name = None
        if state.mastery_path:
            mastery_name = next((d.name.upper() for d in MASTERY.values() if d.path_id == state.mastery_path), None)
        scored = []
        for d in END_PATHS.values():
            score = self._score_affinities(state, d.affinities)
            hints = {x.upper() for x in d.mastery_hints}
            if state.specialization and state.specialization.upper() in hints:
                score += 3.0
            if mastery_name and mastery_name in hints:
                score += 4.0
            scored.append((score, d.path_id, d))
        scored.sort(key=lambda x: (-x[0], x[1]))
        return [x[2] for x in scored[:max(1, limit)]]

    def commit_end_path(self, state: PlayerProgressionState, path_id: Optional[str] = None) -> EndPathDefinition:
        if state.level < 50 or not state.mastery_path:
            raise ValueError('end path is not available yet')
        if state.end_path:
            return END_PATHS[state.end_path]
        candidates = self.end_path_candidates(state, limit=3)
        if path_id is None:
            # End identity is earned; default commits the strongest biography match.
            chosen = candidates[0]
        else:
            allowed = {d.path_id for d in candidates}
            if path_id not in allowed:
                raise ValueError('end path is not supported by current character development')
            chosen = END_PATHS[path_id]
        state.end_path = chosen.path_id
        return chosen

    @staticmethod
    def visible_specialization_choice(defs: Iterable[SpecializationDefinition]) -> List[dict]:
        return [{'kind':'specialization_candidate','name':d.name,'description':d.description} for d in defs]

    @staticmethod
    def visible_mastery(d: MasteryDefinition) -> dict:
        return {
            'kind':'mastery_path', 'name':d.name, 'description':d.description,
            'signature': {'name':d.signature_name, 'description':d.signature_description}
        }

    @staticmethod
    def visible_end_path(d: EndPathDefinition) -> dict:
        return {
            'kind':'end_path', 'name':d.name, 'description':d.description,
            'signature': {'name':d.signature_name, 'description':d.signature_description}
        }
