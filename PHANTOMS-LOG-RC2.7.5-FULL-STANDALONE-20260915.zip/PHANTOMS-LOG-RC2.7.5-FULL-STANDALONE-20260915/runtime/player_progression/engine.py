from dataclasses import dataclass, field
from typing import Dict, Iterable
from .model import PlayerProgressionState, AFFINITIES

@dataclass(frozen=True)
class BehaviorEvent:
    action_family: str
    affinity_weights: Dict[str, float]
    difficulty: float = 1.0
    consequence: float = 1.0
    contextual_variety: float = 1.0
    intentionality: float = 1.0
    success_quality: float = 1.0
    novelty: float = 1.0
    repetition: float = 0.0
    triviality: float = 0.0
    exploit_signal: float = 0.0
    tags: tuple[str, ...] = field(default_factory=tuple)

class HiddenAffinityEngine:
    """Player-only hidden progression accumulator.

    No presentation API exposes raw scores. Runtime callers may persist state,
    while UI/narration must consume qualitative projections added in later stages.
    """

    def apply(self, state: PlayerProgressionState, event: BehaviorEvent) -> PlayerProgressionState:
        positive = (
            max(0.0, event.difficulty)
            * max(0.0, event.consequence)
            * max(0.0, event.contextual_variety)
            * max(0.0, event.intentionality)
            * max(0.0, event.success_quality)
            * max(0.0, event.novelty)
        )
        penalty = 1.0 + max(0.0, event.repetition) + max(0.0, event.triviality) + max(0.0, event.exploit_signal)
        evidence = positive / penalty
        # hard cap per event prevents one spectacular event from dominating a run.
        evidence = min(evidence, 4.0)

        for affinity, weight in event.affinity_weights.items():
            if affinity not in AFFINITIES:
                raise ValueError(f'unknown affinity: {affinity}')
            state.affinities[affinity] += evidence * max(0.0, float(weight))

        state.pattern_evidence[event.action_family] = state.pattern_evidence.get(event.action_family, 0.0) + evidence
        return state

    def apply_many(self, state: PlayerProgressionState, events: Iterable[BehaviorEvent]) -> PlayerProgressionState:
        for event in events:
            self.apply(state, event)
        return state

    @staticmethod
    def player_visible_payload(state: PlayerProgressionState) -> dict:
        """Deliberately excludes all numeric hidden learning state."""
        return {
            'start_class': state.start_class,
            'level': state.level,
            'specialization': state.specialization,
            'mastery_path': state.mastery_path,
            'end_path': state.end_path,
            'unlocked_insights': list(state.unlocked_insights),
        }
