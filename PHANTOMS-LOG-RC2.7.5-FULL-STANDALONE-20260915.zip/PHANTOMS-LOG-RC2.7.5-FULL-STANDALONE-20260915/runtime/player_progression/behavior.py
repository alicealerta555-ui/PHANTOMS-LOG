from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass, field
from hashlib import sha256
from math import exp
from typing import Deque, Dict, Iterable, Mapping, Optional, Sequence, Tuple

from .engine import BehaviorEvent


@dataclass(frozen=True)
class RawActionEvent:
    """Normalized runtime action emitted by gameplay systems.

    The tracker intentionally does not know about UI text. All values are hidden
    runtime evidence used to build a BehaviorEvent for HiddenAffinityEngine.
    """

    action_family: str
    affinity_weights: Mapping[str, float]
    location_id: str = ""
    target_kind: str = ""
    tool_kind: str = ""
    outcome: str = "success"  # success | partial | failure | abort
    difficulty_hint: float = 1.0
    consequence_hint: float = 1.0
    intentionality_hint: float = 1.0
    risk_tags: Tuple[str, ...] = field(default_factory=tuple)
    context_tags: Tuple[str, ...] = field(default_factory=tuple)
    actor_is_player: bool = True


@dataclass(frozen=True)
class AntiFarmAssessment:
    repetition: float
    triviality: float
    exploit_signal: float
    contextual_variety: float
    novelty: float
    success_quality: float


@dataclass
class BehaviorTrackerState:
    """Per-run tracker state; player-only and persisted with mutable run state."""

    recent_signatures: Deque[str] = field(default_factory=lambda: deque(maxlen=48))
    signature_counts: Counter = field(default_factory=Counter)
    family_counts: Counter = field(default_factory=Counter)
    context_counts: Counter = field(default_factory=Counter)
    last_signature: Optional[str] = None
    repeated_streak: int = 0
    accepted_events: int = 0
    ignored_non_player_events: int = 0

    def to_dict(self) -> dict:
        return {
            "recent_signatures": list(self.recent_signatures),
            "signature_counts": dict(self.signature_counts),
            "family_counts": dict(self.family_counts),
            "context_counts": dict(self.context_counts),
            "last_signature": self.last_signature,
            "repeated_streak": self.repeated_streak,
            "accepted_events": self.accepted_events,
            "ignored_non_player_events": self.ignored_non_player_events,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, object]) -> "BehaviorTrackerState":
        state = cls()
        state.recent_signatures.extend(data.get("recent_signatures", []) or [])
        state.signature_counts.update(data.get("signature_counts", {}) or {})
        state.family_counts.update(data.get("family_counts", {}) or {})
        state.context_counts.update(data.get("context_counts", {}) or {})
        state.last_signature = data.get("last_signature") or None
        state.repeated_streak = int(data.get("repeated_streak", 0) or 0)
        state.accepted_events = int(data.get("accepted_events", 0) or 0)
        state.ignored_non_player_events = int(data.get("ignored_non_player_events", 0) or 0)
        return state


class BehaviorTracker:
    """Converts gameplay actions into anti-farm-weighted BehaviorEvents.

    Principles:
    - Player-only: NPC/Crew events are rejected before learning.
    - Context beats raw repetition.
    - Failure may still teach if risk/context were meaningful.
    - Repeated safe actions asymptotically approach negligible learning.
    - No unlock probability or hidden numerical state is exposed to presentation.
    """

    _SUCCESS_QUALITY = {
        "success": 1.0,
        "partial": 0.72,
        "failure": 0.48,
        "abort": 0.18,
    }

    def __init__(self, recent_window: int = 48):
        if recent_window < 8:
            raise ValueError("recent_window must be >= 8")
        self.recent_window = recent_window

    @staticmethod
    def _clamp(value: float, lo: float, hi: float) -> float:
        return max(lo, min(hi, float(value)))

    @staticmethod
    def _context_key(event: RawActionEvent) -> str:
        tags = ",".join(sorted(set(event.context_tags + event.risk_tags)))
        return f"{event.action_family}|{event.location_id}|{event.target_kind}|{event.tool_kind}|{tags}"

    @classmethod
    def _signature(cls, event: RawActionEvent) -> str:
        # Hash avoids persisting verbose/raw context strings and keeps state compact.
        raw = cls._context_key(event).encode("utf-8", "replace")
        return sha256(raw).hexdigest()[:20]

    @staticmethod
    def _risk_multiplier(tags: Sequence[str]) -> float:
        t = set(tags)
        if {"life_or_death", "critical"} & t:
            return 1.65
        if {"dangerous", "combat", "time_pressure"} & t:
            return 1.30
        if {"safe", "training_dummy", "no_consequence"} & t:
            return 0.45
        return 1.0

    def assess(self, state: BehaviorTrackerState, event: RawActionEvent) -> AntiFarmAssessment:
        sig = self._signature(event)
        seen_total = state.signature_counts[sig]
        family_seen = state.family_counts[event.action_family]
        context_seen = state.context_counts[self._context_key(event)]

        recent = list(state.recent_signatures)
        recent_same = recent.count(sig)
        recent_family_density = 0.0
        if recent:
            # Approximate density through persisted signature family-independent repetition.
            recent_family_density = min(1.0, recent_same / max(1.0, len(recent) * 0.35))

        # Repetition grows fast for identical context, but never blocks learning entirely.
        repetition = (
            min(5.0, seen_total * 0.22)
            + min(4.0, recent_same * 0.48)
            + min(3.0, state.repeated_streak * 0.35)
            + recent_family_density
        )

        difficulty = self._clamp(event.difficulty_hint, 0.05, 2.5)
        consequence = self._clamp(event.consequence_hint, 0.05, 2.5)
        risk_mult = self._risk_multiplier(event.risk_tags)

        triviality = 0.0
        if difficulty < 0.55:
            triviality += (0.55 - difficulty) * 3.0
        if consequence < 0.55:
            triviality += (0.55 - consequence) * 3.0
        if risk_mult < 1.0:
            triviality += 1.1

        # Strong exploit signal requires BOTH repetition and low-value context.
        exploit_signal = 0.0
        if seen_total >= 8 and (difficulty < 0.5 or consequence < 0.5):
            exploit_signal += min(5.0, (seen_total - 7) * 0.30)
        if state.repeated_streak >= 6 and risk_mult <= 1.0:
            exploit_signal += min(4.0, (state.repeated_streak - 5) * 0.45)
        if {"training_dummy", "no_consequence"} & set(event.risk_tags):
            exploit_signal += 1.25

        # Novel contexts matter; exact repeats taper. Context variety is bounded.
        novelty = 1.0 / (1.0 + 0.18 * seen_total)
        novelty = self._clamp(novelty, 0.18, 1.0)

        context_novelty = 1.0 / (1.0 + 0.10 * context_seen)
        family_breadth = 1.0 + min(0.35, family_seen / 60.0)
        contextual_variety = self._clamp(context_novelty * family_breadth, 0.35, 1.35)

        base_quality = self._SUCCESS_QUALITY.get(event.outcome, 0.5)
        # Meaningful failures can still teach; dangerous failures receive a modest floor.
        if event.outcome == "failure" and risk_mult > 1.0:
            base_quality = max(base_quality, 0.62)
        success_quality = self._clamp(base_quality * risk_mult, 0.12, 1.45)

        return AntiFarmAssessment(
            repetition=repetition,
            triviality=triviality,
            exploit_signal=exploit_signal,
            contextual_variety=contextual_variety,
            novelty=novelty,
            success_quality=success_quality,
        )

    def record(self, state: BehaviorTrackerState, event: RawActionEvent) -> Optional[BehaviorEvent]:
        if not event.actor_is_player:
            state.ignored_non_player_events += 1
            return None

        assessment = self.assess(state, event)
        sig = self._signature(event)
        key = self._context_key(event)

        if state.last_signature == sig:
            state.repeated_streak += 1
        else:
            state.repeated_streak = 0
        state.last_signature = sig

        # Recreate bounded deque if loaded state used a different maxlen.
        if state.recent_signatures.maxlen != self.recent_window:
            state.recent_signatures = deque(state.recent_signatures, maxlen=self.recent_window)
        state.recent_signatures.append(sig)
        state.signature_counts[sig] += 1
        state.family_counts[event.action_family] += 1
        state.context_counts[key] += 1
        state.accepted_events += 1

        return BehaviorEvent(
            action_family=event.action_family,
            affinity_weights=dict(event.affinity_weights),
            difficulty=self._clamp(event.difficulty_hint, 0.05, 2.5),
            consequence=self._clamp(event.consequence_hint, 0.05, 2.5),
            contextual_variety=assessment.contextual_variety,
            intentionality=self._clamp(event.intentionality_hint, 0.1, 1.5),
            success_quality=assessment.success_quality,
            novelty=assessment.novelty,
            repetition=assessment.repetition,
            triviality=assessment.triviality,
            exploit_signal=assessment.exploit_signal,
            tags=tuple(sorted(set(event.context_tags + event.risk_tags))),
        )

    def record_many(self, state: BehaviorTrackerState, events: Iterable[RawActionEvent]) -> list[BehaviorEvent]:
        out: list[BehaviorEvent] = []
        for event in events:
            weighted = self.record(state, event)
            if weighted is not None:
                out.append(weighted)
        return out
