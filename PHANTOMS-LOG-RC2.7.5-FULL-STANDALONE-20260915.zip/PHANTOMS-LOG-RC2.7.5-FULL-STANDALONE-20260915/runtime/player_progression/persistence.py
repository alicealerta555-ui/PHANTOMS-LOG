from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Mapping, Any

from .model import PlayerProgressionState, AFFINITIES, START_CLASSES
from .behavior import BehaviorTrackerState
from .habits import HabitRuntimeState
from .predictive import PredictiveRoutineState
from .levels import level_for_xp

CURRENT_SCHEMA_VERSION = 10


class ProgressionSaveError(ValueError):
    pass


@dataclass(frozen=True)
class MigrationResult:
    payload: dict
    migrated_from: int
    migrated_to: int


def _clean_affinities(raw: Mapping[str, Any] | None) -> dict[str, float]:
    raw = raw or {}
    legacy_keys={key.removeprefix("AFF_") for key in AFFINITIES}
    if any(str(key) in legacy_keys for key in raw):
        raise ProgressionSaveError("legacy affinity namespace unsupported")
    out: dict[str, float] = {}
    for key in AFFINITIES:
        try:
            value = float(raw.get(key, 0.0) or 0.0)
        except (TypeError, ValueError):
            value = 0.0
        out[key] = max(0.0, value)
    return out


def migrate_payload(data: Mapping[str, Any]) -> MigrationResult:
    """Migrate additive player-progression save payloads to the current schema.

    Fail-closed principles:
    - never invent player/run identity;
    - never borrow another run's state;
    - unknown optional fields are ignored by the progression runtime;
    - missing hidden-learning fields default to a clean, empty state.
    """
    src = deepcopy(dict(data or {}))
    old_version = int(src.get("schema_version", 1) or 1)

    # Accept both wrapped runtime payloads and early direct progression payloads.
    if "progression" in src:
        progression = dict(src.get("progression") or {})
        tracker = dict(src.get("tracker_state") or {})
        habits = dict(src.get("habit_state") or {})
        predictive = dict(src.get("predictive_state") or {})
    else:
        progression = dict(src)
        tracker = {}
        habits = {}
        predictive = {}

    player_uuid = str(progression.get("player_uuid") or "").strip()
    run_uuid = str(progression.get("run_uuid") or "").strip()
    start_class = str(progression.get("start_class") or "").strip().upper()
    if not player_uuid:
        raise ProgressionSaveError("missing player_uuid")
    if not run_uuid:
        raise ProgressionSaveError("missing run_uuid")
    if start_class not in START_CLASSES:
        raise ProgressionSaveError(f"invalid start_class: {start_class or '<missing>'}")

    progression["player_uuid"] = player_uuid
    progression["run_uuid"] = run_uuid
    progression["start_class"] = start_class
    progression["level"] = max(1, int(progression.get("level", 1) or 1))
    progression["affinities"] = _clean_affinities(progression.get("affinities"))
    progression["pattern_evidence"] = {
        str(k): max(0.0, float(v or 0.0))
        for k, v in dict(progression.get("pattern_evidence") or {}).items()
        if str(k)
    }
    # RC2.6.8 compatibility repair: older saves accumulated anti-farm-filtered
    # pattern evidence but had no numeric XP field. Preserve that earned
    # progress exactly once by using the already persisted evidence total.
    if "xp" in progression:
        try:
            xp = max(0.0, float(progression.get("xp", 0.0) or 0.0))
        except (TypeError, ValueError):
            xp = 0.0
    else:
        xp = sum(progression["pattern_evidence"].values())
    progression["xp"] = xp
    progression["level"] = level_for_xp(xp)
    progression["unlocked_insights"] = list(dict.fromkeys(
        str(x) for x in (progression.get("unlocked_insights") or []) if str(x)
    ))
    progression.setdefault("specialization", None)
    progression.setdefault("mastery_path", None)
    progression.setdefault("end_path", None)
    progression["schema_version"] = CURRENT_SCHEMA_VERSION

    # BehaviorTrackerState.from_dict validates/coerces the persisted anti-farm history.
    tracker_state = BehaviorTrackerState.from_dict(tracker).to_dict()

    out = {
        "schema_version": CURRENT_SCHEMA_VERSION,
        "progression": progression,
        "tracker_state": tracker_state,
        "habit_state": HabitRuntimeState.from_dict(habits).to_dict(),
        "predictive_state": PredictiveRoutineState.from_dict(predictive).to_dict(),
    }
    return MigrationResult(out, old_version, CURRENT_SCHEMA_VERSION)


def load_runtime_payload(data: Mapping[str, Any]) -> tuple[PlayerProgressionState, BehaviorTrackerState, HabitRuntimeState, PredictiveRoutineState]:
    migrated = migrate_payload(data).payload
    return (
        PlayerProgressionState.from_dict(migrated["progression"]),
        BehaviorTrackerState.from_dict(migrated["tracker_state"]),
        HabitRuntimeState.from_dict(migrated.get("habit_state") or {}),
        PredictiveRoutineState.from_dict(migrated.get("predictive_state") or {}),
    )


def dump_runtime_payload(progression: PlayerProgressionState, tracker_state: BehaviorTrackerState, habit_state: HabitRuntimeState | None = None, predictive_state: PredictiveRoutineState | None = None) -> dict:
    return {
        "schema_version": CURRENT_SCHEMA_VERSION,
        "progression": {**progression.to_dict(), "schema_version": CURRENT_SCHEMA_VERSION},
        "tracker_state": tracker_state.to_dict(),
        "habit_state": (habit_state or HabitRuntimeState()).to_dict(),
        "predictive_state": (predictive_state or PredictiveRoutineState()).to_dict(),
    }
