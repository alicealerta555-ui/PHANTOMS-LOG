from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

from .gameplay_hooks import GameplayLearningBridge, ResolvedGameplayEvent
from .livehooks import LiveHookResult, PlayerDevelopmentCoordinator
from .npc_learning import (
    NPCActorSnapshot, NPCWitnessContext, NPCReaction,
    NPCObservationalLearningBridge,
)
from .pipeline import PlayerLearningRuntime
from .npc_naming import NPCNameGenerator, NPCNameRegistry, NameRequest, GeneratedNPCName
from .npc_encounter import (
    NPCFirstContactEngine, NPCVisualSnapshot, NPCEncounterContext,
    NPCPresentationProfile, NPCFirstContactResult,
)
from .npc_social import NPCSocialKnowledgeEngine, SocialSource, SocialUpdateResult
from .npc_item_interest import (
    NPCItemInterestEngine, ItemSnapshot, NPCEquipmentExpertise, ItemInterestContext, ItemInterestResult,
)
from .npc_lifelike import (
    NPCLivedExperienceEngine, NPCLifeSnapshot, SocialMomentContext, ConversationTopic, LifelikeSocialResult,
)
from .npc_psychology import NPCPsychologyEngine, PsychologicalSnapshot, SupportContext, SupportResult
from .npc_memory import NPCMemoryBudgetEngine, MemoryEvent
from .npc_social_life import NPCSocialLifeEngine, NPCSocialActor, SocialLifeContext, NPCToNPCResult


@dataclass
class AdaptiveResolutionResult:
    """One host-facing result for player development + NPC observation."""
    player: LiveHookResult
    npc_reactions: list[NPCReaction] = field(default_factory=list)


class AdaptiveGameplayRuntime:
    """Final host integration surface for adaptive character development.

    Separation guarantees:
    - PlayerLearningRuntime owns Player Insights/Habits/Instincts/Paths.
    - NPCObservationalLearningBridge owns only observational NPC routines.
    - NPC observation never writes into player progression and never grants NPC
      access to hidden Player Insight definitions.
    - Only committed, resolved player actions may feed either side.
    """

    def __init__(self, player_bridge: GameplayLearningBridge,
                 npc_bridge: Optional[NPCObservationalLearningBridge] = None,
                 npc_names: Optional[NPCNameGenerator] = None,
                 npc_first_contact: Optional[NPCFirstContactEngine] = None,
                 npc_social: Optional[NPCSocialKnowledgeEngine] = None,
                 npc_item_interest: Optional[NPCItemInterestEngine] = None,
                 npc_lived_experience: Optional[NPCLivedExperienceEngine] = None,
                 npc_psychology: Optional[NPCPsychologyEngine] = None,
                 npc_memory: Optional[NPCMemoryBudgetEngine] = None,
                 npc_social_life: Optional[NPCSocialLifeEngine] = None):
        self.player_bridge = player_bridge
        self.npc_bridge = npc_bridge or NPCObservationalLearningBridge()
        self.npc_names = npc_names
        self.npc_first_contact = npc_first_contact
        self.npc_social = npc_social
        self.npc_item_interest = npc_item_interest or NPCItemInterestEngine()
        self.npc_lived_experience = npc_lived_experience or NPCLivedExperienceEngine()
        self.npc_psychology = npc_psychology or NPCPsychologyEngine()
        self.npc_memory = npc_memory or NPCMemoryBudgetEngine()
        self.npc_social_life = npc_social_life or NPCSocialLifeEngine()

    @classmethod
    def new(cls, player_runtime: PlayerLearningRuntime) -> "AdaptiveGameplayRuntime":
        return cls(GameplayLearningBridge(PlayerDevelopmentCoordinator(player_runtime)))

    def after_resolution(self, event: ResolvedGameplayEvent,
                         npc_observers: Sequence[tuple[NPCActorSnapshot, NPCWitnessContext]] = ()) -> AdaptiveResolutionResult:
        # Player learning executes first from authoritative resolution. NPCs then
        # observe the same public/visible event supplied by the host.
        player_result = self.player_bridge.after_resolution(event)
        npc_reactions = self.npc_bridge.after_player_resolution(event, npc_observers)
        return AdaptiveResolutionResult(player=player_result, npc_reactions=npc_reactions)

    def before_player_decision(self, **kwargs) -> LiveHookResult:
        return self.player_bridge.before_decision(**kwargs)

    def discuss_npc_pattern(self, actor: NPCActorSnapshot, pattern_key: str) -> NPCReaction:
        return self.npc_bridge.engine.discuss(actor, pattern_key)

    def attach_npc_identity(self, name_generator: Optional[NPCNameGenerator] = None) -> None:
        self.npc_names = name_generator or NPCNameGenerator()
        self.npc_first_contact = NPCFirstContactEngine(self.npc_names)
        self.npc_social = NPCSocialKnowledgeEngine(self.npc_names, self.npc_first_contact.registry)

    def ensure_npc_name(self, request: NameRequest) -> GeneratedNPCName:
        if self.npc_names is None:
            self.attach_npc_identity()
        return self.npc_names.generate(request)

    def present_npc(self, visual: NPCVisualSnapshot, context: NPCEncounterContext,
                    profile: NPCPresentationProfile) -> NPCFirstContactResult:
        if self.npc_first_contact is None:
            if self.npc_names is None:
                raise RuntimeError("NPC identity layer is not attached; call ensure_npc_name() or attach_npc_identity() first")
            self.npc_first_contact = NPCFirstContactEngine(self.npc_names)
        self.npc_social = NPCSocialKnowledgeEngine(self.npc_names, self.npc_first_contact.registry)
        return self.npc_first_contact.first_contact(visual, context, profile)


    def recognize_npc(self, npc_id: str, context: str = "") -> SocialUpdateResult:
        if self.npc_social is None:
            if self.npc_names is None or self.npc_first_contact is None:
                raise RuntimeError("NPC identity layer is not attached")
            self.npc_social = NPCSocialKnowledgeEngine(self.npc_names, self.npc_first_contact.registry)
        return self.npc_social.recognize(npc_id, context)

    def npc_third_party_introduction(self, npc_id: str, introduced_name_level: str,
                                     source: SocialSource, profession: Optional[str] = None,
                                     affiliation: Optional[str] = None) -> SocialUpdateResult:
        if self.npc_social is None:
            if self.npc_names is None or self.npc_first_contact is None:
                raise RuntimeError("NPC identity layer is not attached")
            self.npc_social = NPCSocialKnowledgeEngine(self.npc_names, self.npc_first_contact.registry)
        return self.npc_social.third_party_introduction(npc_id, introduced_name_level, source, profession, affiliation)


    def evaluate_item_of_interest(self, item: ItemSnapshot, npc: NPCEquipmentExpertise,
                                  context: ItemInterestContext) -> ItemInterestResult:
        return self.npc_item_interest.evaluate(item, npc, context)

    def revisit_item_topic(self, item: ItemSnapshot, npc: NPCEquipmentExpertise,
                           context: ItemInterestContext) -> ItemInterestResult:
        return self.npc_item_interest.revisit_deferred(item, npc, context)

    def npc_social_moment(self, npc: NPCLifeSnapshot, context: SocialMomentContext,
                          topic: ConversationTopic) -> LifelikeSocialResult:
        return self.npc_lived_experience.evaluate(npc, context, topic)

    def revisit_npc_topic(self, npc: NPCLifeSnapshot, context: SocialMomentContext,
                          topic_key: str) -> LifelikeSocialResult:
        return self.npc_lived_experience.revisit(npc, context, topic_key)


    def support_npc(self, snapshot: PsychologicalSnapshot, context: SupportContext) -> SupportResult:
        return self.npc_psychology.support(snapshot, context)

    def record_npc_memory(self, event: MemoryEvent) -> str:
        return self.npc_memory.remember(event)

    def npc_to_npc_moment(self, a: NPCSocialActor, b: NPCSocialActor, context: SocialLifeContext) -> NPCToNPCResult:
        return self.npc_social_life.interact(a, b, context)

    def snapshot_for_save(self) -> dict:
        payload = {
            "schema_version": 6,
            "player_learning": self.player_bridge.coordinator.snapshot_for_save(),
            "npc_observational_learning": self.npc_bridge.snapshot_for_save(),
            "npc_item_interest": self.npc_item_interest.snapshot_for_save(),
            "npc_lived_experience": self.npc_lived_experience.snapshot_for_save(),
            "npc_psychology": self.npc_psychology.snapshot_for_save(),
            "npc_memory": self.npc_memory.snapshot_for_save(),
            "npc_social_life": self.npc_social_life.snapshot_for_save(),
        }
        if self.npc_names is not None:
            payload["npc_identity"] = {
                "naming_registry": self.npc_names.registry.to_dict(),
                "first_contact": self.npc_first_contact.snapshot_for_save() if self.npc_first_contact else {},
                "social_knowledge": self.npc_social.snapshot_for_save() if self.npc_social else {},
            }
        return payload

    @classmethod
    def from_save(cls, payload: dict) -> "AdaptiveGameplayRuntime":
        player_coord = PlayerDevelopmentCoordinator.from_save(payload["player_learning"])
        npc_bridge = NPCObservationalLearningBridge.from_save(payload.get("npc_observational_learning", {}))
        identity = payload.get("npc_identity")
        if not identity:
            return cls(
                GameplayLearningBridge(player_coord), npc_bridge,
                npc_item_interest=NPCItemInterestEngine.from_save(payload.get("npc_item_interest", {})),
                npc_lived_experience=NPCLivedExperienceEngine.from_save(payload.get("npc_lived_experience", {})),
                npc_psychology=NPCPsychologyEngine.from_save(payload.get("npc_psychology", {})),
                npc_memory=NPCMemoryBudgetEngine.from_save(payload.get("npc_memory", {})),
                npc_social_life=NPCSocialLifeEngine.from_save(payload.get("npc_social_life", {})),
            )
        names = NPCNameGenerator(registry=NPCNameRegistry.from_dict(identity.get("naming_registry", {})))
        contact = NPCFirstContactEngine.from_save(names, identity.get("first_contact", {}))
        social = NPCSocialKnowledgeEngine.from_save(names, contact.registry, identity.get("social_knowledge", {}))
        return cls(
            GameplayLearningBridge(player_coord), npc_bridge, names, contact, social,
            NPCItemInterestEngine.from_save(payload.get("npc_item_interest", {})),
            NPCLivedExperienceEngine.from_save(payload.get("npc_lived_experience", {})),
            NPCPsychologyEngine.from_save(payload.get("npc_psychology", {})),
            NPCMemoryBudgetEngine.from_save(payload.get("npc_memory", {})),
            NPCSocialLifeEngine.from_save(payload.get("npc_social_life", {})),
        )
