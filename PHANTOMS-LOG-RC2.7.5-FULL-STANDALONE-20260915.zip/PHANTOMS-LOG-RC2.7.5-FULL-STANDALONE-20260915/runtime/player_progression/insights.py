from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, Mapping, Optional, Sequence, Tuple

from .model import PlayerProgressionState


@dataclass(frozen=True)
class InsightDefinition:
    insight_id: str
    name: str
    family: str
    tier: str
    affinities: Mapping[str, float]
    action_families: Tuple[str, ...] = field(default_factory=tuple)
    required_tags_any: Tuple[str, ...] = field(default_factory=tuple)
    requires_insights: Tuple[str, ...] = field(default_factory=tuple)
    player_text: str = ""
    effect_key: str = ""
    hybrid: bool = False


@dataclass(frozen=True)
class InsightCandidate:
    insight_id: str
    readiness: float
    reason_keys: Tuple[str, ...]


# Hidden numeric thresholds. Never send these to presentation/UI.
_TIER_THRESHOLD = {
    "MICRO": 5.5,
    "TECHNIQUE": 12.0,
    "ADVANCED": 22.0,
    "SIGNATURE": 36.0,
}


def _d(i, n, f, t, a, acts=(), tags=(), req=(), text="", effect="", hybrid=False):
    return InsightDefinition(i, n, f, t, a, tuple(acts), tuple(tags), tuple(req), text, effect, hybrid)


# 64 single-affinity insights: four progressive observations for each hidden axis.
_BASE = [
    # FORCE
    _d("force_brace", "Brace", "AFF_FORCE", "MICRO", {"AFF_FORCE":1}, ("melee","breach","block"), text="Du setzt dein Gewicht inzwischen instinktiv gegen einen erwarteten Aufprall.", effect="brace"),
    _d("force_follow_through", "Follow Through", "AFF_FORCE", "TECHNIQUE", {"AFF_FORCE":1}, ("melee","heavy_attack"), req=("force_brace",), text="Du hörst nicht mehr am Treffpunkt auf. Deine Bewegung trägt den Angriff kontrolliert weiter.", effect="follow_through"),
    _d("force_shock_entry", "Shock Entry", "AFF_FORCE", "ADVANCED", {"AFF_FORCE":1,"AFF_MOBILITY":.25}, ("breach","charge"), req=("force_follow_through",), text="Du hast gelernt, den Moment des Eindringens selbst als Waffe zu benutzen.", effect="shock_entry"),
    _d("force_redline", "Redline", "AFF_FORCE", "SIGNATURE", {"AFF_FORCE":1,"AFF_ENDURANCE":.45}, ("melee","charge","heavy_attack"), req=("force_shock_entry",), text="Wenn du einmal Druck aufgebaut hast, fühlt sich jeder weitere Schritt natürlicher an als Rückzug.", effect="redline"),
    # ENDURANCE
    _d("end_second_wind", "Second Wind", "AFF_ENDURANCE", "MICRO", {"AFF_ENDURANCE":1}, ("survive","sprint","combat"), text="Dein Körper findet nach extremer Belastung schneller zurück in einen brauchbaren Rhythmus.", effect="second_wind"),
    _d("end_pain_focus", "Pain Focus", "AFF_ENDURANCE", "TECHNIQUE", {"AFF_ENDURANCE":1}, ("combat","survive"), req=("end_second_wind",), text="Schmerz ist noch da, aber er bestimmt nicht mehr automatisch deine nächste Entscheidung.", effect="pain_focus"),
    _d("end_last_reserve", "Last Reserve", "AFF_ENDURANCE", "ADVANCED", {"AFF_ENDURANCE":1,"AFF_ADAPTATION":.2}, ("survive","rescue"), req=("end_pain_focus",), text="Unter Belastung findest du Reserven, auf die du dich früher nicht verlassen konntest.", effect="last_reserve"),
    _d("end_unbroken", "Unbroken", "AFF_ENDURANCE", "SIGNATURE", {"AFF_ENDURANCE":1,"AFF_PROTECTION":.25}, ("survive","combat"), req=("end_last_reserve",), text="Du hast gelernt weiterzuarbeiten, wenn andere längst nur noch versuchen würden durchzuhalten.", effect="unbroken"),
    # PROTECTION
    _d("prot_cover_body", "Cover Body", "AFF_PROTECTION", "MICRO", {"AFF_PROTECTION":1}, ("protect","rescue","block"), text="Du stellst dich inzwischen automatisch zwischen Gefahr und diejenigen, die du schützen willst.", effect="cover_body"),
    _d("prot_intercept", "Intercept", "AFF_PROTECTION", "TECHNIQUE", {"AFF_PROTECTION":1,"AFF_MOBILITY":.15}, ("protect","rescue"), req=("prot_cover_body",), text="Du erkennst den Augenblick früher, in dem du eine Gefahr noch abfangen kannst.", effect="intercept"),
    _d("prot_hold_line", "Hold Line", "AFF_PROTECTION", "ADVANCED", {"AFF_PROTECTION":1,"AFF_ENDURANCE":.3}, ("protect","block"), req=("prot_intercept",), text="Du hältst Positionen nicht nur. Andere beginnen sich darauf zu verlassen, dass sie hinter dir bestehen bleiben.", effect="hold_line"),
    _d("prot_bastion_instinct", "Bastion Instinct", "AFF_PROTECTION", "SIGNATURE", {"AFF_PROTECTION":1,"AFF_COMMAND":.25}, ("protect","rescue","command"), req=("prot_hold_line",), text="Schutz ist kein einzelner Handgriff mehr. Er ist zu deinem Raumgefühl geworden.", effect="bastion_instinct"),
    # PRECISION
    _d("prec_breath", "Breath Control", "AFF_PRECISION", "MICRO", {"AFF_PRECISION":1}, ("aim","ranged_attack"), text="Du bemerkst, wann dein Atem einen Schuss stört und wann er ihn trägt.", effect="breath_control"),
    _d("prec_range_feel", "Range Feel", "AFF_PRECISION", "TECHNIQUE", {"AFF_PRECISION":1,"AFF_PERCEPTION":.2}, ("aim","ranged_attack"), req=("prec_breath",), text="Entfernungen fühlen sich weniger wie Schätzungen und mehr wie Erfahrung an.", effect="range_feel"),
    _d("prec_weakpoint", "Weakpoint Memory", "AFF_PRECISION", "ADVANCED", {"AFF_PRECISION":1,"AFF_PERCEPTION":.35}, ("aim","observe","ranged_attack"), req=("prec_range_feel",), text="Du merkst dir Schwachstellen, noch bevor du bewusst entscheidest, auf sie zu zielen.", effect="weakpoint_memory"),
    _d("prec_focus_lock", "Focus Lock", "AFF_PRECISION", "SIGNATURE", {"AFF_PRECISION":1,"AFF_PERCEPTION":.45}, ("aim","observe"), req=("prec_weakpoint",), text="Je länger du ein Ziel liest, desto weniger bleibt am entscheidenden Moment dem Zufall überlassen.", effect="focus_lock"),
    # AFF_STEALTH
    _d("stealth_soft_step", "Soft Step", "AFF_STEALTH", "MICRO", {"AFF_STEALTH":1}, ("sneak","move"), text="Du setzt deine Schritte dort, wo die Umgebung sie am ehesten verschluckt.", effect="soft_step"),
    _d("stealth_noise_mask", "Noise Masking", "AFF_STEALTH", "TECHNIQUE", {"AFF_STEALTH":1,"AFF_PERCEPTION":.2}, ("sneak","move"), tags=("noise",), req=("stealth_soft_step",), text="Du nutzt fremde Geräusche inzwischen bewusst als Deckung für die eigenen.", effect="noise_masking"),
    _d("stealth_lost_contact", "Lost Contact", "AFF_STEALTH", "ADVANCED", {"AFF_STEALTH":1,"AFF_MOBILITY":.25}, ("sneak","evade"), req=("stealth_noise_mask",), text="Wenn Sichtkontakt abreißt, verlässt du instinktiv die Route, die man von dir erwarten würde.", effect="lost_contact"),
    _d("stealth_vanish", "Vanish Window", "AFF_STEALTH", "SIGNATURE", {"AFF_STEALTH":1,"AFF_MOBILITY":.35}, ("sneak","evade"), req=("stealth_lost_contact",), text="Ein kurzer Moment ohne Augen auf dir reicht inzwischen, um aus einer Verfolgung ein Rätsel zu machen.", effect="vanish_window"),
    # AFF_MOBILITY
    _d("mob_balance", "Balance", "AFF_MOBILITY", "MICRO", {"AFF_MOBILITY":1}, ("move","climb","jump"), text="Unsichere Flächen kosten dich weniger Aufmerksamkeit als früher.", effect="balance"),
    _d("mob_fast_vault", "Fast Vault", "AFF_MOBILITY", "TECHNIQUE", {"AFF_MOBILITY":1}, ("vault","move"), req=("mob_balance",), text="Hindernisse sind immer seltener Unterbrechungen deiner Bewegung.", effect="fast_vault"),
    _d("mob_flow", "Flow", "AFF_MOBILITY", "ADVANCED", {"AFF_MOBILITY":1,"AFF_ADAPTATION":.2}, ("move","vault","climb","evade"), req=("mob_fast_vault",), text="Gelungene Bewegungen verbinden sich beinahe von selbst zur nächsten.", effect="flow"),
    _d("mob_combat_parkour", "Combat Parkour", "AFF_MOBILITY", "SIGNATURE", {"AFF_MOBILITY":1,"AFF_FORCE":.2,"AFF_PRECISION":.2}, ("move","vault","combat"), req=("mob_flow",), text="Kampf und Bewegung sind für dich keine getrennten Zustände mehr.", effect="combat_parkour"),
    # AFF_PERCEPTION
    _d("perc_audio_dir", "Audio Direction", "AFF_PERCEPTION", "MICRO", {"AFF_PERCEPTION":1}, ("observe","listen"), text="Geräusche bekommen Richtung, Entfernung und Bedeutung schneller als früher.", effect="audio_direction"),
    _d("perc_motion", "Motion Priority", "AFF_PERCEPTION", "TECHNIQUE", {"AFF_PERCEPTION":1}, ("observe","scan"), req=("perc_audio_dir",), text="Bewegung zieht deinen Blick an, ohne dass du aktiv danach suchen musst.", effect="motion_priority"),
    _d("perc_pattern", "Pattern Recognition", "AFF_PERCEPTION", "ADVANCED", {"AFF_PERCEPTION":1,"AFF_ADAPTATION":.25}, ("observe","track","scan"), req=("perc_motion",), text="Wiederkehrende Abläufe springen dir schneller ins Auge – gerade dann, wenn etwas davon abweicht.", effect="pattern_recognition"),
    _d("perc_threat_forecast", "Threat Forecast", "AFF_PERCEPTION", "SIGNATURE", {"AFF_PERCEPTION":1,"AFF_PRECISION":.2,"AFF_SURVIVAL":.2}, ("observe","combat","track"), req=("perc_pattern",), text="Manche Gefahren erkennst du inzwischen im Ablauf, bevor sie offen sichtbar werden.", effect="threat_forecast"),
    # AFF_TECH
    _d("tech_part_memory", "Part Memory", "AFF_TECH", "MICRO", {"AFF_TECH":1}, ("repair","salvage"), text="Bauteile, die du schon einmal in der Hand hattest, erkennst du schneller wieder.", effect="part_memory"),
    _d("tech_fault_sound", "Fault Sound", "AFF_TECH", "TECHNIQUE", {"AFF_TECH":1,"AFF_PERCEPTION":.15}, ("repair","inspect_machine"), req=("tech_part_memory",), text="Einige Defekte hörst du inzwischen, bevor du ein Gehäuse öffnest.", effect="fault_sound"),
    _d("tech_field_fab", "Field Fabrication", "AFF_TECH", "ADVANCED", {"AFF_TECH":1,"AFF_SURVIVAL":.2}, ("repair","craft","salvage"), req=("tech_fault_sound",), text="Aus brauchbaren Resten entstehen in deinem Kopf schon Lösungen, bevor du alle Teile sortiert hast.", effect="field_fabrication"),
    _d("tech_gear_whisper", "Gear Whisper", "AFF_TECH", "SIGNATURE", {"AFF_TECH":1,"AFF_MACHINE":.25}, ("repair","craft","inspect_machine"), req=("tech_field_fab",), text="Mechanik wirkt auf dich immer weniger wie ein Rätsel und immer mehr wie eine Sprache.", effect="gear_whisper"),
    # NETWORK
    _d("net_map", "Network Mapping", "AFF_NETWORK", "MICRO", {"AFF_NETWORK":1}, ("hack","scan_network"), text="Verbindungen und Abhängigkeiten eines Netzes ordnen sich für dich schneller.", effect="network_mapping"),
    _d("net_trace", "Trace Awareness", "AFF_NETWORK", "TECHNIQUE", {"AFF_NETWORK":1,"AFF_PERCEPTION":.1}, ("hack","scan_network"), req=("net_map",), text="Du bemerkst früher, wann ein Zugriff beginnt Spuren zu hinterlassen.", effect="trace_awareness"),
    _d("net_ghost_access", "Ghost Access", "AFF_NETWORK", "ADVANCED", {"AFF_NETWORK":1,"AFF_STEALTH":.25}, ("hack",), req=("net_trace",), text="Unauffälliger Zugriff ist für dich nicht mehr nur Glück, sondern eine eigene Disziplin.", effect="ghost_access"),
    _d("net_dead_signal", "Dead Signal", "AFF_NETWORK", "SIGNATURE", {"AFF_NETWORK":1,"AFF_STEALTH":.35}, ("hack","sabotage"), req=("net_ghost_access",), text="Du weißt inzwischen, wie ein System ausfallen muss, damit sein Schweigen natürlich wirkt.", effect="dead_signal"),
    # MACHINE
    _d("mach_remote", "Remote Familiarity", "AFF_MACHINE", "MICRO", {"AFF_MACHINE":1}, ("drone","remote_control"), text="Fernsteuerung verlangt dir weniger bewusste Aufmerksamkeit ab.", effect="remote_familiarity"),
    _d("mach_sensor_link", "Sensor Link", "AFF_MACHINE", "TECHNIQUE", {"AFF_MACHINE":1,"AFF_PERCEPTION":.15}, ("drone","scan"), req=("mach_remote",), text="Du liest fremde Sensorsichten inzwischen fast so schnell wie deine eigenen.", effect="sensor_link"),
    _d("mach_mesh", "Mesh", "AFF_MACHINE", "ADVANCED", {"AFF_MACHINE":1,"AFF_COMMAND":.2}, ("drone","remote_control","command"), req=("mach_sensor_link",), text="Mehrere Geräte fühlen sich nicht mehr wie einzelne Werkzeuge an, sondern wie ein gemeinsames System.", effect="mesh"),
    _d("mach_living_network", "Living Network", "AFF_MACHINE", "SIGNATURE", {"AFF_MACHINE":1,"AFF_NETWORK":.25,"AFF_COMMAND":.2}, ("drone","hack","command"), req=("mach_mesh",), text="Deine Systeme beginnen miteinander zu arbeiten, bevor du jeden Schritt einzeln anweisen musst.", effect="living_network"),
    # MEDICAL
    _d("med_bleeding", "Bleeding Recognition", "AFF_MEDICAL", "MICRO", {"AFF_MEDICAL":1}, ("heal","diagnose"), text="Du erkennst schneller, welche Blutung sofort zählt und welche noch warten kann.", effect="bleeding_recognition"),
    _d("med_trauma", "Trauma Control", "AFF_MEDICAL", "TECHNIQUE", {"AFF_MEDICAL":1}, ("heal","stabilize"), req=("med_bleeding",), text="Unter Druck konzentrierst du dich zuverlässiger auf das, was einen Menschen zuerst am Leben hält.", effect="trauma_control"),
    _d("med_adaptive", "Adaptive Treatment", "AFF_MEDICAL", "ADVANCED", {"AFF_MEDICAL":1,"AFF_ADAPTATION":.2}, ("heal","diagnose"), req=("med_trauma",), text="Du behandelst nicht mehr nur nach Schema. Körper, Implantate und Umstände fließen in dieselbe Entscheidung ein.", effect="adaptive_treatment"),
    _d("med_last_light", "Last Light", "AFF_MEDICAL", "SIGNATURE", {"AFF_MEDICAL":1,"AFF_PROTECTION":.25}, ("heal","rescue"), req=("med_adaptive",), text="In den schlimmsten Sekunden wird deine Ruhe für andere zu Zeit.", effect="last_light"),
    # SURVIVAL
    _d("surv_scav_eye", "Scavenger Eye", "AFF_SURVIVAL", "MICRO", {"AFF_SURVIVAL":1}, ("scavenge","explore"), text="Zwischen Schrott fällt dir Brauchbares schneller auf.", effect="scavenger_eye"),
    _d("surv_route", "Route Sense", "AFF_SURVIVAL", "TECHNIQUE", {"AFF_SURVIVAL":1,"AFF_PERCEPTION":.15}, ("explore","travel"), req=("surv_scav_eye",), text="Du merkst früher, welche Route nur kurz aussieht und welche tatsächlich sicher durchführt.", effect="route_sense"),
    _d("surv_hazard", "Hazard Recognition", "AFF_SURVIVAL", "ADVANCED", {"AFF_SURVIVAL":1,"AFF_PERCEPTION":.25}, ("explore","travel","observe"), req=("surv_route",), text="Umweltgefahren wirken auf dich zunehmend wie Spuren statt Überraschungen.", effect="hazard_recognition"),
    _d("surv_last_exit", "Last Exit", "AFF_SURVIVAL", "SIGNATURE", {"AFF_SURVIVAL":1,"AFF_ADAPTATION":.3}, ("escape","travel","explore"), req=("surv_hazard",), text="Wenn eine Lage kippt, siehst du oft noch einen Weg, bevor andere überhaupt akzeptieren, dass sie fliehen müssen.", effect="last_exit"),
    # AFF_RESONANCE
    _d("res_static", "Static", "AFF_RESONANCE", "MICRO", {"AFF_RESONANCE":1}, ("resonate","sense_anomaly"), text="Manche Orte fühlen sich falsch an, noch bevor du einen Grund dafür findest.", effect="static"),
    _d("res_grounding", "Grounding", "AFF_RESONANCE", "TECHNIQUE", {"AFF_RESONANCE":1,"AFF_ENDURANCE":.1}, ("resonate","resist"), req=("res_static",), text="Du hast Wege gefunden, dich nach fremden Eindrücken schneller wieder bei dir selbst zu verankern.", effect="grounding"),
    _d("res_redirect", "Redirect", "AFF_RESONANCE", "ADVANCED", {"AFF_RESONANCE":1,"AFF_ADAPTATION":.15}, ("resonate","energy_control"), req=("res_grounding",), text="Energie fühlt sich weniger wie etwas an, das nur auf dich trifft – und mehr wie etwas, dessen Weg sich beeinflussen lässt.", effect="redirect"),
    _d("res_cascade", "Resonance Cascade", "AFF_RESONANCE", "SIGNATURE", {"AFF_RESONANCE":1,"AFF_PERCEPTION":.2}, ("resonate","energy_control"), req=("res_redirect",), text="Du erkennst Verbindungen zwischen Resonanzen, die früher wie einzelne Ereignisse wirkten.", effect="resonance_cascade"),
    # SOCIAL
    _d("soc_read_room", "Read Room", "AFF_SOCIAL", "MICRO", {"AFF_SOCIAL":1}, ("talk","negotiate"), text="Du bemerkst schneller, wer tatsächlich spricht und wer nur darauf wartet, dass jemand anderes entscheidet.", effect="read_room"),
    _d("soc_calm_voice", "Calm Voice", "AFF_SOCIAL", "TECHNIQUE", {"AFF_SOCIAL":1,"AFF_PROTECTION":.1}, ("talk","deescalate"), req=("soc_read_room",), text="Du weißt besser, wann Ruhe ansteckender ist als Lautstärke.", effect="calm_voice"),
    _d("soc_pressure", "Pressure Point", "AFF_SOCIAL", "ADVANCED", {"AFF_SOCIAL":1,"AFF_PERCEPTION":.2}, ("negotiate","intimidate"), req=("soc_calm_voice",), text="Du erkennst häufiger, welche Sorge oder Hoffnung ein Gespräch wirklich steuert.", effect="pressure_point"),
    _d("soc_gravity", "Personal Gravity", "AFF_SOCIAL", "SIGNATURE", {"AFF_SOCIAL":1,"AFF_COMMAND":.25}, ("talk","negotiate","command"), req=("soc_pressure",), text="Menschen beginnen deine Haltung mitzudenken, noch bevor du sie ausdrücklich formulierst.", effect="personal_gravity"),
    # COMMAND
    _d("cmd_callout", "Clear Callout", "AFF_COMMAND", "MICRO", {"AFF_COMMAND":1}, ("command","protect"), text="Deine kurzen Anweisungen werden klarer und kommen in hektischen Momenten besser an.", effect="clear_callout"),
    _d("cmd_target_share", "Target Share", "AFF_COMMAND", "TECHNIQUE", {"AFF_COMMAND":1,"AFF_PERCEPTION":.15}, ("command","combat"), req=("cmd_callout",), text="Du teilst nicht mehr nur ein Ziel mit – du vermittelst, warum es jetzt zählt.", effect="target_share"),
    _d("cmd_battle_rhythm", "Battle Rhythm", "AFF_COMMAND", "ADVANCED", {"AFF_COMMAND":1,"AFF_ADAPTATION":.15}, ("command","combat","protect"), req=("cmd_target_share",), text="Du erkennst den Rhythmus einer Gruppe und gibst Anweisungen zunehmend dort, wo sie ihn verstärken statt unterbrechen.", effect="battle_rhythm"),
    _d("cmd_field_conductor", "Field Conductor", "AFF_COMMAND", "SIGNATURE", {"AFF_COMMAND":1,"AFF_MACHINE":.15,"AFF_SOCIAL":.15}, ("command",), req=("cmd_battle_rhythm",), text="Menschen und Systeme um dich herum beginnen sich unter Druck wie Teile derselben Handlung zu bewegen.", effect="field_conductor"),
    # ADAPTATION
    _d("adapt_improvise", "Improvised Solution", "AFF_ADAPTATION", "MICRO", {"AFF_ADAPTATION":1}, ("improvise","solve"), text="Unvollständige Werkzeuge fühlen sich seltener wie ein Ende und häufiger wie ein Anfang an.", effect="improvised_solution"),
    _d("adapt_failure_read", "Failure Read", "AFF_ADAPTATION", "TECHNIQUE", {"AFF_ADAPTATION":1}, ("solve","recover"), req=("adapt_improvise",), text="Fehlschläge hinterlassen dir inzwischen mehr Information als Frust.", effect="failure_read"),
    _d("adapt_context_switch", "Context Switch", "AFF_ADAPTATION", "ADVANCED", {"AFF_ADAPTATION":1,"AFF_PERCEPTION":.15}, ("solve","improvise","recover"), req=("adapt_failure_read",), text="Du wechselst Lösungswege schneller, wenn sich die Lage verändert.", effect="context_switch"),
    _d("adapt_wildcard", "Wildcard", "AFF_ADAPTATION", "SIGNATURE", {"AFF_ADAPTATION":1,"AFF_SURVIVAL":.15,"AFF_TECH":.15}, ("solve","improvise"), req=("adapt_context_switch",), text="Du hast aufgehört, ungewöhnliche Lösungen erst dann zu erwägen, wenn alle normalen versagt haben.", effect="wildcard"),
]

# 32 hybrid insights. These reward class-foreign play without requiring a class switch.
_HYBRID = [
    _d("hyb_field_armorer","Field Armorer","FORCE_TECH","TECHNIQUE",{"AFF_FORCE":.55,"AFF_TECH":.75},("repair","combat","armor"),text="Du behandelst Panzerung nicht mehr getrennt von deinem eigenen Bewegungsstil.",effect="field_armorer",hybrid=True),
    _d("hyb_hard_reset","Hard Reset","FORCE_NETWORK","TECHNIQUE",{"AFF_FORCE":.55,"AFF_NETWORK":.75},("hack","breach"),text="Du erkennst, wann ein System eher physisch als elegant überzeugt werden will.",effect="hard_reset",hybrid=True),
    _d("hyb_kinetic_execution","Kinetic Execution","FORCE_MOBILITY","ADVANCED",{"AFF_FORCE":.8,"AFF_MOBILITY":.8},("move","melee","charge"),text="Geschwindigkeit ist für dich nicht mehr der Weg zum Angriff. Sie ist ein Teil des Angriffs.",effect="kinetic_execution",hybrid=True),
    _d("hyb_guardian_drive","Guardian Drive","FORCE_PROTECTION","ADVANCED",{"AFF_FORCE":.75,"AFF_PROTECTION":.85},("protect","melee","rescue"),text="Du hast gelernt, offensiven Druck so einzusetzen, dass er Raum für andere schafft.",effect="guardian_drive",hybrid=True),
    _d("hyb_warsaint_seed","Warsaint Seed","FORCE_RESONANCE","ADVANCED",{"AFF_FORCE":.7,"AFF_RESONANCE":.85},("melee","resonate","protect"),text="Kraft und Resonanz antworten zunehmend im selben Moment aufeinander.",effect="warsaint_seed",hybrid=True),
    _d("hyb_predator_clock","Predator Clock","FORCE_PERCEPTION","TECHNIQUE",{"AFF_FORCE":.55,"AFF_PERCEPTION":.75},("observe","melee","track"),text="Du wartest nicht mehr auf eine Öffnung. Du merkst, wann sie entstehen wird.",effect="predator_clock",hybrid=True),
    _d("hyb_quiet_hands","Quiet Hands","STEALTH_MEDICAL","TECHNIQUE",{"AFF_STEALTH":.7,"AFF_MEDICAL":.7},("heal","sneak"),text="Du behandelst Verletzte, ohne dabei deine Aufmerksamkeit oder Ruhe an die Umgebung zu verlieren.",effect="quiet_hands",hybrid=True),
    _d("hyb_silent_repair","Silent Repair","STEALTH_TECH","TECHNIQUE",{"AFF_STEALTH":.65,"AFF_TECH":.75},("repair","sneak"),text="Werkzeuggeräusche sind für dich inzwischen genauso kontrollierbar wie Schritte.",effect="silent_repair",hybrid=True),
    _d("hyb_dead_circuit","Dead Circuit","STEALTH_NETWORK","ADVANCED",{"AFF_STEALTH":.8,"AFF_NETWORK":.85},("hack","sabotage","sneak"),text="Du weißt, wie elektronische Störungen aussehen müssen, damit niemand zuerst an Sabotage denkt.",effect="dead_circuit",hybrid=True),
    _d("hyb_ghost_drone","Ghost Drone","STEALTH_MACHINE","ADVANCED",{"AFF_STEALTH":.75,"AFF_MACHINE":.8},("drone","sneak","scan"),text="Deine Geräte lernen denselben Grundsatz wie du: gesehen werden ist oft schon der erste Fehler.",effect="ghost_drone",hybrid=True),
    _d("hyb_phase_seed","Phase Seed","STEALTH_RESONANCE","ADVANCED",{"AFF_STEALTH":.75,"AFF_RESONANCE":.85},("sneak","resonate","evade"),text="Du beginnst Resonanz nicht nur als Kraft, sondern als Möglichkeit zum Verschwinden zu begreifen.",effect="phase_seed",hybrid=True),
    _d("hyb_recon_specialist","Recon Specialist","STEALTH_PERCEPTION","ADVANCED",{"AFF_STEALTH":.7,"AFF_PERCEPTION":.85},("observe","sneak","scan"),text="Unsichtbar zu bleiben und alles zu sehen sind für dich zu einer gemeinsamen Aufgabe geworden.",effect="recon_specialist",hybrid=True),
    _d("hyb_field_tuning","Field Tuning","PRECISION_TECH","TECHNIQUE",{"AFF_PRECISION":.65,"AFF_TECH":.7},("repair","aim","weapon_mod"),text="Du stimmst Waffen nicht auf Tabellen ab, sondern auf die Art, wie du sie tatsächlich führst.",effect="field_tuning",hybrid=True),
    _d("hyb_sensor_shot","Sensor Shot","PRECISION_MACHINE","ADVANCED",{"AFF_PRECISION":.75,"AFF_MACHINE":.75},("aim","drone","scan"),text="Fremde Sensoren werden zunehmend zu einer Erweiterung deiner eigenen Zielwahrnehmung.",effect="sensor_shot",hybrid=True),
    _d("hyb_angel_drone","Angel Drone","MEDICAL_MACHINE","ADVANCED",{"AFF_MEDICAL":.8,"AFF_MACHINE":.8},("heal","drone","rescue"),text="Deine Drohnen suchen Gefahr nicht mehr nur. Sie suchen diejenigen, die darin verschwinden könnten.",effect="angel_drone",hybrid=True),
    _d("hyb_bioshaper_seed","Bioshaper Seed","MEDICAL_RESONANCE","ADVANCED",{"AFF_MEDICAL":.8,"AFF_RESONANCE":.8},("heal","resonate","diagnose"),text="Biologie und Resonanz beginnen für dich dieselben Fragen mit unterschiedlichen Worten zu stellen.",effect="bioshaper_seed",hybrid=True),
    _d("hyb_combat_medic","Combat Medic","MEDICAL_FORCE","TECHNIQUE",{"AFF_MEDICAL":.7,"AFF_FORCE":.6},("heal","combat","rescue"),text="Du behandelst nicht mehr nach dem Gefecht. Du behandelst mitten in seinem Rhythmus.",effect="combat_medic",hybrid=True),
    _d("hyb_signal_empathy","Signal Empathy","NETWORK_RESONANCE","ADVANCED",{"AFF_NETWORK":.8,"AFF_RESONANCE":.8},("hack","resonate","scan_network"),text="Manche Systemzustände bemerkst du inzwischen, bevor du sie technisch sauber erklären kannst.",effect="signal_empathy",hybrid=True),
    _d("hyb_machine_communion","Machine Communion","MACHINE_RESONANCE","SIGNATURE",{"AFF_MACHINE":1.0,"AFF_RESONANCE":1.0},("drone","resonate","repair"),req=("hyb_signal_empathy",),text="Maschinen wirken nicht lebendig. Aber ihr Zustand ist für dich auch nicht mehr stumm.",effect="machine_communion",hybrid=True),
    _d("hyb_ironhand_seed","Ironhand Seed","FORCE_MACHINE","ADVANCED",{"AFF_FORCE":.75,"AFF_MACHINE":.75},("combat","drone","heavy_attack"),text="Schwere Technik beginnt sich deinem Angriffstempo unterzuordnen statt es auszubremsen.",effect="ironhand_seed",hybrid=True),
    _d("hyb_survival_engineer","Survival Engineer","SURVIVAL_TECH","TECHNIQUE",{"AFF_SURVIVAL":.7,"AFF_TECH":.7},("craft","repair","scavenge"),text="Du baust nicht für Eleganz. Du baust dafür, dass es draußen weitergeht.",effect="survival_engineer",hybrid=True),
    _d("hyb_ruin_whisper","Ruin Whisper","SURVIVAL_PERCEPTION","ADVANCED",{"AFF_SURVIVAL":.75,"AFF_PERCEPTION":.8},("explore","observe","scavenge"),text="Ruinen erzählen dir zunehmend, wo Menschen gingen, wo etwas brach und wo noch Gefahr wartet.",effect="ruin_whisper",hybrid=True),
    _d("hyb_field_leader","Field Leader","COMMAND_PROTECTION","ADVANCED",{"AFF_COMMAND":.8,"AFF_PROTECTION":.8},("command","protect","rescue"),text="Deine Anweisungen beginnen dort, wo Schutz nicht mehr allein mit deinem eigenen Körper möglich ist.",effect="field_leader",hybrid=True),
    _d("hyb_pack_hunter","Pack Hunter","COMMAND_PERCEPTION","ADVANCED",{"AFF_COMMAND":.7,"AFF_PERCEPTION":.8},("command","track","observe"),text="Du liest nicht nur das Ziel, sondern auch, wie deine Gruppe sich am besten darum schließt.",effect="pack_hunter",hybrid=True),
    _d("hyb_social_engineer","Social Engineer","SOCIAL_NETWORK","TECHNIQUE",{"AFF_SOCIAL":.7,"AFF_NETWORK":.7},("talk","hack","negotiate"),text="Menschen und Systeme haben unterschiedliche Passwörter, aber oft denselben Fehler: Vertrauen.",effect="social_engineer",hybrid=True),
    _d("hyb_command_mesh","Command Mesh","COMMAND_MACHINE","ADVANCED",{"AFF_COMMAND":.8,"AFF_MACHINE":.8},("command","drone","remote_control"),text="Du verteilst Aufmerksamkeit zwischen Menschen und Maschinen, ohne beide getrennt führen zu müssen.",effect="command_mesh",hybrid=True),
    _d("hyb_resonant_guard","Resonant Guard","PROTECTION_RESONANCE","ADVANCED",{"AFF_PROTECTION":.8,"AFF_RESONANCE":.8},("protect","resonate"),text="Dein Schutzinstinkt beginnt Resonanz genauso selbstverständlich einzubeziehen wie Deckung und Körperposition.",effect="resonant_guard",hybrid=True),
    _d("hyb_signal_warden","Signal Warden","PROTECTION_NETWORK","ADVANCED",{"AFF_PROTECTION":.7,"AFF_NETWORK":.8},("protect","hack","scan_network"),text="Du verteidigst nicht mehr nur Räume und Menschen, sondern auch ihre Verbindungen.",effect="signal_warden",hybrid=True),
    _d("hyb_adaptive_shooter","Adaptive Shooter","PRECISION_ADAPTATION","ADVANCED",{"AFF_PRECISION":.75,"AFF_ADAPTATION":.75},("aim","ranged_attack","improvise"),text="Du hältst nicht an einem perfekten Schuss fest, wenn die Lage längst einen anderen verlangt.",effect="adaptive_shooter",hybrid=True),
    _d("hyb_impossible_route","Impossible Route","MOBILITY_ADAPTATION","ADVANCED",{"AFF_MOBILITY":.8,"AFF_ADAPTATION":.8},("move","climb","escape","improvise"),text="Wo andere zwischen Wegen wählen, beginnst du manchmal einen neuen zu sehen.",effect="impossible_route",hybrid=True),
    _d("hyb_cold_reader","Cold Reader","SOCIAL_PERCEPTION","ADVANCED",{"AFF_SOCIAL":.8,"AFF_PERCEPTION":.8},("talk","observe","negotiate"),text="Kleine Reaktionen verraten dir immer öfter, welche Worte wirklich getroffen haben.",effect="cold_reader",hybrid=True),
    _d("hyb_wild_medic","Wild Medic","MEDICAL_ADAPTATION","ADVANCED",{"AFF_MEDICAL":.75,"AFF_ADAPTATION":.8},("heal","improvise","survive"),text="Wenn Material fehlt, hörst du nicht auf zu behandeln. Du denkst anders weiter.",effect="wild_medic",hybrid=True),
]

INSIGHTS: Dict[str, InsightDefinition] = {d.insight_id: d for d in (_BASE + _HYBRID)}


class InsightResolver:
    """Deterministic hidden readiness evaluator.

    No random unlocks. A candidate becomes ready from accumulated meaningful
    behavior, then waits for a fitting trigger action. Numeric readiness is never
    exposed through the player-facing projection.
    """

    def __init__(self, catalog: Mapping[str, InsightDefinition] = INSIGHTS):
        self.catalog = dict(catalog)

    def _affinity_readiness(self, state: PlayerProgressionState, d: InsightDefinition, threshold: float) -> float:
        # Every listed affinity is a real gate. Action repetition may support an
        # insight, but can never compensate for a missing side of a hybrid build.
        vals = []
        for key, weight in d.affinities.items():
            required = threshold * max(.35, float(weight))
            vals.append(state.affinities.get(key, 0.0) / required)
        return min(vals) if vals else 0.0

    def _action_evidence(self, state: PlayerProgressionState, d: InsightDefinition) -> float:
        if not d.action_families:
            return 0.0
        return sum(state.pattern_evidence.get(k, 0.0) for k in d.action_families)

    def candidate(self, state: PlayerProgressionState, insight_id: str) -> Optional[InsightCandidate]:
        if insight_id in state.unlocked_insights:
            return None
        d = self.catalog[insight_id]
        if any(req not in state.unlocked_insights for req in d.requires_insights):
            return None
        threshold = _TIER_THRESHOLD[d.tier]
        affinity_ratio = self._affinity_readiness(state, d, threshold)
        action_ratio = self._action_evidence(state, d) / threshold
        # Contextual experience accelerates recognition only up to the weakest
        # required affinity. This preserves true cross-class development.
        supported_action_ratio = min(action_ratio, affinity_ratio)
        readiness = min(1.25, affinity_ratio * .78 + supported_action_ratio * .22)
        reasons = tuple(sorted(d.affinities.keys()))
        return InsightCandidate(insight_id, readiness, reasons)

    def ready_for_event(self, state: PlayerProgressionState, action_family: str, tags: Sequence[str] = ()) -> list[InsightCandidate]:
        tagset = set(tags)
        ready: list[InsightCandidate] = []
        for d in self.catalog.values():
            c = self.candidate(state, d.insight_id)
            if c is None or c.readiness < 1.0:
                continue
            if d.action_families and action_family not in d.action_families:
                continue
            if d.required_tags_any and not (tagset & set(d.required_tags_any)):
                continue
            ready.append(c)
        # One fitting moment should not produce a shower of insights.
        ready.sort(key=lambda c: (-c.readiness, self._tier_rank(self.catalog[c.insight_id].tier), c.insight_id))
        return ready

    @staticmethod
    def _tier_rank(tier: str) -> int:
        return {"SIGNATURE":0,"ADVANCED":1,"TECHNIQUE":2,"MICRO":3}.get(tier, 9)

    def unlock_best(self, state: PlayerProgressionState, action_family: str, tags: Sequence[str] = ()) -> Optional[InsightDefinition]:
        ready = self.ready_for_event(state, action_family, tags)
        if not ready:
            return None
        d = self.catalog[ready[0].insight_id]
        state.unlocked_insights.append(d.insight_id)
        return d

    def player_visible_unlock(self, d: InsightDefinition) -> dict:
        return {
            "kind": "ERKENNTNIS",
            "name": d.name,
            "description": d.player_text,
            "effect_key": d.effect_key,
        }
