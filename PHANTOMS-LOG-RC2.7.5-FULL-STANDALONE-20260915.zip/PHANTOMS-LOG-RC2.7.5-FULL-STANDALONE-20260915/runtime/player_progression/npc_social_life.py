from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Dict, Tuple, Optional

@dataclass(frozen=True)
class NPCSocialActor:
    npc_id: str
    sociability: float = .5
    patience: float = .5
    trust_tendency: float = .5
    conflict_tolerance: float = .5
    gossip_tendency: float = .3
    privacy: float = .5
    interests: Tuple[str,...] = ()
    dislikes: Tuple[str,...] = ()

@dataclass
class RelationshipEdge:
    a: str
    b: str
    trust: float = 0.0
    respect: float = 0.0
    affection: float = 0.0
    resentment: float = 0.0
    familiarity: float = 0.0
    last_turn: int = 0
    shared_summary: str = ""

@dataclass
class NPCSocialWorldState:
    relationships: Dict[str, RelationshipEdge] = field(default_factory=dict)
    group_rituals: Dict[str, str] = field(default_factory=dict)
    rumors: Dict[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class SocialLifeContext:
    turn: int
    safe: bool = True
    time_pressure: float = 0.0
    privacy: float = .5
    shared_tags: Tuple[str,...] = ()
    world_event: str = ""

@dataclass(frozen=True)
class NPCToNPCResult:
    action: str
    visible_cue: str = ""
    line_hint: str = ""
    relationship_changed: bool = False

class NPCSocialLifeEngine:
    """Sparse NPC-to-NPC social life.

    Relationships exist only after meaningful contact. Background NPCs do not get
    all-to-all edges. Offscreen life can be summarized rather than replayed turn by turn.
    """
    def __init__(self,state:Optional[NPCSocialWorldState]=None): self.state=state or NPCSocialWorldState()
    @staticmethod
    def _key(a:str,b:str)->str: return "|".join(sorted((a,b)))
    def edge(self,a:str,b:str,create:bool=False)->Optional[RelationshipEdge]:
        k=self._key(a,b)
        if k not in self.state.relationships and create: self.state.relationships[k]=RelationshipEdge(a,b)
        return self.state.relationships.get(k)
    def interact(self,a:NPCSocialActor,b:NPCSocialActor,ctx:SocialLifeContext)->NPCToNPCResult:
        common=set(a.interests)&set(b.interests); friction=(set(a.dislikes)&set(b.interests))|(set(b.dislikes)&set(a.interests))
        if not ctx.safe or ctx.time_pressure>=.8:
            return NPCToNPCResult("TASK_FOCUSED","Beide bleiben bei der unmittelbaren Aufgabe.","")
        e=self.edge(a.npc_id,b.npc_id,create=True); e.last_turn=ctx.turn
        old=(e.trust,e.respect,e.affection,e.resentment,e.familiarity)
        e.familiarity=min(1.0,e.familiarity+.04)
        if common:
            e.respect=min(1.0,e.respect+.03); e.affection=min(1.0,e.affection+.02)
            cue="Die beiden finden sichtbar einen gemeinsamen Bezugspunkt."
            line="Darüber wollte ich dich sowieso noch etwas fragen."
            action="BOND"
        elif friction:
            e.resentment=min(1.0,e.resentment+.04); cue="Zwischen den beiden entsteht merkliche Reibung."
            line="Da werden wir uns nicht einig."; action="FRICTION"
        else:
            cue="Die Begegnung bleibt beiläufig."; line=""; action="CASUAL"
        new=(e.trust,e.respect,e.affection,e.resentment,e.familiarity)
        return NPCToNPCResult(action,cue,line,new!=old)
    def share_rumor(self,source:NPCSocialActor,target:NPCSocialActor,rumor_key:str,rumor_text:str,ctx:SocialLifeContext)->NPCToNPCResult:
        e=self.edge(source.npc_id,target.npc_id,create=False)
        familiarity=e.familiarity if e else 0.0
        chance=source.gossip_tendency*.45+familiarity*.25+(1-source.privacy)*.15
        if ctx.time_pressure>.6 or chance<.25:
            return NPCToNPCResult("NO_RUMOR","","")
        self.state.rumors[f"{target.npc_id}:{rumor_key}"]=rumor_text
        return NPCToNPCResult("RUMOR_SHARED","Das Gespräch wird leiser und persönlicher.","Ich hab da etwas gehört …")
    def set_group_ritual(self,group_id:str,description:str)->None: self.state.group_rituals[group_id]=description
    def offscreen_summary(self,a:str,b:str,elapsed:int)->str:
        e=self.edge(a,b,create=False)
        if not e: return "no_meaningful_contact"
        if elapsed<=0: return "no_time_passed"
        if e.resentment>.5: return "tension_persisted"
        if e.affection>.45 or e.respect>.5: return "relationship_held"
        return "routine_contact"
    def snapshot_for_save(self)->dict:
        return {"relationships":{k:asdict(v) for k,v in self.state.relationships.items()},"group_rituals":dict(self.state.group_rituals),"rumors":dict(self.state.rumors)}
    @classmethod
    def from_save(cls,p:dict)->"NPCSocialLifeEngine":
        st=NPCSocialWorldState({k:RelationshipEdge(**v) for k,v in p.get("relationships",{}).items()},dict(p.get("group_rituals",{})),dict(p.get("rumors",{})))
        return cls(st)
