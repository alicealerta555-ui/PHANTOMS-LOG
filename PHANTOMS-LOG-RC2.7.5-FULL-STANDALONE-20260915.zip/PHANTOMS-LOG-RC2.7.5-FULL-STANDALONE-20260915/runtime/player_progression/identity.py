from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Dict, Mapping, Optional, Sequence

from .habits import HabitRuntimeState, HABIT_BY_ID
from .model import AFFINITIES, PlayerProgressionState

# Habit evidence is deliberately weak compared with lived action affinity.
# It may break close ties, but must never overpower the actual play history.
HABIT_AFFINITY_HINTS: Mapping[str, tuple[str, ...]] = {
    "cover_entry": ("AFF_PROTECTION", "AFF_PERCEPTION"),
    "motion_check": ("AFF_PERCEPTION",),
    "quiet_entry": ("AFF_STEALTH", "AFF_MOBILITY"),
    "exit_memory": ("AFF_PERCEPTION", "AFF_SURVIVAL"),
    "field_check": ("AFF_TECH", "AFF_SURVIVAL"),
    "ammo_check": ("AFF_PRECISION", "AFF_SURVIVAL"),
    "reload_cover": ("AFF_PROTECTION", "AFF_PRECISION"),
    "wounded_scan": ("AFF_MEDICAL", "AFF_PROTECTION"),
    "drone_first": ("AFF_MACHINE", "AFF_PERCEPTION"),
    "salvage_scan": ("AFF_TECH", "AFF_SURVIVAL"),
    "lock_after_rest": ("AFF_SURVIVAL", "AFF_PROTECTION"),
    "light_discipline": ("AFF_STEALTH", "AFF_PERCEPTION"),
    "overcautious_entry": ("AFF_PERCEPTION", "AFF_PROTECTION"),
    "tunnel_target": ("AFF_PRECISION", "AFF_FORCE"),
    "ammo_hungry": ("AFF_FORCE",),
    "loot_compulsion": ("AFF_SURVIVAL", "AFF_ADAPTATION"),
    "pain_ignore": ("AFF_ENDURANCE", "AFF_FORCE"),
    "do_it_self": ("AFF_ADAPTATION", "AFF_TECH"),
    "early_exit": ("AFF_SURVIVAL", "AFF_MOBILITY"),
    "risk_appetite": ("AFF_ADAPTATION", "AFF_FORCE"),
    "distrustful_check": ("AFF_PERCEPTION", "AFF_SOCIAL"),
    "deescalate_first": ("AFF_SOCIAL", "AFF_PROTECTION"),
    "command_spacing": ("AFF_COMMAND", "AFF_PROTECTION"),
    "repair_before_replace": ("AFF_TECH", "AFF_ADAPTATION"),
}

_STAGE_WEIGHT = {
    "forming": 0.0,
    "habit": 0.35,
    "instinct": 0.65,
    "fading": 0.15,
}


@dataclass(frozen=True)
class IdentitySignal:
    affinity_hints: Dict[str, float]
    helpful_habits: tuple[str, ...]
    double_edged_habits: tuple[str, ...]


class HabitIdentityBridge:
    """Translate learned habits into *weak* biography evidence.

    This bridge never unlocks a skill directly and never returns player-visible
    numeric values. It is only for internal path tie-breaking and identity flavor.
    """

    def signal(self, habit_state: HabitRuntimeState) -> IdentitySignal:
        hints = {k: 0.0 for k in AFFINITIES}
        helpful: list[str] = []
        double_edged: list[str] = []
        for habit_id, rec in habit_state.habits.items():
            d = HABIT_BY_ID.get(habit_id)
            if d is None:
                continue
            w = _STAGE_WEIGHT.get(rec.stage, 0.0)
            if w <= 0.0:
                continue
            # Cap each habit's influence. Habit strength never becomes a path score itself.
            w *= min(1.0, max(0.0, rec.strength))
            for affinity in HABIT_AFFINITY_HINTS.get(habit_id, ()):
                hints[affinity] += w
            if rec.stage in {"habit", "instinct"}:
                if d.tone == "double_edged":
                    double_edged.append(habit_id)
                else:
                    helpful.append(habit_id)
        # Global cap keeps the habit layer subordinate to actual action history.
        for key in hints:
            hints[key] = min(1.5, hints[key])
        return IdentitySignal(hints, tuple(sorted(helpful)), tuple(sorted(double_edged)))

    def projected_state(self, state: PlayerProgressionState, habit_state: HabitRuntimeState) -> PlayerProgressionState:
        projected = deepcopy(state)
        signal = self.signal(habit_state)
        for key, bonus in signal.affinity_hints.items():
            projected.affinities[key] = float(projected.affinities.get(key, 0.0)) + bonus
        return projected

    def qualitative_identity_note(self, habit_state: HabitRuntimeState) -> Optional[str]:
        signal = self.signal(habit_state)
        active_count = len(signal.helpful_habits) + len(signal.double_edged_habits)
        if active_count == 0:
            return None
        if signal.double_edged_habits and signal.helpful_habits:
            return "Deine Routinen tragen inzwischen eine eigene Handschrift – nützlich, aber nicht ohne Macken."
        if signal.double_edged_habits:
            return "Einige deiner Routinen sitzen tief. Sie helfen dir oft, können dich aber auch festlegen."
        return "Viele deiner Entscheidungen wirken inzwischen weniger wie Planung und mehr wie ein persönlicher Rhythmus."
