from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from .behavior import BehaviorTracker, BehaviorTrackerState, RawActionEvent
from .engine import HiddenAffinityEngine
from .model import PlayerProgressionState
from .insights import InsightResolver
from .presentation import DevelopmentPresenter, assert_player_payload_clean
from .persistence import dump_runtime_payload, load_runtime_payload
from .habits import DecisionEvent, HabitEngine, HabitRuntimeState, HABIT_BY_ID
from .identity import HabitIdentityBridge
from .paths import PathResolver
from .predictive import PredictiveRoutineEngine, PredictiveRoutineState, RoutineContext
from .levels import level_for_xp


@dataclass
class PlayerLearningRuntime:
    """RC2.x integration seam for hidden player-only development."""

    progression: PlayerProgressionState
    tracker_state: BehaviorTrackerState = field(default_factory=BehaviorTrackerState)
    tracker: BehaviorTracker = field(default_factory=BehaviorTracker)
    affinity_engine: HiddenAffinityEngine = field(default_factory=HiddenAffinityEngine)
    insight_resolver: InsightResolver = field(default_factory=InsightResolver)
    presenter: DevelopmentPresenter = field(default_factory=DevelopmentPresenter)
    pending_unlocks: list[dict] = field(default_factory=list)
    habit_state: HabitRuntimeState = field(default_factory=HabitRuntimeState)
    habit_engine: HabitEngine = field(default_factory=HabitEngine)
    pending_habit_messages: list[dict] = field(default_factory=list)
    identity_bridge: HabitIdentityBridge = field(default_factory=HabitIdentityBridge)
    path_resolver: PathResolver = field(default_factory=PathResolver)
    predictive_state: PredictiveRoutineState = field(default_factory=PredictiveRoutineState)
    predictive_engine: PredictiveRoutineEngine = field(default_factory=PredictiveRoutineEngine)

    def observe(self, event: RawActionEvent) -> bool:
        weighted = self.tracker.record(self.tracker_state, event)
        if weighted is None:
            return False
        before_evidence = sum(float(v or 0.0) for v in self.progression.pattern_evidence.values())
        self.affinity_engine.apply(self.progression, weighted)
        after_evidence = sum(float(v or 0.0) for v in self.progression.pattern_evidence.values())
        gained_xp = max(0.0, after_evidence - before_evidence)
        self.progression.xp += gained_xp
        self.progression.level = level_for_xp(self.progression.xp)
        unlocked = self.insight_resolver.unlock_best(self.progression, weighted.action_family, weighted.tags)
        if unlocked is not None:
            visible = self.presenter.insight_unlock(unlocked)
            assert_player_payload_clean(visible)
            self.pending_unlocks.append(visible)
        return True

    def observe_many(self, events: Iterable[RawActionEvent]) -> int:
        count = 0
        for event in events:
            count += int(self.observe(event))
        return count

    def drain_unlocks(self) -> list[dict]:
        out = list(self.pending_unlocks)
        self.pending_unlocks.clear()
        return out

    def visible_development(self) -> dict:
        payload = self.presenter.development_snapshot(self.progression)
        assert_player_payload_clean(payload)
        return payload

    def visible_growth_hint(self):
        payload = self.presenter.soft_growth_hint(self.progression)
        if payload is not None:
            assert_player_payload_clean(payload)
        return payload


    def observe_decision(self, event: DecisionEvent) -> list[dict]:
        transitions = self.habit_engine.observe(self.habit_state, event)
        if event.actor_is_player:
            self.predictive_engine.observe_choice(self.predictive_state, event.situation_family, event.choice_key, event.context_tags)
        visible = []
        for t in transitions:
            d = HABIT_BY_ID.get(t.habit_id)
            if d is None:
                continue
            payload = self.presenter.habit_transition(d, t.transition)
            assert_player_payload_clean(payload)
            self.pending_habit_messages.append(payload)
            visible.append(payload)
        return visible

    def drain_habit_messages(self) -> list[dict]:
        out = list(self.pending_habit_messages)
        self.pending_habit_messages.clear()
        return out

    def visible_habits(self) -> dict:
        payload = self.presenter.habit_snapshot(self.habit_engine.active_records(self.habit_state))
        assert_player_payload_clean(payload)
        return payload

    def suggest_instinct_action(self, situation_family: str, context_tags=()):
        auto = self.habit_engine.automation_for(self.habit_state, situation_family, context_tags)
        if auto is None:
            return None
        payload = self.presenter.instinct_action(auto.choice_key, auto.narrative_hint)
        assert_player_payload_clean(payload)
        return payload


    def predict_routine(self, situation_family: str, context_tags=(), *, reversible: bool = True,
                        player_has_explicit_order: bool = False, high_stakes: bool = False):
        prediction = self.predictive_engine.predict(
            self.predictive_state, self.habit_state,
            RoutineContext(
                situation_family=situation_family,
                context_tags=tuple(context_tags),
                reversible=reversible,
                player_has_explicit_order=player_has_explicit_order,
                high_stakes=high_stakes,
            ),
        )
        if prediction is None:
            return None
        if prediction.mode == "auto":
            payload = self.presenter.instinct_action(prediction.choice_key, prediction.narrative_hint)
            payload["kind"] = "instinct_routine"
        else:
            payload = {
                "kind": "routine_prepared",
                "text": prediction.narrative_hint,
                "choice": prediction.choice_key,
            }
        assert_player_payload_clean(payload)
        return payload

    def confirm_predicted_routine(self) -> None:
        self.predictive_engine.accept(self.predictive_state)

    def override_predicted_routine(self, habit_id: str | None = None) -> bool:
        self.predictive_engine.override(self.predictive_state)
        if habit_id is None:
            return True
        return self.habit_engine.override(self.habit_state, habit_id)

    def override_instinct(self, habit_id: str) -> bool:
        return self.habit_engine.override(self.habit_state, habit_id)

    def request_habit_retraining(self, habit_id: str, replacement_choice: str | None = None) -> dict | None:
        if not self.habit_engine.request_retraining(self.habit_state, habit_id, replacement_choice):
            return None
        definition = HABIT_BY_ID.get(habit_id)
        if definition is None:
            return None
        payload = {
            'kind': 'habit_retraining_started',
            'name': definition.name,
            'text': 'Du willst dieses Muster verändern. Der alte Reflex verschwindet nicht sofort; erst wiederholtes bewusstes Gegenverhalten wird ihn nach und nach umformen.'
        }
        assert_player_payload_clean(payload)
        return payload


    def level10_specialization_candidates(self, limit: int = 2) -> list[dict]:
        projected = self.identity_bridge.projected_state(self.progression, self.habit_state)
        defs = self.path_resolver.level10_candidates(projected, limit=limit)
        payload = self.path_resolver.visible_specialization_choice(defs)
        assert_player_payload_clean(payload)
        return payload

    def choose_specialization(self, spec_id: str) -> dict:
        projected = self.identity_bridge.projected_state(self.progression, self.habit_state)
        # validate with projected biography, commit to canonical state only after validation
        allowed = {d.spec_id for d in self.path_resolver.level10_candidates(projected, limit=2)}
        if spec_id not in allowed:
            raise ValueError('specialization is not supported by current character development')
        d = self.path_resolver.choose_specialization(self.progression, spec_id)
        payload = {'kind':'specialization_committed','name':d.name,'description':d.description}
        assert_player_payload_clean(payload)
        return payload

    def resolve_mastery_path(self) -> dict | None:
        projected = self.identity_bridge.projected_state(self.progression, self.habit_state)
        d = self.path_resolver.resolve_mastery(projected)
        if d is None:
            return None
        payload = self.path_resolver.visible_mastery(d)
        assert_player_payload_clean(payload)
        return payload

    def commit_mastery_path(self) -> dict:
        projected = self.identity_bridge.projected_state(self.progression, self.habit_state)
        d = self.path_resolver.resolve_mastery(projected)
        if d is None:
            raise ValueError('mastery path is not available yet')
        # Commit the resolved path id to canonical state; do not leak projected values.
        self.progression.mastery_path = d.path_id
        payload = self.path_resolver.visible_mastery(d)
        assert_player_payload_clean(payload)
        return payload

    def end_path_candidates(self, limit: int = 3) -> list[dict]:
        projected = self.identity_bridge.projected_state(self.progression, self.habit_state)
        defs = self.path_resolver.end_path_candidates(projected, limit=limit)
        payload = [self.path_resolver.visible_end_path(d) for d in defs]
        assert_player_payload_clean(payload)
        return payload

    def commit_end_path(self, path_id: str | None = None) -> dict:
        projected = self.identity_bridge.projected_state(self.progression, self.habit_state)
        candidates = self.path_resolver.end_path_candidates(projected, limit=3)
        if self.progression.level < 50 or not self.progression.mastery_path:
            raise ValueError('end path is not available yet')
        if self.progression.end_path:
            d = next(x for x in candidates if x.path_id == self.progression.end_path) if any(x.path_id == self.progression.end_path for x in candidates) else self.path_resolver.commit_end_path(self.progression)
        else:
            if path_id is None:
                d = candidates[0]
            else:
                allowed = {x.path_id for x in candidates}
                if path_id not in allowed:
                    raise ValueError('end path is not supported by current character development')
                d = next(x for x in candidates if x.path_id == path_id)
            self.progression.end_path = d.path_id
        payload = self.path_resolver.visible_end_path(d)
        assert_player_payload_clean(payload)
        return payload

    def visible_identity_note(self):
        text = self.identity_bridge.qualitative_identity_note(self.habit_state)
        if text is None:
            return None
        payload = {'kind':'identity_note','text':text}
        assert_player_payload_clean(payload)
        return payload

    def to_dict(self) -> dict:
        return dump_runtime_payload(self.progression, self.tracker_state, self.habit_state, self.predictive_state)

    @classmethod
    def from_dict(cls, data: dict) -> "PlayerLearningRuntime":
        progression, tracker_state, habit_state, predictive_state = load_runtime_payload(data)
        return cls(progression=progression, tracker_state=tracker_state, habit_state=habit_state, predictive_state=predictive_state)
