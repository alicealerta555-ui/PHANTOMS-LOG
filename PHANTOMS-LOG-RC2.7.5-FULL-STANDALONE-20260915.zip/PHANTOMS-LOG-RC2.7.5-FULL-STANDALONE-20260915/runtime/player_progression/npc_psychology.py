from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Dict, Tuple, Optional

@dataclass(frozen=True)
class PsychologicalSnapshot:
    npc_id: str
    stress: float = 0.0
    fear: float = 0.0
    anxiety: float = 0.0
    exhaustion: float = 0.0
    grief: float = 0.0
    anger_pressure: float = 0.0
    shame_guilt: float = 0.0
    safety: float = 0.5
    trust: float = 0.0
    openness: float = 0.5
    resilience: float = 0.5
    trigger_tags: Tuple[str, ...] = ()
    avoidance_tags: Tuple[str, ...] = ()
    coping_styles: Tuple[str, ...] = ()

@dataclass(frozen=True)
class SupportContext:
    turn: int
    safe: bool = True
    privacy: float = 0.5
    time_pressure: float = 0.0
    danger: float = 0.0
    player_respects_boundary: bool = True
    player_listens: bool = False
    player_reassures: bool = False
    player_offers_choice: bool = False
    player_forces_exposure: bool = False
    player_follows_up: bool = False
    context_tags: Tuple[str, ...] = ()

@dataclass
class RecoveryTheme:
    key: str
    burden: float = 0.5
    safety_memory: float = 0.0
    avoidance: float = 0.0
    supportive_moments: int = 0
    harmful_moments: int = 0
    last_turn: int = 0

@dataclass
class NPCPsychologyState:
    npc_id: str
    themes: Dict[str, RecoveryTheme] = field(default_factory=dict)
    felt_heard: int = 0
    boundaries_respected: int = 0
    positive_exposures: int = 0
    harmful_pressure: int = 0

    def to_dict(self) -> dict:
        return {"npc_id": self.npc_id, "themes": {k: asdict(v) for k,v in self.themes.items()},
                "felt_heard": self.felt_heard, "boundaries_respected": self.boundaries_respected,
                "positive_exposures": self.positive_exposures, "harmful_pressure": self.harmful_pressure}
    @classmethod
    def from_dict(cls, d: dict) -> "NPCPsychologyState":
        obj = cls(d.get("npc_id", ""))
        obj.themes = {k: RecoveryTheme(**v) for k,v in d.get("themes", {}).items()}
        obj.felt_heard = int(d.get("felt_heard",0)); obj.boundaries_respected=int(d.get("boundaries_respected",0))
        obj.positive_exposures=int(d.get("positive_exposures",0)); obj.harmful_pressure=int(d.get("harmful_pressure",0))
        return obj

@dataclass(frozen=True)
class SupportResult:
    npc_id: str
    action: str
    visible_change: str = ""
    progress_hint: str = ""
    theme: Optional[str] = None

class NPCPsychologyEngine:
    """Compact state/behavior layer, not a diagnosis engine.

    Short, ordinary supportive interactions can accumulate recovery progress. No
    single line cures trauma; repeated safety, respected boundaries and positive
    experiences matter. Triggers raise probability/pressure but never force one
    scripted reaction.
    """
    def __init__(self, states: Optional[Dict[str,NPCPsychologyState]]=None):
        self.states = states or {}
    def state_for(self, npc_id: str) -> NPCPsychologyState:
        return self.states.setdefault(npc_id, NPCPsychologyState(npc_id))
    def _theme(self, st: NPCPsychologyState, tag: str, snapshot: PsychologicalSnapshot, turn: int) -> RecoveryTheme:
        if tag not in st.themes:
            st.themes[tag] = RecoveryTheme(tag, burden=max(.25, min(1.0, .35 + .35*snapshot.fear + .2*snapshot.anxiety)),
                                            avoidance=.45 if tag in snapshot.avoidance_tags else .15, last_turn=turn)
        return st.themes[tag]
    def support(self, snapshot: PsychologicalSnapshot, ctx: SupportContext) -> SupportResult:
        st = self.state_for(snapshot.npc_id)
        trigger = next((t for t in ctx.context_tags if t in snapshot.trigger_tags or t in snapshot.avoidance_tags), None)
        theme = self._theme(st, trigger, snapshot, ctx.turn) if trigger else None
        if ctx.danger >= .7 or ctx.time_pressure >= .85:
            return SupportResult(snapshot.npc_id, "STABILIZE_ONLY", "Die Reaktion bleibt knapp und auf das Jetzt gerichtet.", "Sicherheit vor Gespräch.", trigger)
        if ctx.player_forces_exposure:
            st.harmful_pressure += 1
            if theme:
                theme.harmful_moments += 1; theme.burden=min(1.0, theme.burden+.08); theme.avoidance=min(1.0, theme.avoidance+.08); theme.last_turn=ctx.turn
            return SupportResult(snapshot.npc_id, "PRESSURED", "Der NPC zieht sich merklich zurück.", "Druck erschwert Vertrauen.", trigger)
        gain = 0.0
        if ctx.player_listens:
            st.felt_heard += 1; gain += .08
        if ctx.player_respects_boundary:
            st.boundaries_respected += 1; gain += .06
        if ctx.player_reassures and ctx.safe:
            gain += .05
        if ctx.player_offers_choice:
            gain += .06
        if ctx.player_follows_up:
            gain += .05
        gain *= (.65 + .35*snapshot.trust)
        if theme and gain > 0:
            theme.supportive_moments += 1; theme.safety_memory=min(1.0, theme.safety_memory+gain)
            theme.burden=max(.05, theme.burden-gain*.45); theme.avoidance=max(.0, theme.avoidance-gain*.25); theme.last_turn=ctx.turn
        if gain >= .12:
            return SupportResult(snapshot.npc_id, "SUPPORTED", "Die Anspannung lässt ein wenig nach.", "Mehr Sicherheit und Vertrauen.", trigger)
        if gain > 0:
            return SupportResult(snapshot.npc_id, "SMALL_SUPPORT", "Die Haltung wird für einen Moment weniger verschlossen.", "Kleine positive Erfahrung.", trigger)
        return SupportResult(snapshot.npc_id, "NO_CHANGE", "", "Keine relevante Unterstützung.", trigger)
    def positive_exposure(self, snapshot: PsychologicalSnapshot, tag: str, turn: int, voluntary: bool=True, supported: bool=True) -> SupportResult:
        st=self.state_for(snapshot.npc_id); theme=self._theme(st, tag, snapshot, turn)
        if not voluntary:
            theme.harmful_moments += 1; theme.burden=min(1.0, theme.burden+.05)
            return SupportResult(snapshot.npc_id,"PRESSURED_EXPOSURE","Die Situation verstärkt die Abwehr.","Erzwungene Konfrontation zählt nicht als Fortschritt.",tag)
        delta=.09 + (.05 if supported else 0)
        st.positive_exposures += 1; theme.safety_memory=min(1.0, theme.safety_memory+delta)
        theme.avoidance=max(0.0, theme.avoidance-delta*.5); theme.burden=max(.05, theme.burden-delta*.35); theme.last_turn=turn
        return SupportResult(snapshot.npc_id,"POSITIVE_EXPOSURE","Der NPC bleibt in der Situation und findet wieder Kontrolle.","Vermeidung kann langsam sinken.",tag)
    def snapshot_for_save(self) -> dict:
        return {"states": {k:v.to_dict() for k,v in self.states.items()}}
    @classmethod
    def from_save(cls, payload: dict) -> "NPCPsychologyEngine":
        return cls({k:NPCPsychologyState.from_dict(v) for k,v in payload.get("states",{}).items()})
