from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Dict, Optional, Sequence, Tuple


class SocialAction(str, Enum):
    ENGAGE = "ENGAGE"
    BRIEF = "BRIEF"
    DEFER = "DEFER"
    DECLINE = "DECLINE"
    INITIATE = "INITIATE"
    SILENT = "SILENT"


@dataclass(frozen=True)
class NPCLifeSnapshot:
    """Host supplied, observable/current life state.

    This is not a second Actor brain. It is a compact social-presence projection of
    authoritative Actor state. The host remains authority for true needs, tasks,
    relationships and schedule.
    """
    npc_id: str
    trust: float = 0.0
    familiarity: float = 0.0
    sociability: float = 0.5
    patience: float = 0.5
    curiosity: float = 0.5
    openness: float = 0.5
    privacy_preference: float = 0.5
    fatigue: float = 0.0
    hunger: float = 0.0
    pain: float = 0.0
    stress: float = 0.0
    social_energy: float = 0.7
    task_pressure: float = 0.0
    active_task: str = ""
    current_mood: str = "neutral"
    interests: Tuple[str, ...] = ()
    dislikes: Tuple[str, ...] = ()
    relationship_tags: Tuple[str, ...] = ()


@dataclass(frozen=True)
class SocialMomentContext:
    turn: int
    safe: bool = True
    danger: float = 0.0
    time_pressure: float = 0.0
    privacy: float = 0.5
    player_busy: bool = False
    npc_busy: bool = False
    interruption_cost: float = 0.0
    conversation_open: bool = False
    explicit_player_question: bool = False
    player_needs_help: bool = False
    reunion_after_absence: bool = False
    public_setting: bool = False


@dataclass(frozen=True)
class ConversationTopic:
    key: str
    label: str
    tags: Tuple[str, ...] = ()
    urgency: float = 0.0
    intimacy: float = 0.0
    practical_value: float = 0.0
    npc_personal_relevance: float = 0.0
    player_relevance: float = 0.0
    requires_privacy: bool = False
    can_wait: bool = True
    # Request-boundary model. These are host-supplied facts about the request,
    # not personality guesses. NPCs protect themselves and their obligations
    # before ordinary friendliness/engagement is considered.
    physical_risk: float = 0.0
    legal_risk: float = 0.0
    professional_risk: float = 0.0
    economic_risk: float = 0.0
    security_sensitive: bool = False
    role_appropriate: bool = True
    requires_authorization: bool = False
    authorization_present: bool = False
    persuasion_leverage: float = 0.0


@dataclass
class DeferredTopic:
    key: str
    label: str
    first_turn: int
    last_turn: int
    reason: str
    tags: Tuple[str, ...] = ()
    times_deferred: int = 1


@dataclass
class NPCContinuityState:
    npc_id: str
    deferred_topics: Dict[str, DeferredTopic] = field(default_factory=dict)
    recent_topics: Dict[str, int] = field(default_factory=dict)
    pending_promises: Dict[str, str] = field(default_factory=dict)
    remembered_player_details: Dict[str, str] = field(default_factory=dict)
    last_interaction_turn: int = 0
    interaction_count: int = 0
    last_social_action: str = ""

    def to_dict(self) -> dict:
        return {
            "npc_id": self.npc_id,
            "deferred_topics": {k: asdict(v) for k, v in self.deferred_topics.items()},
            "recent_topics": dict(self.recent_topics),
            "pending_promises": dict(self.pending_promises),
            "remembered_player_details": dict(self.remembered_player_details),
            "last_interaction_turn": self.last_interaction_turn,
            "interaction_count": self.interaction_count,
            "last_social_action": self.last_social_action,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "NPCContinuityState":
        obj = cls(npc_id=data.get("npc_id", ""))
        obj.deferred_topics = {
            k: DeferredTopic(**v) for k, v in data.get("deferred_topics", {}).items()
        }
        obj.recent_topics = {str(k): int(v) for k, v in data.get("recent_topics", {}).items()}
        obj.pending_promises = {str(k): str(v) for k, v in data.get("pending_promises", {}).items()}
        obj.remembered_player_details = {
            str(k): str(v) for k, v in data.get("remembered_player_details", {}).items()
        }
        obj.last_interaction_turn = int(data.get("last_interaction_turn", 0))
        obj.interaction_count = int(data.get("interaction_count", 0))
        obj.last_social_action = str(data.get("last_social_action", ""))
        return obj


@dataclass(frozen=True)
class LifelikeSocialResult:
    npc_id: str
    action: SocialAction
    visible_cues: Tuple[str, ...] = ()
    line_hint: str = ""
    reason: str = ""
    deferred_topic: Optional[str] = None
    resumes_task: bool = False
    recalls_previous: bool = False


class NPCLivedExperienceEngine:
    """Adds continuity and human-scale social friction to NPC interactions.

    Design goals:
    - NPCs do not exist only for the player.
    - Ongoing tasks, fatigue, pain and social energy affect availability.
    - Interest is shown through observable behavior before exposition.
    - Important topics can be deferred and revisited later.
    - Repetition is damped; NPCs do not spam the same comment.
    - Trust/familiarity unlock depth, not omniscience.
    - No hidden world facts are inferred here.
    """

    def __init__(self, states: Optional[Dict[str, NPCContinuityState]] = None):
        self.states: Dict[str, NPCContinuityState] = states or {}

    def state_for(self, npc_id: str) -> NPCContinuityState:
        if npc_id not in self.states:
            self.states[npc_id] = NPCContinuityState(npc_id=npc_id)
        return self.states[npc_id]

    @staticmethod
    def _interest(snapshot: NPCLifeSnapshot, topic: ConversationTopic) -> float:
        tags = set(topic.tags)
        affinity = 0.0
        if tags.intersection(snapshot.interests):
            affinity += 0.35
        if tags.intersection(snapshot.dislikes):
            affinity -= 0.25
        affinity += 0.20 * topic.npc_personal_relevance
        affinity += 0.12 * snapshot.curiosity
        return max(-0.5, min(1.0, affinity))

    @staticmethod
    def _burden(snapshot: NPCLifeSnapshot, context: SocialMomentContext) -> float:
        bodily = max(snapshot.fatigue, snapshot.hunger * .65, snapshot.pain, snapshot.stress)
        task = max(snapshot.task_pressure, context.time_pressure, context.interruption_cost)
        danger = max(context.danger, 0.65 if not context.safe else 0.0)
        busy = 0.25 if context.npc_busy else 0.0
        return min(1.0, 0.42 * bodily + 0.38 * task + 0.45 * danger + busy)

    @staticmethod
    def _depth(snapshot: NPCLifeSnapshot, topic: ConversationTopic, context: SocialMomentContext) -> float:
        relation = 0.55 * snapshot.trust + 0.35 * snapshot.familiarity + 0.10 * snapshot.openness
        privacy_ok = 1.0 if not topic.requires_privacy else context.privacy
        intimacy_gate = relation * privacy_ok
        if topic.intimacy > intimacy_gate + .15:
            return -1.0
        return relation

    def evaluate(self, snapshot: NPCLifeSnapshot, context: SocialMomentContext,
                 topic: ConversationTopic) -> LifelikeSocialResult:
        st = self.state_for(snapshot.npc_id)
        burden = self._burden(snapshot, context)
        interest = self._interest(snapshot, topic)
        depth = self._depth(snapshot, topic, context)
        recent_turn = st.recent_topics.get(topic.key)
        repeated = recent_turn is not None and context.turn - recent_turn <= 6

        cues = []
        if snapshot.active_task:
            cues.append(f"Der NPC bleibt nebenbei bei seiner Aufgabe: {snapshot.active_task}.")
        if snapshot.fatigue >= .65:
            cues.append("Die Müdigkeit ist in Haltung und Reaktion deutlich zu sehen.")
        if snapshot.pain >= .55:
            cues.append("Eine Bewegung wird kurz geschont, bevor die Aufmerksamkeit zurückkehrt.")
        if snapshot.stress >= .65:
            cues.append("Die Antwort kommt angespannter und knapper als sonst.")
        if interest >= .35:
            cues.append("Die Aufmerksamkeit bleibt einen Moment länger an dem Thema hängen.")
        if context.reunion_after_absence and snapshot.familiarity >= .45:
            cues.append("Das Wiedersehen wird sichtbar registriert, nicht wie eine erste Begegnung behandelt.")

        # Self-protection and institutional boundaries come before friendliness.
        # A polite NPC may still refuse a request that risks injury, employment,
        # legal exposure, money, or protected systems. Persuasion can influence
        # borderline cases but does not silently erase hard authorization rules.
        request_risk = max(
            topic.physical_risk, topic.legal_risk, topic.professional_risk,
            topic.economic_risk,
        )
        if topic.requires_authorization and not topic.authorization_present:
            return self._finish(
                st, context, topic, SocialAction.DECLINE, cues,
                "Nein. Dafür brauchst du eine gültige Autorisierung.",
                "authorization_required", resumes_task=bool(snapshot.active_task),
            )
        if topic.security_sensitive and not topic.authorization_present:
            return self._finish(
                st, context, topic, SocialAction.DECLINE, cues,
                "Nein. Das ist ein interner oder sicherheitsrelevanter Bereich.",
                "security_boundary", resumes_task=bool(snapshot.active_task),
            )
        if not topic.role_appropriate and request_risk >= .25:
            effective_risk = max(0.0, request_risk - .20 * topic.persuasion_leverage)
            if effective_risk >= .25:
                return self._finish(
                    st, context, topic, SocialAction.DECLINE, cues,
                    "Nein. Das fällt nicht in meinen Zuständigkeitsbereich.",
                    "role_and_self_protection_boundary",
                    resumes_task=bool(snapshot.active_task),
                )
        effective_risk = max(0.0, request_risk - .25 * topic.persuasion_leverage)
        if effective_risk >= .65:
            return self._finish(
                st, context, topic, SocialAction.DECLINE, cues,
                "Nein. Das Risiko gehe ich nicht ein.",
                "self_protection_boundary", resumes_task=bool(snapshot.active_task),
            )

        # Hard situational gates: life continues even when player wants to talk.
        if context.danger >= .7 or context.time_pressure >= .85:
            if topic.urgency >= .85 or context.player_needs_help:
                action = SocialAction.BRIEF
                line = "Kurz. Was ist jetzt wichtig?"
                reason = "acute_context_but_urgent_topic"
            elif topic.can_wait:
                self.defer(snapshot.npc_id, topic, context.turn, "danger_or_time_pressure")
                action = SocialAction.DEFER
                line = "Nicht jetzt. Später."
                reason = "danger_or_time_pressure"
            else:
                action = SocialAction.DECLINE
                line = "Dafür ist gerade keine Zeit."
                reason = "unsafe_context"
            return self._finish(st, context, topic, action, cues, line, reason,
                                deferred=(topic.key if action == SocialAction.DEFER else None),
                                resumes_task=bool(snapshot.active_task))

        if topic.requires_privacy and context.privacy < .45 and topic.intimacy >= .35:
            if topic.can_wait:
                self.defer(snapshot.npc_id, topic, context.turn, "needs_privacy")
                return self._finish(st, context, topic, SocialAction.DEFER, cues,
                                    "Nicht hier.", "needs_privacy", topic.key,
                                    resumes_task=bool(snapshot.active_task))
            return self._finish(st, context, topic, SocialAction.DECLINE, cues,
                                "Darüber rede ich hier nicht.", "privacy_boundary",
                                resumes_task=bool(snapshot.active_task))

        if depth < 0:
            return self._finish(st, context, topic, SocialAction.DECLINE, cues,
                                "Das ist mir zu persönlich.", "relationship_boundary",
                                resumes_task=bool(snapshot.active_task))

        # Explicit player questions deserve an answer where plausible, but not a lecture.
        if context.explicit_player_question:
            if burden >= .70 and topic.can_wait and topic.urgency < .70:
                self.defer(snapshot.npc_id, topic, context.turn, "too_busy_or_drained")
                return self._finish(st, context, topic, SocialAction.DEFER, cues,
                                    "Ich sag dir später was dazu.", "too_busy_or_drained",
                                    topic.key, resumes_task=True)
            action = SocialAction.BRIEF if burden >= .52 or snapshot.social_energy < .30 else SocialAction.ENGAGE
            line = "Ich hab dazu einen Gedanken." if action == SocialAction.ENGAGE else "Kurz gesagt …"
            return self._finish(st, context, topic, action, cues, line,
                                "explicit_question", resumes_task=bool(snapshot.active_task))

        # Unsolicited social initiative requires real interest and a suitable moment.
        initiative = (
            .30 * snapshot.sociability + .25 * snapshot.curiosity + .20 * snapshot.social_energy
            + .20 * max(0.0, interest) + .10 * snapshot.familiarity - .45 * burden
        )
        if repeated:
            initiative -= .38
        if context.player_busy:
            initiative -= .25
        if not context.conversation_open:
            initiative -= .08

        if initiative >= .58 and interest >= .22:
            action = SocialAction.INITIATE
            line = "Da wollte ich dich noch etwas zu fragen." if topic.key not in st.deferred_topics else "Wegen vorhin …"
            recalled = topic.key in st.deferred_topics
            st.deferred_topics.pop(topic.key, None)
            return self._finish(st, context, topic, action, cues, line,
                                "npc_initiative", resumes_task=bool(snapshot.active_task),
                                recalls_previous=recalled)

        if burden >= .58 and topic.can_wait and interest >= .20:
            self.defer(snapshot.npc_id, topic, context.turn, "interested_but_bad_moment")
            return self._finish(st, context, topic, SocialAction.DEFER, cues,
                                "Der NPC wirkt interessiert, greift das Thema aber nicht auf.",
                                "interested_but_bad_moment", topic.key,
                                resumes_task=bool(snapshot.active_task))

        # Interest may be visible without forcing dialogue.
        if interest >= .28:
            return self._finish(st, context, topic, SocialAction.SILENT, cues,
                                "", "visible_interest_without_interruption",
                                resumes_task=bool(snapshot.active_task))

        return self._finish(st, context, topic, SocialAction.SILENT, cues,
                            "", "no_social_trigger", resumes_task=bool(snapshot.active_task))

    def defer(self, npc_id: str, topic: ConversationTopic, turn: int, reason: str) -> None:
        st = self.state_for(npc_id)
        old = st.deferred_topics.get(topic.key)
        if old:
            old.last_turn = turn
            old.reason = reason
            old.times_deferred += 1
        else:
            st.deferred_topics[topic.key] = DeferredTopic(
                key=topic.key, label=topic.label, first_turn=turn, last_turn=turn,
                reason=reason, tags=topic.tags,
            )

    def revisit(self, snapshot: NPCLifeSnapshot, context: SocialMomentContext,
                topic_key: str) -> LifelikeSocialResult:
        st = self.state_for(snapshot.npc_id)
        d = st.deferred_topics.get(topic_key)
        if d is None:
            return LifelikeSocialResult(snapshot.npc_id, SocialAction.SILENT, reason="no_deferred_topic")
        topic = ConversationTopic(
            key=d.key, label=d.label, tags=d.tags, npc_personal_relevance=.55,
            player_relevance=.55, can_wait=True,
        )
        return self.evaluate(snapshot, SocialMomentContext(
            turn=context.turn, safe=context.safe, danger=context.danger,
            time_pressure=context.time_pressure, privacy=context.privacy,
            player_busy=context.player_busy, npc_busy=context.npc_busy,
            interruption_cost=context.interruption_cost,
            conversation_open=True, explicit_player_question=False,
            player_needs_help=context.player_needs_help,
            reunion_after_absence=context.reunion_after_absence,
            public_setting=context.public_setting,
        ), topic)

    def remember_player_detail(self, npc_id: str, key: str, value: str) -> None:
        self.state_for(npc_id).remembered_player_details[key] = value

    def add_promise(self, npc_id: str, key: str, description: str) -> None:
        self.state_for(npc_id).pending_promises[key] = description

    def resolve_promise(self, npc_id: str, key: str) -> None:
        self.state_for(npc_id).pending_promises.pop(key, None)

    def _finish(self, st: NPCContinuityState, context: SocialMomentContext,
                topic: ConversationTopic, action: SocialAction, cues: Sequence[str],
                line: str, reason: str, deferred: Optional[str] = None,
                resumes_task: bool = False, recalls_previous: bool = False) -> LifelikeSocialResult:
        st.last_interaction_turn = context.turn
        st.interaction_count += 1
        st.last_social_action = action.value
        if action in {SocialAction.ENGAGE, SocialAction.BRIEF, SocialAction.INITIATE}:
            st.recent_topics[topic.key] = context.turn
        return LifelikeSocialResult(
            npc_id=st.npc_id, action=action, visible_cues=tuple(cues), line_hint=line,
            reason=reason, deferred_topic=deferred, resumes_task=resumes_task,
            recalls_previous=recalls_previous,
        )

    def snapshot_for_save(self) -> dict:
        return {
            "schema_version": 1,
            "states": {npc_id: state.to_dict() for npc_id, state in self.states.items()},
        }

    @classmethod
    def from_save(cls, payload: dict) -> "NPCLivedExperienceEngine":
        return cls({
            npc_id: NPCContinuityState.from_dict(data)
            for npc_id, data in payload.get("states", {}).items()
        })
