from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional

START_CLASSES = ('BREAKER','GHOST','OPERATOR','RESONANT')
AFFINITIES = (
    'AFF_FORCE','AFF_ENDURANCE','AFF_PROTECTION','AFF_PRECISION','AFF_STEALTH','AFF_MOBILITY',
    'AFF_PERCEPTION','AFF_TECH','AFF_NETWORK','AFF_MACHINE','AFF_MEDICAL','AFF_SURVIVAL',
    'AFF_RESONANCE','AFF_SOCIAL','AFF_COMMAND','AFF_ADAPTATION'
)

@dataclass
class PlayerProgressionState:
    player_uuid: str
    run_uuid: str
    start_class: str
    level: int = 1
    xp: float = 0.0
    affinities: Dict[str, float] = field(default_factory=lambda: {k: 0.0 for k in AFFINITIES})
    pattern_evidence: Dict[str, float] = field(default_factory=dict)
    unlocked_insights: List[str] = field(default_factory=list)
    specialization: Optional[str] = None
    mastery_path: Optional[str] = None
    end_path: Optional[str] = None
    schema_version: int = 10

    def __post_init__(self):
        if self.start_class not in START_CLASSES:
            raise ValueError(f'unknown start_class: {self.start_class}')
        # fail closed: normalize missing known affinity keys, ignore no hidden state.
        for key in AFFINITIES:
            self.affinities.setdefault(key, 0.0)
        self.level = max(1, int(self.level or 1))
        self.xp = max(0.0, float(self.xp or 0.0))

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data):
        return cls(**data)
