from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass, field
from typing import Deque, Mapping, Optional, Sequence

from .habits import (
    FORBIDDEN_AUTOMATION_CATEGORIES,
    SAFE_AUTOMATION_CATEGORIES,
    HABIT_BY_ID,
    HabitRuntimeState,
)


@dataclass(frozen=True)
class RoutineContext:
    """Context offered to the predictive routine layer.

    The host should use coarse, non-spoiler tags only. Hidden world facts must never be
    placed in this object merely to improve prediction.
    """

    situation_family: str
    context_tags: tuple[str, ...] = ()
    reversible: bool = True
    player_has_explicit_order: bool = False
    high_stakes: bool = False


@dataclass(frozen=True)
class PredictedRoutine:
    choice_key: str
    habit_id: str
    confidence_band: str  # internal qualitative band only
    mode: str  # auto | prepare
    narrative_hint: str


@dataclass
class PredictiveRoutineState:
    """Run-local prediction memory.

    All scores are internal. Player-facing presentation receives only narrative output.
    """

    situation_choice_counts: Counter = field(default_factory=Counter)
    context_choice_counts: Counter = field(default_factory=Counter)
    recent_predictions: Deque[str] = field(default_factory=lambda: deque(maxlen=48))
    accepted_predictions: int = 0
    overridden_predictions: int = 0
    prepared_only: int = 0

    def to_dict(self) -> dict:
        return {
            "situation_choice_counts": dict(self.situation_choice_counts),
            "context_choice_counts": dict(self.context_choice_counts),
            "recent_predictions": list(self.recent_predictions),
            "accepted_predictions": self.accepted_predictions,
            "overridden_predictions": self.overridden_predictions,
            "prepared_only": self.prepared_only,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, object] | None) -> "PredictiveRoutineState":
        data = data or {}
        s = cls()
        s.situation_choice_counts.update(data.get("situation_choice_counts", {}) or {})
        s.context_choice_counts.update(data.get("context_choice_counts", {}) or {})
        s.recent_predictions.extend(data.get("recent_predictions", []) or [])
        s.accepted_predictions = max(0, int(data.get("accepted_predictions", 0) or 0))
        s.overridden_predictions = max(0, int(data.get("overridden_predictions", 0) or 0))
        s.prepared_only = max(0, int(data.get("prepared_only", 0) or 0))
        return s


class PredictiveRoutineEngine:
    """Conservative, player-subordinate anticipation of trained micro-routines.

    Rules:
    - an active instinct is required for *automatic* execution;
    - high stakes, irreversible contexts, explicit orders and forbidden categories block auto;
    - strong habit evidence without an instinct may produce `prepare`, never execution;
    - player override always wins for the current situation;
    - asking to stop a habit does not disable it. Retraining still requires contrary practice.
    """

    MIN_SITUATION_OBSERVATIONS = 6
    MIN_CONTEXT_OBSERVATIONS = 3
    AUTO_STABILITY = 0.78
    PREPARE_STABILITY = 0.62

    @staticmethod
    def _ctx_key(situation_family: str, context_tags: Sequence[str], choice_key: str) -> str:
        tags = ",".join(sorted(set(context_tags)))
        return f"{situation_family}|{tags}|{choice_key}"

    @staticmethod
    def _sit_key(situation_family: str, choice_key: str) -> str:
        return f"{situation_family}|{choice_key}"

    def observe_choice(self, state: PredictiveRoutineState, situation_family: str,
                       choice_key: str, context_tags: Sequence[str] = ()) -> None:
        state.situation_choice_counts[self._sit_key(situation_family, choice_key)] += 1
        state.context_choice_counts[self._ctx_key(situation_family, context_tags, choice_key)] += 1

    def _stability(self, state: PredictiveRoutineState, situation_family: str,
                   choice_key: str, context_tags: Sequence[str]) -> tuple[float, int, int]:
        prefix = f"{situation_family}|"
        total_situation = sum(v for k, v in state.situation_choice_counts.items() if str(k).startswith(prefix))
        same_situation = state.situation_choice_counts[self._sit_key(situation_family, choice_key)]
        situation_stability = same_situation / max(1, total_situation)

        tag_blob = ",".join(sorted(set(context_tags)))
        ctx_prefix = f"{situation_family}|{tag_blob}|"
        total_context = sum(v for k, v in state.context_choice_counts.items() if str(k).startswith(ctx_prefix))
        same_context = state.context_choice_counts[self._ctx_key(situation_family, context_tags, choice_key)]
        context_stability = same_context / max(1, total_context)
        if total_context < self.MIN_CONTEXT_OBSERVATIONS:
            context_stability = situation_stability * 0.82
        return min(situation_stability, max(context_stability, situation_stability * 0.72)), total_situation, total_context

    def predict(self, state: PredictiveRoutineState, habit_state: HabitRuntimeState,
                context: RoutineContext) -> Optional[PredictedRoutine]:
        if context.player_has_explicit_order:
            return None
        if context.high_stakes or not context.reversible:
            return None

        candidates = []
        for habit_id, record in habit_state.habits.items():
            definition = HABIT_BY_ID.get(habit_id)
            if definition is None or definition.situation_family != context.situation_family:
                continue
            if definition.automation_category in FORBIDDEN_AUTOMATION_CATEGORIES:
                continue
            # Predictive assistance itself can steer behavior. Habits explicitly marked
            # non-automatable therefore stay descriptive only: no auto and no preparation.
            if not definition.safe_to_automate:
                continue
            if definition.required_tags and not set(definition.required_tags) <= set(context.context_tags):
                continue
            stability, sit_n, ctx_n = self._stability(
                state, context.situation_family, definition.choice_key, context.context_tags
            )
            if sit_n < self.MIN_SITUATION_OBSERVATIONS:
                continue

            # Retraining never deletes a habit. It does make the predictor conservative:
            # only an already-trained instinct can still auto, otherwise prepare at most.
            retraining_penalty = 0.08 if record.retraining_requested else 0.0
            adjusted = max(0.0, stability - retraining_penalty)

            can_auto = (
                record.stage == "instinct"
                and definition.safe_to_automate
                and definition.automation_category in SAFE_AUTOMATION_CATEGORIES
                and adjusted >= self.AUTO_STABILITY
            )
            can_prepare = record.stage in {"habit", "instinct", "fading"} and adjusted >= self.PREPARE_STABILITY
            if not (can_auto or can_prepare):
                continue
            mode = "auto" if can_auto else "prepare"
            candidates.append((adjusted, record.strength, habit_id, definition, mode))

        if not candidates:
            return None
        adjusted, _, habit_id, definition, mode = max(candidates, key=lambda x: (x[0], x[1], x[2]))
        band = "very_stable" if adjusted >= 0.90 else "stable"
        if mode == "prepare":
            state.prepared_only += 1
        state.recent_predictions.append(f"{context.situation_family}|{definition.choice_key}|{mode}")
        return PredictedRoutine(
            choice_key=definition.choice_key,
            habit_id=habit_id,
            confidence_band=band,
            mode=mode,
            narrative_hint=definition.instinct_description if mode == "auto" else definition.player_description,
        )

    def accept(self, state: PredictiveRoutineState) -> None:
        state.accepted_predictions += 1

    def override(self, state: PredictiveRoutineState) -> None:
        state.overridden_predictions += 1
