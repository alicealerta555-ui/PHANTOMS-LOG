from __future__ import annotations

from dataclasses import dataclass, field, asdict
from hashlib import sha256
import random
from typing import Dict, Optional, Sequence

from .npc_naming import NPCNameGenerator


REVEAL_ORDER = {"unknown": 0, "callsign": 1, "given": 2, "full": 3}


@dataclass(frozen=True)
class NPCVisualSnapshot:
    npc_id: str
    apparent_build: str = ""
    clothing: tuple[str, ...] = ()
    visible_gear: tuple[str, ...] = ()
    movement: tuple[str, ...] = ()
    visible_traits: tuple[str, ...] = ()
    voice_cues: tuple[str, ...] = ()
    scent_cues: tuple[str, ...] = ()
    activity_cues: tuple[str, ...] = ()
    profession_clues: tuple[str, ...] = ()
    true_profession: Optional[str] = None


@dataclass(frozen=True)
class NPCEncounterContext:
    encounter_type: str = "random"  # random/private/crew/professional/hostile
    danger: float = 0.0
    time_pressure: float = 0.0
    player_initiated_contact: bool = False
    formal_setting: bool = False
    role_is_public: bool = False
    role_known_to_player: bool = False
    prior_acquaintance: bool = False


@dataclass(frozen=True)
class NPCPresentationProfile:
    openness: float = 0.5
    caution: float = 0.5
    formality: float = 0.5
    hostility: float = 0.0
    trust_to_player: float = 0.0
    prefers_callsign: bool = False
    avoids_real_name: bool = False


@dataclass
class NPCPlayerKnowledge:
    npc_id: str
    name_reveal: str = "unknown"
    profession_known: bool = False
    known_profession: Optional[str] = None
    met_count: int = 0
    player_assumptions: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: dict) -> "NPCPlayerKnowledge":
        return cls(**raw)


@dataclass
class NPCEncounterRegistry:
    knowledge: Dict[str, NPCPlayerKnowledge] = field(default_factory=dict)
    schema_version: int = 1

    def get(self, npc_id: str) -> NPCPlayerKnowledge:
        if npc_id not in self.knowledge:
            self.knowledge[npc_id] = NPCPlayerKnowledge(npc_id=npc_id)
        return self.knowledge[npc_id]

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "knowledge": {k: v.to_dict() for k, v in self.knowledge.items()},
        }

    @classmethod
    def from_dict(cls, raw: dict) -> "NPCEncounterRegistry":
        obj = cls(schema_version=int(raw.get("schema_version", 1)))
        for key, value in dict(raw.get("knowledge", {})).items():
            obj.knowledge[key] = NPCPlayerKnowledge.from_dict(value)
        return obj


@dataclass(frozen=True)
class NPCFirstContactResult:
    npc_id: str
    display_name: str
    visible_description: str
    introduction_line: Optional[str]
    name_reveal: str
    profession_revealed: bool
    profession_label: Optional[str]
    profession_clues: tuple[str, ...]


class NPCFirstContactEngine:
    """Epistemic first-contact layer.

    The engine knows the NPC identity but only exposes information justified by
    perception, prior knowledge, or social disclosure. Profession clues may be
    visible immediately; profession labels are never inferred from clues.
    """

    def __init__(self, name_generator: NPCNameGenerator,
                 registry: Optional[NPCEncounterRegistry] = None,
                 seed: str = "PH4NT0M5-L0G:first-contact"):
        self.names = name_generator
        self.registry = registry or NPCEncounterRegistry()
        self.seed = seed

    def _rng(self, npc_id: str, context: NPCEncounterContext, salt: str = "") -> random.Random:
        raw = f"{self.seed}|{npc_id}|{context.encounter_type}|{context.formal_setting}|{salt}"
        return random.Random(int(sha256(raw.encode("utf-8")).hexdigest(), 16))

    @staticmethod
    def _clamp(value: float) -> float:
        return max(0.0, min(1.0, float(value)))

    def _choose_reveal(self, npc_id: str, context: NPCEncounterContext,
                       profile: NPCPresentationProfile) -> str:
        state = self.registry.get(npc_id)
        current = state.name_reveal
        if context.prior_acquaintance:
            return current if current != "unknown" else "given"
        if profile.hostility >= .70 or context.encounter_type == "hostile":
            return current
        if not context.player_initiated_contact and context.encounter_type == "random":
            return current
        if context.danger >= .75 or context.time_pressure >= .80:
            return current

        score = (
            self._clamp(profile.openness) * .34
            + self._clamp(profile.trust_to_player) * .26
            + (1.0 - self._clamp(profile.caution)) * .22
            + (.12 if context.formal_setting else 0.0)
            + (.10 if context.encounter_type in {"crew", "professional", "private"} else 0.0)
        )
        if profile.avoids_real_name:
            return "callsign" if self.names.registry.names[npc_id].callsign else current
        if profile.prefers_callsign and self.names.registry.names[npc_id].callsign:
            return "callsign"
        if context.formal_setting and profile.formality >= .65 and score >= .45:
            return "full"
        if score >= .52:
            return "given"
        if score >= .38 and self.names.registry.names[npc_id].callsign:
            return "callsign"
        return current

    @staticmethod
    def _max_reveal(a: str, b: str) -> str:
        return a if REVEAL_ORDER.get(a, 0) >= REVEAL_ORDER.get(b, 0) else b

    def _display_name(self, npc_id: str, reveal: str) -> str:
        name = self.names.registry.names[npc_id]
        if reveal == "unknown":
            return "Unbekannte Person"
        if reveal == "callsign":
            if name.callsign:
                return name.callsign
            return name.canonical_given
        if reveal == "given":
            if name.callsign:
                return f"{name.canonical_given} “{name.callsign}”"
            return name.canonical_given
        return name.full_name

    @staticmethod
    def _describe(visual: NPCVisualSnapshot) -> str:
        parts: list[str] = []
        if visual.apparent_build:
            parts.append(visual.apparent_build.strip().rstrip("."))
        for group in (visual.clothing, visual.visible_traits, visual.visible_gear,
                      visual.movement, visual.voice_cues, visual.scent_cues,
                      visual.activity_cues, visual.profession_clues):
            parts.extend(x.strip().rstrip(".") for x in group if x and x.strip())
        if not parts:
            return "Eine Person befindet sich in Sichtweite."
        text = ". ".join(parts)
        return text[0].upper() + text[1:] + "."

    def first_contact(self, visual: NPCVisualSnapshot, context: NPCEncounterContext,
                      profile: NPCPresentationProfile) -> NPCFirstContactResult:
        if visual.npc_id not in self.names.registry.names:
            raise KeyError("NPC name must be generated/persisted before first-contact presentation")
        state = self.registry.get(visual.npc_id)
        state.met_count += 1
        selected = self._choose_reveal(visual.npc_id, context, profile)
        state.name_reveal = self._max_reveal(state.name_reveal, selected)

        # Profession labels are NOT inferred from visible clues. They appear only
        # when the host already marks that knowledge as established.
        if context.role_known_to_player and visual.true_profession:
            state.profession_known = True
            state.known_profession = visual.true_profession

        introduction = None
        if selected != "unknown" and REVEAL_ORDER[selected] > REVEAL_ORDER.get("unknown", 0):
            name = self.names.registry.names[visual.npc_id]
            if selected == "callsign" and name.callsign:
                introduction = f'„{name.callsign} reicht.“'
            elif selected == "given":
                if name.callsign and profile.prefers_callsign:
                    introduction = f'„{name.canonical_given}. {name.callsign} für die Leute hier.“'
                else:
                    introduction = f'„{name.canonical_given}.“'
            elif selected == "full":
                introduction = f'„{name.full_name}.“'

        return NPCFirstContactResult(
            npc_id=visual.npc_id,
            display_name=self._display_name(visual.npc_id, state.name_reveal),
            visible_description=self._describe(visual),
            introduction_line=introduction,
            name_reveal=state.name_reveal,
            profession_revealed=state.profession_known,
            profession_label=state.known_profession if state.profession_known else None,
            profession_clues=tuple(visual.profession_clues),
        )

    def ask_name(self, npc_id: str, profile: NPCPresentationProfile,
                 context: Optional[NPCEncounterContext] = None) -> str:
        context = context or NPCEncounterContext(player_initiated_contact=True)
        state = self.registry.get(npc_id)
        selected = self._choose_reveal(npc_id, NPCEncounterContext(
            encounter_type=context.encounter_type,
            danger=context.danger,
            time_pressure=context.time_pressure,
            player_initiated_contact=True,
            formal_setting=context.formal_setting,
            role_is_public=context.role_is_public,
            role_known_to_player=context.role_known_to_player,
            prior_acquaintance=context.prior_acquaintance,
        ), profile)
        state.name_reveal = self._max_reveal(state.name_reveal, selected)
        return self._display_name(npc_id, state.name_reveal)

    def establish_profession(self, npc_id: str, profession: str) -> None:
        state = self.registry.get(npc_id)
        state.profession_known = True
        state.known_profession = profession

    def snapshot_for_save(self) -> dict:
        return self.registry.to_dict()

    @classmethod
    def from_save(cls, name_generator: NPCNameGenerator, payload: dict) -> "NPCFirstContactEngine":
        return cls(name_generator=name_generator, registry=NPCEncounterRegistry.from_dict(payload))
