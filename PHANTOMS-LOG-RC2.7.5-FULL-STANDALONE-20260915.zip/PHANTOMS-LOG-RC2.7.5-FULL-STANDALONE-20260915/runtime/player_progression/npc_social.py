from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, Optional, Sequence

from .npc_encounter import NPCEncounterRegistry, REVEAL_ORDER
from .npc_naming import NPCNameGenerator


@dataclass(frozen=True)
class SocialSource:
    source_id: str
    relation: str = "unknown"  # self/third_party/document/public_record/rumor/observation
    reliability: float = 0.5
    authority: float = 0.0
    direct: bool = False


@dataclass
class SocialClaim:
    key: str
    value: str
    source_id: str
    source_relation: str
    confidence: float
    verified: bool = False
    contradicted: bool = False
    first_seen_turn: int = 0
    last_seen_turn: int = 0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: dict) -> "SocialClaim":
        return cls(**raw)


@dataclass
class NPCSocialKnowledge:
    npc_id: str
    recognition_count: int = 0
    last_context: str = ""
    known_affiliations: list[str] = field(default_factory=list)
    known_relationships: Dict[str, str] = field(default_factory=dict)
    claims: list[SocialClaim] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "npc_id": self.npc_id,
            "recognition_count": self.recognition_count,
            "last_context": self.last_context,
            "known_affiliations": list(self.known_affiliations),
            "known_relationships": dict(self.known_relationships),
            "claims": [c.to_dict() for c in self.claims],
        }

    @classmethod
    def from_dict(cls, raw: dict) -> "NPCSocialKnowledge":
        obj = cls(
            npc_id=raw["npc_id"],
            recognition_count=int(raw.get("recognition_count", 0)),
            last_context=str(raw.get("last_context", "")),
            known_affiliations=list(raw.get("known_affiliations", [])),
            known_relationships=dict(raw.get("known_relationships", {})),
        )
        obj.claims = [SocialClaim.from_dict(x) for x in raw.get("claims", [])]
        return obj


@dataclass
class NPCSocialRegistry:
    knowledge: Dict[str, NPCSocialKnowledge] = field(default_factory=dict)
    turn_counter: int = 0
    schema_version: int = 1

    def get(self, npc_id: str) -> NPCSocialKnowledge:
        if npc_id not in self.knowledge:
            self.knowledge[npc_id] = NPCSocialKnowledge(npc_id=npc_id)
        return self.knowledge[npc_id]

    def next_turn(self) -> int:
        self.turn_counter += 1
        return self.turn_counter

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "turn_counter": self.turn_counter,
            "knowledge": {k: v.to_dict() for k, v in self.knowledge.items()},
        }

    @classmethod
    def from_dict(cls, raw: dict) -> "NPCSocialRegistry":
        obj = cls(
            turn_counter=int(raw.get("turn_counter", 0)),
            schema_version=int(raw.get("schema_version", 1)),
        )
        for key, value in dict(raw.get("knowledge", {})).items():
            obj.knowledge[key] = NPCSocialKnowledge.from_dict(value)
        return obj


@dataclass(frozen=True)
class SocialUpdateResult:
    npc_id: str
    display_name: str
    recognized: bool
    new_information: tuple[str, ...] = ()
    unresolved_claims: tuple[str, ...] = ()
    contradictions: tuple[str, ...] = ()


class NPCSocialKnowledgeEngine:
    """Persistent post-first-contact epistemic/social layer.

    Rules:
    - Host npc_id is authoritative identity; recognition does not identify strangers.
    - Claims from rumor/third parties remain claims until verified.
    - Direct self-disclosure may establish name, but profession/function only becomes
      factual when source/context is sufficiently direct/reliable or separately verified.
    - Contradictions are preserved, not silently reconciled.
    - Existing first-contact knowledge is monotonic; social rumors cannot erase facts.
    """

    def __init__(self, names: NPCNameGenerator, encounter_registry: NPCEncounterRegistry,
                 registry: Optional[NPCSocialRegistry] = None):
        self.names = names
        self.encounters = encounter_registry
        self.registry = registry or NPCSocialRegistry()

    @staticmethod
    def _clamp(v: float) -> float:
        return max(0.0, min(1.0, float(v)))

    def _display_name(self, npc_id: str) -> str:
        state = self.encounters.get(npc_id)
        if npc_id not in self.names.registry.names:
            return "Unbekannte Person"
        name = self.names.registry.names[npc_id]
        if state.name_reveal == "unknown":
            return "Unbekannte Person"
        if state.name_reveal == "callsign":
            return name.callsign or name.canonical_given
        if state.name_reveal == "given":
            return f"{name.canonical_given} “{name.callsign}”" if name.callsign else name.canonical_given
        return name.full_name

    def recognize(self, npc_id: str, context: str = "") -> SocialUpdateResult:
        social = self.registry.get(npc_id)
        encounter = self.encounters.get(npc_id)
        recognized = encounter.met_count > 0
        if recognized:
            social.recognition_count += 1
            social.last_context = context
        return SocialUpdateResult(
            npc_id=npc_id,
            display_name=self._display_name(npc_id),
            recognized=recognized,
        )

    def _upsert_claim(self, npc_id: str, key: str, value: str, source: SocialSource,
                      verified: bool = False) -> SocialClaim:
        social = self.registry.get(npc_id)
        turn = self.registry.next_turn()
        confidence = self._clamp(source.reliability * .70 + source.authority * .20 + (.10 if source.direct else 0.0))
        for claim in social.claims:
            if claim.key == key and claim.value == value and claim.source_id == source.source_id:
                claim.last_seen_turn = turn
                claim.confidence = max(claim.confidence, confidence)
                claim.verified = claim.verified or verified
                return claim
        claim = SocialClaim(
            key=key,
            value=value,
            source_id=source.source_id,
            source_relation=source.relation,
            confidence=confidence,
            verified=verified,
            first_seen_turn=turn,
            last_seen_turn=turn,
        )
        # Preserve contradictory claims explicitly.
        for old in social.claims:
            if old.key == key and old.value != value and not old.contradicted:
                old.contradicted = True
                claim.contradicted = True
        social.claims.append(claim)
        return claim

    def third_party_introduction(self, npc_id: str, introduced_name_level: str,
                                 source: SocialSource,
                                 profession: Optional[str] = None,
                                 affiliation: Optional[str] = None) -> SocialUpdateResult:
        if npc_id not in self.names.registry.names:
            raise KeyError("NPC must have a persistent generated name before social introduction")
        encounter = self.encounters.get(npc_id)
        if introduced_name_level not in REVEAL_ORDER:
            raise ValueError("invalid introduced_name_level")
        new_info: list[str] = []
        if REVEAL_ORDER[introduced_name_level] > REVEAL_ORDER.get(encounter.name_reveal, 0):
            # Name introduction is accepted as a social identifier when direct enough.
            if source.direct or source.reliability >= .55 or source.authority >= .50:
                encounter.name_reveal = introduced_name_level
                new_info.append("name")
        if profession:
            verified = bool(source.direct and (source.reliability >= .80 or source.authority >= .65))
            claim = self._upsert_claim(npc_id, "profession", profession, source, verified=verified)
            if verified:
                encounter.profession_known = True
                encounter.known_profession = profession
                new_info.append("profession")
        if affiliation:
            verified_aff = bool(source.direct and (source.reliability >= .75 or source.authority >= .60))
            self._upsert_claim(npc_id, "affiliation", affiliation, source, verified=verified_aff)
            if verified_aff and affiliation not in self.registry.get(npc_id).known_affiliations:
                self.registry.get(npc_id).known_affiliations.append(affiliation)
                new_info.append("affiliation")
        return self._result(npc_id, new_info)

    def self_disclosure(self, npc_id: str, *, name_level: Optional[str] = None,
                        profession: Optional[str] = None,
                        affiliation: Optional[str] = None,
                        reliability: float = .85) -> SocialUpdateResult:
        source = SocialSource(
            source_id=f"self:{npc_id}", relation="self", reliability=reliability,
            authority=.40, direct=True,
        )
        new_info: list[str] = []
        encounter = self.encounters.get(npc_id)
        if name_level:
            if name_level not in REVEAL_ORDER:
                raise ValueError("invalid name_level")
            if REVEAL_ORDER[name_level] > REVEAL_ORDER.get(encounter.name_reveal, 0):
                encounter.name_reveal = name_level
                new_info.append("name")
        if profession:
            # Self-description is a claim unless already corroborated or exceptionally reliable.
            corroborated = any(
                c.key == "profession" and c.value == profession and c.source_id != source.source_id and c.confidence >= .55
                for c in self.registry.get(npc_id).claims
            )
            verified = reliability >= .93 or corroborated
            self._upsert_claim(npc_id, "profession", profession, source, verified=verified)
            if verified:
                encounter.profession_known = True
                encounter.known_profession = profession
                new_info.append("profession")
        if affiliation:
            corroborated = any(
                c.key == "affiliation" and c.value == affiliation and c.source_id != source.source_id and c.confidence >= .55
                for c in self.registry.get(npc_id).claims
            )
            verified = reliability >= .93 or corroborated
            self._upsert_claim(npc_id, "affiliation", affiliation, source, verified=verified)
            if verified and affiliation not in self.registry.get(npc_id).known_affiliations:
                self.registry.get(npc_id).known_affiliations.append(affiliation)
                new_info.append("affiliation")
        return self._result(npc_id, new_info)

    def record_rumor(self, npc_id: str, key: str, value: str, source_id: str,
                     reliability: float = .35) -> SocialUpdateResult:
        source = SocialSource(source_id=source_id, relation="rumor", reliability=reliability, direct=False)
        self._upsert_claim(npc_id, key, value, source, verified=False)
        return self._result(npc_id, [])

    def verify_claim(self, npc_id: str, key: str, value: str, evidence_source: str = "host_verified") -> SocialUpdateResult:
        social = self.registry.get(npc_id)
        turn = self.registry.next_turn()
        matched = False
        new_info: list[str] = []
        for claim in social.claims:
            if claim.key == key:
                if claim.value == value:
                    claim.verified = True
                    claim.contradicted = False
                    claim.confidence = 1.0
                    claim.last_seen_turn = turn
                    matched = True
                else:
                    claim.contradicted = True
        if not matched:
            social.claims.append(SocialClaim(
                key=key, value=value, source_id=evidence_source, source_relation="verified",
                confidence=1.0, verified=True, first_seen_turn=turn, last_seen_turn=turn,
            ))
        encounter = self.encounters.get(npc_id)
        if key == "profession":
            encounter.profession_known = True
            encounter.known_profession = value
            new_info.append("profession")
        elif key == "affiliation":
            if value not in social.known_affiliations:
                social.known_affiliations.append(value)
            new_info.append("affiliation")
        return self._result(npc_id, new_info)

    def establish_relationship(self, npc_id: str, other_actor_id: str, relationship: str,
                               verified: bool = True) -> SocialUpdateResult:
        social = self.registry.get(npc_id)
        if verified:
            social.known_relationships[other_actor_id] = relationship
            return self._result(npc_id, ["relationship"])
        source = SocialSource(source_id=f"relation:{other_actor_id}", relation="rumor", reliability=.45)
        self._upsert_claim(npc_id, f"relationship:{other_actor_id}", relationship, source, verified=False)
        return self._result(npc_id, [])

    def _result(self, npc_id: str, new_info: Sequence[str]) -> SocialUpdateResult:
        social = self.registry.get(npc_id)
        unresolved = tuple(
            f"{c.key}:{c.value}" for c in social.claims if not c.verified and not c.contradicted
        )
        contradictions = tuple(
            f"{c.key}:{c.value}" for c in social.claims if c.contradicted
        )
        return SocialUpdateResult(
            npc_id=npc_id,
            display_name=self._display_name(npc_id),
            recognized=self.encounters.get(npc_id).met_count > 0,
            new_information=tuple(dict.fromkeys(new_info)),
            unresolved_claims=unresolved,
            contradictions=contradictions,
        )

    def snapshot_for_save(self) -> dict:
        return self.registry.to_dict()

    @classmethod
    def from_save(cls, names: NPCNameGenerator, encounter_registry: NPCEncounterRegistry,
                  payload: dict) -> "NPCSocialKnowledgeEngine":
        return cls(names, encounter_registry, NPCSocialRegistry.from_dict(payload))
