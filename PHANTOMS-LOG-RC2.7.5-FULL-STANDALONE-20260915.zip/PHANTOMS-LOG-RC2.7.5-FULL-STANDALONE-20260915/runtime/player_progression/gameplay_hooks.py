from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping, Optional

from .behavior import RawActionEvent
from .habits import DecisionEvent
from .livehooks import LiveContext, LiveHookResult, PlayerDevelopmentCoordinator


# Host-facing semantic domains. The adapter receives only resolved, visible/known
# gameplay facts after the authoritative action pipeline has decided the action.
DOMAINS = {
    "movement", "combat", "interaction", "medicine", "tech", "hacking",
    "dialogue", "exploration", "survival", "crafting",
}

# Conservative defaults. These are hidden runtime weights, never player-facing.
DOMAIN_AFFINITIES: dict[str, dict[str, float]] = {
    "movement": {"AFF_MOBILITY": 1.0, "AFF_PERCEPTION": 0.20},
    "combat": {"AFF_FORCE": 0.55, "AFF_PRECISION": 0.35, "AFF_ENDURANCE": 0.20},
    "interaction": {"AFF_ADAPTATION": 0.45, "AFF_PERCEPTION": 0.25},
    "medicine": {"AFF_MEDICAL": 1.0, "AFF_PROTECTION": 0.35},
    "tech": {"AFF_TECH": 1.0, "AFF_MACHINE": 0.25},
    "hacking": {"AFF_NETWORK": 1.0, "AFF_TECH": 0.35},
    "dialogue": {"AFF_SOCIAL": 0.85, "AFF_COMMAND": 0.20},
    "exploration": {"AFF_PERCEPTION": 0.70, "AFF_SURVIVAL": 0.45, "AFF_ADAPTATION": 0.20},
    "survival": {"AFF_SURVIVAL": 1.0, "AFF_ADAPTATION": 0.25},
    "crafting": {"AFF_TECH": 0.70, "AFF_ADAPTATION": 0.55, "AFF_MACHINE": 0.20},
}


@dataclass(frozen=True)
class ResolvedGameplayEvent:
    """Semantic event emitted *after* authoritative gameplay resolution.

    This adapter deliberately does not parse player prose and does not receive
    hidden world truth. The host supplies only committed/observed facts.
    """

    domain: str
    action_family: str
    committed: bool
    actor_is_player: bool = True
    location_id: str = ""
    target_kind: str = ""
    tool_kind: str = ""
    outcome: str = "success"
    visible_context_tags: tuple[str, ...] = ()
    risk_tags: tuple[str, ...] = ()
    difficulty_hint: float = 1.0
    consequence_hint: float = 1.0
    intentionality_hint: float = 1.0
    affinity_overrides: Mapping[str, float] = field(default_factory=dict)

    # Optional decision evidence for habit learning. This must describe the
    # player's resolved choice, not an inferred intention.
    situation_family: str = ""
    choice_key: str = ""
    decision_category: str = "micro_routine"
    reversible: bool = True
    high_stakes: bool = False
    irreversible: bool = False
    moral_or_story_choice: bool = False


class GameplayLearningBridge:
    """Connects committed gameplay resolution to adaptive player development.

    Rules:
    - no learning from uncommitted/aborted proposals;
    - no NPC/Crew learning through the player-only progression engine;
    - no raw prose parsing;
    - decision habits learn only from explicit resolved choice keys;
    - hidden world facts are not accepted by this interface.
    """

    def __init__(self, coordinator: PlayerDevelopmentCoordinator):
        self.coordinator = coordinator

    @staticmethod
    def _affinities(event: ResolvedGameplayEvent) -> dict[str, float]:
        if event.domain not in DOMAINS:
            raise ValueError(f"unsupported gameplay domain: {event.domain}")
        weights = dict(DOMAIN_AFFINITIES[event.domain])
        for key, value in dict(event.affinity_overrides).items():
            if value > 0:
                weights[str(key)] = float(value)
        return weights

    def after_resolution(self, event: ResolvedGameplayEvent) -> LiveHookResult:
        if not event.committed or not event.actor_is_player:
            return LiveHookResult(applied_action_learning=False)

        action = RawActionEvent(
            action_family=event.action_family,
            affinity_weights=self._affinities(event),
            location_id=event.location_id,
            target_kind=event.target_kind,
            tool_kind=event.tool_kind,
            outcome=event.outcome,
            difficulty_hint=event.difficulty_hint,
            consequence_hint=event.consequence_hint,
            intentionality_hint=event.intentionality_hint,
            risk_tags=tuple(event.risk_tags),
            context_tags=tuple(event.visible_context_tags),
            actor_is_player=True,
        )
        result = self.coordinator.on_action(action)

        # Decision learning is additive and only supplied when the host can name
        # the player's actual resolved choice semantically.
        if event.situation_family and event.choice_key:
            # High-stakes / irreversible / moral choices may still be *observed* as
            # biography, but the habit engine's existing category/reversible gates
            # prevent them from becoming safe automation. We preserve those facts
            # as visible context tags rather than inventing a second decision model.
            d_tags = list(event.visible_context_tags)
            if event.high_stakes:
                d_tags.append("high_stakes")
            if event.irreversible:
                d_tags.append("irreversible")
            if event.moral_or_story_choice:
                d_tags.append("moral_or_story_choice")
            decision = DecisionEvent(
                situation_family=event.situation_family,
                choice_key=event.choice_key,
                category=event.decision_category,
                context_tags=tuple(sorted(set(d_tags))),
                consequence_hint=event.consequence_hint,
                risk_hint=1.5 if event.high_stakes else 1.0,
                reversible=(event.reversible and not event.irreversible and not event.moral_or_story_choice),
                actor_is_player=True,
            )
            dres = self.coordinator.on_decision(decision)
            result.habit_messages.extend(dres.habit_messages)
            result.insight_messages.extend(dres.insight_messages)
            result.identity_note = dres.identity_note
        return result

    def before_decision(self, *, situation_family: str, visible_context_tags=(),
                        reversible: bool = True, high_stakes: bool = False,
                        explicit_player_order: bool = False) -> LiveHookResult:
        return self.coordinator.before_player_prompt(LiveContext(
            situation_family=situation_family,
            context_tags=tuple(visible_context_tags),
            reversible=reversible,
            high_stakes=high_stakes,
            explicit_player_order=explicit_player_order,
        ))
