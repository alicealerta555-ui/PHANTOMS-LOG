from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple

@dataclass(frozen=True)
class MemoryEvent:
    npc_id: str
    key: str
    turn: int
    summary: str
    emotion: float = 0.0
    relationship_effect: float = 0.0
    novelty: float = 0.0
    danger: float = 0.0
    rarity: float = 0.0
    unresolved: bool = False
    repetition_key: str = ""
    tags: Tuple[str, ...] = ()

@dataclass
class MemoryRecord:
    key: str
    summary: str
    salience: float
    first_turn: int
    last_turn: int
    count: int = 1
    unresolved: bool = False
    tags: Tuple[str, ...] = ()

@dataclass
class NPCMemoryState:
    npc_id: str
    recent: List[MemoryRecord] = field(default_factory=list)
    long_term: Dict[str, MemoryRecord] = field(default_factory=dict)
    summaries: Dict[str, str] = field(default_factory=dict)
    last_simulated_turn: int = 0
    current_location: str = ""
    current_goal: str = ""

class NPCMemoryBudgetEngine:
    """Rich simulation, sparse persistence.

    Repetition merges into one record. Low-salience events are dropped. Recent
    memory is a bounded ring. High-salience/unresolved memories survive. Old
    clusters are compressed to summaries. Offscreen state advances lazily.
    """
    def __init__(self, states: Optional[Dict[str,NPCMemoryState]]=None, recent_limit: int=24, long_term_limit: int=48):
        self.states=states or {}; self.recent_limit=recent_limit; self.long_term_limit=long_term_limit
    def state_for(self,npc_id:str)->NPCMemoryState:
        return self.states.setdefault(npc_id,NPCMemoryState(npc_id))
    @staticmethod
    def salience(e: MemoryEvent)->float:
        s=.20*abs(e.emotion)+.22*abs(e.relationship_effect)+.16*e.novelty+.18*e.danger+.14*e.rarity+(.22 if e.unresolved else 0)
        return max(0.0,min(1.0,s))
    def remember(self,e:MemoryEvent)->str:
        st=self.state_for(e.npc_id); score=self.salience(e); merge_key=e.repetition_key or e.key
        # merge repeated patterns before creating new raw entries
        if merge_key in st.long_term:
            r=st.long_term[merge_key]; r.count+=1; r.last_turn=e.turn; r.salience=min(1.0,max(r.salience,score)+.02); r.unresolved=r.unresolved or e.unresolved
            return "MERGED_LONG_TERM"
        for r in st.recent:
            if r.key==merge_key:
                r.count+=1; r.last_turn=e.turn; r.salience=max(r.salience,score); r.unresolved=r.unresolved or e.unresolved
                if r.count>=3 and (r.salience>=.28 or r.unresolved):
                    st.recent.remove(r); st.long_term[merge_key]=r; self._trim_long(st)
                    return "PROMOTED"
                return "MERGED_RECENT"
        if score < .10 and not e.unresolved:
            return "DROPPED"
        rec=MemoryRecord(merge_key,e.summary,score,e.turn,e.turn,1,e.unresolved,e.tags)
        if score>=.48 or e.unresolved:
            st.long_term[merge_key]=rec; self._trim_long(st); return "LONG_TERM"
        st.recent.append(rec)
        if len(st.recent)>self.recent_limit: st.recent=st.recent[-self.recent_limit:]
        return "RECENT"
    def _trim_long(self,st:NPCMemoryState)->None:
        if len(st.long_term)<=self.long_term_limit: return
        candidates=sorted(st.long_term.values(), key=lambda r:(r.unresolved, r.salience, r.last_turn))
        while len(st.long_term)>self.long_term_limit and candidates:
            r=candidates.pop(0)
            if r.unresolved: break
            st.summaries[r.key]=f"{r.summary} (wiederholt: {r.count})"
            st.long_term.pop(r.key,None)
    def compact(self,npc_id:str,current_turn:int,max_age:int=80)->int:
        st=self.state_for(npc_id); removed=0
        keep=[]
        for r in st.recent:
            if current_turn-r.last_turn>max_age and not r.unresolved:
                if r.count>=2 or r.salience>=.12: st.summaries[r.key]=f"{r.summary} (x{r.count})"
                removed+=1
            else: keep.append(r)
        st.recent=keep; self._trim_long(st); return removed
    def lazy_advance(self,npc_id:str,to_turn:int,location:str="",goal:str="")->dict:
        st=self.state_for(npc_id); elapsed=max(0,to_turn-st.last_simulated_turn)
        st.last_simulated_turn=to_turn
        if location: st.current_location=location
        if goal: st.current_goal=goal
        return {"npc_id":npc_id,"elapsed":elapsed,"location":st.current_location,"goal":st.current_goal}
    def snapshot_for_save(self)->dict:
        return {"recent_limit":self.recent_limit,"long_term_limit":self.long_term_limit,"states":{
            k:{"npc_id":v.npc_id,"recent":[asdict(x) for x in v.recent],"long_term":{rk:asdict(rv) for rk,rv in v.long_term.items()},
               "summaries":dict(v.summaries),"last_simulated_turn":v.last_simulated_turn,"current_location":v.current_location,"current_goal":v.current_goal}
            for k,v in self.states.items()}}
    @classmethod
    def from_save(cls,p:dict)->"NPCMemoryBudgetEngine":
        states={}
        for k,v in p.get("states",{}).items():
            st=NPCMemoryState(v.get("npc_id",k)); st.recent=[MemoryRecord(**x) for x in v.get("recent",[])]
            st.long_term={rk:MemoryRecord(**rv) for rk,rv in v.get("long_term",{}).items()}; st.summaries=dict(v.get("summaries",{}))
            st.last_simulated_turn=int(v.get("last_simulated_turn",0)); st.current_location=v.get("current_location",""); st.current_goal=v.get("current_goal","")
            states[k]=st
        return cls(states,int(p.get("recent_limit",24)),int(p.get("long_term_limit",48)))
