from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Dict, Optional, Sequence, Tuple


class InterestAction(str, Enum):
    IGNORE = "IGNORE"
    NOTICE = "NOTICE"
    QUESTION = "QUESTION"
    WARN = "WARN"
    SUGGEST = "SUGGEST"
    DEFER = "DEFER"


@dataclass(frozen=True)
class ItemSnapshot:
    item_id: str
    display_name: str
    category: str
    visible: bool = True
    in_use: bool = False
    regional_rarity: float = 0.0       # 0 common .. 1 extraordinary in this region
    cultural_salience: float = 0.0     # unusual / taboo / prestigious locally
    apparent_value: float = 0.0
    faction_relevance: float = 0.0
    visible_damage: float = 0.0        # only what can actually be seen/heard/smelled
    hidden_damage: float = 0.0         # NEVER used unless host explicitly exposes diagnosis evidence
    modification_salience: float = 0.0 # visible unusual custom work
    tech_complexity: float = 0.5
    condition_tags: Tuple[str, ...] = ()
    modification_tags: Tuple[str, ...] = ()
    worn_on_body: bool = False
    implanted: bool = False
    biological_interface: bool = False
    load_profile: Tuple[str, ...] = ()


@dataclass(frozen=True)
class NPCEquipmentExpertise:
    npc_id: str
    curiosity: float = 0.5
    sociability: float = 0.5
    caution: float = 0.5
    trust: float = 0.0                 # relationship with player: 0 stranger .. 1 deep trust
    familiarity: float = 0.0           # repeated-contact familiarity
    item_knowledge: float = 0.0        # category recognition / lore
    repair_skill: float = 0.0
    modification_skill: float = 0.0
    medical_skill: float = 0.0
    biotech_skill: float = 0.0
    regional_knowledge: float = 0.5
    openness: float = 0.5
    honesty: float = 0.7
    self_interest: float = 0.5
    specialties: Tuple[str, ...] = ()


@dataclass(frozen=True)
class ItemInterestContext:
    region_id: str
    safe_to_talk: bool = True
    time_pressure: float = 0.0
    danger: float = 0.0
    privacy: float = 0.5
    social_window: float = 0.5
    player_busy: bool = False
    conversation_open: bool = False
    explicit_item_topic: bool = False
    diagnostic_access: bool = False     # host says NPC had a plausible chance to inspect/test
    workshop_context: bool = False
    turn: int = 0
    wearer_species: str = "baseline_human"
    wearer_condition_tags: Tuple[str, ...] = ()
    flesh_limits_known: bool = False


@dataclass(frozen=True)
class BiologicalLoadAssessment:
    relevant: bool
    concerns: Tuple[str, ...] = ()
    severity: str = "none"
    confidence: str = "low"


@dataclass(frozen=True)
class CalibrationTradeoff:
    gain: str
    cost: str
    uncertainty: str = ""


@dataclass(frozen=True)
class ModificationProposal:
    title: str
    rationale: str
    tradeoffs: Tuple[CalibrationTradeoff, ...]
    confidence: str                    # qualitative only
    requires_inspection: bool = False
    requires_specialist: bool = False
    biological_limits: Optional[BiologicalLoadAssessment] = None

    def validate(self) -> None:
        if not self.tradeoffs:
            raise ValueError("modification proposals must contain at least one trade-off")
        for t in self.tradeoffs:
            if not t.gain.strip() or not t.cost.strip():
                raise ValueError("every modification gain must have a non-empty cost")


@dataclass
class DeferredItemTopic:
    npc_id: str
    item_id: str
    reason: str
    topic_kind: str
    first_turn: int
    last_turn: int
    mentions: int = 0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: dict) -> "DeferredItemTopic":
        return cls(**raw)


@dataclass
class ItemInterestMemory:
    seen_counts: Dict[str, int] = field(default_factory=dict) # npc|item
    discussed_counts: Dict[str, int] = field(default_factory=dict)
    deferred: Dict[str, DeferredItemTopic] = field(default_factory=dict)
    schema_version: int = 1

    @staticmethod
    def _key(npc_id: str, item_id: str) -> str:
        return f"{npc_id}|{item_id}"

    def note_seen(self, npc_id: str, item_id: str) -> int:
        k = self._key(npc_id, item_id)
        self.seen_counts[k] = self.seen_counts.get(k, 0) + 1
        return self.seen_counts[k]

    def note_discussed(self, npc_id: str, item_id: str) -> int:
        k = self._key(npc_id, item_id)
        self.discussed_counts[k] = self.discussed_counts.get(k, 0) + 1
        return self.discussed_counts[k]

    def defer(self, npc_id: str, item_id: str, *, reason: str, topic_kind: str, turn: int) -> DeferredItemTopic:
        k = self._key(npc_id, item_id)
        if k in self.deferred:
            rec = self.deferred[k]
            rec.last_turn = turn
            rec.reason = reason
            rec.topic_kind = topic_kind
            return rec
        rec = DeferredItemTopic(npc_id, item_id, reason, topic_kind, turn, turn)
        self.deferred[k] = rec
        return rec

    def pop_deferred(self, npc_id: str, item_id: str) -> Optional[DeferredItemTopic]:
        return self.deferred.pop(self._key(npc_id, item_id), None)

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "seen_counts": dict(self.seen_counts),
            "discussed_counts": dict(self.discussed_counts),
            "deferred": {k: v.to_dict() for k, v in self.deferred.items()},
        }

    @classmethod
    def from_dict(cls, raw: dict) -> "ItemInterestMemory":
        obj = cls(
            seen_counts={k: int(v) for k, v in dict(raw.get("seen_counts", {})).items()},
            discussed_counts={k: int(v) for k, v in dict(raw.get("discussed_counts", {})).items()},
            schema_version=int(raw.get("schema_version", 1)),
        )
        obj.deferred = {k: DeferredItemTopic.from_dict(v) for k, v in dict(raw.get("deferred", {})).items()}
        return obj


@dataclass(frozen=True)
class ItemInterestResult:
    npc_id: str
    item_id: str
    action: InterestAction
    visible_interest: bool
    cues: Tuple[str, ...] = ()
    dialogue_seed: Optional[str] = None
    recognized: bool = False
    damage_suspected: bool = False
    modification_noticed: bool = False
    deferred: bool = False
    proposal: Optional[ModificationProposal] = None
    biological_limits: Optional[BiologicalLoadAssessment] = None


class NPCItemInterestEngine:
    """Contextual NPC interest / equipment expertise layer.

    Design rules:
    - no invisible-item knowledge
    - no hidden damage knowledge without diagnostic access
    - interest must be perceptible when it matters
    - low skill may ask questions instead of producing expert answers
    - advice is gated by relationship and current conversational opportunity
    - time pressure/danger can defer rather than erase a topic
    - modifications are calibration trade-offs, never linear +power packages
    - body-linked equipment respects flesh limits; technical possibility != biological suitability
    """

    def __init__(self, memory: Optional[ItemInterestMemory] = None):
        self.memory = memory or ItemInterestMemory()

    def evaluate(self, item: ItemSnapshot, npc: NPCEquipmentExpertise,
                 context: ItemInterestContext) -> ItemInterestResult:
        if not item.visible:
            return ItemInterestResult(npc.npc_id, item.item_id, InterestAction.IGNORE, False)

        seen = self.memory.note_seen(npc.npc_id, item.item_id)
        specialty = item.category in npc.specialties
        recognize = max(npc.item_knowledge, npc.regional_knowledge * item.regional_rarity,
                        npc.modification_skill if item.modification_salience > .35 else 0.0)
        if specialty:
            recognize = min(1.0, recognize + .22)

        salience = max(
            item.regional_rarity * (0.45 + 0.55 * npc.regional_knowledge),
            item.cultural_salience,
            item.faction_relevance,
            item.apparent_value * .65,
            item.visible_damage * (.35 + .65 * npc.repair_skill),
            item.modification_salience * (.30 + .70 * max(npc.item_knowledge, npc.modification_skill)),
        )
        interest = salience * (.35 + .65 * npc.curiosity) * (.55 + .45 * npc.openness)
        repetition = 1.0 if seen <= 1 else max(.18, 1.0 / (seen ** .65))
        interest *= repetition

        damage_detectable = item.visible_damage >= .22 and npc.repair_skill >= .28
        # hidden damage is legal only after plausible diagnostic access
        hidden_diagnostic = context.diagnostic_access and item.hidden_damage >= .22 and npc.repair_skill >= .48
        damage_suspected = damage_detectable or hidden_diagnostic
        mod_noticed = item.modification_salience >= .28 and max(npc.item_knowledge, npc.modification_skill) >= .25
        biological = self._assess_biological_load(item, npc, context)

        # Explicit topic opens the social door but does not grant knowledge.
        if context.explicit_item_topic:
            interest = max(interest, .48)

        visible_interest = interest >= .32
        cues = self._interest_cues(item, npc, damage_suspected, mod_noticed) if visible_interest else ()

        unsafe = (not context.safe_to_talk or context.danger >= .45 or context.time_pressure >= .60 or context.player_busy)
        if visible_interest and unsafe:
            kind = "damage" if damage_suspected else "modification" if mod_noticed else "interest"
            self.memory.defer(npc.npc_id, item.item_id, reason="timing", topic_kind=kind, turn=context.turn)
            return ItemInterestResult(npc.npc_id, item.item_id, InterestAction.DEFER, True, cues,
                                      recognized=recognize >= .36, damage_suspected=damage_suspected,
                                      modification_noticed=mod_noticed, deferred=True, biological_limits=biological)

        # Do not turn every salient item into a conversation.
        social_permission = (
            context.conversation_open or context.explicit_item_topic or context.workshop_context or
            (npc.familiarity >= .30 and context.social_window >= .45)
        )
        if not visible_interest or not social_permission:
            return ItemInterestResult(npc.npc_id, item.item_id,
                                      InterestAction.NOTICE if visible_interest else InterestAction.IGNORE,
                                      visible_interest, cues, recognized=recognize >= .36,
                                      damage_suspected=damage_suspected, modification_noticed=mod_noticed, biological_limits=biological)

        # Repair warning: competent NPCs can flag plausibly detectable faults; trust controls depth.
        if damage_suspected:
            if npc.repair_skill < .45:
                return self._question(item, npc, cues, "damage")
            if npc.trust < .18 and not context.explicit_item_topic:
                return ItemInterestResult(npc.npc_id, item.item_id, InterestAction.NOTICE, True, cues,
                                          recognized=True, damage_suspected=True, modification_noticed=mod_noticed, biological_limits=biological)
            self.memory.note_discussed(npc.npc_id, item.item_id)
            return ItemInterestResult(
                npc.npc_id, item.item_id, InterestAction.WARN, True, cues,
                dialogue_seed=self._warning_seed(item, npc), recognized=True,
                damage_suspected=True, modification_noticed=mod_noticed, biological_limits=biological,
            )

        # A low-skill but curious NPC should ask, especially about conspicuous custom work.
        if mod_noticed and npc.modification_skill < .48:
            return self._question(item, npc, cues, "modification")

        # Advice is relationship-gated unless the player explicitly asks or a workshop context makes it natural.
        advice_permission = (
            context.explicit_item_topic or context.workshop_context or
            (npc.trust >= .42 and npc.familiarity >= .28 and context.social_window >= .50)
        )
        if mod_noticed and npc.modification_skill >= .48 and advice_permission:
            proposal = self._calibration_proposal(item, npc, biological)
            self.memory.note_discussed(npc.npc_id, item.item_id)
            return ItemInterestResult(
                npc.npc_id, item.item_id, InterestAction.SUGGEST, True, cues,
                dialogue_seed=self._suggestion_seed(item, proposal), recognized=True,
                modification_noticed=True, proposal=proposal, biological_limits=biological,
            )

        # Rare/unusual object can still invite a question instead of an unsolicited lecture.
        if interest >= .48 and npc.sociability >= .28:
            return self._question(item, npc, cues, "origin")

        return ItemInterestResult(npc.npc_id, item.item_id, InterestAction.NOTICE, True, cues,
                                  recognized=recognize >= .36, damage_suspected=damage_suspected,
                                  modification_noticed=mod_noticed, biological_limits=biological)

    def revisit_deferred(self, item: ItemSnapshot, npc: NPCEquipmentExpertise,
                         context: ItemInterestContext) -> ItemInterestResult:
        rec = self.memory.deferred.get(self.memory._key(npc.npc_id, item.item_id))
        if rec is None:
            return ItemInterestResult(npc.npc_id, item.item_id, InterestAction.IGNORE, False)
        if not context.safe_to_talk or context.danger >= .30 or context.time_pressure >= .45 or context.player_busy:
            return ItemInterestResult(npc.npc_id, item.item_id, InterestAction.DEFER, True,
                                      ("Der Blick des NPC streift das Item erneut, aber der Moment passt noch nicht.",),
                                      deferred=True)
        # Re-open conversational window; explicit topic remains false so relationship still matters.
        self.memory.pop_deferred(npc.npc_id, item.item_id)
        return self.evaluate(item, npc, ItemInterestContext(
            region_id=context.region_id, safe_to_talk=True, time_pressure=context.time_pressure,
            danger=context.danger, privacy=context.privacy,
            social_window=max(context.social_window, .65), player_busy=False,
            conversation_open=True, explicit_item_topic=context.explicit_item_topic,
            diagnostic_access=context.diagnostic_access, workshop_context=context.workshop_context,
            turn=context.turn, wearer_species=context.wearer_species,
            wearer_condition_tags=context.wearer_condition_tags, flesh_limits_known=context.flesh_limits_known,
        ))

    def _question(self, item: ItemSnapshot, npc: NPCEquipmentExpertise,
                  cues: Tuple[str, ...], kind: str) -> ItemInterestResult:
        self.memory.note_discussed(npc.npc_id, item.item_id)
        if kind == "damage":
            seed = f'„Ist das bei {item.display_name} normal? Das wirkt nicht ganz gesund.“'
        elif kind == "modification":
            seed = f'„Was hast du an {item.display_name} verändert? So habe ich das noch nicht gesehen.“'
        else:
            seed = f'„Wo hast du {item.display_name} her?“'
        return ItemInterestResult(npc.npc_id, item.item_id, InterestAction.QUESTION, True, cues,
                                  dialogue_seed=seed, recognized=False,
                                  damage_suspected=(kind == "damage"), modification_noticed=(kind == "modification"))

    def _interest_cues(self, item: ItemSnapshot, npc: NPCEquipmentExpertise,
                       damage: bool, modified: bool) -> Tuple[str, ...]:
        cues = []
        if damage:
            cues.append("Der Blick bleibt an den Gebrauchsspuren und dem Laufverhalten des Gegenstands hängen.")
        elif modified:
            cues.append("Der NPC betrachtet die ungewöhnlichen Umbauten deutlich länger als nötig.")
        elif item.regional_rarity >= .55:
            cues.append("Der Blick des NPC kehrt mehrmals zu dem ungewöhnlichen Ausrüstungsstück zurück.")
        else:
            cues.append("Der NPC mustert das Ausrüstungsstück mit erkennbarem Interesse.")
        if npc.curiosity >= .72:
            cues.append("Die Neugier ist kaum verborgen.")
        return tuple(cues)

    def _warning_seed(self, item: ItemSnapshot, npc: NPCEquipmentExpertise) -> str:
        if npc.repair_skill >= .75:
            return f'„Bei {item.display_name} stimmt etwas nicht. Noch kein Totalausfall, aber ich würde das prüfen, bevor du es weiter belastest.“'
        return f'„Ich würde {item.display_name} im Auge behalten. Da kündigt sich etwas an.“'

    def _assess_biological_load(self, item: ItemSnapshot, npc: NPCEquipmentExpertise,
                                context: ItemInterestContext) -> BiologicalLoadAssessment:
        relevant = item.worn_on_body or item.implanted or item.biological_interface or bool(item.load_profile)
        if not relevant:
            return BiologicalLoadAssessment(False)
        expertise = max(npc.medical_skill, npc.biotech_skill, npc.modification_skill * .45)
        if expertise < .30 and not context.flesh_limits_known:
            return BiologicalLoadAssessment(True, (), "unknown", "low")
        concerns = []
        tags = set(item.load_profile)
        wearer = set(context.wearer_condition_tags)
        if "neural" in tags:
            concerns.append("Nervenstress, Reizüberlastung oder Sensibilitätsverlust")
        if "circulatory" in tags:
            concerns.append("Kreislauf- und Durchblutungsbelastung")
        if "immune" in tags or item.implanted:
            concerns.append("Entzündung, Abstoßung oder chronische Immunreaktion")
        if "structural" in tags or item.worn_on_body:
            concerns.append("Druckstellen, Gelenkbelastung oder Gewebeschäden bei falscher Lastverteilung")
        if "thermal" in tags:
            concerns.append("Wärmestau und lokale Gewebebelastung")
        if "pain" in tags:
            concerns.append("Schmerz- und Stressbelastung kann die Einsatzfähigkeit begrenzen")
        if "healing" in wearer or "scar_tissue" in wearer:
            concerns.append("Heilung oder Narbengewebe können die Verträglichkeit verändern")
        if "frail" in wearer:
            concerns.append("geringe körperliche Reserve begrenzt sichere Lastspitzen")
        if context.wearer_species not in {"baseline_human", "human"}:
            concerns.append("artspezifische Anatomie muss vor einer Anpassung geprüft werden")
        if not concerns:
            concerns.append("Langzeitverträglichkeit und individuelle Belastungsgrenze prüfen")
        severity = "high" if len(concerns) >= 4 else "medium" if len(concerns) >= 2 else "low"
        confidence = "high" if expertise >= .75 else "medium" if expertise >= .50 else "low"
        return BiologicalLoadAssessment(True, tuple(concerns), severity, confidence)

    def _calibration_proposal(self, item: ItemSnapshot, npc: NPCEquipmentExpertise, biological: BiologicalLoadAssessment) -> ModificationProposal:
        # Generic, bounded calibration. Host/content layer may replace wording with item-specific authored variants.
        if item.category in {"weapon", "firearm", "ranged_weapon"}:
            trades = (
                CalibrationTradeoff("ruhigeres Verhalten / bessere Kontrolle", "etwas trägeres Handling oder höhere Wartungsanforderung",
                                    "hängt stark vom Zustand der vorhandenen Baugruppe ab"),
            )
            title = "Kontroll-Kalibrierung"
        elif item.category in {"armor", "suit", "exosuit"}:
            trades = (
                CalibrationTradeoff("mehr Schutz an den belasteten Zonen", "mehr Gewicht, Wärme oder eingeschränkte Beweglichkeit",
                                    "ohne genaue Passformmessung nur grob abschätzbar"),
            )
            title = "Schutzprofil neu abstimmen"
        elif item.category in {"scanner", "sensor", "electronics", "device"}:
            trades = (
                CalibrationTradeoff("empfindlichere Erfassung", "mehr Energiebedarf und höhere Störanfälligkeit",
                                    "kann in verrauschten Umgebungen sogar schlechter werden"),
            )
            title = "Sensitivitäts-Kalibrierung"
        else:
            trades = (
                CalibrationTradeoff("stärkere Ausrichtung auf den gewünschten Einsatzzweck", "weniger Reserven außerhalb dieses Einsatzzwecks",
                                    "erst nach genauer Prüfung sinnvoll festzulegen"),
            )
            title = "Einsatzprofil kalibrieren"
        if biological.relevant and biological.concerns:
            bio_cost = "; ".join(biological.concerns[:2])
            trades = trades + (CalibrationTradeoff(
                "bessere Abstimmung zwischen Gerät und Körper",
                bio_cost,
                "körperliche Reaktion kann individuell oder artspezifisch abweichen",
            ),)
        confidence = "hoch" if npc.modification_skill >= .78 else "mittel" if npc.modification_skill >= .58 else "vorsichtig"
        prop = ModificationProposal(
            title=title,
            rationale="Nicht stärker um jeden Preis, sondern gezielt auf den tatsächlichen Einsatz abstimmen.",
            tradeoffs=trades,
            confidence=confidence,
            requires_inspection=not item.in_use,
            requires_specialist=npc.modification_skill < .62 or (biological.relevant and max(npc.medical_skill, npc.biotech_skill) < .62),
            biological_limits=biological if biological.relevant else None,
        )
        prop.validate()
        return prop

    def _suggestion_seed(self, item: ItemSnapshot, proposal: ModificationProposal) -> str:
        t = proposal.tradeoffs[0]
        return (f'„Bei {item.display_name} könnte man {proposal.title.lower()}. '
                f'Du gewinnst {t.gain}, aber dafür bekommst du {t.cost}.“')

    def snapshot_for_save(self) -> dict:
        return self.memory.to_dict()

    @classmethod
    def from_save(cls, payload: dict) -> "NPCItemInterestEngine":
        return cls(ItemInterestMemory.from_dict(payload or {}))
