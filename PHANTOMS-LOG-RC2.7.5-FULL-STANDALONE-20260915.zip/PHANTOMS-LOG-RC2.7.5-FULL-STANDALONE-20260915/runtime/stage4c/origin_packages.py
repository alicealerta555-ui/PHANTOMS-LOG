# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import asdict, dataclass, fields, replace
from enum import Enum
import hashlib
import json
from typing import Iterable, Tuple

from runtime.stage4a import SUPEREVOLUTION_PHASES
from runtime.stage4b import (
    FORBIDDEN_BIOLOGICAL_TAG_PREFIXES,
    STAGE5_DETAIL_FIELDS,
    STAGE6_DETAIL_FIELDS,
    GenelineRecord,
    LinkStatus,
    OriginPackageLink,
    validate_geneline_record,
)


class OriginFamily(str, Enum):
    MAMMALIAN = "MAMMALIAN"
    AVIAN = "AVIAN"
    REPTILIAN = "REPTILIAN"
    AMPHIBIAN = "AMPHIBIAN"
    FISH_CEPHALOPOD = "FISH_CEPHALOPOD"
    ARTHROPOD_INSECT = "ARTHROPOD_INSECT"
    FUNGAL_PLANT_MICROBIAL = "FUNGAL_PLANT_MICROBIAL"
    SYNTHETIC_BIOLOGY = "SYNTHETIC_BIOLOGY"


class FunctionalDomain(str, Enum):
    STRUCTURE = "STRUCTURE"
    LOCOMOTION = "LOCOMOTION"
    METABOLISM = "METABOLISM"
    THERMAL = "THERMAL"
    HYDRATION = "HYDRATION"
    RESPIRATION = "RESPIRATION"
    REGENERATION = "REGENERATION"
    DEFENSE = "DEFENSE"
    BIOCHEMISTRY = "BIOCHEMISTRY"
    SENSOR_HOOK = "SENSOR_HOOK"
    ENVIRONMENT = "ENVIRONMENT"


@dataclass(frozen=True)
class FunctionalTradeoff:
    tradeoff_id: str
    domain: FunctionalDomain
    constraint_tags: Tuple[str, ...]
    statement: str


@dataclass(frozen=True)
class FunctionalContribution:
    contribution_id: str
    domain: FunctionalDomain
    capability_tags: Tuple[str, ...]
    required_tradeoff_refs: Tuple[str, ...]
    statement: str


@dataclass(frozen=True)
class OriginPackageProvenance:
    source_refs: Tuple[str, ...]
    authority_domain: str = "WORLD_TRUTH"


@dataclass(frozen=True)
class OriginPackage:
    package_id: str
    family: OriginFamily
    display_name: str
    source_scope: str
    earliest_phase_id: str
    contributions: Tuple[FunctionalContribution, ...]
    tradeoffs: Tuple[FunctionalTradeoff, ...]
    sensor_modalities: Tuple[str, ...]
    provenance: OriginPackageProvenance


@dataclass(frozen=True)
class OriginContributionCandidate:
    package_id: str
    family: OriginFamily
    contribution: FunctionalContribution
    required_tradeoffs: Tuple[FunctionalTradeoff, ...]


@dataclass(frozen=True)
class OriginDesignSpace:
    lineage_id: str
    package_refs: Tuple[str, ...]
    candidates: Tuple[OriginContributionCandidate, ...]

    def candidates_for_domain(self, domain: FunctionalDomain) -> Tuple[OriginContributionCandidate, ...]:
        return tuple(candidate for candidate in self.candidates if candidate.contribution.domain == domain)


_PHASE_ORDER = {phase.phase_id: phase.order for phase in SUPEREVOLUTION_PHASES}


def _validate_id(value: str, code: str) -> None:
    if not value or value.strip() != value or any(ch.isspace() for ch in value):
        raise ValueError(code)


def _iter_package_tags(package: OriginPackage) -> Iterable[str]:
    for contribution in package.contributions:
        yield from contribution.capability_tags
    for tradeoff in package.tradeoffs:
        yield from tradeoff.constraint_tags
    yield from package.sensor_modalities


def _assert_no_later_stage_detail_tag(tag: str) -> None:
    normalized = tag.strip().lower()
    for field_name in STAGE5_DETAIL_FIELDS + STAGE6_DETAIL_FIELDS:
        field_lower = field_name.lower()
        if normalized == field_lower or normalized.startswith(field_lower + ":"):
            raise ValueError(f"ORIGIN_PACKAGE_LATER_STAGE_DETAIL_FORBIDDEN:{tag}")


def validate_origin_package(package: OriginPackage) -> None:
    _validate_id(package.package_id, "ORIGIN_PACKAGE_ID_INVALID")
    if not package.display_name.strip():
        raise ValueError("ORIGIN_PACKAGE_DISPLAY_NAME_REQUIRED")
    if not package.source_scope.strip():
        raise ValueError("ORIGIN_PACKAGE_SOURCE_SCOPE_REQUIRED")
    if package.earliest_phase_id not in _PHASE_ORDER:
        raise ValueError("ORIGIN_PACKAGE_PHASE_UNKNOWN")
    if not package.contributions:
        raise ValueError("ORIGIN_PACKAGE_CONTRIBUTION_REQUIRED")
    if not package.tradeoffs:
        raise ValueError("ORIGIN_PACKAGE_TRADEOFF_REQUIRED")

    tradeoff_ids = [item.tradeoff_id for item in package.tradeoffs]
    if len(tradeoff_ids) != len(set(tradeoff_ids)):
        raise ValueError("ORIGIN_PACKAGE_DUPLICATE_TRADEOFF_ID")
    contribution_ids = [item.contribution_id for item in package.contributions]
    if len(contribution_ids) != len(set(contribution_ids)):
        raise ValueError("ORIGIN_PACKAGE_DUPLICATE_CONTRIBUTION_ID")

    tradeoff_set = set(tradeoff_ids)
    referenced_tradeoffs: set[str] = set()
    for tradeoff in package.tradeoffs:
        _validate_id(tradeoff.tradeoff_id, "ORIGIN_PACKAGE_TRADEOFF_ID_INVALID")
        if not tradeoff.constraint_tags or not tradeoff.statement.strip():
            raise ValueError("ORIGIN_PACKAGE_TRADEOFF_INCOMPLETE")

    for contribution in package.contributions:
        _validate_id(contribution.contribution_id, "ORIGIN_PACKAGE_CONTRIBUTION_ID_INVALID")
        if not contribution.capability_tags or not contribution.statement.strip():
            raise ValueError("ORIGIN_PACKAGE_CONTRIBUTION_INCOMPLETE")
        if not contribution.required_tradeoff_refs:
            raise ValueError("ORIGIN_PACKAGE_CAPABILITY_WITHOUT_TRADEOFF")
        if len(contribution.required_tradeoff_refs) != len(set(contribution.required_tradeoff_refs)):
            raise ValueError("ORIGIN_PACKAGE_DUPLICATE_TRADEOFF_REFERENCE")
        unknown = set(contribution.required_tradeoff_refs) - tradeoff_set
        if unknown:
            raise ValueError(f"ORIGIN_PACKAGE_UNKNOWN_TRADEOFF_REFERENCE:{sorted(unknown)}")
        referenced_tradeoffs.update(contribution.required_tradeoff_refs)

    # Every tradeoff in a canonical package must actually constrain at least one
    # contribution; otherwise it is decorative rather than causal.
    unused = tradeoff_set - referenced_tradeoffs
    if unused:
        raise ValueError(f"ORIGIN_PACKAGE_UNUSED_TRADEOFF:{sorted(unused)}")

    if len(package.sensor_modalities) != len(set(package.sensor_modalities)):
        raise ValueError("ORIGIN_PACKAGE_DUPLICATE_SENSOR_MODALITY")
    if any(not modality.strip() for modality in package.sensor_modalities):
        raise ValueError("ORIGIN_PACKAGE_SENSOR_MODALITY_INVALID")

    for tag in _iter_package_tags(package):
        normalized = tag.strip().lower()
        if any(normalized.startswith(prefix) for prefix in FORBIDDEN_BIOLOGICAL_TAG_PREFIXES):
            raise ValueError(f"GENETIC_DETERMINISM_TAG_FORBIDDEN:{tag}")
        _assert_no_later_stage_detail_tag(tag)

    if package.provenance.authority_domain != "WORLD_TRUTH":
        raise ValueError("ORIGIN_PACKAGE_PROVENANCE_MUST_BE_WORLD_TRUTH")
    if not package.provenance.source_refs:
        raise ValueError("ORIGIN_PACKAGE_PROVENANCE_SOURCE_REQUIRED")

    # Keep Stage 4C itself free from future-stage schema creep.
    names = {field.name for field in fields(OriginPackage)}
    forbidden = set(STAGE5_DETAIL_FIELDS) | set(STAGE6_DETAIL_FIELDS)
    if names & forbidden:
        raise ValueError("ORIGIN_PACKAGE_SCHEMA_STAGE_BOUNDARY_VIOLATION")


class OriginPackageRegistry:
    def __init__(self) -> None:
        self._packages: dict[str, OriginPackage] = {}

    def register(self, package: OriginPackage) -> None:
        validate_origin_package(package)
        if package.package_id in self._packages:
            raise ValueError(f"ORIGIN_PACKAGE_DUPLICATE_ID:{package.package_id}")
        self._packages[package.package_id] = package

    def get(self, package_id: str) -> OriginPackage:
        try:
            return self._packages[package_id]
        except KeyError as exc:
            raise KeyError(f"ORIGIN_PACKAGE_NOT_FOUND:{package_id}") from exc

    def ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._packages))

    def packages(self) -> Tuple[OriginPackage, ...]:
        return tuple(self._packages[key] for key in self.ids())

    def canonical_payload(self) -> list[dict]:
        return [asdict(package) for package in self.packages()]

    def canonical_digest(self) -> str:
        raw = json.dumps(self.canonical_payload(), sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def __len__(self) -> int:
        return len(self._packages)


def _contribution(
    contribution_id: str,
    domain: FunctionalDomain,
    tags: Tuple[str, ...],
    tradeoffs: Tuple[str, ...],
    statement: str,
) -> FunctionalContribution:
    return FunctionalContribution(contribution_id, domain, tags, tradeoffs, statement)


def _tradeoff(
    tradeoff_id: str,
    domain: FunctionalDomain,
    tags: Tuple[str, ...],
    statement: str,
) -> FunctionalTradeoff:
    return FunctionalTradeoff(tradeoff_id, domain, tags, statement)


# These are source-function packages, not species templates. Capabilities are
# available motifs; linking a package does not mean a lineage expresses every
# listed contribution.
CANONICAL_ORIGIN_PACKAGES: Tuple[OriginPackage, ...] = (
    OriginPackage(
        package_id="ORG_MAMMALIAN_HOMEOSTASIS",
        family=OriginFamily.MAMMALIAN,
        display_name="Mammalian homeostasis package",
        source_scope="Mammalian-derived thermoregulation, aerobic endurance and flexible tissue-maintenance motifs.",
        earliest_phase_id="B0",
        contributions=(
            _contribution("MAM_ENDOTHERMIC_HOMEOSTASIS", FunctionalDomain.THERMAL, ("regulated_core_temperature",), ("MAM_HIGH_BASELINE_ENERGY",), "Supports active internal temperature regulation within lineage-specific limits."),
            _contribution("MAM_SUSTAINED_AEROBIC_OUTPUT", FunctionalDomain.METABOLISM, ("sustained_aerobic_output",), ("MAM_HIGH_BASELINE_ENERGY", "MAM_HEAT_DISSIPATION_LOAD"), "Supports sustained aerobic work rather than cost-free endurance."),
            _contribution("MAM_FLEXIBLE_SOFT_TISSUE_REPAIR", FunctionalDomain.REGENERATION, ("soft_tissue_repair_hook",), ("MAM_REPAIR_NUTRIENT_LOAD",), "Provides a repair motif whose expression remains limited by material and energy supply."),
        ),
        tradeoffs=(
            _tradeoff("MAM_HIGH_BASELINE_ENERGY", FunctionalDomain.METABOLISM, ("high_caloric_demand",), "Internal regulation and sustained output require continuous energy throughput."),
            _tradeoff("MAM_HEAT_DISSIPATION_LOAD", FunctionalDomain.THERMAL, ("heat_dissipation_requirement",), "High sustained output increases heat-removal requirements."),
            _tradeoff("MAM_REPAIR_NUTRIENT_LOAD", FunctionalDomain.REGENERATION, ("repair_requires_nutrients",), "Repair cannot exceed available energy and structural feedstock."),
        ),
        sensor_modalities=("auditory", "olfactory", "tactile"),
        provenance=OriginPackageProvenance(("STAGE4C_CANONICAL_FUNCTIONAL_SOURCE",)),
    ),
    OriginPackage(
        package_id="ORG_AVIAN_RESPIRATORY_STRUCTURAL",
        family=OriginFamily.AVIAN,
        display_name="Avian respiratory/structural package",
        source_scope="Avian-derived respiratory-efficiency, mass-reduction, insulation and aerial-locomotion motifs.",
        earliest_phase_id="B1",
        contributions=(
            _contribution("AVI_HIGH_FLOW_RESPIRATION", FunctionalDomain.RESPIRATION, ("high_flow_respiration_hook",), ("AVI_AIR_QUALITY_SENSITIVITY",), "Provides a high-throughput respiratory motif without specifying Stage-5 sensory detail."),
            _contribution("AVI_MASS_REDUCED_STRUCTURE", FunctionalDomain.STRUCTURE, ("mass_reduced_skeletal_hook",), ("AVI_IMPACT_MARGIN_COST",), "Supports lower structural mass with reduced tolerance for some load regimes unless compensated elsewhere."),
            _contribution("AVI_AERIAL_LOCOMOTION", FunctionalDomain.LOCOMOTION, ("aerial_locomotion_hook",), ("AVI_FLIGHT_ENERGY_LOAD", "AVI_IMPACT_MARGIN_COST"), "Permits an aerial-locomotion design space when the complete lineage morphology supports it."),
            _contribution("AVI_INSULATING_INTEGUMENT", FunctionalDomain.THERMAL, ("insulating_integument_hook",), ("AVI_INTEGUMENT_MAINTENANCE",), "Supports lightweight insulation with ongoing maintenance costs."),
        ),
        tradeoffs=(
            _tradeoff("AVI_AIR_QUALITY_SENSITIVITY", FunctionalDomain.RESPIRATION, ("respiratory_contaminant_sensitivity",), "High-throughput respiratory structures can increase exposure to airborne hazards."),
            _tradeoff("AVI_IMPACT_MARGIN_COST", FunctionalDomain.STRUCTURE, ("load_margin_tradeoff",), "Mass reduction constrains impact/load margins unless other structures compensate."),
            _tradeoff("AVI_FLIGHT_ENERGY_LOAD", FunctionalDomain.METABOLISM, ("aerial_locomotion_energy_cost",), "Powered aerial locomotion has substantial energy requirements."),
            _tradeoff("AVI_INTEGUMENT_MAINTENANCE", FunctionalDomain.STRUCTURE, ("integument_maintenance_cycle",), "Insulating integument requires upkeep and replacement."),
        ),
        sensor_modalities=("visual", "vestibular", "magnetoreception_hook"),
        provenance=OriginPackageProvenance(("STAGE4C_CANONICAL_FUNCTIONAL_SOURCE",)),
    ),
    OriginPackage(
        package_id="ORG_REPTILIAN_WATER_THERMAL",
        family=OriginFamily.REPTILIAN,
        display_name="Reptilian water/thermal package",
        source_scope="Reptilian-derived water-conservation, keratinized-surface and temperature-performance motifs.",
        earliest_phase_id="B1",
        contributions=(
            _contribution("REP_WATER_CONSERVING_SURFACE", FunctionalDomain.HYDRATION, ("water_conserving_integument",), ("REP_REDUCED_CUTANEOUS_EXCHANGE",), "Supports reduced passive water loss at the cost of cutaneous exchange."),
            _contribution("REP_LOW_BASELINE_THROUGHPUT", FunctionalDomain.METABOLISM, ("low_baseline_energy_throughput",), ("REP_TEMPERATURE_PERFORMANCE_DEPENDENCE",), "Supports low baseline energy use with stronger environmental performance dependence."),
            _contribution("REP_KERATINIZED_PROTECTION", FunctionalDomain.DEFENSE, ("keratinized_surface_protection",), ("REP_SURFACE_RENEWAL_COST",), "Supports protective external tissues with renewal/maintenance requirements."),
        ),
        tradeoffs=(
            _tradeoff("REP_REDUCED_CUTANEOUS_EXCHANGE", FunctionalDomain.HYDRATION, ("reduced_skin_exchange",), "Water conservation reduces some forms of skin-mediated exchange."),
            _tradeoff("REP_TEMPERATURE_PERFORMANCE_DEPENDENCE", FunctionalDomain.THERMAL, ("temperature_performance_window",), "Low baseline throughput can increase dependence on external thermal conditions."),
            _tradeoff("REP_SURFACE_RENEWAL_COST", FunctionalDomain.STRUCTURE, ("surface_renewal_requirement",), "Protective surfaces require periodic renewal and material investment."),
        ),
        sensor_modalities=("visual", "chemical", "thermal_hook"),
        provenance=OriginPackageProvenance(("STAGE4C_CANONICAL_FUNCTIONAL_SOURCE",)),
    ),
    OriginPackage(
        package_id="ORG_AMPHIBIAN_EXCHANGE_PLASTICITY",
        family=OriginFamily.AMPHIBIAN,
        display_name="Amphibian exchange/plasticity package",
        source_scope="Amphibian-derived cutaneous-exchange, moist-interface and tissue-plasticity motifs.",
        earliest_phase_id="B1",
        contributions=(
            _contribution("AMP_CUTANEOUS_EXCHANGE", FunctionalDomain.RESPIRATION, ("cutaneous_exchange_hook",), ("AMP_DEHYDRATION_SENSITIVITY", "AMP_CONTAMINANT_SENSITIVITY"), "Supports skin-mediated exchange only within suitable moisture and contamination limits."),
            _contribution("AMP_DUAL_ENVIRONMENT_INTERFACE", FunctionalDomain.ENVIRONMENT, ("aquatic_terrestrial_interface_hook",), ("AMP_MOISTURE_DEPENDENCE",), "Supports adaptation to wet transitional environments without implying universal amphibious performance."),
            _contribution("AMP_TISSUE_PLASTICITY", FunctionalDomain.REGENERATION, ("tissue_plasticity_hook",), ("AMP_INFECTION_BARRIER_COST",), "Provides a tissue-remodeling motif constrained by barrier and infection risks."),
        ),
        tradeoffs=(
            _tradeoff("AMP_DEHYDRATION_SENSITIVITY", FunctionalDomain.HYDRATION, ("high_dehydration_sensitivity",), "Exchange surfaces increase vulnerability to drying."),
            _tradeoff("AMP_CONTAMINANT_SENSITIVITY", FunctionalDomain.ENVIRONMENT, ("surface_contaminant_sensitivity",), "Permeable interfaces can increase exposure to environmental contaminants."),
            _tradeoff("AMP_MOISTURE_DEPENDENCE", FunctionalDomain.ENVIRONMENT, ("moisture_dependency",), "Some functional motifs require a moist interface."),
            _tradeoff("AMP_INFECTION_BARRIER_COST", FunctionalDomain.DEFENSE, ("barrier_integrity_tradeoff",), "Tissue plasticity can conflict with strong passive barrier functions."),
        ),
        sensor_modalities=("chemical", "vibration", "pressure_hook"),
        provenance=OriginPackageProvenance(("STAGE4C_CANONICAL_FUNCTIONAL_SOURCE",)),
    ),
    OriginPackage(
        package_id="ORG_AQUATIC_FISH_CEPHALOPOD",
        family=OriginFamily.FISH_CEPHALOPOD,
        display_name="Aquatic fish/cephalopod package",
        source_scope="Aquatic-derived respiration, hydrodynamic locomotion, soft-body manipulation and dynamic-pigment motifs.",
        earliest_phase_id="B1",
        contributions=(
            _contribution("AQU_AQUATIC_RESPIRATION", FunctionalDomain.RESPIRATION, ("aquatic_respiration_hook",), ("AQU_DISSOLVED_OXYGEN_DEPENDENCE",), "Supports extraction of oxygen from water within lineage-specific chemistry limits."),
            _contribution("AQU_HYDRODYNAMIC_LOCOMOTION", FunctionalDomain.LOCOMOTION, ("hydrodynamic_locomotion_hook",), ("AQU_TERRESTRIAL_SUPPORT_COST",), "Supports efficient aquatic movement with reduced utility outside supportive fluid environments."),
            _contribution("AQU_DYNAMIC_PIGMENT", FunctionalDomain.STRUCTURE, ("dynamic_pigment_control_hook",), ("AQU_PIGMENT_ENERGY_COST",), "Supports active pigment-state change without defining perception or communication semantics."),
            _contribution("AQU_FLEXIBLE_APPENDAGE_CONTROL", FunctionalDomain.LOCOMOTION, ("flexible_appendage_control_hook",), ("AQU_SOFT_TISSUE_SUPPORT_LIMIT",), "Supports highly flexible appendage control with structural-support tradeoffs."),
        ),
        tradeoffs=(
            _tradeoff("AQU_DISSOLVED_OXYGEN_DEPENDENCE", FunctionalDomain.ENVIRONMENT, ("water_oxygen_dependency",), "Aquatic respiration depends on water chemistry and dissolved oxygen."),
            _tradeoff("AQU_TERRESTRIAL_SUPPORT_COST", FunctionalDomain.STRUCTURE, ("reduced_unsupported_land_efficiency",), "Fluid-supported body plans may require additional structure on land."),
            _tradeoff("AQU_PIGMENT_ENERGY_COST", FunctionalDomain.METABOLISM, ("active_pigment_energy_cost",), "Dynamic pigment control consumes finite metabolic resources."),
            _tradeoff("AQU_SOFT_TISSUE_SUPPORT_LIMIT", FunctionalDomain.STRUCTURE, ("soft_tissue_load_limit",), "Extreme flexibility can reduce passive load-bearing capability."),
        ),
        sensor_modalities=("pressure", "chemical", "polarization_hook"),
        provenance=OriginPackageProvenance(("STAGE4C_CANONICAL_FUNCTIONAL_SOURCE",)),
    ),
    OriginPackage(
        package_id="ORG_ARTHROPOD_INSECT_SEGMENTAL",
        family=OriginFamily.ARTHROPOD_INSECT,
        display_name="Arthropod/insect segmental package",
        source_scope="Arthropod-derived exoskeletal, segmented-appendage, molting and distributed-chemosensory motifs.",
        earliest_phase_id="B1",
        contributions=(
            _contribution("ART_EXOSKELETAL_SUPPORT", FunctionalDomain.STRUCTURE, ("exoskeletal_support_hook",), ("ART_GROWTH_RENEWAL_CONSTRAINT", "ART_SCALING_CONSTRAINT"), "Supports external structural protection within explicit growth and scaling limits."),
            _contribution("ART_SEGMENTED_APPENDAGES", FunctionalDomain.LOCOMOTION, ("segmented_appendage_specialization",), ("ART_COORDINATION_MAINTENANCE_COST",), "Supports specialized segmented appendages with coordination and maintenance costs."),
            _contribution("ART_LOCAL_STRENGTH_TO_MASS", FunctionalDomain.STRUCTURE, ("local_strength_to_mass_hook",), ("ART_SCALING_CONSTRAINT",), "Supports favorable local strength-to-mass regimes without assuming unrestricted large-body scaling."),
        ),
        tradeoffs=(
            _tradeoff("ART_GROWTH_RENEWAL_CONSTRAINT", FunctionalDomain.STRUCTURE, ("growth_requires_surface_renewal",), "External structural layers complicate continuous growth."),
            _tradeoff("ART_SCALING_CONSTRAINT", FunctionalDomain.STRUCTURE, ("size_scaling_constraint",), "Structural and exchange performance changes strongly with body scale."),
            _tradeoff("ART_COORDINATION_MAINTENANCE_COST", FunctionalDomain.METABOLISM, ("appendage_coordination_cost",), "Additional specialized appendages increase control and maintenance burden."),
        ),
        sensor_modalities=("chemical", "vibration", "compound_visual_hook"),
        provenance=OriginPackageProvenance(("STAGE4C_CANONICAL_FUNCTIONAL_SOURCE",)),
    ),
    OriginPackage(
        package_id="ORG_FUNGAL_PLANT_MICROBIAL_SYMBIOSIS",
        family=OriginFamily.FUNGAL_PLANT_MICROBIAL,
        display_name="Fungal/plant/microbial symbiosis package",
        source_scope="Non-animal-derived symbiosis, substrate processing, supplemental energy capture and modular-growth motifs.",
        earliest_phase_id="B1",
        contributions=(
            _contribution("FPM_SYMBIOTIC_PROCESSING", FunctionalDomain.BIOCHEMISTRY, ("symbiotic_metabolic_processing",), ("FPM_SYMBIONT_DEPENDENCE",), "Supports metabolic functions delegated to maintained symbiotic systems."),
            _contribution("FPM_SUBSTRATE_DETOX", FunctionalDomain.BIOCHEMISTRY, ("specialized_substrate_processing",), ("FPM_SUBSTRATE_SPECIFICITY",), "Supports processing of selected substrates rather than universal toxin immunity."),
            _contribution("FPM_SUPPLEMENTAL_ENERGY_CAPTURE", FunctionalDomain.METABOLISM, ("supplemental_environmental_energy_capture",), ("FPM_LOW_POWER_DENSITY", "FPM_EXPOSURE_DEPENDENCE"), "Provides supplemental environmental energy capture that cannot replace high-power metabolism by default."),
            _contribution("FPM_MODULAR_TISSUE_GROWTH", FunctionalDomain.REGENERATION, ("modular_growth_repair_hook",), ("FPM_SLOW_GROWTH_LOAD",), "Supports modular repair/growth with time and feedstock requirements."),
        ),
        tradeoffs=(
            _tradeoff("FPM_SYMBIONT_DEPENDENCE", FunctionalDomain.BIOCHEMISTRY, ("symbiont_ecology_dependency",), "Symbiotic functions depend on maintaining compatible partner populations."),
            _tradeoff("FPM_SUBSTRATE_SPECIFICITY", FunctionalDomain.BIOCHEMISTRY, ("narrow_substrate_specificity",), "Specialized processing works on limited chemical classes."),
            _tradeoff("FPM_LOW_POWER_DENSITY", FunctionalDomain.METABOLISM, ("low_power_density",), "Environmental energy capture supplies limited power per unit area/volume."),
            _tradeoff("FPM_EXPOSURE_DEPENDENCE", FunctionalDomain.ENVIRONMENT, ("energy_capture_exposure_requirement",), "Environmental capture requires access to the relevant external energy source."),
            _tradeoff("FPM_SLOW_GROWTH_LOAD", FunctionalDomain.REGENERATION, ("slow_growth_or_high_feedstock_load",), "Modular growth remains constrained by time and available material."),
        ),
        sensor_modalities=("chemical", "light_hook", "moisture_hook"),
        provenance=OriginPackageProvenance(("STAGE4C_CANONICAL_FUNCTIONAL_SOURCE",)),
    ),
    OriginPackage(
        package_id="ORG_SYNTHETIC_BIOLOGY_PLATFORM",
        family=OriginFamily.SYNTHETIC_BIOLOGY,
        display_name="Synthetic biology platform package",
        source_scope="Constructed biological modules, scaffold tissues, engineered biochemical pathways and interface motifs.",
        earliest_phase_id="B0",
        contributions=(
            _contribution("SYN_ENGINEERED_BIOCHEMISTRY", FunctionalDomain.BIOCHEMISTRY, ("engineered_biochemical_module",), ("SYN_FEEDSTOCK_DEPENDENCE", "SYN_COMPATIBILITY_RISK"), "Supports deliberately constructed biochemical functions with feedstock and integration limits."),
            _contribution("SYN_SCAFFOLD_TISSUE", FunctionalDomain.STRUCTURE, ("engineered_scaffold_tissue",), ("SYN_REPAIR_FEEDSTOCK",), "Supports constructed structural tissue whose repair depends on compatible materials."),
            _contribution("SYN_BIOSENSOR_INTERFACE", FunctionalDomain.SENSOR_HOOK, ("biosensor_interface_hook",), ("SYN_CALIBRATION_MAINTENANCE",), "Provides a Stage-5-compatible sensor interface hook without defining sensor response curves."),
            _contribution("SYN_MODULAR_ORGAN_SUPPORT", FunctionalDomain.REGENERATION, ("modular_organ_support_hook",), ("SYN_SYSTEM_INTEGRATION_RISK",), "Supports modular biological subsystems with explicit integration-failure risk."),
        ),
        tradeoffs=(
            _tradeoff("SYN_FEEDSTOCK_DEPENDENCE", FunctionalDomain.METABOLISM, ("specialized_feedstock_dependency",), "Constructed pathways may depend on substrates uncommon in ordinary metabolism."),
            _tradeoff("SYN_COMPATIBILITY_RISK", FunctionalDomain.BIOCHEMISTRY, ("biochemical_compatibility_risk",), "Engineered pathways can interact poorly with other biological modules."),
            _tradeoff("SYN_REPAIR_FEEDSTOCK", FunctionalDomain.REGENERATION, ("specialized_repair_material_requirement",), "Engineered scaffolds may require specific repair materials."),
            _tradeoff("SYN_CALIBRATION_MAINTENANCE", FunctionalDomain.SENSOR_HOOK, ("interface_calibration_requirement",), "Sensor interfaces require biological calibration/maintenance."),
            _tradeoff("SYN_SYSTEM_INTEGRATION_RISK", FunctionalDomain.REGENERATION, ("system_integration_failure_risk",), "Modular subsystems can fail if regulatory integration breaks down."),
        ),
        sensor_modalities=("biosensor_hook",),
        provenance=OriginPackageProvenance(("STAGE4C_CANONICAL_FUNCTIONAL_SOURCE",)),
    ),
)


def build_canonical_origin_registry() -> OriginPackageRegistry:
    registry = OriginPackageRegistry()
    for package in CANONICAL_ORIGIN_PACKAGES:
        registry.register(package)
    return registry


def validate_origin_bound_geneline(record: GenelineRecord, registry: OriginPackageRegistry) -> None:
    validate_geneline_record(record)
    if record.origin_packages.status != LinkStatus.RESOLVED:
        raise ValueError("GENELINE_ORIGIN_PACKAGES_NOT_RESOLVED")
    if len(record.origin_packages.package_refs) != len(set(record.origin_packages.package_refs)):
        raise ValueError("GENELINE_DUPLICATE_ORIGIN_PACKAGE_REF")

    if record.provenance.origin_phase_id not in _PHASE_ORDER:
        raise ValueError("GENELINE_ORIGIN_PHASE_UNKNOWN")
    lineage_order = _PHASE_ORDER[record.provenance.origin_phase_id]
    for ref in record.origin_packages.package_refs:
        package = registry.get(ref)
        if _PHASE_ORDER[package.earliest_phase_id] > lineage_order:
            raise ValueError(f"ORIGIN_PACKAGE_NOT_AVAILABLE_AT_LINEAGE_PHASE:{ref}")


def bind_origin_packages(
    record: GenelineRecord,
    package_refs: Tuple[str, ...],
    registry: OriginPackageRegistry,
) -> GenelineRecord:
    if not package_refs:
        raise ValueError("GENELINE_ORIGIN_PACKAGE_BINDING_EMPTY")
    if len(package_refs) != len(set(package_refs)):
        raise ValueError("GENELINE_DUPLICATE_ORIGIN_PACKAGE_REF")
    for ref in package_refs:
        registry.get(ref)

    # Origin membership is a set-like fact. Canonical ordering prevents caller
    # order from becoming accidental biological meaning.
    canonical_refs = tuple(sorted(package_refs))
    bound = replace(record, origin_packages=OriginPackageLink(LinkStatus.RESOLVED, canonical_refs))
    validate_origin_bound_geneline(bound, registry)
    return bound


def build_origin_design_space(
    record: GenelineRecord,
    registry: OriginPackageRegistry,
) -> OriginDesignSpace:
    """Expose all source-supported options without selecting phenotype.

    The design space deliberately preserves every package/contribution/tradeoff
    as a separate candidate. It does not average, rank, merge or auto-express
    traits. Later stages may reason over these candidates under their own rules.
    """
    validate_origin_bound_geneline(record, registry)
    candidates: list[OriginContributionCandidate] = []
    for ref in record.origin_packages.package_refs:
        package = registry.get(ref)
        tradeoffs = {item.tradeoff_id: item for item in package.tradeoffs}
        for contribution in package.contributions:
            required = tuple(tradeoffs[item] for item in contribution.required_tradeoff_refs)
            candidates.append(
                OriginContributionCandidate(
                    package_id=package.package_id,
                    family=package.family,
                    contribution=contribution,
                    required_tradeoffs=required,
                )
            )
    candidates.sort(key=lambda item: (item.package_id, item.contribution.contribution_id))
    return OriginDesignSpace(record.lineage_id, record.origin_packages.package_refs, tuple(candidates))
