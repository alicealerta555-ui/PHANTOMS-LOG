
def clamp(v,a,b): return max(a,min(b,v))
def evidence_record(kind, subject_id, source_actor_id, observed_at, received_at, confidence, event_id):
    return {"kind":kind,"subject_id":subject_id,"source_actor_id":source_actor_id,"observed_at":int(observed_at),
            "received_at":int(received_at),"confidence":clamp(int(confidence),0,100),"event_id":event_id}
def valid_evidence(e):
    req={"kind","subject_id","source_actor_id","observed_at","received_at","confidence","event_id"}
    return req.issubset(e) and bool(e["source_actor_id"]) and bool(e["event_id"]) and int(e["received_at"])>=int(e["observed_at"])
def evidence_score(records):
    valid=[r for r in records if valid_evidence(r)]
    if not valid:return 0
    # Corroboration helps, but repeated claims never become certainty.
    best=max(int(r["confidence"]) for r in valid)
    distinct=len({(r["source_actor_id"],r["event_id"]) for r in valid})
    return clamp(best + max(0,distinct-1)*8,0,95)
def legal_case_candidate(law, jurisdiction_id, accused_actor_id, causal_event_id, evidence):
    score=evidence_score(evidence)
    return {"kind":"LEGAL_CASE_CANDIDATE","law_id":law["id"],"jurisdiction_id":jurisdiction_id,
            "accused_actor_id":accused_actor_id,"causal_event_id":causal_event_id,"evidence_score":score,
            "threshold":int(law["evidence_threshold"]),"actionable":score>=int(law["evidence_threshold"]),
            "authority_required":True}
def reputation_delta(current, delta):
    out=dict(current)
    for k,v in delta.items(): out[k]=clamp(int(out.get(k,0))+int(v),-100,100)
    return out
def enforcement_proposals(case, law):
    if not case.get("actionable"): return []
    return [{"kind":"ENFORCEMENT_PROPOSAL","response":r,"law_id":law["id"],
             "causal_event_id":case["causal_event_id"],"authority_required":True} for r in law.get("responses",[])]
