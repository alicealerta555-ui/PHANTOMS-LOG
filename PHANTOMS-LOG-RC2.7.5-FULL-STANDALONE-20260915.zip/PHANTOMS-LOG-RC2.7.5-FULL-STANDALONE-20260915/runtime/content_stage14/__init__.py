from .law import *
