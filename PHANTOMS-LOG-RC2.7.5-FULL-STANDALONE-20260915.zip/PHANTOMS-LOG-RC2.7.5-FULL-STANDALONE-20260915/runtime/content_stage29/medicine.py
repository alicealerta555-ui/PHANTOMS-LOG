
def clamp(v,a,b): return max(a,min(b,v))

def infection_candidate(condition_id, subject_actor_id, exposure_event_id, route, exposed_at, source_actor_id=None):
    if not condition_id or not subject_actor_id or not exposure_event_id or not route:
        return None
    return {
        "kind":"INFECTION_CANDIDATE",
        "condition_id":condition_id,
        "subject_actor_id":subject_actor_id,
        "exposure_event_id":exposure_event_id,
        "route":route,
        "exposed_at":int(exposed_at),
        "source_actor_id":source_actor_id,
        "authority_required":True
    }

def diagnosis_candidate(subject_actor_id, condition_hypothesis, method, evidence_count, contradiction_count, diagnosed_at):
    confidence=int(method.get("base_confidence",0))
    confidence += max(0,int(evidence_count))*5
    confidence -= max(0,int(contradiction_count))*10
    confidence=clamp(confidence,0,100)
    return {
        "kind":"DIAGNOSIS_CANDIDATE",
        "subject_actor_id":subject_actor_id,
        "condition_hypothesis":condition_hypothesis,
        "method_id":method["id"],
        "confidence":confidence,
        "diagnosed_at":int(diagnosed_at),
        "confirmed_truth":False,
        "authority_required":True
    }

def treatment_candidate(subject_actor_id, treatment, resources_available, elapsed_min, diagnosis_confidence, causal_event_id):
    if int(elapsed_min)<=0 or not bool(resources_available):
        return None
    effective_bp=int(treatment.get("effect_bp",0))
    if "correct_diagnosis" in treatment.get("requires",[]):
        effective_bp=effective_bp*clamp(int(diagnosis_confidence),0,100)//100
    return {
        "kind":"TREATMENT_CANDIDATE",
        "subject_actor_id":subject_actor_id,
        "treatment_id":treatment["id"],
        "elapsed_min":int(elapsed_min),
        "effect_bp":clamp(effective_bp,0,10000),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def progression_projection(current_load, progression_per_day, elapsed_min, treatment_effect_bp=0):
    days=max(0,int(elapsed_min))/1440.0
    growth=int(round(float(progression_per_day)*days))
    treated=growth*max(0,10000-int(treatment_effect_bp))//10000
    return clamp(int(current_load)+treated,0,100)

def recovery_projection(current_load, recovery_rate_per_day, elapsed_min):
    days=max(0,int(elapsed_min))/1440.0
    reduction=int(round(float(recovery_rate_per_day)*days))
    return clamp(int(current_load)-reduction,0,100)

def chronic_consequence_candidate(condition_id, subject_actor_id, residual_load, chronic_risk_bp, causal_event_id):
    if int(residual_load)<=0 or int(chronic_risk_bp)<=0:
        return None
    return {
        "kind":"CHRONIC_HEALTH_CONSEQUENCE_CANDIDATE",
        "condition_id":condition_id,
        "subject_actor_id":subject_actor_id,
        "residual_load":clamp(int(residual_load),0,100),
        "risk_bp":clamp(int(chronic_risk_bp),0,10000),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }
