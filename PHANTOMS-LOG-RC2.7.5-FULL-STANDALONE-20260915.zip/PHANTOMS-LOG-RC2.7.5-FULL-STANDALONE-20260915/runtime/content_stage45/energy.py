
def clamp(v,a,b): return max(a,min(b,v))

def generation_output(max_output, condition=100, resource_factor=100):
    return max(0, int(round(max(0,float(max_output))*clamp(int(condition),0,100)/100.0*clamp(int(resource_factor),0,100)/100.0)))

def fuel_generation_candidate(generator_id, output_requested, max_output, fuel_available, fuel_per_unit, causal_event_id):
    if not generator_id or float(output_requested)<=0 or float(fuel_per_unit)<=0:
        return None
    output=min(max(0,float(output_requested)),max(0,float(max_output)))
    max_by_fuel=max(0,float(fuel_available))/float(fuel_per_unit)
    actual=min(output,max_by_fuel)
    if actual<=0:
        return None
    return {
        "kind":"FUEL_GENERATION_CANDIDATE",
        "generator_id":generator_id,
        "output":round(actual,4),
        "fuel_consumed":round(actual*float(fuel_per_unit),4),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def storage_charge(current, incoming, capacity, charge_limit):
    cur=clamp(int(current),0,int(capacity))
    add=min(max(0,int(incoming)),max(0,int(charge_limit)),max(0,int(capacity)-cur))
    return {"stored":cur+add,"accepted":add,"rejected":max(0,int(incoming)-add)}

def storage_discharge(current, requested, discharge_limit):
    cur=max(0,int(current))
    out=min(cur,max(0,int(requested)),max(0,int(discharge_limit)))
    return {"remaining":cur-out,"delivered":out,"unmet":max(0,int(requested)-out)}

def grid_delivery(supply,demand,line_capacity,condition=100,loss_bp=0):
    raw=min(max(0,int(supply)),max(0,int(demand)),max(0,int(line_capacity)))
    raw=raw*clamp(int(condition),0,100)//100
    loss=raw*clamp(int(loss_bp),0,10000)//10000
    delivered=max(0,raw-loss)
    return {"sent":raw,"loss":loss,"delivered":delivered,"unmet":max(0,int(demand)-delivered)}

def load_shedding(requests, available_supply):
    supply=max(0,int(available_supply))
    ordered=sorted(requests,key=lambda r:int(r.get("priority_weight",0)),reverse=True)
    result=[]
    for r in ordered:
        demand=max(0,int(r.get("demand",0)))
        served=min(supply,demand)
        result.append({"consumer_id":r.get("consumer_id"),"served":served,"shed":demand-served})
        supply-=served
    return {"allocations":result,"remaining_supply":supply}

def network_state(condition, load_ratio_bp=0):
    c=clamp(int(condition),0,100)
    lr=max(0,int(load_ratio_bp))
    if c<=0: return "DESTROYED"
    if c<20: return "FAILED"
    if lr>10000: return "OVERLOADED"
    if c<60: return "DEGRADED"
    return "OPERATIONAL"

def outage_candidate(outage_id, affected_node_ids, cause_ref, started_at, causal_event_id):
    if not outage_id or not affected_node_ids or not cause_ref:
        return None
    return {
        "kind":"OUTAGE_CANDIDATE",
        "outage_id":outage_id,
        "affected_node_ids":list(affected_node_ids),
        "cause_ref":cause_ref,
        "started_at":int(started_at),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }
