# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from enum import Enum
import hashlib
import json
from typing import Tuple

from runtime.stage4b import GenelineRecord
from runtime.stage4c import OriginFamily, OriginPackageRegistry, validate_origin_bound_geneline


class BranchClass(str, Enum):
    SAPIENT = "SAPIENT"
    SEMI_SAPIENT = "SEMI_SAPIENT"
    FERAL = "FERAL"
    SYNTHETIC = "SYNTHETIC"
    DRIFT = "DRIFT"


class CognitiveBranch(str, Enum):
    UNASSESSED = "UNASSESSED"
    SAPIENT = "SAPIENT"
    SEMI_SAPIENT = "SEMI_SAPIENT"


@dataclass(frozen=True)
class CognitiveAssessment:
    branch: CognitiveBranch
    evidence_refs: Tuple[str, ...] = ()
    scope_note: str = ""


@dataclass(frozen=True)
class DevelopmentalBranchEvidence:
    feral_evidence_refs: Tuple[str, ...] = ()
    synthetic_evidence_refs: Tuple[str, ...] = ()
    drift_evidence_refs: Tuple[str, ...] = ()


@dataclass(frozen=True)
class BranchProvenance:
    source_refs: Tuple[str, ...]
    authority_domain: str = "WORLD_TRUTH"


@dataclass(frozen=True)
class BranchProfile:
    lineage_id: str
    cognitive: CognitiveAssessment
    developmental: DevelopmentalBranchEvidence
    provenance: BranchProvenance


@dataclass(frozen=True)
class BranchClassification:
    lineage_id: str
    branch_classes: Tuple[BranchClass, ...]
    cognitive_branch: CognitiveBranch
    is_feral: bool
    is_synthetic: bool
    is_drift: bool
    rationale_codes: Tuple[str, ...]


_BRANCH_ORDER = {
    BranchClass.SAPIENT: 0,
    BranchClass.SEMI_SAPIENT: 1,
    BranchClass.FERAL: 2,
    BranchClass.SYNTHETIC: 3,
    BranchClass.DRIFT: 4,
}

_DRIFT_PHASES = {"B5", "B6"}
_FERAL_PHASES = {"B4", "B5", "B6"}


def _validate_id(value: str, code: str) -> None:
    if not value or value.strip() != value or any(ch.isspace() for ch in value):
        raise ValueError(code)


def _validate_refs(values: Tuple[str, ...], *, duplicate: str, invalid: str) -> None:
    if len(values) != len(set(values)):
        raise ValueError(duplicate)
    for value in values:
        _validate_id(value, invalid)


def _synthetic_package_refs(lineage: GenelineRecord, registry: OriginPackageRegistry) -> Tuple[str, ...]:
    refs = []
    for package_ref in lineage.origin_packages.package_refs:
        if registry.get(package_ref).family == OriginFamily.SYNTHETIC_BIOLOGY:
            refs.append(package_ref)
    return tuple(sorted(refs))


def validate_branch_profile(
    lineage: GenelineRecord,
    profile: BranchProfile,
    origin_registry: OriginPackageRegistry,
) -> None:
    validate_origin_bound_geneline(lineage, origin_registry)
    if profile.lineage_id != lineage.lineage_id:
        raise ValueError("BRANCH_PROFILE_LINEAGE_MISMATCH")
    if profile.provenance.authority_domain != "WORLD_TRUTH":
        raise ValueError("BRANCH_PROVENANCE_MUST_BE_WORLD_TRUTH")
    if not profile.provenance.source_refs:
        raise ValueError("BRANCH_PROVENANCE_SOURCE_REQUIRED")
    _validate_refs(
        profile.provenance.source_refs,
        duplicate="BRANCH_PROVENANCE_DUPLICATE_SOURCE_REF",
        invalid="BRANCH_PROVENANCE_SOURCE_REF_INVALID",
    )

    cognitive = profile.cognitive
    _validate_refs(
        cognitive.evidence_refs,
        duplicate="COGNITIVE_EVIDENCE_DUPLICATE_REF",
        invalid="COGNITIVE_EVIDENCE_REF_INVALID",
    )
    if cognitive.branch == CognitiveBranch.UNASSESSED:
        if cognitive.evidence_refs:
            raise ValueError("COGNITIVE_UNASSESSED_WITH_EVIDENCE")
    else:
        if not cognitive.evidence_refs:
            raise ValueError("COGNITIVE_CLASS_REQUIRES_EVIDENCE")
        if not cognitive.scope_note.strip():
            raise ValueError("COGNITIVE_ASSESSMENT_SCOPE_REQUIRED")

    dev = profile.developmental
    _validate_refs(dev.feral_evidence_refs, duplicate="FERAL_EVIDENCE_DUPLICATE_REF", invalid="FERAL_EVIDENCE_REF_INVALID")
    _validate_refs(dev.synthetic_evidence_refs, duplicate="SYNTHETIC_EVIDENCE_DUPLICATE_REF", invalid="SYNTHETIC_EVIDENCE_REF_INVALID")
    _validate_refs(dev.drift_evidence_refs, duplicate="DRIFT_EVIDENCE_DUPLICATE_REF", invalid="DRIFT_EVIDENCE_REF_INVALID")

    # FERAL is a developmental/ecological ancestry label. It is not inferred
    # from cognitive class, morphology, aggression or lack of institutions in
    # the current scene. For a static lineage branch it requires post-control-
    # failure developmental evidence.
    if dev.feral_evidence_refs and lineage.provenance.origin_phase_id not in _FERAL_PHASES:
        raise ValueError("FERAL_BRANCH_BACKDATED_BEFORE_POST_CONTROL_DEVELOPMENT")

    # SYNTHETIC is source-history, not an intelligence class. A static lineage
    # may only receive it when its Stage-4C provenance actually includes a
    # synthetic-biology source package.
    synthetic_refs = _synthetic_package_refs(lineage, origin_registry)
    if dev.synthetic_evidence_refs and not synthetic_refs:
        raise ValueError("SYNTHETIC_BRANCH_WITHOUT_SYNTHETIC_ORIGIN")

    # DRIFT is an evolutionary-history branch and may not be backdated into
    # directed-control phases. It says nothing about cognition or morality.
    if dev.drift_evidence_refs and lineage.provenance.origin_phase_id not in _DRIFT_PHASES:
        raise ValueError("DRIFT_BRANCH_BACKDATED_BEFORE_FREE_DRIFT")


def classify_branch(
    lineage: GenelineRecord,
    profile: BranchProfile,
    origin_registry: OriginPackageRegistry,
) -> BranchClassification:
    validate_branch_profile(lineage, profile, origin_registry)
    classes: list[BranchClass] = []
    rationale: list[str] = []

    if profile.cognitive.branch == CognitiveBranch.SAPIENT:
        classes.append(BranchClass.SAPIENT)
        rationale.append("COGNITIVE_SAPIENCE_EVIDENCE_PRESENT")
    elif profile.cognitive.branch == CognitiveBranch.SEMI_SAPIENT:
        classes.append(BranchClass.SEMI_SAPIENT)
        rationale.append("COGNITIVE_SEMI_SAPIENCE_EVIDENCE_PRESENT")
    else:
        rationale.append("COGNITIVE_STATUS_UNASSESSED")

    if profile.developmental.feral_evidence_refs:
        classes.append(BranchClass.FERAL)
        rationale.append("POST_CONTROL_FERAL_DEVELOPMENT_EVIDENCE_PRESENT")
    if profile.developmental.synthetic_evidence_refs:
        classes.append(BranchClass.SYNTHETIC)
        rationale.append("SYNTHETIC_BIOLOGY_SOURCE_HISTORY_PRESENT")
    if profile.developmental.drift_evidence_refs:
        classes.append(BranchClass.DRIFT)
        rationale.append("FREE_DRIFT_ANCESTRY_EVIDENCE_PRESENT")

    ordered = tuple(sorted(classes, key=lambda item: _BRANCH_ORDER[item]))
    return BranchClassification(
        lineage_id=lineage.lineage_id,
        branch_classes=ordered,
        cognitive_branch=profile.cognitive.branch,
        is_feral=BranchClass.FERAL in ordered,
        is_synthetic=BranchClass.SYNTHETIC in ordered,
        is_drift=BranchClass.DRIFT in ordered,
        rationale_codes=tuple(rationale),
    )


class BranchProfileRegistry:
    def __init__(self) -> None:
        self._records: dict[str, tuple[BranchProfile, BranchClassification]] = {}

    def register(
        self,
        lineage: GenelineRecord,
        profile: BranchProfile,
        origin_registry: OriginPackageRegistry,
    ) -> BranchClassification:
        if lineage.lineage_id in self._records:
            raise ValueError(f"BRANCH_PROFILE_DUPLICATE_LINEAGE:{lineage.lineage_id}")
        classification = classify_branch(lineage, profile, origin_registry)
        self._records[lineage.lineage_id] = (profile, classification)
        return classification

    def get(self, lineage_id: str) -> tuple[BranchProfile, BranchClassification]:
        try:
            return self._records[lineage_id]
        except KeyError as exc:
            raise KeyError(f"BRANCH_PROFILE_NOT_FOUND:{lineage_id}") from exc

    def ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._records))

    def canonical_payload(self) -> list[dict]:
        payload = []
        for lineage_id in self.ids():
            profile, classification = self._records[lineage_id]
            normalized = replace(
                profile,
                cognitive=replace(profile.cognitive, evidence_refs=tuple(sorted(profile.cognitive.evidence_refs))),
                developmental=DevelopmentalBranchEvidence(
                    tuple(sorted(profile.developmental.feral_evidence_refs)),
                    tuple(sorted(profile.developmental.synthetic_evidence_refs)),
                    tuple(sorted(profile.developmental.drift_evidence_refs)),
                ),
                provenance=replace(profile.provenance, source_refs=tuple(sorted(profile.provenance.source_refs))),
            )
            payload.append({"profile": asdict(normalized), "classification": asdict(classification)})
        return payload

    def canonical_digest(self) -> str:
        raw = json.dumps(self.canonical_payload(), sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def __len__(self) -> int:
        return len(self._records)
