# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

"""Full-version historical Stage 8: regions, biomes, travel, information infrastructure and populations."""

from dataclasses import dataclass
import copy, heapq, json
from pathlib import Path
from typing import Any, Mapping, Sequence

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal, ValidationResult, Verdict
from runtime.stage3c.isolation import RunSession
from runtime.stage9.authority import AuthorityDecision, AuthorityStatus
from runtime.stage9.effects import AuthorityDomain, EffectPrecondition, EffectProposal, EffectType, PreconditionType

STAGE8_RUNTIME_KEY='__content_stage8_world__'

class Stage8WorldError(RuntimeError): pass

@dataclass(frozen=True, slots=True)
class TravelPlan:
    origin_location_id:str
    destination_location_id:str
    route_ids:tuple[str,...]
    location_path:tuple[str,...]
    travel_seconds:int

@dataclass(frozen=True, slots=True)
class InformationPath:
    origin_region_id:str
    destination_region_id:str
    channel:str
    infrastructure_ids:tuple[str,...]
    latency_seconds:int

@dataclass(frozen=True, slots=True)
class RegionSnapshot:
    region_id:str
    biome_tags:tuple[str,...]
    conditions:Mapping[str,Any]
    populations:Mapping[str,int]

@dataclass(frozen=True, slots=True)
class Stage8Snapshot:
    run_uuid:str
    state_revision:int
    regions:Mapping[str,RegionSnapshot]
    infrastructure_states:Mapping[str,str]

class Stage8WorldCatalog:
    def __init__(self,raw:Mapping[str,Any],world:Mapping[str,Any]):
        self.raw=copy.deepcopy(dict(raw)); self.world=copy.deepcopy(dict(world)); self.validate()
        self.regions={r['region_id']:copy.deepcopy(r) for r in self.raw['regions']}
        self.routes={r['route_id']:copy.deepcopy(r) for r in self.raw['routes']}
        self.infrastructure={i['infrastructure_id']:copy.deepcopy(i) for i in self.raw['infrastructure']}
        self.locations={x['location_id']:copy.deepcopy(x) for x in self.world['locations']}
    @classmethod
    def load(cls,path:Path,world:Mapping[str,Any])->'Stage8WorldCatalog': return cls(json.loads(Path(path).read_text(encoding='utf-8')),world)
    def validate(self)->None:
        if self.raw.get('schema')!='PH4NT0M5-L0G_STAGE8_WORLD_V1': raise Stage8WorldError('STAGE8_SCHEMA_INVALID')
        regions=self.raw.get('regions'); routes=self.raw.get('routes'); infra=self.raw.get('infrastructure'); pops=self.raw.get('initial_populations')
        if not isinstance(regions,list) or not regions: raise Stage8WorldError('STAGE8_REGIONS_REQUIRED')
        rids=[r.get('region_id') for r in regions]
        if None in rids or len(rids)!=len(set(rids)): raise Stage8WorldError('STAGE8_REGION_IDS_INVALID')
        known=set(rids); locs={x.get('location_id'):x for x in self.world.get('locations',[])}
        if not locs or any(x.get('region_id') not in known for x in locs.values()): raise Stage8WorldError('STAGE8_LOCATION_REGION_COVERAGE_INVALID')
        route_ids=set(); pairs=set()
        for r in routes or []:
            rid=r.get('route_id'); a=r.get('from_location_id'); b=r.get('to_location_id'); sec=r.get('travel_seconds')
            if not rid or rid in route_ids or a not in locs or b not in locs or a==b or isinstance(sec,bool) or not isinstance(sec,int) or sec<=0: raise Stage8WorldError('STAGE8_ROUTE_INVALID')
            route_ids.add(rid); pairs.add(frozenset((a,b)))
        for a,x in locs.items():
            for b in x.get('connections',[]):
                if frozenset((a,b)) not in pairs: raise Stage8WorldError(f'STAGE8_WORLD_CONNECTION_ROUTE_MISSING:{a}:{b}')
        iids=set()
        for i in infra or []:
            if not i.get('infrastructure_id') or i['infrastructure_id'] in iids or not set(i.get('region_ids',()))<=known: raise Stage8WorldError('STAGE8_INFRASTRUCTURE_INVALID')
            if i.get('initial_state') not in {'ACTIVE','DEGRADED','OFFLINE','BLOCKED'}: raise Stage8WorldError('STAGE8_INFRASTRUCTURE_STATE_INVALID')
            if not i.get('channels') or not isinstance(i.get('base_latency_seconds'),int) or i['base_latency_seconds']<0: raise Stage8WorldError('STAGE8_INFRASTRUCTURE_CHANNEL_INVALID')
            iids.add(i['infrastructure_id'])
        if set(pops or {})!=known: raise Stage8WorldError('STAGE8_POPULATION_REGION_COVERAGE_INVALID')
        for bucket in pops.values():
            if not isinstance(bucket,Mapping) or any(isinstance(v,bool) or not isinstance(v,int) or v<0 for v in bucket.values()): raise Stage8WorldError('STAGE8_POPULATION_INVALID')
    def region_for_location(self,location_id:str)->str:
        try:return self.locations[location_id]['region_id']
        except KeyError as exc: raise Stage8WorldError(f'LOCATION_UNKNOWN:{location_id}') from exc
    def adjacent_regions(self)->set[frozenset[str]]:
        out=set()
        for r in self.routes.values():
            a=self.region_for_location(r['from_location_id']); b=self.region_for_location(r['to_location_id'])
            if a!=b: out.add(frozenset((a,b)))
        return out

class Stage8WorldView:
    def __init__(self,session:RunSession,catalog:Stage8WorldCatalog): self.session=session; self.catalog=catalog
    def _root(self)->dict[str,Any]:
        raw=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,STAGE8_RUNTIME_KEY)
        if raw is None:return {'run_uuid':self.session.identity.run_uuid,'population_overrides':{},'infrastructure_states':{},'migration_ledger':[]}
        if not isinstance(raw,Mapping) or raw.get('run_uuid')!=self.session.identity.run_uuid: raise Stage8WorldError('STAGE8_STATE_CORRUPT')
        return copy.deepcopy(dict(raw))
    def snapshot(self)->Stage8Snapshot:
        root=self._root(); pops=copy.deepcopy(self.catalog.raw['initial_populations'])
        for rid,bucket in dict(root.get('population_overrides',{})).items(): pops[rid]=copy.deepcopy(dict(bucket))
        regions={}
        for rid,r in sorted(self.catalog.regions.items()): regions[rid]=RegionSnapshot(rid,tuple(r['biome_tags']),copy.deepcopy(dict(r['conditions'])),copy.deepcopy(dict(pops[rid])))
        states={iid:str(root.get('infrastructure_states',{}).get(iid,i['initial_state'])) for iid,i in self.catalog.infrastructure.items()}
        return Stage8Snapshot(self.session.identity.run_uuid,self.session.store.revision,regions,states)
    def population(self,region_id:str,population_id:str)->int: return int(self.snapshot().regions[region_id].populations.get(population_id,0))

class Stage8TravelEngine:
    def __init__(self,catalog:Stage8WorldCatalog): self.catalog=catalog
    def plan(self,origin_location_id:str,destination_location_id:str)->TravelPlan:
        if origin_location_id not in self.catalog.locations or destination_location_id not in self.catalog.locations: raise Stage8WorldError('TRAVEL_LOCATION_UNKNOWN')
        if origin_location_id==destination_location_id:return TravelPlan(origin_location_id,destination_location_id,(),(origin_location_id,),0)
        graph={k:[] for k in self.catalog.locations}
        for r in self.catalog.routes.values():
            a,b=r['from_location_id'],r['to_location_id']; sec=int(r['travel_seconds']); rid=r['route_id']; graph[a].append((b,sec,rid)); graph[b].append((a,sec,rid))
        q=[(0,origin_location_id,(),(origin_location_id,))]; best={origin_location_id:0}
        while q:
            sec,node,rids,path=heapq.heappop(q)
            if sec!=best.get(node): continue
            if node==destination_location_id:return TravelPlan(origin_location_id,destination_location_id,rids,path,sec)
            for nxt,cost,rid in graph[node]:
                new=sec+cost
                if new<best.get(nxt,10**18): best[nxt]=new; heapq.heappush(q,(new,nxt,rids+(rid,),path+(nxt,)))
        raise Stage8WorldError('TRAVEL_ROUTE_UNREACHABLE')

    def proposals(self, session:RunSession, actor_instance_id:str, origin_location_id:str, destination_location_id:str, *, resolution_id:str, source_action_id:str, effect_prefix:str)->tuple[EffectProposal,...]:
        plan=self.plan(origin_location_id,destination_location_id)
        if plan.travel_seconds<=0: return ()
        revision=session.store.revision
        move=EffectProposal(effect_id=f'{effect_prefix}:move',run_uuid=session.identity.run_uuid,resolution_id=resolution_id,source_action_id=source_action_id,effect_type=EffectType.MOVE_ACTOR,target_ref=actor_instance_id,
            payload={'actor_instance_id':actor_instance_id,'destination_location_id':destination_location_id},authority_domain=AuthorityDomain.ACTOR_STATE,expected_state_revision=revision,
            preconditions=(EffectPrecondition(PreconditionType.SOURCE_LOCATION_EQUALS,actor_instance_id,'location_ref',origin_location_id),))
        time=EffectProposal(effect_id=f'{effect_prefix}:time',run_uuid=session.identity.run_uuid,resolution_id=resolution_id,source_action_id=source_action_id,effect_type=EffectType.ADVANCE_WORLD_TIME,target_ref=None,
            payload={'seconds':plan.travel_seconds},authority_domain=AuthorityDomain.WORLD_TIME,expected_state_revision=revision)
        return (move,time)

class Stage8InformationEngine:
    def __init__(self,catalog:Stage8WorldCatalog,view:Stage8WorldView): self.catalog=catalog; self.view=view
    def route(self,origin_region_id:str,destination_region_id:str,channel:str)->InformationPath:
        if origin_region_id not in self.catalog.regions or destination_region_id not in self.catalog.regions: raise Stage8WorldError('INFO_REGION_UNKNOWN')
        if origin_region_id==destination_region_id:return InformationPath(origin_region_id,destination_region_id,channel,(),0)
        states=self.view.snapshot().infrastructure_states; graph={r:[] for r in self.catalog.regions}
        for iid,i in self.catalog.infrastructure.items():
            state=states[iid]
            if state in {'OFFLINE','BLOCKED'} or channel not in i['channels']: continue
            factor=2 if state=='DEGRADED' else 1; cost=int(i['base_latency_seconds'])*factor; regs=list(i['region_ids'])
            for a in regs:
                for b in regs:
                    if a!=b: graph[a].append((b,cost,iid))
        q=[(0,origin_region_id,())]; best={origin_region_id:0}
        while q:
            sec,node,path=heapq.heappop(q)
            if sec!=best.get(node):continue
            if node==destination_region_id:return InformationPath(origin_region_id,destination_region_id,channel,path,sec)
            for nxt,cost,iid in graph[node]:
                new=sec+cost
                if new<best.get(nxt,10**18):best[nxt]=new;heapq.heappush(q,(new,nxt,path+(iid,)))
        raise Stage8WorldError('INFORMATION_CHANNEL_UNAVAILABLE')

class Stage8MigrationEngine:
    def __init__(self,session:RunSession,catalog:Stage8WorldCatalog,view:Stage8WorldView): self.session=session; self.catalog=catalog; self.view=view
    def proposal(self,*,from_region_id:str,to_region_id:str,population_id:str,amount:int,cause_ref:str,resolution_id:str,source_action_id:str,effect_id:str)->EffectProposal:
        if not cause_ref: raise Stage8WorldError('MIGRATION_CAUSE_REQUIRED')
        if frozenset((from_region_id,to_region_id)) not in self.catalog.adjacent_regions(): raise Stage8WorldError('MIGRATION_ROUTE_REQUIRED')
        current=self.view.population(from_region_id,population_id); max_ppm=int(self.catalog.raw['migration']['max_fraction_ppm_per_event']); max_amount=max(1,(current*max_ppm)//1_000_000) if current else 0
        if isinstance(amount,bool) or not isinstance(amount,int) or amount<=0 or amount>current or amount>max_amount: raise Stage8WorldError('MIGRATION_AMOUNT_EXCEEDS_BOUND')
        return EffectProposal(effect_id=effect_id,run_uuid=self.session.identity.run_uuid,resolution_id=resolution_id,source_action_id=source_action_id,effect_type=EffectType.POPULATION_TRANSFER,target_ref=from_region_id,
            payload={'from_region_id':from_region_id,'to_region_id':to_region_id,'population_id':population_id,'amount':amount,'cause_ref':cause_ref},authority_domain=AuthorityDomain.REGION,expected_state_revision=self.session.store.revision)
    def infrastructure_proposal(self,*,infrastructure_id:str,new_state:str,cause_ref:str,resolution_id:str,source_action_id:str,effect_id:str)->EffectProposal:
        if infrastructure_id not in self.catalog.infrastructure: raise Stage8WorldError('INFRASTRUCTURE_UNKNOWN')
        return EffectProposal(effect_id=effect_id,run_uuid=self.session.identity.run_uuid,resolution_id=resolution_id,source_action_id=source_action_id,effect_type=EffectType.INFRASTRUCTURE_STATE_CHANGE,target_ref=infrastructure_id,
            payload={'infrastructure_id':infrastructure_id,'new_state':new_state,'cause_ref':cause_ref},authority_domain=AuthorityDomain.REGION,expected_state_revision=self.session.store.revision)

class Stage8CommitAdapter:
    def __init__(self,session:RunSession,catalog:Stage8WorldCatalog): self.session=session; self.catalog=catalog; self.view=Stage8WorldView(session,catalog)
    def apply_many(self,decisions:Sequence[AuthorityDecision],*,commit_id:str,event_id:str)->CommitRecord|ValidationResult:
        if not decisions: raise Stage8WorldError('STAGE8_DECISIONS_REQUIRED')
        revision=self.session.store.revision; raw=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,STAGE8_RUNTIME_KEY)
        root=copy.deepcopy(dict(raw)) if isinstance(raw,Mapping) else {'run_uuid':self.session.identity.run_uuid,'population_overrides':{},'infrastructure_states':{},'migration_ledger':[]}
        if root.get('run_uuid')!=self.session.identity.run_uuid: raise Stage8WorldError('RUN_ISOLATION_VIOLATION')
        snapshot=self.view.snapshot(); pops={rid:dict(r.populations) for rid,r in snapshot.regions.items()}; states=dict(snapshot.infrastructure_states); ledger=list(root.get('migration_ledger',[])); ids=[]
        for d in decisions:
            if d.status!=AuthorityStatus.ALLOW or d.commit_operation is None: raise Stage8WorldError('STAGE8_AUTHORITY_ALLOW_REQUIRED')
            op=d.commit_operation
            if op.approved_state_revision!=revision or op.authority_domain!=AuthorityDomain.REGION: raise Stage8WorldError('STAGE8_AUTHORITY_OR_REVISION_INVALID')
            p=dict(op.payload)
            if op.effect_type==EffectType.POPULATION_TRANSFER:
                fr,to,pid,amount=p['from_region_id'],p['to_region_id'],p['population_id'],int(p['amount'])
                if fr not in pops or to not in pops or pops[fr].get(pid,0)<amount: raise Stage8WorldError('MIGRATION_POPULATION_UNDERFLOW')
                pops[fr][pid]=int(pops[fr].get(pid,0))-amount; pops[to][pid]=int(pops[to].get(pid,0))+amount
                ledger.append({'effect_id':op.effect_id,**p})
            elif op.effect_type==EffectType.INFRASTRUCTURE_STATE_CHANGE:
                if p['infrastructure_id'] not in self.catalog.infrastructure: raise Stage8WorldError('INFRASTRUCTURE_UNKNOWN')
                states[p['infrastructure_id']]=p['new_state']
            else: raise Stage8WorldError('STAGE8_EFFECT_REQUIRED')
            ids.append(op.effect_id)
        root['population_overrides']=pops; root['infrastructure_states']=states; root['migration_ledger']=ledger
        delta=Delta(Domain.RUNTIME_STATE,STAGE8_RUNTIME_KEY,root,Authority.RULE_KERNEL,'CONTENT_S8_MUTATION',Mode.COMMIT,source_event_id=event_id,provenance='|'.join(f'EFFECT:{x}' for x in ids))
        result=self.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(delta,),event_id=event_id,cause='CONTENT_S8_ATOMIC_COMMIT',expected_state_revision=revision,commit_id=commit_id,effect_ids=tuple(ids)))
        if isinstance(result,ValidationResult) and result.verdict not in {Verdict.HOLD,Verdict.PASS}: raise Stage8WorldError('STAGE8_COMMIT_REJECTED')
        return result
