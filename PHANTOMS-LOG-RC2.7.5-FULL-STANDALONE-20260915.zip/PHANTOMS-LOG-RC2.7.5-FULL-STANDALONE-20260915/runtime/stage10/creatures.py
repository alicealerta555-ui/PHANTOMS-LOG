# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

"""Static creature profiles connecting Stage-4 biology/branching to Stage-5 senses.

Profiles are definitions only. They carry no run state and cannot mutate the world.
"""

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Iterable

from runtime.stage4e import BranchClass, CognitiveBranch


class Stage10CreatureError(ValueError):
    pass


_KNOWN_MODALITIES = frozenset({
    "visual", "auditory", "thermal", "chemical", "olfactory", "vibration",
    "tactile", "biosensor", "magnetic", "pressure", "moisture",
    "polarization", "vestibular",
})


@dataclass(frozen=True, slots=True)
class CreatureProfile:
    creature_profile_id: str
    display_name: str
    lineage_id: str
    branch_classes: tuple[BranchClass, ...]
    cognitive_branch: CognitiveBranch
    sense_modalities: tuple[str, ...]
    needs: tuple[str, ...]
    habitat_tags: tuple[str, ...]
    base_threat: int
    behavior_tags: tuple[str, ...]

    def __post_init__(self) -> None:
        for field in (self.creature_profile_id, self.display_name, self.lineage_id):
            if not isinstance(field, str) or not field.strip():
                raise Stage10CreatureError("CREATURE_IDENTITY_REQUIRED")
        if not self.branch_classes:
            raise Stage10CreatureError("CREATURE_BRANCH_CLASS_REQUIRED")
        if any(not isinstance(x, BranchClass) for x in self.branch_classes):
            raise Stage10CreatureError("CREATURE_BRANCH_CLASS_INVALID")
        if not isinstance(self.cognitive_branch, CognitiveBranch):
            raise Stage10CreatureError("CREATURE_COGNITIVE_BRANCH_INVALID")
        if not self.sense_modalities or any(x not in _KNOWN_MODALITIES for x in self.sense_modalities):
            raise Stage10CreatureError("CREATURE_SENSE_MODALITY_INVALID")
        if not self.needs or not self.habitat_tags:
            raise Stage10CreatureError("CREATURE_NEEDS_HABITAT_REQUIRED")
        if isinstance(self.base_threat, bool) or not isinstance(self.base_threat, int) or not 0 <= self.base_threat <= 10:
            raise Stage10CreatureError("CREATURE_BASE_THREAT_INVALID")
        # FERAL is developmental/ecological history, not a cognition shortcut.
        if BranchClass.FERAL in self.branch_classes and self.cognitive_branch == CognitiveBranch.SAPIENT:
            # This combination is allowed by Stage 4. Explicitly do nothing: the check exists
            # as a guard against future code that would equate FERAL with non-sapience.
            pass


class CreatureProfileRegistry:
    def __init__(self, profiles: Iterable[CreatureProfile] = ()) -> None:
        self._profiles: dict[str, CreatureProfile] = {}
        for profile in profiles:
            self.register(profile)

    def register(self, profile: CreatureProfile) -> None:
        if not isinstance(profile, CreatureProfile):
            raise Stage10CreatureError("CREATURE_PROFILE_REQUIRED")
        if profile.creature_profile_id in self._profiles:
            raise Stage10CreatureError("CREATURE_PROFILE_DUPLICATE")
        self._profiles[profile.creature_profile_id] = profile

    def get(self, creature_profile_id: str) -> CreatureProfile:
        try:
            return self._profiles[creature_profile_id]
        except KeyError as exc:
            raise Stage10CreatureError(f"CREATURE_PROFILE_NOT_FOUND:{creature_profile_id}") from exc

    def ids(self) -> tuple[str, ...]:
        return tuple(sorted(self._profiles))

    def __len__(self) -> int:
        return len(self._profiles)

    @classmethod
    def from_json(cls, path: Path) -> "CreatureProfileRegistry":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        if raw.get("schema") != "PH4NT0M5-L0G_CREATURE_PROFILES_V1" or not isinstance(raw.get("profiles"), list):
            raise Stage10CreatureError("CREATURE_CATALOG_SCHEMA_INVALID")
        out = cls()
        for item in raw["profiles"]:
            label = str(item["branch_class"])
            if label == "SAPIENT":
                branches=(BranchClass.SAPIENT,); cognitive=CognitiveBranch.SAPIENT
            elif label == "SEMI_SAPIENT":
                branches=(BranchClass.SEMI_SAPIENT,); cognitive=CognitiveBranch.SEMI_SAPIENT
            elif label == "SYNTHETIC":
                branches=(BranchClass.SYNTHETIC,); cognitive=CognitiveBranch.UNASSESSED
            elif label == "FERAL":
                branches=(BranchClass.FERAL,); cognitive=CognitiveBranch.UNASSESSED
            else:
                raise Stage10CreatureError("CREATURE_BRANCH_LABEL_INVALID")
            out.register(CreatureProfile(
                creature_profile_id=str(item["creature_profile_id"]),
                display_name=str(item["display_name"]),
                lineage_id=str(item["lineage_id"]),
                branch_classes=branches,
                cognitive_branch=cognitive,
                sense_modalities=tuple(str(x) for x in item["sense_modalities"]),
                needs=tuple(str(x) for x in item["needs"]),
                habitat_tags=tuple(str(x) for x in item["habitat_tags"]),
                base_threat=int(item["base_threat"]),
                behavior_tags=tuple(str(x) for x in item["behavior_tags"]),
            ))
        return out
