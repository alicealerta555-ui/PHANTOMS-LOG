# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

"""Causal ecology/recolonization planning. No blind respawn and no direct state writes."""

from dataclasses import dataclass
from hashlib import sha256
from typing import Mapping, Sequence

from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType
from runtime.stage9.scheduler import SchedulerCommitAdapter
from runtime.stage9.authority import StateAuthority, AuthorityStatus
from runtime.stage9.world_time import WorldClock
from runtime.stage3c.isolation import RunSession
from runtime.stage9.actors import RunActorRegistry
from .creatures import CreatureProfile
from .state import DungeonRuntimeState, Stage10WorldView


class Stage10EcologyError(RuntimeError): pass


@dataclass(frozen=True, slots=True)
class RecolonizationPlan:
    dungeon_id: str
    population_id: str
    due_world_time: int
    score: int
    cause_ref: str
    scheduled_event_id: str


class RecolonizationPlanner:
    def __init__(self, session: RunSession, registry: RunActorRegistry, *, minimum_vacancy_seconds: int = 3600) -> None:
        self._session=session; self._authority=StateAuthority(session,actor_registry=registry); self._scheduler=SchedulerCommitAdapter(session); self._min=minimum_vacancy_seconds

    @staticmethod
    def score(attractors: Mapping[str,int], profile: CreatureProfile) -> int:
        # Bounded transparent score; habitat compatibility is causal, not random respawn.
        total=sum(max(0,int(v)) for v in attractors.values())
        if "water" in profile.needs: total += max(0,int(attractors.get("water",0)))
        if "shelter" in profile.needs or "nest" in profile.needs: total += max(0,int(attractors.get("shelter",0)))
        return total

    def plan(self, dungeon: DungeonRuntimeState, definition: Mapping[str,object], candidates: Sequence[CreatureProfile], *, cause_ref: str) -> RecolonizationPlan | None:
        if dungeon.occupancy!="VACANT": return None
        now=WorldClock(self._session).seconds
        if now-dungeon.since_world_time < self._min: return None
        attractors=definition.get("attractors",{})
        ranked=[]
        for p in candidates:
            if not any(tag in {"underground","industrial","wilderness"} for tag in p.habitat_tags): continue
            ranked.append((self.score(attractors,p),p.creature_profile_id,p))
        if not ranked: return None
        ranked.sort(key=lambda x:(-x[0],x[1])); score,pop,_=ranked[0]
        if score<=0: return None
        due=now+max(300,7200-score*300)
        token=sha256(f"{self._session.identity.run_uuid}|{dungeon.dungeon_id}|{pop}|{dungeon.since_world_time}|{cause_ref}".encode()).hexdigest()[:20]
        return RecolonizationPlan(dungeon.dungeon_id,pop,due,score,cause_ref,f"event:recolonize:{token}")

    def schedule(self, plan: RecolonizationPlan):
        payload={"dungeon_id":plan.dungeon_id,"population_id":plan.population_id,"cause_ref":plan.cause_ref}
        effect=EffectProposal(effect_id=f"effect:{plan.scheduled_event_id}:schedule",run_uuid=self._session.identity.run_uuid,resolution_id=f"resolution:{plan.scheduled_event_id}",source_action_id=f"ecology:{plan.dungeon_id}",effect_type=EffectType.SCHEDULE_EVENT,target_ref=plan.scheduled_event_id,payload={"scheduled_event_id":plan.scheduled_event_id,"event_type":"CONTENT_S10_RECOLONIZE","due_world_time":plan.due_world_time,"payload":payload,"sequence_key":plan.scheduled_event_id},authority_domain=AuthorityDomain.SCHEDULER,expected_state_revision=self._session.store.revision)
        decision=self._authority.authorize(effect)
        if decision.status!=AuthorityStatus.ALLOW: raise Stage10EcologyError("RECOLONIZATION_SCHEDULE_REJECTED")
        return self._scheduler.apply(decision,commit_id=f"commit:{plan.scheduled_event_id}:schedule",event_id=f"CONTENT_S10:SCHEDULE:{plan.scheduled_event_id}")


class RecolonizationProcessor:
    """Consume one due recolonization event through ordinary semantic authority/commit.

    If the world effects were already committed before a crash, the persistent effect
    ledger prevents recomputation/double population and only the pending scheduler event
    is cancelled.
    """
    def __init__(self, session: RunSession, registry: RunActorRegistry, stage10_adapter) -> None:
        from runtime.stage9.idempotency import CommitIdempotencyLedger
        self._session=session; self._registry=registry; self._authority=StateAuthority(session,actor_registry=registry)
        self._scheduler=SchedulerCommitAdapter(session); self._adapter=stage10_adapter; self._idem=CommitIdempotencyLedger(session)

    def process_one_due(self):
        batch=self._scheduler.queue.dispatch_due()
        event=next((e for e in batch.events if e.event_type=='CONTENT_S10_RECOLONIZE'),None)
        if event is None: return None
        dungeon_id=str(event.payload.get('dungeon_id','')); population_id=str(event.payload.get('population_id','')); cause_ref=str(event.payload.get('cause_ref',''))
        if not dungeon_id or not population_id or not cause_ref: raise Stage10EcologyError('RECOLONIZATION_EVENT_PAYLOAD_INVALID')
        occ_eid=f'effect:{event.scheduled_event_id}:occupancy'; pop_eid=f'effect:{event.scheduled_event_id}:population'
        if not (self._idem.effect_committed(occ_eid) and self._idem.effect_committed(pop_eid)):
            rev=self._session.store.revision
            effects=(
                EffectProposal(effect_id=occ_eid,run_uuid=self._session.identity.run_uuid,resolution_id=f'resolution:{event.scheduled_event_id}',source_action_id=f'event:{event.scheduled_event_id}',effect_type=EffectType.DUNGEON_OCCUPANCY_SET,target_ref=dungeon_id,payload={'dungeon_id':dungeon_id,'occupancy':'OCCUPIED','population_id':population_id,'cause_ref':cause_ref},authority_domain=AuthorityDomain.DUNGEON,expected_state_revision=rev),
                EffectProposal(effect_id=pop_eid,run_uuid=self._session.identity.run_uuid,resolution_id=f'resolution:{event.scheduled_event_id}',source_action_id=f'event:{event.scheduled_event_id}',effect_type=EffectType.ECOLOGY_POPULATION_DELTA,target_ref=dungeon_id,payload={'site_id':dungeon_id,'population_id':population_id,'delta':1,'cause_ref':cause_ref},authority_domain=AuthorityDomain.ECOLOGY,expected_state_revision=rev),
            )
            decisions=self._authority.authorize_many(effects)
            if any(d.status!=AuthorityStatus.ALLOW for d in decisions): raise Stage10EcologyError('RECOLONIZATION_AUTHORITY_REJECTED')
            self._adapter.apply_many(decisions,commit_id=f'commit:{event.scheduled_event_id}:world',event_id=f'CONTENT_S10:RECOLONIZE:{event.scheduled_event_id}')
        # Consume the scheduler event only after the semantic effects are committed.
        cancel=EffectProposal(effect_id=f'effect:{event.scheduled_event_id}:cancel',run_uuid=self._session.identity.run_uuid,resolution_id=f'resolution:{event.scheduled_event_id}:cancel',source_action_id=f'event:{event.scheduled_event_id}',effect_type=EffectType.CANCEL_EVENT,target_ref=event.scheduled_event_id,payload={'scheduled_event_id':event.scheduled_event_id},authority_domain=AuthorityDomain.SCHEDULER,expected_state_revision=self._session.store.revision)
        decision=self._authority.authorize(cancel)
        if decision.status!=AuthorityStatus.ALLOW: raise Stage10EcologyError('RECOLONIZATION_CANCEL_REJECTED')
        return self._scheduler.apply(decision,commit_id=f'commit:{event.scheduled_event_id}:cancel',event_id=f'CONTENT_S10:CANCEL:{event.scheduled_event_id}')
