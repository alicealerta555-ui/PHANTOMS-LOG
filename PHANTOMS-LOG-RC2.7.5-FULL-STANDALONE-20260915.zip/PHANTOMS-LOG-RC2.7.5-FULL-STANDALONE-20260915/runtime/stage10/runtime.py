# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

"""CONTENT-S10 runtime façade over Runtime-I9 authority/commit contracts."""

from dataclasses import dataclass
from typing import Mapping, Sequence

from runtime.stage3c.isolation import RunSession
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import AuthorityStatus, StateAuthority
from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType
from runtime.stage9.world_time import WorldClock
from .creatures import CreatureProfileRegistry
from .encounter import EncounterDecision, EncounterEngine
from .ecology import RecolonizationPlan, RecolonizationPlanner, RecolonizationProcessor
from .state import Stage10CommitAdapter, Stage10WorldSnapshot, Stage10WorldView


class Stage10RuntimeError(RuntimeError): pass


class Stage10Runtime:
    def __init__(self, session: RunSession, registry: RunActorRegistry, *, dungeons: Sequence[Mapping], creatures: CreatureProfileRegistry) -> None:
        self._session=session; self._registry=registry; self._dungeons={str(x['dungeon_id']):dict(x) for x in dungeons}; self._creatures=creatures
        self._authority=StateAuthority(session,actor_registry=registry); self._adapter=Stage10CommitAdapter(session,dungeon_definitions=dungeons)
        self._planner=RecolonizationPlanner(session,registry); self._processor=RecolonizationProcessor(session,registry,self._adapter); self._encounters=EncounterEngine()

    @property
    def view(self)->Stage10WorldView: return self._adapter.view
    def snapshot(self)->Stage10WorldSnapshot: return self._adapter.view.snapshot()

    def _effect(self, *, effect_id: str, source_action_id: str, effect_type: EffectType, target_ref: str, payload: Mapping, domain: AuthorityDomain) -> EffectProposal:
        return EffectProposal(effect_id=effect_id,run_uuid=self._session.identity.run_uuid,resolution_id=f'resolution:{source_action_id}',source_action_id=source_action_id,effect_type=effect_type,target_ref=target_ref,payload=dict(payload),authority_domain=domain,expected_state_revision=self._session.store.revision)

    def record_vacancy(self, dungeon_id: str, *, cause_ref: str, source_ref: str) -> object:
        if dungeon_id not in self._dungeons: raise Stage10RuntimeError('DUNGEON_NOT_FOUND')
        now=WorldClock(self._session).seconds; source=f's10:vacancy:{dungeon_id}:{now}'
        effects=(
            self._effect(effect_id=f'effect:{source}:occupancy',source_action_id=source,effect_type=EffectType.DUNGEON_OCCUPANCY_SET,target_ref=dungeon_id,payload={'dungeon_id':dungeon_id,'occupancy':'VACANT','cause_ref':cause_ref},domain=AuthorityDomain.DUNGEON),
            self._effect(effect_id=f'effect:{source}:trace',source_action_id=source,effect_type=EffectType.DUNGEON_TRACE_APPEND,target_ref=dungeon_id,payload={'dungeon_id':dungeon_id,'trace_id':f'trace:{source}','trace_type':'VACANCY','source_ref':source_ref,'world_time':now,'detail':cause_ref},domain=AuthorityDomain.DUNGEON),
        )
        decisions=self._authority.authorize_many(effects)
        if any(d.status!=AuthorityStatus.ALLOW for d in decisions): raise Stage10RuntimeError('DUNGEON_VACANCY_AUTHORITY_REJECTED')
        return self._adapter.apply_many(decisions,commit_id=f'commit:{source}',event_id=f'CONTENT_S10:{source}')

    def adjust_resource(self, site_id: str, resource_key: str, delta: int, *, cause_ref: str) -> object:
        source=f's10:resource:{site_id}:{resource_key}:{self._session.store.revision}'
        effect=self._effect(effect_id=f'effect:{source}',source_action_id=source,effect_type=EffectType.ECOLOGY_RESOURCE_DELTA,target_ref=site_id,payload={'site_id':site_id,'resource_key':resource_key,'delta':delta,'cause_ref':cause_ref},domain=AuthorityDomain.ECOLOGY)
        decision=self._authority.authorize(effect)
        if decision.status!=AuthorityStatus.ALLOW: raise Stage10RuntimeError('ECOLOGY_RESOURCE_AUTHORITY_REJECTED')
        return self._adapter.apply_many((decision,),commit_id=f'commit:{source}',event_id=f'CONTENT_S10:{source}')

    def plan_recolonization(self, dungeon_id: str, *, cause_ref: str) -> RecolonizationPlan | None:
        if dungeon_id not in self._dungeons: raise Stage10RuntimeError('DUNGEON_NOT_FOUND')
        state=self.snapshot().dungeons[dungeon_id]
        profiles=tuple(self._creatures.get(x) for x in self._creatures.ids())
        return self._planner.plan(state,self._dungeons[dungeon_id],profiles,cause_ref=cause_ref)

    def schedule_recolonization(self, plan: RecolonizationPlan): return self._planner.schedule(plan)
    def process_due_recolonization(self): return self._processor.process_one_due()

    def decide_encounter(self, creature_profile_id: str, actor_context, *, target_ref: str, resource_pressure: int=0, injury_pressure: int=0, target_threat: int=0) -> EncounterDecision:
        return self._encounters.decide(self._creatures.get(creature_profile_id),actor_context,target_ref=target_ref,resource_pressure=resource_pressure,injury_pressure=injury_pressure,target_threat=target_threat)
