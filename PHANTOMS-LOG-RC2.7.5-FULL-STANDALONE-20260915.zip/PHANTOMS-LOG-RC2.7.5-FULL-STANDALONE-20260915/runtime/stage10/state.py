# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

"""Canonical CONTENT-S10 dungeon/ecology runtime state.

Read-only projections derive defaults from static content. Mutations require semantic
EffectProposal -> StateAuthority -> this adapter -> the existing CommitKernel.
"""

from dataclasses import dataclass
import copy
from typing import Any, Mapping, Sequence

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal, ValidationResult, Verdict
from runtime.stage3c.isolation import RunSession
from runtime.stage9.authority import AuthorityDecision, AuthorityStatus
from runtime.stage9.effects import AuthorityDomain, EffectType
from runtime.stage9.world_time import WorldClock


STAGE10_RUNTIME_KEY = "__content_stage10__"


class Stage10StateError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class DungeonRuntimeState:
    dungeon_id: str
    occupancy: str
    population_id: str | None
    since_world_time: int
    traces: tuple[Mapping[str, Any], ...]


@dataclass(frozen=True, slots=True)
class EcologySiteState:
    site_id: str
    resources: Mapping[str, int]
    populations: Mapping[str, int]


@dataclass(frozen=True, slots=True)
class Stage10WorldSnapshot:
    run_uuid: str
    state_revision: int
    dungeons: Mapping[str, DungeonRuntimeState]
    ecology: Mapping[str, EcologySiteState]


class Stage10WorldView:
    def __init__(self, session: RunSession, *, dungeon_definitions: Sequence[Mapping[str, Any]] = ()) -> None:
        self._session=session
        self._defs={str(x["dungeon_id"]):copy.deepcopy(dict(x)) for x in dungeon_definitions}

    def _root(self) -> dict[str, Any]:
        raw=self._session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,STAGE10_RUNTIME_KEY)
        if raw is None:
            return {"run_uuid":self._session.identity.run_uuid,"dungeons":{},"ecology":{}}
        if not isinstance(raw,Mapping) or raw.get("run_uuid")!=self._session.identity.run_uuid:
            raise Stage10StateError("STAGE10_STATE_CORRUPT")
        if not isinstance(raw.get("dungeons"),Mapping) or not isinstance(raw.get("ecology"),Mapping):
            raise Stage10StateError("STAGE10_STATE_SCHEMA_INVALID")
        return copy.deepcopy(dict(raw))

    def snapshot(self) -> Stage10WorldSnapshot:
        root=self._root(); now=WorldClock(self._session).seconds
        dungeons={}
        for did,definition in sorted(self._defs.items()):
            raw=dict(root["dungeons"].get(did,{}))
            occupancy=raw.get("occupancy",definition.get("initial_occupancy","VACANT"))
            population=raw.get("population_id",definition.get("initial_population_id"))
            since=int(raw.get("since_world_time",0))
            traces=tuple(copy.deepcopy(raw.get("traces",[])))
            dungeons[did]=DungeonRuntimeState(did,str(occupancy),population,since,traces)
        # Preserve dynamically known sites even when no static dungeon definition exists.
        for did,raw0 in sorted(root["dungeons"].items()):
            if did in dungeons: continue
            raw=dict(raw0); dungeons[did]=DungeonRuntimeState(did,str(raw.get("occupancy","VACANT")),raw.get("population_id"),int(raw.get("since_world_time",now)),tuple(copy.deepcopy(raw.get("traces",[]))))
        ecology={}
        for sid,raw0 in sorted(root["ecology"].items()):
            raw=dict(raw0)
            resources={str(k):int(v) for k,v in dict(raw.get("resources",{})).items()}
            populations={str(k):int(v) for k,v in dict(raw.get("populations",{})).items()}
            ecology[sid]=EcologySiteState(sid,resources,populations)
        return Stage10WorldSnapshot(self._session.identity.run_uuid,self._session.store.revision,dungeons,ecology)


class Stage10CommitAdapter:
    def __init__(self, session: RunSession, *, dungeon_definitions: Sequence[Mapping[str, Any]] = ()) -> None:
        self._session=session
        self._view=Stage10WorldView(session,dungeon_definitions=dungeon_definitions)

    @property
    def view(self) -> Stage10WorldView: return self._view

    def apply_many(self, decisions: Sequence[AuthorityDecision], *, commit_id: str, event_id: str) -> CommitRecord | ValidationResult:
        if not decisions: raise Stage10StateError("STAGE10_DECISIONS_REQUIRED")
        revision=self._session.store.revision
        raw=self._session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,STAGE10_RUNTIME_KEY)
        root=copy.deepcopy(dict(raw)) if isinstance(raw,Mapping) else {"run_uuid":self._session.identity.run_uuid,"dungeons":{},"ecology":{}}
        if root.get("run_uuid")!=self._session.identity.run_uuid: raise Stage10StateError("RUN_ISOLATION_VIOLATION")
        effect_ids=[]; now=WorldClock(self._session).seconds
        for decision in decisions:
            if decision.status!=AuthorityStatus.ALLOW or decision.commit_operation is None: raise Stage10StateError("STAGE10_AUTHORITY_ALLOW_REQUIRED")
            op=decision.commit_operation
            if op.approved_state_revision!=revision: raise Stage10StateError("STALE_STATE_REVISION")
            if op.authority_domain not in {AuthorityDomain.DUNGEON,AuthorityDomain.ECOLOGY}: raise Stage10StateError("STAGE10_AUTHORITY_DOMAIN_REQUIRED")
            p=dict(op.payload); effect_ids.append(op.effect_id)
            if op.effect_type==EffectType.DUNGEON_OCCUPANCY_SET:
                did=p["dungeon_id"]; current=copy.deepcopy(dict(root["dungeons"].get(did,{})))
                current["occupancy"]=p["occupancy"]; current["population_id"]=p.get("population_id")
                current["since_world_time"]=now; current["cause_ref"]=p["cause_ref"]; current.setdefault("traces",[])
                root["dungeons"][did]=current
            elif op.effect_type==EffectType.DUNGEON_TRACE_APPEND:
                did=p["dungeon_id"]; current=copy.deepcopy(dict(root["dungeons"].get(did,{}))); traces=list(current.get("traces",[]))
                if any(t.get("trace_id")==p["trace_id"] for t in traces): raise Stage10StateError("DUNGEON_TRACE_DUPLICATE")
                traces.append({k:copy.deepcopy(v) for k,v in p.items() if k!="dungeon_id"}); current["traces"]=traces
                current.setdefault("occupancy","VACANT"); current.setdefault("population_id",None); current.setdefault("since_world_time",now)
                root["dungeons"][did]=current
            elif op.effect_type in {EffectType.ECOLOGY_RESOURCE_DELTA,EffectType.ECOLOGY_POPULATION_DELTA}:
                sid=p["site_id"]; current=copy.deepcopy(dict(root["ecology"].get(sid,{}))); field="resources" if op.effect_type==EffectType.ECOLOGY_RESOURCE_DELTA else "populations"; key=p["resource_key"] if field=="resources" else p["population_id"]
                bucket=copy.deepcopy(dict(current.get(field,{}))); value=int(bucket.get(key,0))+int(p["delta"])
                if value<0: raise Stage10StateError("ECOLOGY_UNDERFLOW")
                bucket[key]=value; current[field]=bucket; current.setdefault("resources",{}); current.setdefault("populations",{}); current["last_cause_ref"]=p["cause_ref"]; root["ecology"][sid]=current
            else:
                raise Stage10StateError(f"STAGE10_EFFECT_TYPE_REQUIRED:{op.effect_type.value}")
        delta=Delta(Domain.RUNTIME_STATE,STAGE10_RUNTIME_KEY,root,Authority.RULE_KERNEL,"CONTENT_S10_MUTATION",Mode.COMMIT,source_event_id=event_id,provenance="|".join(f"EFFECT:{x}" for x in effect_ids))
        proposal=Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(delta,),event_id=event_id,cause="CONTENT_S10_ATOMIC_COMMIT",expected_state_revision=revision,commit_id=commit_id,effect_ids=tuple(effect_ids))
        result=self._session.kernel.process(proposal)
        if isinstance(result,ValidationResult) and result.verdict not in {Verdict.HOLD,Verdict.PASS}: raise Stage10StateError("STAGE10_COMMIT_REJECTED:"+"|".join(result.reasons))
        return result
