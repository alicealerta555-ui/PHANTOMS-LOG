# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
from __future__ import annotations

"""Pure encounter behavior from actor-visible evidence only.

This module deliberately does not receive RunSession/StateStore/WorldTruth. It can be
used by deterministic stubs or as a pre-model policy feature without granting authority.
"""

from dataclasses import dataclass
from enum import Enum

from runtime.stage9.actor_context import ActorDecisionContext
from .creatures import CreatureProfile


class Stage10EncounterError(ValueError):
    pass


class EncounterStance(str, Enum):
    IGNORE = "IGNORE"
    APPROACH = "APPROACH"
    WITHDRAW = "WITHDRAW"
    THREATEN = "THREATEN"
    HUNT = "HUNT"
    COEXIST = "COEXIST"


@dataclass(frozen=True, slots=True)
class EncounterDecision:
    stance: EncounterStance
    target_ref: str | None
    reason_codes: tuple[str, ...]
    context_fingerprint: str


class EncounterEngine:
    def decide(
        self,
        profile: CreatureProfile,
        context: ActorDecisionContext,
        *,
        target_ref: str,
        resource_pressure: int = 0,
        injury_pressure: int = 0,
        target_threat: int = 0,
    ) -> EncounterDecision:
        if not isinstance(profile, CreatureProfile) or not isinstance(context, ActorDecisionContext):
            raise Stage10EncounterError("ENCOUNTER_INPUT_INVALID")
        for value in (resource_pressure, injury_pressure, target_threat):
            if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 10:
                raise Stage10EncounterError("ENCOUNTER_PRESSURE_INVALID")
        perceived = {p.subject_ref for p in context.perception}
        known = {k.knowledge_key for k in context.knowledge}
        if target_ref not in perceived:
            # No telepathy: absent perception cannot become an attack/approach decision.
            return EncounterDecision(EncounterStance.IGNORE, None, ("TARGET_NOT_PERCEIVED",), context.context_fingerprint)
        score = profile.base_threat + resource_pressure - injury_pressure - target_threat
        social = "social" in profile.behavior_tags
        if injury_pressure >= 6 or target_threat >= 7:
            stance=EncounterStance.WITHDRAW; reasons=("SELF_PRESERVATION",)
        elif social and any(key.startswith("relation:positive:") for key in known):
            stance=EncounterStance.COEXIST; reasons=("POSITIVE_RELATION_KNOWN",)
        elif score >= 8 and "food" in profile.needs:
            stance=EncounterStance.HUNT; reasons=("HIGH_RESOURCE_PRESSURE",)
        elif score >= 5:
            stance=EncounterStance.THREATEN; reasons=("TERRITORIAL_OR_RISK_PRESSURE",)
        elif social:
            stance=EncounterStance.APPROACH; reasons=("SOCIAL_INVESTIGATION",)
        else:
            stance=EncounterStance.IGNORE; reasons=("NO_CAUSAL_MOTIVE_TO_ENGAGE",)
        return EncounterDecision(stance,target_ref,reasons,context.context_fingerprint)
