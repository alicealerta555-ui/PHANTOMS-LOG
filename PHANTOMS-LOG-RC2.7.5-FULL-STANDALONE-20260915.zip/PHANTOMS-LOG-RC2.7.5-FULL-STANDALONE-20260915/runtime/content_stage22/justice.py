
def clamp(v,a,b): return max(a,min(b,v))

def evidence_item(evidence_class, source_actor_id, subject_actor_id, event_id, location_id, collected_at, confidence):
    return {
        "evidence_class":evidence_class,
        "source_actor_id":source_actor_id,
        "subject_actor_id":subject_actor_id,
        "event_id":event_id,
        "location_id":location_id,
        "collected_at":int(collected_at),
        "confidence":clamp(int(confidence),0,100)
    }

def valid_evidence(e, allowed_classes):
    req=("evidence_class","subject_actor_id","event_id","location_id","collected_at","confidence")
    if not all(k in e for k in req): return False
    if e["evidence_class"] not in allowed_classes: return False
    if not e.get("event_id") or not e.get("location_id"): return False
    return 0 <= int(e["confidence"]) <= 100

def investigation_score(records, evidence_defs):
    defs={d["id"]:d for d in evidence_defs}
    score=0
    seen=set()
    for r in records:
        d=defs.get(r.get("evidence_class"))
        if not d or not d.get("admissible",False): continue
        key=(r.get("source_actor_id"),r.get("event_id"),r.get("evidence_class"))
        if key in seen: continue
        seen.add(key)
        score += int(d["weight"])*int(r.get("confidence",0))//100
    return clamp(score,0,100)

def warrant_candidate(warrant_type, jurisdiction_id, law_id, subject_actor_id, evidence_score, threshold, causal_event_id):
    if not jurisdiction_id or not law_id: return None
    return {
        "kind":"WARRANT_CANDIDATE",
        "warrant_type":warrant_type,
        "jurisdiction_id":jurisdiction_id,
        "law_id":law_id,
        "subject_actor_id":subject_actor_id,
        "evidence_score":int(evidence_score),
        "threshold":int(threshold),
        "authorized":int(evidence_score)>=int(threshold),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def detention_proposal(subject_actor_id, warrant, causal_event_id):
    if not warrant or not warrant.get("authorized"): return None
    if warrant.get("warrant_type")!="WAR_DETENTION": return None
    return {
        "kind":"DETENTION_PROPOSAL",
        "subject_actor_id":subject_actor_id,
        "jurisdiction_id":warrant["jurisdiction_id"],
        "law_id":warrant["law_id"],
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def trial_candidate(subject_actor_id, jurisdiction_id, law_id, admissible_score, conviction_threshold, causal_event_id):
    score=int(admissible_score)
    threshold=int(conviction_threshold)
    outcome="CONVICTED" if score>=threshold else "ACQUITTED"
    return {
        "kind":"TRIAL_CANDIDATE",
        "subject_actor_id":subject_actor_id,
        "jurisdiction_id":jurisdiction_id,
        "law_id":law_id,
        "admissible_score":score,
        "conviction_threshold":threshold,
        "outcome":outcome,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def sentence_proposals(trial, responses):
    if not trial or trial.get("outcome")!="CONVICTED": return []
    return [{
        "kind":"LEGAL_SENTENCE_PROPOSAL",
        "response":r,
        "subject_actor_id":trial["subject_actor_id"],
        "jurisdiction_id":trial["jurisdiction_id"],
        "law_id":trial["law_id"],
        "causal_event_id":trial["causal_event_id"],
        "authority_required":True
    } for r in responses]
