
def clamp(v,a,b): return max(a,min(b,v))
def message_record(message_id,sender_id,content_ref,created_at):
    if not message_id or not sender_id or not content_ref: return None
    return {"message_id":message_id,"sender_id":sender_id,"content_ref":content_ref,"created_at":int(created_at)}
def transmission_candidate(message_id,channel_id,origin_id,destination_id,available,latency_min,causal_event_id):
    if not message_id or not channel_id or not origin_id or not destination_id or not available: return None
    return {"kind":"MESSAGE_TRANSMISSION_CANDIDATE","message_id":message_id,"channel_id":channel_id,
            "origin_id":origin_id,"destination_id":destination_id,"latency_min":max(0,int(latency_min)),
            "causal_event_id":causal_event_id,"authority_required":True}
def delivery_state(sent,route_ok,elapsed_min,latency_min):
    if not sent: return "NOT_SENT"
    if not route_ok: return "BLOCKED"
    return "DELIVERED" if int(elapsed_min)>=int(latency_min) else "IN_TRANSIT"
def network_capacity(requested,capacity,condition=100):
    eff=max(0,int(capacity))*clamp(int(condition),0,100)//100
    return min(max(0,int(requested)),eff)
def broadcast_reach(base_range,coverage_factor=100):
    return max(0,int(base_range))*clamp(int(coverage_factor),0,100)//100
def outage_candidate(network_id,cause_ref,affected_channels,started_at,causal_event_id):
    if not network_id or not cause_ref or not affected_channels: return None
    return {"kind":"COMM_OUTAGE_CANDIDATE","network_id":network_id,"cause_ref":cause_ref,
            "affected_channels":list(affected_channels),"started_at":int(started_at),
            "causal_event_id":causal_event_id,"authority_required":True}
