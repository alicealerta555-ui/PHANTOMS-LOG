
def verify_stage_presence(stage_numbers, present_numbers):
    present=set(int(x) for x in present_numbers)
    missing=[int(s) for s in stage_numbers if int(s) not in present]
    return {"ok":len(missing)==0,"missing":missing}
def verify_static_no_mutable_ids(texts):
    bad=[]
    for name,text in texts.items():
        low=text.lower()
        if "player_uuid" in low or "run_uuid" in low:
            bad.append(name)
    return {"ok":len(bad)==0,"violations":bad}
def closure_record(version, validated_tests, causal_invariants_ok):
    return {"version":version,"validated_tests":int(validated_tests),
            "causal_invariants_ok":bool(causal_invariants_ok),
            "status":"FROZEN_BASELINE" if causal_invariants_ok else "NOT_FROZEN"}
