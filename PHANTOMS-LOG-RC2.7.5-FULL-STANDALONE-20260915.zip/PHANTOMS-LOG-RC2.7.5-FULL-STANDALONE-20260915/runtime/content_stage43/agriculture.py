
def clamp(v,a,b): return max(a,min(b,v))

def crop_progress(elapsed_days, cycle_days):
    if int(cycle_days)<=0:
        return 0
    return clamp(int(round(max(0,float(elapsed_days))/float(cycle_days)*100)),0,100)

def projected_yield(base_yield_per_area, area, season_bp=10000, water_factor=100, labor_factor=100):
    base=max(0,float(base_yield_per_area))*max(0,float(area))
    season=max(0,int(season_bp))/10000.0
    water=clamp(int(water_factor),0,100)/100.0
    labor=clamp(int(labor_factor),0,100)/100.0
    return max(0,int(round(base*season*water*labor)))

def harvest_candidate(cycle_id, projected_yield_value, requested_harvest, harvested_at, causal_event_id):
    if not cycle_id or int(projected_yield_value)<0 or int(requested_harvest)<0:
        return None
    actual=min(int(projected_yield_value),int(requested_harvest))
    return {
        "kind":"HARVEST_CANDIDATE",
        "cycle_id":cycle_id,
        "projected_yield":int(projected_yield_value),
        "actual_harvest":actual,
        "harvested_at":int(harvested_at),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def livestock_pressure(feed_required,feed_available,water_required,water_available,care_factor=100):
    feed_short=max(0,int(feed_required)-int(feed_available))
    water_short=max(0,int(water_required)-int(water_available))
    care_penalty=100-clamp(int(care_factor),0,100)
    return clamp(feed_short*10 + water_short*10 + care_penalty,0,100)

def spoilage_projection(stock, loss_bp_per_day, elapsed_days):
    s=max(0,int(stock))
    if int(elapsed_days)<=0:
        return {"remaining":s,"lost":0}
    loss=int(round(s*max(0,int(loss_bp_per_day))/10000.0*int(elapsed_days)))
    loss=min(s,max(0,loss))
    return {"remaining":s-loss,"lost":loss}

def production_candidate(cycle_id, site_id, product_id, inputs_ok, labor_ok, elapsed_days, causal_event_id):
    if not cycle_id or not site_id or not product_id or int(elapsed_days)<=0:
        return None
    if not inputs_ok or not labor_ok:
        return None
    return {
        "kind":"AGRICULTURAL_PRODUCTION_CANDIDATE",
        "cycle_id":cycle_id,
        "site_id":site_id,
        "product_id":product_id,
        "elapsed_days":int(elapsed_days),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def seasonal_output(base_output, season_bp):
    return max(0,int(round(max(0,float(base_output))*max(0,int(season_bp))/10000.0)))
