
def clamp(v,a,b): return max(a,min(b,v))

def publication_record(publication_id,source_work_id,publisher_id,media_type,published_at,provenance):
    if not publication_id or not source_work_id or not publisher_id or not media_type:
        return None
    return {
        "publication_id":publication_id,
        "source_work_id":source_work_id,
        "publisher_id":publisher_id,
        "media_type":media_type,
        "published_at":int(published_at),
        "provenance":provenance,
        "truth_asserted_by_system":False
    }

def publication_reach(base_reach, copies_or_audience, channel_modifier_bp=10000):
    base=max(0,int(base_reach))
    scale=min(100,max(0,int(copies_or_audience))//5)
    reach=(base+scale)*max(0,int(channel_modifier_bp))//10000
    return clamp(reach,0,100)

def archive_access(archive_type, authorized=False, has_role=False, is_owner=False):
    mode=archive_type["access_mode"]
    if mode=="public": return True
    if mode=="permission": return bool(authorized)
    if mode=="role": return bool(has_role)
    if mode=="owner": return bool(is_owner)
    return False

def censorship_candidate(action, target_id, authority_actor_id, legal_or_org_basis, causal_event_id):
    if not action or not target_id or not authority_actor_id or not legal_or_org_basis:
        return None
    return {
        "kind":"CENSORSHIP_CANDIDATE",
        "action":action,
        "target_id":target_id,
        "authority_actor_id":authority_actor_id,
        "basis":legal_or_org_basis,
        "erases_actor_knowledge":False,
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def preservation_projection(condition, elapsed_days, environment_quality=100, maintenance=0):
    c=clamp(int(condition),0,100)
    if int(elapsed_days)<=0:
        return c
    env=clamp(int(environment_quality),0,100)
    maint=clamp(int(maintenance),0,100)
    loss=max(0,100-env-maint//2)*int(elapsed_days)//365
    return clamp(c-loss,0,100)

def record_state(condition):
    c=clamp(int(condition),0,100)
    if c<=0: return "LOST"
    if c<25: return "PARTIAL"
    if c<50: return "DAMAGED"
    if c<80: return "AGED"
    return "INTACT"

def archive_record(record_id,archive_id,source_id,stored_at,provenance,condition):
    if not record_id or not archive_id or not source_id or not provenance:
        return None
    return {
        "record_id":record_id,
        "archive_id":archive_id,
        "source_id":source_id,
        "stored_at":int(stored_at),
        "provenance":provenance,
        "condition":clamp(int(condition),0,100)
    }
