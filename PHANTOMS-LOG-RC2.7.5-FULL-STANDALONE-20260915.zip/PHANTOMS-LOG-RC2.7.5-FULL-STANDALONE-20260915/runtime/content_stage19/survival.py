
def clamp(v,a,b): return max(a,min(b,v))

def apply_need_drift(needs, minutes, activity_bp=10000, weather_exposure_bp=0, shelter_reduction_bp=0):
    out=dict(needs)
    m=max(0,int(minutes))
    out["hunger"]=clamp(int(out.get("hunger",0)) + (m*max(0,int(activity_bp))//10000)//180,0,100)
    out["thirst"]=clamp(int(out.get("thirst",0)) + (m*max(0,int(activity_bp))//10000)//120,0,100)
    out["fatigue"]=clamp(int(out.get("fatigue",0)) + m//90,0,100)
    effective=max(0,int(weather_exposure_bp)-max(0,int(shelter_reduction_bp)))
    out["exposure"]=clamp(int(out.get("exposure",0)) + (m*effective//10000)//60,0,100)
    return out

def consume_proposal(actor_id, item_id, current_qty, consumable, causal_event_id):
    if int(current_qty)<=0: return None
    return {"kind":"SURVIVAL_CONSUME_PROPOSAL","actor_id":actor_id,"item_id":item_id,
            "consume_qty":1,"reduces":dict(consumable.get("reduces",{})),
            "causal_event_id":causal_event_id,"authority_required":True}

def rest_projection(needs, minutes, rest_efficiency_bp=10000, safe=True):
    out=dict(needs)
    m=max(0,int(minutes))
    eff=max(0,int(rest_efficiency_bp))
    recovered=m*eff//10000
    out["fatigue"]=clamp(int(out.get("fatigue",0))-recovered//12,0,100)
    # Hunger/thirst continue to drift slowly while resting.
    out["hunger"]=clamp(int(out.get("hunger",0))+m//360,0,100)
    out["thirst"]=clamp(int(out.get("thirst",0))+m//300,0,100)
    return {"projected_needs":out,"safe":bool(safe),"elapsed_min":m,"authority_required":True}

def camp_setup_proposal(profile, actor_id, inventory, location_id, causal_event_id):
    for item,qty in profile.get("requires",{}).items():
        if int(inventory.get(item,0))<int(qty): return None
    return {"kind":"CAMP_SETUP_PROPOSAL","camp_id":profile["id"],"actor_id":actor_id,
            "location_id":location_id,"consume":dict(profile.get("requires",{})),
            "setup_min":int(profile["setup_min"]),"shelter_id":profile["shelter_id"],
            "causal_event_id":causal_event_id,"authority_required":True}

def survival_consequence_proposals(needs, definitions, actor_id, causal_event_id):
    out=[]
    for d in definitions:
        if int(needs.get(d["dimension"],0))>=int(d["threshold"]):
            out.append({"kind":"SURVIVAL_CONSEQUENCE_PROPOSAL","id":d["id"],"actor_id":actor_id,
                        "dimension":d["dimension"],"effects":list(d["effects"]),
                        "causal_event_id":causal_event_id,"authority_required":True})
    return out
