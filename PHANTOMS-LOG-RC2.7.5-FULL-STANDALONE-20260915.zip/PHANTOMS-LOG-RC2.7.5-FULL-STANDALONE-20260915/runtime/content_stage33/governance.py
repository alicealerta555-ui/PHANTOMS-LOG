
def clamp(v,a,b): return max(a,min(b,v))

def assess_tax(tax_def, basis_amount, jurisdiction_id, liable_id, assessed_at, causal_event_id):
    if not jurisdiction_id or not liable_id or float(basis_amount)<0:
        return None
    amount=int(round(float(basis_amount)*int(tax_def["rate_bp"])/10000.0))
    return {
        "kind":"TAX_ASSESSMENT_PROPOSAL",
        "tax_id":tax_def["id"],
        "jurisdiction_id":jurisdiction_id,
        "liable_id":liable_id,
        "basis_amount":float(basis_amount),
        "amount":max(0,amount),
        "assessed_at":int(assessed_at),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def budget_projection(opening_balance, revenue, spending, allow_deficit=False):
    opening=int(opening_balance)
    rev=max(0,int(revenue))
    spend=max(0,int(spending))
    if not allow_deficit and spend>opening+rev:
        spend=opening+rev
    return {
        "opening_balance":opening,
        "revenue":rev,
        "spending":spend,
        "closing_balance":opening+rev-spend
    }

def service_delivery(service_def, budget_available, demand):
    unit=max(1,int(service_def["budget_unit_cost"]))
    capacity=max(0,int(service_def["capacity"]))
    funded_capacity=max(0,int(budget_available))//unit
    effective_capacity=min(capacity,funded_capacity)
    served=min(max(0,int(demand)),effective_capacity)
    shortage=max(0,int(demand)-served)
    cost=served*unit
    return {
        "effective_capacity":effective_capacity,
        "served":served,
        "shortage":shortage,
        "cost":cost
    }

def legitimacy_delta(current, delta):
    out=dict(current)
    dims=("fairness","competence","security","service_quality","overall")
    for d in dims:
        out[d]=clamp(int(out.get(d,0))+int(delta.get(d,0)),-100,100)
    return out

def policy_proposal(government_id, policy_type, parameters, causal_event_id):
    if not government_id or not policy_type:
        return None
    return {
        "kind":"GOVERNANCE_POLICY_PROPOSAL",
        "government_id":government_id,
        "policy_type":policy_type,
        "parameters":dict(parameters or {}),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }

def public_spending_proposal(government_id, service_id, amount, available_balance, causal_event_id):
    if int(amount)<0 or int(available_balance)<0:
        return None
    if int(amount)>int(available_balance):
        return None
    return {
        "kind":"PUBLIC_SPENDING_PROPOSAL",
        "government_id":government_id,
        "service_id":service_id,
        "amount":int(amount),
        "causal_event_id":causal_event_id,
        "authority_required":True
    }
