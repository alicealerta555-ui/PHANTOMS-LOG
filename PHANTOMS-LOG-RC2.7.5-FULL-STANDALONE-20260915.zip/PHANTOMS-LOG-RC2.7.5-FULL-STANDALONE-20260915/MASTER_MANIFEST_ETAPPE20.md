# Master Manifest – through Etappe 20

Latest integrated layers:
- Etappe 18: Psychological State & Supportive Dialogue
- Etappe 19: Memory Compression, Salience & Lazy Simulation
- Etappe 20: NPC-to-NPC Social Life

Runtime schema: AdaptiveGameplayRuntime save schema 6.
Regression: 189 PASS.
