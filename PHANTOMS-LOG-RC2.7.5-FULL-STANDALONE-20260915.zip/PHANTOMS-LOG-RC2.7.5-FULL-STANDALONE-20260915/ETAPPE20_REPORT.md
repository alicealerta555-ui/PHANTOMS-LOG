# Etappe 20 – NPC-to-NPC Social Life

Implemented sparse NPC-to-NPC relationship edges, shared interests, friction, limited rumor transfer, group rituals, and offscreen relationship summaries. No all-to-all relationship matrix is created.
