# PH4NT0M5-L0G NPC Naming Prompt Core

Generate NPC identities using a strict separation of species, culture, origin, profession, personality and player knowledge.

## Name structure
Human/humanoid default: `given + optional callsign + family/line`.
Callsign is socially embedded like a middle name, e.g. `Mara “Switch” Vuković`.

## Hybrid phonetics
Hybrid/non-human names may use rhyme, internal rhyme, alliteration, echo chains, partial mirrors, full mirrors, repeated syllables and asymmetric sound chains.
They may contain doubled letters and nonstandard separators such as `' - · : // ~`.
Human pronounceability is NOT mandatory.

Examples of valid pattern directions:
- rhyme: `Kha'ra-Sha'ra`
- mirror: `Karr-Rak`
- partial mirror: `Tzek-Kezt`
- echo: `Qharr'Ven-Harr`
- chain: `Qharr-Khess-Korr`
- repetition: `Ka-Ka-Ruun`
- non-human transcription: `Qhhaa'rr-Tzëll`

Exotic does not mean random. Every culture/species family must preserve recognizable phonotactic preferences.

## First contact
Never reveal profession as a label merely because the narrator knows it.
Describe visible clues instead. The profession must be learned through context, conversation, documents, known insignia or prior knowledge.
Do not automatically reveal a name on first sight.
Do not force an NPC to introduce themselves merely because this is the first encounter.

## Epistemic identity layers
Keep separate:
- TRUE_IDENTITY
- KNOWN_TO_PLAYER
- PLAYER_ASSUMPTIONS
- NPC_SELF_PRESENTATION

Narration may use only direct perception plus KNOWN_TO_PLAYER.
