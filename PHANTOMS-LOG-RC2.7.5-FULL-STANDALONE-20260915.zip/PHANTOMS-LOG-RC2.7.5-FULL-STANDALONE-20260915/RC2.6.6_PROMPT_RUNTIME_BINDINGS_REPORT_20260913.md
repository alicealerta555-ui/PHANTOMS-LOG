# RC2.6.6 — Prompt Runtime Bindings

Date: 2026-09-13

## Scope
All full-version presentation prompt cores are now bound to the active playable runtime path through one read-only prompt registry.

## Implemented
- Added `playable_full_version/playable/prompt_bindings.py` as the single registry/packet builder.
- Startup validation fails closed on unbound prompt cores or dangling bindings.
- All 19 prompt-core files under `content/full_version/prompts/` are bound.
- Live bindings cover location detail, content variation, cultural world surface, weather/environment, dynamic events, search, NPC dialogue, NPC culture, social/faction dialogue, merchant dialogue, quest offers, NPC item responses, item inspection/cultural variation, repair diagnostics, terminal/data reading, embodied needs and generic committed world interaction narration.
- JSON chat-host output now carries `narration` packets separately from deterministic fallback text.
- Narration packets are detached copies and presentation-only; they do not receive mutation handles.
- Deterministic fallback output remains playable if no LLM/chat host consumes the packet.

## Validation
- Prompt registry audit: 19 files / 19 uniquely bound / 0 unbound / 0 missing.
- Focused regression suite: 31/31 passed.
- Extended integration/blackbox run reached 48 passing tests with no visible failure before execution timeout; therefore not claimed as a completed full-suite pass.
- Active playable/runtime placeholder scan: no TODO/FIXME/PLACEHOLDER/NOT_IMPLEMENTED/stub/dummy markers found.

## Authority rule
Database/resolver/runtime/commit remains authoritative. Prompt cores may only present already resolved data and may not create state, facts, inventory, knowledge, relationships, quests or consequences.
