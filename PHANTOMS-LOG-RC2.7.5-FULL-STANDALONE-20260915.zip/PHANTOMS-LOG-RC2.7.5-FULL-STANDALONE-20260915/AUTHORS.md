# Authors / Project authorship

**PHANTOMS-LOG**

Original project creator:

**Manuel Meiko Kohl**

Copyright © 2026 Manuel Meiko Kohl.

Original material in this public repository is licensed under GPL-3.0 unless otherwise stated. Third-party contributions remain attributed according to repository history and applicable notices.
