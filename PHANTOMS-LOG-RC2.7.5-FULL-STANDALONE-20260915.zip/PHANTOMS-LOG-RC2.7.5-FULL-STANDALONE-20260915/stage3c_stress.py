#!/usr/bin/env python3
from pathlib import Path
import random
import tempfile
from uuid import uuid4

from runtime.stage3a.integration import RuntimeDelta
from runtime.stage3c.isolation import FilesystemRunRepository, RunIdentity, RunSessionManager, RunNotFoundError


def main() -> None:
    rng = random.Random(20260903)
    manager = RunSessionManager(master_seed=0x3C20260903)
    players = [str(uuid4()) for _ in range(24)]
    sessions = []
    expected = {}
    for player in players:
        for _ in range(3):
            s = manager.create_run(player_uuid=player)
            sessions.append(s)
            expected[s.identity] = 0

    checks = 0
    for n in range(20000):
        s = sessions[rng.randrange(len(sessions))]
        expected[s.identity] += 1
        value = expected[s.identity]
        result = s.bridge.commit_runtime_event(
            event_id=f"ST3C-{n}",
            cause="isolation stress",
            deltas=(RuntimeDelta("RUNTIME_STATE", "counter", value, "RULE_KERNEL", "isolation stress"),),
        )
        if getattr(result, "revision", None) != s.store.revision:
            raise SystemExit(f"STAGE3C_STRESS_FAIL:revision:{n}")
        if s.store.runtime_state.get("counter") != value:
            raise SystemExit(f"STAGE3C_STRESS_FAIL:target:{n}")
        # Probe a different run. Its counter must equal only its own expected sequence.
        other = sessions[(sessions.index(s) + 1) % len(sessions)]
        if other is not s and other.store.runtime_state.get("counter", 0) != expected[other.identity]:
            raise SystemExit(f"STAGE3C_STRESS_FAIL:bleed:{n}")
        checks += 1

    with tempfile.TemporaryDirectory() as td:
        repo = FilesystemRunRepository(td)
        for n in range(500):
            s = sessions[rng.randrange(len(sessions))]
            before_hash = s.store.state_hash()
            repo.save(s)
            fresh = RunSessionManager(master_seed=0x3C20260903)
            loaded = repo.load_session(fresh, s.identity)
            if loaded.store.state_hash() != before_hash:
                raise SystemExit(f"STAGE3C_STRESS_FAIL:persistence:{n}")
            checks += 1
        # Exact-miss check: same player, nonexistent run must not fall back to sibling.
        miss = RunIdentity(sessions[0].identity.player_uuid, str(uuid4()))
        try:
            repo.load_store(miss)
        except RunNotFoundError:
            checks += 1
        else:
            raise SystemExit("STAGE3C_STRESS_FAIL:fallback")

    print(f"STAGE3C_STRESS={checks}/{checks} PASS")


if __name__ == "__main__":
    main()
