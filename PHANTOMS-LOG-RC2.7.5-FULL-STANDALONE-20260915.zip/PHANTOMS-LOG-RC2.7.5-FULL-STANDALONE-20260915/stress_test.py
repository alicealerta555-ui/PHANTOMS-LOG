#!/usr/bin/env python3
import random
from runtime.stage3a.kernel import *

R = random.Random(303003)
store = StateStore()
k = CommitKernel(store, world_seed=424242)

checks = 0
valid_commits = 0
blocked_writes = 0
query_checks = 0
resolution_pairs = 0

# 1) Query/hypothesis immutability under adversarial payloads.
for i in range(2500):
    before = store.state_hash()
    d = Delta(
        domain=R.choice(list(Domain)),
        key=f"q.{i}",
        value=R.randint(0, 9999),
        writer=R.choice(list(Authority)),
        cause="adversarial query payload",
        actor_id="NPC" if R.random() < .5 else None,
        provenance="obs:X" if R.random() < .5 else None,
    )
    r = k.process(Proposal(mode=Mode.QUERY, source=Authority.PLAYER_INPUT,
                           query_text="maybe?", player_suggestion=d.value, deltas=(d,)))
    assert r.verdict == Verdict.HOLD
    assert store.state_hash() == before
    query_checks += 1
    checks += 1

# 2) Unauthorized direct writes never alter state.
for i in range(2500):
    src = R.choice([Authority.PLAYER_INPUT, Authority.LLM_PROPOSAL, Authority.NARRATOR])
    before = store.state_hash()
    d = Delta(Domain.WORLD_TRUTH, f"bad.{i}", i, src, "unauthorized")
    r = k.process(Proposal(mode=Mode.COMMIT, source=src, event_id=f"BAD-{i}", cause="unauthorized", deltas=(d,)))
    assert r.verdict == Verdict.REJECT
    assert store.state_hash() == before
    blocked_writes += 1
    checks += 1

# 3) Valid rule commits + duplicate idempotency.
for i in range(1500):
    event = f"GOOD-{i}"
    p = Proposal(mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id=event, cause="stress valid",
                 deltas=(Delta(Domain.RUNTIME_STATE, f"runtime.{i}", i, Authority.RULE_KERNEL, "stress valid"),))
    rev = store.revision
    rec = k.process(p)
    assert isinstance(rec, CommitRecord)
    assert store.revision == rev + 1
    duplicate = k.process(p)
    assert duplicate.verdict == Verdict.HOLD
    assert store.revision == rev + 1
    valid_commits += 1
    checks += 2

# 4) Anti-suggestion deterministic minimal pairs.
for i in range(1000):
    key = f"u.{i}"
    def resolve(suggestion):
        local = CommitKernel(StateStore(), world_seed=10000 + i)
        local.register_unresolved(UnresolvedSpec(key, (
            WeightedOption("A", 1), WeightedOption("B", 2), WeightedOption("C", 1)
        ), seed_salt="fixed"))
        local.process(Proposal(mode=Mode.RESOLVE, source=Authority.WORLD_RESOLVER,
                               resolution_key=key, player_suggestion=suggestion,
                               event_id=f"R-{i}", cause="stress resolve"))
        return local.store.world_truth[key]
    a = resolve("A")
    b = resolve("B")
    c = resolve(None)
    assert a == b == c
    resolution_pairs += 1
    checks += 1

# 5) Mixed transaction must fail atomically when one delta is unauthorized.
for i in range(1000):
    before = store.state_hash()
    p = Proposal(mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id=f"MIX-{i}", cause="mixed",
                 deltas=(
                     Delta(Domain.RUNTIME_STATE, f"mix.ok.{i}", i, Authority.RULE_KERNEL, "ok"),
                     Delta(Domain.WORLD_TRUTH, f"mix.bad.{i}", i, Authority.NARRATOR, "bad"),
                 ))
    r = k.process(p)
    assert r.verdict == Verdict.REJECT
    assert store.state_hash() == before
    checks += 1

print(f"STAGE3A_STRESS=PASS CHECKS={checks} QUERY_NO_WRITE={query_checks} BLOCKED_UNAUTHORIZED={blocked_writes} VALID_COMMITS={valid_commits} ANTI_SUGGESTION_PAIRS={resolution_pairs}")
