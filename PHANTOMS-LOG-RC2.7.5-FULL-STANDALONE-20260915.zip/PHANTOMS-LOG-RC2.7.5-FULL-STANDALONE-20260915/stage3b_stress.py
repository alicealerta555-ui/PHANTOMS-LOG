from runtime.stage3a.kernel import Authority, CommitKernel, Delta, Domain, Mode, Proposal, StateStore
from runtime.stage3a.integration import RuntimeAuthorityBridge
from runtime.stage3b.pipeline import ActionPipeline, ActionRequest, ActionRule, ActionStatus, Condition, Effect, FactRef, Operator, OutcomeBranch, RandomDraw, ValueSource


def init(k):
    return k.process(Proposal(mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="init", cause="init", deltas=(
        Delta(Domain.RUNTIME_STATE, "energy", 100000, Authority.RULE_KERNEL, "init", source_event_id="init"),
    )))


def main():
    k = CommitKernel(StateStore(), world_seed=123456)
    init(k)
    p = ActionPipeline(RuntimeAuthorityBridge(k))
    passed = 0
    total = 0

    for i in range(5000):
        rule = ActionRule(
            "STEP",
            facts=(FactRef("energy", Domain.RUNTIME_STATE, "energy"),),
            preconditions=(Condition(ValueSource.FACT, "energy", Operator.GT, 0),),
            random_draws=(RandomDraw("roll", 1, 100),),
            outcomes=(
                OutcomeBranch("A", (Condition(ValueSource.RNG, "roll", Operator.LE, 50),), (Effect(Domain.RUNTIME_STATE, "trace", "A", "RULE_KERNEL", "STEP"),)),
                OutcomeBranch("B", (Condition(ValueSource.RNG, "roll", Operator.GT, 50),), (Effect(Domain.RUNTIME_STATE, "trace", "B", "RULE_KERNEL", "STEP"),)),
            ),
        )
        before = k.store.revision
        r = p.execute(ActionRequest(f"evt:{i}", rule, player_text=f"I want outcome {'A' if i%2==0 else 'B'}"))
        total += 1
        if r.status == ActionStatus.COMMITTED and k.store.revision == before + 1:
            passed += 1

    # 5k failed preconditions must not mutate.
    block_rule = ActionRule("BLOCK", facts=(FactRef("energy", Domain.RUNTIME_STATE, "energy"),), preconditions=(Condition(ValueSource.FACT, "energy", Operator.LT, 0),), outcomes=(OutcomeBranch("BAD", effects=(Effect(Domain.RUNTIME_STATE, "bad", True, "RULE_KERNEL", "BAD"),)),))
    for i in range(5000):
        h = k.store.state_hash()
        r = p.execute(ActionRequest(f"block:{i}", block_rule))
        total += 1
        if r.status == ActionStatus.BLOCKED and k.store.state_hash() == h:
            passed += 1

    # 5k deterministic repeat pairs across fresh stores, with opposite suggestion text.
    rng_rule = ActionRule("RNG", random_draws=(RandomDraw("d", 1, 1000000),), outcomes=(OutcomeBranch("O"),))
    for i in range(5000):
        vals = []
        for text in ("expect high", "expect low"):
            kk = CommitKernel(StateStore(), world_seed=99)
            pp = ActionPipeline(RuntimeAuthorityBridge(kk))
            rr = pp.execute(ActionRequest(f"rng:{i}", rng_rule, player_text=text, player_suggestion=text))
            vals.append(rr.rng["d"])
        total += 1
        if vals[0] == vals[1]:
            passed += 1

    # 5k duplicate event checks.
    dup_rule = ActionRule("DUP", outcomes=(OutcomeBranch("O", effects=(Effect(Domain.RUNTIME_STATE, "dup", True, "RULE_KERNEL", "DUP"),)),))
    for i in range(5000):
        kk = CommitKernel(StateStore(), world_seed=1)
        pp = ActionPipeline(RuntimeAuthorityBridge(kk))
        a = pp.execute(ActionRequest(f"dup:{i}", dup_rule))
        rev = kk.store.revision
        b = pp.execute(ActionRequest(f"dup:{i}", dup_rule))
        total += 1
        if a.status == ActionStatus.COMMITTED and b.status == ActionStatus.HOLD and kk.store.revision == rev:
            passed += 1

    print(f"STAGE3B_STRESS={passed}/{total}")
    if passed != total:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
