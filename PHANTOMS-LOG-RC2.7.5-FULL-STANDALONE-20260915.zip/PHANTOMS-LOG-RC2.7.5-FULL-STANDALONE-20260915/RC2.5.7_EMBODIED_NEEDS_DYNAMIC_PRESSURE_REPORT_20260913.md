# RC2.5.7 — Embodied Needs & Dynamic World Pressure

Design lock: 1 + 2 + 4
- forgiving baseline / low friction
- physiological logic primarily creates lived embodiment
- dynamic situational pressure from activity, climate, injury/danger context

Implementation:
- additive embodied layer over authoritative Stage7 needs; no competing state authority
- hydration, nutrition, rest and climate-fit bands
- differentiated rates: thirst reacts faster than nutrition
- activity and heat multipliers; safe-settlement attenuation
- meaningful recovery events
- symptom projection instead of ordinary numeric-meter narration
- narration anti-spam/cooldown policy
- no player-level scaling
- NPC thresholds specified for future routine integration; no NPC physiology is fabricated before Stage7 actor initialization
- `/body` player-facing qualitative status

Research-informed balance:
- survival pressure should create decisions without constant maintenance
- survival systems work best when tied to world/story experience rather than genre convention
- time/resource pressure should preserve room for exploration and narrative
- minimal/qualitative presentation supports embodiment better than exposing raw numbers

Validation:
- RC2.5.7 focused tests: 6 PASS
- full suite: 1694 PASS + 289 subtests PASS
