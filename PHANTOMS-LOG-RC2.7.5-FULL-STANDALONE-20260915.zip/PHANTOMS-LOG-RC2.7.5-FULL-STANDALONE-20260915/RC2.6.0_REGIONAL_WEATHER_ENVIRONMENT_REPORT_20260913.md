# RC2.6.0 — Regional Weather & Environmental Runtime

Selected design:
PH4NT0M5 Hybrid — regional dependent transitions + physical-lite state + moving fronts, deliberately lightweight.

Architecture:
- Reuses canonical Stage19 weather profiles: WX_CLEAR, WX_COLD_RAIN, WX_FREEZE, WX_HEAT, WX_DUST_STORM.
- Adds authoritative run-scoped regional weather state.
- Five regions maintain temperature, humidity, wind, precipitation and exposure projection.
- Weather transitions depend on the previous weather state and the region's climate preference.
- Up to two lightweight fronts can move only across actual region adjacency.
- Physical variables use inertia instead of a full meteorological simulation.
- No player targeting and no player-level scaling.

Runtime integration:
- World-pulse order is now Environment -> NPC schedules -> embodied physiology -> shelter response -> rumors -> dynamic events.
- Player physiology receives weather from the player's actual location/region.
- Location category attenuates exposure; indoor/civic locations shelter much more than wilderness routes.
- Persistent NPCs receive the same physiological logic based on their own actual locations.
- Severe NPC climate pressure may cause one graph-valid step toward established home/shelter.
- Weather contributes causal pressure tags to Dynamic Events.
- Dynamic Events remain independently gated; weather cannot directly invent consequences.
- `/weather` exposes qualitative/current environment without internal probabilities.
- Location descriptions include committed weather context.

Performance hardening:
- Heterogeneous player/NPC physiology updates are batched into one authoritative Stage7/Embodied commit per world-pulse.
- This avoids one commit per occupied location and keeps the lightweight design viable for local execution.

Validation:
- Focused weather/needs/events/integration suite: 25 PASS.
- Full suite: 1713 PASS + 289 subtests PASS.
- MASTER_MERGE_AUDIT=PASS.
- FULL_VERSION_TRANSITION_AUDIT=PASS.
- FULL_VERSION_MASTER_AUDIT=PASS.
