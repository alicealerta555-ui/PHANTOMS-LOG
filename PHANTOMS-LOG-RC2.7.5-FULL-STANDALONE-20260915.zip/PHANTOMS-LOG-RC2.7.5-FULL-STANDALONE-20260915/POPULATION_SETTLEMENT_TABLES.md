# PH4NT0M5-L0G — Population & Settlement Tables

Active data source: `content/full_version/population_settlement_tables.json`.
All percentages are distribution priors unless explicitly committed as individual runtime state. Culture is not biological lineage.

## Regions

| Region | Archetype | Density | Resident | Commuter | Traveler |
|---|---|---:|---:|---:|---:|
| region:01 — Habitatgürtel | verdichtete Wohnhabitate | hoch | 82.0% | 13.0% | 5.0% |
| region:02 — Zentralring | Markt- und Versorgungszentrum | sehr hoch | 56.0% | 30.0% | 14.0% |
| region:03 — Industriekamm | Arbeits-, Technik- und Verwaltungszone | mittel-hoch | 51.0% | 39.0% | 10.0% |
| region:04 — Randmark | lockere Rand- und Werkstattsiedlungen | niedrig-mittel | 65.0% | 17.0% | 18.0% |
| region:05 — Dunkelnetz | unterirdische Enklaven und Routenstationen | niedrig | 59.0% | 9.0% | 32.0% |

## Culture mix by region

| Region | culture:habitat_circle | culture:habitat_market | culture:market_chain | culture:civic_archive | culture:civic_rimworks | culture:rimworks | culture:deep_route | culture:rim_deep |
|---|---|---|---|---|---|---|---|---|
| region:01 | 62.0% | 19.0% | 9.0% | 4.0% | 2.0% | 2.0% | 1.0% | 1.0% |
| region:02 | 10.0% | 21.0% | 43.0% | 9.0% | 6.0% | 5.0% | 3.0% | 3.0% |
| region:03 | 5.0% | 6.0% | 9.0% | 34.0% | 23.0% | 15.0% | 4.0% | 4.0% |
| region:04 | 4.0% | 5.0% | 6.0% | 5.0% | 17.0% | 39.0% | 9.0% | 15.0% |
| region:05 | 4.0% | 4.0% | 5.0% | 5.0% | 7.0% | 10.0% | 39.0% | 26.0% |

## Settlement types

| Category | Settlement type | Density factor | Traveler factor | Public mix | Occupation bias | Household bias |
|---|---|---:|---:|---|---|---|
| residential_domestic | Wohncluster | 1.15× | 0.55× | niedrig | farmer, medic, service_worker, care_worker | family, extended, pair |
| commerce_services | Marktquartier | 1.35× | 1.70× | sehr hoch | merchant, hauler, service_worker, guard | shared, single, pair |
| civic_social_infrastructure | Versorgungs-/Bürgerknoten | 1.25× | 1.15× | hoch | medic, archivist, guard, care_worker | shared, care_collective, single |
| industrial_maintenance | Werk-/Arbeitsquartier | 1.00× | 0.90× | mittel | mechanic, technician, hauler | shared, single, pair |
| perimeter_outskirts | Randposten | 0.65× | 1.30× | mittel | scout, mechanic, guard, farmer | extended, shared, single |
| wilderness_routes | Routenstation | 0.35× | 2.00× | wechselnd | scout, hauler, merchant | shared, single, extended |
| underground_dungeon | Tiefenenklave | 0.30× | 1.45× | niedrig | scout, mechanic, technician, medic | shared, extended, care_collective |

## Household types

| ID | Label | Typical size | Care capacity |
|---|---|---:|---|
| single | Einzelhaushalt | 1–1 | niedrig |
| pair | Paar-/Zweierhaushalt | 2–2 | mittel |
| family | Familienhaushalt | 3–6 | mittel-hoch |
| extended | Erweiterter Mehrgenerationen-/Verwandtschaftsverbund | 4–10 | hoch |
| shared | Zweck-/Wohngemeinschaft | 2–8 | variabel |
| care_collective | Pflege-/Versorgungskollektiv | 3–12 | sehr hoch |

## Occupation types

| ID | Label |
|---|---|
| mechanic | Mechanik/Instandhaltung |
| medic | Medizin/Versorgung |
| hauler | Transport/Fracht |
| scout | Erkundung/Routen |
| merchant | Handel |
| technician | Technik/Systeme |
| archivist | Archiv/Information |
| guard | Schutz/Sicherheit |
| farmer | Nahrung/Produktion |
| service_worker | Dienstleistung/Versorgung |
| care_worker | Pflege/Soziales |

## Mobility types

| ID | Label | Home tie |
|---|---|---|
| local_resident | lokal ansässig | hoch |
| district_commuter | Quartierpendler | hoch |
| regional_commuter | Regionalpendler | mittel |
| trader_traveler | Händler/Reisender | niedrig |
| migrant_newcomer | Neuzugezogen | im Aufbau |
| transient | vorübergehend anwesend | sehr niedrig |

## Hybrid cultures

| Culture | Parents | Rarity | Typical contexts |
|---|---|---|---|
| culture:habitat_market | culture:habitat_circle, culture:market_chain | uncommon | shared households, market work, mixed residential-commercial zones |
| culture:civic_rimworks | culture:civic_archive, culture:rimworks | rare | technical administration, industrial civic services, maintenance institutions |
| culture:rim_deep | culture:rimworks, culture:deep_route | rare | perimeter routes, deep transport, mobile repair groups |

## Traveler origin matrix

| Destination | region:01 | region:02 | region:03 | region:04 | region:05 |
|---|---:|---:|---:|---:|---:|
| region:01 | 50.0% | 26.0% | 10.0% | 9.0% | 5.0% |
| region:02 | 22.0% | 35.0% | 19.0% | 14.0% | 10.0% |
| region:03 | 10.0% | 22.0% | 36.0% | 22.0% | 10.0% |
| region:04 | 7.0% | 13.0% | 23.0% | 35.0% | 22.0% |
| region:05 | 4.0% | 9.0% | 12.0% | 27.0% | 48.0% |

## Location profiles

All 100 enterable locations have an explicit population profile.

| Location | Region | Category | Settlement | Resident | Commuter | Traveler | Presence band |
|---|---|---|---|---:|---:|---:|---|
| loc:residential_domestic:01 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:02 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:03 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:04 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:05 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:06 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:07 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:08 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:09 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:10 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:11 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:12 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:13 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:14 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:15 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:16 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:17 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:18 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:19 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:20 | region:01 | residential_domestic | Wohncluster | 83.9% | 13.3% | 2.8% | 18–55 |
| loc:residential_domestic:21 | region:02 | residential_domestic | Wohncluster | 60.1% | 32.2% | 7.7% | 18–55 |
| loc:residential_domestic:22 | region:02 | residential_domestic | Wohncluster | 60.1% | 32.2% | 7.7% | 18–55 |
| loc:residential_domestic:23 | region:02 | residential_domestic | Wohncluster | 60.1% | 32.2% | 7.7% | 18–55 |
| loc:residential_domestic:24 | region:02 | residential_domestic | Wohncluster | 60.1% | 32.2% | 7.7% | 18–55 |
| loc:commerce_services:01 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:02 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:03 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:04 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:05 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:06 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:07 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:08 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:09 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:10 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:11 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:12 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:13 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:14 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:commerce_services:15 | region:02 | commerce_services | Marktquartier | 49.6% | 26.6% | 23.8% | 25–90 |
| loc:civic_social_infrastructure:01 | region:02 | civic_social_infrastructure | Versorgungs-/Bürgerknoten | 54.6% | 29.3% | 16.1% | 20–75 |
| loc:civic_social_infrastructure:02 | region:03 | civic_social_infrastructure | Versorgungs-/Bürgerknoten | 50.1% | 38.4% | 11.5% | 20–75 |
| loc:civic_social_infrastructure:03 | region:03 | civic_social_infrastructure | Versorgungs-/Bürgerknoten | 50.1% | 38.4% | 11.5% | 20–75 |
| loc:civic_social_infrastructure:04 | region:03 | civic_social_infrastructure | Versorgungs-/Bürgerknoten | 50.1% | 38.4% | 11.5% | 20–75 |
| loc:civic_social_infrastructure:05 | region:03 | civic_social_infrastructure | Versorgungs-/Bürgerknoten | 50.1% | 38.4% | 11.5% | 20–75 |
| loc:civic_social_infrastructure:06 | region:03 | civic_social_infrastructure | Versorgungs-/Bürgerknoten | 50.1% | 38.4% | 11.5% | 20–75 |
| loc:civic_social_infrastructure:07 | region:03 | civic_social_infrastructure | Versorgungs-/Bürgerknoten | 50.1% | 38.4% | 11.5% | 20–75 |
| loc:civic_social_infrastructure:08 | region:03 | civic_social_infrastructure | Versorgungs-/Bürgerknoten | 50.1% | 38.4% | 11.5% | 20–75 |
| loc:civic_social_infrastructure:09 | region:03 | civic_social_infrastructure | Versorgungs-/Bürgerknoten | 50.1% | 38.4% | 11.5% | 20–75 |
| loc:civic_social_infrastructure:10 | region:03 | civic_social_infrastructure | Versorgungs-/Bürgerknoten | 50.1% | 38.4% | 11.5% | 20–75 |
| loc:civic_social_infrastructure:11 | region:03 | civic_social_infrastructure | Versorgungs-/Bürgerknoten | 50.1% | 38.4% | 11.5% | 20–75 |
| loc:civic_social_infrastructure:12 | region:03 | civic_social_infrastructure | Versorgungs-/Bürgerknoten | 50.1% | 38.4% | 11.5% | 20–75 |
| loc:civic_social_infrastructure:13 | region:03 | civic_social_infrastructure | Versorgungs-/Bürgerknoten | 50.1% | 38.4% | 11.5% | 20–75 |
| loc:industrial_maintenance:01 | region:03 | industrial_maintenance | Werk-/Arbeitsquartier | 51.6% | 39.4% | 9.0% | 12–48 |
| loc:industrial_maintenance:02 | region:03 | industrial_maintenance | Werk-/Arbeitsquartier | 51.6% | 39.4% | 9.0% | 12–48 |
| loc:industrial_maintenance:03 | region:03 | industrial_maintenance | Werk-/Arbeitsquartier | 51.6% | 39.4% | 9.0% | 12–48 |
| loc:industrial_maintenance:04 | region:03 | industrial_maintenance | Werk-/Arbeitsquartier | 51.6% | 39.4% | 9.0% | 12–48 |
| loc:industrial_maintenance:05 | region:03 | industrial_maintenance | Werk-/Arbeitsquartier | 51.6% | 39.4% | 9.0% | 12–48 |
| loc:industrial_maintenance:06 | region:03 | industrial_maintenance | Werk-/Arbeitsquartier | 51.6% | 39.4% | 9.0% | 12–48 |
| loc:industrial_maintenance:07 | region:03 | industrial_maintenance | Werk-/Arbeitsquartier | 51.6% | 39.4% | 9.0% | 12–48 |
| loc:industrial_maintenance:08 | region:03 | industrial_maintenance | Werk-/Arbeitsquartier | 51.6% | 39.4% | 9.0% | 12–48 |
| loc:industrial_maintenance:09 | region:04 | industrial_maintenance | Werk-/Arbeitsquartier | 66.4% | 17.4% | 16.2% | 12–48 |
| loc:industrial_maintenance:10 | region:04 | industrial_maintenance | Werk-/Arbeitsquartier | 66.4% | 17.4% | 16.2% | 12–48 |
| loc:perimeter_outskirts:01 | region:04 | perimeter_outskirts | Randposten | 60.7% | 15.9% | 23.4% | 5–24 |
| loc:perimeter_outskirts:02 | region:04 | perimeter_outskirts | Randposten | 60.7% | 15.9% | 23.4% | 5–24 |
| loc:perimeter_outskirts:03 | region:04 | perimeter_outskirts | Randposten | 60.7% | 15.9% | 23.4% | 5–24 |
| loc:perimeter_outskirts:04 | region:04 | perimeter_outskirts | Randposten | 60.7% | 15.9% | 23.4% | 5–24 |
| loc:perimeter_outskirts:05 | region:04 | perimeter_outskirts | Randposten | 60.7% | 15.9% | 23.4% | 5–24 |
| loc:perimeter_outskirts:06 | region:04 | perimeter_outskirts | Randposten | 60.7% | 15.9% | 23.4% | 5–24 |
| loc:perimeter_outskirts:07 | region:04 | perimeter_outskirts | Randposten | 60.7% | 15.9% | 23.4% | 5–24 |
| loc:perimeter_outskirts:08 | region:04 | perimeter_outskirts | Randposten | 60.7% | 15.9% | 23.4% | 5–24 |
| loc:perimeter_outskirts:09 | region:04 | perimeter_outskirts | Randposten | 60.7% | 15.9% | 23.4% | 5–24 |
| loc:perimeter_outskirts:10 | region:04 | perimeter_outskirts | Randposten | 60.7% | 15.9% | 23.4% | 5–24 |
| loc:perimeter_outskirts:11 | region:04 | perimeter_outskirts | Randposten | 60.7% | 15.9% | 23.4% | 5–24 |
| loc:perimeter_outskirts:12 | region:04 | perimeter_outskirts | Randposten | 60.7% | 15.9% | 23.4% | 5–24 |
| loc:perimeter_outskirts:13 | region:04 | perimeter_outskirts | Randposten | 60.7% | 15.9% | 23.4% | 5–24 |
| loc:wilderness_routes:01 | region:04 | wilderness_routes | Routenstation | 50.7% | 13.3% | 36.0% | 1–12 |
| loc:wilderness_routes:02 | region:04 | wilderness_routes | Routenstation | 50.7% | 13.3% | 36.0% | 1–12 |
| loc:wilderness_routes:03 | region:04 | wilderness_routes | Routenstation | 50.7% | 13.3% | 36.0% | 1–12 |
| loc:wilderness_routes:04 | region:04 | wilderness_routes | Routenstation | 50.7% | 13.3% | 36.0% | 1–12 |
| loc:wilderness_routes:05 | region:04 | wilderness_routes | Routenstation | 50.7% | 13.3% | 36.0% | 1–12 |
| loc:wilderness_routes:06 | region:05 | wilderness_routes | Routenstation | 31.2% | 4.8% | 64.0% | 1–12 |
| loc:wilderness_routes:07 | region:05 | wilderness_routes | Routenstation | 31.2% | 4.8% | 64.0% | 1–12 |
| loc:wilderness_routes:08 | region:05 | wilderness_routes | Routenstation | 31.2% | 4.8% | 64.0% | 1–12 |
| loc:wilderness_routes:09 | region:05 | wilderness_routes | Routenstation | 31.2% | 4.8% | 64.0% | 1–12 |
| loc:wilderness_routes:10 | region:05 | wilderness_routes | Routenstation | 31.2% | 4.8% | 64.0% | 1–12 |
| loc:underground_dungeon:01 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:02 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:03 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:04 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:05 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:06 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:07 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:08 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:09 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:10 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:11 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:12 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:13 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:14 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
| loc:underground_dungeon:15 | region:05 | underground_dungeon | Tiefenenklave | 46.5% | 7.1% | 46.4% | 2–18 |
