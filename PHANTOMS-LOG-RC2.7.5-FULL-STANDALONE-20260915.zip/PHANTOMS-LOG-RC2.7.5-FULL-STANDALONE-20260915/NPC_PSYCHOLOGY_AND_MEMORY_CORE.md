# NPC Psychology, Support & Memory Core

PH4NT0M5-L0G treats psychological strain as changing attention, avoidance, trust, coping and behavior probabilities—not as a stereotyped character label.

The player can help through ordinary low-cost interaction: listening, respecting boundaries, offering choice, reassurance, practical safety and later follow-up. Progress is accumulated through repeated positive moments rather than long therapy dialogue trees.

Memory follows the rule: **simulate richly, persist sparsely**. The system stores compact states and summaries rather than exhaustive transcripts.
