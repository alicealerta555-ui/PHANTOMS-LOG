# PH4NT0M5-L0G RC2.2 – Etappe 16: Item of Interest / Equipment Expertise / Flesh Limits

## Status
IMPLEMENTED / TESTED / PASS

Gesamttests: **157/157 PASS**

## Enthalten
- regionale Seltenheit und kulturelle Auffälligkeit von Ausrüstung
- sichtbares NPC-Interesse statt unsichtbarer Trigger
- Erkennung sichtbarer Schäden und plausibler Diagnose nach Untersuchung
- niedriger Skill -> Frage/Unsicherheit statt Expertenwissen
- hoher Skill + Beziehung/Kontext -> Warnung, Beratung oder Kalibrierungsvorschlag
- Deferred Advice bei Gefahr, Zeitdruck oder unpassender sozialer Situation
- Persistenz von gesehenen, besprochenen und aufgeschobenen Item-Themen
- Integration in `AdaptiveGameplayRuntime`
- Modifikationen als Trade-offs statt lineare Power-Ups
- biologische/fleischliche Grenzen bei körpernahen, implantierten oder biologisch gekoppelten Systemen

## Flesh Limits
Berücksichtigt werden je nach Item, Körper und Wissen des NPC u.a.:
- Nervenstress / Reizüberlastung / Sensibilitätsverlust
- Kreislauf- und Durchblutungsbelastung
- Entzündung / Abstoßung / Immunreaktionen
- Gelenk-, Druck- und Gewebebelastung
- Wärmestau
- Schmerz- und Stressbelastung
- Heilung / Narbengewebe
- geringe körperliche Reserve
- artspezifische Anatomie bei Nichtmenschen/Hybriden

Technische Machbarkeit bedeutet ausdrücklich nicht automatisch biologische Eignung.

## Kernregel
NPC-Wissen bleibt begrenzt durch tatsächliche Expertise und Informationszugang. Ein NPC mit zu wenig medizinischem/biotechnischem Wissen darf keine präzise Fleischdiagnose erfinden.
