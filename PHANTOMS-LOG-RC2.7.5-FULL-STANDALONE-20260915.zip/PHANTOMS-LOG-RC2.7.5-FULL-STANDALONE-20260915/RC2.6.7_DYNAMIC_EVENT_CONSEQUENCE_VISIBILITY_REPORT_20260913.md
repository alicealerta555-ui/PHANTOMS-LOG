# RC2.6.7 — Dynamic Event Consequence & Visibility Integration

Date: 2026-09-13

## Scope

This release connects the existing scheduler-owned dynamic-event lifecycle to persistent world-facing consequences without giving narration or UI authority over world truth.

## Implemented

- Every dynamic event type has a consequence profile.
- `ACTIVE` creates canonical visual/audio traces plus bounded mechanical effects.
- `AFTERMATH` replaces direct activity with aftermath traces/effects.
- `EXPIRED` clears mechanical effects but may leave a time-bounded residual physical trace.
- Perception projection applies weather audio/visual masking and returns only observable fields.
- Automatic arrival and detailed look use the projection; raw `causal_tags`, event preconditions and hidden director state are never passed to the narration context.
- Market shortage changes local merchant pricing through the existing trade path.
- Route disruption adds canonical world-time delay to actual movement through the existing world clock.
- Event rumors are seeded only when a real NPC is physically present at the event location. Player knowledge is never seeded directly. Existing rumor propagation remains responsible for later spread.
- Consequence state persists through save/load.

## Validation

Focused RC2.6.7 validation: **100 tests PASS + 6 subtests PASS**.

Covered suites include dynamic-event lifecycle, RC2.6.7 consequence visibility, playable RC2 regressions, trade/item query, NPC social knowledge, regional weather, location search, runtime integration and prompt-core bindings.

The inherited full-partition RC2.6.2 baseline remains **1723 tests + 289 subtests PASS**; a full RC2.6.7 partition rerun is not claimed by this report.

## Next engineering block

Bind the already aggregated secondary consequence values (`service_capacity_ppm`, `security_presence_ppm`, `population_presence_ppm`, `social_tension_ppm`) into existing authoritative systems, and tighten dynamic-event preconditions with actual population/system pressure provenance.
