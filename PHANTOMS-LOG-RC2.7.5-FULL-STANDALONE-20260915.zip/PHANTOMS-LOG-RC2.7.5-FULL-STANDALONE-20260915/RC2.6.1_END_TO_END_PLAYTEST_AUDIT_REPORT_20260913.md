# RC2.6.1 — End-to-End Playtest Audit & Runtime Hardening

Purpose:
Turn the historical RC2.4 playtest TODO into a regression checklist against the current playable runtime.

Audited black-box chain:
Player input -> parser/handler -> resolver/runtime -> static data -> authority -> commit -> elapsed world time ->
weather -> embodied needs -> NPC routines -> social/event side effects -> narration -> save/load.

Validated player paths:
- SEARCH -> resource/information resolution -> KnowledgeRouter -> time -> weather/needs -> persistence
- TAKE of search-spawned items
- TALK -> identity knowledge -> cultural/social presentation
- ASK NPC -> real inventory only
- TRADE BUY/SELL -> real stock, ownership transfer, credits, social pricing, relationship state
- CRAFT -> real input consumption -> committed output
- REPAIR -> real material consumption -> bounded condition recovery
- DATA ACCESS -> real data item + terminal -> knowledge commit
- INTERACTABLES -> location-bound object listing
- QUEST discovery/offer/accept/full lifecycle retained from existing lifecycle suites
- qualitative SOCIAL/FACTION/WEATHER UI
- save/load continuity
- player/run authority and isolation via the existing full regression suite

Finding fixed:
Regional weather existed as a deterministic projection before the first hourly weather tick,
but no canonical weather runtime state was persisted until a full weather slot elapsed.
This meant an early save relied on deterministic reconstruction rather than an already committed
environment snapshot.

Fix:
- Added RegionalWeatherRuntime.ensure_initialized().
- The playable runtime now commits the initial regional weather snapshot at run startup/load when absent.
- The state remains run-bound and authority-owned.
- Black-box save/reload regression now asserts weather state persistence before hour 1.

New regression suite:
tests/test_rc261_blackbox_e2e.py

Validation:
- RC2.6.1 black-box + regional weather: 14 PASS
- tests/test_[a-h]*: 531 PASS
- tests/test_[i-p]*: 233 PASS + 6 subtests
- tests/test_[q-z]*: 739 PASS + 17 subtests
- tests_stage5: 216 PASS + 266 subtests
- TOTAL: 1719 PASS + 289 subtests PASS
- MASTER_MERGE_AUDIT=PASS
- FULL_VERSION_TRANSITION_AUDIT=PASS
- FULL_VERSION_MASTER_AUDIT=PASS

Historical TODO disposition:
The old RC2.4 checklist is retained as regression intent, not current missing-feature status.
SEARCH, REPAIR, CRAFT, TALK, TRADE, QUEST, DATA ACCESS, NPC runtime naming/routines, location search tables,
interactables and the formerly proposed narrow prompt cores are present in the current line and must remain tested.
