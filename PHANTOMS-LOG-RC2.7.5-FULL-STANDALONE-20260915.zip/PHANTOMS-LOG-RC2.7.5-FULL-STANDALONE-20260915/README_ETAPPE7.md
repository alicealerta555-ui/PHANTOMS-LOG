# PH4NT0M5-L0G RC2.2 — Etappe 7 Habit & Instinct Layer

This extension lets repeated player decisions become habits and, with enough stable evidence, instincts.

- useful, neutral and mildly double-edged habits
- poor habits never become run-destroying penalties
- changed behavior makes old habits fade
- explicit player input always overrides automation
- only safe, reversible micro-routines can be automated
- irreversible and moral choices remain manual
- hidden numeric learning state never reaches player-facing output
- habit state is persisted per player/run

The design goal is that the character gradually feels like they *love the player's playstyle* and begin handling familiar micro-routines naturally, while retaining quirks and imperfections.
