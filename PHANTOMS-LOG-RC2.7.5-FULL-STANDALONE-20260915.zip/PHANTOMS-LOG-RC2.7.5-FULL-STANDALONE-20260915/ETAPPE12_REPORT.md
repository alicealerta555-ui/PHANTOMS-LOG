# PH4NT0M5-L0G RC2.2 – Etappe 12
## NPC Observational Learning – FINAL

Status: IMPLEMENTED / TESTED / PASS

## Ziel
NPCs reagieren auf wiederkehrende, tatsächlich beobachtete Spielerhandlungen, ohne den exklusiven Player-Hidden-Insight-Kern zu erhalten.

## Implementiert
- NPCs beobachten nur committete Spielerhandlungen, die sie tatsächlich wahrnehmen konnten.
- Beobachtete Muster werden pro NPC und Run persistent gespeichert.
- NPC-Reaktionen: bemerken, nachfragen, übernehmen, ablehnen, anpassen, bessere Methode vorschlagen.
- Vorhandene Actor-Intelligenz wird konsumiert; es existiert keine zweite Intelligenzskala.
- Kompetenz, Vertrauen, Offenheit, Sturheit und Eigeninteresse beeinflussen Reaktionen.
- Offensichtlich absurde/kontraproduktive Routinen werden ab kompetenter Actor-Intelligenz nicht blind kopiert.
- Katastrophal selbstschädigende/nonsensische Routinen werden unabhängig von Intelligenz nicht übernommen.
- Sehr kompetente/intelligente NPCs können aus der Spieler-Methode eine verbesserte Variante ableiten.
- NPCs können auf Nachfrage erklären, ob sie eine Methode übernommen, angepasst oder abgelehnt haben.
- Player Hidden Insights, Player Habits/Instincts und End Paths bleiben exklusiv beim Spieler.
- NPC-Lernen erzeugt nur normale Actor-Verhaltenshinweise/Routinen.
- Keine Hidden-World-Information wird für NPC-Beobachtung verlangt oder verarbeitet.

## Finale Integrationsoberfläche
`AdaptiveGameplayRuntime.after_resolution(...)`

Ein einziger Host-Aufruf speist:
1. Player Adaptive Development
2. beobachtende NPCs

Nur der Host entscheidet, welche NPCs die Handlung tatsächlich wahrgenommen haben.

## Save/Load
Kombinierter Snapshot:
- `player_learning`
- `npc_observational_learning`

Beide Zustände bleiben getrennt.

## Tests
Gesamtsuite: **105/105 PASS**
