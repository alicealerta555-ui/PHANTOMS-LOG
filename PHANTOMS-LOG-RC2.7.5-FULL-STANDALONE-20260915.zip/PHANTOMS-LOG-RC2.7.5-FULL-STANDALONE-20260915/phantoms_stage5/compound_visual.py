# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Per-facet detection of one common stimulus; no image reconstruction."""
from dataclasses import dataclass
from .senses import BoundSense, Expression, _text
from .light import _finite
from .visual import Detection


@dataclass(frozen=True)
class FacetLimits:
    facet_id: str
    calibration_id: str
    max_distance_m: float
    min_irradiance_w_m2: float

    def __post_init__(self):
        _text(self.facet_id)
        _text(self.calibration_id)
        _finite(self.max_distance_m, "FACET_RANGE", positive=True)
        _finite(self.min_irradiance_w_m2, "FACET_THRESHOLD", positive=True)


@dataclass(frozen=True)
class FacetConditions:
    facet_id: str
    calibration_id: str | None
    distance_m: float | None
    received_irradiance_w_m2: float | None
    in_field_of_view: bool | None
    line_of_sight_clear: bool | None

    def __post_init__(self):
        _text(self.facet_id)
        if self.calibration_id is not None:
            _text(self.calibration_id)
        _finite(self.distance_m, "FACET_DISTANCE", optional=True, minimum=0)
        _finite(self.received_irradiance_w_m2, "FACET_IRRADIANCE", optional=True, minimum=0)
        for value in (self.in_field_of_view, self.line_of_sight_clear):
            if value is not None and type(value) is not bool:
                raise ValueError("FACET_BOOLEAN_REQUIRED")


def _indexed(values, cls):
    if not isinstance(values, tuple) or any(not isinstance(v, cls) for v in values):
        raise ValueError("FACET_TYPED_TUPLE_REQUIRED")
    result = {v.facet_id: v for v in values}
    if len(result) != len(values):
        raise ValueError("DUPLICATE_FACET")
    return result


@dataclass(frozen=True)
class CompoundVisualLimits:
    profile_id: str
    facets: tuple[FacetLimits, ...]

    def __post_init__(self):
        _text(self.profile_id)
        if not _indexed(self.facets, FacetLimits):
            raise ValueError("FACETS_REQUIRED")


@dataclass(frozen=True)
class FacetResult:
    facet_id: str
    detection: Detection
    reasons: tuple[str, ...]


@dataclass(frozen=True)
class CompoundVisualResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]
    facets: tuple[FacetResult, ...]


def detect_compound_visual(sense, limits, conditions):
    if not isinstance(sense, BoundSense) or not isinstance(limits, CompoundVisualLimits):
        raise ValueError("COMPOUND_TYPED_INPUTS_REQUIRED")
    supplied = _indexed(conditions, FacetConditions)
    if sense.modality != "compound_visual_hook":
        raise ValueError("COMPOUND_MODALITY_REQUIRED")
    if not isinstance(sense.expression, Expression):
        raise ValueError("COMPOUND_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("COMPOUND_PROFILE_REQUIRED")
        return CompoundVisualResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",), ())
    if sense.profile.profile_id != limits.profile_id or sense.profile.modality != sense.modality:
        raise ValueError("COMPOUND_PROFILE_MISMATCH")
    configured = _indexed(limits.facets, FacetLimits)
    if supplied.keys() - configured.keys():
        raise ValueError("UNKNOWN_FACET")
    results = []
    for facet_id, cfg in sorted(configured.items()):
        data = supplied.get(facet_id)
        if data is not None and data.calibration_id is not None and data.calibration_id != cfg.calibration_id:
            raise ValueError("FACET_CALIBRATION_MISMATCH")
        if sense.expression is Expression.LATENT:
            results.append(FacetResult(facet_id, Detection.NOT_DETECTED, ("LATENT_SENSE",)))
            continue
        if data is None:
            results.append(FacetResult(facet_id, Detection.UNRESOLVED, ("FACET_INPUT_MISSING",)))
            continue
        if data.calibration_id is None:
            results.append(FacetResult(facet_id, Detection.UNRESOLVED, ("FACET_CALIBRATION_UNKNOWN",)))
            continue
        blocked = []
        if data.in_field_of_view is False:
            blocked.append("OUTSIDE_FACET_FIELD")
        if data.line_of_sight_clear is False:
            blocked.append("FACET_OCCLUDED")
        if data.distance_m is not None and data.distance_m > cfg.max_distance_m:
            blocked.append("FACET_OUT_OF_RANGE")
        if data.received_irradiance_w_m2 is not None and data.received_irradiance_w_m2 < cfg.min_irradiance_w_m2:
            blocked.append("FACET_INSUFFICIENT_LIGHT")
        unknown = []
        if sense.expression is not Expression.ACTIVE:
            unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
        for value, reason in ((data.in_field_of_view, "FIELD_UNKNOWN"), (data.line_of_sight_clear, "SIGHT_UNKNOWN"),
                              (data.distance_m, "DISTANCE_UNKNOWN"), (data.received_irradiance_w_m2, "LIGHT_UNKNOWN")):
            if value is None:
                unknown.append(reason)
        status = Detection.NOT_DETECTED if blocked else Detection.UNRESOLVED if unknown else Detection.DETECTED
        results.append(FacetResult(facet_id, status, tuple(blocked or unknown or ["FACET_CONDITIONS_MET"])))
    statuses = {r.detection for r in results}
    if Detection.DETECTED in statuses:
        status, reason = Detection.DETECTED, "AT_LEAST_ONE_FACET_DETECTED"
    elif Detection.UNRESOLVED in statuses:
        status, reason = Detection.UNRESOLVED, "FACETS_UNRESOLVED"
    else:
        status, reason = Detection.NOT_DETECTED, "ALL_FACETS_BLOCKED"
    return CompoundVisualResult(sense.hook_id, status, (reason,), tuple(results))
