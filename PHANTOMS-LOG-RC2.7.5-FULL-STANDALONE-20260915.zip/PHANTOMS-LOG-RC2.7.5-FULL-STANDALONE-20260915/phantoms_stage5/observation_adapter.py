# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Trusted engine adapter: first visual detection-to-knowledge integration.

Bind to one run's EpistemicEngine and an authorized observer/lineage. Callers
must supply that observer's current world conditions, location and event time.
This is not an untrusted client endpoint or a scene/identity authorization service.
"""
from dataclasses import dataclass
from runtime.stage3d.epistemic import EpistemicEngine
from .senses import BoundSense, _text
from .visual import Detection, detect_visual


@dataclass(frozen=True)
class ObservationOutcome:
    detection: Detection
    commit: object | None


class VisualObservationAdapter:
    def __init__(self, engine, *, lineage_id, actor_id=None):
        if not isinstance(engine, EpistemicEngine):
            raise ValueError("EPISTEMIC_ENGINE_REQUIRED")
        _text(lineage_id)
        if actor_id is not None:
            _text(actor_id)
        self._engine = engine
        self._lineage_id = lineage_id
        self._actor_id = actor_id

    def observe(self, sense, limits, conditions, *, event_id, location, world_time):
        if not isinstance(sense, BoundSense) or sense.lineage_id != self._lineage_id:
            raise ValueError("OBSERVER_LINEAGE_MISMATCH")
        _text(event_id)
        _text(location)
        if type(world_time) is not int or world_time < 0:
            raise ValueError("OBSERVATION_TIME_REQUIRED")
        result = detect_visual(sense, limits, conditions)
        if result.detection is not Detection.DETECTED:
            return ObservationOutcome(result.detection, None)
        # Deliberately no arbitrary fact_key/value, object identity or raw world
        # payload accepted. Detection grants only a minimal signal observation.
        kwargs = dict(fact_key="perception." + event_id,
                      value={"signal_detected": True, "modality": "visual"},
                      event_id=event_id, source_id=result.hook_id,
                      location=location, world_time=world_time)
        if self._actor_id is None:
            commit = self._engine.record_player_observation(**kwargs)
        else:
            commit = self._engine.record_actor_observation(actor_id=self._actor_id, **kwargs)
        return ObservationOutcome(result.detection, commit)
