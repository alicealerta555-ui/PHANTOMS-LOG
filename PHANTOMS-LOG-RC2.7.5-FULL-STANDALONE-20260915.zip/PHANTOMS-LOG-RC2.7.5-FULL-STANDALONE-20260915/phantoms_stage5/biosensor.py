# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Explicit scalar biosensor contract; no universal biological perception.

An authorized engine configures one measurement, unit, calibration and inclusive
trigger interval. IDs are exact; this interface performs no unit conversions,
chemical recognition, truth authentication, sensor simulation or state writes.
"""
from dataclasses import dataclass
import math
from .senses import BoundSense, Expression, _text
from .visual import Detection


def _finite(value, field, *, optional=False, minimum=None, positive=False):
    if value is None and optional:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("INVALID_" + field)
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite or (minimum is not None and value < minimum) or (positive and value <= 0):
        raise ValueError("INVALID_" + field)


@dataclass(frozen=True)
class BiosensorLimits:
    profile_id: str
    calibration_id: str
    measurement_id: str
    unit_id: str
    min_value: float
    max_value: float

    def __post_init__(self):
        _text(self.profile_id)
        _text(self.calibration_id)
        _text(self.measurement_id)
        _text(self.unit_id)
        _finite(self.min_value, "BIOSENSOR_MIN")
        _finite(self.max_value, "BIOSENSOR_MAX")
        if self.min_value > self.max_value:
            raise ValueError("BIOSENSOR_INVALID_RANGE")


@dataclass(frozen=True)
class BiosensorConditions:
    calibration_id: str | None
    measurement_id: str | None
    unit_id: str | None
    received_value: float | None
    sensor_ready: bool | None

    def __post_init__(self):
        if self.calibration_id is not None:
            _text(self.calibration_id)
        for value in (self.measurement_id, self.unit_id):
            if value is not None:
                _text(value)
        _finite(self.received_value, "BIOSENSOR_VALUE", optional=True)
        if self.sensor_ready is not None and type(self.sensor_ready) is not bool:
            raise ValueError("BIOSENSOR_INVALID_PATH")


@dataclass(frozen=True)
class BiosensorResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]


def detect_biosensor(sense: BoundSense, limits: BiosensorLimits,
                   conditions: BiosensorConditions) -> BiosensorResult:
    if not isinstance(sense, BoundSense) or not isinstance(limits, BiosensorLimits) or not isinstance(conditions, BiosensorConditions):
        raise ValueError("BIOSENSOR_TYPED_INPUTS_REQUIRED")
    if sense.modality != "biosensor_hook":
        raise ValueError("BIOSENSOR_MODALITY_REQUIRED")
    if not isinstance(sense.expression, Expression):
        raise ValueError("BIOSENSOR_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("BIOSENSOR_PROFILE_REQUIRED_FOR_EXPRESSION")
        return BiosensorResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",))
    if sense.profile.profile_id != limits.profile_id or sense.profile.modality != "biosensor_hook":
        raise ValueError("BIOSENSOR_PROFILE_MISMATCH")

    blocked = []
    if sense.expression is Expression.LATENT:
        blocked.append("LATENT_SENSE")
    if conditions.sensor_ready is False:
        blocked.append("BIOSENSOR_READINESS_BLOCKED")
    identifiers_known = True
    for field in ("calibration_id", "measurement_id", "unit_id"):
        value = getattr(conditions, field)
        if value is None:
            identifiers_known = False
        elif value != getattr(limits, field):
            raise ValueError("BIOSENSOR_" + field.upper() + "_MISMATCH")
    if identifiers_known and conditions.received_value is not None and not limits.min_value <= conditions.received_value <= limits.max_value:
        blocked.append("OUTSIDE_CONFIGURED_RANGE")
    if blocked:
        return BiosensorResult(sense.hook_id, Detection.NOT_DETECTED, tuple(blocked))

    unknown = []
    if sense.expression is not Expression.ACTIVE:
        unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
    for value, reason in ((conditions.sensor_ready, "BIOSENSOR_READINESS_UNKNOWN"),
                          (conditions.calibration_id, "CALIBRATION_UNKNOWN"),
                          (conditions.measurement_id, "MEASUREMENT_UNKNOWN"),
                          (conditions.unit_id, "UNIT_UNKNOWN"),
                          (conditions.received_value, "BIOSENSOR_VALUE_UNKNOWN")):
        if value is None:
            unknown.append(reason)
    if unknown:
        return BiosensorResult(sense.hook_id, Detection.UNRESOLVED, tuple(unknown))
    return BiosensorResult(sense.hook_id, Detection.DETECTED, ("BIOSENSOR_CONDITIONS_MET",))
