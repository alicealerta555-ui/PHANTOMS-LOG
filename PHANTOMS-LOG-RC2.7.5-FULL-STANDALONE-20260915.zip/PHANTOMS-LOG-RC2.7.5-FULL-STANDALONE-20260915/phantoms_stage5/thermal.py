# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Simplified thermal-contrast detection, not temperature measurement.

The world engine supplies receiver-side apparent contrast in kelvin after
propagation and attenuation for the selected thermal band. Optical transparency
is not an input. No heat-transfer model, object recognition or knowledge writes.
"""
from dataclasses import dataclass
import math
from .senses import BoundSense, Expression, _text
from .visual import Detection


def _finite(value, field, *, optional=False, minimum=None, positive=False):
    if value is None and optional:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("INVALID_" + field)
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite or (minimum is not None and value < minimum) or (positive and value <= 0):
        raise ValueError("INVALID_" + field)


@dataclass(frozen=True)
class ThermalLimits:
    profile_id: str
    max_distance_m: float
    min_abs_contrast_k: float
    modality: str = "thermal"

    def __post_init__(self):
        _text(self.profile_id)
        if self.modality not in ("thermal", "thermal_hook"):
            raise ValueError("THERMAL_UNSUPPORTED_MODALITY")
        _finite(self.max_distance_m, "THERMAL_MAX_DISTANCE", positive=True)
        _finite(self.min_abs_contrast_k, "THERMAL_CONTRAST_THRESHOLD", positive=True)


@dataclass(frozen=True)
class ThermalConditions:
    distance_m: float | None
    received_contrast_k: float | None
    thermal_path_available: bool | None

    def __post_init__(self):
        _finite(self.distance_m, "THERMAL_DISTANCE", optional=True, minimum=0)
        _finite(self.received_contrast_k, "THERMAL_CONTRAST", optional=True)
        if self.thermal_path_available is not None and type(self.thermal_path_available) is not bool:
            raise ValueError("THERMAL_INVALID_PATH")


@dataclass(frozen=True)
class ThermalResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]


def detect_thermal(sense: BoundSense, limits: ThermalLimits,
                   conditions: ThermalConditions) -> ThermalResult:
    if not isinstance(sense, BoundSense) or not isinstance(limits, ThermalLimits) or not isinstance(conditions, ThermalConditions):
        raise ValueError("THERMAL_TYPED_INPUTS_REQUIRED")
    if sense.modality != limits.modality:
        raise ValueError("THERMAL_MODALITY_REQUIRED")
    if not isinstance(sense.expression, Expression):
        raise ValueError("THERMAL_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("THERMAL_PROFILE_REQUIRED_FOR_EXPRESSION")
        return ThermalResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",))
    if sense.profile.profile_id != limits.profile_id or sense.profile.modality != limits.modality:
        raise ValueError("THERMAL_PROFILE_MISMATCH")

    blocked = []
    if sense.expression is Expression.LATENT:
        blocked.append("LATENT_SENSE")
    if conditions.thermal_path_available is False:
        blocked.append("THERMALLY_BLOCKED")
    if conditions.distance_m is not None and conditions.distance_m > limits.max_distance_m:
        blocked.append("OUT_OF_RANGE")
    if conditions.received_contrast_k is not None and abs(conditions.received_contrast_k) < limits.min_abs_contrast_k:
        blocked.append("INSUFFICIENT_THERMAL_CONTRAST")
    if blocked:
        return ThermalResult(sense.hook_id, Detection.NOT_DETECTED, tuple(blocked))

    unknown = []
    if sense.expression is not Expression.ACTIVE:
        unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
    for value, reason in ((conditions.thermal_path_available, "THERMAL_PATH_UNKNOWN"),
                          (conditions.distance_m, "DISTANCE_UNKNOWN"),
                          (conditions.received_contrast_k, "THERMAL_CONTRAST_UNKNOWN")):
        if value is None:
            unknown.append(reason)
    if unknown:
        return ThermalResult(sense.hook_id, Detection.UNRESOLVED, tuple(unknown))
    return ThermalResult(sense.hook_id, Detection.DETECTED, ("THERMAL_CONDITIONS_MET",))
