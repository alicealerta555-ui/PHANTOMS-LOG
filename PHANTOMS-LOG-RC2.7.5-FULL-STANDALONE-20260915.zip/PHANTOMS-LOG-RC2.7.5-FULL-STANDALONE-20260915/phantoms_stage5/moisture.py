# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Threshold detection of calibrated receptor-side relative air humidity.

This bounded game model accepts 0..100 percent RH only, with threshold >0.
Engine calibration defines local temperature/reference and response window.
No soil moisture, liquid contact, hydration, humidity conversion or state writes.
"""
from dataclasses import dataclass
import math
from .senses import BoundSense, Expression, _text
from .visual import Detection


def _finite(value, field, *, optional=False, minimum=None, maximum=None, positive=False):
    if value is None and optional:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("INVALID_" + field)
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite or (minimum is not None and value < minimum) or (maximum is not None and value > maximum) or (positive and value <= 0):
        raise ValueError("INVALID_" + field)


@dataclass(frozen=True)
class MoistureLimits:
    profile_id: str
    calibration_id: str
    min_relative_humidity_pct: float

    def __post_init__(self):
        _text(self.profile_id)
        _text(self.calibration_id)
        _finite(self.min_relative_humidity_pct, "MOISTURE_RELATIVE_HUMIDITY_THRESHOLD", positive=True, maximum=100)


@dataclass(frozen=True)
class MoistureConditions:
    calibration_id: str | None
    received_relative_humidity_pct: float | None
    receptor_exposed: bool | None

    def __post_init__(self):
        if self.calibration_id is not None:
            _text(self.calibration_id)
        _finite(self.received_relative_humidity_pct, "MOISTURE_RELATIVE_HUMIDITY", optional=True, minimum=0, maximum=100)
        if self.receptor_exposed is not None and type(self.receptor_exposed) is not bool:
            raise ValueError("MOISTURE_INVALID_PATH")


@dataclass(frozen=True)
class MoistureResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]


def detect_moisture(sense: BoundSense, limits: MoistureLimits,
                   conditions: MoistureConditions) -> MoistureResult:
    if not isinstance(sense, BoundSense) or not isinstance(limits, MoistureLimits) or not isinstance(conditions, MoistureConditions):
        raise ValueError("MOISTURE_TYPED_INPUTS_REQUIRED")
    if sense.modality != "moisture_hook":
        raise ValueError("MOISTURE_MODALITY_REQUIRED")
    if not isinstance(sense.expression, Expression):
        raise ValueError("MOISTURE_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("MOISTURE_PROFILE_REQUIRED_FOR_EXPRESSION")
        return MoistureResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",))
    if sense.profile.profile_id != limits.profile_id or sense.profile.modality != "moisture_hook":
        raise ValueError("MOISTURE_PROFILE_MISMATCH")

    blocked = []
    if sense.expression is Expression.LATENT:
        blocked.append("LATENT_SENSE")
    if conditions.receptor_exposed is False:
        blocked.append("MOISTURE_EXPOSURE_BLOCKED")
    if conditions.calibration_id is not None and conditions.calibration_id != limits.calibration_id:
        raise ValueError("MOISTURE_CALIBRATION_MISMATCH")
    if conditions.calibration_id == limits.calibration_id and conditions.received_relative_humidity_pct is not None and conditions.received_relative_humidity_pct < limits.min_relative_humidity_pct:
        blocked.append("INSUFFICIENT_MOISTURE_RELATIVE_HUMIDITY")
    if blocked:
        return MoistureResult(sense.hook_id, Detection.NOT_DETECTED, tuple(blocked))

    unknown = []
    if sense.expression is not Expression.ACTIVE:
        unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
    for value, reason in ((conditions.receptor_exposed, "MOISTURE_EXPOSURE_UNKNOWN"),
                          (conditions.calibration_id, "CALIBRATION_UNKNOWN"),
                          (conditions.received_relative_humidity_pct, "MOISTURE_RELATIVE_HUMIDITY_UNKNOWN")):
        if value is None:
            unknown.append(reason)
    if unknown:
        return MoistureResult(sense.hook_id, Detection.UNRESOLVED, tuple(unknown))
    return MoistureResult(sense.hook_id, Detection.DETECTED, ("MOISTURE_CONDITIONS_MET",))
