# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Pure biological sense binding. Availability is not perception or knowledge.

Callers supply engine-authorized expression/provenance; this layer checks the
binding structure, not the factual authenticity of an evidence reference.
"""
from dataclasses import dataclass
from enum import Enum
from typing import Iterable

from runtime.stage4b import GenelineRecord, validate_geneline_record


class Expression(str, Enum):
    ACTIVE = "ACTIVE"
    LATENT = "LATENT"
    CONDITIONAL = "CONDITIONAL"
    UNRESOLVED = "UNRESOLVED"


class Availability(str, Enum):
    AVAILABLE = "AVAILABLE"
    CONDITIONAL = "CONDITIONAL"
    UNRESOLVED = "UNRESOLVED"
    UNAVAILABLE = "UNAVAILABLE"


def _text(value: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError("SENSE_NONEMPTY_CANONICAL_TEXT_REQUIRED")


def _refs(values: tuple[str, ...], *, required: bool = False) -> None:
    if not isinstance(values, tuple):
        raise ValueError("SENSE_IMMUTABLE_REFERENCES_REQUIRED")
    for value in values:
        _text(value)
    if len(set(values)) != len(values) or (required and not values):
        raise ValueError("SENSE_DISTINCT_REFERENCES_REQUIRED")


@dataclass(frozen=True)
class SenseProfile:
    profile_id: str
    modality: str
    constraint_refs: tuple[str, ...]

    def __post_init__(self):
        _text(self.profile_id)
        _text(self.modality)
        _refs(self.constraint_refs, required=True)


@dataclass(frozen=True)
class SenseBinding:
    hook_id: str
    profile_id: str
    expression: Expression
    evidence_refs: tuple[str, ...]
    condition_refs: tuple[str, ...] = ()

    def __post_init__(self):
        _text(self.hook_id)
        _text(self.profile_id)
        if not isinstance(self.expression, Expression):
            raise ValueError("SENSE_EXPRESSION_ENUM_REQUIRED")
        _refs(self.evidence_refs, required=True)
        _refs(self.condition_refs)
        if (self.expression is Expression.CONDITIONAL) != bool(self.condition_refs):
            raise ValueError("SENSE_CONDITIONS_REQUIRE_CONDITIONAL_EXPRESSION")


@dataclass(frozen=True)
class BoundSense:
    lineage_id: str
    hook_id: str
    modality: str
    profile: SenseProfile | None
    expression: Expression
    evidence_refs: tuple[str, ...]
    condition_refs: tuple[str, ...]


@dataclass(frozen=True)
class SenseAssessment:
    modality: str
    availability: Availability
    sources: tuple[BoundSense, ...]


class SenseRegistry:
    def __init__(self, profiles: Iterable[SenseProfile] = ()):
        self._profiles: dict[str, SenseProfile] = {}
        for profile in profiles:
            if not isinstance(profile, SenseProfile):
                raise ValueError("SENSE_PROFILE_REQUIRED")
            if profile.profile_id in self._profiles:
                raise ValueError("SENSE_DUPLICATE_PROFILE")
            self._profiles[profile.profile_id] = profile

    def bind(self, record: GenelineRecord,
             bindings: Iterable[SenseBinding] = ()) -> tuple[BoundSense, ...]:
        validate_geneline_record(record)
        hooks = {hook.hook_id: hook for hook in record.sensor_hooks}
        explicit: dict[str, SenseBinding] = {}
        for binding in bindings:
            if not isinstance(binding, SenseBinding):
                raise ValueError("SENSE_BINDING_REQUIRED")
            if binding.hook_id in explicit:
                raise ValueError("SENSE_DUPLICATE_BINDING")
            if binding.hook_id not in hooks:
                raise ValueError("SENSE_UNKNOWN_HOOK")
            if binding.profile_id not in self._profiles:
                raise ValueError("SENSE_UNKNOWN_PROFILE")
            if self._profiles[binding.profile_id].modality != hooks[binding.hook_id].modality:
                raise ValueError("SENSE_MODALITY_MISMATCH")
            known = {item.constraint_id for item in record.known_constraints}
            if not set(self._profiles[binding.profile_id].constraint_refs) <= known:
                raise ValueError("SENSE_UNKNOWN_CONSTRAINT")
            explicit[binding.hook_id] = binding
        result = []
        for hook_id, hook in sorted(hooks.items()):
            binding = explicit.get(hook_id)
            result.append(BoundSense(
                record.lineage_id, hook_id, hook.modality,
                self._profiles[binding.profile_id] if binding else None,
                binding.expression if binding else Expression.UNRESOLVED,
                binding.evidence_refs if binding else (),
                binding.condition_refs if binding else (),
            ))
        return tuple(result)


def assess_modality(senses: tuple[BoundSense, ...], modality: str) -> SenseAssessment:
    """Report capability only; never resolves conditional expressions or writes state."""
    _text(modality)
    if not isinstance(senses, tuple) or any(not isinstance(s, BoundSense) for s in senses):
        raise ValueError("BOUND_SENSE_TUPLE_REQUIRED")
    if len({s.lineage_id for s in senses}) > 1:
        raise ValueError("SENSE_CROSS_LINEAGE_MIX")
    sources = tuple(s for s in senses if s.modality == modality)
    states = {s.expression for s in sources}
    if Expression.ACTIVE in states:
        availability = Availability.AVAILABLE
    elif Expression.CONDITIONAL in states:
        availability = Availability.CONDITIONAL
    elif Expression.UNRESOLVED in states:
        availability = Availability.UNRESOLVED
    else:
        availability = Availability.UNAVAILABLE
    return SenseAssessment(modality, availability, sources)
