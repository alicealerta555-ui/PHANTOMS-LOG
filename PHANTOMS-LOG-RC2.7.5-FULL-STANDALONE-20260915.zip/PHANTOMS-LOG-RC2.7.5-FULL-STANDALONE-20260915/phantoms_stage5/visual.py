# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Bounded visual detection from trusted engine inputs; no knowledge writes.

Line-of-sight and incident illuminance come from the world engine. This module
does not infer geometry, identify objects, or model acuity/partial occlusion.
"""
from dataclasses import dataclass
from enum import Enum
import math

from .senses import BoundSense, Expression, _text


class Detection(str, Enum):
    DETECTED = "DETECTED"
    NOT_DETECTED = "NOT_DETECTED"
    UNRESOLVED = "UNRESOLVED"


def _number(value, name, *, positive=False, optional=False):
    if value is None and optional:
        return
    if (isinstance(value, bool) or not isinstance(value, (int, float))
            or not math.isfinite(value) or value < 0 or (positive and value == 0)):
        raise ValueError("VISUAL_INVALID_" + name)


@dataclass(frozen=True)
class VisualLimits:
    profile_id: str
    max_distance_m: float
    min_illuminance_lux: float

    def __post_init__(self):
        _text(self.profile_id)
        _number(self.max_distance_m, "MAX_DISTANCE", positive=True)
        _number(self.min_illuminance_lux, "LIGHT_THRESHOLD", positive=True)


@dataclass(frozen=True)
class VisualConditions:
    distance_m: float | None
    incident_illuminance_lux: float | None
    line_of_sight_clear: bool | None

    def __post_init__(self):
        _number(self.distance_m, "DISTANCE", optional=True)
        _number(self.incident_illuminance_lux, "ILLUMINANCE", optional=True)
        if self.line_of_sight_clear is not None and type(self.line_of_sight_clear) is not bool:
            raise ValueError("VISUAL_INVALID_LINE_OF_SIGHT")


@dataclass(frozen=True)
class VisualResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]


def detect_visual(sense: BoundSense, limits: VisualLimits,
                  conditions: VisualConditions) -> VisualResult:
    if not isinstance(sense, BoundSense) or not isinstance(limits, VisualLimits) or not isinstance(conditions, VisualConditions):
        raise ValueError("VISUAL_TYPED_INPUTS_REQUIRED")
    if sense.modality != "visual":
        raise ValueError("VISUAL_MODALITY_REQUIRED")
    if not isinstance(sense.expression, Expression):
        raise ValueError("VISUAL_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("VISUAL_PROFILE_REQUIRED_FOR_EXPRESSION")
        return VisualResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",))
    elif sense.profile.profile_id != limits.profile_id or sense.profile.modality != "visual":
        raise ValueError("VISUAL_PROFILE_MISMATCH")

    blocked = []
    if sense.expression is Expression.LATENT:
        blocked.append("LATENT_SENSE")
    if conditions.line_of_sight_clear is False:
        blocked.append("OCCLUDED")
    if conditions.distance_m is not None and conditions.distance_m > limits.max_distance_m:
        blocked.append("OUT_OF_RANGE")
    if conditions.incident_illuminance_lux is not None and conditions.incident_illuminance_lux < limits.min_illuminance_lux:
        blocked.append("INSUFFICIENT_LIGHT")
    if blocked:
        return VisualResult(sense.hook_id, Detection.NOT_DETECTED, tuple(blocked))

    unknown = []
    if sense.expression is not Expression.ACTIVE:
        unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
    if conditions.line_of_sight_clear is None:
        unknown.append("LINE_OF_SIGHT_UNKNOWN")
    if conditions.distance_m is None:
        unknown.append("DISTANCE_UNKNOWN")
    if conditions.incident_illuminance_lux is None:
        unknown.append("LIGHT_UNKNOWN")
    if unknown:
        return VisualResult(sense.hook_id, Detection.UNRESOLVED, tuple(unknown))
    return VisualResult(sense.hook_id, Detection.DETECTED, ("VISUAL_CONDITIONS_MET",))
