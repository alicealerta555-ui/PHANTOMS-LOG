# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Simplified auditory detection using engine-supplied receiver-side levels.

Signal and noise use the same dB SPL reference and assessment band/window.
Propagation, obstacles and attenuation have already been applied by the caller.
No speech recognition, source identification, localization or knowledge write.
"""
from dataclasses import dataclass
import math
from .senses import BoundSense, Expression, _text
from .visual import Detection


def _finite(value, field, *, optional=False, minimum=None, positive=False):
    if value is None and optional:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("AUDITORY_INVALID_" + field)
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite or (minimum is not None and value < minimum) or (positive and value <= 0):
        raise ValueError("AUDITORY_INVALID_" + field)


@dataclass(frozen=True)
class AuditoryLimits:
    profile_id: str
    max_distance_m: float
    min_signal_db_spl: float
    min_snr_db: float

    def __post_init__(self):
        _text(self.profile_id)
        _finite(self.max_distance_m, "MAX_DISTANCE", positive=True)
        _finite(self.min_signal_db_spl, "SIGNAL_THRESHOLD")
        _finite(self.min_snr_db, "SNR_THRESHOLD", minimum=0)


@dataclass(frozen=True)
class AuditoryConditions:
    distance_m: float | None
    received_signal_db_spl: float | None
    received_noise_db_spl: float | None
    acoustic_path_available: bool | None

    def __post_init__(self):
        _finite(self.distance_m, "DISTANCE", optional=True, minimum=0)
        _finite(self.received_signal_db_spl, "SIGNAL", optional=True)
        _finite(self.received_noise_db_spl, "NOISE", optional=True)
        if self.acoustic_path_available is not None and type(self.acoustic_path_available) is not bool:
            raise ValueError("AUDITORY_INVALID_PATH")


@dataclass(frozen=True)
class AuditoryResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]


def detect_auditory(sense: BoundSense, limits: AuditoryLimits,
                    conditions: AuditoryConditions) -> AuditoryResult:
    if not isinstance(sense, BoundSense) or not isinstance(limits, AuditoryLimits) or not isinstance(conditions, AuditoryConditions):
        raise ValueError("AUDITORY_TYPED_INPUTS_REQUIRED")
    if sense.modality != "auditory":
        raise ValueError("AUDITORY_MODALITY_REQUIRED")
    if not isinstance(sense.expression, Expression):
        raise ValueError("AUDITORY_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("AUDITORY_PROFILE_REQUIRED_FOR_EXPRESSION")
        return AuditoryResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",))
    if sense.profile.profile_id != limits.profile_id or sense.profile.modality != "auditory":
        raise ValueError("AUDITORY_PROFILE_MISMATCH")

    signal = conditions.received_signal_db_spl
    noise = conditions.received_noise_db_spl
    blocked = []
    if sense.expression is Expression.LATENT:
        blocked.append("LATENT_SENSE")
    if conditions.acoustic_path_available is False:
        blocked.append("NO_ACOUSTIC_PATH")
    if conditions.distance_m is not None and conditions.distance_m > limits.max_distance_m:
        blocked.append("OUT_OF_RANGE")
    if signal is not None and signal < limits.min_signal_db_spl:
        blocked.append("BELOW_HEARING_THRESHOLD")
    if signal is not None and noise is not None:
        snr = signal - noise
        _finite(snr, "DERIVED_SNR")
        if snr < limits.min_snr_db:
            blocked.append("MASKED_BY_NOISE")
    if blocked:
        return AuditoryResult(sense.hook_id, Detection.NOT_DETECTED, tuple(blocked))

    unknown = []
    if sense.expression is not Expression.ACTIVE:
        unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
    for value, reason in ((conditions.acoustic_path_available, "ACOUSTIC_PATH_UNKNOWN"),
                          (conditions.distance_m, "DISTANCE_UNKNOWN"),
                          (signal, "SIGNAL_UNKNOWN"), (noise, "NOISE_UNKNOWN")):
        if value is None:
            unknown.append(reason)
    if unknown:
        return AuditoryResult(sense.hook_id, Detection.UNRESOLVED, tuple(unknown))
    return AuditoryResult(sense.hook_id, Detection.DETECTED, ("AUDITORY_CONDITIONS_MET",))
