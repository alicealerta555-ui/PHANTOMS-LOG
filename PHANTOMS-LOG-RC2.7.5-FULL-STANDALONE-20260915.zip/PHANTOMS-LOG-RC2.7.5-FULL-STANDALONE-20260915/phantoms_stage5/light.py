# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Calibrated single-receptor light stimulus, without image formation.

Engine supplies nonnegative irradiance in W/m² after attenuation, under an
explicit calibration defining spectral weighting, receptor and time window.
No lux conversion, object identity, photosynthesis or world/knowledge writes.
"""
from dataclasses import dataclass
import math
from .senses import BoundSense, Expression, _text
from .visual import Detection


def _finite(value, field, *, optional=False, minimum=None, positive=False):
    if value is None and optional:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("INVALID_" + field)
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite or (minimum is not None and value < minimum) or (positive and value <= 0):
        raise ValueError("INVALID_" + field)


@dataclass(frozen=True)
class LightLimits:
    profile_id: str
    calibration_id: str
    min_irradiance_w_m2: float

    def __post_init__(self):
        _text(self.profile_id)
        _text(self.calibration_id)
        _finite(self.min_irradiance_w_m2, "LIGHT_IRRADIANCE_THRESHOLD", positive=True)


@dataclass(frozen=True)
class LightConditions:
    calibration_id: str | None
    received_irradiance_w_m2: float | None
    light_path_available: bool | None

    def __post_init__(self):
        if self.calibration_id is not None:
            _text(self.calibration_id)
        _finite(self.received_irradiance_w_m2, "LIGHT_IRRADIANCE", optional=True, minimum=0)
        if self.light_path_available is not None and type(self.light_path_available) is not bool:
            raise ValueError("LIGHT_INVALID_PATH")


@dataclass(frozen=True)
class LightResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]


def detect_light(sense: BoundSense, limits: LightLimits,
                   conditions: LightConditions) -> LightResult:
    if not isinstance(sense, BoundSense) or not isinstance(limits, LightLimits) or not isinstance(conditions, LightConditions):
        raise ValueError("LIGHT_TYPED_INPUTS_REQUIRED")
    if sense.modality != "light_hook":
        raise ValueError("LIGHT_MODALITY_REQUIRED")
    if not isinstance(sense.expression, Expression):
        raise ValueError("LIGHT_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("LIGHT_PROFILE_REQUIRED_FOR_EXPRESSION")
        return LightResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",))
    if sense.profile.profile_id != limits.profile_id or sense.profile.modality != "light_hook":
        raise ValueError("LIGHT_PROFILE_MISMATCH")

    blocked = []
    if sense.expression is Expression.LATENT:
        blocked.append("LATENT_SENSE")
    if conditions.light_path_available is False:
        blocked.append("LIGHT_PATH_BLOCKED")
    if conditions.calibration_id is not None and conditions.calibration_id != limits.calibration_id:
        raise ValueError("LIGHT_CALIBRATION_MISMATCH")
    if conditions.calibration_id == limits.calibration_id and conditions.received_irradiance_w_m2 is not None and conditions.received_irradiance_w_m2 < limits.min_irradiance_w_m2:
        blocked.append("INSUFFICIENT_LIGHT_IRRADIANCE")
    if blocked:
        return LightResult(sense.hook_id, Detection.NOT_DETECTED, tuple(blocked))

    unknown = []
    if sense.expression is not Expression.ACTIVE:
        unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
    for value, reason in ((conditions.light_path_available, "LIGHT_PATH_UNKNOWN"),
                          (conditions.calibration_id, "CALIBRATION_UNKNOWN"),
                          (conditions.received_irradiance_w_m2, "LIGHT_IRRADIANCE_UNKNOWN")):
        if value is None:
            unknown.append(reason)
    if unknown:
        return LightResult(sense.hook_id, Detection.UNRESOLVED, tuple(unknown))
    return LightResult(sense.hook_id, Detection.DETECTED, ("LIGHT_CONDITIONS_MET",))
