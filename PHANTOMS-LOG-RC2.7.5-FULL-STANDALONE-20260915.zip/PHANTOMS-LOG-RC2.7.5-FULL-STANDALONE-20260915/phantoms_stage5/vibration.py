# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""One narrowband mechanical vibration component at a receptor.

Engine supplies frequency and RMS acceleration after propagation, in a common
measurement window. No spectrum decomposition, propagation or source identity.
Zero Hz is allowed as input but outside every positive vibration passband.
"""
from dataclasses import dataclass
import math
from .senses import BoundSense, Expression, _text
from .visual import Detection


def _magnitude(value, *, optional=False, positive=False):
    if value is None and optional:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("VIBRATION_INVALID_MAGNITUDE")
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite or value < 0 or (positive and value == 0):
        raise ValueError("VIBRATION_INVALID_MAGNITUDE")


@dataclass(frozen=True)
class VibrationLimits:
    profile_id: str
    min_frequency_hz: float
    max_frequency_hz: float
    min_acceleration_rms_m_s2: float

    def __post_init__(self):
        _text(self.profile_id)
        _magnitude(self.min_frequency_hz, positive=True)
        _magnitude(self.max_frequency_hz, positive=True)
        if self.max_frequency_hz < self.min_frequency_hz:
            raise ValueError("VIBRATION_INVALID_FREQUENCY_RANGE")
        _magnitude(self.min_acceleration_rms_m_s2, positive=True)


@dataclass(frozen=True)
class VibrationConditions:
    mechanical_path_available: bool | None
    received_frequency_hz: float | None
    received_acceleration_rms_m_s2: float | None

    def __post_init__(self):
        if self.mechanical_path_available is not None and type(self.mechanical_path_available) is not bool:
            raise ValueError("VIBRATION_INVALID_PATH")
        _magnitude(self.received_frequency_hz, optional=True)
        _magnitude(self.received_acceleration_rms_m_s2, optional=True)


@dataclass(frozen=True)
class VibrationResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]


def detect_vibration(sense: BoundSense, limits: VibrationLimits,
                   conditions: VibrationConditions) -> VibrationResult:
    if not isinstance(sense, BoundSense) or not isinstance(limits, VibrationLimits) or not isinstance(conditions, VibrationConditions):
        raise ValueError("VIBRATION_TYPED_INPUTS_REQUIRED")
    if sense.modality != "vibration":
        raise ValueError("VIBRATION_MODALITY_REQUIRED")
    if not isinstance(sense.expression, Expression):
        raise ValueError("VIBRATION_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("VIBRATION_PROFILE_REQUIRED_FOR_EXPRESSION")
        return VibrationResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",))
    if sense.profile.profile_id != limits.profile_id or sense.profile.modality != "vibration":
        raise ValueError("VIBRATION_PROFILE_MISMATCH")

    blocked = []
    if sense.expression is Expression.LATENT:
        blocked.append("LATENT_SENSE")
    if conditions.mechanical_path_available is False:
        blocked.append("NO_MECHANICAL_PATH")
    if conditions.received_acceleration_rms_m_s2 is not None and conditions.received_acceleration_rms_m_s2 < limits.min_acceleration_rms_m_s2:
        blocked.append("INSUFFICIENT_VIBRATION_ACCELERATION")
    if conditions.received_frequency_hz is not None and not limits.min_frequency_hz <= conditions.received_frequency_hz <= limits.max_frequency_hz:
        blocked.append("FREQUENCY_OUT_OF_BAND")
    if blocked:
        return VibrationResult(sense.hook_id, Detection.NOT_DETECTED, tuple(blocked))

    unknown = []
    if sense.expression is not Expression.ACTIVE:
        unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
    if conditions.mechanical_path_available is None:
        unknown.append("MECHANICAL_PATH_UNKNOWN")
    if conditions.received_acceleration_rms_m_s2 is None:
        unknown.append("VIBRATION_ACCELERATION_UNKNOWN")
    if conditions.received_frequency_hz is None:
        unknown.append("FREQUENCY_UNKNOWN")
    if unknown:
        return VibrationResult(sense.hook_id, Detection.UNRESOLVED, tuple(unknown))
    return VibrationResult(sense.hook_id, Detection.DETECTED, ("VIBRATION_CONDITIONS_MET",))
