# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Signed pressure difference detection relative to an explicit engine reference.

Receiver-side differential pressure in Pa, not absolute pressure, contact load,
acoustic SPL or a biological survival range. No reference adaptation or state.
"""
from dataclasses import dataclass
import math
from .senses import BoundSense, Expression, _text
from .visual import Detection


def _finite(value, field, *, optional=False, minimum=None, positive=False):
    if value is None and optional:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("INVALID_" + field)
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite or (minimum is not None and value < minimum) or (positive and value <= 0):
        raise ValueError("INVALID_" + field)


@dataclass(frozen=True)
class PressureLimits:
    profile_id: str
    reference_id: str
    min_abs_difference_pa: float
    modality: str = "pressure"

    def __post_init__(self):
        _text(self.profile_id)
        if self.modality not in ("pressure", "pressure_hook"):
            raise ValueError("PRESSURE_UNSUPPORTED_MODALITY")
        _text(self.reference_id)
        _finite(self.min_abs_difference_pa, "PRESSURE_DIFFERENCE_THRESHOLD", positive=True)


@dataclass(frozen=True)
class PressureConditions:
    reference_id: str | None
    received_difference_pa: float | None
    pressure_path_available: bool | None

    def __post_init__(self):
        if self.reference_id is not None:
            _text(self.reference_id)
        _finite(self.received_difference_pa, "PRESSURE_DIFFERENCE", optional=True)
        if self.pressure_path_available is not None and type(self.pressure_path_available) is not bool:
            raise ValueError("PRESSURE_INVALID_PATH")


@dataclass(frozen=True)
class PressureResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]


def detect_pressure(sense: BoundSense, limits: PressureLimits,
                   conditions: PressureConditions) -> PressureResult:
    if not isinstance(sense, BoundSense) or not isinstance(limits, PressureLimits) or not isinstance(conditions, PressureConditions):
        raise ValueError("PRESSURE_TYPED_INPUTS_REQUIRED")
    if sense.modality != limits.modality:
        raise ValueError("PRESSURE_MODALITY_REQUIRED")
    if not isinstance(sense.expression, Expression):
        raise ValueError("PRESSURE_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("PRESSURE_PROFILE_REQUIRED_FOR_EXPRESSION")
        return PressureResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",))
    if sense.profile.profile_id != limits.profile_id or sense.profile.modality != limits.modality:
        raise ValueError("PRESSURE_PROFILE_MISMATCH")

    blocked = []
    if sense.expression is Expression.LATENT:
        blocked.append("LATENT_SENSE")
    if conditions.pressure_path_available is False:
        blocked.append("PRESSURE_PATH_BLOCKED")
    if conditions.reference_id is not None and conditions.reference_id != limits.reference_id:
        raise ValueError("PRESSURE_REFERENCE_MISMATCH")
    if conditions.reference_id == limits.reference_id and conditions.received_difference_pa is not None and abs(conditions.received_difference_pa) < limits.min_abs_difference_pa:
        blocked.append("INSUFFICIENT_PRESSURE_DIFFERENCE")
    if blocked:
        return PressureResult(sense.hook_id, Detection.NOT_DETECTED, tuple(blocked))

    unknown = []
    if sense.expression is not Expression.ACTIVE:
        unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
    for value, reason in ((conditions.pressure_path_available, "PRESSURE_PATH_UNKNOWN"),
                          (conditions.reference_id, "REFERENCE_UNKNOWN"),
                          (conditions.received_difference_pa, "PRESSURE_DIFFERENCE_UNKNOWN")):
        if value is None:
            unknown.append(reason)
    if unknown:
        return PressureResult(sense.hook_id, Detection.UNRESOLVED, tuple(unknown))
    return PressureResult(sense.hook_id, Detection.DETECTED, ("PRESSURE_CONDITIONS_MET",))
