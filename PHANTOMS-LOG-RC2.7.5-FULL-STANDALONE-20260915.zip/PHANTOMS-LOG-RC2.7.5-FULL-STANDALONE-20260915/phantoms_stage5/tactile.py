# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Single-site normal-contact detection; no texture, pain or object knowledge.

The engine supplies effective contact pressure at the receptor after any
intervening material. This models only one tactile stimulus class, not every
mechanoreceptor response. Atmospheric pressure and vibration are not aliases.
"""
from dataclasses import dataclass
import math
from .senses import BoundSense, Expression, _text
from .visual import Detection


def _pressure(value, *, optional=False, positive=False):
    if value is None and optional:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("TACTILE_INVALID_PRESSURE")
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite or value < 0 or (positive and value == 0):
        raise ValueError("TACTILE_INVALID_PRESSURE")


@dataclass(frozen=True)
class TactileLimits:
    profile_id: str
    min_contact_pressure_pa: float

    def __post_init__(self):
        _text(self.profile_id)
        _pressure(self.min_contact_pressure_pa, positive=True)


@dataclass(frozen=True)
class TactileConditions:
    contact_available: bool | None
    received_contact_pressure_pa: float | None

    def __post_init__(self):
        if self.contact_available is not None and type(self.contact_available) is not bool:
            raise ValueError("TACTILE_INVALID_CONTACT")
        _pressure(self.received_contact_pressure_pa, optional=True)


@dataclass(frozen=True)
class TactileResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]


def detect_tactile(sense: BoundSense, limits: TactileLimits,
                   conditions: TactileConditions) -> TactileResult:
    if not isinstance(sense, BoundSense) or not isinstance(limits, TactileLimits) or not isinstance(conditions, TactileConditions):
        raise ValueError("TACTILE_TYPED_INPUTS_REQUIRED")
    if sense.modality != "tactile":
        raise ValueError("TACTILE_MODALITY_REQUIRED")
    if not isinstance(sense.expression, Expression):
        raise ValueError("TACTILE_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("TACTILE_PROFILE_REQUIRED_FOR_EXPRESSION")
        return TactileResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",))
    if sense.profile.profile_id != limits.profile_id or sense.profile.modality != "tactile":
        raise ValueError("TACTILE_PROFILE_MISMATCH")

    blocked = []
    if sense.expression is Expression.LATENT:
        blocked.append("LATENT_SENSE")
    if conditions.contact_available is False:
        blocked.append("NO_CONTACT")
    if conditions.received_contact_pressure_pa is not None and conditions.received_contact_pressure_pa < limits.min_contact_pressure_pa:
        blocked.append("INSUFFICIENT_CONTACT_PRESSURE")
    if blocked:
        return TactileResult(sense.hook_id, Detection.NOT_DETECTED, tuple(blocked))

    unknown = []
    if sense.expression is not Expression.ACTIVE:
        unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
    if conditions.contact_available is None:
        unknown.append("CONTACT_UNKNOWN")
    if conditions.received_contact_pressure_pa is None:
        unknown.append("CONTACT_PRESSURE_UNKNOWN")
    if unknown:
        return TactileResult(sense.hook_id, Detection.UNRESOLVED, tuple(unknown))
    return TactileResult(sense.hook_id, Detection.DETECTED, ("TACTILE_CONDITIONS_MET",))
