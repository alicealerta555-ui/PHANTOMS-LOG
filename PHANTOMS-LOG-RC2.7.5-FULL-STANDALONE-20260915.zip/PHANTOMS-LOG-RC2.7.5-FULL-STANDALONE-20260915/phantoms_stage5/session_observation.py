# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Visual observation bound to one live session; no current/last-run fallback."""
from runtime.stage3c.isolation import RunIdentity, RunSessionManager
from .observation_adapter import VisualObservationAdapter


class SessionVisualObserver:
    def __init__(self, manager, identity, *, lineage_id, actor_id=None):
        if not isinstance(manager, RunSessionManager) or not isinstance(identity, RunIdentity):
            raise ValueError("SESSION_MANAGER_AND_IDENTITY_REQUIRED")
        self._manager = manager
        self._identity = identity
        self._session = manager.get_run(**identity.as_dict())
        self._session.assert_identity(identity)
        self._engine = self._session.epistemics
        self._adapter = VisualObservationAdapter(self._engine, lineage_id=lineage_id, actor_id=actor_id)

    def observe(self, identity, sense, limits, conditions, *, event_id, location, world_time):
        if not isinstance(identity, RunIdentity) or identity != self._identity:
            raise ValueError("OBSERVATION_RUN_IDENTITY_MISMATCH")
        current = self._manager.get_run(**identity.as_dict())
        current.assert_identity(identity)
        if current is not self._session or current.epistemics is not self._engine:
            raise ValueError("OBSERVATION_SESSION_REPLACED_REBIND_REQUIRED")
        return self._adapter.observe(sense, limits, conditions, event_id=event_id,
                                     location=location, world_time=world_time)
