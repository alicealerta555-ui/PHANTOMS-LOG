# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Single-axis magnetic stimulus threshold; no compass or navigation output.

Engine supplies a signed local magnetic flux-density component in microtesla
under a calibration defining receptor axis, frame and response window.
No vector projection, field propagation, source attribution or knowledge writes.
"""
from dataclasses import dataclass
import math
from .senses import BoundSense, Expression, _text
from .visual import Detection


def _finite(value, field, *, optional=False, minimum=None, positive=False):
    if value is None and optional:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("INVALID_" + field)
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite or (minimum is not None and value < minimum) or (positive and value <= 0):
        raise ValueError("INVALID_" + field)


@dataclass(frozen=True)
class MagneticLimits:
    profile_id: str
    calibration_id: str
    min_abs_field_component_ut: float

    def __post_init__(self):
        _text(self.profile_id)
        _text(self.calibration_id)
        _finite(self.min_abs_field_component_ut, "MAGNETIC_FIELD_COMPONENT_THRESHOLD", positive=True)


@dataclass(frozen=True)
class MagneticConditions:
    calibration_id: str | None
    received_field_component_ut: float | None
    receptor_coupling_available: bool | None

    def __post_init__(self):
        if self.calibration_id is not None:
            _text(self.calibration_id)
        _finite(self.received_field_component_ut, "MAGNETIC_FIELD_COMPONENT", optional=True)
        if self.receptor_coupling_available is not None and type(self.receptor_coupling_available) is not bool:
            raise ValueError("MAGNETIC_INVALID_PATH")


@dataclass(frozen=True)
class MagneticResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]


def detect_magnetic(sense: BoundSense, limits: MagneticLimits,
                   conditions: MagneticConditions) -> MagneticResult:
    if not isinstance(sense, BoundSense) or not isinstance(limits, MagneticLimits) or not isinstance(conditions, MagneticConditions):
        raise ValueError("MAGNETIC_TYPED_INPUTS_REQUIRED")
    if sense.modality != "magnetoreception_hook":
        raise ValueError("MAGNETIC_MODALITY_REQUIRED")
    if not isinstance(sense.expression, Expression):
        raise ValueError("MAGNETIC_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("MAGNETIC_PROFILE_REQUIRED_FOR_EXPRESSION")
        return MagneticResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",))
    if sense.profile.profile_id != limits.profile_id or sense.profile.modality != "magnetoreception_hook":
        raise ValueError("MAGNETIC_PROFILE_MISMATCH")

    blocked = []
    if sense.expression is Expression.LATENT:
        blocked.append("LATENT_SENSE")
    if conditions.receptor_coupling_available is False:
        blocked.append("RECEPTOR_COUPLING_BLOCKED")
    if conditions.calibration_id is not None and conditions.calibration_id != limits.calibration_id:
        raise ValueError("MAGNETIC_CALIBRATION_MISMATCH")
    if conditions.calibration_id == limits.calibration_id and conditions.received_field_component_ut is not None and abs(conditions.received_field_component_ut) < limits.min_abs_field_component_ut:
        blocked.append("INSUFFICIENT_MAGNETIC_FIELD_COMPONENT")
    if blocked:
        return MagneticResult(sense.hook_id, Detection.NOT_DETECTED, tuple(blocked))

    unknown = []
    if sense.expression is not Expression.ACTIVE:
        unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
    for value, reason in ((conditions.receptor_coupling_available, "RECEPTOR_COUPLING_UNKNOWN"),
                          (conditions.calibration_id, "CALIBRATION_UNKNOWN"),
                          (conditions.received_field_component_ut, "MAGNETIC_FIELD_COMPONENT_UNKNOWN")):
        if value is None:
            unknown.append(reason)
    if unknown:
        return MagneticResult(sense.hook_id, Detection.UNRESOLVED, tuple(unknown))
    return MagneticResult(sense.hook_id, Detection.DETECTED, ("MAGNETIC_CONDITIONS_MET",))
