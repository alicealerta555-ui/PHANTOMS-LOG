# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Threshold detection of linear polarization under explicit calibration.

Engine supplies received total irradiance W/m² and degree of linear polarization
(0..1) for the same spectral band, receptor aperture and time window. No angle,
Stokes reconstruction, circular-polarization detection or knowledge writes.
"""
from dataclasses import dataclass
import math
from .senses import BoundSense, Expression, _text
from .visual import Detection


def _finite(value, field, *, optional=False, minimum=None, positive=False):
    if value is None and optional:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("INVALID_" + field)
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite or (minimum is not None and value < minimum) or (positive and value <= 0):
        raise ValueError("INVALID_" + field)


def _fraction(value, *, optional=False, positive=False):
    _finite(value, "POLARIZATION_FRACTION", optional=optional, minimum=0, positive=positive)
    if value is not None and value > 1:
        raise ValueError("INVALID_POLARIZATION_FRACTION")


@dataclass(frozen=True)
class PolarizationLimits:
    profile_id: str
    calibration_id: str
    min_irradiance_w_m2: float
    min_linear_fraction: float

    def __post_init__(self):
        _fraction(self.min_linear_fraction, positive=True)
        _text(self.profile_id)
        _text(self.calibration_id)
        _finite(self.min_irradiance_w_m2, "POLARIZATION_IRRADIANCE_THRESHOLD", positive=True)


@dataclass(frozen=True)
class PolarizationConditions:
    calibration_id: str | None
    received_irradiance_w_m2: float | None
    polarization_path_available: bool | None
    received_linear_fraction: float | None

    def __post_init__(self):
        _fraction(self.received_linear_fraction, optional=True)
        if self.calibration_id is not None:
            _text(self.calibration_id)
        _finite(self.received_irradiance_w_m2, "POLARIZATION_IRRADIANCE", optional=True, minimum=0)
        if self.polarization_path_available is not None and type(self.polarization_path_available) is not bool:
            raise ValueError("POLARIZATION_INVALID_PATH")


@dataclass(frozen=True)
class PolarizationResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]


def detect_polarization(sense: BoundSense, limits: PolarizationLimits,
                   conditions: PolarizationConditions) -> PolarizationResult:
    if not isinstance(sense, BoundSense) or not isinstance(limits, PolarizationLimits) or not isinstance(conditions, PolarizationConditions):
        raise ValueError("POLARIZATION_TYPED_INPUTS_REQUIRED")
    if sense.modality != "polarization_hook":
        raise ValueError("POLARIZATION_MODALITY_REQUIRED")
    if not isinstance(sense.expression, Expression):
        raise ValueError("POLARIZATION_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("POLARIZATION_PROFILE_REQUIRED_FOR_EXPRESSION")
        return PolarizationResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",))
    if sense.profile.profile_id != limits.profile_id or sense.profile.modality != "polarization_hook":
        raise ValueError("POLARIZATION_PROFILE_MISMATCH")

    blocked = []
    if sense.expression is Expression.LATENT:
        blocked.append("LATENT_SENSE")
    if conditions.polarization_path_available is False:
        blocked.append("POLARIZATION_PATH_BLOCKED")
    if conditions.calibration_id is not None and conditions.calibration_id != limits.calibration_id:
        raise ValueError("POLARIZATION_CALIBRATION_MISMATCH")
    if conditions.calibration_id == limits.calibration_id and conditions.received_irradiance_w_m2 is not None and conditions.received_irradiance_w_m2 < limits.min_irradiance_w_m2:
        blocked.append("INSUFFICIENT_POLARIZATION_IRRADIANCE")
    if conditions.calibration_id == limits.calibration_id and conditions.received_linear_fraction is not None and conditions.received_linear_fraction < limits.min_linear_fraction:
        blocked.append("INSUFFICIENT_LINEAR_POLARIZATION")
    if blocked:
        return PolarizationResult(sense.hook_id, Detection.NOT_DETECTED, tuple(blocked))

    unknown = []
    if sense.expression is not Expression.ACTIVE:
        unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
    for value, reason in ((conditions.polarization_path_available, "POLARIZATION_PATH_UNKNOWN"),
                          (conditions.calibration_id, "CALIBRATION_UNKNOWN"),
                          (conditions.received_linear_fraction, "LINEAR_FRACTION_UNKNOWN"),
                          (conditions.received_irradiance_w_m2, "POLARIZATION_IRRADIANCE_UNKNOWN")):
        if value is None:
            unknown.append(reason)
    if unknown:
        return PolarizationResult(sense.hook_id, Detection.UNRESOLVED, tuple(unknown))
    return PolarizationResult(sense.hook_id, Detection.DETECTED, ("POLARIZATION_CONDITIONS_MET",))
