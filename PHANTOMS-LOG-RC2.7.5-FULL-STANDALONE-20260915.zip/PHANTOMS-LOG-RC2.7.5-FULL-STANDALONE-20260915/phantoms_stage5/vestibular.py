# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Single-axis vestibular angular-response threshold for a game engine.

The engine supplies signed receptor-filtered angular response in rad/s, under
an explicit calibration (axis, frame, time window and temporal response model).
It is not raw world angular speed. No balance, heading or position inference.
"""
from dataclasses import dataclass
import math
from .senses import BoundSense, Expression, _text
from .visual import Detection


def _finite(value, field, *, optional=False, minimum=None, positive=False):
    if value is None and optional:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("INVALID_" + field)
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite or (minimum is not None and value < minimum) or (positive and value <= 0):
        raise ValueError("INVALID_" + field)


@dataclass(frozen=True)
class VestibularLimits:
    profile_id: str
    calibration_id: str
    min_abs_angular_response_rad_s: float

    def __post_init__(self):
        _text(self.profile_id)
        _text(self.calibration_id)
        _finite(self.min_abs_angular_response_rad_s, "VESTIBULAR_ANGULAR_RESPONSE_THRESHOLD", positive=True)


@dataclass(frozen=True)
class VestibularConditions:
    calibration_id: str | None
    received_angular_response_rad_s: float | None
    receptor_coupling_available: bool | None

    def __post_init__(self):
        if self.calibration_id is not None:
            _text(self.calibration_id)
        _finite(self.received_angular_response_rad_s, "VESTIBULAR_ANGULAR_RESPONSE", optional=True)
        if self.receptor_coupling_available is not None and type(self.receptor_coupling_available) is not bool:
            raise ValueError("VESTIBULAR_INVALID_PATH")


@dataclass(frozen=True)
class VestibularResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]


def detect_vestibular(sense: BoundSense, limits: VestibularLimits,
                   conditions: VestibularConditions) -> VestibularResult:
    if not isinstance(sense, BoundSense) or not isinstance(limits, VestibularLimits) or not isinstance(conditions, VestibularConditions):
        raise ValueError("VESTIBULAR_TYPED_INPUTS_REQUIRED")
    if sense.modality != "vestibular":
        raise ValueError("VESTIBULAR_MODALITY_REQUIRED")
    if not isinstance(sense.expression, Expression):
        raise ValueError("VESTIBULAR_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("VESTIBULAR_PROFILE_REQUIRED_FOR_EXPRESSION")
        return VestibularResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",))
    if sense.profile.profile_id != limits.profile_id or sense.profile.modality != "vestibular":
        raise ValueError("VESTIBULAR_PROFILE_MISMATCH")

    blocked = []
    if sense.expression is Expression.LATENT:
        blocked.append("LATENT_SENSE")
    if conditions.receptor_coupling_available is False:
        blocked.append("RECEPTOR_COUPLING_BLOCKED")
    if conditions.calibration_id is not None and conditions.calibration_id != limits.calibration_id:
        raise ValueError("VESTIBULAR_CALIBRATION_MISMATCH")
    if conditions.calibration_id == limits.calibration_id and conditions.received_angular_response_rad_s is not None and abs(conditions.received_angular_response_rad_s) < limits.min_abs_angular_response_rad_s:
        blocked.append("INSUFFICIENT_VESTIBULAR_ANGULAR_RESPONSE")
    if blocked:
        return VestibularResult(sense.hook_id, Detection.NOT_DETECTED, tuple(blocked))

    unknown = []
    if sense.expression is not Expression.ACTIVE:
        unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
    for value, reason in ((conditions.receptor_coupling_available, "RECEPTOR_COUPLING_UNKNOWN"),
                          (conditions.calibration_id, "CALIBRATION_UNKNOWN"),
                          (conditions.received_angular_response_rad_s, "VESTIBULAR_ANGULAR_RESPONSE_UNKNOWN")):
        if value is None:
            unknown.append(reason)
    if unknown:
        return VestibularResult(sense.hook_id, Detection.UNRESOLVED, tuple(unknown))
    return VestibularResult(sense.hook_id, Detection.DETECTED, ("VESTIBULAR_CONDITIONS_MET",))
