# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
"""Single-signature detection from trusted receptor-side concentrations.

No plume simulation, chemical identification, toxicity inference or knowledge
write. Signature IDs and transport media are engine-owned exact identifiers.
"""
from dataclasses import dataclass
import math
from .senses import BoundSense, Expression, _text
from .visual import Detection


def _concentration(value, *, optional=False, positive=False):
    if value is None and optional:
        return
    valid = not isinstance(value, bool) and isinstance(value, (int, float))
    if valid:
        try:
            valid = math.isfinite(value) and value >= 0 and (not positive or value > 0)
        except OverflowError:
            valid = False
    if not valid:
        raise ValueError("CHEMICAL_INVALID_CONCENTRATION")


@dataclass(frozen=True)
class ChemicalLimits:
    profile_id: str
    modality: str
    signature_id: str
    medium_id: str
    min_concentration_mol_m3: float

    def __post_init__(self):
        for value in (self.profile_id, self.signature_id, self.medium_id):
            _text(value)
        if self.modality not in ("chemical", "olfactory"):
            raise ValueError("CHEMICAL_EXPLICIT_MODALITY_REQUIRED")
        _concentration(self.min_concentration_mol_m3, positive=True)


@dataclass(frozen=True)
class ChemicalConditions:
    received_signature_id: str | None
    received_medium_id: str | None
    received_concentration_mol_m3: float | None
    transport_available: bool | None

    def __post_init__(self):
        for value in (self.received_signature_id, self.received_medium_id):
            if value is not None:
                _text(value)
        _concentration(self.received_concentration_mol_m3, optional=True)
        if self.transport_available is not None and type(self.transport_available) is not bool:
            raise ValueError("CHEMICAL_INVALID_TRANSPORT")


@dataclass(frozen=True)
class ChemicalResult:
    hook_id: str
    detection: Detection
    reasons: tuple[str, ...]


def detect_chemical(sense: BoundSense, limits: ChemicalLimits,
                    conditions: ChemicalConditions) -> ChemicalResult:
    if not isinstance(sense, BoundSense) or not isinstance(limits, ChemicalLimits) or not isinstance(conditions, ChemicalConditions):
        raise ValueError("CHEMICAL_TYPED_INPUTS_REQUIRED")
    if sense.modality != limits.modality:
        raise ValueError("CHEMICAL_MODALITY_MISMATCH")
    if not isinstance(sense.expression, Expression):
        raise ValueError("CHEMICAL_EXPRESSION_REQUIRED")
    if sense.profile is None:
        if sense.expression is not Expression.UNRESOLVED:
            raise ValueError("CHEMICAL_PROFILE_REQUIRED_FOR_EXPRESSION")
        return ChemicalResult(sense.hook_id, Detection.UNRESOLVED, ("PROFILE_UNBOUND",))
    if sense.profile.profile_id != limits.profile_id or sense.profile.modality != limits.modality:
        raise ValueError("CHEMICAL_PROFILE_MISMATCH")

    blocked = []
    if sense.expression is Expression.LATENT:
        blocked.append("LATENT_SENSE")
    if conditions.transport_available is False:
        blocked.append("NO_CHEMICAL_TRANSPORT")
    if conditions.received_signature_id is not None and conditions.received_signature_id != limits.signature_id:
        blocked.append("SIGNATURE_NOT_SENSITIVE")
    if conditions.received_medium_id is not None and conditions.received_medium_id != limits.medium_id:
        blocked.append("MEDIUM_NOT_SUPPORTED")
    if conditions.received_concentration_mol_m3 is not None and conditions.received_concentration_mol_m3 < limits.min_concentration_mol_m3:
        blocked.append("BELOW_CONCENTRATION_THRESHOLD")
    if blocked:
        return ChemicalResult(sense.hook_id, Detection.NOT_DETECTED, tuple(blocked))

    unknown = []
    if sense.expression is not Expression.ACTIVE:
        unknown.append("EXPRESSION_NOT_RESOLVED_ACTIVE")
    for value, reason in ((conditions.received_signature_id, "SIGNATURE_UNKNOWN"),
                          (conditions.received_medium_id, "MEDIUM_UNKNOWN"),
                          (conditions.received_concentration_mol_m3, "CONCENTRATION_UNKNOWN"),
                          (conditions.transport_available, "TRANSPORT_UNKNOWN")):
        if value is None:
            unknown.append(reason)
    if unknown:
        return ChemicalResult(sense.hook_id, Detection.UNRESOLVED, tuple(unknown))
    return ChemicalResult(sense.hook_id, Detection.DETECTED, ("CHEMICAL_CONDITIONS_MET",))
