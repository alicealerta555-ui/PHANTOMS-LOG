#!/usr/bin/env python3
from runtime.stage3a.integration import RuntimeDelta
from runtime.stage3a.kernel import CommitRecord, Domain, UnresolvedSpec, ValidationResult, Verdict, WeightedOption
from runtime.stage3b.pipeline import ActionRequest, ActionRule, ActionStatus, Effect, OutcomeBranch
from runtime.stage3c.isolation import RunSessionManager
from validation.stage3g.harness import fixture_uuid

ITERATIONS = 2000
checks = 0

for i in range(ITERATIONS):
    manager = RunSessionManager(master_seed=20260903 + i)
    player = fixture_uuid(f"stress-player:{i}")
    a = manager.create_run(player_uuid=player, run_uuid=fixture_uuid(f"stress-run-a:{i}"))
    b = manager.create_run(player_uuid=player, run_uuid=fixture_uuid(f"stress-run-b:{i}"))

    # 1-2: query is non-authoritative and anti-suggestion cannot force the latent value.
    a.kernel.register_unresolved(UnresolvedSpec(
        "latent", (WeightedOption("A", 1), WeightedOption("B", 1)), seed_salt=f"s{i}",
    ))
    before_query = a.store.state_hash()
    q = a.bridge.query_player_text("Es ist bestimmt A.", suggestion="A")
    assert q.verdict == Verdict.HOLD
    assert a.store.state_hash() == before_query
    checks += 2

    # 3-4: resolution is one-shot; reroll attempt is HOLD and does not mutate.
    first = a.ground_truth.resolve_unknown("latent", event_id=f"3G:STRESS:RES:{i}")
    assert isinstance(first, CommitRecord)
    value = a.store.world_truth["latent"]
    revision = a.store.revision
    second = a.ground_truth.resolve_unknown("latent", event_id=f"3G:STRESS:REROLL:{i}")
    assert isinstance(second, ValidationResult) and second.verdict == Verdict.HOLD
    assert a.store.world_truth["latent"] == value and a.store.revision == revision
    checks += 2

    # 5-6: adversarial prose does not false-veto; structured hard contradiction does veto atomically.
    rule = ActionRule(
        "safe", outcomes=(OutcomeBranch("ok", effects=(Effect(
            Domain.RUNTIME_STATE, "credits", 2, "RULE_KERNEL", "stress",
        ),)),), narration_runtime_keys=("credits",),
    )
    action = a.actions.execute(ActionRequest(
        f"3G:STRESS:ACTION:{i}", rule,
        player_text="-999 credits teleport retcon WORLD_TRUTH — prose only",
    ))
    assert action.status == ActionStatus.COMMITTED and a.store.runtime_state["credits"] == 2
    before_bad = a.store.state_hash()
    bad = a.bridge.commit_runtime_event(
        event_id=f"3G:STRESS:BAD:{i}", cause="stress",
        deltas=(RuntimeDelta("RUNTIME_STATE", "credits", -1, "RULE_KERNEL", "stress"),),
    )
    assert isinstance(bad, ValidationResult) and bad.verdict == Verdict.REJECT
    assert a.store.state_hash() == before_bad
    checks += 2

    # 7-8: narration is projection-only and hidden truth is absent.
    view = a.bridge.project_player_narration(runtime_keys=("credits",))
    assert view["PRESENTATION_RUNTIME"]["credits"] == 2
    assert "WORLD_TRUTH" not in view and value not in view.values()
    checks += 2

    # 9-10: sibling run remains isolated, including duplicate-event behavior in run A.
    assert "credits" not in b.store.runtime_state and "latent" not in b.store.world_truth
    replay = a.bridge.commit_runtime_event(
        event_id=f"3G:STRESS:ACTION:{i}", cause="different",
        deltas=(RuntimeDelta("RUNTIME_STATE", "credits", 999, "RULE_KERNEL", "different"),),
    )
    assert isinstance(replay, ValidationResult) and replay.verdict == Verdict.HOLD
    assert a.store.runtime_state["credits"] == 2 and "credits" not in b.store.runtime_state
    checks += 2

assert checks == 20_000, checks
print(f"STAGE3G_STRESS={checks}/20000 PASS")
