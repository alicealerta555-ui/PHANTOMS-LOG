# RC2.6.8 Survival Consequence Hotfix

Embodied needs are now connected to authoritative mechanical consequences.

- >=70% hydration pressure: dehydration-impaired status
- >=90% hydration pressure: critical dehydration; sustained 6 critical hours causes 1 HP damage
- >=70% nutrition pressure: starvation-impaired status
- >=90% nutrition pressure: critical starvation; sustained 24 critical hours causes 1 HP damage
- >=70% rest pressure: exhaustion-impaired status
- >=90% rest pressure: critical exhaustion; no direct HP damage from exhaustion alone
- >=70% climate pressure: exposure-impaired status
- >=90% climate pressure: critical exposure; sustained 4 critical hours causes 1 HP damage
- leaving the critical band clears the corresponding critical-time accumulator
- HP loss and survival status flags are committed to authoritative actor state and persist with saves

The existing Stage-7 embodied-needs store remains canonical for hunger, thirst, rest and climate pressure.

Validation: 26 targeted survival/status regressions pass. A broader pytest run reached 44% with no failure before the execution-window timeout; this is not claimed as a complete full-suite pass.
