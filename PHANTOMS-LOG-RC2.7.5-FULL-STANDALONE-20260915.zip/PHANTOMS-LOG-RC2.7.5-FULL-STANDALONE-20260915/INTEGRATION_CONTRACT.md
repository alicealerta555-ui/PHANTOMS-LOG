# Integration Contract — Etappe 5

## Canonical boundary
All hidden-progression UI / narrator output must go through `DevelopmentPresenter`.

Do not serialize `PlayerProgressionState`, `InsightCandidate`, affinity maps, thresholds, readiness values or effect keys directly into user-visible responses.

## Public presentation methods
- `DevelopmentPresenter.insight_unlock(...)`
- `DevelopmentPresenter.specialization_offer(...)`
- `DevelopmentPresenter.specialization_committed(...)`
- `DevelopmentPresenter.mastery_reveal(...)`
- `DevelopmentPresenter.end_path_reveal(...)`
- `DevelopmentPresenter.development_snapshot(...)`
- `DevelopmentPresenter.soft_growth_hint(...)`

`assert_player_payload_clean(...)` is the fail-closed validation gate for all progression payloads before they reach the game UI / narrator.

## Internal data remains numeric
Numeric affinity and readiness data remains valid in save/runtime state. This is intentional and required for balancing. It must never be echoed to the player as character-development information.
