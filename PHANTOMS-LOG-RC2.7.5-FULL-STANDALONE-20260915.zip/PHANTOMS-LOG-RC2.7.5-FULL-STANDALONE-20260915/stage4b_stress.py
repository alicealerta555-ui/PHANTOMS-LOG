from dataclasses import replace

from runtime.stage4b import (
    EnvironmentalEnvelope,
    GenelineMatrix,
    GenelineRecord,
    HybridizationProfile,
    KnownBiologicalConstraint,
    LineageProvenance,
    MetabolismProfile,
    MorphologyProfile,
    OriginPackageLink,
    RegenerationProfile,
    SensorCapabilityHook,
    StabilityProfile,
    StabilityStatus,
    validate_geneline_record,
)


def make_record(i: int) -> GenelineRecord:
    return GenelineRecord(
        lineage_id=f"STRESS_{i:05d}",
        display_name=f"Synthetic lineage {i}",
        origin_packages=OriginPackageLink(),
        morphology=MorphologyProfile(("bilateral",), ("terrestrial",), ("stress_fixture",)),
        metabolism=MetabolismProfile(("heterotrophic",), energetic_cost_tags=("nonzero",)),
        environment=EnvironmentalEnvelope(("terrestrial",)),
        regeneration=RegenerationProfile("NONE"),
        sensor_hooks=(SensorCapabilityHook(f"HOOK_{i:05d}", "thermal" if i % 2 else "vibration"),),
        stability=StabilityProfile(StabilityStatus.ROBUST if i % 3 else StabilityStatus.CONTEXT_DEPENDENT),
        hybridization=HybridizationProfile((f"SRC_{i % 17}",), i % 5),
        known_constraints=(KnownBiologicalConstraint(f"C_{i:05d}", "test", "Synthetic non-player fixture constraint."),),
        provenance=LineageProvenance("B3", "E3", ("STRESS_FIXTURE",)),
    )


def main() -> None:
    checks = 0
    matrix = GenelineMatrix()
    # Keep the registry bounded; the stress target is schema validation, not memory growth.
    for i in range(20_000):
        record = make_record(i)
        validate_geneline_record(record)
        checks += 1

        if i < 256:
            matrix.register(record)
        if i % 2 == 0:
            bad = replace(record, morphology=replace(record.morphology, structural_traits=("personality:obedient",)))
            try:
                validate_geneline_record(bad)
            except ValueError:
                pass
            else:
                raise AssertionError("GENETIC_DETERMINISM_ACCEPTED")
        else:
            bad = replace(record, regeneration=RegenerationProfile("FAST_REPAIR"))
            try:
                validate_geneline_record(bad)
            except ValueError:
                pass
            else:
                raise AssertionError("COST_FREE_REGENERATION_ACCEPTED")

    if len(matrix) != 256:
        raise AssertionError("MATRIX_REGISTRY_COUNT_INVALID")
    print(f"STAGE4B_STRESS={checks}/{checks} PASS")


if __name__ == "__main__":
    main()
