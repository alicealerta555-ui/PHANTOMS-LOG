# PH4NT0M5-L0G FULL RC2.4 CLEAN CURRENT

Release date: 2026-09-13

RC2.4 is the single current source tree. It keeps the newest RC2.3 adaptive,
NPC-life, psychology, memory, social and content systems and restores the newer
RC2.1 playable improvements without reverting RC2.3 code.

Active playable improvements:

- mandatory character creation for every new run;
- prompted opening narration for the start room;
- automatic multimodal arrival perception after movement;
- visible motion, working actors, soundscape and changing/flickering light;
- `/look` reserved for closer inspection;
- asynchronous location-image requests with safe visible-only prompts;
- compact, atomic save handling and side-effect-free load behavior.

Removed from the release:

- retired DEMO-0 history tree;
- historical compatibility module;
- superseded playable E2E prototype runtimes 02 through 09;
- their obsolete duplicate tests and references;
- Python cache and compiled bytecode files.

Source precedence:

1. accepted changes from 2026-09-13;
2. accepted changes from 2026-09-12;
3. frozen Stage 3-10 authority contracts;
4. older archives as external provenance only.
