# RC2.7.3 Working — Crew & Organization (2026-09-15)

- Added distinct Breaker/Ghost/Operator/Resonant crew and organization scaling.
- Added separate Social capacity, Command span, machine bandwidth and specialist-cell capacity.
- Added Controller/Drohnenwart narrow four-skill line and machine-provided drone functions.
- Added hierarchy-gated large organizations, Stage-17 role / Stage-24 rank separation and NPC-consent recruitment.
- Added team templates for dungeon, intelligence, salvage, loot, drones, production, construction, logistics, security, rescue, recruitment and diplomacy.
- Added authority-bound group-operation handoffs; no auto-resolved dungeon/loot/travel/industry outcomes.
- Added `/crew`, `/teamtypen`, `/organisation gründen <Name>` and `/org`.
- Final regression evidence: 4608 main tests + 23 subtests PASS; 3025 capability tests PASS; 216 Stage-5 tests PASS; architecture/release gates PASS.

# Changelog
## RC2.7.2 Working Overlay — 2026-09-15

- Enforced exactly two distinct class talents at level 1; later levels add exactly one talent.
- Added an automatic, skippable class-specific calibration tutorial for BREAKER, GHOST, OPERATOR and RESONANT.
- The tutorial exercises the actually selected start talents through the real capability/talent resolver rather than simulated prose.
- Tutorial completion grants no XP, items, credits, stats, skills, talents or abilities and does not replace the normal world introduction.
- Retained the RC2.7.1 lifetime-owned start, pre-game life history and inheritance/estate flow.
- Added class-tutorial audit and regression coverage.
- Player biological germline inheritance remains deliberately undefined until a canonical playable genetics model exists.


## RC2.7.0 FULL MASTER — 2026-09-15

- Promoted the canonical Capability Tree to project authority: 10 stats → 30 skills → 26 talents → use-earned expertises → class/path specialization.
- Removed current release authority from obsolete character-model and standalone-continuation documents.
- Bound class/path abilities to the canonical character tree rather than a parallel capability model.
- Promoted staged capability resolution and SAFE/EDGE/EXTREME/HARD_LIMIT/INACCESSIBLE zones.
- Preserved partial successes when later action stages fail.
- Hardened action-policy, character-tree, Stage-9 authority, reference and master validation gates.
- Promoted visible-state → AI-authored image-prompt → generator as the current image architecture.
- Added explicit current-project and open-work documents for implemented-vs-pending separation.

## RC2.6.9 Full Standalone Master — 2026-09-14

- Added 1,680 class ability definitions across 84 class/path pools.
- Added hard selected-class/path visibility filtering for class abilities.
- Added one-ability-per-level and 10-of-20 per-pool learning limits.
- Added `/abilities`, `/learn`, and `/ability` playable commands.
- Connected learned abilities to dialogue, NPC-reaction and quest contexts without overriding NPC agency, knowledge or security constraints.
- Added RESONANT sensory weapon/control foundations including magnetic, vibration, pressure, bioelectric and spectrum perception.
- Preserved RC2.6.8 survival modifiers.
- Replaced the active character foundation with the canonical Capability Tree: 10 stats → 30 skills → 26 talents → use-earned expertises.
- Derived all class/path abilities from canonical character-tree stat/skill roots; class abilities no longer form a parallel capability model.
- Added SAFE / EDGE / EXTREME / HARD_LIMIT / INACCESSIBLE resolution zones with hard natural limits evaluated before luck, expertise or tools.
- Added staged capability resolution so earlier successes survive later failure (input → interpretation → setup → execution → control).
- Bound active gameplay families including attack, search, craft, repair, treatment, encrypted data access, rebuilding, corpse investigation and class-ability use to the shared capability runtime.
- Declared ordinary low-risk interactions explicitly as ROUTINE_SAFE rather than silently bypassing capability resolution.
- Added 913 talent scenarios, action-capability policy auditing and process-isolated pytest discovery for release validation.
- Reworked scene imagery as visible game state → structured scene context → AI-authored image prompt → image generator; hidden state is excluded.

# Changelog

### Progression hotfix — XP / level wiring
- Added persistent numeric XP to player progression state.
- Anti-farm-filtered gameplay evidence now awards XP automatically.
- XP now resolves authoritative player level (Level 2 at 12 XP; Level 3 at approximately 36 XP).
- Legacy RC2.6.8 saves without XP backfill XP once from already-earned `pattern_evidence`, preserving prior play progress without double counting.
- Added regression tests for XP gain, level thresholds, persistence and legacy migration.

## RC2.6.8 Public Alpha — 2026-09-14

### Public release preparation

- Relicensed original project material under GPL-3.0.
- Added public README, contributing guide, Git ignore rules and GitHub templates.
- Removed generated Python cache files from the public package.
- Fixed `run_all_tests.sh` Python path so playable integration tests can import `playable.game`.

### NPC behaviour patch

- Added a self-protection/security decision gate to the lived-experience NPC layer.
- Added physical, legal, professional and economic request-risk inputs.
- Added security-sensitive and authorization-required request handling.
- Added role-appropriateness checks.
- Preserved ordinary service interactions and low-risk market negotiation.
- Added regression tests for unauthorized terminal access, authorized access, self-risk, role boundaries, routine service and bargaining.

### Validation

- NPC lived-experience tests: 21/21 passing.
- Primary unit-test suite: 1241 passing after test-runner path fix.

### Known development areas

- Natural-language parser/runtime binding
- Persistent emergent quests and migrations
- NPC conflict, retaliation and deeper psychology
- procedural biome/world generation
- model API and local inference integration
- training/fine-tuning
- graphics and generated imagery
- Added XP progression benchmark documentation, the full Level 1–50 curve, and time-to-Level-50 calibration scenarios.

- survival consequence hotfix: sustained critical thirst, hunger and climate exposure now produce persistent status/HP consequences; exhaustion produces persistent impairment/critical status without direct HP damage
- 26 targeted survival/status regression tests passing

### RC2.6.8 survival-stat correction
- Removed survival-driven HP loss introduced by the prior experimental patch.
- Hunger, thirst, rest and climate pressure now create temporary effective-stat penalties instead of mutating permanent stats.
- Matching talents mitigate condition penalties in their established domains without boosting above the stored base value.
- Bound effective stats into crafting, repair, treatment, encrypted-data access and player combat checks.
- Removed HP from the compact player-facing status panel; legacy internal HP fields remain only for compatibility with older runtime/combat code.
