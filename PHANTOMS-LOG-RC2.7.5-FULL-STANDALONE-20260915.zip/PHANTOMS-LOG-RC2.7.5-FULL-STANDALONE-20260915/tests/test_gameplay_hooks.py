from runtime.player_progression import PlayerLearningRuntime
from runtime.player_progression.livehooks import PlayerDevelopmentCoordinator
from runtime.player_progression.gameplay_hooks import GameplayLearningBridge, ResolvedGameplayEvent
from runtime.player_progression.model import PlayerProgressionState


def bridge():
    state = PlayerProgressionState(player_uuid="p", run_uuid="r", start_class="GHOST")
    rt = PlayerLearningRuntime(progression=state)
    return GameplayLearningBridge(PlayerDevelopmentCoordinator(rt)), rt


def test_uncommitted_action_does_not_learn():
    b, rt = bridge()
    res = b.after_resolution(ResolvedGameplayEvent(domain="movement", action_family="move", committed=False))
    assert res.applied_action_learning is False
    assert rt.tracker_state.accepted_events == 0


def test_npc_action_does_not_learn():
    b, rt = bridge()
    res = b.after_resolution(ResolvedGameplayEvent(domain="combat", action_family="shoot", committed=True, actor_is_player=False))
    assert res.applied_action_learning is False
    assert rt.tracker_state.accepted_events == 0


def test_movement_commit_routes_to_learning():
    b, rt = bridge()
    res = b.after_resolution(ResolvedGameplayEvent(
        domain="movement", action_family="vault", committed=True,
        location_id="zone_a", visible_context_tags=("cover",), difficulty_hint=1.2,
    ))
    assert res.applied_action_learning is True
    assert rt.tracker_state.accepted_events == 1
    assert rt.tracker_state.family_counts["vault"] == 1


def test_hacking_uses_semantic_domain_not_player_text():
    b, rt = bridge()
    b.after_resolution(ResolvedGameplayEvent(
        domain="hacking", action_family="bypass_access", committed=True,
        target_kind="terminal", tool_kind="deck", visible_context_tags=("secured_system",),
    ))
    assert rt.progression.affinities["AFF_NETWORK"] > 0
    assert rt.progression.affinities["AFF_TECH"] > 0


def test_decision_choice_can_form_habit_evidence():
    b, rt = bridge()
    for i in range(12):
        b.after_resolution(ResolvedGameplayEvent(
            domain="exploration", action_family="enter_room", committed=True,
            location_id=f"room_{i}", situation_family="room_entry", choice_key="scan_motion",
            decision_category="perception", visible_context_tags=("unknown_room",),
            consequence_hint=1.0,
        ))
    assert rt.habit_state.decision_counts["room_entry|scan_motion"] >= 1


def test_high_stakes_moral_choice_never_becomes_safe_prediction():
    b, rt = bridge()
    for i in range(20):
        b.after_resolution(ResolvedGameplayEvent(
            domain="dialogue", action_family="faction_choice", committed=True,
            location_id=f"scene_{i}", situation_family="faction_choice", choice_key="betray_faction",
            decision_category="social_choice", high_stakes=True, irreversible=True,
            moral_or_story_choice=True, reversible=False,
        ))
    pred = b.before_decision(situation_family="faction_choice", visible_context_tags=("story",),
                             reversible=False, high_stakes=True)
    assert pred.predicted_routine is None


def test_explicit_player_order_vetoes_prediction():
    b, rt = bridge()
    pred = b.before_decision(situation_family="room_entry", visible_context_tags=("unknown_room",),
                             explicit_player_order=True)
    assert pred.predicted_routine is None


def test_all_primary_domains_supported():
    b, rt = bridge()
    domains = ["movement","combat","interaction","medicine","tech","hacking","dialogue","exploration","survival","crafting"]
    for i, domain in enumerate(domains):
        res = b.after_resolution(ResolvedGameplayEvent(domain=domain, action_family=f"a{i}", committed=True, location_id=f"l{i}"))
        assert res.applied_action_learning is True
    assert rt.tracker_state.accepted_events == len(domains)
