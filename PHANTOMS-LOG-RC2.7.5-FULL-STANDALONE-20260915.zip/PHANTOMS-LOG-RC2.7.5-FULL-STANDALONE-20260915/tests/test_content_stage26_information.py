
import json, unittest
from pathlib import Path
from runtime.content_stage26.information import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage26_information_warfare.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_rumor_provenance(self):
  r=rumor_record("x","a","CHAN_FACE_TO_FACE",1,50,"EV")
  self.assertTrue(valid_rumor(r))
  r["source_actor_id"]=""
  self.assertFalse(valid_rumor(r))

 def test_channel_latency(self):
  r=rumor_record("x","a","CHAN_MARKET_WORD",1,50,"EV")
  c=next(x for x in D["channels"] if x["id"]=="CHAN_MARKET_WORD")
  p=transmit_information(r,c,"a","b",100)
  self.assertEqual(p["arrives_at"],160)
  self.assertTrue(p["authority_required"])

 def test_repetition_not_truth(self):
  e=next(x for x in D["propaganda_effects"] if x["id"]=="PROP_SUPPORT")
  p=propaganda_influence(e,10,0)
  self.assertFalse(p["truth_claimed"]); self.assertFalse(p["auto_belief"])

 def test_prop_bounded(self):
  e=next(x for x in D["propaganda_effects"] if x["id"]=="PROP_FEAR")
  p=propaganda_influence(e,999,0)
  self.assertLessEqual(p["delta"],e["max_delta"])

 def test_resistance_reduces(self):
  e=next(x for x in D["propaganda_effects"] if x["id"]=="PROP_TRUST")
  a=propaganda_influence(e,3,0)["delta"]
  b=propaganda_influence(e,3,9000)["delta"]
  self.assertGreater(a,b)

 def test_opinion_bounded(self):
  x=opinion_delta({"fear":95},"fear",50)
  self.assertEqual(x["fear"],100)

 def test_counter_message_not_retroactive(self):
  self.assertEqual(counter_message_influence(80,30),50)
  self.assertEqual(counter_message_influence(20,50),0)

 def test_cultural_memory_requires_sources(self):
  r=cultural_memory_record("M","subject","narrative",[],0,1,70)
  self.assertFalse(validate_cultural_memory(r))

 def test_cultural_memory_valid(self):
  r=cultural_memory_record("M","subject","narrative",["SRC"],0,1,70)
  self.assertTrue(validate_cultural_memory(r))

 def test_contradictions_allowed(self):
  self.assertTrue(D["cultural_memory_contract"]["contradictions_allowed"])

if __name__=="__main__": unittest.main()
