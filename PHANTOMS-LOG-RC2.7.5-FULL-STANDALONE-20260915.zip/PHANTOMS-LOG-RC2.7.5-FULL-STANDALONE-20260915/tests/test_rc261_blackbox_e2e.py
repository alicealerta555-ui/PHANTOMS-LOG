from pathlib import Path
from collections import deque
import tempfile

from playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage9.world_time import WorldClock
from runtime.full_version.search import SEARCH_STATE_PREFIX

ROOT=Path(__file__).resolve().parents[1]
PLAYER="actor:player"

def make_game(tmp):
    g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class="OPERATOR",master_seed=20260913)
    draft=g.creation_template()
    g.complete_character(draft)
    return g

def route(g,target):
    start=g.location(); q=deque([(start,[])]); seen={start}
    while q:
        cur,path=q.popleft()
        if cur==target:
            for step in path:
                txt,_=g.handle("/go "+step)
                assert "COMMITTED" in txt
            return
        for nxt in g.catalog.location(cur)["connections"]:
            if nxt not in seen:
                seen.add(nxt); q.append((nxt,path+[nxt]))
    raise AssertionError("no route")

def first_npc(g,role=None):
    for inst in g.actor_registry.instances():
        if inst.actor_instance_id==PLAYER: continue
        rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,inst.actor_instance_id)
        if isinstance(rec,dict) and (role is None or rec.get("role")==role):
            return inst.actor_instance_id,rec
    raise AssertionError("npc missing")

def inventory_items(g,owner=PLAYER):
    out=[]
    for key in g.session.store.runtime_state:
        rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
        if isinstance(rec,dict) and rec.get("kind")=="item" and rec.get("location_ref")==f"inventory:{owner}":
            out.append((key,rec))
    return out

def test_blackbox_search_take_weather_needs_save_reload():
    with tempfile.TemporaryDirectory() as tmp:
        g=make_game(tmp)
        before_time=WorldClock(g.session).seconds
        before_h=g.embodied_needs.actor_packet(PLAYER)["needs"]["hydration"]["pressure_ppm"]
        text,_=g.handle("/search")
        assert "Sekunden Weltzeit" in text
        assert WorldClock(g.session).seconds>before_time
        assert g.embodied_needs.actor_packet(PLAYER)["needs"]["hydration"]["pressure_ppm"]>=before_h
        assert g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,"__regional_weather_runtime__") is not None
        loc=g.location()
        iid=None
        for _ in range(4):
            for key in g.session.store.runtime_state:
                rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
                if isinstance(rec,dict) and rec.get("provenance")=="LOCATION_SEARCH" and rec.get("location_ref")==loc:
                    iid=key; break
            if iid: break
            g.handle("/search")
        assert iid
        take,_=g.handle("/take "+iid); assert "COMMITTED" in take
        g.save(); g.images.close()
        g2=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),master_seed=20260913)
        rec=g2.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
        assert rec["location_ref"]=="inventory:actor:player"
        assert g2.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,SEARCH_STATE_PREFIX+loc)["search_count"]>=1
        assert g2.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,"__regional_weather_runtime__") is not None
        g2.images.close()

def test_blackbox_talk_ask_inventory_identity():
    with tempfile.TemporaryDirectory() as tmp:
        g=make_game(tmp)
        # Lifetime locals may legitimately own no inventory. Select an NPC that actually carries something.
        chosen=None
        for inst in g.actor_registry.instances():
            if inst.actor_instance_id==PLAYER: continue
            rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,inst.actor_instance_id)
            carried=inventory_items(g,inst.actor_instance_id)
            if isinstance(rec,dict) and carried:
                chosen=(inst.actor_instance_id,rec,carried); break
        assert chosen is not None
        nid,npc,carried=chosen; route(g,npc["location_ref"])
        talk,_=g.handle("/talk "+nid)
        assert "Rolle:" in talk and "Resident " not in talk
        known=g.session.kernel.read(Authority.KNOWLEDGE_ROUTER,Domain.ACTOR_KNOWLEDGE,"npc_identity:"+nid,actor_id=PLAYER)
        assert isinstance(known,dict)
        kind=g.catalog.item_definition(carried[0][1]["item_definition_id"])["kind"]
        ask,_=g.handle("/ask "+nid+" "+kind)
        assert carried[0][0] in ask

def test_blackbox_trade_roundtrip_relationship_and_price():
    with tempfile.TemporaryDirectory() as tmp:
        g=make_game(tmp); mid,m=first_npc(g,"merchant"); route(g,m["location_ref"])
        talk,_=g.handle("/talk "+mid); assert "Angebot:" in talk
        stock=g.merchant_stock(mid); assert stock
        iid=stock[0]["instance_id"]
        buy,_=g.handle(f"/buy {iid} {mid}")
        assert "COMMITTED" in buy and "Kaufpreis:" in buy
        owned=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
        assert owned["owner_actor_instance_id"]==PLAYER
        sell,_=g.handle(f"/sell {iid} {mid}")
        assert "TRADE_SELL_OK" in sell and "Verkaufspreis:" in sell
        rel=g.social_faction.relationship(PLAYER,mid)
        assert isinstance(rel,dict)

def test_blackbox_data_terminal_and_objects():
    with tempfile.TemporaryDirectory() as tmp:
        g=make_game(tmp)
        if not g.data_runtime.terminals(g.location()):
            loc=next(x["location_id"] for x in g.catalog.world["locations"] if g.data_runtime.terminals(x["location_id"]))
            route(g,loc)
        objects,_=g.handle("/objects")
        assert objects and "Keine expliziten Interaktionsobjekte." not in objects
        # The family diary is a lifetime document, not a generic terminal dataset. Inject a normal data fixture.
        data='item:test:blackbox-data'
        rec={'run_uuid':g.identity.run_uuid,'kind':'item','item_definition_id':'item_def:data:016','location_ref':'inventory:actor:player','owner_actor_instance_id':'actor:player','condition':100,'max_condition':100,'provenance':'TEST_ONLY'}
        event='TEST_BLACKBOX_DATA_FIXTURE'
        committed=g.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(Delta(Domain.RUNTIME_STATE,data,rec,Authority.RULE_KERNEL,'TEST_FIXTURE',source_event_id=event,provenance='TEST_ONLY'),),event_id=event,cause='TEST_FIXTURE',expected_state_revision=g.session.store.revision))
        assert isinstance(committed,CommitRecord)
        before=WorldClock(g.session).seconds
        read,_=g.handle("/read "+data)
        assert "Datensatz" in read
        assert WorldClock(g.session).seconds>=before

def test_blackbox_craft_and_repair_commands_are_live():
    with tempfile.TemporaryDirectory() as tmp:
        g=make_game(tmp); mid,m=first_npc(g,"merchant"); route(g,m["location_ref"])
        # Buy a known crafting component used by operation:04 if present.
        stock=g.merchant_stock(mid)
        comp=None
        for x in stock:
            rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,x["instance_id"])
            if rec["item_definition_id"]=="item_def:component:029":
                comp=x["instance_id"]; break
        assert comp
        txt,_=g.handle(f"/buy {comp} {mid}"); assert "COMMITTED" in txt
        before=WorldClock(g.session).seconds
        crafted,_=g.handle("/craft operation:04")
        assert "Hergestellt:" in crafted and WorldClock(g.session).seconds>before
        assert any(str(k).startswith("item:crafted:") for k in g.session.store.runtime_state)

def test_player_facing_social_and_weather_hide_internal_scores():
    with tempfile.TemporaryDirectory() as tmp:
        g=make_game(tmp)
        social,_=g.handle("/social"); factions,_=g.handle("/factions"); weather,_=g.handle("/weather")
        assert "Vertrauen 0" not in social
        assert "Stand 0" not in factions
        assert "ppm" not in weather.lower()
