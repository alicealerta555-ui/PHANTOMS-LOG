
import json, unittest
from pathlib import Path
from runtime.content_stage35.family import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage35_family_households.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_kinship_types(self):
  self.assertGreaterEqual(len(D["kinship_types"]),8)

 def test_kinship_not_self(self):
  self.assertIsNone(kinship_record("a","a","SIBLING",1))

 def test_household_membership_authority(self):
  p=household_membership_candidate("H","a","JOIN","EV")
  self.assertTrue(p["authority_required"])

 def test_invalid_household_action(self):
  self.assertIsNone(household_membership_candidate("H","a","MOVE","EV"))

 def test_caregiving_unmet(self):
  x=caregiving_load([{"minutes":60},{"minutes":90}],100)
  self.assertEqual(x["required_minutes"],150)
  self.assertEqual(x["unmet_minutes"],50)

 def test_inheritance_requires_death_event(self):
  self.assertIsNone(inheritance_candidate("ASSET","dead","heir","INH_WILL","", "EV"))

 def test_inheritance_authority(self):
  p=inheritance_candidate("ASSET","dead","heir","INH_WILL","DEATH","EV")
  self.assertTrue(p["authority_required"])

 def test_inheritance_distinct_parties(self):
  self.assertIsNone(inheritance_candidate("ASSET","a","a","INH_WILL","DEATH","EV"))

 def test_dependency_pressure_bounded(self):
  self.assertEqual(dependency_pressure(90,50,False),100)

 def test_household_continuity(self):
  a=household_continuity_candidate("H",["a"],True,"EV")
  b=household_continuity_candidate("H",["a"],False,"EV")
  self.assertTrue(a["continues"])
  self.assertFalse(b["continues"])

 def test_rule_separates_rights(self):
  self.assertTrue(any("does not automatically grant ownership" in x.lower() for x in D["rules"]))

if __name__=="__main__": unittest.main()
