
import json,unittest
from pathlib import Path
from runtime.content_stage21.social import *
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage21_social_checks.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_actions(self):
  self.assertGreaterEqual(len(D["social_actions"]),5)

 def test_score_bounded(self):
  self.assertEqual(social_score(999,9999,9999,9999),10000)
  self.assertEqual(social_score(-999,-9999,-9999,-9999),0)

 def test_check_threshold(self):
  p=social_check_candidate("a","b","SOC_PERSUADE",7000,5500,"EV")
  self.assertTrue(p["success"])
  self.assertTrue(p["authority_required"])

 def test_failed_check(self):
  p=social_check_candidate("a","b","SOC_PERSUADE",1000,5500,"EV")
  self.assertFalse(p["success"])

 def test_persuasion_not_mind_control(self):
  p=persuasion_influence(True,20,0)
  self.assertFalse(p["decision_forced"])

 def test_conflict_reduces_persuasion(self):
  a=persuasion_influence(True,20,0)["respect"]
  b=persuasion_influence(True,20,9000)["respect"]
  self.assertGreater(a,b)

 def test_deception_known_contradiction(self):
  d=deception_candidate(True,"claim",True,9000)
  self.assertEqual(d["belief_pressure"],0)
  self.assertFalse(d["auto_belief"])

 def test_deception_never_auto_belief(self):
  d=deception_candidate(True,"claim",False,9000)
  self.assertGreater(d["belief_pressure"],0)
  self.assertFalse(d["auto_belief"])

 def test_intimidation_has_cost(self):
  i=intimidation_influence(True,20)
  self.assertGreater(i["fear"],0)
  self.assertGreater(i["hostility"],0)
  self.assertFalse(i["guaranteed_compliance"])

 def test_influence_authority(self):
  p=influence_proposal("a","b","SOC_INTIMIDATE",{"fear":10},"EV")
  self.assertTrue(p["authority_required"])
  self.assertEqual(p["causal_event_id"],"EV")

if __name__=="__main__": unittest.main()
