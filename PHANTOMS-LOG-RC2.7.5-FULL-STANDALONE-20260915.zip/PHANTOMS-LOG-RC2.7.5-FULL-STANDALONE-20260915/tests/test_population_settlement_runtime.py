from pathlib import Path
import json, tempfile

from runtime.full_version.catalog import FullVersionCatalog
from runtime.full_version.population_runtime import PopulationResolver
from playable_full_version.playable.game import FullVersionGame

ROOT=Path(__file__).resolve().parents[1]

def test_population_tables_cover_full_world_and_sum():
    cat=FullVersionCatalog.load(ROOT)
    resolver=PopulationResolver(cat)
    assert len(resolver.raw['region_profiles'])==5
    assert len(resolver.raw['settlement_profiles'])==7
    assert len(resolver.raw['location_profiles'])==100
    for p in resolver.raw['region_profiles'].values():
        assert sum(p['culture_mix_ppm'].values())==1_000_000
        assert sum(p['occupation_mix_ppm'].values())==1_000_000
        assert sum(p['household_mix_ppm'].values())==1_000_000
        assert sum(p['mobility_modes_ppm'].values())==1_000_000

def test_npc_social_assignment_is_run_stable_and_explicit():
    cat=FullVersionCatalog.load(ROOT); r=PopulationResolver(cat)
    a=r.assign_npc(npc_id='actor:npc:001',role='mechanic',home_location_id='loc:residential_domestic:01',run_uuid='run-a')
    b=r.assign_npc(npc_id='actor:npc:001',role='mechanic',home_location_id='loc:residential_domestic:01',run_uuid='run-a')
    assert a==b
    assert a['culture_id'].startswith('culture:')
    assert a['household_ref'].startswith('household:')
    assert 'lineage' not in a and 'species' not in a and 'ancestry' not in a

def test_bootstrap_commits_social_profiles_and_culture_alignment():
    with tempfile.TemporaryDirectory() as td:
        g=FullVersionGame(core_root=ROOT,saves_root=Path(td),start_class='OPERATOR',master_seed=20260913)
        try:
            npcs=g.actors_here()
            # actors_here may be empty at the player start; inspect registry instead.
            checked=0
            for inst in g.actor_registry.instances():
                if inst.actor_instance_id=='actor:player': continue
                rec=g.session.store.runtime_state.get(inst.actor_instance_id)
                if not isinstance(rec,dict): continue
                sp=rec.get('social_profile'); cs=rec.get('cultural_surface')
                assert isinstance(sp,dict) and isinstance(cs,dict)
                assert sp['culture_id']==cs['culture_id']
                checked+=1
            # 45 static world NPCs plus 3 persistent Lifetime-start NPCs.
            assert checked==48
        finally:
            g.images.close()

def test_population_command_exposes_distribution_not_individual_inference():
    with tempfile.TemporaryDirectory() as td:
        g=FullVersionGame(core_root=ROOT,saves_root=Path(td),start_class='BREAKER',master_seed=20260913)
        try:
            text,done=g.handle('/population')
            assert not done
            assert 'Siedlung:' in text and 'Kulturen (Verteilungsprior):' in text and 'Mobilität:' in text
        finally:
            g.images.close()

def test_hybrid_rules_are_cultural_only():
    raw=json.loads((ROOT/'content/full_version/population_settlement_tables.json').read_text(encoding='utf-8'))
    assert raw['rules']['culture_is_not_lineage'] is True
    assert raw['rules']['hybrid_culture_is_social_cultural_not_biological'] is True
    assert raw['rules']['no_inference_from_name_role_or_location'] is True
    assert set(raw['hybrid_culture_rules'])=={'culture:habitat_market','culture:civic_rimworks','culture:rim_deep'}

def test_local_resident_routine_target_stays_in_home_region():
    from runtime.full_version.npc_routines import NPCRoutineRuntime
    from runtime.stage3c.isolation import RunSessionManager
    from runtime.stage9.actors import RunActorRegistry
    from runtime.full_version.bootstrap import FullVersionBootstrap
    cat=FullVersionCatalog.load(ROOT)
    mgr=RunSessionManager(master_seed=20260913)
    session=mgr.create_run(player_uuid='00000000-0000-4000-8000-000000000001',run_uuid='00000000-0000-4000-8000-000000000002')
    reg=RunActorRegistry(session)
    FullVersionBootstrap(cat).initialize_new_run(session,reg,start_class='BREAKER')
    rt=NPCRoutineRuntime(cat,session)
    npc_id=next(x.actor_instance_id for x in reg.instances() if x.actor_instance_id.startswith('actor:npc:'))
    npc=session.store.runtime_state[npc_id]
    npc=dict(npc); sp=dict(npc['social_profile']); sp['mobility_type']='local_resident'; npc['social_profile']=sp
    home_region=cat.location(npc['home_location_id'])['region_id']
    for phase in ('work','supply','social'):
        target=rt._choose_target(npc,npc_id,phase=phase,day=0)
        assert cat.location(target)['region_id']==home_region
