from runtime.player_progression.habits import DecisionEvent
from runtime.player_progression.identity import HabitIdentityBridge
from runtime.player_progression.model import PlayerProgressionState
from runtime.player_progression.pipeline import PlayerLearningRuntime


def make_rt(start='GHOST', level=10):
    s = PlayerProgressionState('p','r',start, level=level)
    return PlayerLearningRuntime(s)


def repeat(rt, event, n=20):
    for _ in range(n):
        rt.observe_decision(event)


def test_habit_identity_bridge_is_weak_and_capped():
    rt = make_rt()
    repeat(rt, DecisionEvent('room_entry','scan_motion',category='perception'), 24)
    sig = rt.identity_bridge.signal(rt.habit_state)
    assert 0 < sig.affinity_hints['AFF_PERCEPTION'] <= 1.5


def test_forming_habit_does_not_bias_identity():
    rt = make_rt()
    rt.observe_decision(DecisionEvent('room_entry','scan_motion',category='perception'))
    sig = rt.identity_bridge.signal(rt.habit_state)
    assert sig.affinity_hints['AFF_PERCEPTION'] == 0


def test_specialization_candidates_are_player_clean():
    rt = make_rt('GHOST', 10)
    repeat(rt, DecisionEvent('room_entry','enter_quietly',category='micro_routine'), 20)
    payload = rt.level10_specialization_candidates()
    text = str(payload)
    for forbidden in ('affinity','score','threshold','strength','0.','1.'):
        assert forbidden not in text.lower()


def test_habit_note_contains_no_numbers():
    rt = make_rt()
    repeat(rt, DecisionEvent('travel_departure','check_gear',category='preparation'), 20)
    payload = rt.visible_identity_note()
    assert payload is not None
    assert not any(ch.isdigit() for ch in str(payload))


def test_double_edged_habit_can_automate_mild_routine_and_is_overridable():
    rt = make_rt()
    repeat(rt, DecisionEvent('room_entry','extended_check',category='perception'), 20)
    note = rt.visible_identity_note()
    assert note is not None
    auto = rt.suggest_instinct_action('room_entry')
    assert auto is not None
    assert auto.get('choice') == 'extended_check'
    assert rt.override_instinct('overcautious_entry') is True


def test_mastery_uses_directed_biography_with_habit_projection():
    rt = make_rt('GHOST', 30)
    rt.progression.specialization = 'shade'
    rt.progression.affinities['AFF_FORCE'] = 9.0
    rt.progression.affinities['AFF_STEALTH'] = 3.0
    payload = rt.resolve_mastery_path()
    assert payload is not None
    assert payload['kind'] == 'mastery_path'


def test_end_path_payload_clean():
    rt = make_rt('OPERATOR', 50)
    rt.progression.specialization = 'gearsmith'
    rt.progression.mastery_path = 'architect'
    rt.progression.affinities['AFF_TECH'] = 12.0
    rt.progression.affinities['AFF_MACHINE'] = 10.0
    payloads = rt.end_path_candidates()
    assert payloads
    text = str(payloads).lower()
    assert 'score' not in text and 'affinity' not in text and 'threshold' not in text


def test_identity_bridge_does_not_mutate_canonical_affinities():
    rt = make_rt()
    before = dict(rt.progression.affinities)
    repeat(rt, DecisionEvent('travel_departure','check_gear',category='preparation'), 20)
    _ = rt.identity_bridge.projected_state(rt.progression, rt.habit_state)
    assert rt.progression.affinities == before
