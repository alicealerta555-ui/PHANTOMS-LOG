
import json,unittest
from pathlib import Path
from runtime.content_stage20.stealth import *
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage20_stealth_tracking.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_concealment_bounded(self):
  self.assertEqual(concealment_score(9000,3000,0,0),10000)
  self.assertEqual(concealment_score(0,0,5000,5000),0)

 def test_detection_threshold(self):
  p=detection_candidate("o","t","L","vision",7000,6000,"EV")
  self.assertTrue(p["success"])
  self.assertTrue(p["authority_required"])

 def test_detection_failure_not_knowledge(self):
  p=detection_candidate("o","t","L","vision",1000,6000,"EV")
  self.assertFalse(p["success"])

 def test_trace_freshness(self):
  tr=trace_record("TRACE_FOOTPRINT","t","L",0,80,"EV")
  self.assertGreater(trace_freshness(tr,100,720),trace_freshness(tr,600,720))

 def test_expired_trace(self):
  tr=trace_record("TRACE_FOOTPRINT","t","L",0,80,"EV")
  self.assertEqual(trace_freshness(tr,10000,720),0)

 def test_tracking_uncertain(self):
  tr=trace_record("TRACE_WITNESS_REPORT","t","L",0,20,"EV")
  p=tracking_candidate("o",tr,10,4320,25)
  self.assertFalse(p["usable"])

 def test_tracking_authority(self):
  tr=trace_record("TRACE_BLOOD","t","L",0,90,"EV")
  p=tracking_candidate("o",tr,10,1440,25)
  self.assertTrue(p["authority_required"])

 def test_lost_contact(self):
  self.assertEqual(pursuit_transition("DIRECT_CONTACT",False,None),"LOST_CONTACT")

 def test_track_transition(self):
  self.assertEqual(pursuit_transition("SUSPECTED",None,True),"TRACKING")

 def test_no_teleport_pursuit(self):
  self.assertIsNone(pursuit_move_proposal("o","t","A","B",None,"EV"))
  p=pursuit_move_proposal("o","t","A","B","ROUTE_X","EV")
  self.assertEqual(p["route_id"],"ROUTE_X")
  self.assertTrue(p["authority_required"])

if __name__=="__main__": unittest.main()
