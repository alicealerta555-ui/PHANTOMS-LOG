
import json, unittest
from pathlib import Path
from runtime.content_stage24.organizations import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage24_organizations.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_archetypes(self):
  self.assertGreaterEqual(len(D["organization_archetypes"]),5)

 def test_membership_separate(self):
  m=membership_record("ORG","a","RANK_MEMBER",1,True)
  self.assertEqual(m["rank_id"],"RANK_MEMBER")
  self.assertTrue(m["active"])

 def test_authority_bounded(self):
  self.assertEqual(authority_score(90,50,10000),100)
  self.assertGreaterEqual(authority_score(50,0,5000),0)

 def test_orders_not_forced(self):
  o=hierarchical_order("ORG","boss","npc","guard",80,"EV")
  self.assertTrue(o["requires_actor_decision"])

 def test_succession_threshold(self):
  a=succession_candidate("ORG","LEADER","old","new","SUCCESSION_ELECTION",40,60,"EV")
  b=succession_candidate("ORG","LEADER","old","new","SUCCESSION_ELECTION",70,60,"EV")
  self.assertFalse(a["successful"])
  self.assertTrue(b["successful"])
  self.assertTrue(b["authority_required"])

 def test_bloc_pressure_bounded(self):
  self.assertEqual(internal_bloc_pressure(999,-999,99999,99999),100)
  self.assertEqual(internal_bloc_pressure(-999,999,-99999,-99999),-100)

 def test_office_change_requires_target(self):
  self.assertIsNone(office_change_proposal("ORG","LEADER","a","a","election","EV"))

 def test_office_change_authority(self):
  p=office_change_proposal("ORG","LEADER","a","b","election","EV")
  self.assertTrue(p["authority_required"])
  self.assertEqual(p["to_actor_id"],"b")

 def test_leader_not_omniscient_rule(self):
  self.assertTrue(any("not omniscient" in x.lower() for x in D["rules"]))

 def test_internal_bloc_parent_unchanged(self):
  self.assertTrue(D["internal_faction_contract"]["parent_identity_unchanged"])

if __name__=="__main__": unittest.main()
