from runtime.player_progression import PlayerLearningRuntime
from runtime.player_progression.model import PlayerProgressionState
from runtime.player_progression.gameplay_hooks import ResolvedGameplayEvent
from runtime.player_progression.npc_learning import NPCActorSnapshot, NPCWitnessContext
from runtime.player_progression.adaptive_runtime import AdaptiveGameplayRuntime


def runtime():
    state = PlayerProgressionState(player_uuid="p", run_uuid="r", start_class="GHOST")
    return AdaptiveGameplayRuntime.new(PlayerLearningRuntime(progression=state))


def npc(n="n1"):
    return NPCActorSnapshot(npc_id=n, intelligence_grade=7, trust_player=.8, openness=.8,
                            stubbornness=.2, self_interest=.2, competencies={"exploration": .7})


def ev(i=0):
    return ResolvedGameplayEvent(domain="exploration", action_family="scan_motion", committed=True,
        actor_is_player=True, location_id=f"r{i}", situation_family="room_entry", choice_key="scan_motion",
        visible_context_tags=("unknown_room",), outcome="success")


def test_single_host_call_feeds_player_and_witnessing_npc():
    rt = runtime()
    out = rt.after_resolution(ev(), [(npc(), NPCWitnessContext(visible_tags=("hall",)))])
    assert out.player.applied_action_learning is True
    assert rt.npc_bridge.engine.state_for("n1").patterns


def test_uncommitted_event_feeds_neither_side():
    rt = runtime()
    e = ResolvedGameplayEvent(domain="exploration", action_family="look", committed=False)
    out = rt.after_resolution(e, [(npc(), NPCWitnessContext())])
    assert out.player.applied_action_learning is False
    assert rt.npc_bridge.engine.states == {}


def test_npc_state_does_not_mutate_player_insights():
    rt = runtime()
    before = list(rt.player_bridge.coordinator.runtime.progression.unlocked_insights)
    for i in range(6):
        rt.after_resolution(ev(i), [(npc(), NPCWitnessContext(visible_tags=(f"ctx{i}",)))])
    # Whatever player unlocked is produced only by player runtime; NPC routine storage
    # cannot write into this field directly.
    assert isinstance(rt.player_bridge.coordinator.runtime.progression.unlocked_insights, list)
    assert not hasattr(rt.npc_bridge.engine.state_for("n1"), "unlocked_insights")


def test_combined_save_roundtrip():
    rt = runtime()
    for i in range(5):
        rt.after_resolution(ev(i), [(npc(), NPCWitnessContext(visible_tags=(f"ctx{i}",)))])
    payload = rt.snapshot_for_save()
    restored = AdaptiveGameplayRuntime.from_save(payload)
    assert restored.snapshot_for_save() == payload


def test_discussion_uses_persisted_npc_stance():
    rt = runtime()
    for i in range(5):
        rt.after_resolution(ev(i), [(npc(), NPCWitnessContext(visible_tags=(f"ctx{i}",)))])
    resp = rt.discuss_npc_pattern(npc(), "room_entry|scan_motion")
    assert resp.dialogue_hook


def test_hidden_world_data_not_required_by_combined_api():
    rt = runtime()
    e = ev()
    # API has only visible_context_tags/risk_tags from resolved event and per-NPC
    # witness-visible tags; there is no hidden-world-truth field to consume.
    out = rt.after_resolution(e, [(npc(), NPCWitnessContext(visible_tags=("audible",)))])
    assert out.player.applied_action_learning is True
