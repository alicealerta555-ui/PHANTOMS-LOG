import json
from contextlib import contextmanager
from runtime.player_progression import PlayerProgressionState, PathResolver, MASTERY, END_PATHS, SPECIALIZATIONS

@contextmanager
def raises(error):
    try:
        yield
    except error:
        return
    raise AssertionError(f"{error.__name__} was not raised")


def state(start='BREAKER', level=10):
    return PlayerProgressionState('p','r',start,level=level)


def test_16_level10_specializations_four_per_class():
    assert len(SPECIALIZATIONS) == 16
    for c in ('BREAKER','GHOST','OPERATOR','RESONANT'):
        assert sum(1 for d in SPECIALIZATIONS.values() if d.start_class == c) == 4


def test_level10_offers_style_supported_choice_without_numbers():
    s=state('GHOST',10)
    s.affinities['AFF_STEALTH']=50
    s.affinities['AFF_PERCEPTION']=35
    r=PathResolver()
    c=r.level10_candidates(s,2)
    assert len(c)==2
    payload=r.visible_specialization_choice(c)
    txt=json.dumps(payload)
    assert 'AFF_STEALTH' not in txt and '50' not in txt and 'score' not in txt


def test_level10_cannot_pick_unoffered_spec():
    s=state('BREAKER',10)
    s.affinities['AFF_PROTECTION']=100
    s.affinities['AFF_ENDURANCE']=80
    r=PathResolver()
    offered={d.spec_id for d in r.level10_candidates(s,2)}
    unoffered=next(x for x in ('RAVAGER','BULWARK','BREACHER','HUNTER') if x not in offered)
    with raises(ValueError):
        r.choose_specialization(s,unoffered)


def test_16_directed_mastery_paths_exist():
    assert len(MASTERY)==16
    assert MASTERY[('BREAKER','GHOST')].name == 'Razor'
    assert MASTERY[('GHOST','BREAKER')].name == 'Predator'


def test_directed_paths_are_not_symmetric():
    assert MASTERY[('BREAKER','OPERATOR')].name != MASTERY[('OPERATOR','BREAKER')].name
    assert MASTERY[('RESONANT','GHOST')].name != MASTERY[('GHOST','RESONANT')].name


def test_level30_uses_biography_and_secondary_playstyle():
    s=state('BREAKER',30)
    s.specialization='RAVAGER'
    s.affinities['AFF_STEALTH']=120
    s.affinities['AFF_MOBILITY']=100
    s.affinities['AFF_PRECISION']=80
    d=PathResolver().resolve_mastery(s)
    assert d.name == 'Razor'


def test_level30_requires_specialization():
    s=state('GHOST',30)
    assert PathResolver().resolve_mastery(s) is None


def test_end_paths_have_behavioral_variety():
    assert len(END_PATHS) >= 16
    names={d.name for d in END_PATHS.values()}
    assert {'The Bastion','The Architect','The Signal','The Null','The Adaptive'} <= names


def test_level50_end_path_is_behavior_first():
    s=state('BREAKER',50)
    s.specialization='BULWARK'
    s.mastery_path='BREAKER_TO_RESONANT'
    s.affinities['AFF_PROTECTION']=220
    s.affinities['AFF_ENDURANCE']=180
    s.affinities['AFF_COMMAND']=150
    r=PathResolver()
    top=r.end_path_candidates(s,1)[0]
    assert top.path_id == 'THE_BASTION'


def test_visible_mastery_has_no_numbers_or_affinity_keys():
    d=MASTERY[('OPERATOR','RESONANT')]
    payload=PathResolver.visible_mastery(d)
    txt=json.dumps(payload)
    assert not any(k in txt for k in ('AFF_TECH','AFF_RESONANCE','score','threshold','affinity'))
    assert not any(isinstance(v,(int,float)) for v in payload.values())


def test_end_path_is_idempotent_after_commit():
    s=state('OPERATOR',50)
    s.specialization='GEARSMITH'
    s.mastery_path='OPERATOR_TO_OPERATOR'
    s.affinities['AFF_TECH']=200
    s.affinities['AFF_MACHINE']=180
    s.affinities['AFF_NETWORK']=160
    r=PathResolver()
    first=r.commit_end_path(s)
    second=r.commit_end_path(s)
    assert first.path_id == second.path_id == s.end_path
