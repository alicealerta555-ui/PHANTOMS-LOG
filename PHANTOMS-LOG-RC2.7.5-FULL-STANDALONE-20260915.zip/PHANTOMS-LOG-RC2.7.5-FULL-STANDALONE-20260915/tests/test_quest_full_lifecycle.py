from pathlib import Path
from collections import deque
import tempfile

from playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal

ROOT=Path(__file__).resolve().parents[1]
PLAYER='actor:player'


def game(tmp):
    g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class='OPERATOR',master_seed=20260913)
    data=g.creation_template(); data['skills']['SKILL_TECHNOLOGY']=10; data['skills']['SKILL_NETWORKS']=10
    g.complete_character(data)
    return g


def move_to(g,target):
    start=g.location(); q=deque([start]); parent={start:None}
    while q:
        cur=q.popleft()
        if cur==target: break
        for nxt in g.catalog.location(cur)['connections']:
            if nxt not in parent: parent[nxt]=cur; q.append(nxt)
    assert target in parent
    path=[]; cur=target
    while cur!=start: path.append(cur); cur=parent[cur]
    for dest in reversed(path):
        r=g.execute(action_type='MOVE',raw_input='test move',parameters={'destination_location_id':dest})
        assert r.status.value in {'COMMITTED','IDEMPOTENT'}


def inject_knowledge(g,key):
    event='TEST_KNOW:'+key
    ep={'source_type':'DIRECT_OBSERVATION','source_id':'test-fixture','origin_location':g.location(),'learned_at':0,'path':[],'confidence_ppm':1000000,'distortions':[]}
    r=g.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(Delta(Domain.ACTOR_KNOWLEDGE,key,{'test_fixture':True},Authority.KNOWLEDGE_ROUTER,'TEST_FIXTURE',actor_id=PLAYER,source_event_id=event,provenance='TEST_ONLY',epistemic=ep),),event_id=event,cause='TEST_FIXTURE',expected_state_revision=g.session.store.revision))
    assert isinstance(r,CommitRecord)


def issuer_for(g,template_id):
    t=g.quest_runtime.templates[template_id]
    roles=set(g.quest_runtime.aliases[t['issuer_role']])
    for key in g.session.store.runtime_state:
        if str(key).startswith('actor:npc:'):
            rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
            if rec.get('role') in roles: return key,rec
    raise AssertionError('issuer missing')


def setup_quest(g,template_id,prereq):
    inject_knowledge(g,prereq)
    npc,nrec=issuer_for(g,template_id); move_to(g,nrec['location_ref'])
    text=g.talk_to(npc); assert 'Auftrag verfügbar' in text
    qid=next(qid for qid,q in g.quest_runtime.active() if q['template_id']==template_id)
    r=g.execute(action_type='QUEST_ACCEPT',raw_input='accept',target_refs=(qid,)); assert r.status.value=='COMMITTED'
    q=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid); assert q['state']=='ACTIVE'
    return qid,npc,q


def reveal_take(g,q):
    move_to(g,q['target_location_id'])
    text=g.search_location(); assert q['asset_item_id'] in text
    r=g.execute(action_type='TAKE',raw_input='take',target_refs=(q['asset_item_id'],)); assert r.status.value=='COMMITTED'


def test_reactor_key_full_loop_returned():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); qid,npc,q=setup_quest(g,'Q_REACTOR_KEY','rumor:reactor_vault')
        reveal_take(g,q)
        issuer=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,npc); move_to(g,issuer['location_ref'])
        text=g.talk_to(npc); assert 'Auftrag abgeschlossen' in text
        done=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
        assert done['state']=='COMPLETED' and done['final_outcome']=='returned'


def test_drowned_archive_full_loop_verified():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); qid,npc,q=setup_quest(g,'Q_DROWNED_ARCHIVE','channel:archive_lead')
        reveal_take(g,q)
        text=g.read_data_item(q['asset_item_id']); assert 'Archivkern' in text
        mid=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid); assert mid['progress'].get('data_read') is True
        issuer=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,npc); move_to(g,issuer['location_ref'])
        g.talk_to(npc)
        done=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
        assert done['state']=='COMPLETED' and done['final_outcome']=='verified'


def test_pump_crisis_full_loop_repaired():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); qid,npc,q=setup_quest(g,'Q_PUMP_CRISIS','event:pump_pressure')
        reveal_take(g,q)
        # Isolated synthetic material fixture for the repair operation only.
        iid='item:test:repair-material'; event='TEST_REPAIR_MATERIAL'
        rec={'run_uuid':g.identity.run_uuid,'kind':'item','item_definition_id':'item_def:component:021','location_ref':'inventory:actor:player','owner_actor_instance_id':'actor:player','condition':100,'max_condition':100,'provenance':'TEST_ONLY'}
        r=g.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(Delta(Domain.RUNTIME_STATE,iid,rec,Authority.RULE_KERNEL,'TEST_FIXTURE',source_event_id=event,provenance='TEST_ONLY'),),event_id=event,cause='TEST_FIXTURE',expected_state_revision=g.session.store.revision)); assert isinstance(r,CommitRecord)
        g.repair_operation('operation:03',q['asset_item_id'])
        issuer=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,npc); move_to(g,issuer['location_ref'])
        g.talk_to(npc)
        done=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
        assert done['state']=='COMPLETED' and done['final_outcome']=='repaired'
        ckey='quest_consequence:'+qid.split(':',1)[1]
        candidate=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,ckey)
        assert candidate['state']=='PROPOSED' and 'supply_water_up' in candidate['effects']


def test_caravan_full_loop_delivered_on_real_travel():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); qid,npc,q=setup_quest(g,'Q_CARAVAN_ROUTE','route:open')
        asset=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,q['asset_item_id'])
        assert asset['location_ref']=='inventory:actor:player'
        move_to(g,q['target_location_id'])
        done=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
        assert done['state']=='COMPLETED' and done['final_outcome']=='delivered'
        asset2=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,q['asset_item_id'])
        assert asset2['location_ref']==f'delivered:{qid}'
