from pathlib import Path
import tempfile

from playable_full_version.playable.game import FullVersionGame

ROOT=Path(__file__).resolve().parents[1]

def _game(tmp, seed):
    g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class='OPERATOR',master_seed=seed)
    draft=g.creation_template()
    g.complete_character(draft)
    return g

def test_data_content_has_bounded_variants_and_locked_facts():
    import json
    raw=json.loads((ROOT/'content/full_version/data_item_contents.json').read_text(encoding='utf-8'))
    assert raw['schema']=='PH4NT0M5_DATA_ITEM_CONTENTS_V2'
    assert len(raw['entries'])==10
    for e in raw['entries']:
        assert len(e['canonical_facts'])>=3
        assert len(e['presentation_variants'])>=3
        assert e['variation_policy']=='presentation_only'

def test_content_variant_is_stable_within_run():
    with tempfile.TemporaryDirectory() as tmp:
        g=_game(tmp,20260913)
        item_def='item_def:data:016'
        p1=g.data_runtime.presentation_packet(item_def)
        p2=g.data_runtime.presentation_packet(item_def)
        assert p1==p2
        assert p1['selected_variant'] in g.data_runtime.contents[item_def]['presentation_variants']

def test_prompt_forbids_semantic_randomization():
    text=(ROOT/'content/full_version/prompts/CONTENT_VARIATION_PROMPT_CORE.md').read_text(encoding='utf-8').lower()
    assert 'presentation only' in text
    assert 'never invent' in text
    assert 'run-stable' in text
    assert 'must not reroll' in text
