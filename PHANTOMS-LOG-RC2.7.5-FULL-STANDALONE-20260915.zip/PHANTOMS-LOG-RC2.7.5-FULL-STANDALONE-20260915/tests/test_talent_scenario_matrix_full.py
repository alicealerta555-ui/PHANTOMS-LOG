from __future__ import annotations

import pytest

from runtime.full_version.capability_catalog import STATS, SKILLS, TALENTS
from runtime.full_version.capability_resolution import CapabilityZone, StageDemand, assess_talent
from runtime.full_version.capability_scenarios import CASE_DEFINITIONS, talent_scenarios

SCENARIOS=talent_scenarios()


def _base(talent_id):
    t=TALENTS[talent_id]
    return {
        "stats":{sid:8 for sid in STATS},
        "skills":{sid:(7 if sid in t.required_skills else 1) for sid in SKILLS},
        "talents":[talent_id],
        "expertises":{},
        "stat_penalties":{},
    }


def _demands(talent_id, difficulty=5, hard_min=3):
    t=TALENTS[talent_id]
    return tuple(StageDemand(stage,{sid:hard_min for sid in t.required_stats},difficulty) for stage in t.modifies_stages)


def test_scenario_matrix_is_complete_for_every_named_talent_situation():
    assert len(SCENARIOS) == sum(len(t.situations) for t in TALENTS.values()) * len(CASE_DEFINITIONS)
    index={(s.talent_id,s.situation,s.case) for s in SCENARIOS}
    for t in TALENTS.values():
        for situation in t.situations:
            for case,_,_ in CASE_DEFINITIONS:
                assert (t.talent_id,situation,case) in index


@pytest.mark.parametrize("sc", SCENARIOS, ids=lambda s:s.scenario_id)
def test_every_named_talent_situation_has_expected_mechanical_outcome(sc):
    c=_base(sc.talent_id)
    kwargs={}
    demands=_demands(sc.talent_id)
    t=TALENTS[sc.talent_id]

    if sc.case == "SAFE_ROUTINE":
        demands=_demands(sc.talent_id,difficulty=5,hard_min=3)
    elif sc.case == "EDGE_UNCERTAIN":
        demands=_demands(sc.talent_id,difficulty=9,hard_min=3)
    elif sc.case == "EXTREME_RISK":
        demands=_demands(sc.talent_id,difficulty=12,hard_min=3)
    elif sc.case == "HARD_LIMIT":
        stat=t.required_stats[0]; c["stats"][stat]=2
        demands=_demands(sc.talent_id,difficulty=5,hard_min=5)
    elif sc.case == "INACCESSIBLE_TALENT":
        c["talents"]=[]
    elif sc.case == "INACCESSIBLE_SKILL":
        c["skills"][t.required_skills[0]]=0
    elif sc.case == "STATE_IMPAIRMENT":
        stat=t.required_stats[0]; c["stat_penalties"][stat]=5
        demands=_demands(sc.talent_id,difficulty=5,hard_min=5)
    elif sc.case == "AIDED_METHOD":
        demands=_demands(sc.talent_id,difficulty=10,hard_min=3)
        kwargs["situational_bonus"]=3
    elif sc.case == "EXPERTISE_APPLIED":
        demands=_demands(sc.talent_id,difficulty=10,hard_min=3)
        kwargs["expertise_bonus"]=3
    elif sc.case == "ACTIVE_OPPOSITION":
        demands=_demands(sc.talent_id,difficulty=5,hard_min=3)
        kwargs["opposition_penalty"]=5
    elif sc.case == "PARTIAL_SUCCESS_LATE_LIMIT":
        # First stage deliberately succeeds. A later stage uses the same available
        # body but a higher unavoidable minimum, proving that early information is retained.
        first_stat=t.required_stats[0]
        later=t.modifies_stages[-1]
        demands=(
            StageDemand("INPUT",{first_stat:3},4),
            StageDemand(later,{first_stat:9},5),
        )

    r=assess_talent(c,sc.talent_id,demands,**kwargs)
    assert r.zone == sc.expected_zone
    if sc.case == "PARTIAL_SUCCESS_LATE_LIMIT":
        assert r.stages[0].passed_information is True
        assert r.failure_stage == demands[-1].stage
