import json
import unittest

from runtime.player_progression import (
    PlayerProgressionState,
    PlayerLearningRuntime,
    RawActionEvent,
)


class BehaviorTrackingTests(unittest.TestCase):
    def runtime(self, start='GHOST', run='r1'):
        return PlayerLearningRuntime(PlayerProgressionState('p1', run, start))

    def test_npc_and_crew_actions_never_train_player(self):
        rt = self.runtime()
        before = dict(rt.progression.affinities)
        accepted = rt.observe(RawActionEvent(
            'HACK', {'AFF_NETWORK': 1.0}, actor_is_player=False,
            difficulty_hint=2.0, consequence_hint=2.0,
        ))
        self.assertFalse(accepted)
        self.assertEqual(before, rt.progression.affinities)
        self.assertEqual(rt.tracker_state.ignored_non_player_events, 1)

    def test_exact_safe_repetition_is_strongly_damped(self):
        farm = self.runtime('BREAKER', 'farm')
        meaningful = self.runtime('BREAKER', 'meaningful')

        for _ in range(30):
            farm.observe(RawActionEvent(
                'BREACH', {'AFF_FORCE': 1.0}, location_id='safe_room',
                target_kind='practice_door', tool_kind='boot',
                difficulty_hint=0.15, consequence_hint=0.1,
                risk_tags=('safe','training_dummy','no_consequence'),
            ))

        contexts = [
            ('lab','security_door','ram'),
            ('tunnel','jammed_hatch','crowbar'),
            ('warehouse','barricade','shoulder'),
            ('reactor','blast_door','hydraulic_tool'),
        ]
        for loc, target, tool in contexts:
            meaningful.observe(RawActionEvent(
                'BREACH', {'AFF_FORCE': 1.0, 'AFF_ADAPTATION': 0.25},
                location_id=loc, target_kind=target, tool_kind=tool,
                difficulty_hint=1.45, consequence_hint=1.35,
                risk_tags=('dangerous','time_pressure'),
            ))

        self.assertGreater(meaningful.progression.affinities['AFF_FORCE'],
                           farm.progression.affinities['AFF_FORCE'])

    def test_meaningful_failure_can_teach(self):
        rt = self.runtime('OPERATOR')
        rt.observe(RawActionEvent(
            'FIELD_REPAIR', {'AFF_TECH': 1.0, 'AFF_ADAPTATION': 0.4},
            location_id='generator', target_kind='power_unit', tool_kind='scrap_kit',
            outcome='failure', difficulty_hint=1.7, consequence_hint=1.5,
            risk_tags=('dangerous','time_pressure'), context_tags=('improvised',),
        ))
        self.assertGreater(rt.progression.affinities['AFF_TECH'], 0)
        self.assertGreater(rt.progression.affinities['AFF_ADAPTATION'], 0)

    def test_cross_class_behavior_is_preserved(self):
        rt = self.runtime('BREAKER')
        rt.observe(RawActionEvent(
            'TRIAGE', {'AFF_MEDICAL': 1.0, 'AFF_PROTECTION': 0.5},
            location_id='alley', target_kind='crew_wounded', tool_kind='medkit',
            difficulty_hint=1.2, consequence_hint=1.7,
            risk_tags=('combat','dangerous'),
        ))
        self.assertGreater(rt.progression.affinities['AFF_MEDICAL'], 0)
        self.assertGreater(rt.progression.affinities['AFF_PROTECTION'], 0)

    def test_tracker_roundtrip_keeps_antifarm_history(self):
        rt = self.runtime('GHOST')
        event = RawActionEvent(
            'STEALTH_MOVE', {'AFF_STEALTH': 1.0, 'AFF_MOBILITY': 0.3},
            location_id='hall', target_kind='patrol', tool_kind='none',
            difficulty_hint=1.0, consequence_hint=1.0,
        )
        for _ in range(4):
            rt.observe(event)
        blob = json.loads(json.dumps(rt.to_dict()))
        restored = PlayerLearningRuntime.from_dict(blob)
        before = restored.progression.affinities['AFF_STEALTH']
        restored.observe(event)
        gain_after_restore = restored.progression.affinities['AFF_STEALTH'] - before

        fresh = self.runtime('GHOST', 'fresh')
        before_fresh = fresh.progression.affinities['AFF_STEALTH']
        fresh.observe(event)
        gain_fresh = fresh.progression.affinities['AFF_STEALTH'] - before_fresh
        self.assertLess(gain_after_restore, gain_fresh)

    def test_no_hidden_numbers_in_player_visible_payload(self):
        rt = self.runtime('OPERATOR')
        rt.observe(RawActionEvent('HACK', {'AFF_NETWORK':1.0}))
        visible = rt.affinity_engine.player_visible_payload(rt.progression)
        encoded = json.dumps(visible)
        self.assertNotIn('tracker_state', encoded)
        self.assertNotIn('affinities', encoded)
        self.assertNotIn('pattern_evidence', encoded)


if __name__ == '__main__':
    unittest.main()
