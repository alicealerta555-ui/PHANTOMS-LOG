import unittest
from dataclasses import replace

from runtime.core.chronology import CRY_T0
from runtime.stage4a import (
    BiologicalProcess,
    NON_DETERMINISM_RULES,
    SUPEREVOLUTION_LATEST_START_CRY,
    SUPEREVOLUTION_MIN_LEAD_YEARS,
    SUPEREVOLUTION_PHASES,
    assert_process_allowed_in_epoch,
    biological_phase_for_process,
    validate_superevolution_timeline,
)


class Stage4ASuperevolutionTimelineTests(unittest.TestCase):
    def test_current_timeline_validates(self):
        validate_superevolution_timeline()

    def test_superevolution_begins_at_least_2000_years_before_t0(self):
        self.assertGreaterEqual(SUPEREVOLUTION_MIN_LEAD_YEARS, 2000)
        self.assertLessEqual(SUPEREVOLUTION_LATEST_START_CRY, CRY_T0 - 2000)

    def test_all_processes_have_exactly_one_phase(self):
        for process in BiologicalProcess:
            phase = biological_phase_for_process(process)
            self.assertIn(process, phase.processes)

    def test_therapy_precedes_adaptation(self):
        therapy = biological_phase_for_process(BiologicalProcess.THERAPEUTIC_MODIFICATION)
        adaptation = biological_phase_for_process(BiologicalProcess.DIRECTED_ADAPTATION)
        self.assertLess(therapy.order, adaptation.order)

    def test_adaptation_precedes_hybridization(self):
        adaptation = biological_phase_for_process(BiologicalProcess.DIRECTED_ADAPTATION)
        hybrid = biological_phase_for_process(BiologicalProcess.DIRECTED_HYBRIDIZATION)
        self.assertLess(adaptation.order, hybrid.order)
        self.assertEqual(hybrid.canonical_epochs, ("E2",))

    def test_repeated_mixing_follows_hybridization(self):
        hybrid = biological_phase_for_process(BiologicalProcess.DIRECTED_HYBRIDIZATION)
        mixing = biological_phase_for_process(BiologicalProcess.REPEATED_MIXING)
        self.assertLess(hybrid.order, mixing.order)

    def test_free_drift_requires_control_failure(self):
        drift = biological_phase_for_process(BiologicalProcess.FREE_DRIFT)
        self.assertTrue(drift.requires_control_failure)
        self.assertIn("E4", drift.canonical_epochs)

    def test_stable_sublineages_are_late_not_retroactive(self):
        stable = biological_phase_for_process(BiologicalProcess.STABLE_SUBLINEAGE_FORMATION)
        self.assertEqual(stable.canonical_epochs, ("E5",))
        self.assertIn("not retroactive", stable.causal_rule)

    def test_hybridization_cannot_be_asserted_in_e0(self):
        with self.assertRaisesRegex(ValueError, "BIOLOGICAL_PROCESS_NOT_ALLOWED_IN_EPOCH"):
            assert_process_allowed_in_epoch(BiologicalProcess.DIRECTED_HYBRIDIZATION, "E0")

    def test_free_drift_cannot_be_asserted_in_e2(self):
        with self.assertRaisesRegex(ValueError, "BIOLOGICAL_PROCESS_NOT_ALLOWED_IN_EPOCH"):
            assert_process_allowed_in_epoch(BiologicalProcess.FREE_DRIFT, "E2")

    def test_duplicate_phase_id_fails_closed(self):
        broken = tuple(list(SUPEREVOLUTION_PHASES) + [replace(SUPEREVOLUTION_PHASES[-1], order=7)])
        with self.assertRaisesRegex(ValueError, "DUPLICATE_BIOLOGICAL_PHASE_ID"):
            validate_superevolution_timeline(broken)

    def test_unknown_epoch_fails_closed(self):
        broken = list(SUPEREVOLUTION_PHASES)
        broken[0] = replace(broken[0], canonical_epochs=("EX",))
        with self.assertRaisesRegex(ValueError, "UNKNOWN_CANONICAL_EPOCH"):
            validate_superevolution_timeline(tuple(broken))

    def test_control_failure_cannot_be_removed_from_free_drift(self):
        broken = list(SUPEREVOLUTION_PHASES)
        broken[5] = replace(broken[5], requires_control_failure=False)
        with self.assertRaisesRegex(ValueError, "FREE_DRIFT_REQUIRES_POST_CONTROL_FAILURE_POPULATIONS"):
            validate_superevolution_timeline(tuple(broken))

    def test_non_determinism_contract_covers_protected_axes(self):
        joined = "\n".join(NON_DETERMINISM_RULES)
        for term in ("morality", "profession", "dominance", "submission", "attraction", "consent", "personality"):
            self.assertIn(term, joined)
        self.assertIn("physiological_response_is_not_a_decision", NON_DETERMINISM_RULES)


if __name__ == "__main__":
    unittest.main()
