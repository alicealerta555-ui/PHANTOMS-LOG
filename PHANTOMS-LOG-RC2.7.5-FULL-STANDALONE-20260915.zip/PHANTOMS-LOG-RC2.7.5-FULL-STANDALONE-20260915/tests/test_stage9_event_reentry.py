from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from uuid import uuid4

from runtime.stage3a.kernel import CommitRecord
from runtime.stage3c.isolation import FilesystemRunRepository, RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import AuthorityStatus, StateAuthority
from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType
from runtime.stage9.event_reentry import (
    SEMANTIC_EFFECT_EVENT_TYPE,
    EventReentryStatus,
    ScheduledEventReentry,
)
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.scheduler import SchedulerCommitAdapter, SchedulerQueue
from runtime.stage9.world_time import WorldClock, WorldTimeCommitAdapter


class Stage9EventReentryTests(unittest.TestCase):
    def setUp(self):
        self.manager = RunSessionManager(master_seed=20260911)
        self.player_uuid = str(uuid4())
        self.session = self.manager.create_run(player_uuid=self.player_uuid)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(self.player_uuid, self.session.identity.run_uuid, "actor:player")
        self.registry.register(self.identity, actor_definition_id="actor-def:player")
        self.authority = StateAuthority(self.session, actor_registry=self.registry)
        self.scheduler = SchedulerCommitAdapter(self.session)
        self.queue = SchedulerQueue(self.session)
        self.clock = WorldClock(self.session)
        self.time = WorldTimeCommitAdapter(self.session)
        self.reentry = ScheduledEventReentry(self.session, actor_registry=self.registry)
        self.counter = 0

    def _schedule(self, scheduled_id: str, descriptor: dict, *, due: int = 0, event_type: str = SEMANTIC_EFFECT_EVENT_TYPE):
        self.counter += 1
        p = EffectProposal(
            effect_id=f"effect:schedule:{self.counter}",
            run_uuid=self.session.identity.run_uuid,
            resolution_id=f"resolution:schedule:{self.counter}",
            source_action_id=f"action:schedule:{self.counter}",
            effect_type=EffectType.SCHEDULE_EVENT,
            target_ref=scheduled_id,
            payload={
                "scheduled_event_id": scheduled_id,
                "event_type": event_type,
                "due_world_time": due,
                "sequence_key": scheduled_id,
                "payload": descriptor,
            },
            authority_domain=AuthorityDomain.SCHEDULER,
            expected_state_revision=self.session.store.revision,
        )
        d = self.authority.authorize(p)
        self.assertEqual(d.status, AuthorityStatus.ALLOW)
        return self.scheduler.apply(d, commit_id=f"commit:schedule:{self.counter}", event_id=f"SCHEDULE:{self.counter}")

    @staticmethod
    def _time_descriptor(seconds: int) -> dict:
        return {"effect_type": "ADVANCE_WORLD_TIME", "target_ref": None, "payload": {"seconds": seconds}}

    def test_due_event_reenters_authority_commits_effect_then_consumes(self):
        self._schedule("scheduled:time", self._time_descriptor(5))
        before = self.session.store.revision
        receipt = self.reentry.process_next_due()
        self.assertEqual(receipt.status, EventReentryStatus.COMMITTED_AND_CONSUMED)
        self.assertEqual(self.clock.seconds, 5)
        self.assertIsNone(self.queue.get("scheduled:time"))
        self.assertEqual(self.session.store.revision, before + 2)  # effect + consume

    def test_no_due_event_is_read_only(self):
        before_rev = self.session.store.revision
        before_hash = self.session.store.state_hash()
        receipt = self.reentry.process_next_due()
        self.assertEqual(receipt.status, EventReentryStatus.NO_DUE_EVENT)
        self.assertEqual(self.session.store.revision, before_rev)
        self.assertEqual(self.session.store.state_hash(), before_hash)

    def test_unsupported_event_type_rejected_without_consumption(self):
        self._schedule("scheduled:legacy", self._time_descriptor(5), event_type="LEGACY_DIRECT_EXEC")
        before_rev = self.session.store.revision
        receipt = self.reentry.process_next_due()
        self.assertEqual(receipt.status, EventReentryStatus.INVALID_EVENT)
        self.assertIn("SCHEDULED_EVENT_TYPE_UNSUPPORTED", receipt.reason_codes)
        self.assertEqual(self.session.store.revision, before_rev)
        self.assertIsNotNone(self.queue.get("scheduled:legacy"))

    def test_invalid_semantic_descriptor_rejected_without_consumption(self):
        self._schedule("scheduled:bad", {"effect_type": "ADVANCE_WORLD_TIME", "payload": {"seconds": 1}, "raw_patch": {"x": 1}})
        before_rev = self.session.store.revision
        receipt = self.reentry.process_next_due()
        self.assertEqual(receipt.status, EventReentryStatus.INVALID_EVENT)
        self.assertTrue(any("FIELD_FORBIDDEN" in r for r in receipt.reason_codes))
        self.assertEqual(self.session.store.revision, before_rev)
        self.assertIsNotNone(self.queue.get("scheduled:bad"))

    def test_actor_authority_rejection_leaves_event_queued(self):
        descriptor = {
            "effect_type": "MOVE_ACTOR",
            "target_ref": "actor:ghost",
            "payload": {"actor_instance_id": "actor:ghost", "destination_location_id": "loc:2"},
        }
        self._schedule("scheduled:ghost", descriptor)
        before_rev = self.session.store.revision
        receipt = self.reentry.process_next_due()
        self.assertEqual(receipt.status, EventReentryStatus.AUTHORITY_REJECTED)
        self.assertIn("ACTOR_NOT_REGISTERED_IN_RUN", receipt.reason_codes)
        self.assertEqual(self.session.store.revision, before_rev)
        self.assertIsNotNone(self.queue.get("scheduled:ghost"))

    def test_allowed_effect_without_commit_adapter_fails_closed(self):
        descriptor = {
            "effect_type": "MOVE_ACTOR",
            "target_ref": "actor:player",
            "payload": {"actor_instance_id": "actor:player", "destination_location_id": "loc:2"},
        }
        self._schedule("scheduled:move", descriptor)
        before_rev = self.session.store.revision
        receipt = self.reentry.process_next_due()
        self.assertEqual(receipt.status, EventReentryStatus.COMMIT_ROUTE_UNAVAILABLE)
        self.assertEqual(self.session.store.revision, before_rev)
        self.assertIsNotNone(self.queue.get("scheduled:move"))

    def test_crash_after_effect_before_consume_retry_only_consumes(self):
        scheduled_id = "scheduled:crash"
        self._schedule(scheduled_id, self._time_descriptor(7))
        effect = EffectProposal(
            effect_id=self.reentry.effect_id_for(scheduled_id),
            run_uuid=self.session.identity.run_uuid,
            resolution_id=f"event-resolution:{self.reentry._token(scheduled_id)}",
            source_action_id=f"event-action:{self.reentry._token(scheduled_id)}",
            effect_type=EffectType.ADVANCE_WORLD_TIME,
            target_ref=None,
            payload={"seconds": 7},
            authority_domain=AuthorityDomain.WORLD_TIME,
            expected_state_revision=self.session.store.revision,
        )
        decision = self.authority.authorize(effect)
        self.assertEqual(decision.status, AuthorityStatus.ALLOW)
        first = self.time.advance(
            decision,
            commit_id=self.reentry.effect_commit_id_for(scheduled_id),
            event_id=self.reentry.effect_event_id_for(scheduled_id),
        )
        self.assertIsInstance(first, CommitRecord)
        self.assertEqual(self.clock.seconds, 7)
        self.assertIsNotNone(self.queue.get(scheduled_id))  # simulated crash window
        before_retry = self.session.store.revision
        receipt = self.reentry.process_next_due()
        self.assertEqual(receipt.status, EventReentryStatus.ALREADY_COMMITTED_AND_CONSUMED)
        self.assertEqual(self.clock.seconds, 7)
        self.assertIsNone(self.queue.get(scheduled_id))
        self.assertEqual(self.session.store.revision, before_retry + 1)  # consume only

    def test_effect_id_binding_conflict_fails_closed(self):
        scheduled_id = "scheduled:binding"
        self._schedule(scheduled_id, self._time_descriptor(3))
        p = EffectProposal(
            effect_id=self.reentry.effect_id_for(scheduled_id),
            run_uuid=self.session.identity.run_uuid,
            resolution_id="resolution:other",
            source_action_id="action:other",
            effect_type=EffectType.ADVANCE_WORLD_TIME,
            target_ref=None,
            payload={"seconds": 1},
            authority_domain=AuthorityDomain.WORLD_TIME,
            expected_state_revision=self.session.store.revision,
        )
        d = self.authority.authorize(p)
        self.time.advance(d, commit_id="commit:other", event_id="EVENT:OTHER")
        receipt = self.reentry.process_next_due()
        self.assertEqual(receipt.status, EventReentryStatus.EFFECT_COMMIT_REJECTED)
        self.assertIn("EVENT_EFFECT_IDEMPOTENCY_BINDING_CONFLICT", receipt.reason_codes)
        self.assertIsNotNone(self.queue.get(scheduled_id))

    def test_scheduler_cascade_is_re_evaluated_one_event_per_call(self):
        child_descriptor = self._time_descriptor(2)
        parent_descriptor = {
            "effect_type": "SCHEDULE_EVENT",
            "target_ref": "scheduled:child",
            "payload": {
                "scheduled_event_id": "scheduled:child",
                "event_type": SEMANTIC_EFFECT_EVENT_TYPE,
                "due_world_time": 0,
                "sequence_key": "child",
                "payload": child_descriptor,
            },
        }
        self._schedule("scheduled:parent", parent_descriptor)
        first = self.reentry.process_next_due()
        self.assertEqual(first.status, EventReentryStatus.COMMITTED_AND_CONSUMED)
        self.assertIsNone(self.queue.get("scheduled:parent"))
        self.assertIsNotNone(self.queue.get("scheduled:child"))
        self.assertEqual(self.clock.seconds, 0)
        second = self.reentry.process_next_due()
        self.assertEqual(second.status, EventReentryStatus.COMMITTED_AND_CONSUMED)
        self.assertEqual(self.clock.seconds, 2)
        self.assertIsNone(self.queue.get("scheduled:child"))

    def test_self_cancel_effect_counts_as_consumed(self):
        scheduled_id = "scheduled:selfcancel"
        descriptor = {
            "effect_type": "CANCEL_EVENT",
            "target_ref": scheduled_id,
            "payload": {"scheduled_event_id": scheduled_id},
        }
        self._schedule(scheduled_id, descriptor)
        receipt = self.reentry.process_next_due()
        self.assertEqual(receipt.status, EventReentryStatus.COMMITTED_AND_CONSUMED)
        self.assertIsNone(self.queue.get(scheduled_id))

    def test_save_load_after_effect_before_consume_resumes_without_double_apply(self):
        scheduled_id = "scheduled:persist-crash"
        self._schedule(scheduled_id, self._time_descriptor(4))
        effect = EffectProposal(
            effect_id=self.reentry.effect_id_for(scheduled_id),
            run_uuid=self.session.identity.run_uuid,
            resolution_id=f"event-resolution:{self.reentry._token(scheduled_id)}",
            source_action_id=f"event-action:{self.reentry._token(scheduled_id)}",
            effect_type=EffectType.ADVANCE_WORLD_TIME,
            target_ref=None,
            payload={"seconds": 4},
            authority_domain=AuthorityDomain.WORLD_TIME,
            expected_state_revision=self.session.store.revision,
        )
        d = self.authority.authorize(effect)
        self.time.advance(d, commit_id=self.reentry.effect_commit_id_for(scheduled_id), event_id=self.reentry.effect_event_id_for(scheduled_id))
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(Path(td))
            repo.save(self.session)
            ident = self.session.identity
            self.manager.close_run(player_uuid=ident.player_uuid, run_uuid=ident.run_uuid)
            loaded = repo.load_session(self.manager, ident)
            registry = RunActorRegistry(loaded)
            engine = ScheduledEventReentry(loaded, actor_registry=registry)
            receipt = engine.process_next_due()
            self.assertEqual(receipt.status, EventReentryStatus.ALREADY_COMMITTED_AND_CONSUMED)
            self.assertEqual(WorldClock(loaded).seconds, 4)
            self.assertIsNone(SchedulerQueue(loaded).get(scheduled_id))

    def test_due_knowledge_event_uses_new_knowledge_commit_route(self):
        descriptor = {
            "effect_type": "WRITE_KNOWLEDGE",
            "target_ref": "actor:player",
            "payload": {
                "actor_instance_id": "actor:player",
                "knowledge_key": "event.alarm_heard",
                "value": {"signal_detected": True, "channel": "auditory"},
                "provenance": "SCHEDULED_EVENT:test",
                "epistemic": {
                    "source_type": "RECORD",
                    "source_id": "scheduled:test",
                    "origin_location": "PERCEPTION_ORIGIN_UNSPECIFIED",
                    "learned_at": 0,
                    "path": [],
                    "confidence_ppm": 1000000,
                    "distortions": [],
                },
            },
        }
        self._schedule("scheduled:knowledge", descriptor)
        before = self.session.store.revision
        receipt = self.reentry.process_next_due()
        self.assertEqual(receipt.status, EventReentryStatus.COMMITTED_AND_CONSUMED)
        self.assertIsNone(self.queue.get("scheduled:knowledge"))
        self.assertEqual(self.session.store.revision, before + 2)
        record = self.session.store.actor_knowledge["actor:player"]["event.alarm_heard"]
        self.assertEqual(record["value"], {"signal_detected": True, "channel": "auditory"})
        self.assertEqual(self.session.store.player_knowledge, {})


if __name__ == "__main__":
    unittest.main(verbosity=2)
