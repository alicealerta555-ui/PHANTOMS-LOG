from runtime.player_progression import (
    PlayerProgressionState, PlayerLearningRuntime, PlayerDevelopmentCoordinator,
    LiveContext, RawActionEvent, DecisionEvent,
)


def make():
    state = PlayerProgressionState(player_uuid='p1', run_uuid='r1', start_class='GHOST')
    return PlayerDevelopmentCoordinator(PlayerLearningRuntime(progression=state))


def test_action_hook_routes_learning_and_messages():
    c = make()
    result = c.on_action(RawActionEvent(
        action_family='stealth_move', affinity_weights={'AFF_STEALTH':1.0,'AFF_MOBILITY':0.6}, outcome='success',
        location_id='corridor-a', context_tags=('stealth','mobility'), difficulty_hint=1.2, consequence_hint=1.0,
        actor_is_player=True,
    ))
    assert result.applied_action_learning is True
    assert isinstance(result.insight_messages, list)


def test_non_player_action_does_not_learn():
    c = make()
    result = c.on_action(RawActionEvent(
        action_family='stealth_move', affinity_weights={'AFF_STEALTH':1.0}, outcome='success',
        location_id='corridor-a', context_tags=('stealth',), actor_is_player=False,
    ))
    assert result.applied_action_learning is False


def test_decision_hook_routes_habit_learning():
    c = make()
    for _ in range(12):
        c.on_decision(DecisionEvent('room_entry','use_cover',context_tags=('unknown_room',)))
    assert c.runtime.habit_state.habits['cover_entry'].stage in {'habit','instinct'}


def test_explicit_order_vetoes_prediction():
    c = make()
    for _ in range(16):
        c.on_decision(DecisionEvent('room_entry','use_cover',context_tags=('unknown_room',)))
    out = c.before_player_prompt(LiveContext('room_entry',('unknown_room',),explicit_player_order=True))
    assert out.predicted_routine is None


def test_high_stakes_vetoes_prediction():
    c = make()
    for _ in range(16):
        c.on_decision(DecisionEvent('room_entry','use_cover',context_tags=('unknown_room',)))
    out = c.before_player_prompt(LiveContext('room_entry',('unknown_room',),high_stakes=True))
    assert out.predicted_routine is None


def test_irreversible_vetoes_prediction():
    c = make()
    for _ in range(16):
        c.on_decision(DecisionEvent('room_entry','use_cover',context_tags=('unknown_room',)))
    out = c.before_player_prompt(LiveContext('room_entry',('unknown_room',),reversible=False))
    assert out.predicted_routine is None


def test_roundtrip_schema8_and_identity():
    c = make()
    for _ in range(8):
        c.on_decision(DecisionEvent('room_entry','use_cover'))
    payload = c.snapshot_for_save()
    assert payload['schema_version'] == 10
    d = PlayerDevelopmentCoordinator.from_save(payload)
    assert d.runtime.progression.player_uuid == 'p1'
    assert d.runtime.progression.run_uuid == 'r1'
    assert 'cover_entry' in d.runtime.habit_state.habits


def test_retraining_request_does_not_delete_habit():
    c = make()
    for _ in range(12):
        c.on_decision(DecisionEvent('room_entry','use_cover'))
    before = c.runtime.habit_state.habits['cover_entry'].stage
    msg = c.request_retraining('cover_entry','enter_directly')
    after = c.runtime.habit_state.habits['cover_entry'].stage
    assert msg is not None
    assert before == after
    assert c.runtime.habit_state.habits['cover_entry'].retraining_requested is True
