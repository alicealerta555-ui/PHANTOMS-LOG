import ast
from pathlib import Path
import tempfile
import unittest

from runtime.stage9.single_writer import audit_active_tree


ROOT = Path(__file__).resolve().parents[1]


class Stage9SingleWriterTests(unittest.TestCase):
    def test_active_production_tree_has_no_direct_canonical_state_writer(self):
        self.assertEqual(audit_active_tree(ROOT), ())

    def test_audit_detects_direct_runtime_state_assignment(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            path = root / "runtime" / "rogue.py"
            path.parent.mkdir(parents=True)
            path.write_text(
                "def bad(session):\n"
                "    session.kernel.store.runtime_state['hp'] = 0\n",
                encoding="utf-8",
            )
            findings = audit_active_tree(root)
            self.assertEqual(len(findings), 1)
            self.assertIn("runtime_state", findings[0].target)

    def test_audit_detects_direct_revision_write(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            path = root / "runtime" / "rogue.py"
            path.parent.mkdir(parents=True)
            path.write_text(
                "def bad(kernel):\n"
                "    kernel.store.revision += 1\n",
                encoding="utf-8",
            )
            findings = audit_active_tree(root)
            self.assertEqual(len(findings), 1)
            self.assertEqual(findings[0].target, "kernel.store.revision")

    def test_commit_kernel_write_is_allowed(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            path = root / "runtime" / "stage3a" / "kernel.py"
            path.parent.mkdir(parents=True)
            path.write_text(
                "class CommitKernel:\n"
                "    def _apply(self, store):\n"
                "        store.runtime_state['hp'] = 1\n",
                encoding="utf-8",
            )
            self.assertEqual(audit_active_tree(root), ())

    def test_noncanonical_local_mutation_is_not_flagged(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            path = root / "runtime" / "rules.py"
            path.parent.mkdir(parents=True)
            path.write_text(
                "def ok():\n"
                "    values = {}\n"
                "    values['hp'] = 1\n",
                encoding="utf-8",
            )
            self.assertEqual(audit_active_tree(root), ())


if __name__ == '__main__':
    unittest.main()
