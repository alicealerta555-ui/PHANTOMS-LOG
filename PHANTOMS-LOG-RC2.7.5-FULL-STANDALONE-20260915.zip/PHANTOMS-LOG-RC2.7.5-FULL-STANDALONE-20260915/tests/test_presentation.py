import json
from contextlib import contextmanager

from runtime.player_progression import (
    PlayerProgressionState, DevelopmentPresenter, assert_player_payload_clean,
    INSIGHTS, SPECIALIZATIONS, MASTERY, END_PATHS, PlayerLearningRuntime,
)

@contextmanager
def raises(error):
    try:
        yield
    except error:
        return
    raise AssertionError(f"{error.__name__} was not raised")


def state(start="GHOST"):
    return PlayerProgressionState("p", "r", start)


def flatten(obj):
    return json.dumps(obj, ensure_ascii=False)


def test_snapshot_contains_no_numeric_progression_values():
    s = state()
    s.affinities["AFF_STEALTH"] = 123.4
    s.affinities["AFF_TECH"] = 88.0
    payload = DevelopmentPresenter().development_snapshot(s)
    assert_player_payload_clean(payload)
    assert "123" not in flatten(payload)
    assert "88" not in flatten(payload)


def test_snapshot_does_not_expose_affinity_identifiers():
    s = state("OPERATOR")
    s.affinities["AFF_TECH"] = 90
    s.affinities["AFF_NETWORK"] = 75
    txt = flatten(DevelopmentPresenter().development_snapshot(s))
    assert "AFF_TECH" not in txt
    assert "AFF_NETWORK" not in txt
    assert "affinity" not in txt.lower()


def test_snapshot_describes_cross_class_direction():
    s = state("GHOST")
    s.affinities["AFF_STEALTH"] = 100
    s.affinities["AFF_TECH"] = 95
    payload = DevelopmentPresenter().development_snapshot(s)
    assert "techn" in payload["direction"].lower()
    assert "unauff" in payload["direction"].lower()


def test_insight_unlock_hides_effect_key_and_requirements():
    d = next(iter(INSIGHTS.values()))
    payload = DevelopmentPresenter().insight_unlock(d)
    assert_player_payload_clean(payload)
    txt = flatten(payload)
    assert "effect_key" not in txt
    assert d.effect_key not in txt


def test_specialization_offer_contains_only_human_facing_choices():
    s = state("BREAKER")
    defs = [d for d in SPECIALIZATIONS.values() if d.start_class == "BREAKER"][:2]
    payload = DevelopmentPresenter().specialization_offer(defs, s)
    assert_player_payload_clean(payload)
    assert len(payload["options"]) == 2
    assert set(payload["options"][0]) == {"name", "description"}


def test_mastery_reveal_is_narrative_only():
    d = MASTERY[("GHOST", "OPERATOR")]
    payload = DevelopmentPresenter().mastery_reveal(d)
    assert_player_payload_clean(payload)
    assert payload["title"] == "Spectre"
    assert "Signatur" in payload["detail"]


def test_end_path_reveal_is_narrative_only():
    d = END_PATHS["THE_BASTION"]
    payload = DevelopmentPresenter().end_path_reveal(d)
    assert_player_payload_clean(payload)
    assert payload["title"] == "The Bastion"


def test_guard_rejects_numeric_payload():
    with raises(ValueError):
        assert_player_payload_clean({"text": "ok", "progress": 0.7})


def test_guard_rejects_hidden_affinity_token():
    with raises(ValueError):
        assert_player_payload_clean({"text": "AFF_STEALTH entwickelt sich"})


def test_guard_rejects_hidden_key():
    with raises(ValueError):
        assert_player_payload_clean({"score": "high"})


def test_empty_character_gets_open_ended_description():
    payload = DevelopmentPresenter().development_snapshot(state("RESONANT"))
    assert "offen" in payload["observations"][0].lower()
    assert_player_payload_clean(payload)


def test_growth_hint_is_qualitative():
    s = state("BREAKER")
    s.affinities["AFF_PROTECTION"] = 30
    p = DevelopmentPresenter().soft_growth_hint(s)
    assert p is not None
    assert_player_payload_clean(p)
    assert "Gewohnheit" in p["title"]


def test_runtime_visible_development_uses_canonical_guard():
    s = state("OPERATOR")
    s.affinities["AFF_MEDICAL"] = 77
    rt = PlayerLearningRuntime(s)
    payload = rt.visible_development()
    assert_player_payload_clean(payload)


def test_runtime_save_keeps_numbers_internal():
    s = state("GHOST")
    s.affinities["AFF_MOBILITY"] = 44.5
    rt = PlayerLearningRuntime(s)
    internal = rt.to_dict()
    assert isinstance(internal["progression"]["affinities"]["AFF_MOBILITY"], float)
    visible = rt.visible_development()
    assert_player_payload_clean(visible)


def test_player_message_has_no_level_number_dependency():
    s = state("BREAKER")
    s.level = 50
    s.affinities["AFF_FORCE"] = 100
    p = DevelopmentPresenter().development_snapshot(s)
    assert "50" not in flatten(p)
