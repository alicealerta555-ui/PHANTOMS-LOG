from runtime.player_progression.npc_naming import NPCNameGenerator, NameRequest
from runtime.player_progression.npc_encounter import (
    NPCFirstContactEngine, NPCVisualSnapshot, NPCEncounterContext,
    NPCPresentationProfile, NPCEncounterRegistry,
)


def setup_engine(npc_id="n1", species="thresholdborn", callsign=True):
    names = NPCNameGenerator(seed="enc")
    names.generate(NameRequest(npc_id, species, force_callsign=callsign, known_to_player=False))
    return names, NPCFirstContactEngine(names, seed="encounter")


def test_random_sighting_does_not_auto_introduce():
    names, eng = setup_engine()
    r = eng.first_contact(
        NPCVisualSnapshot("n1", apparent_build="Eine hochgewachsene Gestalt"),
        NPCEncounterContext(encounter_type="random", player_initiated_contact=False),
        NPCPresentationProfile(openness=1, trust_to_player=1),
    )
    assert r.display_name == "Unbekannte Person"
    assert r.introduction_line is None


def test_profession_is_not_inferred_from_clues():
    names, eng = setup_engine(species="baseline_human")
    r = eng.first_contact(
        NPCVisualSnapshot("n1", profession_clues=("Öl sitzt in den Handschuhfalten",), true_profession="Maschinentechnikerin"),
        NPCEncounterContext(player_initiated_contact=False),
        NPCPresentationProfile(),
    )
    assert "Maschinentechnikerin" not in r.visible_description
    assert r.profession_revealed is False
    assert r.profession_label is None
    assert "Öl sitzt" in r.visible_description


def test_known_role_can_be_labeled_without_guessing():
    names, eng = setup_engine(species="baseline_human")
    r = eng.first_contact(
        NPCVisualSnapshot("n1", true_profession="Ärztin", profession_clues=("Eine medizinische Tasche hängt über der Schulter",)),
        NPCEncounterContext(role_known_to_player=True),
        NPCPresentationProfile(),
    )
    assert r.profession_revealed
    assert r.profession_label == "Ärztin"


def test_hostile_actor_keeps_name_hidden():
    names, eng = setup_engine()
    r = eng.first_contact(
        NPCVisualSnapshot("n1"),
        NPCEncounterContext(encounter_type="hostile", player_initiated_contact=True),
        NPCPresentationProfile(openness=1, trust_to_player=1, hostility=1),
    )
    assert r.name_reveal == "unknown"


def test_callsign_preference_reveals_callsign_only():
    names, eng = setup_engine(callsign=True)
    r = eng.first_contact(
        NPCVisualSnapshot("n1"),
        NPCEncounterContext(encounter_type="crew", player_initiated_contact=True),
        NPCPresentationProfile(openness=.8, caution=.2, prefers_callsign=True),
    )
    assert r.name_reveal == "callsign"
    assert r.display_name == names.registry.names["n1"].callsign


def test_formal_open_actor_can_use_full_name():
    names, eng = setup_engine(species="baseline_human")
    r = eng.first_contact(
        NPCVisualSnapshot("n1"),
        NPCEncounterContext(encounter_type="professional", player_initiated_contact=True, formal_setting=True),
        NPCPresentationProfile(openness=.9, caution=.1, formality=.9, trust_to_player=.7),
    )
    assert r.name_reveal == "full"
    assert r.display_name == names.registry.names["n1"].full_name


def test_danger_blocks_polite_introduction():
    names, eng = setup_engine(species="baseline_human")
    r = eng.first_contact(
        NPCVisualSnapshot("n1"),
        NPCEncounterContext(encounter_type="professional", player_initiated_contact=True, formal_setting=True, danger=.9),
        NPCPresentationProfile(openness=1, caution=0, formality=1, trust_to_player=1),
    )
    assert r.name_reveal == "unknown"


def test_reveal_never_goes_backwards():
    names, eng = setup_engine(species="baseline_human")
    eng.first_contact(NPCVisualSnapshot("n1"), NPCEncounterContext(encounter_type="professional", player_initiated_contact=True, formal_setting=True), NPCPresentationProfile(openness=1, caution=0, formality=1, trust_to_player=1))
    r = eng.first_contact(NPCVisualSnapshot("n1"), NPCEncounterContext(encounter_type="random"), NPCPresentationProfile(hostility=1))
    assert r.name_reveal == "full"


def test_registry_roundtrip_preserves_knowledge():
    names, eng = setup_engine(species="baseline_human")
    eng.establish_profession("n1", "Technikerin")
    eng.registry.get("n1").name_reveal = "given"
    raw = eng.snapshot_for_save()
    restored = NPCFirstContactEngine.from_save(names, raw)
    st = restored.registry.get("n1")
    assert st.name_reveal == "given"
    assert st.known_profession == "Technikerin"


def test_description_contains_only_supplied_visible_cues():
    names, eng = setup_engine(species="baseline_human")
    r = eng.first_contact(
        NPCVisualSnapshot("n1", clothing=("Ein abgewetzter Mantel",), movement=("Sie hält den linken Arm auffällig ruhig",), visible_gear=("Ein zerkratzter Scanner am Gürtel",)),
        NPCEncounterContext(), NPCPresentationProfile()
    )
    assert "Mantel" in r.visible_description
    assert "Scanner" in r.visible_description
    assert "Arm" in r.visible_description


def test_adaptive_runtime_persists_npc_identity_layer():
    from runtime.player_progression.pipeline import PlayerLearningRuntime
    from runtime.player_progression.model import PlayerProgressionState
    from runtime.player_progression.adaptive_runtime import AdaptiveGameplayRuntime
    prog = PlayerProgressionState(player_uuid="p", run_uuid="r", start_class="GHOST")
    rt = AdaptiveGameplayRuntime.new(PlayerLearningRuntime(prog))
    n = rt.ensure_npc_name(NameRequest("persist-npc", "chimera", force_callsign=True))
    rt.present_npc(
        NPCVisualSnapshot("persist-npc", clothing=("Eine dunkle Jacke",)),
        NPCEncounterContext(encounter_type="crew", player_initiated_contact=True),
        NPCPresentationProfile(openness=.9, caution=.1, prefers_callsign=True),
    )
    raw = rt.snapshot_for_save()
    restored = AdaptiveGameplayRuntime.from_save(raw)
    assert restored.npc_names.registry.names["persist-npc"].full_name == n.full_name
    assert restored.npc_first_contact.registry.get("persist-npc").name_reveal != "unknown"
