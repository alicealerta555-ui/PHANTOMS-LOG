
import json, unittest
from pathlib import Path
from runtime.content_stage42.finance import *
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage42_finance_credit.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_account_types(self):
  self.assertGreaterEqual(len(D["account_types"]),4)

 def test_transfer_requires_funds(self):
  self.assertIsNone(transfer_candidate("A","B",100,50,"EV"))

 def test_transfer_authority(self):
  p=transfer_candidate("A","B",50,50,"EV")
  self.assertTrue(p["authority_required"])

 def test_credit_limit_and_liability(self):
  prod=D["credit_products"][0]
  p=credit_issue_candidate(prod,"BOR",400,"LEN","EV")
  self.assertEqual(p["amount"],p["matching_liability"])
  self.assertIsNone(credit_issue_candidate(prod,"BOR",99999,"LEN","EV"))

 def test_interest_requires_periods(self):
  self.assertEqual(accrue_interest(100,1000,0)["interest_accrued"],0.0)
  self.assertGreater(accrue_interest(100,1000,2)["interest_accrued"],0)

 def test_payment_conservation(self):
  p=payment_projection(100,30)
  self.assertEqual(p["applied"]+p["remaining"],100)

 def test_default_not_personality(self):
  self.assertEqual(default_state(100,0,True),"DEFAULT")
  self.assertEqual(default_state(100,100,True),"CURRENT")

 def test_claim_requires_coverage(self):
  pol={"covers":["fire"],"deductible":10,"coverage_limit":100}
  self.assertIsNone(insurance_claim_candidate(pol,"flood",50,True,True,"EV"))

 def test_claim_requires_premium_and_evidence(self):
  pol={"covers":["fire"],"deductible":10,"coverage_limit":100}
  self.assertIsNone(insurance_claim_candidate(pol,"fire",50,False,True,"EV"))
  self.assertIsNone(insurance_claim_candidate(pol,"fire",50,True,False,"EV"))

 def test_claim_payout_bounded(self):
  pol={"covers":["fire"],"deductible":10,"coverage_limit":25}
  p=insurance_claim_candidate(pol,"fire",100,True,True,"EV")
  self.assertEqual(p["proposed_payout"],25)

 def test_settlement_authority(self):
  p=debt_settlement_candidate("D",100,100,"EV")
  self.assertTrue(p["settled"])
  self.assertTrue(p["authority_required"])

if __name__=="__main__": unittest.main()
