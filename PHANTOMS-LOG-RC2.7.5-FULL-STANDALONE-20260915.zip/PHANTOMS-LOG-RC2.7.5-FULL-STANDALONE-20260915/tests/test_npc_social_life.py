from runtime.player_progression.npc_social_life import *

def actor(i,**kw):
    d=dict(npc_id=i); d.update(kw); return NPCSocialActor(**d)

def test_sparse_relationship_created_only_on_contact():
    e=NPCSocialLifeEngine(); assert e.edge("a","b") is None
    e.interact(actor("a"),actor("b"),SocialLifeContext(1))
    assert e.edge("a","b") is not None

def test_common_interest_builds_bond():
    e=NPCSocialLifeEngine(); r=e.interact(actor("a",interests=("tech",)),actor("b",interests=("tech",)),SocialLifeContext(1))
    assert r.action=="BOND" and e.edge("a","b").respect>0

def test_friction_can_exist_without_hostility_script():
    e=NPCSocialLifeEngine(); r=e.interact(actor("a",dislikes=("gambling",)),actor("b",interests=("gambling",)),SocialLifeContext(1))
    assert r.action=="FRICTION"

def test_danger_suppresses_social_chatter():
    e=NPCSocialLifeEngine(); r=e.interact(actor("a"),actor("b"),SocialLifeContext(1,safe=False))
    assert r.action=="TASK_FOCUSED" and e.edge("a","b") is None

def test_group_ritual_persists():
    e=NPCSocialLifeEngine(); e.set_group_ritual("crew","tea after watch")
    e2=NPCSocialLifeEngine.from_save(e.snapshot_for_save()); assert e2.state.group_rituals["crew"]=="tea after watch"
