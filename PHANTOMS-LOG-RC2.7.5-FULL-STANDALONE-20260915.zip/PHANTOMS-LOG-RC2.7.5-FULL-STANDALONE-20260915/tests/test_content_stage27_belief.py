
import json, unittest
from pathlib import Path
from runtime.content_stage27.belief import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage27_belief_institutions.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_institutions(self):
  self.assertGreaterEqual(len(D["institution_archetypes"]),5)

 def test_belief_bounded(self):
  x=belief_delta({"conviction":95,"institutional_loyalty":95},{"conviction":50,"institutional_loyalty":50})
  self.assertEqual(x["conviction"],100); self.assertEqual(x["institutional_loyalty"],100)

 def test_doctrine_not_truth(self):
  d=doctrine_record("D","I","claim","source",90)
  self.assertFalse(d["world_truth"])

 def test_ritual_requires_participants(self):
  self.assertIsNone(ritual_candidate("R","I",[],"L",1,[],"EV"))

 def test_ritual_authority(self):
  r=ritual_candidate("R","I",["a"],"L",1,["b"],"EV")
  self.assertTrue(r["authority_required"])

 def test_taboo_requires_committed_event(self):
  self.assertIsNone(taboo_violation_candidate("T","a",False,50,"EV"))

 def test_taboo_authority(self):
  t=taboo_violation_candidate("T","a",True,50,"EV")
  self.assertTrue(t["authority_required"])

 def test_conversion_not_automatic(self):
  c=conversion_pressure(50,80,20,0,0)
  self.assertFalse(c["auto_conversion"])

 def test_ritual_consequence_authority(self):
  r=ritual_candidate("R","I",["a"],"L",1,[],"EV")
  p=ritual_consequence_proposals(r,["social_bond"])
  self.assertEqual(len(p),1)
  self.assertTrue(p[0]["authority_required"])

 def test_claim_rule(self):
  self.assertTrue(D["doctrine_contract"]["claim_is_not_world_truth"])

if __name__=="__main__": unittest.main()
