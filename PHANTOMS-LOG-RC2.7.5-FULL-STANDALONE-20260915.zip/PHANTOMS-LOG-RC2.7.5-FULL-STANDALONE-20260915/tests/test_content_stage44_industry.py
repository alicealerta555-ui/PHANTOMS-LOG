
import json, unittest
from pathlib import Path
from runtime.content_stage44.industry import *
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage44_industry_manufacturing.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_facility_types(self):
  self.assertGreaterEqual(len(D["facility_types"]),4)

 def test_inputs_sufficient(self):
  self.assertTrue(inputs_sufficient({"A":2},{"A":4},2))
  self.assertFalse(inputs_sufficient({"A":2},{"A":3},2))

 def test_max_batches_from_inputs(self):
  self.assertEqual(max_batches_from_inputs({"A":2,"B":1},{"A":5,"B":10}),2)

 def test_throughput_requires_time(self):
  self.assertEqual(throughput_capacity(100,100,100,0),0)

 def test_machine_condition_reduces_throughput(self):
  a=throughput_capacity(100,100,100,1)
  b=throughput_capacity(100,50,100,1)
  self.assertGreater(a,b)

 def test_production_requires_inputs(self):
  r=D["recipes"][0]
  self.assertIsNone(production_candidate("B","F",r,{},100,100,1,1,"EV"))

 def test_production_authority(self):
  r=D["recipes"][0]
  p=production_candidate("B","F",r,{"MAT_WIRE":10,"MAT_SCRAP_METAL":10},100,100,1,1,"EV")
  self.assertTrue(p["authority_required"])

 def test_output_defects_conserve_gross(self):
  r=D["recipes"][0]
  x=output_projection(r,10,2000)
  item=list(r["outputs"].keys())[0]
  gross=r["outputs"][item]*10
  self.assertEqual(x["outputs"][item]+x["defects"][item],gross)

 def test_machine_states(self):
  self.assertEqual(machine_state(100),"OPERATIONAL")
  self.assertEqual(machine_state(40),"DEGRADED")
  self.assertEqual(machine_state(10),"FAILED")
  self.assertEqual(machine_state(0),"DESTROYED")

 def test_provenance_required(self):
  self.assertIsNone(batch_provenance("B","F","R",[],1))
  self.assertIsNotNone(batch_provenance("B","F","R",["IN1"],1))

 def test_intermediate_skip_rule(self):
  self.assertTrue(any("intermediate steps cannot be skipped" in x.lower() for x in D["rules"]))

if __name__=="__main__": unittest.main()
