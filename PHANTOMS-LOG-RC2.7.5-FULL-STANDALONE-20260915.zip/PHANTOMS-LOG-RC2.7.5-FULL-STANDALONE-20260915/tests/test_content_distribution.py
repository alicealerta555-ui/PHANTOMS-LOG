from pathlib import Path
import json, tempfile

from runtime.full_version.catalog import FullVersionCatalog
from runtime.full_version.content_distribution import ContentDistributionResolver
from playable_full_version.playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, Domain

ROOT=Path(__file__).resolve().parents[1]


def test_distribution_schema_and_culture_separation():
    raw=json.loads((ROOT/'content/full_version/content_distribution_profiles.json').read_text(encoding='utf-8'))
    assert raw['schema']=='PH4NT0M5_CONTENT_DISTRIBUTION_V1'
    assert len(raw['cultures'])>=8
    assert any(x.get('hybrid_of') for x in raw['cultures'])
    assert all('lineage' not in x for x in raw['cultures'])
    assert len(raw['item_profiles'])==80


def test_distance_and_biome_make_rare_content_less_available_not_impossible():
    c=FullVersionCatalog.load(ROOT); r=ContentDistributionResolver(c)
    local=r.resolve('item_def:data:064','loc:underground_dungeon:01',run_uuid='run:a')
    far=r.resolve('item_def:data:064','loc:residential_domestic:01',run_uuid='run:a')
    assert local.availability_ppm > far.availability_ppm
    assert far.availability_ppm >= r.rules['availability_floor_ppm']
    assert local.biome_match is True and far.biome_match is False


def test_hybrid_culture_is_explicit_and_can_select_bounded_variant_pool():
    c=FullVersionCatalog.load(ROOT); r=ContentDistributionResolver(c)
    x=r.resolve('item_def:data:032','loc:wilderness_routes:06',run_uuid='run:x',culture_id='culture:rim_deep')
    assert x.hybrid_culture is True
    assert x.culture_match is True
    assert x.allowed_variant_indexes
    assert set(x.allowed_variant_indexes) <= {0,1,2}


def test_lineage_factor_requires_explicit_lineage():
    c=FullVersionCatalog.load(ROOT); r=ContentDistributionResolver(c)
    plain=r.resolve('item_def:data:056','loc:perimeter_outskirts:01',run_uuid='run:y')
    linked=r.resolve('item_def:data:056','loc:perimeter_outskirts:01',run_uuid='run:y',lineage_id='lineage:drift_stalker')
    assert plain.lineage_match is False
    assert linked.lineage_match is True
    assert linked.availability_ppm >= plain.availability_ppm


def test_data_presentation_is_location_contextual_but_run_stable():
    with tempfile.TemporaryDirectory() as tmp:
        g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class='OPERATOR',master_seed=20260913)
        draft=g.creation_template(); g.complete_character(draft)
        actor=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,'actor:player')
        location=actor['location_ref']
        item_def='item_def:data:016'
        p1=g.data_runtime.presentation_packet(item_def,location)
        p2=g.data_runtime.presentation_packet(item_def,location)
        assert p1==p2
        assert p1['distribution_packet']['location_id']==location
        assert p1['variation_index'] in p1['distribution_packet'].get('allowed_variant_indexes',[]) or not p1['distribution_packet'].get('allowed_variant_indexes')


def test_prompt_guards_culture_lineage_and_distance():
    text=(ROOT/'content/full_version/prompts/CONTENT_VARIATION_PROMPT_CORE.md').read_text(encoding='utf-8').lower()
    assert 'biological lineage and cultural membership are separate' in text
    assert 'distance from an origin region' in text
    assert 'never infer an actor' in text
    assert 'rarity changes probability' in text
