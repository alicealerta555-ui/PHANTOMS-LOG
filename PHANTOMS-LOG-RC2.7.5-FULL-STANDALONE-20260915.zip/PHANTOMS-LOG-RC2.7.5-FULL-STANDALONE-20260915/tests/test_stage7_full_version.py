# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
import unittest
from pathlib import Path
from uuid import UUID

from runtime.full_version.catalog import FullVersionCatalog
from runtime.full_version.bootstrap import FullVersionBootstrap, PLAYER_ACTOR_INSTANCE_ID
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage7.needs import *
from runtime.stage9.actor_context import ActorContextProjector
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import StateAuthority
from runtime.stage9.identity import RuntimeIdentity

PLAYER=str(UUID('22222222-2222-4222-8222-222222222222'))

class Stage7FullVersionTests(unittest.TestCase):
    def setUp(self):
        self.root=Path(__file__).resolve().parents[1]; self.catalog=FullVersionCatalog.load(self.root); self.manager=RunSessionManager(master_seed=707); self.session=self.manager.create_run(player_uuid=PLAYER); self.registry=RunActorRegistry(self.session)
        FullVersionBootstrap(self.catalog).initialize_new_run(self.session,self.registry,start_class='BREAKER')
        self.authority=StateAuthority(self.session,actor_registry=self.registry); self.engine=Stage7NeedEngine(self.session,self.registry,self.catalog.stage7_needs); self.adapter=Stage7CommitAdapter(self.session,self.registry)
    def test_bootstrap_actor_has_full_need_profile(self):
        snap=self.engine.reader.snapshot_for_actor(PLAYER_ACTOR_INSTANCE_ID); self.assertEqual(len(snap.pressures),len(self.catalog.stage7_needs.need_keys)); self.assertEqual(snap.run_uuid,self.session.identity.run_uuid)
    def test_time_and_event_changes_are_causal_and_actor_local(self):
        before={x.need_key:x.pressure_ppm for x in self.engine.reader.snapshot_for_actor(PLAYER_ACTOR_INSTANCE_ID).pressures}
        deltas=self.engine.time_deltas('needs:player_default',3600); eps=self.engine.proposals(PLAYER_ACTOR_INSTANCE_ID,deltas,cause_ref='time:1h',resolution_id='resolution:time',source_action_id='action:time',effect_prefix='effect:time')
        self.adapter.apply_many(tuple(self.authority.authorize(x) for x in eps),commit_id='commit:time',event_id='event:time')
        after={x.need_key:x.pressure_ppm for x in self.engine.reader.snapshot_for_actor(PLAYER_ACTOR_INSTANCE_ID).pressures}; self.assertGreater(after['nutrition'],before['nutrition']); self.assertGreater(after['hydration'],before['hydration'])
        mods=self.engine.event_deltas('meal'); eps=self.engine.proposals(PLAYER_ACTOR_INSTANCE_ID,mods,cause_ref='event:meal',resolution_id='resolution:meal',source_action_id='action:meal',effect_prefix='effect:meal')
        self.adapter.apply_many(tuple(self.authority.authorize(x) for x in eps),commit_id='commit:meal',event_id='event:meal'); final={x.need_key:x.pressure_ppm for x in self.engine.reader.snapshot_for_actor(PLAYER_ACTOR_INSTANCE_ID).pressures}; self.assertLess(final['nutrition'],after['nutrition'])
    def test_multiple_needs_compete_and_none_is_action_authority(self):
        mods={'safety':500000,'autonomy':400000,'belonging':300000}; eps=self.engine.proposals(PLAYER_ACTOR_INSTANCE_ID,mods,cause_ref='event:pressure',resolution_id='resolution:pressure',source_action_id='action:pressure',effect_prefix='effect:pressure')
        self.adapter.apply_many(tuple(self.authority.authorize(x) for x in eps),commit_id='commit:pressure',event_id='event:pressure')
        ranked=self.engine.ranked_pressures(PLAYER_ACTOR_INSTANCE_ID); self.assertGreaterEqual(len([x for x in ranked if x.pressure_ppm>300000]),2)
        self.assertFalse(hasattr(ranked[0],'action')); self.assertFalse(hasattr(ranked[0],'consent'))
    def test_actor_logic_context_receives_actor_local_need_pressures(self):
        identity=RuntimeIdentity(self.session.identity.player_uuid,self.session.identity.run_uuid,PLAYER_ACTOR_INSTANCE_ID); ctx=ActorContextProjector(self.session,self.registry,identity).project(); self.assertEqual(len(ctx.needs),len(self.catalog.stage7_needs.need_keys)); self.assertTrue(all(0<=x.pressure_ppm<=1_000_000 for x in ctx.needs))
    def test_multi_turn_npc_need_scene_changes_motives_without_forcing_action(self):
        npc_id='actor:npc:stage7:worker'
        npc_identity=RuntimeIdentity(self.session.identity.player_uuid,self.session.identity.run_uuid,npc_id)
        self.registry.register(npc_identity,actor_definition_id='npc:stage7:worker')
        profile=self.catalog.stage7_needs.profile('needs:sapient_default')
        self.adapter.bootstrap_actor(npc_id,profile['initial_pressure_ppm'],profile_id='needs:sapient_default',event_id='event:npc:needs:init')
        before=self.engine.ranked_pressures(npc_id)
        threat=self.engine.proposals(npc_id,self.engine.event_deltas('threat'),cause_ref='turn:1:threat',resolution_id='resolution:npc:turn1',source_action_id='action:npc:turn1',effect_prefix='effect:npc:turn1')
        self.adapter.apply_many(tuple(self.authority.authorize(x) for x in threat),commit_id='commit:npc:turn1',event_id='event:npc:turn1')
        turn1=self.engine.ranked_pressures(npc_id)
        recovery=self.engine.proposals(npc_id,self.engine.event_deltas('safe_shelter'),cause_ref='turn:2:shelter',resolution_id='resolution:npc:turn2',source_action_id='action:npc:turn2',effect_prefix='effect:npc:turn2')
        self.adapter.apply_many(tuple(self.authority.authorize(x) for x in recovery),commit_id='commit:npc:turn2',event_id='event:npc:turn2')
        turn2=self.engine.ranked_pressures(npc_id)
        b={x.need_key:x.pressure_ppm for x in before}; t1={x.need_key:x.pressure_ppm for x in turn1}; t2={x.need_key:x.pressure_ppm for x in turn2}
        self.assertGreater(t1['safety'],b['safety']); self.assertLess(t2['safety'],t1['safety'])
        ctx=ActorContextProjector(self.session,self.registry,npc_identity).project()
        self.assertEqual({x.need_key:x.pressure_ppm for x in ctx.needs},t2)
        self.assertFalse(hasattr(ctx,'forced_action')); self.assertFalse(hasattr(ctx,'consent'))

    def test_cross_run_need_isolation(self):
        other=self.manager.create_run(player_uuid=PLAYER); otherreg=RunActorRegistry(other); FullVersionBootstrap(self.catalog).initialize_new_run(other,otherreg,start_class='OPERATOR')
        mods=self.engine.event_deltas('threat'); eps=self.engine.proposals(PLAYER_ACTOR_INSTANCE_ID,mods,cause_ref='event:threat',resolution_id='resolution:threat',source_action_id='action:threat',effect_prefix='effect:threat'); self.adapter.apply_many(tuple(self.authority.authorize(x) for x in eps),commit_id='commit:threat',event_id='event:threat')
        self.assertNotEqual(Stage7NeedReader(self.session,self.registry).snapshot_for_actor(PLAYER_ACTOR_INSTANCE_ID),Stage7NeedReader(other,otherreg).snapshot_for_actor(PLAYER_ACTOR_INSTANCE_ID))

if __name__=='__main__': unittest.main(verbosity=2)
