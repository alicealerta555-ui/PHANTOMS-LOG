from pathlib import Path
import tempfile

import pytest

from playable.game import FullVersionGame
from playable.location_images import ImageConfig
from runtime.stage3a.kernel import Authority, Domain
from runtime.stage9.world_time import WorldClock
from runtime.full_version.persistent_world import PersistentWorldError

ROOT=Path(__file__).resolve().parents[1]


def game(*, images='off'):
    td=tempfile.TemporaryDirectory()
    g=FullVersionGame(core_root=ROOT,saves_root=Path(td.name),start_class='OPERATOR',master_seed=20260913,image_config=ImageConfig(mode=images))
    g.complete_character(g.creation_template())
    g._tmp=td
    return g


def first_npc(g):
    for inst in g.actor_registry.instances():
        if not inst.actor_instance_id.startswith('actor:npc:'):
            continue
        rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,inst.actor_instance_id)
        if isinstance(rec,dict) and rec.get('location_ref') and int(rec.get('hp',1))>0:
            return inst.actor_instance_id,rec
    raise AssertionError('no NPC')


def test_population_precondition_uses_real_context_not_category_tag_alone():
    g=game(); loc=next(x['location_id'] for x in g.catalog.world['locations'] if x['primary_category']=='residential_domestic')
    none={x['id'] for x in g.dynamic_events.eligible(loc,population_context={'expected_present':0,'explicit_living_npcs':0,'population_presence_ppm':1_000_000})}
    some={x['id'] for x in g.dynamic_events.eligible(loc,population_context={'expected_present':1,'explicit_living_npcs':0,'population_presence_ppm':1_000_000})}
    assert 'local_dispute' not in none
    assert 'local_dispute' in some


def test_secondary_pressure_retains_parent_provenance_and_chain_depth():
    g=game(); loc=g.location(); now=WorldClock(g.session).seconds
    parent='world_event:parent:tension'
    st=g.dynamic_events._state()
    st['events'][parent]={
        'event_id':parent,'event_type':'local_dispute','severity':'minor','location_id':loc,
        'created_world_time':now,'status':'ACTIVE','causal_tags':['population_present'],
        'parent_event_id':None,'root_event_id':parent,'chain_depth':0,'player_targeted':False,'presentation':'UNSEEN',
        'consequence_state':{'phase':'ACTIVE','phase_world_time':now,'visual_trace':'x','audio_trace':'x','effects':{'social_tension_ppm':1_350_000},'rumor_seeded':False},
    }
    g.dynamic_events._commit_state(st,'TEST_CHAIN_PARENT')
    ctx=g.dynamic_events.secondary_pressure_context(loc)
    assert 'faction_tension' in ctx['tags'] and parent in ctx['parents_by_tag']['faction_tension']
    # Force a single causal child candidate so the provenance assertion is deterministic.
    g.dynamic_events.t['event_types']=[{'id':'faction_flashpoint','severity':'major','requires':['faction_tension','population_present'],'weight':1,'offscreen':True,'consequence':'faction_signal'}]
    g.dynamic_events.t['director']['event_cost']['major']=1
    g.dynamic_events.t['director']['breather_seconds']['major']=0
    g.npc_routines.wait(900)
    pressure={loc:{'tags':['faction_tension'],'parents_by_tag':{'faction_tension':[parent]}}}
    pop={loc:{'expected_present':1,'explicit_living_npcs':0,'population_presence_ppm':1_000_000}}
    created=g.dynamic_events.tick(pressures_by_location=pressure,population_by_location=pop)
    assert created and created[0]['parent_event_id']==parent
    assert created[0]['root_event_id']==parent and created[0]['chain_depth']==1


def test_chain_depth_cap_blocks_unbounded_recursive_event_generation():
    g=game(); loc=g.location(); now=WorldClock(g.session).seconds
    parent='world_event:parent:maxdepth'; st=g.dynamic_events._state()
    st['events'][parent]={
        'event_id':parent,'event_type':'local_dispute','severity':'minor','location_id':loc,
        'created_world_time':now,'status':'ACTIVE','causal_tags':['population_present'],'parent_event_id':'older',
        'root_event_id':'root','chain_depth':4,'player_targeted':False,'presentation':'UNSEEN',
        'consequence_state':{'phase':'ACTIVE','phase_world_time':now,'visual_trace':'x','audio_trace':'x','effects':{'social_tension_ppm':1_350_000},'rumor_seeded':False},
    }
    g.dynamic_events._commit_state(st,'TEST_CHAIN_CAP')
    g.dynamic_events.t['event_types']=[{'id':'faction_flashpoint','severity':'major','requires':['faction_tension','population_present'],'weight':1,'offscreen':True,'consequence':'faction_signal'}]
    g.dynamic_events.t['director']['event_cost']['major']=1; g.dynamic_events.t['director']['breather_seconds']['major']=0
    g.npc_routines.wait(900)
    created=g.dynamic_events.tick(
        pressures_by_location={loc:{'tags':['faction_tension'],'parents_by_tag':{'faction_tension':[parent]}}},
        population_by_location={loc:{'expected_present':1,'explicit_living_npcs':0,'population_presence_ppm':1_000_000}},
    )
    assert created==[]


def test_persistent_infrastructure_damage_is_idempotent_and_survives_save_load():
    g=game(); loc=g.location(); now=WorldClock(g.session).seconds; eid='world_event:test:damage'
    event={'event_id':eid,'event_type':'route_disruption','severity':'major','location_id':loc,'created_world_time':now,'status':'ACTIVE'}
    g.persistent_world.sync_from_dynamic_events({eid:event},actors_by_location={})
    first=g.persistent_world.infrastructure(loc)
    g.persistent_world.sync_from_dynamic_events({eid:event},actors_by_location={})
    second=g.persistent_world.infrastructure(loc)
    assert first['integrity']==82 and second['integrity']==82
    g.save(); loaded=FullVersionGame(core_root=ROOT,saves_root=g.saves_root,master_seed=20260913,image_config=ImageConfig(mode='off'))
    assert loaded.persistent_world.infrastructure(loc)['integrity']==82


def test_npc_workers_can_rebuild_damaged_infrastructure_over_time():
    g=game(); loc=g.location(); g.persistent_world.damage_infrastructure(loc,50,source_event_id='test:damage',cause='TEST')
    before=g.persistent_world.infrastructure(loc)['integrity']
    g.npc_routines.wait(7200)
    changed=g.persistent_world.npc_rebuild_tick(
        elapsed_seconds=3600,
        living_actors_by_location={loc:[('actor:npc:worker',{'role':'mechanic','hp':10,'location_ref':loc})]},
        service_capacity_by_location={loc:1_000_000},
    )
    after=g.persistent_world.infrastructure(loc)['integrity']
    assert changed and after>before


def test_offscreen_death_requires_real_present_named_npc_and_leaves_corpse_and_quest_seed():
    g=game(); nid,npc=first_npc(g); loc=str(npc['location_ref']); now=WorldClock(g.session).seconds
    g.persistent_world.cfg['offscreen_mortality']['event_risk_ppm']['faction_flashpoint']=1_000_000
    eid='world_event:test:death'
    event={'event_id':eid,'event_type':'faction_flashpoint','severity':'major','location_id':loc,'created_world_time':now,'status':'ACTIVE'}
    changes=g.persistent_world.sync_from_dynamic_events({eid:event},actors_by_location={loc:[(nid,npc)]})
    dead=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,nid)
    corpses=g.persistent_world.corpses_at(loc)
    assert nid in changes['deaths'] and dead['life_state']=='DEAD' and dead['hp']==0
    assert len(corpses)==1 and corpses[0]['npc_actor_id']==nid
    assert any(x['kind']=='CORPSE_INVESTIGATION' for x in g.persistent_world.dynamic_quest_seeds(location_id=loc))


def test_major_event_can_generate_a_new_playable_quest_and_search_can_complete_it():
    g=game(); loc=g.location(); eid='world_event:test:quest'; now=WorldClock(g.session).seconds
    event={'event_id':eid,'event_type':'medical_emergency','severity':'major','location_id':loc,'created_world_time':now,'status':'ACTIVE'}
    g.persistent_world.sync_from_dynamic_events({eid:event},actors_by_location={})
    seed=next(x for x in g.persistent_world.dynamic_quest_seeds(location_id=loc) if x['kind']=='EVENT_INVESTIGATION')
    qid,q=g.quest_runtime.materialize_dynamic_seed(seed); g.persistent_world.mark_quest_seed_materialized(seed['seed_id'],qid)
    assert q['state']=='AVAILABLE' and q['template_id']=='dynamic:event_investigation'
    receipt=g.execute(action_type='QUEST_ACCEPT',raw_input='accept '+qid,target_refs=(qid,))
    assert receipt.outcome_id=='QUEST_ACCEPTED'
    completed=g.quest_runtime.observe_dynamic_search(loc)
    assert qid in completed
    final=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
    assert final['state']=='COMPLETED' and final['final_outcome']=='event_investigated'


def test_long_term_environment_change_requires_cause_duration_and_is_rate_limited():
    g=game(); region=g.catalog.location(g.location())['region_id']
    with pytest.raises(PersistentWorldError,match='ENVIRONMENT_CAUSE_REQUIRED'):
        g.persistent_world.apply_environment_shift(region,cause_id='',elapsed_seconds=86400,ecology_delta_ppm=1000)
    with pytest.raises(PersistentWorldError,match='ENVIRONMENT_CAUSAL_DURATION_TOO_SHORT'):
        g.persistent_world.apply_environment_shift(region,cause_id='cause',elapsed_seconds=3600,ecology_delta_ppm=1000)
    rec=g.persistent_world.apply_environment_shift(region,cause_id='cause',elapsed_seconds=30*86400,ecology_delta_ppm=900000,climate_offset_millic=900000)
    assert abs(rec['ecology_shift_ppm'])<=25000
    assert abs(rec['climate_offset_millic'])<=100


def test_location_image_cache_changes_for_durable_damage_not_transient_event_trace():
    g=game(images='chatgpt'); loc=g.location()
    a=g.request_location_image(); assert a
    now=WorldClock(g.session).seconds; eid='world_event:test:visual'
    st=g.dynamic_events._state(); st['events'][eid]={
        'event_id':eid,'event_type':'local_dispute','severity':'minor','location_id':loc,'created_world_time':now,'status':'ACTIVE',
        'consequence_state':{'phase':'ACTIVE','phase_world_time':now,'visual_trace':'temporary clutter','audio_trace':'voices','effects':{},'rumor_seeded':False},
    }
    g.dynamic_events._commit_state(st,'TEST_TRANSIENT_VISUAL')
    b=g.request_location_image(); assert b['request_id']==a['request_id']
    g.persistent_world.damage_infrastructure(loc,40,source_event_id='damage:test',cause='TEST')
    c=g.request_location_image(); assert c['request_id']!=a['request_id']


def test_compact_status_panel_contains_player_progression_and_survival_summary():
    g=game(); p=g.status_panel(); text=g.status_panel_text()
    assert {'location_name','day','time','credits','level','xp','needs','weather','infrastructure_state'}<=set(p)
    assert 'hp' not in p and 'max_hp' not in p
    assert {'hydration','nutrition','rest','climate_fit'}<=set(p['needs'])
    assert all({'pressure_ppm','percent','band'}<=set(p['needs'][k]) for k in ('hydration','nutrition','rest','climate_fit'))
    assert 'Lvl ' in text and 'XP ' in text and 'HP ' not in text
    assert 'Durst ' in text and 'Hunger ' in text and 'Müdigkeit ' in text and 'Temperatur ' in text
    assert 'causal_tags' not in text and 'world_event:' not in text
