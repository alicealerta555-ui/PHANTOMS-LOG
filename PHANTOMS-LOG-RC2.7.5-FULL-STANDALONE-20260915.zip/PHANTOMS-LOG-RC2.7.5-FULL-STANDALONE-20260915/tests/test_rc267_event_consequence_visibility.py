from pathlib import Path
import json
import tempfile

from playable.game import FullVersionGame
from runtime.stage9.world_time import WorldClock
from runtime.stage3a.kernel import Authority,Domain
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]


def make_game():
    td=tempfile.TemporaryDirectory()
    g=FullVersionGame(core_root=ROOT,saves_root=Path(td.name),start_class='OPERATOR',master_seed=20260913)
    g.complete_character(g.creation_template())
    g._tmp=td
    return g


def seed_event(g,event_type='local_dispute',severity='minor',location_id=None):
    loc=location_id or g.location(); now=WorldClock(g.session).seconds
    eid=f'world_event:rc267:{event_type}:{loc}'
    st=g.dynamic_events._state()
    st['events'][eid]={
        'event_id':eid,'event_type':event_type,'severity':severity,'location_id':loc,
        'created_world_time':now,'status':'MATERIALIZED','causal_tags':['test:hidden-cause'],
        'player_targeted':False,'presentation':'UNSEEN',
    }
    g.dynamic_events._commit_state(st,'TEST_RC267_EVENT')
    g.dynamic_events._schedule_marker(eid,'ACTIVE',now+60)
    return eid


def activate(g,eid):
    g.npc_routines.wait(60)
    processed=g.dynamic_events.process_due_lifecycle()
    assert (eid,'ACTIVE') in processed


def test_materialized_event_has_no_observable_trace_until_active():
    g=make_game(); seed_event(g,'local_dispute','minor')
    assert g.dynamic_events.perceived_consequences_at(g.location(),weather_id='WX_CLEAR')==()


def test_active_event_creates_persistent_consequence_and_safe_projection():
    g=make_game(); eid=seed_event(g,'local_dispute','minor'); activate(g,eid)
    rec=g.dynamic_events._state()['events'][eid]
    assert rec['consequence_state']['phase']=='ACTIVE'
    seen=g.dynamic_events.perceived_consequences_at(g.location(),weather_id='WX_CLEAR',detail=True)
    assert len(seen)==1 and seen[0]['visual'] and seen[0]['audio']
    raw=json.dumps(seen,ensure_ascii=False)
    assert 'causal_tags' not in raw and 'event_type' not in raw and 'test:hidden-cause' not in raw


def test_weather_can_mask_quiet_event_hearing_and_visibility():
    g=make_game(); eid=seed_event(g,'ambient_repair','ambient'); activate(g,eid)
    clear=g.dynamic_events.perceived_consequences_at(g.location(),weather_id='WX_CLEAR')
    dust=g.dynamic_events.perceived_consequences_at(g.location(),weather_id='WX_DUST_STORM')
    assert clear and clear[0]['audio'] and clear[0]['visual']
    assert dust==()


def test_aftermath_and_residual_trace_age_out():
    g=make_game(); eid=seed_event(g,'ambient_repair','ambient'); activate(g,eid)
    g.npc_routines.wait(g.dynamic_events.t['lifecycle']['active_seconds_by_severity']['ambient'])
    g.dynamic_events.process_due_lifecycle()
    rec=g.dynamic_events._state()['events'][eid]
    assert rec['status']=='AFTERMATH' and rec['consequence_state']['phase']=='AFTERMATH'
    assert g.dynamic_events.perceived_consequences_at(g.location(),weather_id='WX_CLEAR')
    g.npc_routines.wait(g.dynamic_events.t['lifecycle']['aftermath_seconds_by_severity']['ambient'])
    g.dynamic_events.process_due_lifecycle()
    rec=g.dynamic_events._state()['events'][eid]
    assert rec['status']=='EXPIRED' and rec['consequence_state']['phase']=='RESIDUAL'
    assert g.dynamic_events.perceived_consequences_at(g.location(),weather_id='WX_CLEAR')
    g.npc_routines.wait(g.dynamic_events._profile('ambient_repair')['residual_seconds']+1)
    assert g.dynamic_events.perceived_consequences_at(g.location(),weather_id='WX_CLEAR')==()


def test_arrival_receives_only_observable_event_projection():
    g=make_game(); eid=seed_event(g,'rare_world_encounter','critical'); activate(g,eid)
    text=g.arrival_description(); packet=g.consume_arrival_packet()
    traces=packet['visible_context']['event_traces']
    assert traces and traces[0]['visual'] in text
    raw=json.dumps(packet['visible_context'],ensure_ascii=False)
    assert 'causal_tags' not in raw and 'event_type' not in raw and 'test:hidden-cause' not in raw


def test_market_shortage_has_mechanical_price_effect():
    g=make_game(); eid=seed_event(g,'market_shortage','minor'); activate(g,eid)
    assert g.dynamic_events.market_price_multiplier_ppm(g.location())==1_250_000
    g.npc_routines.wait(g.dynamic_events.t['lifecycle']['active_seconds_by_severity']['minor'])
    g.dynamic_events.process_due_lifecycle()
    assert g.dynamic_events.market_price_multiplier_ppm(g.location())==1_120_000


def test_route_disruption_adds_canonical_travel_time_in_execute_path():
    g=make_game(); destination=g.catalog.location(g.location())['connections'][0]
    eid=seed_event(g,'route_disruption','major'); activate(g,eid)
    before=WorldClock(g.session).seconds
    with patch.object(g.dynamic_events,'apply_route_delay',wraps=g.dynamic_events.apply_route_delay) as wrapped:
        g.execute(action_type='MOVE',raw_input='go',parameters={'destination_location_id':destination})
    assert wrapped.call_count==1
    assert WorldClock(g.session).seconds-before>=180

def test_event_rumor_requires_real_npc_witness_and_never_seeds_player():
    g=make_game()
    witness=None; witness_loc=None
    for inst in g.actor_registry.instances():
        if not inst.actor_instance_id.startswith('actor:npc:'): continue
        rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,inst.actor_instance_id)
        if isinstance(rec,dict) and rec.get('location_ref'):
            witness=inst.actor_instance_id; witness_loc=str(rec['location_ref']); break
    assert witness and witness_loc
    eid=seed_event(g,'local_dispute','minor',location_id=witness_loc)
    before=WorldClock(g.session).seconds
    g.npc_routines.wait(60)
    g._world_pulse(before)
    npc_rumors=g.social_faction.rumors_for(witness)
    assert any(x['rumor_id']==eid for x in npc_rumors)
    assert g.social_faction.rumors_for('actor:player')==[]
    assert g.dynamic_events._state()['events'][eid]['consequence_state']['rumor_seeded'] is True

def test_consequence_projection_survives_save_load():
    g=make_game(); eid=seed_event(g,'equipment_failure','minor'); activate(g,eid)
    before=g.dynamic_events.perceived_consequences_at(g.location(),weather_id='WX_CLEAR',detail=True)
    g.save()
    loaded=FullVersionGame(core_root=ROOT,saves_root=g.saves_root,master_seed=20260913)
    after=loaded.dynamic_events.perceived_consequences_at(loaded.location(),weather_id='WX_CLEAR',detail=True)
    assert before==after
    assert loaded.dynamic_events._state()['events'][eid]['consequence_state']['phase']=='ACTIVE'
