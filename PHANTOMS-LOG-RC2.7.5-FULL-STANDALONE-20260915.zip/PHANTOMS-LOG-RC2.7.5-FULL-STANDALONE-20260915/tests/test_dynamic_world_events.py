from pathlib import Path
import tempfile
from playable.game import FullVersionGame
from runtime.full_version.dynamic_world_events import DynamicWorldEventRuntime

def game():
    td=tempfile.TemporaryDirectory(); core=Path(__file__).resolve().parents[1]
    g=FullVersionGame(core_root=core,saves_root=Path(td.name),start_class="OPERATOR")
    g.complete_character(g.creation_template()); g._tmp=td
    return g,DynamicWorldEventRuntime(g.catalog,g.session)

def test_rare_never_eligible_without_explicit_anchors():
    g,r=game()
    for loc in [x["location_id"] for x in g.catalog.world["locations"]]:
        assert all(e["id"]!="rare_world_encounter" for e in r.eligible(loc))

def test_rare_requires_both_explicit_gates():
    g,r=game(); loc=g.catalog.world["locations"][0]["location_id"]
    assert all(e["id"]!="rare_world_encounter" for e in r.eligible(loc,["rare_gate"]))
    assert any(e["id"]=="rare_world_encounter" for e in r.eligible(loc,["rare_gate","causal_anchor"]))

def test_events_are_not_player_targeted():
    g,r=game(); g.npc_routines.wait(7200)
    made=r.tick(pressures_by_location={x["location_id"]:["supply_pressure"] for x in g.catalog.world["locations"]})
    assert all(x["player_targeted"] is False for x in made)

def test_tick_is_time_guarded():
    g,r=game(); assert r.tick()==[]
    assert r.tick()==[]

def test_run_isolation():
    g1,r1=game(); g2,r2=game()
    assert r1._state()["run_uuid"]!=r2._state()["run_uuid"]

def test_director_forbidden_contract():
    g,r=game()
    f=set(r.t["forbidden"])
    assert "SPAWN_BECAUSE_STORY_NEEDS_DRAMA" in f
    assert "TARGET_PLAYER_BY_DEFAULT" in f

def test_all_world_categories_have_context_tags():
    g,r=game()
    cats={x["primary_category"] for x in g.catalog.world["locations"]}
    assert cats==set(r.t["category_tags"])
