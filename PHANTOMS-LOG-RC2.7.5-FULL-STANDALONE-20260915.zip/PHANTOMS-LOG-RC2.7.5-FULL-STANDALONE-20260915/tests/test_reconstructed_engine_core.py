from pathlib import Path
import unittest

from runtime.core.chronology import CANONICAL_EPOCHS, CRY_MIN, CRY_T0, validate_canonical_epochs
from runtime.core.contracts import CORE_LAWS, CoreLaw, assert_no_legacy_run_contamination
from runtime.core.content_contracts import MissionContract, MissionPersistence, SolutionFamily
from runtime.core.world_sim import PHASES, RelevanceTier, SimulationCadence, SimulationEvent, WorldSimOrchestrator
from runtime.stage3a.integration import RuntimeAuthorityBridge, RuntimeDelta
from runtime.stage3a.kernel import Authority, CommitKernel, Domain, StateStore


class ReconstructedEngineCoreTests(unittest.TestCase):
    def make_orchestrator(self, producers=None, cadence=None):
        kernel = CommitKernel(StateStore(), world_seed=314159)
        bridge = RuntimeAuthorityBridge(kernel)
        orch = WorldSimOrchestrator(
            bridge,
            cadence=cadence or SimulationCadence(1, 5, 20),
            producers=producers,
        )
        return kernel, bridge, orch

    def test_core_laws_present(self):
        self.assertIn(CoreLaw.WORLD_BEFORE_STORY, CORE_LAWS)
        self.assertIn(CoreLaw.RANDOMIZE_UNKNOWN_SIMULATE_KNOWN, CORE_LAWS)
        self.assertIn(CoreLaw.PLAYER_RUN_STATE_EXTERNAL_TO_STATIC_CORE, CORE_LAWS)

    def test_stage2_axis_and_epochs_validate(self):
        validate_canonical_epochs()
        self.assertEqual(CRY_MIN, 0)
        self.assertEqual(CRY_T0, 10_000)
        self.assertEqual([e.epoch_id for e in CANONICAL_EPOCHS], ["E0", "E1", "E2", "E3", "E4", "E5"])

    def test_fixed_p0_p9_order_and_single_commit(self):
        calls = []
        def producer(ctx):
            calls.append(ctx.phase)
            return ()
        producers = {p: producer for p in PHASES}
        kernel, _, orch = self.make_orchestrator(producers)
        result = orch.run(SimulationEvent("evt-1", "scheduled_world_tick", "seed:evt-1", RelevanceTier.HOT, 1))
        self.assertTrue(result.processed)
        self.assertEqual(result.phase_order, PHASES)
        self.assertEqual(calls, list(PHASES))
        self.assertEqual(kernel.store.revision, 0)
        self.assertIsNone(result.commit)
        self.assertNotIn("WORLD_TRUTH", result.presentation)

    def test_phase_delta_commits_through_stage3a(self):
        def p4(ctx):
            return (RuntimeDelta(
                domain="RUNTIME_STATE",
                key="synthetic.world_tick",
                value=ctx.event.tick,
                producer="RULE_KERNEL",
                cause=ctx.event.cause,
            ),)
        kernel, _, orch = self.make_orchestrator({"P4": p4})
        result = orch.run(
            SimulationEvent("evt-2", "synthetic_timer", "seed:evt-2", RelevanceTier.HOT, 2),
            narration_runtime_keys=("synthetic.world_tick",),
        )
        self.assertTrue(result.processed)
        self.assertEqual(kernel.read(Authority.RULE_KERNEL, Domain.RUNTIME_STATE, "synthetic.world_tick"), 2)
        self.assertEqual(result.presentation["PRESENTATION_RUNTIME"]["synthetic.world_tick"], 2)

    def test_multirate_skip(self):
        _, _, orch = self.make_orchestrator(cadence=SimulationCadence(1, 5, 20))
        warm = orch.run(SimulationEvent("evt-w", "maintenance", "seed:w", RelevanceTier.WARM, 3))
        cold = orch.run(SimulationEvent("evt-c", "slow_trend", "seed:c", RelevanceTier.COLD, 19))
        self.assertFalse(warm.processed)
        self.assertFalse(cold.processed)

    def test_player_presence_is_not_cause(self):
        _, _, orch = self.make_orchestrator()
        with self.assertRaisesRegex(ValueError, "PLAYER_PRESENCE_NOT_VALID_WORLD_CAUSE"):
            orch.run(SimulationEvent("evt-p", "PLAYER_PRESENCE", "seed:p", RelevanceTier.HOT, 1))

    def test_mission_contract_has_real_paths(self):
        m = MissionContract(
            "synthetic-mission",
            MissionPersistence.RANDOM_EPHEMERAL,
            (SolutionFamily.DIRECT, SolutionFamily.STEALTH, SolutionFamily.TECHNICAL),
        )
        m.validate()

    def test_static_core_has_no_known_legacy_run_state(self):
        root = Path(__file__).resolve().parents[1] / "runtime" / "core"
        historical_run_markers = (
            "N7-NULL-1846", "BOT-M12-4471", "CURRENT_M12", "CURRENT_JAX",
            "CURRENT_EQUIPMENT_SUMMARY", "CP-L5-001", "credits: 132", "credits: 141",
        )
        assert_no_legacy_run_contamination(root.rglob("*"), historical_run_markers)


if __name__ == "__main__":
    unittest.main()
