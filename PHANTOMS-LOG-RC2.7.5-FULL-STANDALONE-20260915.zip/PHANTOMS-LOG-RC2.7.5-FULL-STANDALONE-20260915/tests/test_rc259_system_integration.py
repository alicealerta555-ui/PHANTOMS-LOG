from pathlib import Path
import tempfile
from playable.game import FullVersionGame, FullVersionGameError
from runtime.full_version.bootstrap import PLAYER_ACTOR_INSTANCE_ID
from runtime.stage9.world_time import WorldClock

def make_game():
    td=tempfile.TemporaryDirectory(); core=Path(__file__).resolve().parents[1]
    g=FullVersionGame(core_root=core,saves_root=Path(td.name),start_class="OPERATOR")
    g.complete_character(g.creation_template()); g._tmp=td
    return g

def move_to(g,target):
    # BFS through committed graph.
    from collections import deque
    start=g.location(); q=deque([start]); parent={start:None}
    while q:
        cur=q.popleft()
        if cur==target: break
        for n in g.catalog.location(cur)["connections"]:
            if n not in parent: parent[n]=cur; q.append(n)
    path=[]; cur=target
    while cur!=start: path.append(cur); cur=parent[cur]
    for step in reversed(path):
        r=g.execute(action_type="MOVE",raw_input="go",parameters={"destination_location_id":step})
        assert r.status.value in {"COMMITTED","IDEMPOTENT"}

def first_merchant(g):
    for key in g.session.store.runtime_state:
        if str(key).startswith("actor:npc:"):
            rec=g.session.kernel.read(__import__("runtime.stage3a.kernel",fromlist=["Authority"]).Authority.COMMIT_KERNEL,
                                      __import__("runtime.stage3a.kernel",fromlist=["Domain"]).Domain.RUNTIME_STATE,key)
            if isinstance(rec,dict) and rec.get("role")=="merchant": return key,rec
    raise AssertionError("merchant missing")

def test_world_time_pulse_advances_player_and_npc_needs():
    g=make_game()
    npc=next(x.actor_instance_id for x in g.actor_registry.instances() if x.actor_instance_id.startswith("actor:npc:"))
    p0=g.embodied_needs.actor_packet(PLAYER_ACTOR_INSTANCE_ID)["needs"]["hydration"]["pressure_ppm"]
    n0=g.embodied_needs.actor_packet(npc)["needs"]["hydration"]["pressure_ppm"]
    before=WorldClock(g.session).seconds
    g.npc_routines.wait(3600); g._world_pulse(before,activity="rest")
    assert g.embodied_needs.actor_packet(PLAYER_ACTOR_INSTANCE_ID)["needs"]["hydration"]["pressure_ppm"]>p0
    assert g.embodied_needs.actor_packet(npc)["needs"]["hydration"]["pressure_ppm"]>n0

def test_trade_refusal_hook_is_live():
    g=make_game(); mid,m=first_merchant(g); move_to(g,m["location_ref"])
    for _ in range(6):
        g.social_faction.apply_event(PLAYER_ACTOR_INSTANCE_ID,mid,"ATTACK")
    stock=g.merchant_stock(mid); assert stock
    try:
        g.buy_item(stock[0]["instance_id"],mid)
    except FullVersionGameError as e:
        assert "MERCHANT_REFUSES_TRADE" in str(e)
    else:
        raise AssertionError("hostile merchant should refuse trade")

def test_player_social_ui_hides_raw_scores():
    g=make_game()
    assert "Vertrauen 0" not in g.social_status()
    assert "Stand 0" not in g.faction_status()

def test_npc_household_field_is_household_ref():
    g=make_game()
    npcs=[]
    for inst in g.actor_registry.instances():
        if inst.actor_instance_id.startswith("actor:npc:"):
            rec=g.session.kernel.read(__import__("runtime.stage3a.kernel",fromlist=["Authority"]).Authority.COMMIT_KERNEL,
                                      __import__("runtime.stage3a.kernel",fromlist=["Domain"]).Domain.RUNTIME_STATE,inst.actor_instance_id)
            npcs.append(rec)
    assert all("household_ref" in (n.get("social_profile") or {}) for n in npcs)
