
import json, unittest
from pathlib import Path
from runtime.content_stage23.property import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage23_property_access.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_owner_access(self):
  o=ownership_record("P","a","purchase",1)
  self.assertTrue(access_allowed("a",o,[]))

 def test_key_not_ownership_rule(self):
  self.assertTrue(any("key" in x.lower() and "ownership" in x.lower() for x in D["rules"]))

 def test_permission_access(self):
  p=[{"actor_id":"b","right":"GUEST","active":True}]
  self.assertTrue(access_allowed("b",None,p))

 def test_revoked_permission_denied(self):
  p=[{"actor_id":"b","right":"GUEST","active":False}]
  self.assertFalse(access_allowed("b",None,p))

 def test_trespass_requires_presence(self):
  t=trespass_candidate("P","a",True,False,False,"EV")
  self.assertFalse(t["actionable"])

 def test_trespass_requires_no_permission(self):
  t=trespass_candidate("P","a",True,True,True,"EV")
  self.assertFalse(t["actionable"])

 def test_trespass_actionable(self):
  t=trespass_candidate("P","a",True,False,True,"EV")
  self.assertTrue(t["actionable"])
  self.assertTrue(t["authority_required"])

 def test_transfer_requires_distinct_parties(self):
  self.assertIsNone(transfer_proposal("P","a","a","TRANSFER_GIFT","EV"))

 def test_transfer_authority(self):
  p=transfer_proposal("P","a","b","TRANSFER_SALE","EV",consideration={"CUR_SCRIP":100})
  self.assertTrue(p["authority_required"])
  self.assertEqual(p["from_actor_id"],"a"); self.assertEqual(p["to_actor_id"],"b")

 def test_occupancy_and_revocation_authority(self):
  o=occupancy_candidate("P","a","OCCUPIED","EV")
  r=access_revocation_proposal("P","a","lease ended","EV","contract")
  self.assertTrue(o["authority_required"]); self.assertTrue(r["authority_required"])

if __name__=="__main__": unittest.main()
