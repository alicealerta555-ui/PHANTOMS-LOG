from pathlib import Path
import tempfile
import pytest
from playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, Domain
from runtime.full_version.authored_missions_runtime import AuthoredMissionRuntime, AuthoredMissionRuntimeError
ROOT=Path(__file__).resolve().parents[1]

def game(tmp):
    g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class='OPERATOR',master_seed=20260915)
    g.complete_character(g.creation_template())
    return g

def existing_npc(g):
    for k in g.session.store.runtime_state:
        if str(k).startswith('actor:npc:'):
            r=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,k)
            if isinstance(r,dict): return k,r
    raise AssertionError('npc missing')

def test_catalog_has_24_unlocked_templates():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); r=AuthoredMissionRuntime(g.catalog,g.session)
        assert len(r.templates)==60
        assert all(not x['access']['class_lock'] and not x['access']['profession_lock'] for x in r.templates.values())

def test_materialize_requires_real_source_and_location_and_accepts_normally():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); r=AuthoredMissionRuntime(g.catalog,g.session); npc,nrec=existing_npc(g)
        with pytest.raises(AuthoredMissionRuntimeError,match='SOURCE_NOT_FOUND'): r.materialize('AM_SEARCH_PERSON',source_ref='actor:npc:not-real',location_id=g.location())
        with pytest.raises(AuthoredMissionRuntimeError,match='LOCATION_NOT_FOUND'): r.materialize('AM_SEARCH_PERSON',source_ref=npc,location_id='LOC_NOT_REAL')
        qid,q=r.materialize('AM_SEARCH_PERSON',source_ref=npc,location_id=g.location(),issuer_actor_id=npc)
        assert q['mission_family']=='TRACK_PERSON' and q['state']=='AVAILABLE'
        receipt=g.execute(action_type='QUEST_ACCEPT',raw_input='accept authored mission',target_refs=(qid,))
        assert receipt.status.value=='COMMITTED'
        q2=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
        assert q2['state']=='ACTIVE'

def test_hunting_templates_do_not_require_kill():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); r=AuthoredMissionRuntime(g.catalog,g.session)
        hunting=[x for x in r.templates.values() if x['id'].startswith(('AM_HUNT','AM_ECO'))]
        assert hunting and all('kill_not_required' in x['rules'] for x in hunting)

def test_catalog_loads_all_authored_mission_packs_and_new_families():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); r=AuthoredMissionRuntime(g.catalog,g.session)
        assert len(r.templates)==60
        expected={'DIPLOMACY_MEDIATION','RECRUITMENT_SOCIAL','TRADE_NEGOTIATION','PRODUCTION_WORK','LOGISTICS_SUPPLY','INFRASTRUCTURE_RESPONSE','DISASTER_RESPONSE','RESONANCE_INVESTIGATION'}
        assert expected <= {x['mission_family'] for x in r.templates.values()}
        assert all(not x['access']['class_lock'] and not x['access']['profession_lock'] for x in r.templates.values())

def test_new_authored_family_materializes_and_resolves_without_class_lock():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); r=AuthoredMissionRuntime(g.catalog,g.session); npc,_=existing_npc(g)
        qid,q=r.materialize('AM_DIP_MEDIATE',source_ref=npc,location_id=g.location(),issuer_actor_id=npc)
        assert q['mission_family']=='DIPLOMACY_MEDIATION'
        receipt=g.execute(action_type='QUEST_ACCEPT',raw_input='accept mediation',target_refs=(qid,))
        assert receipt.status.value=='COMMITTED'
        result=g.quest_runtime.resolve_mission_attempt(qid,difficulty=5)
        assert result['outcome'] in {'FULL_SUCCESS','SUCCESS_WITH_COST','PARTIAL_SUCCESS','FAILURE','CRITICAL_FAILURE'}
