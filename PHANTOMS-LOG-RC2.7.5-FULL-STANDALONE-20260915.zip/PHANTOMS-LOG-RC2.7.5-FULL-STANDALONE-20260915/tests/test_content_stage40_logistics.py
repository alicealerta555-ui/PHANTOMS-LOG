
import json, unittest
from pathlib import Path
from runtime.content_stage40.logistics import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage40_logistics.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_warehouse_types(self):
  self.assertGreaterEqual(len(D["warehouse_types"]),4)

 def test_reservation_conserves_stock(self):
  r=reserve_stock(10,15)
  self.assertEqual(r["reserved"],10)
  self.assertEqual(r["remaining"],0)
  self.assertEqual(r["unmet"],5)

 def test_shipment_requires_route(self):
  self.assertIsNone(shipment_candidate("S","A","B","","ITEM",5,1,"EV"))

 def test_shipment_authority(self):
  p=shipment_candidate("S","A","B","R","ITEM",5,1,"EV")
  self.assertTrue(p["authority_required"])

 def test_delivery_conserves_quantity(self):
  d=delivery_projection(10,3)
  self.assertEqual(d["delivered"]+d["lost"],10)
  self.assertEqual(d["state"],"PARTIAL")

 def test_warehouse_capacity(self):
  x=warehouse_store(90,30,100,100)
  self.assertEqual(x["stored"],10)
  self.assertEqual(x["overflow"],20)

 def test_condition_reduces_capacity(self):
  a=warehouse_store(0,100,100,100)["effective_capacity"]
  b=warehouse_store(0,100,100,50)["effective_capacity"]
  self.assertGreater(a,b)

 def test_shortage_no_creation(self):
  self.assertEqual(shortage_level(100,100),0)
  self.assertEqual(shortage_level(100,0),100)

 def test_priority_allocation(self):
  req=[
   {"request_id":"low","quantity":8,"priority_weight":25},
   {"request_id":"high","quantity":8,"priority_weight":100}
  ]
  p=allocation_plan(req,10)
  self.assertEqual(p["allocations"][0]["request_id"],"high")
  self.assertEqual(p["allocations"][0]["allocated"],8)
  self.assertEqual(p["remaining_stock"],0)

 def test_transit_delay(self):
  a=transit_time_minutes(60,10000,0)
  b=transit_time_minutes(60,5000,0)
  self.assertGreater(b,a)

 def test_stock_dimension_rule(self):
  self.assertTrue(any("in-transit stock" in x.lower() for x in D["rules"]))

if __name__=="__main__": unittest.main()
