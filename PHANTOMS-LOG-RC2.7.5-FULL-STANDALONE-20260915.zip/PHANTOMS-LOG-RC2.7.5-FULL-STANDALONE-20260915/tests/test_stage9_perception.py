from __future__ import annotations

import tempfile
import unittest
from dataclasses import asdict
from pathlib import Path
from uuid import uuid4

from phantoms_stage5.auditory import AuditoryLimits
from phantoms_stage5.senses import BoundSense, Expression, SenseProfile
from phantoms_stage5.visual import VisualLimits
from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage3c.isolation import FilesystemRunRepository, RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.perception import (
    PERCEPTION_INPUT_WORLD_KEY,
    PerceptionDetection,
    PerceptionReader,
    Stage9PerceptionError,
)


class Stage9PerceptionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.manager = RunSessionManager(master_seed=20260911)
        self.player_uuid = str(uuid4())
        self.session = self.manager.create_run(player_uuid=self.player_uuid)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(self.player_uuid, self.session.identity.run_uuid, "actor:player")
        self.npc_identity = RuntimeIdentity(self.player_uuid, self.session.identity.run_uuid, "actor:npc")
        self.registry.register(self.identity, actor_definition_id="actor-def:player")
        self.registry.register(self.npc_identity, actor_definition_id="actor-def:npc")
        self.visual_sense = BoundSense(
            lineage_id="lineage:human",
            hook_id="sense:eye",
            modality="visual",
            profile=SenseProfile("profile:eye", "visual", ("constraint:light",)),
            expression=Expression.ACTIVE,
            evidence_refs=("static:sense",),
            condition_refs=(),
        )
        self.visual_limits = VisualLimits("profile:eye", 20.0, 2.0)
        self.reader = PerceptionReader(
            self.session,
            self.registry,
            self.identity,
            sense=self.visual_sense,
            limits=self.visual_limits,
        )
        self.commit_counter = 0

    def _visual_record(self, *, observer: str | None = None, subject: str = "object:door", **condition_overrides):
        conditions = {
            "distance_m": 5.0,
            "incident_illuminance_lux": 10.0,
            "line_of_sight_clear": True,
        }
        conditions.update(condition_overrides)
        return {
            "run_uuid": self.session.identity.run_uuid,
            "observer_actor_instance_id": observer or self.identity.actor_instance_id,
            "subject_ref": subject,
            "channel": "visual",
            "lineage_id": self.visual_sense.lineage_id,
            "hook_id": self.visual_sense.hook_id,
            "conditions": conditions,
        }

    def _commit_inputs(self, entries: dict[str, dict]) -> CommitRecord:
        self.commit_counter += 1
        event_id = f"PERCEPTION:INPUT:{self.commit_counter}"
        result = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id=event_id,
            cause="TEST_COMMITTED_PERCEPTION_INPUT",
            deltas=(Delta(
                domain=Domain.WORLD_TRUTH,
                key=PERCEPTION_INPUT_WORLD_KEY,
                value=entries,
                writer=Authority.RULE_KERNEL,
                cause="TEST_COMMITTED_PERCEPTION_INPUT",
                source_event_id=event_id,
            ),),
        ))
        self.assertIsInstance(result, CommitRecord)
        return result

    def test_missing_committed_input_is_unresolved_without_mutation(self):
        revision = self.session.store.revision
        state_hash = self.session.store.state_hash()
        result = self.reader.project(perception_input_id="input:missing", subject_ref="object:door")
        self.assertEqual(result.detection, PerceptionDetection.UNRESOLVED)
        self.assertEqual(result.reasons, ("PERCEPTION_INPUT_MISSING",))
        self.assertEqual(self.session.store.revision, revision)
        self.assertEqual(self.session.store.state_hash(), state_hash)
        self.assertEqual(self.session.store.actor_knowledge, {})
        self.assertEqual(self.session.store.player_knowledge, {})

    def test_visual_projection_uses_committed_conditions_and_is_read_only(self):
        self._commit_inputs({"input:door": self._visual_record()})
        revision = self.session.store.revision
        state_hash = self.session.store.state_hash()
        result = self.reader.project(perception_input_id="input:door", subject_ref="object:door")
        self.assertEqual(result.detection, PerceptionDetection.DETECTED)
        self.assertEqual(result.channel, "visual")
        self.assertEqual(result.observer_actor_instance_id, "actor:player")
        self.assertEqual(result.subject_ref, "object:door")
        self.assertEqual(result.state_revision, revision)
        self.assertEqual(result.world_time, 0)
        self.assertEqual(self.session.store.revision, revision)
        self.assertEqual(self.session.store.state_hash(), state_hash)
        self.assertEqual(self.session.store.actor_knowledge, {})
        self.assertEqual(self.session.store.player_knowledge, {})

    def test_occluded_committed_input_is_not_detected(self):
        self._commit_inputs({"input:door": self._visual_record(line_of_sight_clear=False)})
        result = self.reader.project(perception_input_id="input:door", subject_ref="object:door")
        self.assertEqual(result.detection, PerceptionDetection.NOT_DETECTED)
        self.assertIn("OCCLUDED", result.reasons)

    def test_other_registered_observer_record_is_not_visible(self):
        self._commit_inputs({"input:npc": self._visual_record(observer=self.npc_identity.actor_instance_id)})
        before = self.session.store.state_hash()
        with self.assertRaisesRegex(Stage9PerceptionError, "PERCEPTION_OBSERVER_MISMATCH"):
            self.reader.project(perception_input_id="input:npc", subject_ref="object:door")
        self.assertEqual(self.session.store.state_hash(), before)

    def test_subject_channel_lineage_and_hook_binding_fail_closed(self):
        cases = [
            ({"subject_ref": "object:other"}, "PERCEPTION_SUBJECT_MISMATCH"),
            ({"channel": "auditory"}, "PERCEPTION_CHANNEL_MISMATCH"),
            ({"lineage_id": "lineage:other"}, "PERCEPTION_LINEAGE_MISMATCH"),
            ({"hook_id": "sense:other"}, "PERCEPTION_HOOK_MISMATCH"),
        ]
        for index, (changes, code) in enumerate(cases):
            with self.subTest(code=code):
                record = self._visual_record()
                record.update(changes)
                self._commit_inputs({f"input:{index}": record})
                subject = "object:door" if code != "PERCEPTION_SUBJECT_MISMATCH" else "object:door"
                with self.assertRaisesRegex(Stage9PerceptionError, code):
                    self.reader.project(perception_input_id=f"input:{index}", subject_ref=subject)

    def test_record_and_conditions_schema_reject_hidden_payload(self):
        record = self._visual_record()
        record["secret_world_truth"] = "omega"
        self._commit_inputs({"input:secret": record})
        with self.assertRaisesRegex(Stage9PerceptionError, "RECORD_SCHEMA_INVALID"):
            self.reader.project(perception_input_id="input:secret", subject_ref="object:door")

        record = self._visual_record()
        record["conditions"] = dict(record["conditions"], hidden_identity="enemy:boss")
        self._commit_inputs({"input:conditions": record})
        with self.assertRaisesRegex(Stage9PerceptionError, "CONDITIONS_SCHEMA_INVALID"):
            self.reader.project(perception_input_id="input:conditions", subject_ref="object:door")

    def test_observation_never_exposes_raw_conditions_or_world_truth(self):
        self._commit_inputs({"input:door": self._visual_record()})
        result = self.reader.project(perception_input_id="input:door", subject_ref="object:door")
        exposed = asdict(result)
        self.assertNotIn("conditions", exposed)
        self.assertNotIn("world_truth", exposed)
        self.assertEqual(
            set(exposed),
            {
                "run_uuid", "observer_actor_instance_id", "perception_input_id", "subject_ref",
                "channel", "source_hook_id", "detection", "reasons", "state_revision", "world_time",
            },
        )

    def test_unregistered_actor_cannot_bind_perception_reader(self):
        ghost = RuntimeIdentity(self.player_uuid, self.session.identity.run_uuid, "actor:ghost")
        with self.assertRaises(Stage9PerceptionError) as ctx:
            PerceptionReader(
                self.session,
                self.registry,
                ghost,
                sense=self.visual_sense,
                limits=self.visual_limits,
            )
        self.assertIn("ACTOR_NOT_REGISTERED_IN_RUN", str(ctx.exception))

    def test_run_isolation_and_wrong_run_record_rejected(self):
        other = self.manager.create_run(player_uuid=self.player_uuid)
        other_registry = RunActorRegistry(other)
        other_identity = RuntimeIdentity(self.player_uuid, other.identity.run_uuid, "actor:player")
        other_registry.register(other_identity, actor_definition_id="actor-def:player")
        other_reader = PerceptionReader(
            other,
            other_registry,
            other_identity,
            sense=self.visual_sense,
            limits=self.visual_limits,
        )
        self._commit_inputs({"input:door": self._visual_record()})
        self.assertEqual(
            other_reader.project(perception_input_id="input:door", subject_ref="object:door").detection,
            PerceptionDetection.UNRESOLVED,
        )
        record = self._visual_record()
        record["run_uuid"] = other.identity.run_uuid
        self._commit_inputs({"input:wrong-run": record})
        with self.assertRaisesRegex(Stage9PerceptionError, "PERCEPTION_RUN_MISMATCH"):
            self.reader.project(perception_input_id="input:wrong-run", subject_ref="object:door")

    def test_auditory_channel_is_distinct_and_read_only(self):
        sense = BoundSense(
            lineage_id="lineage:human",
            hook_id="sense:ear",
            modality="auditory",
            profile=SenseProfile("profile:ear", "auditory", ("constraint:sound",)),
            expression=Expression.ACTIVE,
            evidence_refs=("static:sense",),
            condition_refs=(),
        )
        limits = AuditoryLimits("profile:ear", 30.0, 20.0, 3.0)
        reader = PerceptionReader(self.session, self.registry, self.identity, sense=sense, limits=limits)
        record = {
            "run_uuid": self.session.identity.run_uuid,
            "observer_actor_instance_id": self.identity.actor_instance_id,
            "subject_ref": "event:noise",
            "channel": "auditory",
            "lineage_id": sense.lineage_id,
            "hook_id": sense.hook_id,
            "conditions": {
                "distance_m": 8.0,
                "received_signal_db_spl": 45.0,
                "received_noise_db_spl": 30.0,
                "acoustic_path_available": True,
            },
        }
        self._commit_inputs({"input:noise": record})
        before = self.session.store.state_hash()
        result = reader.project(perception_input_id="input:noise", subject_ref="event:noise")
        self.assertEqual(result.channel, "auditory")
        self.assertEqual(result.detection, PerceptionDetection.DETECTED)
        self.assertEqual(self.session.store.state_hash(), before)
        self.assertEqual(self.session.store.actor_knowledge, {})

    def test_save_load_preserves_input_but_rehydration_creates_no_perception_or_knowledge(self):
        self._commit_inputs({"input:door": self._visual_record()})
        original = self.reader.project(perception_input_id="input:door", subject_ref="object:door")
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(Path(td))
            repo.save(self.session)
            identity = self.session.identity
            self.manager.close_run(player_uuid=identity.player_uuid, run_uuid=identity.run_uuid)
            loaded = repo.load_session(self.manager, identity)
            self.assertEqual(loaded.store.actor_knowledge, {})
            self.assertEqual(loaded.store.player_knowledge, {})
            loaded_registry = RunActorRegistry(loaded)
            loaded_reader = PerceptionReader(
                loaded,
                loaded_registry,
                self.identity,
                sense=self.visual_sense,
                limits=self.visual_limits,
            )
            revision = loaded.store.revision
            state_hash = loaded.store.state_hash()
            again = loaded_reader.project(perception_input_id="input:door", subject_ref="object:door")
            self.assertEqual(again.detection, original.detection)
            self.assertEqual(again.reasons, original.reasons)
            self.assertEqual(loaded.store.revision, revision)
            self.assertEqual(loaded.store.state_hash(), state_hash)

    def test_invalid_or_unsupported_sensor_binding_fails_closed(self):
        wrong_sense = BoundSense(
            lineage_id="lineage:human",
            hook_id="sense:wrong",
            modality="auditory",
            profile=SenseProfile("profile:wrong", "auditory", ("constraint:x",)),
            expression=Expression.ACTIVE,
            evidence_refs=("static:sense",),
            condition_refs=(),
        )
        with self.assertRaisesRegex(Stage9PerceptionError, "SENSE_CHANNEL_MISMATCH"):
            PerceptionReader(
                self.session,
                self.registry,
                self.identity,
                sense=wrong_sense,
                limits=self.visual_limits,
            )
        with self.assertRaisesRegex(Stage9PerceptionError, "CHANNEL_UNSUPPORTED"):
            PerceptionReader(
                self.session,
                self.registry,
                self.identity,
                sense=self.visual_sense,
                limits=object(),
            )


if __name__ == "__main__":
    unittest.main()
