from __future__ import annotations

import unittest
from uuid import uuid4

from runtime.stage3b.pipeline import ActionResult, ActionStatus
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actor_context import ActorContextProjector
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.context import RuntimeContext
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.narrative import DeterministicTurnRenderer, NarrativeProjector, TurnResultBuilder
from runtime.stage9.playable_runtime import RuntimeLifecycle, RuntimeTurnReceipt
from runtime.stage9.transaction import TurnTransaction, TurnTransactionStatus


class Stage9NarrativeTests(unittest.TestCase):
    def setUp(self):
        m = RunSessionManager(master_seed=1)
        p = str(uuid4())
        self.s = m.create_run(player_uuid=p)
        self.r = RunActorRegistry(self.s)
        self.i = RuntimeIdentity(p, self.s.identity.run_uuid, "actor:player")
        self.r.register(self.i, actor_definition_id="player")
        self.ctx = RuntimeContext.capture(self.s, self.r, self.i, turn_id="turn:n1", action_window_id="window:n1")
        tx = TurnTransaction(self.ctx)
        # Construct a minimal immutable transaction snapshot without using gameplay state.
        self.tx_snapshot = tx.snapshot()
        result = ActionResult(status=ActionStatus.RESOLVED_NO_CHANGE, event_id="NARR:E", rule_id="LOOK", outcome_id="LOOK_OK")
        self.receipt = RuntimeTurnReceipt(
            runtime_context=self.ctx, action_result=result,
            revision_before=self.s.store.revision, revision_after=self.s.store.revision,
            lifecycle_trace=(RuntimeLifecycle.READY, RuntimeLifecycle.TURN_COMPLETE, RuntimeLifecycle.READY),
            transaction=self.tx_snapshot,
        )
        self.actor_context = ActorContextProjector(self.s, self.r, self.i).project()

    def test_projection_and_renderer_are_deterministic(self):
        p = NarrativeProjector().project(self.receipt, self.actor_context)
        self.assertEqual(p, NarrativeProjector().project(self.receipt, self.actor_context))
        text = DeterministicTurnRenderer().render(p)
        self.assertEqual(text, DeterministicTurnRenderer().render(p))
        self.assertIn("Outcome: LOOK_OK", text)

    def test_projection_does_not_include_hidden_world_truth(self):
        self.s.store.world_truth["secret:gm"] = "HIDDEN"  # test-only corruption after context capture
        p = NarrativeProjector().project(self.receipt, self.actor_context)
        self.assertNotIn("HIDDEN", DeterministicTurnRenderer().render(p))

    def test_turn_result_is_projection_not_state_container(self):
        p = NarrativeProjector().project(self.receipt, self.actor_context)
        result = TurnResultBuilder().build(self.receipt, self.actor_context, p)
        self.assertEqual(result.run_uuid, self.s.identity.run_uuid)
        self.assertFalse(hasattr(result, "store"))
        self.assertFalse(hasattr(result, "commit_kernel"))


if __name__ == "__main__": unittest.main()
