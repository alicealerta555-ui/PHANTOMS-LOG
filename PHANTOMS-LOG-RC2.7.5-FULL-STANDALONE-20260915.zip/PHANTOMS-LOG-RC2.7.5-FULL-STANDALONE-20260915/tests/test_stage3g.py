import json
import tempfile
import unittest
from pathlib import Path
from uuid import UUID

from validation.stage3g.harness import (
    REQUIRED_CHAIN_INVARIANTS,
    REQUIRED_INVARIANTS,
    REQUIRED_PAIR_INVARIANTS,
    CaseResult,
    Invariant,
    Stage3GClosureHarness,
    fixture_uuid,
)


class Stage3GTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report = Stage3GClosureHarness().run()

    def test_full_closure_report_passes(self):
        self.assertTrue(self.report.passed)

    def test_all_required_invariants_are_covered(self):
        self.assertFalse(self.report.missing_invariants)
        self.assertEqual(set(self.report.covered_invariants), {i.value for i in REQUIRED_INVARIANTS})

    def test_minimal_pair_coverage_is_complete(self):
        self.assertFalse(self.report.missing_pair_coverage)
        self.assertTrue({i.value for i in REQUIRED_PAIR_INVARIANTS}.issubset(set(self.report.pair_coverage)))

    def test_multiturn_coverage_is_complete(self):
        self.assertFalse(self.report.missing_chain_coverage)
        self.assertTrue({i.value for i in REQUIRED_CHAIN_INVARIANTS}.issubset(set(self.report.chain_coverage)))

    def test_expected_case_matrix_is_present(self):
        self.assertEqual(len(self.report.cases), 14)
        self.assertEqual(sum(c.family == "MINIMAL_PAIR" for c in self.report.cases), 9)
        self.assertEqual(sum(c.family == "MULTI_TURN" for c in self.report.cases), 5)

    def test_every_case_passes(self):
        failed = [c for c in self.report.cases if not c.passed]
        self.assertEqual(failed, [])

    def test_no_reality_write_has_dedicated_case(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-01-NO-REALITY-WRITE")
        self.assertTrue(case.evidence["query_state_unchanged"])

    def test_anti_suggestion_pair_resolves_identically(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-02-ANTI-SUGGESTION")
        self.assertTrue(case.evidence["pair_equal"])
        self.assertTrue(case.evidence["query_no_commit"])

    def test_false_veto_case_keeps_structured_outcome(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-04-FALSE-VETO")
        self.assertTrue(case.evidence["same_outcome"])

    def test_hard_veto_case_is_atomic(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-05-TENFOLD-ATOMICITY")
        self.assertTrue(case.evidence["invalid_rejected"])
        self.assertTrue(case.evidence["atomic"])

    def test_truth_knowledge_chain_survives_save_reload(self):
        case = next(c for c in self.report.cases if c.case_id == "CH-01-TRUTH-KNOWLEDGE-SAVE")
        self.assertTrue(case.evidence["truth_stable"])
        self.assertTrue(case.evidence["causal_knowledge"])
        self.assertTrue(case.evidence["save_reload"])

    def test_run_isolation_chain_keeps_ledgers_separate(self):
        case = next(c for c in self.report.cases if c.case_id == "CH-04-RUN-ISOLATION-RELOAD")
        self.assertTrue(case.evidence["ledger_isolated"])

    def test_fixture_uuids_are_deterministic_anonymous_canonical(self):
        a = fixture_uuid("x")
        b = fixture_uuid("x")
        c = fixture_uuid("y")
        self.assertEqual(a, b)
        self.assertNotEqual(a, c)
        self.assertEqual(str(UUID(a)), a)

    def test_report_serializes_to_json(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "report.json"
            self.report.write_json(path)
            raw = json.loads(path.read_text())
        self.assertTrue(raw["passed"])
        self.assertEqual(len(raw["cases"]), 14)

    def test_case_wrapper_collects_failure_without_hiding_it(self):
        def broken():
            raise RuntimeError("synthetic")
        result = Stage3GClosureHarness._case("X", "MINIMAL_PAIR", (Invariant.NO_REALITY_WRITE,), broken)
        self.assertIsInstance(result, CaseResult)
        self.assertFalse(result.passed)
        self.assertIn("RuntimeError:synthetic", result.failure)


if __name__ == "__main__":
    unittest.main()
