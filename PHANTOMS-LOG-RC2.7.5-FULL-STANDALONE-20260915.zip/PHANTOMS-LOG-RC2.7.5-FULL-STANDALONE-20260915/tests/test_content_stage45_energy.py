
import json, unittest
from pathlib import Path
from runtime.content_stage45.energy import *
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage45_energy_grid.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_generation_types(self):
  self.assertGreaterEqual(len(D["generation_types"]),5)

 def test_generation_condition(self):
  a=generation_output(100,100,100)
  b=generation_output(100,50,100)
  self.assertGreater(a,b)

 def test_fuel_generation_requires_fuel(self):
  self.assertIsNone(fuel_generation_candidate("G",50,100,0,1,"EV"))

 def test_fuel_conservation(self):
  p=fuel_generation_candidate("G",50,100,20,0.5,"EV")
  self.assertLessEqual(p["fuel_consumed"],20)
  self.assertTrue(p["authority_required"])

 def test_storage_charge_bounded(self):
  x=storage_charge(90,50,100,20)
  self.assertEqual(x["stored"],100)
  self.assertEqual(x["accepted"],10)

 def test_storage_discharge_bounded(self):
  x=storage_discharge(100,80,25)
  self.assertEqual(x["delivered"],25)
  self.assertEqual(x["remaining"],75)

 def test_grid_loss_conservation(self):
  x=grid_delivery(100,100,100,100,1000)
  self.assertEqual(x["sent"],x["delivered"]+x["loss"])

 def test_grid_capacity_limits_delivery(self):
  self.assertEqual(grid_delivery(100,100,40,100,0)["delivered"],40)

 def test_load_shedding_priority(self):
  req=[{"consumer_id":"low","demand":50,"priority_weight":25},{"consumer_id":"critical","demand":50,"priority_weight":100}]
  x=load_shedding(req,60)
  self.assertEqual(x["allocations"][0]["consumer_id"],"critical")
  self.assertEqual(x["allocations"][0]["served"],50)

 def test_network_states(self):
  self.assertEqual(network_state(100,0),"OPERATIONAL")
  self.assertEqual(network_state(50,0),"DEGRADED")
  self.assertEqual(network_state(100,12000),"OVERLOADED")
  self.assertEqual(network_state(0,0),"DESTROYED")

 def test_outage_authority(self):
  p=outage_candidate("O",["N1"],"LINE_FAIL",1,"EV")
  self.assertTrue(p["authority_required"])

if __name__=="__main__": unittest.main()
