import unittest
from dataclasses import fields, replace

from runtime.stage4b import (
    EnvironmentalEnvelope, GenelineRecord, HybridizationProfile, KnownBiologicalConstraint,
    LineageProvenance, MetabolismProfile, MorphologyProfile, OriginPackageLink,
    RegenerationProfile, SensorCapabilityHook, StabilityProfile, STAGE5_DETAIL_FIELDS,
    STAGE6_DETAIL_FIELDS,
)
from runtime.stage4c import (
    CANONICAL_ORIGIN_PACKAGES, FunctionalContribution, FunctionalDomain, FunctionalTradeoff,
    OriginFamily, OriginPackage, OriginPackageProvenance, OriginPackageRegistry,
    bind_origin_packages, build_canonical_origin_registry, build_origin_design_space, validate_origin_bound_geneline,
    validate_origin_package,
)


def lineage(phase="B3", epoch="E3"):
    return GenelineRecord(
        lineage_id="TEST_4C_LINEAGE",
        display_name="Stage 4C synthetic fixture",
        origin_packages=OriginPackageLink(),
        morphology=MorphologyProfile(("bilateral",), ("terrestrial",), ("fixture",)),
        metabolism=MetabolismProfile(("heterotrophic",), energetic_cost_tags=("finite_energy",)),
        environment=EnvironmentalEnvelope(("temperate",)),
        regeneration=RegenerationProfile("NONE"),
        sensor_hooks=(SensorCapabilityHook("HOOK", "thermal", ("hook_only",)),),
        stability=StabilityProfile(),
        hybridization=HybridizationProfile(("SRC_A", "SRC_B"), 2),
        known_constraints=(KnownBiologicalConstraint("C1", "fixture", "Finite resources."),),
        provenance=LineageProvenance(phase, epoch, ("STAGE4C_TEST",)),
    )


def simple_package(**changes):
    p = OriginPackage(
        package_id="ORG_TEST",
        family=OriginFamily.MAMMALIAN,
        display_name="Test package",
        source_scope="Synthetic test source scope.",
        earliest_phase_id="B1",
        contributions=(FunctionalContribution("CAP", FunctionalDomain.METABOLISM, ("capability",), ("COST",), "Capability."),),
        tradeoffs=(FunctionalTradeoff("COST", FunctionalDomain.METABOLISM, ("finite_cost",), "Cost."),),
        sensor_modalities=("thermal",),
        provenance=OriginPackageProvenance(("TEST",)),
    )
    return replace(p, **changes)


class Stage4COriginPackageTests(unittest.TestCase):
    def test_canonical_registry_has_eight_families(self):
        reg = build_canonical_origin_registry()
        self.assertEqual(len(reg), 8)
        self.assertEqual({p.family for p in reg.packages()}, set(OriginFamily))

    def test_all_canonical_packages_validate(self):
        for package in CANONICAL_ORIGIN_PACKAGES:
            validate_origin_package(package)

    def test_every_capability_has_tradeoff(self):
        for package in CANONICAL_ORIGIN_PACKAGES:
            for contribution in package.contributions:
                self.assertTrue(contribution.required_tradeoff_refs)

    def test_unused_tradeoff_rejected(self):
        p = simple_package(tradeoffs=simple_package().tradeoffs + (FunctionalTradeoff("UNUSED", FunctionalDomain.STRUCTURE, ("x",), "Unused."),))
        with self.assertRaisesRegex(ValueError, "UNUSED_TRADEOFF"):
            validate_origin_package(p)

    def test_capability_without_tradeoff_rejected(self):
        c = replace(simple_package().contributions[0], required_tradeoff_refs=())
        with self.assertRaisesRegex(ValueError, "CAPABILITY_WITHOUT_TRADEOFF"):
            validate_origin_package(simple_package(contributions=(c,)))

    def test_unknown_tradeoff_reference_rejected(self):
        c = replace(simple_package().contributions[0], required_tradeoff_refs=("MISSING",))
        with self.assertRaisesRegex(ValueError, "UNKNOWN_TRADEOFF_REFERENCE"):
            validate_origin_package(simple_package(contributions=(c,)))

    def test_genetic_personality_tag_rejected(self):
        c = replace(simple_package().contributions[0], capability_tags=("personality:obedient",))
        with self.assertRaisesRegex(ValueError, "GENETIC_DETERMINISM"):
            validate_origin_package(simple_package(contributions=(c,)))

    def test_stage5_detail_tag_rejected(self):
        c = replace(simple_package().contributions[0], capability_tags=("wavelength_response:500nm",))
        with self.assertRaisesRegex(ValueError, "LATER_STAGE_DETAIL_FORBIDDEN"):
            validate_origin_package(simple_package(contributions=(c,)))

    def test_stage6_detail_tag_rejected(self):
        t = replace(simple_package().tradeoffs[0], constraint_tags=("alleles:A/B",))
        with self.assertRaisesRegex(ValueError, "LATER_STAGE_DETAIL_FORBIDDEN"):
            validate_origin_package(simple_package(tradeoffs=(t,)))

    def test_schema_has_no_stage5_or_stage6_fields(self):
        names = {f.name for f in fields(OriginPackage)}
        self.assertFalse(names.intersection(STAGE5_DETAIL_FIELDS))
        self.assertFalse(names.intersection(STAGE6_DETAIL_FIELDS))

    def test_world_truth_provenance_required(self):
        with self.assertRaisesRegex(ValueError, "PROVENANCE_MUST_BE_WORLD_TRUTH"):
            validate_origin_package(simple_package(provenance=OriginPackageProvenance(("TEST",), "PUBLIC_CANON")))

    def test_registry_duplicate_rejected(self):
        reg = OriginPackageRegistry(); reg.register(simple_package())
        with self.assertRaisesRegex(ValueError, "DUPLICATE_ID"):
            reg.register(simple_package())

    def test_unknown_package_lookup_fails_closed(self):
        with self.assertRaisesRegex(KeyError, "ORIGIN_PACKAGE_NOT_FOUND"):
            OriginPackageRegistry().get("MISSING")

    def test_binding_resolves_4b_link(self):
        reg = build_canonical_origin_registry()
        bound = bind_origin_packages(lineage(), ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL"), reg)
        self.assertEqual(bound.origin_packages.status.value, "RESOLVED")
        validate_origin_bound_geneline(bound, reg)

    def test_binding_empty_rejected(self):
        with self.assertRaisesRegex(ValueError, "BINDING_EMPTY"):
            bind_origin_packages(lineage(), (), build_canonical_origin_registry())

    def test_binding_duplicate_ref_rejected(self):
        ref = "ORG_MAMMALIAN_HOMEOSTASIS"
        with self.assertRaisesRegex(ValueError, "DUPLICATE_ORIGIN_PACKAGE_REF"):
            bind_origin_packages(lineage(), (ref, ref), build_canonical_origin_registry())

    def test_binding_unknown_ref_rejected(self):
        with self.assertRaisesRegex(KeyError, "ORIGIN_PACKAGE_NOT_FOUND"):
            bind_origin_packages(lineage(), ("MISSING",), build_canonical_origin_registry())

    def test_package_cannot_precede_its_available_phase(self):
        # Avian package is a B1+ engineering source; B0 lineage provenance cannot use it.
        with self.assertRaisesRegex(ValueError, "NOT_AVAILABLE_AT_LINEAGE_PHASE"):
            bind_origin_packages(lineage("B0", "E0"), ("ORG_AVIAN_RESPIRATORY_STRUCTURAL",), build_canonical_origin_registry())

    def test_b0_package_can_bind_to_b0(self):
        bound = bind_origin_packages(lineage("B0", "E0"), ("ORG_SYNTHETIC_BIOLOGY_PLATFORM",), build_canonical_origin_registry())
        self.assertEqual(bound.origin_packages.package_refs, ("ORG_SYNTHETIC_BIOLOGY_PLATFORM",))

    def test_linking_package_does_not_auto_copy_all_traits(self):
        bound = bind_origin_packages(lineage(), ("ORG_AVIAN_RESPIRATORY_STRUCTURAL",), build_canonical_origin_registry())
        self.assertEqual(bound.morphology.body_plan_tags, ("bilateral",))
        self.assertNotIn("aerial_locomotion_hook", bound.morphology.locomotion_hooks)

    def test_registry_digest_order_independent(self):
        packages = list(CANONICAL_ORIGIN_PACKAGES)
        a = OriginPackageRegistry(); b = OriginPackageRegistry()
        for p in packages: a.register(p)
        for p in reversed(packages): b.register(p)
        self.assertEqual(a.canonical_digest(), b.canonical_digest())

    def test_package_ids_unique(self):
        ids = [p.package_id for p in CANONICAL_ORIGIN_PACKAGES]
        self.assertEqual(len(ids), len(set(ids)))


    def test_binding_order_is_canonical_and_has_no_semantic_effect(self):
        reg = build_canonical_origin_registry()
        refs = ("ORG_REPTILIAN_WATER_THERMAL", "ORG_MAMMALIAN_HOMEOSTASIS")
        a = bind_origin_packages(lineage(), refs, reg)
        b = bind_origin_packages(lineage(), tuple(reversed(refs)), reg)
        self.assertEqual(a.origin_packages.package_refs, b.origin_packages.package_refs)

    def test_all_eight_sources_can_coexist_in_late_design_space(self):
        reg = build_canonical_origin_registry()
        late = lineage("B6", "E5")
        bound = bind_origin_packages(late, reg.ids(), reg)
        self.assertEqual(len(bound.origin_packages.package_refs), 8)
        space = build_origin_design_space(bound, reg)
        self.assertEqual(space.package_refs, reg.ids())

    def test_design_space_preserves_all_candidates_and_source_attribution(self):
        reg = build_canonical_origin_registry()
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_AVIAN_RESPIRATORY_STRUCTURAL", "ORG_SYNTHETIC_BIOLOGY_PLATFORM")
        bound = bind_origin_packages(lineage(), refs, reg)
        space = build_origin_design_space(bound, reg)
        expected = sum(len(reg.get(ref).contributions) for ref in refs)
        self.assertEqual(len(space.candidates), expected)
        self.assertEqual({c.package_id for c in space.candidates}, set(refs))
        self.assertTrue(all(c.required_tradeoffs for c in space.candidates))

    def test_design_space_does_not_auto_select_or_mutate_phenotype(self):
        reg = build_canonical_origin_registry()
        base = lineage()
        bound = bind_origin_packages(base, ("ORG_AVIAN_RESPIRATORY_STRUCTURAL", "ORG_ARTHROPOD_INSECT_SEGMENTAL"), reg)
        before = (bound.morphology, bound.metabolism, bound.regeneration, bound.sensor_hooks)
        space = build_origin_design_space(bound, reg)
        after = (bound.morphology, bound.metabolism, bound.regeneration, bound.sensor_hooks)
        self.assertEqual(before, after)
        self.assertGreater(len(space.candidates), 1)

    def test_same_domain_candidates_remain_separate_not_averaged(self):
        reg = build_canonical_origin_registry()
        bound = bind_origin_packages(lineage(), ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL"), reg)
        space = build_origin_design_space(bound, reg)
        metabolic = space.candidates_for_domain(FunctionalDomain.METABOLISM)
        self.assertGreaterEqual(len(metabolic), 2)
        self.assertGreaterEqual(len({c.package_id for c in metabolic}), 2)

    def test_design_space_is_deterministic_across_binding_order(self):
        reg = build_canonical_origin_registry()
        refs = ("ORG_AVIAN_RESPIRATORY_STRUCTURAL", "ORG_SYNTHETIC_BIOLOGY_PLATFORM", "ORG_MAMMALIAN_HOMEOSTASIS")
        a = build_origin_design_space(bind_origin_packages(lineage(), refs, reg), reg)
        b = build_origin_design_space(bind_origin_packages(lineage(), tuple(reversed(refs)), reg), reg)
        self.assertEqual(a, b)

    def test_sensor_modalities_are_hooks_not_stage5_models(self):
        for package in CANONICAL_ORIGIN_PACKAGES:
            for modality in package.sensor_modalities:
                self.assertNotIn("response", modality.lower())
                self.assertNotIn("curve", modality.lower())


if __name__ == "__main__":
    unittest.main()
