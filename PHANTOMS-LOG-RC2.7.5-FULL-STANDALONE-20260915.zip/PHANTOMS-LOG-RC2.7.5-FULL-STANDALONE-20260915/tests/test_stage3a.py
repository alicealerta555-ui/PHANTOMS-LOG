import unittest

from runtime.stage3a.kernel import (
    Authority, CommitKernel, Delta, Domain, Mode, NarrationGate, Proposal,
    Stage3AError, StateStore, UnresolvedSpec, Verdict, WeightedOption,
)
from runtime.stage3d.epistemic import epistemic_stamp


def epi_meta(source="test", t=1):
    return epistemic_stamp(source_type="DIRECT_OBSERVATION", source_id=source, origin_location="TEST", learned_at=t)


class Stage3ATests(unittest.TestCase):
    def setUp(self):
        self.store = StateStore()
        self.k = CommitKernel(self.store, world_seed=771337)

    def test_query_never_commits(self):
        p = Proposal(
            mode=Mode.QUERY,
            source=Authority.PLAYER_INPUT,
            query_text="Ist hinter der Tür ein Feind?",
            deltas=(Delta(Domain.WORLD_TRUTH, "door.enemy", True, Authority.PLAYER_INPUT, "question"),),
        )
        r = self.k.process(p)
        self.assertEqual(r.verdict, Verdict.HOLD)
        self.assertNotIn("door.enemy", self.store.world_truth)

    def test_llm_cannot_commit_world_truth(self):
        p = Proposal(
            mode=Mode.COMMIT,
            source=Authority.LLM_PROPOSAL,
            event_id="E1", cause="draft",
            deltas=(Delta(Domain.WORLD_TRUTH, "x", 1, Authority.LLM_PROPOSAL, "draft"),),
        )
        r = self.k.process(p)
        self.assertEqual(r.verdict, Verdict.REJECT)

    def test_narrator_cannot_commit(self):
        p = Proposal(
            mode=Mode.COMMIT, source=Authority.NARRATOR, event_id="E2", cause="prose",
            deltas=(Delta(Domain.RUNTIME_STATE, "hp", 9, Authority.NARRATOR, "prose"),),
        )
        r = self.k.process(p)
        self.assertEqual(r.verdict, Verdict.REJECT)

    def test_rule_kernel_can_commit_runtime_state(self):
        p = Proposal(
            mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E3", cause="damage",
            deltas=(Delta(Domain.RUNTIME_STATE, "player.hp", 9, Authority.RULE_KERNEL, "damage"),),
        )
        rec = self.k.process(p)
        self.assertEqual(self.store.runtime_state["player.hp"], 9)
        self.assertEqual(rec.event_id, "E3")

    def test_wrong_writer_rejected(self):
        p = Proposal(
            mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E4", cause="bad",
            deltas=(Delta(Domain.WORLD_TRUTH, "x", 2, Authority.KNOWLEDGE_ROUTER, "bad"),),
        )
        r = self.k.process(p)
        self.assertEqual(r.verdict, Verdict.REJECT)

    def test_actor_knowledge_requires_actor(self):
        p = Proposal(
            mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E5", cause="heard",
            deltas=(Delta(Domain.ACTOR_KNOWLEDGE, "gate.code", 7, Authority.KNOWLEDGE_ROUTER, "heard", provenance="witness:E0"),),
        )
        r = self.k.process(p)
        self.assertEqual(r.verdict, Verdict.REJECT)

    def test_actor_knowledge_requires_provenance(self):
        p = Proposal(
            mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E6", cause="heard",
            deltas=(Delta(Domain.ACTOR_KNOWLEDGE, "gate.code", 7, Authority.KNOWLEDGE_ROUTER, "heard", actor_id="NPC1"),),
        )
        r = self.k.process(p)
        self.assertEqual(r.verdict, Verdict.REJECT)

    def test_actor_knowledge_commit(self):
        p = Proposal(
            mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E7", cause="heard",
            deltas=(Delta(Domain.ACTOR_KNOWLEDGE, "gate.code", 7, Authority.KNOWLEDGE_ROUTER, "heard", actor_id="NPC1", provenance="witness:E0", epistemic=epi_meta("witness:E0")),),
        )
        self.k.process(p)
        self.assertEqual(self.store.actor_knowledge["NPC1"]["gate.code"]["value"], 7)

    def test_player_knowledge_requires_provenance(self):
        p = Proposal(
            mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E8", cause="seen",
            deltas=(Delta(Domain.PLAYER_KNOWLEDGE, "door.open", True, Authority.KNOWLEDGE_ROUTER, "seen"),),
        )
        r = self.k.process(p)
        self.assertEqual(r.verdict, Verdict.REJECT)

    def test_player_knowledge_commit(self):
        p = Proposal(
            mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E9", cause="seen",
            deltas=(Delta(Domain.PLAYER_KNOWLEDGE, "door.open", True, Authority.KNOWLEDGE_ROUTER, "seen", provenance="observation:E9", epistemic=epi_meta("observation:E9")),),
        )
        self.k.process(p)
        self.assertTrue(self.store.player_knowledge["door.open"]["value"])

    def test_generate_is_hold(self):
        r = self.k.process(Proposal(mode=Mode.GENERATE, source=Authority.LLM_PROPOSAL))
        self.assertEqual(r.verdict, Verdict.HOLD)

    def test_empty_commit_rejected(self):
        r = self.k.process(Proposal(mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E10", cause="none"))
        self.assertEqual(r.verdict, Verdict.REJECT)

    def test_missing_event_id_rejected(self):
        p = Proposal(mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, cause="x",
                     deltas=(Delta(Domain.RUNTIME_STATE, "x", 1, Authority.RULE_KERNEL, "x"),))
        r = self.k.process(p)
        self.assertEqual(r.verdict, Verdict.REJECT)

    def test_missing_cause_rejected(self):
        p = Proposal(mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E11",
                     deltas=(Delta(Domain.RUNTIME_STATE, "x", 1, Authority.RULE_KERNEL, "x"),))
        r = self.k.process(p)
        self.assertEqual(r.verdict, Verdict.REJECT)

    def test_duplicate_event_is_idempotent(self):
        p = Proposal(mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E12", cause="x",
                     deltas=(Delta(Domain.RUNTIME_STATE, "counter", 1, Authority.RULE_KERNEL, "x"),))
        self.k.process(p)
        rev = self.store.revision
        r = self.k.process(p)
        self.assertEqual(r.verdict, Verdict.HOLD)
        self.assertEqual(self.store.revision, rev)

    def test_resolution_commits_world_truth(self):
        self.k.register_unresolved(UnresolvedSpec("vault.contents", (WeightedOption("A", 1), WeightedOption("B", 3))))
        rec = self.k.process(Proposal(mode=Mode.RESOLVE, source=Authority.WORLD_RESOLVER, resolution_key="vault.contents", event_id="R1", cause="inspection"))
        self.assertIn(self.store.world_truth["vault.contents"], {"A", "B"})
        self.assertEqual(rec.event_id, "R1")
        self.assertNotIn("vault.contents", self.store.unresolved_world)

    def test_resolution_is_seed_deterministic(self):
        def run(suggestion):
            k = CommitKernel(StateStore(), world_seed=1234)
            k.register_unresolved(UnresolvedSpec("x", (WeightedOption("yes", 2), WeightedOption("no", 8)), seed_salt="s"))
            k.process(Proposal(mode=Mode.RESOLVE, source=Authority.WORLD_RESOLVER, resolution_key="x", player_suggestion=suggestion, event_id="RX", cause="probe"))
            return k.store.world_truth["x"]
        self.assertEqual(run("yes"), run("no"))
        self.assertEqual(run(None), run("yes"))

    def test_player_suggestion_does_not_change_distribution_result(self):
        # Strong direct anti-suggestion minimal pair under identical state+seed.
        def resolve(suggestion):
            k = CommitKernel(StateStore(), world_seed=999)
            k.register_unresolved(UnresolvedSpec("guard.present", (WeightedOption(True, 1), WeightedOption(False, 1))))
            k.process(Proposal(mode=Mode.RESOLVE, source=Authority.WORLD_RESOLVER, resolution_key="guard.present", player_suggestion=suggestion, event_id="RG", cause="ground truth needed"))
            return k.store.world_truth["guard.present"]
        self.assertEqual(resolve(True), resolve(False))

    def test_no_reroll(self):
        self.k.register_unresolved(UnresolvedSpec("x", (WeightedOption(1, 1), WeightedOption(2, 1))))
        self.k.process(Proposal(mode=Mode.RESOLVE, source=Authority.WORLD_RESOLVER, resolution_key="x", event_id="R2", cause="first"))
        first = self.store.world_truth["x"]
        r = self.k.process(Proposal(mode=Mode.RESOLVE, source=Authority.WORLD_RESOLVER, resolution_key="x", event_id="R3", cause="again"))
        self.assertEqual(r.verdict, Verdict.HOLD)
        self.assertEqual(self.store.world_truth["x"], first)

    def test_resolve_unknown_key_rejected(self):
        r = self.k.process(Proposal(mode=Mode.RESOLVE, source=Authority.WORLD_RESOLVER, resolution_key="missing", event_id="R4", cause="x"))
        self.assertEqual(r.verdict, Verdict.REJECT)

    def test_resolve_authority_rejected_for_player(self):
        self.k.register_unresolved(UnresolvedSpec("x", (WeightedOption(1, 1),)))
        r = self.k.process(Proposal(mode=Mode.RESOLVE, source=Authority.PLAYER_INPUT, resolution_key="x", event_id="R5", cause="ask"))
        self.assertEqual(r.verdict, Verdict.REJECT)

    def test_cannot_register_unresolved_over_truth(self):
        self.store.world_truth["x"] = 1
        with self.assertRaises(Stage3AError):
            self.k.register_unresolved(UnresolvedSpec("x", (WeightedOption(2, 1),)))

    def test_resolver_cannot_overwrite_existing_truth(self):
        self.store.world_truth["x"] = 1
        p = Proposal(mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E13", cause="reroll",
                     deltas=(Delta(Domain.WORLD_TRUTH, "x", 2, Authority.WORLD_RESOLVER, "reroll"),))
        r = self.k.process(p)
        self.assertEqual(r.verdict, Verdict.REJECT)
        self.assertEqual(self.store.world_truth["x"], 1)

    def test_rule_kernel_world_truth_change_is_allowed(self):
        self.store.world_truth["door.intact"] = True
        p = Proposal(mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E14", cause="explosion",
                     deltas=(Delta(Domain.WORLD_TRUTH, "door.intact", False, Authority.RULE_KERNEL, "explosion"),))
        self.k.process(p)
        self.assertFalse(self.store.world_truth["door.intact"])

    def test_atomic_multi_delta_commit(self):
        p = Proposal(mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E15", cause="move+cost",
                     deltas=(
                         Delta(Domain.RUNTIME_STATE, "pos", "B", Authority.RULE_KERNEL, "move"),
                         Delta(Domain.RUNTIME_STATE, "stamina", 8, Authority.RULE_KERNEL, "cost"),
                     ))
        self.k.process(p)
        self.assertEqual(self.store.runtime_state, {"pos": "B", "stamina": 8})
        self.assertEqual(self.store.revision, 1)

    def test_rejected_transaction_changes_nothing(self):
        before = self.store.state_hash()
        p = Proposal(mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E16", cause="mixed",
                     deltas=(
                         Delta(Domain.RUNTIME_STATE, "ok", 1, Authority.RULE_KERNEL, "ok"),
                         Delta(Domain.WORLD_TRUTH, "bad", 2, Authority.NARRATOR, "bad"),
                     ))
        r = self.k.process(p)
        self.assertEqual(r.verdict, Verdict.REJECT)
        self.assertEqual(self.store.state_hash(), before)

    def test_narration_gate_read_only_contract(self):
        self.store.world_truth["x"] = 4
        g = NarrationGate(self.store)
        before = self.store.state_hash()
        view = g.committed_view()
        self.assertNotIn("WORLD_TRUTH", view)
        self.assertNotIn("ACTOR_KNOWLEDGE", view)
        self.assertNotIn("UNRESOLVED_WORLD", view)
        view["PLAYER_KNOWLEDGE"]["fake"] = 999
        g.assert_no_state_change(before)
        self.assertEqual(self.store.world_truth["x"], 4)

    def test_hold_never_commits(self):
        before = self.store.state_hash()
        r = self.k.process(Proposal(mode=Mode.HOLD, source=Authority.COMMIT_KERNEL,
                                    deltas=(Delta(Domain.RUNTIME_STATE, "x", 1, Authority.RULE_KERNEL, "x"),)))
        self.assertEqual(r.verdict, Verdict.HOLD)
        self.assertEqual(self.store.state_hash(), before)

    def test_reject_never_commits(self):
        before = self.store.state_hash()
        r = self.k.process(Proposal(mode=Mode.REJECT, source=Authority.COMMIT_KERNEL,
                                    deltas=(Delta(Domain.RUNTIME_STATE, "x", 1, Authority.RULE_KERNEL, "x"),)))
        self.assertEqual(r.verdict, Verdict.REJECT)
        self.assertEqual(self.store.state_hash(), before)

    def test_event_hash_chain_changes(self):
        p = Proposal(mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E17", cause="x",
                     deltas=(Delta(Domain.RUNTIME_STATE, "x", 1, Authority.RULE_KERNEL, "x"),))
        rec = self.k.process(p)
        self.assertNotEqual(rec.before_hash, rec.after_hash)

    def test_event_ledger_contains_commit(self):
        p = Proposal(mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E18", cause="x",
                     deltas=(Delta(Domain.RUNTIME_STATE, "x", 1, Authority.RULE_KERNEL, "x"),))
        self.k.process(p)
        self.assertIn("E18", self.store.event_ledger)

    def test_unresolved_bad_weight_rejected(self):
        with self.assertRaises(Stage3AError):
            self.k.register_unresolved(UnresolvedSpec("x", (WeightedOption(1, 0),)))

    def test_unresolved_empty_rejected(self):
        with self.assertRaises(Stage3AError):
            self.k.register_unresolved(UnresolvedSpec("x", ()))

    def test_world_truth_does_not_auto_leak_to_actor_knowledge(self):
        self.store.world_truth["secret"] = "alpha"
        self.assertNotIn("NPC1", self.store.actor_knowledge)
        self.assertIsNone(self.store.get(Domain.ACTOR_KNOWLEDGE, "secret", actor_id="NPC1"))

    def test_world_truth_does_not_auto_leak_to_player_knowledge(self):
        self.store.world_truth["secret"] = "alpha"
        self.assertNotIn("secret", self.store.player_knowledge)

    def test_query_with_suggestion_does_not_resolve(self):
        self.k.register_unresolved(UnresolvedSpec("enemy", (WeightedOption(True, 1), WeightedOption(False, 1))))
        r = self.k.process(Proposal(mode=Mode.QUERY, source=Authority.PLAYER_INPUT, query_text="Da ist doch ein Gegner?", player_suggestion=True, resolution_key="enemy"))
        self.assertEqual(r.verdict, Verdict.HOLD)
        self.assertNotIn("enemy", self.store.world_truth)
        self.assertIn("enemy", self.store.unresolved_world)

    def test_resolution_after_hash_matches_final_state(self):
        self.k.register_unresolved(UnresolvedSpec("hash.test", (WeightedOption("A", 1), WeightedOption("B", 1))))
        rec = self.k.process(Proposal(mode=Mode.RESOLVE, source=Authority.WORLD_RESOLVER, resolution_key="hash.test", event_id="RH", cause="resolve"))
        self.assertEqual(rec.after_hash, self.store.state_hash())

    def test_direct_llm_read_world_truth_denied(self):
        self.store.world_truth["secret"] = "omega"
        with self.assertRaises(Stage3AError):
            self.k.read(Authority.LLM_PROPOSAL, Domain.WORLD_TRUTH, "secret")

    def test_narrator_direct_world_truth_read_denied(self):
        self.store.world_truth["secret"] = "omega"
        with self.assertRaises(Stage3AError):
            self.k.read(Authority.NARRATOR, Domain.WORLD_TRUTH, "secret")

    def test_rule_kernel_can_read_world_truth(self):
        self.store.world_truth["door.intact"] = True
        self.assertTrue(self.k.read(Authority.RULE_KERNEL, Domain.WORLD_TRUTH, "door.intact"))

    def test_knowledge_router_can_read_world_truth_for_provenance_routing(self):
        self.store.world_truth["alarm"] = True
        self.assertTrue(self.k.read(Authority.KNOWLEDGE_ROUTER, Domain.WORLD_TRUTH, "alarm"))


    def test_exists_distinguishes_missing_from_none(self):
        rec = self.k.process(Proposal(
            mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="evt-null", cause="INIT",
            deltas=(Delta(Domain.RUNTIME_STATE, "nullable", None, Authority.RULE_KERNEL, "INIT"),),
        ))
        self.assertEqual(rec.event_id, "evt-null")
        self.assertTrue(self.k.exists(Authority.RULE_KERNEL, Domain.RUNTIME_STATE, "nullable"))
        self.assertFalse(self.k.exists(Authority.RULE_KERNEL, Domain.RUNTIME_STATE, "absent"))
        self.assertIsNone(self.k.read(Authority.RULE_KERNEL, Domain.RUNTIME_STATE, "nullable"))

    def test_exists_obeys_read_authority(self):
        with self.assertRaises(Stage3AError):
            self.k.exists(Authority.NARRATOR, Domain.WORLD_TRUTH, "x")

if __name__ == "__main__":
    unittest.main(verbosity=2)
