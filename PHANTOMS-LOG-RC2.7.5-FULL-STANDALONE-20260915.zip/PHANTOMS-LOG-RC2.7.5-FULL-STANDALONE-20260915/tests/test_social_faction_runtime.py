from pathlib import Path
import tempfile
from playable.game import FullVersionGame
from runtime.full_version.social_faction import SocialFactionRuntime, SOCIAL_STATE_KEY
from runtime.stage3a.kernel import Authority, Domain

def make_game():
    core=Path(__file__).resolve().parents[1]
    td=tempfile.TemporaryDirectory()
    g=FullVersionGame(core_root=core,saves_root=Path(td.name),start_class="OPERATOR")
    g.complete_character(g.creation_template())
    g._tmp=td
    return g

def test_social_state_bootstrapped():
    g=make_game()
    s=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,SOCIAL_STATE_KEY)
    assert s["run_uuid"]==g.session.identity.run_uuid and "relationships" in s

def test_talk_changes_real_relationship():
    g=make_game()
    npcs=g.actors_here()
    if not npcs:
        # use first NPC and move player to its committed location for the integration test
        nid=next(x.actor_instance_id for x in g.actor_registry.instances() if x.actor_instance_id.startswith("actor:npc:"))
        npc=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,nid)
        # Relationship runtime itself is location-independent; this validates committed social consequence.
    else: nid=npcs[0]["actor_instance_id"]
    before=g.social_faction.relationship("actor:player",nid)["trust"]
    npc=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,nid)
    sp=npc.get("social_profile",{})
    region=g.catalog.location(npc["location_ref"])["region_id"]
    g.social_faction.apply_event("actor:player",nid,"TALK",region_id=region,household_id=sp.get("household_ref",""),faction_id=npc["faction_id"])
    assert g.social_faction.relationship("actor:player",nid)["trust"]>before

def test_scoped_reputation_is_separate():
    g=make_game()
    nid=next(x.actor_instance_id for x in g.actor_registry.instances() if x.actor_instance_id.startswith("actor:npc:"))
    npc=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,nid); sp=npc["social_profile"]
    region=g.catalog.location(npc["home_location_id"])["region_id"]
    g.social_faction.apply_event("actor:player",nid,"HELP",region_id=region,household_id=sp["household_ref"],faction_id=npc["faction_id"])
    assert g.social_faction.reputation("npc",nid)["trust"] >= g.social_faction.reputation("faction",npc["faction_id"])["trust"]
    assert g.social_faction.reputation("household",sp["household_ref"])["trust"] != 0

def test_attack_effect_can_refuse_trade():
    g=make_game()
    nid=next(x.actor_instance_id for x in g.actor_registry.instances() if x.actor_instance_id.startswith("actor:npc:"))
    npc=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,nid)
    for _ in range(3): g.social_faction.apply_event("actor:player",nid,"ATTACK",faction_id=npc["faction_id"])
    assert not g.social_faction.can_trade(nid)

def test_rumor_is_provenance_bound_and_propagates_only_to_actor_contacts():
    g=make_game(); ids=[x.actor_instance_id for x in g.actor_registry.instances() if x.actor_instance_id.startswith("actor:npc:")][:3]
    g.social_faction.seed_rumor("rumor:test",ids[0],"Die Nordpumpe stockt.",80)
    assert g.social_faction.rumors_for(ids[0])[0]["confidence"]==80
    assert g.social_faction.rumors_for(ids[1])==[]

def test_legal_event_without_witness_is_not_guilt():
    g=make_game()
    r=g.social_faction.record_legal_event("THEFT","actor:player","region:test",[],"event:test")
    assert r["status"]=="UNOBSERVED" and r["law_id"]=="LAW_THEFT"

def test_prompt_exists_and_forbids_omniscience():
    p=Path(__file__).resolve().parents[1]/"content/full_version/prompts/SOCIAL_FACTION_DIALOGUE_PROMPT_CORE.md"
    t=p.read_text()
    assert "NPC knowledge is not world truth" in t and "accusation is not guilt" in t.lower()
