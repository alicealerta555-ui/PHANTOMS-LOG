from __future__ import annotations

import unittest
from uuid import uuid4

from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actor_context import ActorContextProjector
from runtime.stage9.actor_logic import (
    ActorDecisionCandidate, ActorDecisionKind, DeterministicStubBackend,
    ModelDecisionValidator, SafeModelActorLogicBackend, Stage9ActorLogicError,
)
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.context import RuntimeContext
from runtime.stage9.identity import RuntimeIdentity


class Stage9ActorLogicTests(unittest.TestCase):
    def setUp(self):
        self.manager = RunSessionManager(master_seed=7)
        self.player = str(uuid4())
        self.session = self.manager.create_run(player_uuid=self.player)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(self.player, self.session.identity.run_uuid, "actor:npc")
        self.registry.register(self.identity, actor_definition_id="npc:test")
        self.context = ActorContextProjector(self.session, self.registry, self.identity).project()
        self.runtime_context = RuntimeContext.capture(
            self.session, self.registry, self.identity, turn_id="turn:npc:1", action_window_id="window:npc:1"
        )

    def test_stub_hold_is_deterministic(self):
        b = DeterministicStubBackend()
        self.assertEqual(b.decide(self.context), b.decide(self.context))
        self.assertEqual(b.decide(self.context).kind, ActorDecisionKind.HOLD)

    def test_stub_action_is_untrusted_choice_only(self):
        before = self.session.store.state_hash()
        c = DeterministicStubBackend(preferred_action="LOOK").decide(self.context)
        self.assertEqual(c.kind, ActorDecisionKind.ACTION)
        self.assertEqual(self.session.store.state_hash(), before)

    def test_disabled_model_uses_stub_without_invocation(self):
        called = []
        b = SafeModelActorLogicBackend(lambda _: called.append(True) or {}, enabled=False)
        c = b.decide(self.context)
        self.assertEqual(c.kind, ActorDecisionKind.HOLD)
        self.assertEqual(called, [])

    def test_model_invoker_receives_json_string_only(self):
        seen = []
        def invoke(prompt):
            seen.append(prompt)
            return {
                "run_uuid": self.context.run_uuid,
                "actor_instance_id": self.context.actor_instance_id,
                "context_fingerprint": self.context.context_fingerprint,
                "kind": "HOLD",
            }
        c = SafeModelActorLogicBackend(invoke).decide(self.context)
        self.assertEqual(c.kind, ActorDecisionKind.HOLD)
        self.assertIsInstance(seen[0], str)
        self.assertNotIn("StateStore", seen[0])
        self.assertNotIn("CommitKernel", seen[0])

    def test_invalid_model_output_falls_back_hold_bounded(self):
        calls = []
        def bad(_):
            calls.append(1)
            return {"forbidden": "field"}
        c = SafeModelActorLogicBackend(bad, max_attempts=2).decide(self.context)
        self.assertEqual(c.kind, ActorDecisionKind.HOLD)
        self.assertEqual(len(calls), 2)

    def test_valid_action_maps_to_ordinary_action_proposal(self):
        c = DeterministicStubBackend(preferred_action="LOOK").decide(self.context)
        p = ModelDecisionValidator(frozenset({"LOOK", "MOVE"}), "actor:npc").validate_to_action_proposal(
            self.context, self.runtime_context, c
        )
        self.assertIsNotNone(p)
        self.assertEqual(p.action_type, "LOOK")
        self.assertEqual(p.actor_instance_id, "actor:npc")

    def test_stale_context_fingerprint_rejected(self):
        c = ActorDecisionCandidate(
            decision_id="decision:x", run_uuid=self.context.run_uuid,
            actor_instance_id=self.context.actor_instance_id,
            context_fingerprint="0" * 64, kind=ActorDecisionKind.ACTION, action_type="LOOK"
        )
        with self.assertRaisesRegex(Stage9ActorLogicError, "FINGERPRINT_MISMATCH"):
            ModelDecisionValidator(frozenset({"LOOK"}), "actor:npc").validate_to_action_proposal(
                self.context, self.runtime_context, c
            )

    def test_wrong_actor_rejected(self):
        c = ActorDecisionCandidate(
            decision_id="decision:x", run_uuid=self.context.run_uuid,
            actor_instance_id="actor:other", context_fingerprint=self.context.context_fingerprint,
            kind=ActorDecisionKind.ACTION, action_type="LOOK"
        )
        with self.assertRaisesRegex(Stage9ActorLogicError, "ACTOR_MISMATCH"):
            ModelDecisionValidator(frozenset({"LOOK"}), "actor:npc").validate_to_action_proposal(
                self.context, self.runtime_context, c
            )

    def test_unallowed_action_rejected(self):
        c = DeterministicStubBackend(preferred_action="ADMIN_DELETE").decide(self.context)
        with self.assertRaisesRegex(Stage9ActorLogicError, "ACTION_NOT_ALLOWED"):
            ModelDecisionValidator(frozenset({"LOOK"}), "actor:npc").validate_to_action_proposal(
                self.context, self.runtime_context, c
            )


if __name__ == "__main__":
    unittest.main()
