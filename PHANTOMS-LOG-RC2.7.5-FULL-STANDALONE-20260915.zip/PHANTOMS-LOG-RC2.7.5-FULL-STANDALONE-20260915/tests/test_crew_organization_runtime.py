from pathlib import Path
import tempfile

from playable.game import FullVersionGame
from runtime.full_version.capability_catalog import class_start_skills
from runtime.full_version.organization_runtime import derive_capacity, OrganizationRuntimeError

ROOT=Path(__file__).resolve().parents[1]


def tables():
    import json
    return json.loads((ROOT/'content/full_version/organization_capability_tables.json').read_text(encoding='utf-8'))


def test_class_playstyles_have_distinct_capacity_weighting():
    t=tables()
    profiles={c:derive_capacity(t,start_class=c,level=1,skills=class_start_skills(c)) for c in ('BREAKER','GHOST','OPERATOR','RESONANT')}
    assert profiles['BREAKER'].direct_crew > profiles['OPERATOR'].direct_crew
    assert profiles['GHOST'].cell_slots > profiles['BREAKER'].cell_slots
    assert profiles['OPERATOR'].machine_bandwidth > profiles['RESONANT'].machine_bandwidth
    assert profiles['RESONANT'].organization_members > profiles['GHOST'].organization_members


def test_social_and_command_are_separate_axes():
    t=tables(); base=class_start_skills('RESONANT')
    social=dict(base); social['SKILL_PEOPLE_READING']=10; social['SKILL_ATTENTION']=1
    command=dict(base); command['SKILL_PEOPLE_READING']=1; command['SKILL_ATTENTION']=10
    a=derive_capacity(t,start_class='RESONANT',level=30,skills=social)
    b=derive_capacity(t,start_class='RESONANT',level=30,skills=command)
    assert a.organization_members > b.organization_members
    assert b.command_units >= a.command_units


def test_controller_is_narrow_machine_scaling_line():
    t=tables(); skills=class_start_skills('OPERATOR')
    base=derive_capacity(t,start_class='OPERATOR',level=20,skills=skills)
    ctrl=derive_capacity(t,start_class='OPERATOR',level=20,skills=skills,specialization='CONTROLLER')
    assert ctrl.machine_bandwidth >= base.machine_bandwidth+10
    assert ctrl.narrow_core_skills == ('SKILL_NETWORKS','SKILL_ELECTRONICS','SKILL_DIAGNOSTICS','SKILL_ATTENTION')
    assert len(ctrl.narrow_core_skills)==4


def test_resonant_social_path_scales_large_organization():
    t=tables(); skills=class_start_skills('RESONANT')
    base=derive_capacity(t,start_class='RESONANT',level=50,skills=skills)
    signal=derive_capacity(t,start_class='RESONANT',level=50,skills=skills,specialization='SEER',end_path='THE_SIGNAL')
    assert signal.organization_members >= base.organization_members+100
    assert signal.command_units > base.command_units
    assert signal.delegation_tier=='ORGANIZATION'


def make_game(start_class='RESONANT'):
    td=tempfile.TemporaryDirectory()
    g=FullVersionGame(core_root=ROOT,saves_root=Path(td.name),start_class=start_class)
    g.complete_character(g.creation_template())
    g._tmp=td
    return g


def first_npc(g):
    return next(x.actor_instance_id for x in g.actor_registry.instances() if x.actor_instance_id.startswith('actor:npc:'))


def test_recruitment_requires_candidate_acceptance_and_capacity():
    g=make_game(); org=g.organization_runtime.create_organization('Signalhaus')
    npc=first_npc(g); offer=g.organization_runtime.offer_recruitment(npc,'ROLE_SCOUT')
    assert npc not in g.organization_runtime.state_view()['members']
    assert offer['status']=='OFFERED' and offer['organization_id']==org['organization_id']
    decision=g.organization_runtime.resolve_recruitment(offer['offer_id'],npc,'ACCEPT')
    assert decision['status']=='ACCEPTED'
    assert npc in g.organization_runtime.state_view()['members']


def test_operation_requires_actor_decisions_and_authoritative_result_ref():
    g=make_game(); g.organization_runtime.create_organization('Signalhaus')
    npc=first_npc(g); offer=g.organization_runtime.offer_recruitment(npc,'ROLE_TRADER'); g.organization_runtime.resolve_recruitment(offer['offer_id'],npc,'ACCEPT')
    team=g.organization_runtime.create_team('team:envoy','DIPLOMATIC_MISSION',['actor:player',npc],leader_actor_id='actor:player')
    op=g.organization_runtime.dispatch_operation('op:talk',['team:envoy'],target_ref='faction:test',objective='Verhandlung vorbereiten')
    assert op['status']=='AWAITING_ACCEPTANCE'
    assert op['required_actor_acceptance']==[npc]
    assert all(x['requires_actor_decision'] for x in op['orders'])
    op=g.organization_runtime.record_operation_decision('op:talk',npc,True)
    assert op['status']=='READY'
    op=g.organization_runtime.activate_operation('op:talk'); assert op['status']=='ACTIVE'
    try:
        g.organization_runtime.complete_operation('op:talk',result_ref='')
        assert False, 'empty result ref must fail'
    except OrganizationRuntimeError as exc:
        assert 'AUTHORITATIVE_RESULT_REF_REQUIRED' in str(exc)
    op=g.organization_runtime.complete_operation('op:talk',result_ref='content-s25:resolution:123')
    assert op['status']=='COMPLETE'
    assert g.organization_runtime.state_view()['teams'][team['team_id']]['status']=='AVAILABLE'


def test_team_templates_bridge_existing_systems_without_class_lockout():
    g=make_game('OPERATOR')
    templates={x['template_id']:x for x in g.organization_runtime.team_templates()}
    assert templates['DRONE_WING']['favored'] is True
    assert templates['DIPLOMATIC_MISSION']['favored'] is False
    assert 'CONTENT_S10_DUNGEON' in templates['DUNGEON_SURVEY']['integration']
    assert 'CONTENT_S44_INDUSTRY' in templates['PRODUCTION_CELL']['integration']
    assert len(templates)>=12


def test_game_exposes_crew_team_and_org_surfaces():
    g=make_game('OPERATOR')
    text,_=g.handle('/crew'); assert 'Maschinenbandbreite' in text and 'Direkte Crew' in text
    text,_=g.handle('/teamtypen'); assert 'DRONE_WING' in text and 'DIPLOMATIC_MISSION' in text
    text,_=g.handle('/organisation gründen Werkbund'); assert 'Organisation gegründet' in text
    text,_=g.handle('/org'); assert 'Werkbund' in text

def test_large_scale_requires_real_delegation_ranks():
    g=make_game('RESONANT'); g.organization_runtime.create_organization('Signalhaus')
    assert g.organization_runtime.staffed_member_capacity()==g.organization_runtime.capacity().direct_crew
    npcs=[x.actor_instance_id for x in g.actor_registry.instances() if x.actor_instance_id.startswith('actor:npc:')]
    first=npcs[0]; offer=g.organization_runtime.offer_recruitment(first,'ROLE_SCOUT'); g.organization_runtime.resolve_recruitment(offer['offer_id'],first,'ACCEPT')
    before=g.organization_runtime.staffed_member_capacity()
    try:
        g.organization_runtime.apply_rank_assignment(first,'RANK_OFFICER',authority_result_ref='')
        assert False, 'rank change must require an authoritative result'
    except OrganizationRuntimeError as exc:
        assert 'AUTHORITATIVE_RANK_RESULT_REF_REQUIRED' in str(exc)
    g.organization_runtime.apply_rank_assignment(first,'RANK_OFFICER',authority_result_ref='content-s24:appointment:1')
    assert g.organization_runtime.staffed_member_capacity() > before
    assert g.organization_runtime.staffed_member_capacity() <= g.organization_runtime.capacity().organization_members


def test_drone_functions_come_from_machine_units_not_player_skill_mutation():
    g=make_game('OPERATOR'); g.organization_runtime.create_organization('Werkbund')
    before=dict(g.character()['skills'])
    team=g.organization_runtime.create_team('team:drones','DRONE_WING',['actor:player'],leader_actor_id='actor:player',
        machine_profiles={'DRONE_SCOUT':2,'DRONE_REPAIR':2})
    assert team['machine_units']==4
    assert 'SKILL_OBSERVATION' in team['machine_functions']
    assert 'SKILL_FINE_MECHANICS' in team['machine_functions']
    assert g.character()['skills']==before
    op=g.organization_runtime.dispatch_operation('op:scan',['team:drones'],target_ref='site:test',objective='Kartieren und Defekte markieren')
    assert op['status']=='READY'
    handoff=g.organization_runtime.operation_handoff('op:scan')
    assert handoff['auto_resolve_forbidden'] is True
    assert handoff['authority_required'] is True
    assert 'SKILL_OBSERVATION' in handoff['machine_functions']
