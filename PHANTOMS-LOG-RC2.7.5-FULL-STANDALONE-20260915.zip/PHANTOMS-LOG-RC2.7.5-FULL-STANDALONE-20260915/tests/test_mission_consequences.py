from pathlib import Path
import tempfile
import pytest
from playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, Delta, Domain, Mode, Proposal, CommitRecord
from runtime.full_version.authored_missions_runtime import AuthoredMissionRuntime
from runtime.full_version.mission_consequences import MissionConsequenceRouter, MissionConsequenceError
from runtime.stage9.world_time import WorldClock
ROOT=Path(__file__).resolve().parents[1]

def game(tmp):
    g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class='OPERATOR',master_seed=20260915)
    g.complete_character(g.creation_template()); return g

def npc(g):
    for k in g.session.store.runtime_state:
        if str(k).startswith('actor:npc:'):
            r=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,k)
            if isinstance(r,dict): return k
    raise AssertionError

def evidence(g, key='evidence:mission:test'):
    rec={'run_uuid':g.session.identity.run_uuid,'kind':'mission_evidence','resolved':True}
    out=g.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,
        deltas=(Delta(Domain.RUNTIME_STATE,key,rec,Authority.RULE_KERNEL,'TEST_EVIDENCE',source_event_id='TEST_EVIDENCE',provenance='TEST'),),
        event_id='TEST_EVIDENCE',cause='TEST_EVIDENCE',expected_state_revision=g.session.store.revision))
    assert isinstance(out,CommitRecord); return key

def candidate(g, template_id='AM_MED_TRIAGE'):
    n=npc(g); ar=AuthoredMissionRuntime(g.catalog,g.session)
    qid,_=ar.materialize(template_id,source_ref=n,location_id=g.location(),issuer_actor_id=n)
    g.execute(action_type='QUEST_ACCEPT',raw_input='accept',target_refs=(qid,))
    e=g.quest_runtime.resolve_mission_attempt(qid,difficulty=20,danger=5,time_pressure=5)
    assert e['outcome'] in {'FAILURE','CRITICAL_FAILURE'}
    return f"mission_consequence:{qid.split(':',1)[1]}:1"

def test_consequence_requires_existing_evidence():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); cid=candidate(g); r=MissionConsequenceRouter(g.session)
        with pytest.raises(MissionConsequenceError,match='EVIDENCE_NOT_FOUND'):
            r.apply_fact(cid,{'fact_type':'WORLD_TIME_LOSS','seconds':60,'evidence_ref':'evidence:not-real'})

def test_time_loss_routes_through_semantic_authority_and_marks_candidate():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); cid=candidate(g); ev=evidence(g); r=MissionConsequenceRouter(g.session)
        before=WorldClock(g.session).seconds; receipt=r.apply_fact(cid,{'fact_type':'WORLD_TIME_LOSS','seconds':90,'evidence_ref':ev})
        assert WorldClock(g.session).seconds==before+90
        c=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,cid)
        assert c['state']=='APPLIED' and c['effects'][0]['effect_type']=='ADVANCE_WORLD_TIME'
        with pytest.raises(MissionConsequenceError,match='ALREADY_RESOLVED'):
            r.apply_fact(cid,{'fact_type':'WORLD_TIME_LOSS','seconds':90,'evidence_ref':ev})

def test_resource_delta_uses_existing_owner_and_cannot_underflow():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); cid=candidate(g); ev=evidence(g); r=MissionConsequenceRouter(g.session)
        actor='actor:player'
        rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,actor)
        rec=dict(rec); rec['resources']={'test_supply':3}
        out=g.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,
            deltas=(Delta(Domain.RUNTIME_STATE,actor,rec,Authority.RULE_KERNEL,'TEST_RESOURCE',source_event_id='TEST_RESOURCE',provenance='TEST'),),
            event_id='TEST_RESOURCE',cause='TEST_RESOURCE',expected_state_revision=g.session.store.revision)); assert isinstance(out,CommitRecord)
        r.apply_fact(cid,{'fact_type':'RESOURCE_DELTA','owner_ref':actor,'resource_key':'test_supply','delta':-2,'evidence_ref':ev})
        after=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,actor)
        assert after['resources']['test_supply']==1

def test_unsupported_fact_cannot_invent_infrastructure_or_ecology_effect():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); cid=candidate(g); ev=evidence(g); r=MissionConsequenceRouter(g.session)
        with pytest.raises(MissionConsequenceError,match='FACT_UNSUPPORTED'):
            r.apply_fact(cid,{'fact_type':'INFRASTRUCTURE_DAMAGE','infrastructure_id':'x','evidence_ref':ev})

def test_infrastructure_consequence_uses_stage8_authority_path():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); cid=candidate(g,'AM_ECO_CAUSE'); ev=evidence(g); r=MissionConsequenceRouter(g.session,g.catalog)
        iid=next(iter(g.catalog.stage8_world.infrastructure))
        receipt=r.apply_fact(cid,{'fact_type':'INFRASTRUCTURE_STATE_CHANGE','infrastructure_id':iid,'new_state':'DEGRADED','evidence_ref':ev})
        from runtime.stage8.world import Stage8WorldView
        assert Stage8WorldView(g.session,g.catalog.stage8_world).snapshot().infrastructure_states[iid]=='DEGRADED'
        assert receipt.effect_type=='INFRASTRUCTURE_STATE_CHANGE'


def test_ecology_resource_consequence_uses_stage10_authority_path():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); cid=candidate(g,'AM_ECO_SAMPLE'); ev=evidence(g); r=MissionConsequenceRouter(g.session,g.catalog)
        did=g.catalog.dungeons[0]['dungeon_id']
        r.apply_fact(cid,{'fact_type':'ECOLOGY_RESOURCE_DELTA','site_id':did,'resource_key':'water','delta':2,'evidence_ref':ev})
        from runtime.stage10.state import Stage10WorldView
        assert Stage10WorldView(g.session,dungeon_definitions=g.catalog.dungeons).snapshot().ecology[did].resources['water']==2


def test_ecology_population_loss_requires_existing_real_population():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); cid=candidate(g,'AM_HUNT_PROBLEM'); ev=evidence(g); r=MissionConsequenceRouter(g.session,g.catalog)
        did=g.catalog.dungeons[0]['dungeon_id']; pid=next(iter(g.catalog.creature_registry.ids()))
        with pytest.raises(MissionConsequenceError,match='POPULATION_NOT_PRESENT'):
            r.apply_fact(cid,{'fact_type':'ECOLOGY_POPULATION_DELTA','site_id':did,'population_id':pid,'delta':-1,'evidence_ref':ev})


def test_family_profile_blocks_semantically_unrelated_fact():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); cid=candidate(g,'AM_MED_TRIAGE'); ev=evidence(g); r=MissionConsequenceRouter(g.session,g.catalog)
        did=g.catalog.dungeons[0]['dungeon_id']
        with pytest.raises(MissionConsequenceError,match='FACT_NOT_ALLOWED_FOR_FAMILY'):
            r.apply_fact(cid,{'fact_type':'ECOLOGY_RESOURCE_DELTA','site_id':did,'resource_key':'water','delta':1,'evidence_ref':ev})

def test_all_authored_mission_families_have_consequence_profile():
    import json
    authored=json.loads((ROOT/'content/full_version/authored_missions_search_medical_drone_hunting_ecology.json').read_text())
    profiles=json.loads((ROOT/'content/full_version/mission_consequence_profiles.json').read_text())
    assert {m['mission_family'] for m in authored['missions']} <= set(profiles['families'])
