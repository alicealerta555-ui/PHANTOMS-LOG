
import json,unittest
from pathlib import Path
from runtime.content_stage14.law import *
ROOT=Path(__file__).resolve().parents[1]; D=json.loads((ROOT/"content/full_version/stage14_factions_law.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_factions(self): self.assertGreaterEqual(len(D["factions"]),5)
 def test_jurisdiction(self): self.assertGreaterEqual(len(D["jurisdictions"]),3)
 def test_evidence_provenance(self):
  e=evidence_record("witness_report","a","w",1,2,60,"EV"); self.assertTrue(valid_evidence(e)); e["source_actor_id"]=""; self.assertFalse(valid_evidence(e))
 def test_accusation_not_guilt(self):
  law=D["laws"][1]; c=legal_case_candidate(law,"J","a","EV",[]); self.assertFalse(c["actionable"])
 def test_threshold(self):
  law=D["laws"][0]; e=[evidence_record("direct_observation","a","w",1,2,60,"EV")]; self.assertTrue(legal_case_candidate(law,"J","a","EV",e)["actionable"])
 def test_no_certainty_by_repetition(self):
  es=[evidence_record("witness_report","a","w",1,2,99,"EV") for _ in range(10)]; self.assertLess(evidence_score(es),100)
 def test_reputation_bounded(self):
  self.assertEqual(reputation_delta({"standing":90},{"standing":50})["standing"],100)
 def test_enforcement_authority(self):
  law=D["laws"][0]; e=[evidence_record("direct_observation","a","w",1,2,80,"EV")]; c=legal_case_candidate(law,"J","a","EV",e)
  p=enforcement_proposals(c,law); self.assertTrue(p); self.assertTrue(all(x["authority_required"] for x in p))
if __name__=="__main__": unittest.main()
