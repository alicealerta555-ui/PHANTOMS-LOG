import json
from pathlib import Path
import tempfile
import unittest
from uuid import uuid4

from runtime.stage3a.integration import RuntimeDelta
from runtime.stage3a.kernel import CommitRecord, UnresolvedSpec, WeightedOption
from runtime.stage3d.epistemic import epistemic_stamp
from runtime.stage3c.isolation import (
    FilesystemRunRepository,
    LoadedRunState,
    RunIdentity,
    RunNotFoundError,
    RunSessionManager,
    Stage3CError,
    derive_run_seed,
)


def epi_meta(source="test", t=1):
    return epistemic_stamp(source_type="DIRECT_OBSERVATION", source_id=source, origin_location="TEST", learned_at=t)


class Stage3CIsolationTests(unittest.TestCase):
    def setUp(self):
        self.p1 = str(uuid4())
        self.p2 = str(uuid4())
        self.r1 = str(uuid4())
        self.r2 = str(uuid4())
        self.manager = RunSessionManager(master_seed=20260903)

    def test_identity_requires_uuid(self):
        with self.assertRaises(Stage3CError):
            RunIdentity("player-one", self.r1)
        with self.assertRaises(Stage3CError):
            RunIdentity(self.p1, "run-one")

    def test_same_player_two_runs_have_distinct_stores(self):
        a = self.manager.create_run(player_uuid=self.p1, run_uuid=self.r1)
        b = self.manager.create_run(player_uuid=self.p1, run_uuid=self.r2)
        self.assertIsNot(a.store, b.store)
        a.bridge.commit_runtime_event(
            event_id="E1", cause="move",
            deltas=(RuntimeDelta("RUNTIME_STATE", "position", "A", "RULE_KERNEL", "move"),),
        )
        self.assertEqual(a.store.runtime_state["position"], "A")
        self.assertNotIn("position", b.store.runtime_state)

    def test_two_players_same_event_id_do_not_collide(self):
        a = self.manager.create_run(player_uuid=self.p1, run_uuid=self.r1)
        b = self.manager.create_run(player_uuid=self.p2, run_uuid=self.r2)
        ra = a.bridge.commit_runtime_event(
            event_id="TURN-1", cause="award",
            deltas=(RuntimeDelta("RUNTIME_STATE", "credits", 10, "RULE_KERNEL", "award"),),
        )
        rb = b.bridge.commit_runtime_event(
            event_id="TURN-1", cause="award",
            deltas=(RuntimeDelta("RUNTIME_STATE", "credits", 99, "RULE_KERNEL", "award"),),
        )
        self.assertIsInstance(ra, CommitRecord)
        self.assertIsInstance(rb, CommitRecord)
        self.assertEqual(a.store.runtime_state["credits"], 10)
        self.assertEqual(b.store.runtime_state["credits"], 99)

    def test_unknown_lookup_has_no_fallback(self):
        self.manager.create_run(player_uuid=self.p1, run_uuid=self.r1)
        with self.assertRaises(RunNotFoundError):
            self.manager.get_run(player_uuid=self.p1, run_uuid=self.r2)
        with self.assertRaises(RunNotFoundError):
            self.manager.get_run(player_uuid=self.p2, run_uuid=self.r1)

    def test_run_seed_is_stable_and_isolated(self):
        i1 = RunIdentity(self.p1, self.r1)
        i2 = RunIdentity(self.p1, self.r2)
        self.assertEqual(derive_run_seed(7, i1), derive_run_seed(7, i1))
        self.assertNotEqual(derive_run_seed(7, i1), derive_run_seed(7, i2))
        self.assertNotEqual(derive_run_seed(7, i1), derive_run_seed(8, i1))

    def test_unknown_resolution_does_not_cross_runs(self):
        a = self.manager.create_run(player_uuid=self.p1, run_uuid=self.r1)
        b = self.manager.create_run(player_uuid=self.p1, run_uuid=self.r2)
        spec = UnresolvedSpec("door.enemy", (WeightedOption(True, 1), WeightedOption(False, 1)))
        a.kernel.register_unresolved(spec)
        a.bridge.resolve_unknown("door.enemy", event_id="RES-1")
        self.assertIn("door.enemy", a.store.world_truth)
        self.assertNotIn("door.enemy", b.store.world_truth)
        self.assertNotIn("door.enemy", b.store.unresolved_world)

    def test_attached_store_is_defensively_cloned(self):
        a = self.manager.create_run(player_uuid=self.p1, run_uuid=self.r1)
        a.bridge.commit_runtime_event(
            event_id="E1", cause="x",
            deltas=(RuntimeDelta("RUNTIME_STATE", "x", {"n": 1}, "RULE_KERNEL", "x"),),
        )
        manager2 = RunSessionManager(master_seed=20260903)
        loaded_state = LoadedRunState(a.identity, a.store, derive_run_seed(20260903, a.identity))
        loaded = manager2.attach_loaded_run(loaded_state)
        loaded.store.runtime_state["x"]["n"] = 2
        self.assertEqual(a.store.runtime_state["x"]["n"], 1)

    def test_loaded_state_cannot_be_rebound_to_other_identity(self):
        a = self.manager.create_run(player_uuid=self.p1, run_uuid=self.r1)
        manager2 = RunSessionManager(master_seed=20260903)
        forged = LoadedRunState(RunIdentity(self.p2, self.r2), a.store, a.run_seed)
        with self.assertRaises(Stage3CError):
            manager2.attach_loaded_run(forged)

    def test_filesystem_layout_is_exact_identity(self):
        session = self.manager.create_run(player_uuid=self.p1, run_uuid=self.r1)
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(td)
            path = repo.save(session)
            self.assertEqual(path, Path(td).resolve() / self.p1 / self.r1 / "state.json")
            self.assertTrue(path.is_file())

    def test_save_load_roundtrip_all_domains_and_ledger(self):
        session = self.manager.create_run(player_uuid=self.p1, run_uuid=self.r1)
        session.kernel.register_unresolved(UnresolvedSpec(
            "weather.local", (WeightedOption("dry", 2), WeightedOption("rain", 1)), seed_salt="x"
        ))
        session.bridge.commit_runtime_event(
            event_id="K1", cause="observed",
            deltas=(
                RuntimeDelta("ACTOR_KNOWLEDGE", "alarm", True, "KNOWLEDGE_ROUTER", "heard", actor_id="NPC-X", provenance="OBS:alarm", epistemic=epi_meta("alarm", 6)),
                RuntimeDelta("PLAYER_KNOWLEDGE", "map.mark", "A7", "KNOWLEDGE_ROUTER", "seen", provenance="OBS:map", epistemic=epi_meta("map", 6)),
                RuntimeDelta("RUNTIME_STATE", "position", "A7", "RULE_KERNEL", "move"),
                RuntimeDelta("WORLD_TRUTH", "door.open", True, "RULE_KERNEL", "opened"),
            ),
        )
        before_hash = session.store.state_hash()
        before_rev = session.store.revision
        before_ledger = set(session.store.event_ledger)
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(td)
            repo.save(session)
            manager2 = RunSessionManager(master_seed=20260903)
            loaded = repo.load_session(manager2, session.identity)
            self.assertEqual(loaded.store.state_hash(), before_hash)
            self.assertEqual(loaded.store.revision, before_rev)
            self.assertEqual(set(loaded.store.event_ledger), before_ledger)
            self.assertIn("weather.local", loaded.store.unresolved_world)
            self.assertEqual(loaded.store.runtime_state["position"], "A7")
            self.assertEqual(loaded.store.world_truth["door.open"], True)
            self.assertEqual(loaded.store.actor_knowledge["NPC-X"]["alarm"]["value"], True)

    def test_missing_save_does_not_load_sibling_run(self):
        session = self.manager.create_run(player_uuid=self.p1, run_uuid=self.r1)
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(td)
            repo.save(session)
            with self.assertRaises(RunNotFoundError):
                repo.load_store(RunIdentity(self.p1, self.r2))
            with self.assertRaises(RunNotFoundError):
                repo.load_store(RunIdentity(self.p2, self.r1))

    def test_tampered_identity_rejected(self):
        session = self.manager.create_run(player_uuid=self.p1, run_uuid=self.r1)
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(td)
            path = repo.save(session)
            payload = json.loads(path.read_text())
            payload["identity"]["run_uuid"] = self.r2
            path.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaises(Stage3CError):
                repo.load_store(session.identity)

    def test_tampered_state_hash_rejected(self):
        session = self.manager.create_run(player_uuid=self.p1, run_uuid=self.r1)
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(td)
            path = repo.save(session)
            payload = json.loads(path.read_text())
            payload["store"]["RUNTIME_STATE"]["injected"] = 1
            path.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaises(Stage3CError):
                repo.load_store(session.identity)


    def test_tampered_event_ledger_rejected(self):
        session = self.manager.create_run(player_uuid=self.p1, run_uuid=self.r1)
        session.bridge.commit_runtime_event(
            event_id="E1", cause="x",
            deltas=(RuntimeDelta("RUNTIME_STATE", "x", 1, "RULE_KERNEL", "x"),),
        )
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(td)
            path = repo.save(session)
            payload = json.loads(path.read_text())
            payload["store"]["EVENT_LEDGER"]["E1"]["cause"] = "tampered"
            path.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaises(Stage3CError):
                repo.load_store(session.identity)

    def test_save_root_inside_static_core_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            core = Path(td) / "static_core"
            core.mkdir()
            with self.assertRaises(Stage3CError):
                FilesystemRunRepository(core / "saves", static_core_roots=(core,))

    def test_save_root_sibling_space_outside_static_core_is_allowed(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            core = root / "static_core"
            core.mkdir()
            repo = FilesystemRunRepository(root / "external_saves", static_core_roots=(core,))
            self.assertFalse(str(repo.root).startswith(str(core.resolve())))

    def test_close_removes_exact_run_only(self):
        self.manager.create_run(player_uuid=self.p1, run_uuid=self.r1)
        self.manager.create_run(player_uuid=self.p1, run_uuid=self.r2)
        self.manager.close_run(player_uuid=self.p1, run_uuid=self.r1)
        with self.assertRaises(RunNotFoundError):
            self.manager.get_run(player_uuid=self.p1, run_uuid=self.r1)
        self.assertEqual(self.manager.get_run(player_uuid=self.p1, run_uuid=self.r2).identity.run_uuid, self.r2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
