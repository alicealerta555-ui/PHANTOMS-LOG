from __future__ import annotations

import unittest
from unittest.mock import Mock
from uuid import uuid4

from runtime.stage3a.kernel import (
    Authority,
    CommitKernel,
    Delta,
    Domain,
    Mode,
    Proposal,
    StateStore,
    UnresolvedSpec,
    WeightedOption,
)
from runtime.stage3a.integration import RuntimeAuthorityBridge
from runtime.stage3b.pipeline import (
    ActionPipeline,
    ActionRequest,
    ActionResult,
    ActionRule,
    ActionStatus,
    ActionValidationStatus,
    ActionResolutionStatus,
    Condition,
    Effect,
    FactRef,
    Operator,
    OutcomeBranch,
    RandomDraw,
    ValueSource,
)
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.playable_runtime import PlayableRuntime
from runtime.stage9.validation_resolution import Stage9SplitActionExecutor


def commit_runtime(kernel: CommitKernel, event_id: str, key: str, value: object) -> None:
    kernel.process(
        Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id=event_id,
            cause="TEST",
            deltas=(
                Delta(
                    Domain.RUNTIME_STATE,
                    key,
                    value,
                    Authority.RULE_KERNEL,
                    "TEST",
                    source_event_id=event_id,
                ),
            ),
        )
    )


class Stage9ValidationResolutionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.kernel = CommitKernel(StateStore(), world_seed=9014)
        self.bridge = RuntimeAuthorityBridge(self.kernel)
        self.pipeline = ActionPipeline(self.bridge)
        commit_runtime(self.kernel, "init:energy", "energy", 5)

    @staticmethod
    def _rng_rule(*, with_effect: bool = False) -> ActionRule:
        effects = (
            Effect(Domain.RUNTIME_STATE, "resolved_value", 1, "RULE_KERNEL", "SPLIT_TEST"),
        ) if with_effect else ()
        return ActionRule(
            rule_id="SPLIT_RNG",
            random_draws=(RandomDraw("d20", 1, 20),),
            outcomes=(OutcomeBranch("OK", effects=effects),),
        )

    def test_validation_is_read_only_and_does_not_draw_rng(self) -> None:
        request = ActionRequest("split:validate", self._rng_rule(with_effect=True))
        before_snapshot = self.kernel.store.snapshot()
        before_revision = self.kernel.store.revision
        original = self.pipeline._draw_rng
        draw = Mock(side_effect=original)
        self.pipeline._draw_rng = draw  # type: ignore[method-assign]

        validation = self.pipeline.validate_read_only(request)

        self.assertEqual(validation.status, ActionValidationStatus.ACCEPTED)
        self.assertEqual(validation.state_revision, before_revision)
        self.assertEqual(draw.call_count, 0)
        self.assertEqual(self.kernel.store.snapshot(), before_snapshot)
        self.assertEqual(self.kernel.store.revision, before_revision)

    def test_failed_precondition_blocks_before_rng(self) -> None:
        rule = ActionRule(
            rule_id="BLOCK_BEFORE_RNG",
            facts=(FactRef("energy", Domain.RUNTIME_STATE, "energy"),),
            preconditions=(Condition(ValueSource.FACT, "energy", Operator.GE, 99),),
            random_draws=(RandomDraw("d20", 1, 20),),
            outcomes=(OutcomeBranch("OK"),),
        )
        draw = Mock(side_effect=AssertionError("validation drew RNG"))
        self.pipeline._draw_rng = draw  # type: ignore[method-assign]
        validation = self.pipeline.validate_read_only(ActionRequest("split:block", rule))
        self.assertEqual(validation.status, ActionValidationStatus.BLOCKED)
        self.assertEqual(draw.call_count, 0)

    def test_rng_precondition_is_rejected_explicitly_without_rng_draw(self) -> None:
        rule = ActionRule(
            rule_id="RNG_PRECONDITION",
            random_draws=(RandomDraw("d20", 1, 20),),
            preconditions=(Condition(ValueSource.RNG, "d20", Operator.GE, 10),),
            outcomes=(OutcomeBranch("OK"),),
        )
        draw = Mock(side_effect=AssertionError("validation drew RNG"))
        self.pipeline._draw_rng = draw  # type: ignore[method-assign]
        validation = self.pipeline.validate_read_only(ActionRequest("split:rng-pre", rule))
        self.assertEqual(validation.status, ActionValidationStatus.REJECTED)
        self.assertIn("VALIDATION_RNG_PRECONDITION_FORBIDDEN:d20:GE", validation.reasons)
        self.assertEqual(draw.call_count, 0)

    def test_unresolved_ground_truth_holds_without_materializing_truth(self) -> None:
        self.kernel.register_unresolved(
            UnresolvedSpec(
                "crate_trapped",
                (WeightedOption(True, 1), WeightedOption(False, 1)),
                seed_salt="crate",
            ),
            event_id="init:crate",
        )
        rule = ActionRule(
            rule_id="INSPECT",
            facts=(FactRef("trapped", Domain.WORLD_TRUTH, "crate_trapped", resolve_if_unknown=True),),
            outcomes=(OutcomeBranch("SEEN"),),
        )
        before = self.kernel.store.snapshot()
        validation = self.pipeline.validate_read_only(ActionRequest("split:unknown", rule))
        self.assertEqual(validation.status, ActionValidationStatus.HOLD)
        self.assertTrue(any("VALIDATION_UNRESOLVED_FACT" in r for r in validation.reasons))
        self.assertEqual(self.kernel.store.snapshot(), before)
        self.assertNotIn("crate_trapped", self.kernel.store.world_truth)
        self.assertIn("crate_trapped", self.kernel.store.unresolved_world)

    def test_circumstance_requirement_holds_without_calling_provider(self) -> None:
        provider = Mock()
        provider.resolve_for_action.side_effect = AssertionError("validation resolved circumstance")
        pipeline = ActionPipeline(self.bridge, circumstance_provider=provider)
        rule = ActionRule(
            rule_id="CIRC",
            outcomes=(OutcomeBranch("OK"),),
            requires_circumstance=True,
            circumstance_id="circ:test",
        )
        validation = pipeline.validate_read_only(ActionRequest("split:circ", rule))
        self.assertEqual(validation.status, ActionValidationStatus.HOLD)
        self.assertEqual(provider.resolve_for_action.call_count, 0)

    def test_resolution_draws_rng_and_emits_deltas_without_commit(self) -> None:
        request = ActionRequest("split:resolve", self._rng_rule(with_effect=True))
        validation = self.pipeline.validate_read_only(request)
        before = self.kernel.store.snapshot()
        before_revision = self.kernel.store.revision

        resolution = self.pipeline.resolve_read_only(request, validation)

        self.assertEqual(resolution.status, ActionResolutionStatus.RESOLVED)
        self.assertIn("d20", resolution.rng)
        self.assertEqual(len(resolution.deltas), 1)
        self.assertEqual(resolution.deltas[0].key, "resolved_value")
        self.assertEqual(self.kernel.store.snapshot(), before)
        self.assertEqual(self.kernel.store.revision, before_revision)
        self.assertNotIn("resolved_value", self.kernel.store.runtime_state)

    def test_stale_validation_holds_before_resolution_rng(self) -> None:
        request = ActionRequest("split:stale", self._rng_rule(with_effect=True))
        validation = self.pipeline.validate_read_only(request)
        draw = Mock(side_effect=AssertionError("stale validation drew RNG"))
        self.pipeline._draw_rng = draw  # type: ignore[method-assign]
        commit_runtime(self.kernel, "external:bump", "external", 1)
        revision_after_bump = self.kernel.store.revision

        resolution = self.pipeline.resolve_read_only(request, validation)

        self.assertEqual(resolution.status, ActionResolutionStatus.HOLD)
        self.assertIn("RESOLUTION_STALE_VALIDATION", resolution.reasons)
        self.assertEqual(draw.call_count, 0)
        self.assertEqual(self.kernel.store.revision, revision_after_bump)
        self.assertNotIn("resolved_value", self.kernel.store.runtime_state)

    def test_split_executor_commits_only_after_resolution(self) -> None:
        request = ActionRequest("split:commit", self._rng_rule(with_effect=True))
        executor = Stage9SplitActionExecutor(self.pipeline)
        before_revision = self.kernel.store.revision

        execution = executor.execute(request)

        self.assertEqual(execution.validation.status, ActionValidationStatus.ACCEPTED)
        self.assertIsNotNone(execution.resolution)
        assert execution.resolution is not None
        self.assertEqual(execution.resolution.status, ActionResolutionStatus.RESOLVED)
        self.assertEqual(execution.result.status, ActionStatus.COMMITTED)
        self.assertEqual(self.kernel.store.revision, before_revision + 1)
        self.assertEqual(self.kernel.store.runtime_state["resolved_value"], 1)

    def test_validation_and_resolution_artifacts_are_immutable(self) -> None:
        request = ActionRequest("split:immutable", self._rng_rule())
        validation = self.pipeline.validate_read_only(request)
        resolution = self.pipeline.resolve_read_only(request, validation)
        with self.assertRaises(TypeError):
            validation.facts["x"] = 1  # type: ignore[index]
        with self.assertRaises(TypeError):
            resolution.rng["d20"] = 99  # type: ignore[index]

    def test_playable_runtime_records_split_artifacts_in_transaction(self) -> None:
        player_uuid = str(uuid4())
        run_uuid = str(uuid4())
        manager = RunSessionManager(master_seed=9014)
        session = manager.create_run(player_uuid=player_uuid, run_uuid=run_uuid)
        registry = RunActorRegistry(session)
        identity = RuntimeIdentity(player_uuid, run_uuid, "actor:player")
        registry.register(identity, actor_definition_id="test.player")
        runtime = PlayableRuntime(session, registry)
        context = runtime.create_context(
            identity,
            turn_id="turn:split",
            action_window_id="window:split",
        )
        request = ActionRequest("split:runtime", self._rng_rule())

        receipt = runtime.execute_action(context, request)

        self.assertEqual(receipt.action_result.status, ActionStatus.RESOLVED_NO_CHANGE)
        self.assertEqual(receipt.transaction.validation_status, ActionValidationStatus.ACCEPTED.value)
        self.assertEqual(receipt.transaction.validation_state_revision, context.state_revision)
        self.assertEqual(receipt.transaction.resolution_status, ActionResolutionStatus.RESOLVED.value)
        self.assertEqual(receipt.transaction.resolution_outcome_id, "OK")
        self.assertEqual(receipt.transaction.resolution_rng_names, ("d20",))

    def test_playable_runtime_marks_turn_committing_only_for_real_commit(self) -> None:
        player_uuid = str(uuid4())
        run_uuid = str(uuid4())
        manager = RunSessionManager(master_seed=9015)
        session = manager.create_run(player_uuid=player_uuid, run_uuid=run_uuid)
        registry = RunActorRegistry(session)
        identity = RuntimeIdentity(player_uuid, run_uuid, "actor:player")
        registry.register(identity, actor_definition_id="test.player")
        runtime = PlayableRuntime(session, registry)
        context = runtime.create_context(
            identity,
            turn_id="turn:split-commit",
            action_window_id="window:split-commit",
        )
        request = ActionRequest("split:runtime-commit", self._rng_rule(with_effect=True))

        receipt = runtime.execute_action(context, request)

        self.assertEqual(receipt.action_result.status, ActionStatus.COMMITTED)
        from runtime.stage9.playable_runtime import RuntimeLifecycle
        self.assertIn(RuntimeLifecycle.TURN_COMMITTING, receipt.lifecycle_trace)
        self.assertEqual(receipt.transaction.validation_status, ActionValidationStatus.ACCEPTED.value)
        self.assertEqual(receipt.transaction.resolution_status, ActionResolutionStatus.RESOLVED.value)
        self.assertEqual(receipt.transaction.commit_revision, receipt.revision_after)

    def test_legacy_execute_remains_action_result_with_rng_precondition(self) -> None:
        rule = ActionRule(
            rule_id="LEGACY_RNG_PRECONDITION",
            random_draws=(RandomDraw("d20", 1, 20),),
            preconditions=(Condition(ValueSource.RNG, "d20", Operator.GE, 10),),
            outcomes=(OutcomeBranch("OK"),),
        )
        result = self.pipeline.execute(ActionRequest("legacy:rng-pre", rule))
        self.assertIsInstance(result, ActionResult)
        self.assertEqual(result.status, ActionStatus.BLOCKED)
        self.assertTrue(any("PRECONDITION_FAILED:RNG:d20:GE" in reason for reason in result.reasons))

    def test_validation_reject_schema_never_enters_resolution(self) -> None:
        bad_rule = ActionRule(
            rule_id="BAD",
            preconditions=(Condition(ValueSource.FACT, "undeclared", Operator.EQ, 1),),
            outcomes=(OutcomeBranch("OK"),),
        )
        execution = Stage9SplitActionExecutor(self.pipeline).execute(ActionRequest("split:bad", bad_rule))
        self.assertEqual(execution.validation.status, ActionValidationStatus.REJECTED)
        self.assertIsNone(execution.resolution)
        self.assertEqual(execution.result.status, ActionStatus.REJECTED)


if __name__ == "__main__":
    unittest.main()
