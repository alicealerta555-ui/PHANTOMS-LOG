from runtime.player_progression.habits import DecisionEvent, HabitEngine, HabitRuntimeState, HABIT_BY_ID
from runtime.player_progression.model import PlayerProgressionState
from runtime.player_progression.pipeline import PlayerLearningRuntime


def make_rt():
    return PlayerLearningRuntime(PlayerProgressionState("p", "r", "GHOST"))


def repeat(rt, event, n):
    out = []
    for _ in range(n):
        out.extend(rt.observe_decision(event))
    return out


def test_repeated_safe_decision_forms_habit_then_instinct():
    rt = make_rt()
    event = DecisionEvent("room_entry", "use_cover", category="positioning", context_tags=("unknown",))
    repeat(rt, event, 20)
    rec = rt.habit_state.habits["cover_entry"]
    assert rec.stage == "instinct"


def test_instinct_can_automate_only_safe_routine():
    rt = make_rt()
    repeat(rt, DecisionEvent("room_entry", "use_cover", category="positioning"), 20)
    auto = rt.suggest_instinct_action("room_entry")
    assert auto is not None
    assert auto["choice"] == "use_cover"
    assert "habit_id" not in auto
    assert "strength" not in auto


def test_risky_habit_never_automates():
    rt = make_rt()
    repeat(rt, DecisionEvent("opportunity", "take_risk", category="story_choice", consequence_hint=1.4, risk_hint=1.4), 25)
    assert rt.habit_state.habits["risk_appetite"].stage == "instinct"
    assert rt.suggest_instinct_action("opportunity") is None


def test_player_override_always_wins_but_does_not_erase_training():
    rt = make_rt()
    repeat(rt, DecisionEvent("room_entry", "use_cover", category="positioning"), 20)
    before = rt.habit_state.habits["cover_entry"].strength
    assert rt.override_instinct("cover_entry") is True
    rec = rt.habit_state.habits["cover_entry"]
    assert rec.strength == before
    assert rec.times_overridden == 1
    assert rec.stage == "instinct"


def test_changed_playstyle_makes_old_habit_fade():
    rt = make_rt()
    repeat(rt, DecisionEvent("room_entry", "use_cover", category="positioning"), 14)
    assert rt.habit_state.habits["cover_entry"].stage in {"habit", "instinct"}
    # New choice repeatedly contradicts cover-first routine.
    repeat(rt, DecisionEvent("room_entry", "enter_quietly", category="micro_routine"), 14)
    assert rt.habit_state.habits["cover_entry"].stage in {"fading", "forming"}


def test_bad_habit_is_mild_and_player_facing_text_has_no_numbers():
    rt = make_rt()
    msgs = repeat(rt, DecisionEvent("room_entry", "extended_check", category="perception"), 16)
    visible = rt.visible_habits()
    joined = str(visible)
    assert ("Übervorsicht" in joined) or ("Sicherheitsritual" in joined)
    assert "strength" not in joined
    assert "threshold" not in joined
    assert not any(ch.isdigit() for ch in joined)


def test_non_player_decisions_do_not_learn():
    rt = make_rt()
    repeat(rt, DecisionEvent("room_entry", "use_cover", actor_is_player=False), 30)
    assert "cover_entry" not in rt.habit_state.habits
    assert rt.habit_state.ignored_non_player == 30


def test_habit_state_roundtrip():
    rt = make_rt()
    repeat(rt, DecisionEvent("travel_departure", "check_gear", category="preparation"), 14)
    dumped = rt.to_dict()
    loaded = PlayerLearningRuntime.from_dict(dumped)
    assert loaded.habit_state.habits["field_check"].stage == rt.habit_state.habits["field_check"].stage
    assert loaded.progression.player_uuid == "p"
    assert loaded.progression.run_uuid == "r"


def test_telling_character_to_stop_starts_retraining_not_disable():
    rt = make_rt()
    repeat(rt, DecisionEvent("travel_departure", "check_gear", category="preparation"), 20)
    assert rt.suggest_instinct_action("travel_departure") is not None
    msg = rt.request_habit_retraining("field_check")
    assert msg is not None
    assert "verschwindet nicht sofort" in msg["text"]
    # The learned instinct still exists; a menu-like off switch is intentionally absent.
    assert rt.suggest_instinct_action("travel_departure") is not None
    assert rt.habit_state.habits["field_check"].stage == "instinct"
    assert rt.habit_state.habits["field_check"].retraining_requested is True


def test_retraining_requires_real_counterpractice():
    rt = make_rt()
    repeat(rt, DecisionEvent("room_entry", "use_cover", category="positioning"), 16)
    rt.request_habit_retraining("cover_entry", "enter_quietly")
    # A request alone does not erase the habit.
    assert rt.habit_state.habits["cover_entry"].stage in {"habit", "instinct"}
    # Repeated contrary behavior changes the character over time.
    repeat(rt, DecisionEvent("room_entry", "enter_quietly", category="micro_routine"), 18)
    assert rt.habit_state.habits["cover_entry"].stage in {"fading", "forming"}
