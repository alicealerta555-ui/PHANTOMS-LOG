import pytest
from runtime.full_version.dynamic_mission_generator import DynamicMissionGenerator,DynamicMissionGeneratorError

def test_requires_world_authorized_candidates():
    with pytest.raises(DynamicMissionGeneratorError): DynamicMissionGenerator().choose([],run_uuid='r',context_key='x')

def test_is_run_stable_and_cannot_choose_outside_candidates():
    g=DynamicMissionGenerator(); ids=['A','B','C']
    a=g.choose(ids,run_uuid='run',context_key='site')
    b=g.choose(ids,run_uuid='run',context_key='site')
    assert a==b and a in ids

def test_weights_only_rank_existing_candidates():
    g=DynamicMissionGenerator(); ids=['A','B']
    for n in range(50): assert g.choose(ids,run_uuid=f'r{n}',context_key='x',weights={'A':0,'B':1})=='B'
