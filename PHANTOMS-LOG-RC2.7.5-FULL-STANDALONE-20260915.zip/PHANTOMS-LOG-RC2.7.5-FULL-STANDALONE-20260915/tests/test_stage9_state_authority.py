from __future__ import annotations

import unittest
from uuid import uuid4

from runtime.stage3a.kernel import Authority, Delta, Domain, Mode, Proposal
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import AuthorityStatus, StateAuthority
from runtime.stage9.effects import (
    AuthorityDomain,
    EffectPrecondition,
    EffectProposal,
    EffectType,
    PreconditionType,
)
from runtime.stage9.identity import RuntimeIdentity


class Stage9StateAuthorityTests(unittest.TestCase):
    def setUp(self) -> None:
        self.manager = RunSessionManager(master_seed=20260911)
        self.player_uuid = str(uuid4())
        self.session = self.manager.create_run(player_uuid=self.player_uuid)
        self.registry = RunActorRegistry(self.session)
        self.player_actor = RuntimeIdentity(
            self.player_uuid, self.session.identity.run_uuid, "actor:player"
        )
        self.registry.register(self.player_actor, actor_definition_id="actor-def:player")
        self.authority = StateAuthority(self.session, actor_registry=self.registry)

    def proposal(self, **overrides) -> EffectProposal:
        data = dict(
            effect_id="effect:move:1",
            run_uuid=self.session.identity.run_uuid,
            resolution_id="resolution:1",
            source_action_id="action:1",
            effect_type=EffectType.MOVE_ACTOR,
            target_ref="actor:player",
            payload={
                "actor_instance_id": "actor:player",
                "destination_location_id": "location:room-b",
            },
            authority_domain=AuthorityDomain.ACTOR_STATE,
            expected_state_revision=self.session.store.revision,
        )
        data.update(overrides)
        return EffectProposal(**data)

    def test_allow_returns_semantic_commit_operation(self):
        d = self.authority.authorize(self.proposal())
        self.assertEqual(d.status, AuthorityStatus.ALLOW)
        self.assertTrue(d.allowed)
        self.assertIsNotNone(d.commit_operation)
        self.assertEqual(d.commit_operation.effect_type, EffectType.MOVE_ACTOR)
        self.assertEqual(d.commit_operation.payload["destination_location_id"], "location:room-b")
        self.assertNotIn("state_path", d.commit_operation.as_dict())

    def test_authority_is_read_only(self):
        p = self.proposal()
        before = self.session.store.snapshot()
        before_hash = self.session.store.state_hash()
        before_revision = self.session.store.revision
        d = self.authority.authorize(p)
        self.assertEqual(d.status, AuthorityStatus.ALLOW)
        self.assertEqual(self.session.store.snapshot(), before)
        self.assertEqual(self.session.store.state_hash(), before_hash)
        self.assertEqual(self.session.store.revision, before_revision)

    def test_wrong_run_rejected(self):
        other = self.manager.create_run(player_uuid=self.player_uuid)
        p = self.proposal(run_uuid=other.identity.run_uuid)
        d = self.authority.authorize(p)
        self.assertEqual(d.status, AuthorityStatus.REJECT)
        self.assertEqual(d.reason_codes, ("RUN_ISOLATION_VIOLATION",))
        self.assertIsNone(d.commit_operation)

    def test_stale_revision_is_marked_stale_without_mutation(self):
        current = self.session.store.revision
        p = self.proposal(expected_state_revision=current + 1)
        before = self.session.store.snapshot()
        d = self.authority.authorize(p)
        self.assertEqual(d.status, AuthorityStatus.STALE)
        self.assertEqual(d.reason_codes, ("STALE_STATE_REVISION",))
        self.assertEqual(self.session.store.snapshot(), before)

    def test_unregistered_actor_effect_rejected(self):
        p = self.proposal(
            target_ref="actor:not-registered",
            payload={
                "actor_instance_id": "actor:not-registered",
                "destination_location_id": "location:room-b",
            },
        )
        d = self.authority.authorize(p)
        self.assertEqual(d.status, AuthorityStatus.REJECT)
        self.assertEqual(d.reason_codes, ("ACTOR_NOT_REGISTERED_IN_RUN",))

    def test_write_knowledge_requires_registered_actor(self):
        p = self.proposal(
            effect_id="effect:knowledge:1",
            effect_type=EffectType.WRITE_KNOWLEDGE,
            target_ref="actor:not-registered",
            payload={
                "actor_instance_id": "actor:not-registered",
                "knowledge_key": "door.visible",
                "value": True,
                "provenance": "direct-vision",
                "epistemic": {"source_type": "VISION"},
            },
            authority_domain=AuthorityDomain.KNOWLEDGE,
        )
        d = self.authority.authorize(p)
        self.assertEqual(d.status, AuthorityStatus.REJECT)
        self.assertEqual(d.reason_codes, ("ACTOR_NOT_REGISTERED_IN_RUN",))

    def test_write_knowledge_registered_actor_allowed_but_not_committed(self):
        p = self.proposal(
            effect_id="effect:knowledge:2",
            effect_type=EffectType.WRITE_KNOWLEDGE,
            target_ref="actor:player",
            payload={
                "actor_instance_id": "actor:player",
                "knowledge_key": "door.visible",
                "value": True,
                "provenance": "direct-vision",
                "epistemic": {"source_type": "VISION"},
            },
            authority_domain=AuthorityDomain.KNOWLEDGE,
        )
        before = self.session.store.snapshot()
        d = self.authority.authorize(p)
        self.assertEqual(d.status, AuthorityStatus.ALLOW)
        self.assertEqual(self.session.store.snapshot(), before)
        self.assertNotIn("door.visible", self.session.store.actor_knowledge.get("actor:player", {}))

    def _commit_runtime_entity(self, key: str, value: dict) -> None:
        event_id = f"TEST:AUTHORITY:ENTITY:{key}"
        result = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id=event_id,
            cause="TEST_AUTHORITY_ENTITY",
            deltas=(Delta(
                domain=Domain.RUNTIME_STATE,
                key=key,
                value=value,
                writer=Authority.RULE_KERNEL,
                cause="TEST_AUTHORITY_ENTITY",
                source_event_id=event_id,
            ),),
        ))
        self.assertTrue(hasattr(result, "revision"))

    def test_field_equals_precondition_reads_canonical_state(self):
        self._commit_runtime_entity("door:service", {
            "run_uuid": self.session.identity.run_uuid,
            "state": "CLOSED",
        })
        p = self.proposal(
            effect_id="effect:door:1",
            effect_type=EffectType.SET_DOOR_STATE,
            target_ref="door:service",
            payload={"door_instance_id": "door:service", "new_state": "OPEN"},
            authority_domain=AuthorityDomain.WORLD_OBJECT,
            expected_state_revision=self.session.store.revision,
            preconditions=(EffectPrecondition(
                PreconditionType.FIELD_EQUALS,
                "door:service",
                field="state",
                expected="CLOSED",
            ),),
        )
        d = self.authority.authorize(p)
        self.assertEqual(d.status, AuthorityStatus.ALLOW)
        self.assertEqual(d.validated_preconditions, ("FIELD_EQUALS:door:service:state",))

    def test_failed_precondition_rejects(self):
        self._commit_runtime_entity("door:service", {
            "run_uuid": self.session.identity.run_uuid,
            "state": "OPEN",
        })
        p = self.proposal(
            effect_id="effect:door:2",
            effect_type=EffectType.SET_DOOR_STATE,
            target_ref="door:service",
            payload={"door_instance_id": "door:service", "new_state": "OPEN"},
            authority_domain=AuthorityDomain.WORLD_OBJECT,
            expected_state_revision=self.session.store.revision,
            preconditions=(EffectPrecondition(
                PreconditionType.FIELD_EQUALS,
                "door:service",
                field="state",
                expected="CLOSED",
            ),),
        )
        before = self.session.store.snapshot()
        d = self.authority.authorize(p)
        self.assertEqual(d.status, AuthorityStatus.REJECT)
        self.assertEqual(d.reason_codes, ("PRECONDITION_FIELD_MISMATCH",))
        self.assertEqual(self.session.store.snapshot(), before)

    def test_resource_precondition(self):
        self._commit_runtime_entity("actor:player:resources", {
            "run_uuid": self.session.identity.run_uuid,
            "ammo": 2,
        })
        p = self.proposal(
            effect_id="effect:time:1",
            effect_type=EffectType.ADVANCE_WORLD_TIME,
            target_ref=None,
            payload={"seconds": 1},
            authority_domain=AuthorityDomain.WORLD_TIME,
            expected_state_revision=self.session.store.revision,
            preconditions=(EffectPrecondition(
                PreconditionType.RESOURCE_AT_LEAST,
                "actor:player:resources",
                field="ammo",
                expected=1,
            ),),
        )
        d = self.authority.authorize(p)
        self.assertEqual(d.status, AuthorityStatus.ALLOW)

    def test_authorize_many_does_not_change_revision(self):
        revision = self.session.store.revision
        p1 = self.proposal(effect_id="effect:move:batch1")
        p2 = self.proposal(
            effect_id="effect:time:batch2",
            effect_type=EffectType.ADVANCE_WORLD_TIME,
            target_ref=None,
            payload={"seconds": 1},
            authority_domain=AuthorityDomain.WORLD_TIME,
        )
        decisions = self.authority.authorize_many((p1, p2))
        self.assertEqual([x.status for x in decisions], [AuthorityStatus.ALLOW, AuthorityStatus.ALLOW])
        self.assertEqual(self.session.store.revision, revision)

    def test_invalid_nonproposal_is_fail_closed(self):
        d = self.authority.authorize({"effect_type": "MOVE_ACTOR"})  # type: ignore[arg-type]
        self.assertEqual(d.status, AuthorityStatus.INVALID)
        self.assertEqual(d.reason_codes, ("EFFECT_PROPOSAL_INVALID",))


if __name__ == "__main__":
    unittest.main(verbosity=2)
