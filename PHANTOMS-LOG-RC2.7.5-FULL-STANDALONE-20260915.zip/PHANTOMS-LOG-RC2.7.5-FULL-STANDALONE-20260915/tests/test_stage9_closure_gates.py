from __future__ import annotations
import unittest
from uuid import uuid4

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal, StateStore
from runtime.stage3a.integration import RuntimeAuthorityBridge, RuntimeDelta
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage3d.epistemic import (
    DistortionPolicy, DistortionVariant, EpistemicEngine, InformationGraph, InformationRoute,
    PPM, Stage3DError,
)
from runtime.stage9.actor_context import ActorContextProjector
from runtime.stage9.actor_logic import ActorDecisionKind, DeterministicStubBackend
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import StateAuthority
from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType
from runtime.stage9.gameplay import SemanticCommitAdapter, bootstrap_minimal_world
from runtime.stage9.identity import RuntimeIdentity


class Stage9ClosureMiscGates(unittest.TestCase):
    def test_resource_double_spend_is_idempotent(self):
        m=RunSessionManager(master_seed=12); p=str(uuid4()); s=m.create_run(player_uuid=p); r=RunActorRegistry(s)
        i=RuntimeIdentity(p,s.identity.run_uuid,'actor:player'); r.register(i,actor_definition_id='player')
        r.register(RuntimeIdentity(p,s.identity.run_uuid,'actor:npc'),actor_definition_id='npc')
        bootstrap_minimal_world(s,r)
        # Seed resource through canonical init, then spend once through semantic authority.
        rec=dict(s.store.runtime_state['actor:player']); rec['resources']={'stamina':2}
        init=s.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,event_id='RESOURCE:INIT',cause='RESOURCE_INIT',deltas=(Delta(domain=Domain.RUNTIME_STATE,key='actor:player',value=rec,writer=Authority.SYSTEM_INIT,cause='RESOURCE_INIT',source_event_id='RESOURCE:INIT'),)))
        self.assertIsInstance(init,CommitRecord)
        a=StateAuthority(s,actor_registry=r)
        e=EffectProposal(effect_id='effect:resource:once',run_uuid=s.identity.run_uuid,resolution_id='resolution:resource',source_action_id='action:resource',effect_type=EffectType.RESOURCE_DELTA,target_ref='actor:player',payload={'owner_ref':'actor:player','resource_key':'stamina','delta':-1},authority_domain=AuthorityDomain.RESOURCE,expected_state_revision=s.store.revision)
        d=a.authorize(e); adapter=SemanticCommitAdapter(s,r)
        plan=adapter.prepare_many((d,),commit_id='commit:resource:once',event_id='RESOURCE:SPEND')
        first=adapter.commit(plan); self.assertIsInstance(first,CommitRecord)
        rev=s.store.revision; second=adapter.commit(plan)
        self.assertNotIsInstance(second,CommitRecord)
        self.assertEqual(s.store.runtime_state['actor:player']['resources']['stamina'],1)
        self.assertEqual(s.store.revision,rev)

    def test_communication_requires_causal_channel_not_telepathy(self):
        store=StateStore(); kernel=__import__('runtime.stage3a.kernel',fromlist=['CommitKernel']).CommitKernel(store,world_seed=1)
        bridge=RuntimeAuthorityBridge(kernel)
        graph=InformationGraph((InformationRoute('AB','A','B',5,channel='RADIO'),))
        eng=EpistemicEngine(bridge,run_seed=1,graph=graph)
        with self.assertRaises(Stage3DError):
            eng.queue_actor_relay(message_id='M',source_actor_id='a',target_actor_id='b',fact_key='x',source_location='A',target_location='B',depart_at=0)

    def test_rumour_distortion_never_rewrites_world_truth(self):
        store=StateStore(); kernel=__import__('runtime.stage3a.kernel',fromlist=['CommitKernel']).CommitKernel(store,world_seed=2); bridge=RuntimeAuthorityBridge(kernel)
        graph=InformationGraph((InformationRoute('AB','A','B',1),)); eng=EpistemicEngine(bridge,run_seed=2,graph=graph)
        bridge.commit_runtime_event(event_id='T',cause='truth',deltas=(RuntimeDelta('WORLD_TRUTH','rumour','alpha','RULE_KERNEL','truth'),))
        eng.record_actor_observation(actor_id='a',fact_key='rumour',value='alpha',event_id='O',source_id='eye',location='A',world_time=0)
        q=eng.queue_actor_relay(message_id='R',source_actor_id='a',target_actor_id='b',fact_key='rumour',source_location='A',target_location='B',depart_at=0,distortion_policy=DistortionPolicy((DistortionVariant('misheard',PPM,'beta'),)))
        eng.deliver_due(world_time=q.arrival_at,event_id='D')
        self.assertEqual(store.actor_knowledge['b']['rumour']['value'],'beta')
        self.assertEqual(store.world_truth['rumour'],'alpha')

    def test_faction_or_hostility_metadata_cannot_auto_attack(self):
        m=RunSessionManager(master_seed=3); p=str(uuid4()); s=m.create_run(player_uuid=p); r=RunActorRegistry(s)
        i=RuntimeIdentity(p,s.identity.run_uuid,'actor:npc'); r.register(i,actor_definition_id='npc')
        # Even if the actor knows a hostile faction fact, the deterministic safe backend
        # performs no action unless a policy/backend explicitly chooses one.
        s.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,event_id='K',cause='K',deltas=(Delta(domain=Domain.ACTOR_KNOWLEDGE,key='faction.hostile',value=True,writer=Authority.SYSTEM_INIT,cause='K',source_event_id='K',actor_id='actor:npc',provenance='bootstrap'),)))
        ctx=ActorContextProjector(s,r,i).project()
        decision=DeterministicStubBackend().decide(ctx)
        self.assertEqual(decision.kind,ActorDecisionKind.HOLD)

if __name__=='__main__': unittest.main()
