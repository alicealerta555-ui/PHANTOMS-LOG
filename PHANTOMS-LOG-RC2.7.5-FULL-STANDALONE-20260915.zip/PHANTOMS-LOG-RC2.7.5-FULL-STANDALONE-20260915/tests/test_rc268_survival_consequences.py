import copy
from runtime.full_version.effective_stats import effective_skill, effective_stat, stat_breakdown
from runtime.full_version.capability_catalog import SCHEMA_ID, class_start_stats, class_start_skills

BASE={
    "hp":10,"max_hp":10,"status_flags":[],
    "character_profile":{
        "schema":SCHEMA_ID,
        "stats":class_start_stats("BREAKER"),
        "skills":class_start_skills("BREAKER"),
        "talents":[]
    }
}

def actor(*flags,talents=()):
    a=copy.deepcopy(BASE); a["status_flags"]=list(flags); a["character_profile"]["talents"]=list(talents); return a

def test_survival_never_changes_stored_values_or_hp():
    a=actor("SURV_DEHYDRATION_CRITICAL","SURV_EXHAUSTION_CRITICAL")
    before=copy.deepcopy(a)
    effective_skill(a,"SKILL_FORCE_APPLICATION"); effective_stat(a,"STAT_WIL")
    assert a==before and a["hp"]==10

def test_impaired_hydration_reduces_relevant_skill_but_not_unrelated_skill():
    a=actor("SURV_DEHYDRATION_IMPAIRED")
    assert effective_skill(a,"SKILL_FORCE_APPLICATION")==5
    assert effective_skill(a,"SKILL_NETWORKS")==1

def test_critical_replaces_impaired_instead_of_double_counting_same_need():
    a=actor("SURV_DEHYDRATION_IMPAIRED","SURV_DEHYDRATION_CRITICAL")
    assert effective_skill(a,"SKILL_FORCE_APPLICATION")==4

def test_multiple_needs_stack_but_total_penalty_is_capped():
    a=actor("SURV_DEHYDRATION_CRITICAL","SURV_EXHAUSTION_CRITICAL","SURV_EXPOSURE_CRITICAL")
    b=stat_breakdown(a,"SKILL_ATTENTION",kind="skill")
    assert b["survival_penalty"]==4 and b["effective"]==0

def test_unyielding_mitigates_matching_survival_penalty_only():
    a=actor("SURV_EXHAUSTION_CRITICAL",talents=("TALENT_UNYIELDING",))
    assert stat_breakdown(a,"SKILL_LOAD_CONTROL",kind="skill")=={"base":5,"survival_penalty":2,"talent_mitigation":1,"effective":4}
    assert effective_skill(a,"SKILL_ATTENTION")==0

def test_force_line_mitigates_current_force_pressure_never_above_base():
    healthy=actor(talents=("TALENT_FORCE_LINE",))
    tired=actor("SURV_DEHYDRATION_IMPAIRED",talents=("TALENT_FORCE_LINE",))
    assert effective_skill(healthy,"SKILL_FORCE_APPLICATION")==6
    assert effective_skill(tired,"SKILL_FORCE_APPLICATION")==6

def test_talent_mitigation_never_raises_natural_stat_above_stored_base():
    a=actor("SURV_DEHYDRATION_CRITICAL",talents=("TALENT_FORCE_LINE",))
    assert effective_stat(a,"STAT_STR")==6
    assert stat_breakdown(a,"STAT_STR",kind="stat")["base"]==7
