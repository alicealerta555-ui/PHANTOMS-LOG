import unittest
from dataclasses import fields, replace

from runtime.stage4b import (
    EnvironmentalEnvelope,
    GenelineMatrix,
    GenelineRecord,
    HybridizationProfile,
    KnownBiologicalConstraint,
    LineageProvenance,
    LinkStatus,
    MetabolismProfile,
    MorphologyProfile,
    NumericRange,
    OriginPackageLink,
    RegenerationProfile,
    SensorCapabilityHook,
    StabilityProfile,
    StabilityStatus,
    STAGE5_DETAIL_FIELDS,
    STAGE6_DETAIL_FIELDS,
    validate_geneline_record,
)


def fixture(**changes):
    record = GenelineRecord(
        lineage_id="TEST_LINEAGE_A",
        display_name="Synthetic Test Lineage A",
        origin_packages=OriginPackageLink(),
        morphology=MorphologyProfile(
            body_plan_tags=("bilateral", "limbed"),
            locomotion_hooks=("terrestrial",),
            structural_traits=("reinforced_joint",),
            height_m=NumericRange(1.5, 2.1, "m"),
            mass_kg=NumericRange(50.0, 110.0, "kg"),
        ),
        metabolism=MetabolismProfile(
            strategy_tags=("heterotrophic",),
            thermal_strategy_tags=("regulated",),
            hydration_dependency_tags=("moderate",),
            energetic_cost_tags=("baseline_high",),
        ),
        environment=EnvironmentalEnvelope(
            habitat_tags=("terrestrial", "sheltered"),
            temperature_c=NumericRange(-10.0, 42.0, "C"),
            pressure_kpa=NumericRange(80.0, 110.0, "kPa"),
            oxygen_fraction=NumericRange(0.16, 0.30, "fraction"),
        ),
        regeneration=RegenerationProfile(
            capability_tag="ACCELERATED_TISSUE_REPAIR",
            cost_tags=("high_energy_demand",),
        ),
        sensor_hooks=(
            SensorCapabilityHook("THERMAL_HINT", "thermal", ("coarse_detection",)),
        ),
        stability=StabilityProfile(StabilityStatus.CONTEXT_DEPENDENT, ("nutrient_sensitive",)),
        hybridization=HybridizationProfile(("ANCESTRAL_A", "ANCESTRAL_B"), 2),
        known_constraints=(
            KnownBiologicalConstraint("C_ENERGY", "metabolism", "High repair activity increases energy demand."),
        ),
        provenance=LineageProvenance("B3", "E3", ("SYNTHETIC_TEST_FIXTURE",)),
    )
    return replace(record, **changes)


class Stage4BGenelineMatrixTests(unittest.TestCase):
    def test_valid_record_passes(self):
        validate_geneline_record(fixture())

    def test_matrix_register_get_and_sorted_ids(self):
        matrix = GenelineMatrix()
        b = replace(fixture(), lineage_id="TEST_B", display_name="B")
        a = replace(fixture(), lineage_id="TEST_A", display_name="A")
        matrix.register(b)
        matrix.register(a)
        self.assertEqual(matrix.ids(), ("TEST_A", "TEST_B"))
        self.assertEqual(matrix.get("TEST_A").display_name, "A")

    def test_duplicate_id_fails_closed(self):
        matrix = GenelineMatrix()
        matrix.register(fixture())
        with self.assertRaisesRegex(ValueError, "GENELINE_DUPLICATE_ID"):
            matrix.register(fixture())

    def test_origin_package_pending_until_4c(self):
        record = fixture()
        self.assertEqual(record.origin_packages.status, LinkStatus.PENDING_STAGE_4C)
        self.assertEqual(record.origin_packages.package_refs, ())

    def test_resolved_origin_package_requires_reference(self):
        bad = fixture(origin_packages=OriginPackageLink(LinkStatus.RESOLVED, ()))
        with self.assertRaisesRegex(ValueError, "ORIGIN_PACKAGE_RESOLVED_WITHOUT_REFS"):
            validate_geneline_record(bad)

    def test_pending_origin_package_cannot_smuggle_reference(self):
        bad = fixture(origin_packages=OriginPackageLink(LinkStatus.PENDING_STAGE_4C, ("MAMMAL",)))
        with self.assertRaisesRegex(ValueError, "ORIGIN_PACKAGE_PENDING_WITH_REFS"):
            validate_geneline_record(bad)

    def test_range_rejects_inverted_bounds(self):
        bad = fixture(morphology=replace(fixture().morphology, height_m=NumericRange(2.0, 1.0, "m")))
        with self.assertRaisesRegex(ValueError, "HEIGHT_RANGE:MIN_GT_MAX"):
            validate_geneline_record(bad)

    def test_oxygen_fraction_rejects_impossible_bounds(self):
        bad = fixture(environment=replace(fixture().environment, oxygen_fraction=NumericRange(-0.1, 1.2, "fraction")))
        with self.assertRaisesRegex(ValueError, "OXYGEN_RANGE:OUT_OF_BOUNDS"):
            validate_geneline_record(bad)

    def test_regeneration_requires_cost_or_constraint(self):
        bad = fixture(regeneration=RegenerationProfile("ACCELERATED_TISSUE_REPAIR"))
        with self.assertRaisesRegex(ValueError, "REGENERATION_ADVANTAGE_WITHOUT_COST_OR_CONSTRAINT"):
            validate_geneline_record(bad)

    def test_sensor_hook_is_stage5_placeholder_only(self):
        bad_hook = SensorCapabilityHook("THERMAL_HINT", "thermal", (), detail_owner="STAGE_4B")
        bad = fixture(sensor_hooks=(bad_hook,))
        with self.assertRaisesRegex(ValueError, "SENSOR_DETAIL_OWNER_MUST_BE_STAGE_5"):
            validate_geneline_record(bad)

    def test_hybrid_classification_remains_stage4d(self):
        bad = fixture(hybridization=replace(fixture().hybridization, classification_owner="STAGE_4B"))
        with self.assertRaisesRegex(ValueError, "HYBRID_CLASSIFICATION_OWNER_MUST_BE_STAGE_4D"):
            validate_geneline_record(bad)

    def test_self_source_lineage_rejected(self):
        bad = fixture(hybridization=HybridizationProfile(("TEST_LINEAGE_A",), 1))
        with self.assertRaisesRegex(ValueError, "GENELINE_CANNOT_BE_ITS_OWN_SOURCE"):
            validate_geneline_record(bad)

    def test_provenance_must_be_world_truth(self):
        bad = fixture(provenance=replace(fixture().provenance, authority_domain="PUBLIC_CANON"))
        with self.assertRaisesRegex(ValueError, "GENELINE_PROVENANCE_MUST_BE_WORLD_TRUTH"):
            validate_geneline_record(bad)

    def test_provenance_phase_epoch_must_match_stage4a(self):
        bad = fixture(provenance=LineageProvenance("B2", "E0", ("TEST",)))
        with self.assertRaisesRegex(ValueError, "BIOLOGICAL_PROCESS_NOT_ALLOWED_IN_EPOCH"):
            validate_geneline_record(bad)

    def test_genetic_morality_tag_rejected(self):
        bad = fixture(morphology=replace(fixture().morphology, structural_traits=("morality:evil",)))
        with self.assertRaisesRegex(ValueError, "GENETIC_DETERMINISM_TAG_FORBIDDEN"):
            validate_geneline_record(bad)

    def test_genetic_consent_tag_rejected(self):
        bad = fixture(metabolism=replace(fixture().metabolism, strategy_tags=("consent:automatic",)))
        with self.assertRaisesRegex(ValueError, "GENETIC_DETERMINISM_TAG_FORBIDDEN"):
            validate_geneline_record(bad)

    def test_no_stage5_or_stage6_detail_fields_in_record_schema(self):
        names = {field.name for field in fields(GenelineRecord)}
        self.assertFalse(names.intersection(STAGE5_DETAIL_FIELDS))
        self.assertFalse(names.intersection(STAGE6_DETAIL_FIELDS))

    def test_digest_is_order_independent_for_registration_order(self):
        a = replace(fixture(), lineage_id="A", display_name="A")
        b = replace(fixture(), lineage_id="B", display_name="B")
        left = GenelineMatrix(); left.register(a); left.register(b)
        right = GenelineMatrix(); right.register(b); right.register(a)
        self.assertEqual(left.canonical_digest(), right.canonical_digest())

    def test_unknown_lineage_lookup_fails_closed(self):
        with self.assertRaisesRegex(KeyError, "GENELINE_NOT_FOUND"):
            GenelineMatrix().get("MISSING")


if __name__ == "__main__":
    unittest.main()
