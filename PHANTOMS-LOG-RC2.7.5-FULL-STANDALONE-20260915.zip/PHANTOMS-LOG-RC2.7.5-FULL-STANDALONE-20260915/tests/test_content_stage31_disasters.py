
import json, unittest
from pathlib import Path
from runtime.content_stage31.disasters import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage31_disasters.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_disaster_types(self):
  self.assertGreaterEqual(len(D["disaster_types"]),5)

 def test_disaster_requires_trigger(self):
  self.assertIsNone(disaster_event("DIS_FIRE","L","",0,20,"EV"))

 def test_disaster_authority(self):
  p=disaster_event("DIS_FIRE","L","spark",0,20,"EV")
  self.assertTrue(p["authority_required"])

 def test_propagation_requires_time(self):
  self.assertEqual(propagate_intensity(20,2000,0,0),20)

 def test_propagation_resistance(self):
  a=propagate_intensity(20,2000,60,0)
  b=propagate_intensity(20,2000,60,9000)
  self.assertGreater(a,b)

 def test_connection_required(self):
  self.assertIsNone(propagation_candidate("E","A","B","",60,50,"EV"))

 def test_propagation_authority(self):
  p=propagation_candidate("E","A","B","EDGE",60,50,"EV")
  self.assertTrue(p["authority_required"])

 def test_infrastructure_states(self):
  self.assertEqual(infrastructure_damage_state(100),"INTACT")
  self.assertEqual(infrastructure_damage_state(10),"FAILED")
  self.assertEqual(infrastructure_damage_state(0),"DESTROYED")

 def test_cascade_requires_parent(self):
  self.assertIsNone(cascade_candidate("","DIS_COLLAPSE","L","fire_damage",10,"EV"))

 def test_cascade_authority(self):
  p=cascade_candidate("E1","DIS_COLLAPSE","L","fire_damage",10,"EV")
  self.assertTrue(p["authority_required"])
  self.assertEqual(p["parent_event_id"],"E1")

 def test_evacuation_not_guaranteed(self):
  p=evacuation_proposal("A","B","R",["x"],1,"EV")
  self.assertFalse(p["success_guaranteed"])
  self.assertTrue(p["authority_required"])

if __name__=="__main__": unittest.main()
