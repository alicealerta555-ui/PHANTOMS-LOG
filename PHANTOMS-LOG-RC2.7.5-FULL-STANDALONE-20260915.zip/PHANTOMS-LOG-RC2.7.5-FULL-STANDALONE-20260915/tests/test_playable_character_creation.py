import json, unittest
from pathlib import Path
from runtime.playable_character.character_creation import *
from runtime.playable_character.gameplay_bridge import *
from runtime.full_version.capability_catalog import SCHEMA_ID, STATS, SKILLS, class_start_stats, class_start_skills, class_start_talents

ROOT=Path(__file__).resolve().parents[1]
SCHEMA=json.loads((ROOT/"content/full_version/playable_character_creation_contract.json").read_text())

def base():
 return {
  "name":"Nexus","sex":"m","age":25,"origin":"Randmark – Vorwerk","role":"Überlebender / Arbeitssuchend",
  "stats":class_start_stats("BREAKER"),
  "skills":class_start_skills("BREAKER"),
  "talents":class_start_talents("BREAKER"),
  "location_id":"SET_NEXUS_GATE"
 }

class T(unittest.TestCase):
 def test_schema_mutable(self):
  self.assertEqual(SCHEMA["authority"],"RUNTIME_MUTABLE_RUN_STATE")
  self.assertEqual(SCHEMA["schema_version"],SCHEMA_ID)
  self.assertEqual(SCHEMA["onboarding_policy"]["level_1_start_talent_count"],2)
  self.assertEqual(SCHEMA["onboarding_policy"]["later_level_talent_gain"],1)
  self.assertTrue(SCHEMA["onboarding_policy"]["automatic_class_tutorial_after_creation"])
  self.assertFalse(SCHEMA["onboarding_policy"]["tutorial_grants_progression_or_world_rewards"])
 def test_requires_name(self):
  x=base(); x["name"]=""; self.assertFalse(validate_character_input(x)["ok"])
 def test_stat_bounds(self):
  x=base(); x["stats"]["STAT_STR"]=11; self.assertFalse(validate_character_input(x)["ok"])
 def test_skill_bounds(self):
  x=base(); x["skills"]["SKILL_TECHNOLOGY"]=99; self.assertFalse(validate_character_input(x)["ok"])
 def test_requires_complete_canonical_stat_set(self):
  x=base(); x["stats"].pop("STAT_RES"); self.assertFalse(validate_character_input(x)["ok"])
 def test_requires_complete_canonical_skill_set(self):
  x=base(); x["skills"].pop("SKILL_BALANCE"); self.assertFalse(validate_character_input(x)["ok"])
 def test_create_has_uuids_and_schema(self):
  p=create_character(base(),"PLAYER-1","RUN-1"); s=p["proposal"]["state"]
  self.assertEqual(s["player_uuid"],"PLAYER-1"); self.assertEqual(s["run_uuid"],"RUN-1"); self.assertEqual(s["schema"],SCHEMA_ID)
 def test_creation_authority(self):
  p=create_character(base(),"P","R")["proposal"]; self.assertTrue(p["authority_required"]); self.assertTrue(p["commit_required"])
 def test_commit(self):
  p=create_character(base(),"P","R")["proposal"]; s=committed_character(p,"C1")
  self.assertEqual(s["creation_commit_id"],"C1")
 def test_skills_accessible(self):
  s=committed_character(create_character(base(),"P","R")["proposal"],"C1")
  self.assertEqual(skill_value(s,"SKILL_FORCE_APPLICATION"),6); self.assertIn("SKILL_RESONANCE_SENSE",s["skills"])
 def test_context_contains_full_character_tree(self):
  s=committed_character(create_character(base(),"P","R")["proposal"],"C1")
  c=action_context(s,"Ich untersuche den Raum")
  self.assertTrue(c["ok"]); self.assertEqual(set(c["skills"]),set(SKILLS)); self.assertEqual(set(c["stats"]),set(STATS)); self.assertEqual(c["expertises"],{})
 def test_no_action_before_creation(self):
  self.assertFalse(action_context({}, "look")["ok"])
 def test_gameplay_context_has_location(self):
  s=committed_character(create_character(base(),"P","R")["proposal"],"C1")
  self.assertEqual(gameplay_context(s)["location_id"],"SET_NEXUS_GATE")
 def test_check_inputs(self):
  s=committed_character(create_character(base(),"P","R")["proposal"],"C1")
  c=check_inputs(s,"SKILL_FORCE_APPLICATION","STAT_STR")
  self.assertEqual(c["skill_value"],6); self.assertEqual(c["stat_value"],7)
 def test_expertise_cannot_be_assigned_at_creation(self):
  x=base(); x["expertises"]={"door_lifting":99}; self.assertFalse(validate_character_input(x)["ok"])

if __name__=="__main__": unittest.main()
