from pathlib import Path
import tempfile

from playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority,Domain
from runtime.stage9.world_time import WorldClock
from runtime.full_version.dynamic_world_events import EVENT_STATE_KEY,LIFECYCLE_EVENT_TYPE

ROOT=Path(__file__).resolve().parents[1]

def game():
    td=tempfile.TemporaryDirectory()
    g=FullVersionGame(core_root=ROOT,saves_root=Path(td.name),start_class="OPERATOR",master_seed=20260913)
    g.complete_character(g.creation_template()); g._tmp=td
    return g

def seed_event(g,severity="minor"):
    now=WorldClock(g.session).seconds
    eid=f"world_event:test:{severity}"
    st=g.dynamic_events._state()
    st["events"][eid]={
        "event_id":eid,"event_type":"local_dispute","severity":severity,
        "location_id":g.location(),"created_world_time":now,"status":"MATERIALIZED",
        "causal_tags":["population_present"],"player_targeted":False,"presentation":"UNSEEN",
    }
    g.dynamic_events._commit_state(st,"TEST_DYNAMIC_EVENT")
    sid=g.dynamic_events._schedule_marker(eid,"ACTIVE",now+60)
    return eid,sid

def test_lifecycle_marker_is_canonical_scheduler_state():
    g=game(); eid,sid=seed_event(g)
    marker=g.dynamic_events.queue.get(sid)
    assert marker is not None
    assert marker.event_type==LIFECYCLE_EVENT_TYPE
    assert marker.payload["world_event_id"]==eid

def test_materialized_to_active_to_aftermath_to_expired():
    g=game(); eid,_=seed_event(g,"ambient")
    g.npc_routines.wait(60); g.dynamic_events.process_due_lifecycle()
    assert g.dynamic_events._state()["events"][eid]["status"]=="ACTIVE"
    g.npc_routines.wait(g.dynamic_events.t["lifecycle"]["active_seconds_by_severity"]["ambient"])
    g.dynamic_events.process_due_lifecycle()
    assert g.dynamic_events._state()["events"][eid]["status"]=="AFTERMATH"
    g.npc_routines.wait(g.dynamic_events.t["lifecycle"]["aftermath_seconds_by_severity"]["ambient"])
    g.dynamic_events.process_due_lifecycle()
    assert g.dynamic_events._state()["events"][eid]["status"]=="EXPIRED"
    assert g.dynamic_events.events_at(g.location())==()
    assert g.dynamic_events.events_at(g.location(),include_expired=True)[0]["event_id"]==eid

def test_offscreen_lifecycle_never_grants_player_knowledge():
    g=game(); eid,_=seed_event(g)
    before=dict(g.session.store.actor_knowledge.get("actor:player",{}))
    g.npc_routines.wait(60); g.dynamic_events.process_due_lifecycle()
    after=dict(g.session.store.actor_knowledge.get("actor:player",{}))
    assert before==after
    assert g.dynamic_events._state()["events"][eid]["presentation"]=="UNSEEN"

def test_scheduler_marker_is_consumed_after_transition():
    g=game(); eid,sid=seed_event(g)
    g.npc_routines.wait(60); g.dynamic_events.process_due_lifecycle()
    assert g.dynamic_events.queue.get(sid) is None
    scheduled=[x for x in g.dynamic_events.queue.snapshot().events if x.payload.get("world_event_id")==eid]
    assert len(scheduled)==1 and scheduled[0].payload["phase"]=="AFTERMATH"
