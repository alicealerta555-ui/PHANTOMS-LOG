from __future__ import annotations

import unittest
from uuid import uuid4

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.action_proposal import ActionProposal, ActionSource
from runtime.stage9.actor_logic import DeterministicStubBackend, ModelDecisionValidator
from runtime.stage9.actor_context import ActorContextProjector
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.context import RuntimeContext
from runtime.stage9.event_reentry import EventReentryStatus, ScheduledEventReentry
from runtime.stage9.gameplay import Stage9SemanticActionEngine, SemanticActionStatus, bootstrap_minimal_world
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.save_snapshot import CanonicalSaveSnapshotBuilder
from runtime.stage9.rehydration import Stage9Rehydrator
from runtime.stage9.world_time import WorldClock


class Stage9GoldenPathTests(unittest.TestCase):
    def setUp(self):
        self.seed=9901
        self.m=RunSessionManager(master_seed=self.seed)
        self.player=str(uuid4())
        self.s=self.m.create_run(player_uuid=self.player)
        self.r=RunActorRegistry(self.s)
        self.pi=RuntimeIdentity(self.player,self.s.identity.run_uuid,"actor:player")
        self.ni=RuntimeIdentity(self.player,self.s.identity.run_uuid,"actor:npc")
        self.r.register(self.pi,actor_definition_id="player")
        self.r.register(self.ni,actor_definition_id="npc")
        bootstrap_minimal_world(self.s,self.r)
        self.engine=Stage9SemanticActionEngine(self.s,self.r)
        self.turn=0

    def _ctx(self, identity=None):
        self.turn+=1
        identity=identity or self.pi
        return RuntimeContext.capture(self.s,self.r,identity,turn_id=f"turn:g:{self.turn}",action_window_id=f"window:g:{self.turn}")

    def _proposal(self, ctx, action, *, targets=(), params=None, action_id=None, source=ActionSource.PLAYER_UI):
        return ActionProposal.from_context(ctx,action_id=action_id or f"a:{self.turn}:{action}",input_id=f"i:{self.turn}:{action}",action_type=action,raw_input="",source=source,target_refs=tuple(targets),parameters=params or {})

    def test_basic_interaction_look_take_open_move(self):
        c=self._ctx(); r=self.engine.execute(c,self._proposal(c,"LOOK")); self.assertEqual(r.status,SemanticActionStatus.RESOLVED_NO_CHANGE)
        c=self._ctx(); r=self.engine.execute(c,self._proposal(c,"TAKE",targets=("item:flashlight",))); self.assertEqual(r.status,SemanticActionStatus.COMMITTED)
        self.assertEqual(self.s.store.runtime_state["item:flashlight"]["location_ref"],"inventory:actor:player")
        c=self._ctx(); self.engine.execute(c,self._proposal(c,"OPEN",targets=("door:ab",)))
        self.assertEqual(self.s.store.runtime_state["door:ab"]["state"],"OPEN")
        c=self._ctx(); self.engine.execute(c,self._proposal(c,"MOVE",params={"destination_location_id":"room:b","door_instance_id":"door:ab"}))
        self.assertEqual(self.s.store.runtime_state["actor:player"]["location_ref"],"room:b")
        self.assertEqual(WorldClock(self.s).seconds,3)

    def test_closed_door_move_is_blocked_without_mutation(self):
        before=self.s.store.state_hash(); c=self._ctx(); r=self.engine.execute(c,self._proposal(c,"MOVE",params={"destination_location_id":"room:b","door_instance_id":"door:ab"}))
        self.assertEqual(r.status,SemanticActionStatus.BLOCKED); self.assertEqual(self.s.store.state_hash(),before)

    def test_duplicate_take_cannot_double_spend_item(self):
        c=self._ctx(); self.engine.execute(c,self._proposal(c,"TAKE",targets=("item:flashlight",),action_id="same:take"))
        c2=self._ctx(); r=self.engine.execute(c2,self._proposal(c2,"TAKE",targets=("item:flashlight",),action_id="same:take"))
        self.assertEqual(r.status,SemanticActionStatus.BLOCKED)
        self.assertEqual(self.s.store.runtime_state["item:flashlight"]["location_ref"],"inventory:actor:player")

    def test_combat_ammo_rng_time_noise_and_retry(self):
        # Put player into the NPC room first.
        c=self._ctx(); self.engine.execute(c,self._proposal(c,"OPEN",targets=("door:ab",)))
        c=self._ctx(); self.engine.execute(c,self._proposal(c,"MOVE",params={"destination_location_id":"room:b","door_instance_id":"door:ab"}))
        before_ammo=self.s.store.runtime_state["weapon:pistol"]["ammo"]
        before_hp=self.s.store.runtime_state["actor:npc"]["hp"]
        c=self._ctx(); p=self._proposal(c,"ATTACK",targets=("actor:npc","weapon:pistol"),action_id="combat:stable")
        first=self.engine.execute(c,p)
        self.assertEqual(first.status,SemanticActionStatus.COMMITTED)
        self.assertEqual(self.s.store.runtime_state["weapon:pistol"]["ammo"],before_ammo-1)
        self.assertIn("attack_roll",first.rng)
        if first.outcome_id=="ATTACK_HIT": self.assertLess(self.s.store.runtime_state["actor:npc"]["hp"],before_hp)
        else: self.assertEqual(self.s.store.runtime_state["actor:npc"]["hp"],before_hp)
        # Retry same action id in a fresh action window: no second ammo/damage/time commit.
        state_hash=self.s.store.state_hash(); rev=self.s.store.revision; ammo=self.s.store.runtime_state["weapon:pistol"]["ammo"]
        c2=self._ctx(); p2=self._proposal(c2,"ATTACK",targets=("actor:npc","weapon:pistol"),action_id="combat:stable")
        retry=self.engine.execute(c2,p2)
        self.assertEqual(retry.status,SemanticActionStatus.IDEMPOTENT)
        self.assertEqual(self.s.store.state_hash(),state_hash); self.assertEqual(self.s.store.revision,rev); self.assertEqual(self.s.store.runtime_state["weapon:pistol"]["ammo"],ammo)
        # Noise event is due because attack atomically advanced world time.
        event=ScheduledEventReentry(self.s,actor_registry=self.r).process_next_due()
        self.assertIn(event.status,{EventReentryStatus.COMMITTED_AND_CONSUMED,EventReentryStatus.ALREADY_COMMITTED_AND_CONSUMED})
        self.assertTrue(any(k.startswith("heard_attack:") for k in self.s.store.actor_knowledge.get("actor:npc",{})))

    def test_save_rehydrate_continue_preserves_combat_rng_identity(self):
        c=self._ctx(); self.engine.execute(c,self._proposal(c,"OPEN",targets=("door:ab",)))
        c=self._ctx(); self.engine.execute(c,self._proposal(c,"MOVE",params={"destination_location_id":"room:b","door_instance_id":"door:ab"}))
        snap=CanonicalSaveSnapshotBuilder(self.s).capture()
        fresh=RunSessionManager(master_seed=self.seed)
        rr=Stage9Rehydrator(fresh).rehydrate(snap)
        engine=Stage9SemanticActionEngine(rr.session,rr.actor_registry)
        ctx=RuntimeContext.capture(rr.session,rr.actor_registry,self.pi,turn_id="turn:afterload",action_window_id="window:afterload")
        p=ActionProposal.from_context(ctx,action_id="combat:afterload",input_id="i:combat:afterload",action_type="ATTACK",raw_input="",source=ActionSource.PLAYER_UI,target_refs=("actor:npc","weapon:pistol"))
        a=engine.execute(ctx,p)
        expected=(int.from_bytes(__import__('hashlib').sha256(f"{rr.session.run_seed}|combat:afterload|attack".encode()).digest()[:8],"big")%20)+1
        self.assertEqual(a.rng["attack_roll"],expected)

    def test_npc_stub_action_maps_to_same_action_path(self):
        ctx=self._ctx(self.ni)
        ac=ActorContextProjector(self.s,self.r,self.ni).project()
        cand=DeterministicStubBackend(preferred_action="LOOK").decide(ac)
        prop=ModelDecisionValidator(frozenset({"LOOK"}), "actor:npc").validate_to_action_proposal(ac,ctx,cand)
        self.assertIsNotNone(prop)
        receipt=self.engine.execute(ctx,prop)
        self.assertEqual(receipt.outcome_id,"LOOK_OK")

if __name__ == '__main__': unittest.main()
