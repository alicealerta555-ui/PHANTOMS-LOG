
import json, unittest
from pathlib import Path
from runtime.content_stage36.demographics import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage36_demographics.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_cohorts(self):
  self.assertGreaterEqual(len(D["age_cohorts"]),5)

 def test_age_progression(self):
  self.assertEqual(age_years(0,365*1440),1)

 def test_cohort_mapping(self):
  self.assertEqual(cohort_for_age(1),"COHORT_INFANT")
  self.assertEqual(cohort_for_age(25),"COHORT_ADULT")
  self.assertEqual(cohort_for_age(70),"COHORT_ELDER")

 def test_projection_nonnegative(self):
  self.assertGreaterEqual(cohort_projection(10,0,10000,0,0,365),0)

 def test_birth_requires_parents(self):
  self.assertIsNone(birth_candidate("new",[],"H","L",1,"EV"))

 def test_birth_authority(self):
  p=birth_candidate("new",["a","b"],"H","L",1,"EV")
  self.assertTrue(p["authority_required"])

 def test_mortality_aggregate_not_named(self):
  p=mortality_pressure_candidate("R","COHORT_ADULT",500,"disease",30,"EV")
  self.assertFalse(p["affects_named_actors_directly"])
  self.assertTrue(p["authority_required"])

 def test_mortality_requires_time(self):
  self.assertIsNone(mortality_pressure_candidate("R","COHORT_ADULT",500,"disease",0,"EV"))

 def test_named_death_requires_event(self):
  self.assertIsNone(death_record("a","",100,"cause"))
  d=death_record("a","DEATH1",100,"cause")
  self.assertTrue(d["authoritative_event_required"])

 def test_generation_snapshot(self):
  g=generation_snapshot("G1",0,100,["C1"])
  self.assertTrue(g["historical_provenance_required"])

 def test_invalid_generation_range(self):
  self.assertIsNone(generation_snapshot("G1",100,0,[]))

if __name__=="__main__": unittest.main()
