
import json,unittest
from pathlib import Path
from runtime.content_stage15.aftermath import *
ROOT=Path(__file__).resolve().parents[1]; D=json.loads((ROOT/"content/full_version/stage15_aftermath.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_injuries(self): self.assertGreaterEqual(len(D["injury_templates"]),4)
 def test_distinct_states(self): self.assertIn("UNCONSCIOUS",D["condition_states"]); self.assertIn("DEAD",D["condition_states"])
 def test_condition(self):
  self.assertEqual(condition_from_vitals(0),"DEAD"); self.assertEqual(condition_from_vitals(10),"INCAPACITATED"); self.assertEqual(condition_from_vitals(80),"ACTIVE")
 def test_unconscious(self): self.assertEqual(condition_from_vitals(80,False),"UNCONSCIOUS")
 def test_recovery_time(self):
  self.assertLess(recovery_progress(100,1000),recovery_progress(500,1000))
 def test_treatment_helps(self):
  self.assertGreater(recovery_progress(100,1000,True,True),recovery_progress(100,1000,True,False))
 def test_death_authority(self):
  self.assertIsNone(death_proposal("a","EV",1)); p=death_proposal("a","EV",0); self.assertTrue(p["authority_required"]); self.assertTrue(p["permadeath"])
 def test_injury_authority(self):
  p=injury_proposal(D["injury_templates"][0],"a","EV"); self.assertTrue(p["authority_required"]); self.assertEqual(p["causal_event_id"],"EV")
 def test_aftermath_causal(self):
  p=aftermath_proposals("a","EV",D["aftermath_domains"]); self.assertTrue(all(x["causal_event_id"]=="EV" and x["authority_required"] for x in p))
 def test_no_auto_resurrection(self): self.assertFalse(D["death"]["automatic_resurrection"])
if __name__=="__main__": unittest.main()
