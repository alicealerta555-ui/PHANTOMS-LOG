from __future__ import annotations

import unittest
from dataclasses import replace
from uuid import uuid4

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.rehydration import Stage9RehydrationError, Stage9Rehydrator
from runtime.stage9.save_snapshot import CanonicalSaveSnapshotBuilder
from runtime.stage9.world_time import WorldClock


class Stage9RehydrationTests(unittest.TestCase):
    def setUp(self):
        self.seed = 424242
        self.manager = RunSessionManager(master_seed=self.seed)
        self.player = str(uuid4())
        self.session = self.manager.create_run(player_uuid=self.player)
        self.identity = RuntimeIdentity(self.player, self.session.identity.run_uuid, "actor:player")
        self.registry = RunActorRegistry(self.session)
        self.registry.register(self.identity, actor_definition_id="actor-def:player")
        self.session.kernel.process(Proposal(
            mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL,
            event_id="REHYDRATE:STATE:1", cause="TEST",
            deltas=(Delta(domain=Domain.RUNTIME_STATE, key="test:key", value={"n": 7},
                          writer=Authority.RULE_KERNEL, cause="TEST", source_event_id="REHYDRATE:STATE:1"),),
        ))
        self.snapshot = CanonicalSaveSnapshotBuilder(self.session).capture()

    def _fresh(self):
        return RunSessionManager(master_seed=self.seed)

    def test_snapshot_rehydrate_snapshot_byte_identical(self):
        runtime = Stage9Rehydrator(self._fresh()).rehydrate(self.snapshot)
        self.assertEqual(runtime.canonical_snapshot.canonical_json, self.snapshot.canonical_json)
        self.assertEqual(runtime.session.store.revision, self.snapshot.state_revision)
        self.assertEqual(runtime.session.store.state_hash(), self.snapshot.state_hash)

    def test_rehydration_is_side_effect_free(self):
        runtime = Stage9Rehydrator(self._fresh()).rehydrate(self.snapshot)
        self.assertEqual(runtime.session.store.revision, self.session.store.revision)
        self.assertEqual(len(runtime.session.store.event_ledger), len(self.session.store.event_ledger))
        self.assertEqual(WorldClock(runtime.session).seconds, WorldClock(self.session).seconds)

    def test_handles_are_fresh_and_bound_to_new_session(self):
        runtime = Stage9Rehydrator(self._fresh()).rehydrate(self.snapshot)
        self.assertIsNot(runtime.session, self.session)
        self.assertIsNot(runtime.session.store, self.session.store)
        self.assertEqual(runtime.actor_registry.run_identity, runtime.session.identity)
        self.assertEqual(runtime.world_clock.run_uuid, runtime.session.identity.run_uuid)
        self.assertEqual(runtime.scheduler_queue.run_uuid, runtime.session.identity.run_uuid)

    def test_repeated_rehydration_has_no_drift(self):
        one = Stage9Rehydrator(self._fresh()).rehydrate(self.snapshot)
        snap2 = CanonicalSaveSnapshotBuilder(one.session).capture()
        two = Stage9Rehydrator(self._fresh()).rehydrate(snap2)
        self.assertEqual(two.canonical_snapshot.canonical_json, self.snapshot.canonical_json)

    def test_wrong_master_seed_rejected(self):
        with self.assertRaisesRegex(Stage9RehydrationError, "RUN_SEED_MISMATCH"):
            Stage9Rehydrator(RunSessionManager(master_seed=self.seed + 1)).rehydrate(self.snapshot)

    def test_tampered_attribute_rejected(self):
        forged = replace(self.snapshot, state_revision=self.snapshot.state_revision + 1)
        with self.assertRaisesRegex(Stage9RehydrationError, "ATTRIBUTE_MISMATCH"):
            Stage9Rehydrator(self._fresh()).rehydrate(forged)

    def test_noncanonical_json_rejected(self):
        forged = replace(self.snapshot, canonical_json=b"{}")
        with self.assertRaises(Stage9RehydrationError):
            Stage9Rehydrator(self._fresh()).rehydrate(forged)

    def test_duplicate_open_run_rejected(self):
        manager = self._fresh()
        Stage9Rehydrator(manager).rehydrate(self.snapshot)
        with self.assertRaisesRegex(Stage9RehydrationError, "RUN_ALREADY_OPEN"):
            Stage9Rehydrator(manager).rehydrate(self.snapshot)


if __name__ == "__main__":
    unittest.main()
