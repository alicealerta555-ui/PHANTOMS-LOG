from runtime.player_progression import PlayerProgressionState, PlayerLearningRuntime
from runtime.player_progression.adaptive_runtime import AdaptiveGameplayRuntime
from runtime.player_progression.npc_psychology import PsychologicalSnapshot, SupportContext
from runtime.player_progression.npc_memory import MemoryEvent
from runtime.player_progression.npc_social_life import NPCSocialActor, SocialLifeContext

def runtime():
    p=PlayerProgressionState(player_uuid='p',run_uuid='r',start_class='OPERATOR')
    return AdaptiveGameplayRuntime.new(PlayerLearningRuntime(p))

def test_all_new_npc_layers_roundtrip_in_host_runtime():
    rt=runtime()
    rt.support_npc(PsychologicalSnapshot('n',trust=.5,trigger_tags=('tunnel',)), SupportContext(1,player_listens=True,context_tags=('tunnel',)))
    rt.record_npc_memory(MemoryEvent('n','rescue',2,'player helped',emotion=1,relationship_effect=1))
    rt.npc_to_npc_moment(NPCSocialActor('n',interests=('tech',)),NPCSocialActor('m',interests=('tech',)),SocialLifeContext(3))
    payload=rt.snapshot_for_save()
    assert payload['schema_version']==6
    restored=AdaptiveGameplayRuntime.from_save(payload)
    assert restored.npc_psychology.state_for('n').themes
    assert restored.npc_memory.state_for('n').long_term or restored.npc_memory.state_for('n').recent
    assert restored.npc_social_life.edge('n','m') is not None
