from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from uuid import uuid4

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal, ValidationResult, Verdict
from runtime.stage3c.isolation import FilesystemRunRepository, RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import AuthorityStatus, StateAuthority
from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.world_time import (
    MAX_WORLD_TIME_SECONDS,
    WORLD_TIME_RUNTIME_KEY,
    Stage9WorldTimeError,
    WorldClock,
    WorldTimeCommitAdapter,
)


class Stage9CanonicalWorldTimeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.manager = RunSessionManager(master_seed=20260911)
        self.player_uuid = str(uuid4())
        self.session = self.manager.create_run(player_uuid=self.player_uuid)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(
            self.player_uuid,
            self.session.identity.run_uuid,
            "actor:player",
        )
        self.registry.register(self.identity, actor_definition_id="actor-def:player")
        self.authority = StateAuthority(self.session, actor_registry=self.registry)
        self.clock = WorldClock(self.session)
        self.adapter = WorldTimeCommitAdapter(self.session)

    def _decision(self, seconds: int = 5, effect_id: str = "effect:time:1"):
        p = EffectProposal(
            effect_id=effect_id,
            run_uuid=self.session.identity.run_uuid,
            resolution_id="resolution:time:1",
            source_action_id="action:time:1",
            effect_type=EffectType.ADVANCE_WORLD_TIME,
            target_ref=None,
            payload={"seconds": seconds},
            authority_domain=AuthorityDomain.WORLD_TIME,
            expected_state_revision=self.session.store.revision,
        )
        d = self.authority.authorize(p)
        self.assertEqual(d.status, AuthorityStatus.ALLOW)
        return d

    def test_fresh_run_reads_zero_without_bootstrap_commit(self):
        before_revision = self.session.store.revision
        before_hash = self.session.store.state_hash()
        snap = self.clock.snapshot()
        self.assertEqual(snap.seconds, 0)
        self.assertEqual(snap.run_uuid, self.session.identity.run_uuid)
        self.assertEqual(snap.state_revision, before_revision)
        self.assertNotIn(WORLD_TIME_RUNTIME_KEY, self.session.store.runtime_state)
        self.assertEqual(self.session.store.revision, before_revision)
        self.assertEqual(self.session.store.state_hash(), before_hash)

    def test_authorized_effect_advances_exactly_once(self):
        before_revision = self.session.store.revision
        plan = self.adapter.prepare(self._decision(7), commit_id="commit:time:1", event_id="TIME:E1")
        self.assertEqual(plan.from_seconds, 0)
        self.assertEqual(plan.to_seconds, 7)
        self.assertEqual(self.clock.seconds, 0)
        result = self.adapter.commit(plan)
        self.assertIsInstance(result, CommitRecord)
        self.assertEqual(self.clock.seconds, 7)
        self.assertEqual(self.session.store.revision, before_revision + 1)

    def test_time_is_monotonic_across_multiple_commits(self):
        self.assertIsInstance(
            self.adapter.advance(self._decision(3, "effect:t1"), commit_id="commit:t1", event_id="TIME:T1"),
            CommitRecord,
        )
        self.assertEqual(self.clock.seconds, 3)
        self.assertIsInstance(
            self.adapter.advance(self._decision(11, "effect:t2"), commit_id="commit:t2", event_id="TIME:T2"),
            CommitRecord,
        )
        self.assertEqual(self.clock.seconds, 14)

    def test_replay_same_prepared_plan_is_idempotent(self):
        plan = self.adapter.prepare(self._decision(9), commit_id="commit:retry", event_id="TIME:RETRY")
        first = self.adapter.commit(plan)
        self.assertIsInstance(first, CommitRecord)
        revision = self.session.store.revision
        state_hash = self.session.store.state_hash()
        second = self.adapter.commit(plan)
        self.assertIsInstance(second, ValidationResult)
        self.assertEqual(second.verdict, Verdict.HOLD)
        self.assertIn("DUPLICATE_COMMIT_IDEMPOTENT_SKIP", second.reasons)
        self.assertEqual(self.clock.seconds, 9)
        self.assertEqual(self.session.store.revision, revision)
        self.assertEqual(self.session.store.state_hash(), state_hash)

    def test_stale_authority_decision_cannot_prepare_time_commit(self):
        decision = self._decision(5, "effect:stale")
        other = Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id="TIME:OTHER",
            cause="TEST_OTHER_STATE",
            deltas=(Delta(
                domain=Domain.RUNTIME_STATE,
                key="other:key",
                value=1,
                writer=Authority.RULE_KERNEL,
                cause="TEST_OTHER_STATE",
                source_event_id="TIME:OTHER",
            ),),
        )
        self.assertIsInstance(self.session.kernel.process(other), CommitRecord)
        with self.assertRaisesRegex(Stage9WorldTimeError, "STALE_STATE_REVISION"):
            self.adapter.prepare(decision, commit_id="commit:stale", event_id="TIME:STALE")
        self.assertEqual(self.clock.seconds, 0)

    def test_generic_rule_writer_cannot_write_reserved_world_time_key(self):
        before = self.session.store.state_hash()
        result = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id="TIME:ROGUE",
            cause="ROGUE_TIME_WRITE",
            deltas=(Delta(
                domain=Domain.RUNTIME_STATE,
                key=WORLD_TIME_RUNTIME_KEY,
                value={"run_uuid": self.session.identity.run_uuid, "seconds": 99},
                writer=Authority.RULE_KERNEL,
                cause="ROGUE_TIME_WRITE",
                source_event_id="TIME:ROGUE",
            ),),
        ))
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertIn("WORLD_TIME_WRITER_REQUIRED", result.reasons)
        self.assertEqual(self.session.store.state_hash(), before)
        self.assertEqual(self.clock.seconds, 0)

    def test_kernel_rejects_non_monotonic_world_time_even_for_world_time_writer(self):
        self.assertIsInstance(
            self.adapter.advance(self._decision(8), commit_id="commit:mono", event_id="TIME:MONO:1"),
            CommitRecord,
        )
        result = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id="TIME:MONO:2",
            cause="TEST_NON_MONOTONIC",
            deltas=(Delta(
                domain=Domain.RUNTIME_STATE,
                key=WORLD_TIME_RUNTIME_KEY,
                value={"run_uuid": self.session.identity.run_uuid, "seconds": 7},
                writer=Authority.WORLD_TIME,
                cause="TEST_NON_MONOTONIC",
                source_event_id="TIME:MONO:2",
            ),),
        ))
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertIn("WORLD_TIME_NOT_MONOTONIC", result.reasons)
        self.assertEqual(self.clock.seconds, 8)

    def test_run_isolation(self):
        other = self.manager.create_run(player_uuid=self.player_uuid)
        other_clock = WorldClock(other)
        self.adapter.advance(self._decision(4), commit_id="commit:iso", event_id="TIME:ISO")
        self.assertEqual(self.clock.seconds, 4)
        self.assertEqual(other_clock.seconds, 0)
        self.assertNotIn(WORLD_TIME_RUNTIME_KEY, other.store.runtime_state)

    def test_save_load_preserves_world_time_without_load_advance(self):
        self.adapter.advance(self._decision(37), commit_id="commit:persist", event_id="TIME:PERSIST")
        expected_revision = self.session.store.revision
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(Path(td))
            repo.save(self.session)
            self.manager.close_run(
                player_uuid=self.session.identity.player_uuid,
                run_uuid=self.session.identity.run_uuid,
            )
            loaded = repo.load_session(self.manager, self.session.identity)
            loaded_clock = WorldClock(loaded)
            self.assertEqual(loaded_clock.seconds, 37)
            self.assertEqual(loaded.store.revision, expected_revision)
            # Repeated reads/re-hydration access do not advance time or revision.
            self.assertEqual(loaded_clock.seconds, 37)
            self.assertEqual(loaded.store.revision, expected_revision)

    def test_wrong_effect_type_is_rejected_by_time_adapter(self):
        p = EffectProposal(
            effect_id="effect:not-time",
            run_uuid=self.session.identity.run_uuid,
            resolution_id="resolution:not-time",
            source_action_id="action:not-time",
            effect_type=EffectType.MOVE_ACTOR,
            target_ref="actor:player",
            payload={"actor_instance_id": "actor:player", "destination_location_id": "room:b"},
            authority_domain=AuthorityDomain.ACTOR_STATE,
            expected_state_revision=self.session.store.revision,
        )
        d = self.authority.authorize(p)
        self.assertEqual(d.status, AuthorityStatus.ALLOW)
        with self.assertRaisesRegex(Stage9WorldTimeError, "WORLD_TIME_EFFECT_TYPE_REQUIRED"):
            self.adapter.prepare(d, commit_id="commit:not-time", event_id="TIME:NOTTIME")

    def test_reads_and_external_delay_do_not_advance_time(self):
        revision = self.session.store.revision
        first = self.clock.snapshot()
        second = self.clock.snapshot()
        self.assertEqual(first.seconds, second.seconds)
        self.assertEqual(first.state_revision, second.state_revision)
        self.assertEqual(self.session.store.revision, revision)

    def test_overflow_is_fail_closed(self):
        # A direct first write using the dedicated producer is structurally legal and lets
        # us exercise the adapter overflow boundary without billions of advances.
        result = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id="TIME:MAX:INIT",
            cause="TEST_MAX_TIME",
            deltas=(Delta(
                domain=Domain.RUNTIME_STATE,
                key=WORLD_TIME_RUNTIME_KEY,
                value={"run_uuid": self.session.identity.run_uuid, "seconds": MAX_WORLD_TIME_SECONDS},
                writer=Authority.WORLD_TIME,
                cause="TEST_MAX_TIME",
                source_event_id="TIME:MAX:INIT",
            ),),
        ))
        self.assertIsInstance(result, CommitRecord)
        with self.assertRaisesRegex(Stage9WorldTimeError, "WORLD_TIME_OVERFLOW"):
            self.adapter.prepare(self._decision(1, "effect:overflow"), commit_id="commit:overflow", event_id="TIME:OVERFLOW")


if __name__ == "__main__":
    unittest.main(verbosity=2)
