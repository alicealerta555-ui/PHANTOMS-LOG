from runtime.player_progression.class_abilities import ABILITIES, POOLS, visible_abilities, visible_pool_ids, bounded_context_bonus


def test_all_pools_have_twenty_choices():
    assert POOLS
    assert all(len(ids)==20 for ids in POOLS.values())


def test_base_visibility_is_hard_class_filtered():
    for cls in ('BREAKER','GHOST','OPERATOR','RESONANT'):
        defs=visible_abilities(cls,1)
        assert len(defs)==20
        assert all(d.pool_id==f'{cls}:BASE' for d in defs)
        assert all(d.owner==cls for d in defs)


def test_resonant_does_not_expose_operator_base():
    ids={d.ability_id for d in visible_abilities('RESONANT',1)}
    assert ids
    assert not any(x.startswith('operator_') for x in ids)
    assert 'resonant_base_11' in ids  # Magnetic Sense


def test_specialization_and_mastery_unlocks_are_path_bound():
    pools=visible_pool_ids('RESONANT',40,'FLUX','RESONANT_TO_OPERATOR',None)
    assert pools==('RESONANT:BASE','FLUX:T10','FLUX:T20','RESONANT_TO_OPERATOR:T30','RESONANT_TO_OPERATOR:T40')
    assert 'SEER:T10' not in pools
    assert 'OPERATOR:BASE' not in pools


def test_context_bonus_does_not_stack_without_bound():
    owned=['resonant_base_15','resonant_base_19']
    assert bounded_context_bonus(owned,'dialogue')==1


def test_npc_policy_is_non_coercive():
    assert all(d.npc_policy=='NO_FORCED_COMPLIANCE' for d in ABILITIES.values())
