import unittest
from dataclasses import fields, replace

from runtime.stage4b import (
    EnvironmentalEnvelope, GenelineRecord, HybridizationProfile, KnownBiologicalConstraint,
    LineageProvenance, MetabolismProfile, MorphologyProfile, OriginPackageLink,
    RegenerationProfile, StabilityProfile, STAGE5_DETAIL_FIELDS, STAGE6_DETAIL_FIELDS,
)
from runtime.stage4c import bind_origin_packages, build_canonical_origin_registry
from runtime.stage4d import (
    CoherenceAssessment, CoherenceStatus, ExpressionPartition, HybridClass,
    HybridCompositionProvenance, HybridCompositionRecord, HybridCompositionRegistry,
    HybridSourceComponent, IntegrationMode, IntegrationNode, TraitCandidateRef,
    apply_hybrid_composition, classify_hybrid, validate_hybrid_composition,
)


def base_lineage(lineage_id="TEST_4D", source_refs=()):
    return GenelineRecord(
        lineage_id=lineage_id,
        display_name="Stage 4D fixture",
        origin_packages=OriginPackageLink(),
        morphology=MorphologyProfile(("bilateral",), ("terrestrial",), ("fixture",)),
        metabolism=MetabolismProfile(("heterotrophic",), energetic_cost_tags=("finite",)),
        environment=EnvironmentalEnvelope(("temperate",)),
        regeneration=RegenerationProfile("NONE"),
        sensor_hooks=(),
        stability=StabilityProfile(),
        hybridization=HybridizationProfile(tuple(source_refs), 0),
        known_constraints=(KnownBiologicalConstraint("C4D", "fixture", "Finite biological resources."),),
        provenance=LineageProvenance("B3", "E3", ("STAGE4D_TEST",)),
    )


def bound_lineage(package_refs, source_refs=(), lineage_id="TEST_4D"):
    registry = build_canonical_origin_registry()
    return bind_origin_packages(base_lineage(lineage_id, source_refs), tuple(package_refs), registry), registry


def candidate(registry, component_id, package_id, index=0):
    contribution = registry.get(package_id).contributions[index]
    return TraitCandidateRef(component_id, package_id, contribution.contribution_id)


def composition(lineage, components, nodes=(), root_ref=None, expression=None, coherence=None):
    return HybridCompositionRecord(
        lineage_id=lineage.lineage_id,
        components=tuple(components),
        integration_nodes=tuple(nodes),
        root_ref=root_ref or components[0].component_id,
        expression=expression or ExpressionPartition(),
        coherence=coherence or CoherenceAssessment(),
        provenance=HybridCompositionProvenance(("STAGE4D_TEST",)),
    )


class Stage4DHybridClassificationTests(unittest.TestCase):
    def test_mono_is_one_independent_source_complex_not_one_package(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_SYNTHETIC_BIOLOGY_PLATFORM")
        lineage, registry = bound_lineage(refs)
        comp = composition(lineage, (HybridSourceComponent("A", "SRC_A", refs),))
        result = classify_hybrid(lineage, comp, registry)
        self.assertEqual(result.hybrid_class, HybridClass.MONO)
        self.assertEqual(result.independent_source_count, 1)
        self.assertEqual(result.integration_depth, 0)

    def test_same_package_can_belong_to_two_independent_sources(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS",)
        lineage, registry = bound_lineage(refs)
        comps = (
            HybridSourceComponent("A", "SRC_A", refs),
            HybridSourceComponent("B", "SRC_B", refs),
        )
        node = IntegrationNode("H", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("A", "B"))
        result = classify_hybrid(lineage, composition(lineage, comps, (node,), "H"), registry)
        self.assertEqual(result.hybrid_class, HybridClass.MULTI)
        self.assertEqual(result.independent_source_count, 2)

    def test_many_direct_sources_are_multi_not_automatically_poly(self):
        lineage, registry = bound_lineage(build_canonical_origin_registry().ids())
        comps = tuple(
            HybridSourceComponent(f"C{i}", f"SRC_{i}", (pkg,))
            for i, pkg in enumerate(registry.ids())
        )
        node = IntegrationNode("H", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, tuple(c.component_id for c in comps))
        result = classify_hybrid(lineage, composition(lineage, comps, (node,), "H"), registry)
        self.assertEqual(result.hybrid_class, HybridClass.MULTI)
        self.assertEqual(result.independent_source_count, 8)
        self.assertEqual(result.integration_depth, 1)

    def test_nested_three_source_ancestry_is_poly(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL", "ORG_AVIAN_RESPIRATORY_STRUCTURAL")
        lineage, registry = bound_lineage(refs)
        comps = (
            HybridSourceComponent("A", "SRC_A", (refs[0],)),
            HybridSourceComponent("B", "SRC_B", (refs[1],)),
            HybridSourceComponent("C", "SRC_C", (refs[2],)),
        )
        nodes = (
            IntegrationNode("H1", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("A", "B")),
            IntegrationNode("H2", "B3", "E3", IntegrationMode.REPEATED_MIXING, ("H1", "C")),
        )
        result = classify_hybrid(lineage, composition(lineage, comps, nodes, "H2"), registry)
        self.assertEqual(result.hybrid_class, HybridClass.POLY)
        self.assertEqual(result.integration_depth, 2)

    def test_two_source_nested_backcross_remains_multi(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL")
        lineage, registry = bound_lineage(refs)
        comps = (
            HybridSourceComponent("A", "SRC_A", (refs[0],)),
            HybridSourceComponent("B", "SRC_B", (refs[1],)),
        )
        nodes = (
            IntegrationNode("H1", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("A", "B")),
            IntegrationNode("H2", "B3", "E3", IntegrationMode.REPEATED_MIXING, ("H1", "A")),
        )
        result = classify_hybrid(lineage, composition(lineage, comps, nodes, "H2"), registry)
        self.assertEqual(result.hybrid_class, HybridClass.MULTI)
        self.assertEqual(result.integration_depth, 2)

    def test_expression_visibility_does_not_change_class(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL")
        lineage, registry = bound_lineage(refs)
        comps = (
            HybridSourceComponent("A", "SRC_A", (refs[0],)),
            HybridSourceComponent("B", "SRC_B", (refs[1],)),
        )
        node = IntegrationNode("H", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("A", "B"))
        blank = composition(lineage, comps, (node,), "H")
        active = composition(
            lineage, comps, (node,), "H",
            ExpressionPartition(active_candidate_refs=(candidate(registry, "A", refs[0]), candidate(registry, "B", refs[1]))),
        )
        self.assertEqual(classify_hybrid(lineage, blank, registry).hybrid_class, classify_hybrid(lineage, active, registry).hybrid_class)

    def test_expression_partitions_are_source_qualified(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS",)
        lineage, registry = bound_lineage(refs)
        comps = (HybridSourceComponent("A", "SRC_A", refs), HybridSourceComponent("B", "SRC_B", refs))
        node = IntegrationNode("H", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("A", "B"))
        expr = ExpressionPartition(
            active_candidate_refs=(candidate(registry, "A", refs[0]),),
            latent_candidate_refs=(candidate(registry, "B", refs[0]),),
        )
        result = classify_hybrid(lineage, composition(lineage, comps, (node,), "H", expr), registry)
        self.assertEqual(result.active_candidate_count, 1)
        self.assertEqual(result.latent_candidate_count, 1)

    def test_expression_overlap_rejected(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS",)
        lineage, registry = bound_lineage(refs)
        comp = HybridSourceComponent("A", "SRC_A", refs)
        ref = candidate(registry, "A", refs[0])
        value = composition(lineage, (comp,), expression=ExpressionPartition((ref,), (ref,), ()))
        with self.assertRaisesRegex(ValueError, "PARTITIONS_OVERLAP"):
            validate_hybrid_composition(lineage, value, registry)

    def test_unknown_expression_candidate_rejected(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS",)
        lineage, registry = bound_lineage(refs)
        comp = HybridSourceComponent("A", "SRC_A", refs)
        bad = TraitCandidateRef("A", refs[0], "NOT_A_CONTRIBUTION")
        value = composition(lineage, (comp,), expression=ExpressionPartition((bad,), (), ()))
        with self.assertRaisesRegex(ValueError, "UNKNOWN_CANDIDATE"):
            validate_hybrid_composition(lineage, value, registry)

    def test_unassigned_candidates_remain_unresolved_not_auto_selected(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS",)
        lineage, registry = bound_lineage(refs)
        comp = HybridSourceComponent("A", "SRC_A", refs)
        result = classify_hybrid(lineage, composition(lineage, (comp,)), registry)
        self.assertGreater(result.unassigned_candidate_count, 0)
        self.assertEqual(result.active_candidate_count, 0)

    def test_orphan_component_rejected(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL")
        lineage, registry = bound_lineage(refs)
        comps = (HybridSourceComponent("A", "SRC_A", (refs[0],)), HybridSourceComponent("B", "SRC_B", (refs[1],)))
        with self.assertRaisesRegex(ValueError, "ORPHAN_SOURCE_COMPONENT"):
            validate_hybrid_composition(lineage, composition(lineage, comps, root_ref="A"), registry)

    def test_orphan_integration_node_rejected(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL")
        lineage, registry = bound_lineage(refs)
        comps = (HybridSourceComponent("A", "SRC_A", (refs[0],)), HybridSourceComponent("B", "SRC_B", (refs[1],)))
        root = IntegrationNode("ROOT", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("A", "B"))
        orphan = IntegrationNode("ORPHAN", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("A", "B"))
        with self.assertRaisesRegex(ValueError, "ORPHAN_INTEGRATION_NODE"):
            validate_hybrid_composition(lineage, composition(lineage, comps, (root, orphan), root_ref="ROOT"), registry)

    def test_graph_cycle_rejected(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL", "ORG_AVIAN_RESPIRATORY_STRUCTURAL")
        lineage, registry = bound_lineage(refs)
        comps = tuple(HybridSourceComponent(x, f"SRC_{x}", (pkg,)) for x, pkg in zip(("A", "B", "C"), refs))
        nodes = (
            IntegrationNode("H1", "B3", "E3", IntegrationMode.REPEATED_MIXING, ("H2", "A")),
            IntegrationNode("H2", "B3", "E3", IntegrationMode.REPEATED_MIXING, ("H1", "B", "C")),
        )
        with self.assertRaisesRegex(ValueError, "GRAPH_CYCLE"):
            validate_hybrid_composition(lineage, composition(lineage, comps, nodes, "H2"), registry)

    def test_directed_hybridization_cannot_consume_composite(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL", "ORG_AVIAN_RESPIRATORY_STRUCTURAL")
        lineage, registry = bound_lineage(refs)
        comps = tuple(HybridSourceComponent(x, f"SRC_{x}", (pkg,)) for x, pkg in zip(("A", "B", "C"), refs))
        nodes = (
            IntegrationNode("H1", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("A", "B")),
            IntegrationNode("H2", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("H1", "C")),
        )
        with self.assertRaisesRegex(ValueError, "CANNOT_USE_COMPOSITE_INPUT"):
            validate_hybrid_composition(lineage, composition(lineage, comps, nodes, "H2"), registry)

    def test_repeated_mixing_must_use_b3(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL")
        lineage, registry = bound_lineage(refs)
        comps = (HybridSourceComponent("A", "SRC_A", (refs[0],)), HybridSourceComponent("B", "SRC_B", (refs[1],)))
        node = IntegrationNode("H", "B2", "E2", IntegrationMode.REPEATED_MIXING, ("A", "B"))
        with self.assertRaisesRegex(ValueError, "MODE_PHASE_MISMATCH"):
            validate_hybrid_composition(lineage, composition(lineage, comps, (node,), "H"), registry)

    def test_directed_hybridization_epoch_guard(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL")
        lineage, registry = bound_lineage(refs)
        comps = (HybridSourceComponent("A", "SRC_A", (refs[0],)), HybridSourceComponent("B", "SRC_B", (refs[1],)))
        node = IntegrationNode("H", "B2", "E3", IntegrationMode.DIRECTED_HYBRIDIZATION, ("A", "B"))
        with self.assertRaisesRegex(ValueError, "BIOLOGICAL_PROCESS_NOT_ALLOWED_IN_EPOCH"):
            validate_hybrid_composition(lineage, composition(lineage, comps, (node,), "H"), registry)

    def test_component_package_must_be_bound_to_lineage(self):
        lineage, registry = bound_lineage(("ORG_MAMMALIAN_HOMEOSTASIS",))
        comp = HybridSourceComponent("A", "SRC_A", ("ORG_REPTILIAN_WATER_THERMAL",))
        with self.assertRaisesRegex(ValueError, "PACKAGE_NOT_BOUND"):
            validate_hybrid_composition(lineage, composition(lineage, (comp,)), registry)

    def test_all_bound_packages_must_be_attributed(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL")
        lineage, registry = bound_lineage(refs)
        comp = HybridSourceComponent("A", "SRC_A", (refs[0],))
        with self.assertRaisesRegex(ValueError, "PACKAGE_COVERAGE_MISMATCH"):
            validate_hybrid_composition(lineage, composition(lineage, (comp,)), registry)

    def test_existing_source_lineage_mismatch_rejected(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS",)
        lineage, registry = bound_lineage(refs, source_refs=("OLD",))
        comp = HybridSourceComponent("A", "SRC_A", refs)
        with self.assertRaisesRegex(ValueError, "SOURCE_LINEAGE_SET_MISMATCH"):
            validate_hybrid_composition(lineage, composition(lineage, (comp,)), registry)

    def test_coherent_requires_evidence_and_no_conflict(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS",)
        lineage, registry = bound_lineage(refs)
        comp = HybridSourceComponent("A", "SRC_A", refs)
        with self.assertRaisesRegex(ValueError, "REQUIRES_EVIDENCE"):
            validate_hybrid_composition(lineage, composition(lineage, (comp,), coherence=CoherenceAssessment(CoherenceStatus.COHERENT)), registry)
        with self.assertRaisesRegex(ValueError, "COHERENT_WITH_CONFLICTS"):
            validate_hybrid_composition(lineage, composition(lineage, (comp,), coherence=CoherenceAssessment(CoherenceStatus.COHERENT, ("EV",), ("CF",))), registry)

    def test_context_dependent_requires_support_and_conflict(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS",)
        lineage, registry = bound_lineage(refs)
        comp = HybridSourceComponent("A", "SRC_A", refs)
        with self.assertRaisesRegex(ValueError, "REQUIRES_BOTH"):
            validate_hybrid_composition(lineage, composition(lineage, (comp,), coherence=CoherenceAssessment(CoherenceStatus.CONTEXT_DEPENDENT, ("EV",), ())), registry)

    def test_classification_is_independent_of_coherence_status(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL")
        lineage, registry = bound_lineage(refs)
        comps = (HybridSourceComponent("A", "SRC_A", (refs[0],)), HybridSourceComponent("B", "SRC_B", (refs[1],)))
        node = IntegrationNode("H", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("A", "B"))
        a = classify_hybrid(lineage, composition(lineage, comps, (node,), "H"), registry)
        b = classify_hybrid(lineage, composition(lineage, comps, (node,), "H", coherence=CoherenceAssessment(CoherenceStatus.CONFLICTED, (), ("CF",))), registry)
        self.assertEqual(a.hybrid_class, b.hybrid_class)

    def test_apply_resolves_source_set_and_depth_without_changing_phenotype(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL", "ORG_AVIAN_RESPIRATORY_STRUCTURAL")
        lineage, registry = bound_lineage(refs)
        comps = tuple(HybridSourceComponent(x, f"SRC_{x}", (pkg,)) for x, pkg in zip(("A", "B", "C"), refs))
        nodes = (
            IntegrationNode("H1", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("A", "B")),
            IntegrationNode("H2", "B3", "E3", IntegrationMode.REPEATED_MIXING, ("H1", "C")),
        )
        before = (lineage.morphology, lineage.metabolism, lineage.regeneration)
        updated, result = apply_hybrid_composition(lineage, composition(lineage, comps, nodes, "H2"), registry)
        self.assertEqual(updated.hybridization.integration_depth_hint, 2)
        self.assertEqual(updated.hybridization.source_lineage_refs, ("SRC_A", "SRC_B", "SRC_C"))
        self.assertEqual(before, (updated.morphology, updated.metabolism, updated.regeneration))
        self.assertEqual(result.hybrid_class, HybridClass.POLY)

    def test_registry_duplicate_rejected(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS",)
        lineage, registry = bound_lineage(refs)
        comp = composition(lineage, (HybridSourceComponent("A", "SRC_A", refs),))
        hybrid_registry = HybridCompositionRegistry(); hybrid_registry.register(lineage, comp, registry)
        with self.assertRaisesRegex(ValueError, "DUPLICATE_LINEAGE"):
            hybrid_registry.register(lineage, comp, registry)

    def test_provenance_must_be_world_truth(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS",)
        lineage, registry = bound_lineage(refs)
        comp = composition(lineage, (HybridSourceComponent("A", "SRC_A", refs),))
        bad = replace(comp, provenance=HybridCompositionProvenance(("TEST",), "PUBLIC_CANON"))
        with self.assertRaisesRegex(ValueError, "MUST_BE_WORLD_TRUTH"):
            validate_hybrid_composition(lineage, bad, registry)

    def test_lineage_cannot_be_own_source(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS",)
        lineage, registry = bound_lineage(refs)
        comp = HybridSourceComponent("A", lineage.lineage_id, refs)
        with self.assertRaisesRegex(ValueError, "CANNOT_BE_ITS_OWN_SOURCE"):
            validate_hybrid_composition(lineage, composition(lineage, (comp,)), registry)

    def test_stage4d_schema_has_no_stage5_or_stage6_owned_fields(self):
        names = {field.name for field in fields(HybridCompositionRecord)}
        self.assertFalse(names.intersection(set(STAGE5_DETAIL_FIELDS) | set(STAGE6_DETAIL_FIELDS)))

    def test_latent_expression_is_not_inheritance_mechanics(self):
        names = {field.name for field in fields(ExpressionPartition)}
        self.assertIn("latent_candidate_refs", names)
        for forbidden in ("alleles", "germline", "inheritance_probability", "penetrance", "meiotic_rules"):
            self.assertNotIn(forbidden, names)

    def test_component_order_and_node_input_order_do_not_change_classification(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL", "ORG_AVIAN_RESPIRATORY_STRUCTURAL")
        lineage, registry = bound_lineage(refs)
        comps = tuple(HybridSourceComponent(x, f"SRC_{x}", (pkg,)) for x, pkg in zip(("A", "B", "C"), refs))
        nodes_a = (
            IntegrationNode("H1", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("A", "B")),
            IntegrationNode("H2", "B3", "E3", IntegrationMode.REPEATED_MIXING, ("H1", "C")),
        )
        nodes_b = (
            IntegrationNode("H2", "B3", "E3", IntegrationMode.REPEATED_MIXING, ("C", "H1")),
            IntegrationNode("H1", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("B", "A")),
        )
        a = classify_hybrid(lineage, composition(lineage, comps, nodes_a, "H2"), registry)
        b = classify_hybrid(lineage, composition(lineage, tuple(reversed(comps)), nodes_b, "H2"), registry)
        self.assertEqual(a, b)


    def test_registry_digest_is_order_independent_for_set_like_graph_inputs(self):
        refs = ("ORG_MAMMALIAN_HOMEOSTASIS", "ORG_REPTILIAN_WATER_THERMAL", "ORG_AVIAN_RESPIRATORY_STRUCTURAL")
        lineage, registry = bound_lineage(refs)
        comps = tuple(HybridSourceComponent(x, f"SRC_{x}", (pkg,)) for x, pkg in zip(("A", "B", "C"), refs))
        nodes_a = (
            IntegrationNode("H1", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("A", "B")),
            IntegrationNode("H2", "B3", "E3", IntegrationMode.REPEATED_MIXING, ("H1", "C")),
        )
        nodes_b = (
            IntegrationNode("H2", "B3", "E3", IntegrationMode.REPEATED_MIXING, ("C", "H1")),
            IntegrationNode("H1", "B2", "E2", IntegrationMode.DIRECTED_HYBRIDIZATION, ("B", "A")),
        )
        a = HybridCompositionRegistry(); b = HybridCompositionRegistry()
        a.register(lineage, composition(lineage, comps, nodes_a, "H2"), registry)
        b.register(lineage, composition(lineage, tuple(reversed(comps)), nodes_b, "H2"), registry)
        self.assertEqual(a.canonical_digest(), b.canonical_digest())



if __name__ == "__main__":
    unittest.main()
