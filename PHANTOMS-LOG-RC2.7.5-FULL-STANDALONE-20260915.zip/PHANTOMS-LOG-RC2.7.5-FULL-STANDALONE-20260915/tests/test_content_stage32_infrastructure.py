
import json, unittest
from pathlib import Path
from runtime.content_stage32.infrastructure import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage32_infrastructure.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_project_types(self):
  self.assertGreaterEqual(len(D["project_types"]),5)

 def test_material_gate(self):
  req={"A":2}
  self.assertFalse(materials_sufficient(req,{"A":1}))
  self.assertTrue(materials_sufficient(req,{"A":2}))

 def test_progress_requires_inputs(self):
  self.assertEqual(project_progress(10,10,100,False,60),10)
  self.assertEqual(project_progress(10,10,100,True,0),10)

 def test_progress_bounded(self):
  self.assertEqual(project_progress(95,100,100,True,60),100)

 def test_construction_authority(self):
  p=construction_candidate("P","PRJ_SHELTER","L","S",50,"EV")
  self.assertTrue(p["authority_required"])

 def test_utility_shortage(self):
  s=utility_service(100,150,100)
  self.assertEqual(s["served"],100)
  self.assertEqual(s["shortage"],50)

 def test_condition_reduces_capacity(self):
  a=utility_service(100,100,100)["served"]
  b=utility_service(100,100,50)["served"]
  self.assertGreater(a,b)

 def test_decay_requires_time(self):
  self.assertEqual(decay_projection(80,10,0),80)
  self.assertLess(decay_projection(80,10,1440),80)

 def test_maintenance_requires_resources(self):
  p=D["maintenance_profiles"][0]
  self.assertIsNone(maintenance_candidate("A",p,50,False,"EV"))

 def test_maintenance_bounded(self):
  p=D["maintenance_profiles"][2]
  m=maintenance_candidate("A",p,90,True,"EV")
  self.assertEqual(m["condition_after"],100)
  self.assertTrue(m["authority_required"])

 def test_state_mapping(self):
  self.assertEqual(infrastructure_state(100),"OPERATIONAL")
  self.assertEqual(infrastructure_state(30),"DEGRADED")
  self.assertEqual(infrastructure_state(10),"FAILED")
  self.assertEqual(infrastructure_state(0),"DESTROYED")

if __name__=="__main__": unittest.main()
