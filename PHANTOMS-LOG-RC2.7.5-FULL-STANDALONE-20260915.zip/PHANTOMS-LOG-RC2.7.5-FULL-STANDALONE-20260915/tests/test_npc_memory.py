from runtime.player_progression.npc_memory import *

def ev(turn=1, **kw):
    d=dict(npc_id="n", key=f"k{turn}", turn=turn, summary="event", novelty=.2)
    d.update(kw); return MemoryEvent(**d)

def test_low_salience_drops():
    e=NPCMemoryBudgetEngine(); assert e.remember(ev(novelty=0))=="DROPPED"

def test_repetition_merges_not_log_spam():
    e=NPCMemoryBudgetEngine();
    for t in range(1,5): e.remember(ev(t,key="door",repetition_key="checks_door",novelty=.25))
    st=e.state_for("n")
    assert len(st.recent)+len(st.long_term)<=1

def test_important_memory_survives():
    e=NPCMemoryBudgetEngine(); assert e.remember(ev(emotion=1,relationship_effect=1,danger=1))=="LONG_TERM"

def test_compaction_summarizes_old_relevant():
    e=NPCMemoryBudgetEngine(); e.remember(ev(1,key="a",novelty=.8)); e.compact("n",200,max_age=10)
    assert "a" in e.state_for("n").summaries or "a" in e.state_for("n").long_term

def test_lazy_simulation_stores_anchor_not_ticks():
    e=NPCMemoryBudgetEngine(); r=e.lazy_advance("n",500,"market","find_parts")
    assert r["elapsed"]==500 and e.state_for("n").last_simulated_turn==500

def test_persistence_roundtrip():
    e=NPCMemoryBudgetEngine(); e.remember(ev(emotion=1)); e.lazy_advance("n",50,"hub","sleep")
    e2=NPCMemoryBudgetEngine.from_save(e.snapshot_for_save())
    assert e2.state_for("n").current_location=="hub"
