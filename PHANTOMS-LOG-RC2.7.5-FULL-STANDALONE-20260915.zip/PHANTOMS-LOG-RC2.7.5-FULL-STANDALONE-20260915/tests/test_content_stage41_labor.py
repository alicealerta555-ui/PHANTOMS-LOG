
import json, unittest
from pathlib import Path
from runtime.content_stage41.labor import *
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage41_labor_employment.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_job_types(self): self.assertGreaterEqual(len(D["job_types"]),5)
 def test_offer_not_employment(self): self.assertFalse(job_offer("E","W","JOB_TECH","CONTRACT_HOURLY",10,1)["accepted"])
 def test_acceptance_authority(self):
  a=accept_job(job_offer("E","W","JOB_TECH","CONTRACT_HOURLY",10,1),"W","EV"); self.assertTrue(a["accepted"]); self.assertTrue(a["authority_required"])
 def test_wrong_actor_cannot_accept(self): self.assertIsNone(accept_job(job_offer("E","W","JOB_TECH","CONTRACT_HOURLY",10,1),"X","EV"))
 def test_hourly_wage(self): self.assertEqual(wage_entitlement("CONTRACT_HOURLY",10,3),30)
 def test_task_wage_requires_completion(self):
  self.assertEqual(wage_entitlement("CONTRACT_TASK",50,task_complete=False),0); self.assertEqual(wage_entitlement("CONTRACT_TASK",50,task_complete=True),50)
 def test_payroll_requires_funds(self): self.assertIsNone(payroll_proposal("E","W",100,50,"B","EV"))
 def test_payroll_authority(self): self.assertTrue(payroll_proposal("E","W",50,50,"B","EV")["authority_required"])
 def test_unemployment_not_skill_judgment(self): self.assertEqual(unemployment_state(False,True),"UNEMPLOYED")
 def test_workplace_order_bounded(self):
  self.assertIsNone(workplace_order("A","B",20,40,"do","EV")); self.assertTrue(workplace_order("A","B",60,40,"do","EV")["requires_actor_decision"])
 def test_labor_record(self): self.assertEqual(labor_record("W","WP",8,"TASK",1)["hours"],8.0)
if __name__=="__main__": unittest.main()
