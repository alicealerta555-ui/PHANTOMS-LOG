
import json,unittest
from pathlib import Path
from runtime.content_stage12.quests import *
ROOT=Path(__file__).resolve().parents[1]; D=json.loads((ROOT/"content/full_version/stage12_quests_contracts.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_quests(self): self.assertGreaterEqual(len(D["quest_templates"]),4)
 def test_explicit_acceptance(self): self.assertTrue(D["contract_template"]["acceptance_required"]); self.assertFalse(D["contract_template"]["implicit_acceptance"])
 def test_accept(self):
  c=offer_contract({},'c','q','npc','p',10,20); self.assertEqual(accept_contract(c,'p',15)["status"],"ACCEPTED"); self.assertIsNone(accept_contract(c,'x',15))
 def test_expiry(self):
  c=offer_contract({},'c','q','npc','p',10,20); self.assertIsNone(accept_contract(c,'p',21))
 def test_rumor_provenance(self):
  r=rumor_record(D["rumor_templates"][0],"npc","p",10,12); self.assertTrue(validate_rumor(r)); self.assertEqual(r["truth_status"],"UNVERIFIED")
 def test_consequence_authority(self):
  x=consequence_proposals(D["consequence_chains"][0],"failed","EV1"); self.assertTrue(x); self.assertTrue(all(e["authority_required"] for e in x)); self.assertTrue(all(e["causal_event_id"]=="EV1" for e in x))
 def test_transition(self):
  self.assertEqual(quest_transition("ACTIVE","complete"),"COMPLETED"); self.assertIsNone(quest_transition("COMPLETED","complete"))
 def test_no_text_grant(self): self.assertTrue(any("No quest may grant" in x for x in D["rules"]))
if __name__=="__main__": unittest.main()
