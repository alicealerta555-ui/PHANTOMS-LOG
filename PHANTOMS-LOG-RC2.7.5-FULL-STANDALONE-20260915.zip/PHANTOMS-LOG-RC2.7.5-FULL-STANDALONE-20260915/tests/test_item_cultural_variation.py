import json
from pathlib import Path

from runtime.full_version.catalog import FullVersionCatalog
from runtime.full_version.content_distribution import ContentDistributionResolver
from runtime.full_version.item_surface import ItemSurfaceResolver

ROOT=Path(__file__).resolve().parents[1]


def test_all_80_items_have_distribution_profiles():
    c=FullVersionCatalog.load(ROOT)
    r=ContentDistributionResolver(c)
    ids={x['item_definition_id'] for x in c.world['item_definitions']}
    assert len(ids)==80
    assert ids==set(r.profiles)


def test_surface_variant_is_stable_and_does_not_change_canonical_definition():
    c=FullVersionCatalog.load(ROOT)
    r=ItemSurfaceResolver(c)
    iid='item_def:clothing:007'; loc='loc:industrial_maintenance:01'
    canonical=dict(c.item_definition(iid))
    a=r.resolve(iid,loc,run_uuid='run-A',instance_id='item:x')
    b=r.resolve(iid,loc,run_uuid='run-A',instance_id='item:x')
    assert a==b
    assert dict(c.item_definition(iid))==canonical
    assert a.base_name==canonical['display_name']
    assert a.display_name


def test_hybrid_culture_surface_is_explicitly_hybrid_not_lineage():
    c=FullVersionCatalog.load(ROOT)
    r=ItemSurfaceResolver(c)
    s=r.resolve('item_def:tool:001','loc:industrial_maintenance:01',run_uuid='x',instance_id='i',culture_id='culture:civic_rimworks')
    assert s.hybrid_culture is True
    assert 'Civic-Rim' in s.display_name or 'Civic-Rim' in s.culture_suffix
    packet=s.to_dict()
    assert 'lineage' not in packet


def test_variant_contract_forbids_mechanical_changes():
    raw=json.loads((ROOT/'content/full_version/item_surface_variants.json').read_text())
    forbidden=set(raw['rules']['variant_must_not_change'])
    assert {'kind','mechanical_effect','canonical_identity','quest_semantics','ownership','condition'} <= forbidden


def test_market_scarcity_changes_price_multiplier():
    c=FullVersionCatalog.load(ROOT)
    r=ContentDistributionResolver(c)
    iid='item_def:tool:001'
    native=r.resolve(iid,'loc:industrial_maintenance:01',run_uuid='market')
    remote=r.resolve(iid,'loc:underground_dungeon:01',run_uuid='market')
    assert r.market_price_multiplier_ppm(remote) >= r.market_price_multiplier_ppm(native)


def test_merchant_offer_is_seed_stable():
    c=FullVersionCatalog.load(ROOT)
    r=ContentDistributionResolver(c)
    a=r.merchant_offer('item_def:food:027','loc:commerce_services:01',run_uuid='r',merchant_id='m')
    b=r.merchant_offer('item_def:food:027','loc:commerce_services:01',run_uuid='r',merchant_id='m')
    assert a==b
