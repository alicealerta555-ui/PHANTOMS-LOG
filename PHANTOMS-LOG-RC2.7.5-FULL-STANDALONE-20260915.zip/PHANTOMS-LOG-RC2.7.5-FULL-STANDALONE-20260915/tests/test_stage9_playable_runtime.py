from __future__ import annotations

import unittest
from unittest.mock import Mock
from uuid import uuid4

from runtime.stage3a.kernel import Authority, Delta, Domain, Mode, Proposal
from runtime.stage3b.pipeline import ActionRequest, ActionResult, ActionStatus, ActionRule, OutcomeBranch
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.context import RuntimeContext
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.playable_runtime import (
    PlayableRuntime,
    PlayableRuntimeError,
    RuntimeLifecycle,
)


class Stage9PlayableRuntimeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.player_uuid = str(uuid4())
        self.run_uuid = str(uuid4())
        self.manager = RunSessionManager(master_seed=99)
        self.session = self.manager.create_run(player_uuid=self.player_uuid, run_uuid=self.run_uuid)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(self.player_uuid, self.run_uuid, "actor:player")
        self.registry.register(self.identity, actor_definition_id="test.player")
        self.runtime = PlayableRuntime(self.session, self.registry)

    @staticmethod
    def _request(event_id: str = "stage9:test:turn") -> ActionRequest:
        rule = ActionRule(
            rule_id="STAGE9_TEST_NOOP",
            outcomes=(OutcomeBranch(outcome_id="NOOP", effects=()),),
        )
        return ActionRequest(event_id=event_id, rule=rule, cause="STAGE9_TEST")

    def _context(self, suffix: str = "turn") -> RuntimeContext:
        return self.runtime.create_context(
            self.identity,
            turn_id=f"turn:{suffix}",
            action_window_id=f"window:{suffix}",
        )

    def test_starts_ready(self) -> None:
        runtime = self.runtime
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.READY)

    def test_explicit_identity_required(self) -> None:
        runtime = self.runtime
        with self.assertRaisesRegex(PlayableRuntimeError, "INVALID_RUNTIME_CONTEXT"):
            runtime.execute_action(None, self._request())  # type: ignore[arg-type]
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.READY)

    def test_wrong_run_identity_rejected_without_state_change(self) -> None:
        runtime = self.runtime
        before = self.session.store.snapshot()
        wrong = RuntimeIdentity(self.player_uuid, str(uuid4()), "actor:player")
        with self.assertRaises(Exception):
            runtime.create_context(wrong, turn_id="turn:wrong", action_window_id="window:wrong")
        self.assertEqual(before, self.session.store.snapshot())
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.READY)

    def test_unregistered_actor_rejected(self) -> None:
        runtime = self.runtime
        wrong_actor = RuntimeIdentity(self.player_uuid, self.run_uuid, "actor:missing")
        with self.assertRaises(Exception):
            runtime.create_context(wrong_actor, turn_id="turn:missing", action_window_id="window:missing")
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.READY)

    def test_noop_action_uses_runtime_root_and_returns_ready(self) -> None:
        runtime = self.runtime
        receipt = runtime.execute_action(self._context("noop"), self._request())
        self.assertEqual(receipt.action_result.status, ActionStatus.RESOLVED_NO_CHANGE)
        self.assertFalse(receipt.canonical_state_changed)
        self.assertEqual(
            receipt.lifecycle_trace,
            (
                RuntimeLifecycle.READY,
                RuntimeLifecycle.TURN_OPEN,
                RuntimeLifecycle.TURN_PROCESSING,
                RuntimeLifecycle.POST_COMMIT,
                RuntimeLifecycle.TURN_COMPLETE,
                RuntimeLifecycle.READY,
            ),
        )
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.READY)
        self.assertNotIn(RuntimeLifecycle.TURN_COMMITTING, receipt.lifecycle_trace)

    def test_real_commit_is_observed_not_written_by_runtime(self) -> None:
        event_id = "stage9:test:commit"
        def executor(_request: ActionRequest) -> ActionResult:
            record = self.session.kernel.process(Proposal(
                mode=Mode.COMMIT,
                source=Authority.COMMIT_KERNEL,
                event_id=event_id,
                cause="STAGE9_TEST_COMMIT",
                deltas=(Delta(
                    Domain.RUNTIME_STATE,
                    "stage9.test.value",
                    1,
                    Authority.RULE_KERNEL,
                    "STAGE9_TEST_COMMIT",
                    source_event_id=event_id,
                ),),
            ))
            return ActionResult(
                status=ActionStatus.COMMITTED,
                event_id=event_id,
                rule_id="STAGE9_TEST",
                commit=record,  # type: ignore[arg-type]
            )

        runtime = PlayableRuntime(self.session, self.registry, action_executor=executor)
        before = self.session.store.revision
        receipt = runtime.execute_action(self._context("commit"), self._request(event_id))
        self.assertTrue(receipt.canonical_state_changed)
        self.assertEqual(receipt.revision_before, before)
        self.assertEqual(receipt.revision_after, before + 1)
        self.assertEqual(self.session.store.runtime_state["stage9.test.value"], 1)
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.READY)

    def test_invalid_executor_result_integrity_blocks_runtime(self) -> None:
        runtime = PlayableRuntime(self.session, self.registry, action_executor=lambda _r: object())  # type: ignore[arg-type]
        with self.assertRaisesRegex(PlayableRuntimeError, "ACTION_EXECUTOR_INVALID_RESULT"):
            runtime.execute_action(runtime.create_context(self.identity, turn_id="turn:invalid-result", action_window_id="window:invalid-result"), self._request())
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.INTEGRITY_BLOCKED)
        runtime.reset_fault()
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.READY)

    def test_executor_exception_enters_runtime_fault(self) -> None:
        def explode(_request: ActionRequest) -> ActionResult:
            raise ValueError("boom")
        runtime = PlayableRuntime(self.session, self.registry, action_executor=explode)
        with self.assertRaisesRegex(ValueError, "boom"):
            runtime.execute_action(runtime.create_context(self.identity, turn_id="turn:explode", action_window_id="window:explode"), self._request())
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.RUNTIME_FAULT)
        runtime.reset_fault()
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.READY)

    def test_nested_second_turn_rejected(self) -> None:
        runtime: PlayableRuntime
        nested_error: list[str] = []
        def executor(_request: ActionRequest) -> ActionResult:
            try:
                runtime.execute_action(self._context("nested"), self._request("nested"))
            except PlayableRuntimeError as exc:
                nested_error.append(str(exc))
            return ActionResult(ActionStatus.RESOLVED_NO_CHANGE, "outer", "TEST")
        runtime = PlayableRuntime(self.session, self.registry, action_executor=executor)
        runtime.execute_action(self._context("outer"), self._request("outer"))
        self.assertEqual(nested_error, ["TURN_ALREADY_ACTIVE"])
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.READY)


    def test_stale_runtime_context_rejected_before_executor(self) -> None:
        calls: list[str] = []
        def executor(_request: ActionRequest) -> ActionResult:
            calls.append("called")
            return ActionResult(ActionStatus.RESOLVED_NO_CHANGE, "stale", "TEST")
        runtime = PlayableRuntime(self.session, self.registry, action_executor=executor)
        context = runtime.create_context(
            self.identity,
            turn_id="turn:stale",
            action_window_id="window:stale",
        )
        event_id = "stage9:test:context-bump"
        self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id=event_id,
            cause="STAGE9_CONTEXT_BUMP",
            deltas=(Delta(
                Domain.RUNTIME_STATE,
                "stage9.context.bump",
                1,
                Authority.RULE_KERNEL,
                "STAGE9_CONTEXT_BUMP",
                source_event_id=event_id,
            ),),
        ))
        revision_after_bump = self.session.store.revision
        with self.assertRaisesRegex(PlayableRuntimeError, "RUNTIME_CONTEXT_STALE"):
            runtime.execute_action(context, self._request("stale"))
        self.assertEqual(calls, [])
        self.assertEqual(self.session.store.revision, revision_after_bump)
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.READY)

    def test_receipt_preserves_context_ids(self) -> None:
        runtime = self.runtime
        context = self._context("receipt")
        receipt = runtime.execute_action(context, self._request("receipt"))
        self.assertEqual(receipt.runtime_context, context)
        self.assertEqual(receipt.runtime_identity, self.identity)
        self.assertEqual(receipt.turn_id, "turn:receipt")
        self.assertEqual(receipt.action_window_id, "window:receipt")

    def test_constructor_rejects_registry_from_other_run(self) -> None:
        other_run = str(uuid4())
        other = self.manager.create_run(player_uuid=self.player_uuid, run_uuid=other_run)
        other_registry = RunActorRegistry(other)
        with self.assertRaisesRegex(PlayableRuntimeError, "ACTOR_REGISTRY_RUN_MISMATCH"):
            PlayableRuntime(self.session, other_registry)

    def test_fault_reset_not_allowed_while_ready(self) -> None:
        runtime = PlayableRuntime(self.session, self.registry)
        with self.assertRaisesRegex(PlayableRuntimeError, "RUNTIME_FAULT_RESET_NOT_ALLOWED"):
            runtime.reset_fault()


if __name__ == "__main__":
    unittest.main()
