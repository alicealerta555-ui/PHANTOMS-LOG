
import json,unittest
from pathlib import Path
from runtime.content_stage22.justice import *
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage22_investigation_justice.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_evidence_classes(self):
  self.assertGreaterEqual(len(D["evidence_classes"]),5)

 def test_rumor_not_admissible(self):
  r=next(x for x in D["evidence_classes"] if x["id"]=="EVID_RUMOR")
  self.assertFalse(r["admissible"])

 def test_evidence_requires_provenance(self):
  allowed={x["id"] for x in D["evidence_classes"]}
  e=evidence_item("EVID_PHYSICAL","src","subj","EV","L",1,80)
  self.assertTrue(valid_evidence(e,allowed))
  e["event_id"]=""
  self.assertFalse(valid_evidence(e,allowed))

 def test_duplicate_evidence_not_double_counted(self):
  defs=D["evidence_classes"]
  e=evidence_item("EVID_DIRECT","src","subj","EV","L",1,100)
  self.assertEqual(investigation_score([e,e],defs),40)

 def test_accusation_alone_no_warrant(self):
  w=warrant_candidate("WAR_DETENTION","J","LAW","a",0,60,"EV")
  self.assertFalse(w["authorized"])

 def test_warrant_threshold(self):
  w=warrant_candidate("WAR_DETENTION","J","LAW","a",70,60,"EV")
  self.assertTrue(w["authorized"])
  self.assertTrue(w["authority_required"])

 def test_detention_requires_authorized_warrant(self):
  bad=warrant_candidate("WAR_DETENTION","J","LAW","a",10,60,"EV")
  self.assertIsNone(detention_proposal("a",bad,"EV"))
  good=warrant_candidate("WAR_DETENTION","J","LAW","a",80,60,"EV")
  self.assertTrue(detention_proposal("a",good,"EV")["authority_required"])

 def test_trial_outcomes(self):
  a=trial_candidate("a","J","LAW",40,60,"EV")
  b=trial_candidate("a","J","LAW",80,60,"EV")
  self.assertEqual(a["outcome"],"ACQUITTED")
  self.assertEqual(b["outcome"],"CONVICTED")

 def test_acquittal_not_sentence(self):
  t=trial_candidate("a","J","LAW",40,60,"EV")
  self.assertEqual(sentence_proposals(t,["fine"]),[])

 def test_conviction_sentence_authority(self):
  t=trial_candidate("a","J","LAW",80,60,"EV")
  p=sentence_proposals(t,["fine","restitution"])
  self.assertEqual(len(p),2)
  self.assertTrue(all(x["authority_required"] for x in p))

if __name__=="__main__": unittest.main()
