from pathlib import Path
import tempfile

from playable.game import FullVersionGame
from playable.location_images import ImageConfig
from runtime.full_version import FullVersionCatalog

ROOT=Path(__file__).resolve().parents[1]


def test_all_100_locations_have_specific_search_profiles_with_real_items():
    c=FullVersionCatalog.load(ROOT)
    local=c.search_tables['location_profiles']
    assert len(local)==len(c.world['locations'])==100
    assert set(local)=={x['location_id'] for x in c.world['locations']}
    item_ids={x['item_definition_id'] for x in c.world['item_definitions']}
    for profile in local.values():
        assert profile['resource_candidates'] and profile['information_candidates']
        assert {x['item_definition_id'] for x in profile['resource_candidates']} <= item_ids
    # Same category does not collapse to one identical item pool everywhere.
    industrial=[x for x in c.world['locations'] if x['primary_category']=='industrial_maintenance']
    pools={tuple(sorted(r['item_definition_id'] for r in local[x['location_id']]['resource_candidates'])) for x in industrial}
    assert len(pools)>1


def test_all_ai_prompt_authority_contracts_exist():
    names={
        'NPC_DIALOGUE_PROMPT_CORE.md','SEARCH_RESOLUTION_PROMPT_CORE.md','LOCATION_DETAIL_PROMPT_CORE.md',
        'QUEST_OFFER_PROMPT_CORE.md','ITEM_INSPECTION_PROMPT_CORE.md','DATA_TERMINAL_PROMPT_CORE.md',
        'MERCHANT_DIALOGUE_PROMPT_CORE.md','NPC_ITEM_RESPONSE_PROMPT_CORE.md','REPAIR_DIAGNOSTIC_PROMPT_CORE.md',
        'WORLD_INTERACTION_NARRATION_CORE.md','CONTENT_VARIATION_PROMPT_CORE.md',
    }
    prompt_dir=ROOT/'content/full_version/prompts'
    assert names <= {p.name for p in prompt_dir.iterdir() if p.is_file()}
    for name in names:
        text=(prompt_dir/name).read_text(encoding='utf-8').lower()
        assert 'authority' in text
        assert ('no state writes' in text) or ('may not commit state' in text) or ('authority' in text)


def test_image_projection_does_not_mutate_game_state():
    with tempfile.TemporaryDirectory() as tmp:
        g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class='GHOST',master_seed=20260913,image_config=ImageConfig(mode='off'))
        g.complete_character(g.creation_template())
        rev=g.session.store.revision
        g.describe()
        assert g.session.store.revision==rev
