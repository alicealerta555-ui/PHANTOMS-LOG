from pathlib import Path
import tempfile
import unittest
from collections import deque

from playable_full_version.playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, Domain

ROOT=Path(__file__).resolve().parents[1]

class NPCPlayableIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.g=FullVersionGame(core_root=ROOT,saves_root=Path(self.tmp.name),start_class='BREAKER',master_seed=20260913)
        self.g.complete_character(self.g.creation_template()); self.addCleanup(self.g.images.close)

    def route_to(self,target):
        start=self.g.location(); q=deque([(start,[])]) ; seen={start}
        while q:
            here,path=q.popleft()
            if here==target:
                for step in path:
                    text,_=self.g.handle('/go '+step); self.assertIn('COMMITTED',text)
                return
            for nxt in self.g.catalog.location(here)['connections']:
                if nxt not in seen:
                    seen.add(nxt); q.append((nxt,path+[nxt]))
        self.fail('no route')

    def first_merchant(self):
        for inst in self.g.actor_registry.instances():
            if inst.actor_instance_id=='actor:player': continue
            rec=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,inst.actor_instance_id)
            if isinstance(rec,dict) and rec.get('role')=='merchant': return inst.actor_instance_id,rec
        self.fail('merchant missing')

    def test_runtime_npcs_have_generated_persistent_names(self):
        npcs=[x for x in self.g.actor_registry.instances() if x.actor_instance_id!='actor:player']
        self.assertEqual(len(npcs),48)
        self.assertEqual(len([x for x in npcs if x.actor_instance_id.startswith('actor:npc:')]),45)
        self.assertEqual(len([x for x in npcs if x.actor_instance_id.startswith('actor:lifetime:')]),3)
        names=[]
        for inst in npcs:
            rec=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,inst.actor_instance_id)
            self.assertNotRegex(rec['display_name'],r'^Resident \\d+$')
            names.append(rec['display_name'])
        self.assertGreater(len(set(names)),30)

    def test_name_not_visible_until_talk_then_persists(self):
        mid,m=self.first_merchant(); self.route_to(m['location_ref'])
        before=self.g.describe(); self.assertIn('Unbekannte Person ['+mid+']',before); self.assertNotIn(m['display_name'],before)
        text,_=self.g.handle('/talk '+mid); self.assertIn(m['display_name'],text)
        after=self.g.describe(); self.assertIn(m['display_name']+' ['+mid+']',after)
        self.g.save(); g2=FullVersionGame(core_root=ROOT,saves_root=Path(self.tmp.name),master_seed=20260913); self.addCleanup(g2.images.close)
        self.assertIn(m['display_name']+' ['+mid+']',g2.describe())

    def test_merchant_stock_is_real_and_buy_is_atomic(self):
        mid,m=self.first_merchant(); self.route_to(m['location_ref']); self.g.handle('/talk '+mid)
        stock=self.g.merchant_stock(mid); self.assertTrue(stock)
        item=stock[0]; player_before=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,'actor:player')['resources']['credits']
        merchant_before=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,mid)['resources']['credits']
        text,_=self.g.handle('/buy '+item['instance_id']+' '+mid); self.assertIn('COMMITTED',text)
        player=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,'actor:player')
        merchant=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,mid)
        bought=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,item['instance_id'])
        self.assertEqual(player['resources']['credits'],player_before-item['unit_price'])
        self.assertEqual(merchant['resources']['credits'],merchant_before+item['unit_price'])
        self.assertEqual(bought['location_ref'],'inventory:actor:player')

if __name__=='__main__': unittest.main()
