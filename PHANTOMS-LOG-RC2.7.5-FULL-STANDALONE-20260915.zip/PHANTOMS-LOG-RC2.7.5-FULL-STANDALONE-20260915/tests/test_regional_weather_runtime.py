from pathlib import Path
import tempfile, copy
from playable.game import FullVersionGame
from runtime.full_version.regional_weather import RegionalWeatherRuntime
from runtime.full_version.bootstrap import PLAYER_ACTOR_INSTANCE_ID
from runtime.stage3a.kernel import Authority,Domain
from runtime.stage9.world_time import WorldClock

def game():
    td=tempfile.TemporaryDirectory(); core=Path(__file__).resolve().parents[1]
    g=FullVersionGame(core_root=core,saves_root=Path(td.name),start_class="OPERATOR")
    g.complete_character(g.creation_template()); g._tmp=td
    return g

def test_weather_initializes_all_regions_and_is_run_bound():
    g=game(); st=g.weather._state()
    assert set(st["regions"])=={"region:01","region:02","region:03","region:04","region:05"}
    assert st["run_uuid"]==g.session.identity.run_uuid

def test_front_adjacency_matches_real_world_graph():
    g=game()
    assert g.weather.adj["region:01"]==("region:02","region:05")
    assert g.weather.adj["region:03"]==("region:02","region:04")

def test_weather_tick_is_deterministic_for_same_run_state():
    g=game(); before=copy.deepcopy(g.weather._state())
    g.npc_routines.wait(3600)
    g.weather.tick()
    after=g.weather._state()
    assert after["last_tick"]==3600
    assert before["run_uuid"]==after["run_uuid"]

def test_weather_pressure_never_targets_player():
    g=game()
    tags=g.weather.pressure_tags_for_location(g.location())
    assert isinstance(tags,tuple)
    assert "player" not in " ".join(tags).lower()

def test_shelter_reduces_hazardous_climate_gain():
    g=game(); a=PLAYER_ACTOR_INSTANCE_ID
    # Compare equivalent synthetic advances by manually recovering to same starting pressure.
    p0=g.embodied_needs.actor_packet(a)["needs"]["climate_fit"]["pressure_ppm"]
    g.embodied_needs.advance(3600,climate="cold",actor_ids=[a],climate_exposure_ppm=1_000_000)
    exposed=g.embodied_needs.actor_packet(a)["needs"]["climate_fit"]["pressure_ppm"]-p0
    # Undo with committed warm shelter recovery, then normalize remaining offset.
    g.embodied_needs.recover(a,"warm_shelter")
    cur=g.embodied_needs.actor_packet(a)["needs"]["climate_fit"]["pressure_ppm"]
    # only relation matters; a sheltered hour must add much less than exposed hour
    g.embodied_needs.advance(3600,climate="cold",actor_ids=[a],climate_exposure_ppm=200_000)
    sheltered=g.embodied_needs.actor_packet(a)["needs"]["climate_fit"]["pressure_ppm"]-cur
    assert exposed>0 and 0<sheltered<exposed

def test_world_pulse_uses_committed_weather_and_creates_weather_state():
    g=game(); before=WorldClock(g.session).seconds
    g.npc_routines.wait(3600)
    g._world_pulse(before,activity="rest")
    raw=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,"__regional_weather_runtime__")
    assert isinstance(raw,dict) and raw["last_tick"]>=3600

def test_weather_status_hides_internal_probabilities():
    g=game(); text=g.weather_status()
    assert "ppm" not in text.lower() and "Wetter in region:" in text

def test_no_level_scaling_in_weather_tables():
    g=game()
    raw=(g.core_root/"content/full_version/regional_weather_tables.json").read_text()
    assert "NO_LEVEL_SCALING" in raw
    assert "player_level" not in raw
