from __future__ import annotations

import unittest
from dataclasses import FrozenInstanceError
from uuid import uuid4

from runtime.stage3b.pipeline import ActionRule, OutcomeBranch
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.action_adapter import LegacyActionRequestAdapter, PlayerActionProposalAdapter
from runtime.stage9.action_proposal import ActionProposal, ActionSource, Stage9ActionProposalError
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.context import RuntimeContext
from runtime.stage9.identity import RuntimeIdentity


class Stage9ActionProposalTests(unittest.TestCase):
    def setUp(self) -> None:
        self.player_uuid = str(uuid4())
        self.run_uuid = str(uuid4())
        manager = RunSessionManager(master_seed=1209)
        self.session = manager.create_run(player_uuid=self.player_uuid, run_uuid=self.run_uuid)
        self.registry = RunActorRegistry(self.session)
        self.player_identity = RuntimeIdentity(self.player_uuid, self.run_uuid, "actor:player")
        self.npc_identity = RuntimeIdentity(self.player_uuid, self.run_uuid, "actor:npc")
        self.registry.register(self.player_identity, actor_definition_id="player")
        self.registry.register(self.npc_identity, actor_definition_id="npc")
        self.context = RuntimeContext.capture(
            self.session, self.registry, self.player_identity,
            turn_id="turn:1", action_window_id="window:1",
        )
        self.adapter = PlayerActionProposalAdapter(
            controlled_actor_instance_id="actor:player",
            allowed_action_types=frozenset({"OPEN_DOOR", "GO_CORRIDOR"}),
        )

    def _proposal(self) -> ActionProposal:
        return self.adapter.from_intent(
            self.context,
            intent_name="OPEN_DOOR",
            raw_text="Ich öffne die Tür",
            input_id="input:1",
            action_id="action:1",
        )

    def test_player_intent_becomes_non_authoritative_proposal(self) -> None:
        p = self._proposal()
        self.assertEqual(p.action_type, "OPEN_DOOR")
        self.assertEqual(p.source, ActionSource.PLAYER_TEXT)
        self.assertEqual(p.actor_instance_id, "actor:player")
        self.assertEqual(p.target_refs, ())
        self.assertEqual(self.session.store.revision, self.context.state_revision)

    def test_raw_input_preserved(self) -> None:
        raw = "  Ich öffne die Tür!  "
        p = self.adapter.from_intent(
            self.context, intent_name="OPEN_DOOR", raw_text=raw,
            input_id="input:raw", action_id="action:raw",
        )
        self.assertEqual(p.raw_input, raw)

    def test_proposal_is_frozen_and_parameters_read_only(self) -> None:
        p = ActionProposal.from_context(
            self.context, action_id="action:frozen", input_id="input:frozen",
            action_type="OPEN_DOOR", raw_input="open", source=ActionSource.PLAYER_TEXT,
            parameters={"mode": "normal"},
        )
        with self.assertRaises((FrozenInstanceError, AttributeError)):
            p.action_type = "GO_CORRIDOR"  # type: ignore[misc]
        with self.assertRaises(TypeError):
            p.parameters["mode"] = "forced"  # type: ignore[index]

    def test_registered_npc_is_not_player_control_authority(self) -> None:
        npc_context = RuntimeContext.capture(
            self.session, self.registry, self.npc_identity,
            turn_id="turn:npc", action_window_id="window:npc",
        )
        with self.assertRaisesRegex(Stage9ActionProposalError, "PLAYER_ACTOR_CONTROL_NOT_AUTHORIZED"):
            self.adapter.from_intent(
                npc_context, intent_name="OPEN_DOOR", raw_text="open",
                input_id="input:npc", action_id="action:npc",
            )

    def test_unknown_or_ui_intent_not_promoted_to_gameplay_action(self) -> None:
        with self.assertRaisesRegex(Stage9ActionProposalError, "ACTION_TYPE_NOT_ALLOWED"):
            self.adapter.from_intent(
                self.context, intent_name="STATUS", raw_text="/status",
                input_id="input:status", action_id="action:status",
            )

    def test_proposal_must_match_runtime_context(self) -> None:
        other = RuntimeContext(
            runtime_identity=self.player_identity,
            turn_id="turn:other", action_window_id="window:other",
            state_revision=self.context.state_revision,
        )
        with self.assertRaisesRegex(Stage9ActionProposalError, "ACTION_PROPOSAL_CONTEXT_MISMATCH"):
            self._proposal().require_context_match(other)

    def test_legacy_adapter_is_deterministic_and_non_mutating(self) -> None:
        before = self.session.store.snapshot()
        bridge = LegacyActionRequestAdapter({
            "OPEN_DOOR": lambda: ActionRule(
                rule_id="OPEN", outcomes=(OutcomeBranch(outcome_id="OPENED"),)
            )
        })
        request = bridge.to_action_request(self.context, self._proposal())
        self.assertEqual(request.rule.rule_id, "OPEN")
        self.assertEqual(request.player_text, "Ich öffne die Tür")
        self.assertIn("action:1", request.event_id)
        self.assertEqual(before, self.session.store.snapshot())

    def test_legacy_adapter_rejects_unmapped_action(self) -> None:
        p = ActionProposal.from_context(
            self.context, action_id="action:unmapped", input_id="input:unmapped",
            action_type="TAKE", raw_input="take", source=ActionSource.PLAYER_TEXT,
        )
        bridge = LegacyActionRequestAdapter({
            "OPEN_DOOR": lambda: ActionRule(rule_id="OPEN", outcomes=(OutcomeBranch(outcome_id="OPENED"),))
        })
        with self.assertRaisesRegex(Stage9ActionProposalError, "ACTION_TYPE_HAS_NO_LEGACY_RULE"):
            bridge.to_action_request(self.context, p)

    def test_proposal_carries_no_rule_or_state_authority(self) -> None:
        p = self._proposal()
        forbidden = {"rule", "state", "store", "kernel", "authority", "commit_kernel"}
        self.assertTrue(forbidden.isdisjoint(set(p.__dataclass_fields__)))


if __name__ == "__main__":
    unittest.main()
