from __future__ import annotations

import unittest
from uuid import uuid4

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.continuity import SaveContinuityVerifier
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.save_snapshot import CanonicalSaveSnapshotBuilder


class Stage9ContinuityTests(unittest.TestCase):
    def setUp(self):
        self.seed = 8181
        self.manager = RunSessionManager(master_seed=self.seed)
        self.player = str(uuid4())
        self.session = self.manager.create_run(player_uuid=self.player)
        self.identity = RuntimeIdentity(self.player, self.session.identity.run_uuid, "actor:player")
        RunActorRegistry(self.session).register(self.identity, actor_definition_id="actor-def:player")

    def _manager_factory(self):
        return RunSessionManager(master_seed=self.seed)

    def test_restart_preserves_identity_seed_revision_and_hash(self):
        before = CanonicalSaveSnapshotBuilder(self.session).capture()
        runtime = SaveContinuityVerifier.restart(self.session, manager_factory=self._manager_factory)
        after = CanonicalSaveSnapshotBuilder(runtime.session).capture()
        self.assertEqual(after.canonical_json, before.canonical_json)
        self.assertEqual(after.player_uuid, before.player_uuid)
        self.assertEqual(after.run_uuid, before.run_uuid)
        self.assertEqual(after.run_seed, before.run_seed)

    def test_continuation_advances_from_same_revision_without_rollback(self):
        before = CanonicalSaveSnapshotBuilder(self.session).capture()
        def continuation(runtime):
            event = "CONTINUE:1"
            result = runtime.session.kernel.process(Proposal(
                mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL,
                event_id=event, cause="CONTINUE",
                deltas=(Delta(domain=Domain.RUNTIME_STATE, key="continued", value=True,
                              writer=Authority.RULE_KERNEL, cause="CONTINUE", source_event_id=event),),
            ))
            self.assertIsInstance(result, CommitRecord)
            return result.revision
        proof = SaveContinuityVerifier.prove(
            self.session, manager_factory=self._manager_factory, continuation=continuation
        )
        self.assertEqual(proof.snapshot_before_restart.canonical_json, proof.snapshot_after_rehydrate.canonical_json)
        self.assertEqual(proof.result_after_rehydrate, before.state_revision + 1)
        self.assertEqual(proof.snapshot_after_continuation.state_revision, before.state_revision + 1)


if __name__ == "__main__":
    unittest.main()
