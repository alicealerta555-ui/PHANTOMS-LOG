# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
import tempfile, unittest
from pathlib import Path
from uuid import UUID

from runtime.full_version.catalog import FullVersionCatalog
from runtime.stage3c.isolation import FilesystemRunRepository, RunSessionManager
from runtime.stage6.biology import *
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import StateAuthority

PLAYER=str(UUID('11111111-1111-4111-8111-111111111111'))

class Stage6FullVersionTests(unittest.TestCase):
    def setUp(self):
        self.root=Path(__file__).resolve().parents[1]; self.catalog=FullVersionCatalog.load(self.root)
        self.manager=RunSessionManager(master_seed=606); self.session=self.manager.create_run(player_uuid=PLAYER)
        self.registry=RunActorRegistry(self.session); self.authority=StateAuthority(self.session,actor_registry=self.registry)
        self.engine=Stage6BiologyEngine(self.session,self.catalog.stage6_biology); self.adapter=Stage6CommitAdapter(self.session)
        self.lineage=self.catalog.stage6_biology.raw['lineages'][0]
    def test_germline_vs_somatic_and_seed_stability(self):
        a={'thermal':TraitState('warm',TraitOrigin.GERMLINE),'scar':TraitState('scarred',TraitOrigin.SOMATIC)}
        b={'thermal':TraitState('cool',TraitOrigin.GERMLINE),'tattoo':TraitState('ink',TraitOrigin.SOMATIC)}
        kw=dict(record_id='inheritance:001',event_id='event:birth:001',parent_lineage_a=self.lineage,parent_lineage_b=self.lineage,parent_a_traits=a,parent_b_traits=b,cause_ref='cause:reproduction')
        one=self.engine.resolve_inheritance(**kw); two=self.engine.resolve_inheritance(**kw)
        self.assertEqual(one,two); self.assertNotIn('scar',one.inherited_traits); self.assertNotIn('tattoo',one.inherited_traits)
        self.assertIn('thermal',set(one.inherited_traits)|set(one.latent_traits))
    def test_compatibility_three_way(self):
        self.assertEqual(self.catalog.stage6_biology.compatibility(self.lineage,self.lineage).status,CompatibilityStatus.ALLOWED)
        lines=self.catalog.stage6_biology.raw['lineages']
        if len(lines)>=4:
            self.assertEqual(self.catalog.stage6_biology.compatibility(lines[2],lines[3]).status,CompatibilityStatus.BLOCKED)
            with self.assertRaises(Stage6BiologyError):
                self.engine.resolve_inheritance(record_id='inheritance:block',event_id='event:block',parent_lineage_a=lines[2],parent_lineage_b=lines[3],parent_a_traits={},parent_b_traits={},cause_ref='cause:block')
        self.assertEqual(self.catalog.stage6_biology.compatibility('lineage:unknown:a','lineage:unknown:b').status,CompatibilityStatus.UNKNOWN)
    def test_drift_is_bounded_and_speciation_requires_multiple_conditions(self):
        no=SpeciationEvidence(1,100000,100000,1); yes=SpeciationEvidence(9,950000,800000,7)
        r=self.engine.simulate_drift(record_id='drift:001',lineage_id=self.lineage,generation=3,pressures={'thermal':500000,'moisture':-250000},evidence=no,cause_ref='cause:climate')
        self.assertTrue(all(abs(v)<=self.catalog.stage6_biology.max_drift_ppm for v in r.trait_deltas_ppm.values())); self.assertEqual(r.speciation_status,SpeciationStatus.NO)
        self.assertEqual(self.engine.assess_speciation(yes),SpeciationStatus.STABLE_LINEAGE)
    def test_persisted_inheritance_survives_save_load(self):
        result=self.engine.resolve_inheritance(record_id='inheritance:persist',event_id='event:persist',parent_lineage_a=self.lineage,parent_lineage_b=self.lineage,parent_a_traits={'x':TraitState(1,TraitOrigin.GERMLINE)},parent_b_traits={'x':TraitState(2,TraitOrigin.GERMLINE)},cause_ref='cause:persist')
        ep=self.engine.inheritance_proposal(result,resolution_id='resolution:persist',source_action_id='action:persist',effect_id='effect:persist')
        self.adapter.apply_many((self.authority.authorize(ep),),commit_id='commit:persist',event_id='event:commit:persist')
        before=Stage6BiologyView(self.session).snapshot()
        with tempfile.TemporaryDirectory() as td:
            repo=FilesystemRunRepository(Path(td)); repo.save(self.session); ident=self.session.identity; self.manager.close_run(player_uuid=ident.player_uuid,run_uuid=ident.run_uuid); loaded=repo.load_session(self.manager,ident)
            after=Stage6BiologyView(loaded).snapshot()
        self.assertEqual(before,after)
    def test_biology_contract_contains_no_consent_or_relationship_fields(self):
        payload=self.engine.resolve_inheritance(record_id='inheritance:sep',event_id='event:sep',parent_lineage_a=self.lineage,parent_lineage_b=self.lineage,parent_a_traits={},parent_b_traits={},cause_ref='cause:sep')
        text=repr(payload.__dataclass_fields__).lower(); self.assertNotIn('consent',text); self.assertNotIn('relationship',text); self.assertNotIn('profession',text)

if __name__=='__main__': unittest.main(verbosity=2)
