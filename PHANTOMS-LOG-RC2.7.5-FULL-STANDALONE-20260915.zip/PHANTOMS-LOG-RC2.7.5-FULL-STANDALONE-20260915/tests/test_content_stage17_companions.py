
import json,unittest
from pathlib import Path
from runtime.content_stage17.companions import *
ROOT=Path(__file__).resolve().parents[1]; D=json.loads((ROOT/"content/full_version/stage17_companions.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_roles(self): self.assertGreaterEqual(len(D["crew_roles"]),5)
 def test_no_implicit_join(self): self.assertFalse(D["recruitment_contract"]["implicit_join"]); self.assertTrue(D["recruitment_contract"]["candidate_decision_required"])
 def test_candidate_only(self):
  o=recruitment_offer("npc","p","ROLE_SCOUT",[],1,10); self.assertIsNone(recruitment_decision(o,"p","ACCEPT",2))
 def test_accept_refuse(self):
  o=recruitment_offer("npc","p","ROLE_SCOUT",[],1,10); self.assertEqual(recruitment_decision(o,"npc","ACCEPT",2)["status"],"ACCEPTED"); self.assertEqual(recruitment_decision(o,"npc","REFUSE",2)["status"],"REFUSED")
 def test_expiry(self):
  o=recruitment_offer("npc","p","ROLE_SCOUT",[],1,10); self.assertIsNone(recruitment_decision(o,"npc","ACCEPT",11))
 def test_loyalty_bounded(self): self.assertEqual(loyalty_delta({"trust":90},{"trust":50})["trust"],100)
 def test_orders_not_commands(self): self.assertTrue(order_request("p","npc","follow","EV")["requires_actor_decision"])
 def test_desertion(self):
  self.assertLess(desertion_pressure({"trust":50,"satisfaction":50,"fear":0}),65)
  self.assertGreaterEqual(desertion_pressure({"trust":-80,"satisfaction":-80,"fear":80},True,True,True),65)
 def test_departure_authority(self):
  self.assertIsNone(departure_proposal("npc","unsafe_conditions",20,"EV")); p=departure_proposal("npc","unsafe_conditions",80,"EV"); self.assertTrue(p["authority_required"])
if __name__=="__main__": unittest.main()
