import tempfile
import unittest
from uuid import uuid4

from runtime.stage3a.integration import RuntimeDelta
from runtime.stage3a.kernel import (
    Authority, CommitKernel, CommitRecord, Delta, Domain, Mode, Proposal, StateStore, Verdict,
)
from runtime.stage3c.isolation import FilesystemRunRepository, RunSessionManager
from runtime.stage3d.epistemic import (
    PPM,
    DistortionPolicy,
    DistortionVariant,
    EpistemicEngine,
    InformationGraph,
    InformationRoute,
    PendingStatus,
    PropagationModifiers,
    SourceType,
    Stage3DError,
    epistemic_stamp,
)


def graph_basic():
    return InformationGraph(
        (
            InformationRoute("AB", "A", "B", 10, channel="ROAD", reliability_ppm=900_000),
            InformationRoute("BC", "B", "C", 20, channel="CARAVAN", reliability_ppm=800_000),
            InformationRoute("AC", "A", "C", 40, channel="RADIO", reliability_ppm=950_000),
        ),
        hub_flow_ppm={"B": 1_250_000},
    )


class Stage3DTests(unittest.TestCase):
    def setUp(self):
        self.store = StateStore()
        self.kernel = CommitKernel(self.store, world_seed=12345)
        from runtime.stage3a.integration import RuntimeAuthorityBridge
        self.bridge = RuntimeAuthorityBridge(self.kernel)
        self.engine = EpistemicEngine(self.bridge, run_seed=12345, graph=graph_basic())

    def test_world_truth_alone_is_not_actor_knowledge(self):
        self.bridge.commit_runtime_event(
            event_id="T1", cause="truth",
            deltas=(RuntimeDelta("WORLD_TRUTH", "vault.code", 42, "RULE_KERNEL", "truth"),),
        )
        self.assertNotIn("npc:1", self.store.actor_knowledge)
        ctx = self.engine.actor_epistemic_context("npc:1", knowledge_keys=("vault.code",))
        self.assertEqual(ctx["ACTOR_KNOWLEDGE"], {})
        self.assertNotIn("WORLD_TRUTH", ctx)

    def test_low_level_runtime_knowledge_requires_stage3d_stamp(self):
        r = self.bridge.commit_runtime_event(
            event_id="K0", cause="bad",
            deltas=(RuntimeDelta(
                "ACTOR_KNOWLEDGE", "x", 1, "KNOWLEDGE_ROUTER", "bad",
                actor_id="npc:1", provenance="heard",
            ),),
        )
        self.assertEqual(r.verdict, Verdict.REJECT)
        self.assertTrue(any("KNOWLEDGE_EPISTEMIC_METADATA_REQUIRED" in x for x in r.reasons))

    def test_direct_actor_observation_records_source_time_and_origin(self):
        r = self.engine.record_actor_observation(
            actor_id="npc:1", fact_key="door.open", value=True, event_id="OBS1",
            source_id="eyes:npc1", location="ROOM-A", world_time=77,
        )
        self.assertIsInstance(r, CommitRecord)
        rec = self.store.actor_knowledge["npc:1"]["door.open"]
        self.assertTrue(rec["value"])
        self.assertEqual(rec["epistemic"]["source_type"], SourceType.DIRECT_OBSERVATION.value)
        self.assertEqual(rec["epistemic"]["source_id"], "eyes:npc1")
        self.assertEqual(rec["epistemic"]["origin_location"], "ROOM-A")
        self.assertEqual(rec["epistemic"]["learned_at"], 77)
        self.assertEqual(rec["epistemic"]["path"], [])

    def test_direct_player_observation_is_player_facing_but_not_truth(self):
        before_truth = dict(self.store.world_truth)
        r = self.engine.record_player_observation(
            fact_key="sign.text", value="KEEP OUT", event_id="POBS1",
            source_id="sign:12", location="GATE", world_time=8,
        )
        self.assertIsInstance(r, CommitRecord)
        self.assertEqual(self.store.world_truth, before_truth)
        view = self.bridge.project_player_narration()
        self.assertEqual(view["PLAYER_KNOWLEDGE"]["sign.text"], "KEEP OUT")
        self.assertNotIn("WORLD_TRUTH", view)

    def test_route_uses_weighted_shortest_arrival(self):
        plan = graph_basic().plan("A", "C", depart_at=100)
        # Hub B makes A->B->C faster than direct A->C in this profile.
        self.assertEqual(tuple(h.edge_id for h in plan.hops), ("AB", "BC"))
        self.assertEqual(plan.hops[0].depart_at, 100)
        self.assertEqual(plan.hops[-1].arrive_at, plan.arrive_at)
        self.assertLess(plan.arrive_at, 140)

    def test_route_is_bidirectional(self):
        plan = graph_basic().plan("C", "A", depart_at=0)
        self.assertTrue(plan.hops)
        self.assertEqual(plan.hops[0].origin, "C")
        self.assertEqual(plan.hops[-1].destination, "A")

    def test_closed_edge_changes_reachability(self):
        g = InformationGraph((InformationRoute("AB", "A", "B", 5, bidirectional=False),))
        with self.assertRaises(Stage3DError):
            g.plan("A", "B", depart_at=0, modifiers=PropagationModifiers(closed_edges=frozenset({"AB"})))

    def test_traffic_hub_season_and_event_modifiers_affect_arrival(self):
        g = InformationGraph((InformationRoute("AB", "A", "B", 100),), hub_flow_ppm={"B": PPM})
        base = g.plan("A", "B", depart_at=0).arrive_at
        faster = g.plan("A", "B", depart_at=0, modifiers=PropagationModifiers(
            traffic_ppm={"AB": 2_000_000}, hub_flow_ppm={"B": 2_000_000},
        )).arrive_at
        slower = g.plan("A", "B", depart_at=0, modifiers=PropagationModifiers(
            season_delay_ppm={"AB": 2_000_000}, event_delay_ppm={"AB": 2_000_000},
        )).arrive_at
        self.assertLess(faster, base)
        self.assertGreater(slower, base)

    def test_equal_time_route_choice_is_deterministic(self):
        g = InformationGraph((
            InformationRoute("A1", "A", "B", 5, bidirectional=False),
            InformationRoute("B1", "B", "D", 5, bidirectional=False),
            InformationRoute("A2", "A", "C", 5, bidirectional=False),
            InformationRoute("C1", "C", "D", 5, bidirectional=False),
        ))
        paths = [tuple(h.edge_id for h in g.plan("A", "D", depart_at=0).hops) for _ in range(20)]
        self.assertEqual(len(set(paths)), 1)

    def test_queue_relay_requires_source_actor_knowledge(self):
        with self.assertRaises(Stage3DError):
            self.engine.queue_actor_relay(
                message_id="M1", source_actor_id="npc:a", target_actor_id="npc:b",
                fact_key="x", source_location="A", target_location="B", depart_at=0,
            )

    def test_bootstrap_knowledge_without_epistemic_stamp_cannot_relay(self):
        r = self.kernel.process(Proposal(
            mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="INITK", cause="init",
            deltas=(Delta(
                Domain.ACTOR_KNOWLEDGE, "x", 1, Authority.SYSTEM_INIT, "init",
                actor_id="npc:a", provenance="bootstrap",
            ),),
        ))
        self.assertIsInstance(r, CommitRecord)
        with self.assertRaises(Stage3DError):
            self.engine.queue_actor_relay(
                message_id="M2", source_actor_id="npc:a", target_actor_id="npc:b",
                fact_key="x", source_location="A", target_location="B", depart_at=0,
            )

    def _seed_source(self, value="alpha"):
        r = self.engine.record_actor_observation(
            actor_id="npc:a", fact_key="rumor", value=value, event_id="SRC",
            source_id="eyes:a", location="A", world_time=0,
        )
        self.assertIsInstance(r, CommitRecord)

    def test_information_does_not_arrive_early(self):
        self._seed_source()
        queued = self.engine.queue_actor_relay(
            message_id="M3", source_actor_id="npc:a", target_actor_id="npc:b",
            fact_key="rumor", source_location="A", target_location="C", depart_at=10,
        )
        r = self.engine.deliver_due(world_time=queued.arrival_at - 1, event_id="DEL0")
        self.assertEqual(r.verdict, Verdict.HOLD)
        self.assertNotIn("npc:b", self.store.actor_knowledge)

    def test_information_arrives_with_full_route_metadata(self):
        self._seed_source()
        queued = self.engine.queue_actor_relay(
            message_id="M4", source_actor_id="npc:a", target_actor_id="npc:b",
            fact_key="rumor", source_location="A", target_location="C", depart_at=10,
        )
        r = self.engine.deliver_due(world_time=queued.arrival_at, event_id="DEL1")
        self.assertIsInstance(r, CommitRecord)
        rec = self.store.actor_knowledge["npc:b"]["rumor"]
        self.assertEqual(rec["value"], "alpha")
        self.assertEqual(rec["epistemic"]["learned_at"], queued.arrival_at)
        self.assertEqual(len(rec["epistemic"]["path"]), len(queued.route.hops))
        pending = self.store.runtime_state["epistemic.pending:M4"]
        self.assertEqual(pending["status"], PendingStatus.DELIVERED.value)

    def test_relay_confidence_degrades_by_route_reliability(self):
        self._seed_source()
        queued = self.engine.queue_actor_relay(
            message_id="M5", source_actor_id="npc:a", target_actor_id="npc:b",
            fact_key="rumor", source_location="A", target_location="C", depart_at=0,
        )
        self.engine.deliver_due(world_time=queued.arrival_at, event_id="DEL2")
        conf = self.store.actor_knowledge["npc:b"]["rumor"]["epistemic"]["confidence_ppm"]
        self.assertLess(conf, PPM)
        self.assertEqual(conf, queued.route.confidence_ppm)

    def test_predeclared_distortion_changes_knowledge_not_world_truth(self):
        self.bridge.commit_runtime_event(
            event_id="TRUTH", cause="truth",
            deltas=(RuntimeDelta("WORLD_TRUTH", "rumor", "alpha", "RULE_KERNEL", "truth"),),
        )
        self._seed_source("alpha")
        policy = DistortionPolicy((DistortionVariant("misheard", PPM, "beta"),))
        queued = self.engine.queue_actor_relay(
            message_id="M6", source_actor_id="npc:a", target_actor_id="npc:b",
            fact_key="rumor", source_location="A", target_location="B", depart_at=0,
            distortion_policy=policy,
        )
        self.engine.deliver_due(world_time=queued.arrival_at, event_id="DEL3")
        self.assertEqual(self.store.actor_knowledge["npc:b"]["rumor"]["value"], "beta")
        self.assertEqual(self.store.world_truth["rumor"], "alpha")
        tags = self.store.actor_knowledge["npc:b"]["rumor"]["epistemic"]["distortions"]
        self.assertTrue(tags and "misheard" in tags[0])

    def test_distortion_is_seed_deterministic(self):
        def one():
            store = StateStore()
            kernel = CommitKernel(store, world_seed=55)
            from runtime.stage3a.integration import RuntimeAuthorityBridge
            eng = EpistemicEngine(RuntimeAuthorityBridge(kernel), run_seed=55, graph=graph_basic())
            eng.record_actor_observation(
                actor_id="a", fact_key="x", value="A", event_id="S", source_id="eye", location="A", world_time=0,
            )
            q = eng.queue_actor_relay(
                message_id="same", source_actor_id="a", target_actor_id="b", fact_key="x",
                source_location="A", target_location="C", depart_at=1,
                distortion_policy=DistortionPolicy((DistortionVariant("v", 500_000, "B"),)),
            )
            eng.deliver_due(world_time=q.arrival_at, event_id="D")
            rec = store.actor_knowledge["b"]["x"]
            return rec["value"], tuple(rec["epistemic"]["distortions"])
        self.assertEqual(one(), one())

    def test_pending_messages_are_run_isolated(self):
        g = graph_basic()
        p = str(uuid4())
        manager = RunSessionManager(master_seed=7, information_graph=g)
        a = manager.create_run(player_uuid=p, run_uuid=str(uuid4()))
        b = manager.create_run(player_uuid=p, run_uuid=str(uuid4()))
        a.epistemics.record_actor_observation(
            actor_id="a", fact_key="x", value=1, event_id="S", source_id="eye", location="A", world_time=0,
        )
        a.epistemics.queue_actor_relay(
            message_id="Q", source_actor_id="a", target_actor_id="b", fact_key="x",
            source_location="A", target_location="B", depart_at=0,
        )
        self.assertIn("epistemic.pending:Q", a.store.runtime_state)
        self.assertNotIn("epistemic.pending:Q", b.store.runtime_state)

    def test_pending_and_epistemic_metadata_survive_save_load(self):
        g = graph_basic()
        p = str(uuid4())
        manager = RunSessionManager(master_seed=8, information_graph=g)
        session = manager.create_run(player_uuid=p, run_uuid=str(uuid4()))
        session.epistemics.record_actor_observation(
            actor_id="a", fact_key="x", value=1, event_id="S", source_id="eye", location="A", world_time=0,
        )
        q = session.epistemics.queue_actor_relay(
            message_id="Q2", source_actor_id="a", target_actor_id="b", fact_key="x",
            source_location="A", target_location="C", depart_at=3,
        )
        identity = session.identity
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(td)
            repo.save(session)
            fresh = RunSessionManager(master_seed=8, information_graph=g)
            loaded = repo.load_session(fresh, identity)
            self.assertIn("epistemic.pending:Q2", loaded.store.runtime_state)
            loaded.epistemics.deliver_due(world_time=q.arrival_at, event_id="DL")
            meta = loaded.store.actor_knowledge["b"]["x"]["epistemic"]
            self.assertEqual(meta["source_type"], SourceType.RELAY.value)
            self.assertTrue(meta["path"])

    def test_actor_epistemic_context_exposes_source_but_not_truth(self):
        self.engine.record_actor_observation(
            actor_id="npc:1", fact_key="x", value=5, event_id="O", source_id="sensor:1", location="A", world_time=9,
            source_type=SourceType.SENSOR,
        )
        self.store.world_truth["secret"] = "hidden"
        ctx = self.engine.actor_epistemic_context("npc:1", knowledge_keys=("x", "secret"))
        self.assertEqual(ctx["ACTOR_KNOWLEDGE"]["x"]["value"], 5)
        self.assertEqual(ctx["ACTOR_KNOWLEDGE"]["x"]["epistemic"]["source_type"], "SENSOR")
        self.assertNotIn("secret", ctx["ACTOR_KNOWLEDGE"])
        self.assertNotIn("WORLD_TRUTH", ctx)

    def test_session_manager_wires_epistemic_engine(self):
        g = graph_basic()
        manager = RunSessionManager(master_seed=9, information_graph=g)
        s = manager.create_run(player_uuid=str(uuid4()), run_uuid=str(uuid4()))
        self.assertIsInstance(s.epistemics, EpistemicEngine)
        self.assertIs(s.epistemics.graph, g)
        self.assertEqual(s.epistemics.run_seed, s.run_seed)

    def test_invalid_route_and_modifier_profiles_fail_closed(self):
        with self.assertRaises(Stage3DError):
            InformationGraph((InformationRoute("BAD", "A", "A", 1),))
        with self.assertRaises(Stage3DError):
            graph_basic().plan("A", "B", depart_at=0, modifiers=PropagationModifiers(traffic_ppm={"AB": 0}))

    def test_same_location_delivery_has_zero_path_and_immediate_arrival(self):
        g = InformationGraph()
        plan = g.plan("A", "A", depart_at=15)
        self.assertEqual(plan.arrive_at, 15)
        self.assertEqual(plan.hops, ())


if __name__ == "__main__":
    unittest.main(verbosity=2)
