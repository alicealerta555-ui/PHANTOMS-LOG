from __future__ import annotations

import unittest
from dataclasses import FrozenInstanceError
from uuid import uuid4

from runtime.stage3a.kernel import Authority, Delta, Domain, Mode, Proposal
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.context import RuntimeContext, RuntimeContextError
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.playable_runtime import PlayableRuntime, PlayableRuntimeError


class Stage9RuntimeContextTests(unittest.TestCase):
    def setUp(self) -> None:
        self.player_uuid = str(uuid4())
        self.run_uuid = str(uuid4())
        self.manager = RunSessionManager(master_seed=1001)
        self.session = self.manager.create_run(player_uuid=self.player_uuid, run_uuid=self.run_uuid)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(self.player_uuid, self.run_uuid, "actor:player")
        self.registry.register(self.identity, actor_definition_id="test.player")
        self.runtime = PlayableRuntime(self.session, self.registry)

    def test_context_capture_binds_identity_turn_window_and_revision(self) -> None:
        context = self.runtime.create_context(
            self.identity,
            turn_id="turn:001",
            action_window_id="window:001",
        )
        self.assertEqual(context.runtime_identity, self.identity)
        self.assertEqual(context.turn_id, "turn:001")
        self.assertEqual(context.action_window_id, "window:001")
        self.assertEqual(context.state_revision, self.session.store.revision)
        self.assertEqual(context.player_uuid, self.player_uuid)
        self.assertEqual(context.run_uuid, self.run_uuid)
        self.assertEqual(context.actor_instance_id, "actor:player")

    def test_context_is_immutable(self) -> None:
        context = self.runtime.create_context(
            self.identity,
            turn_id="turn:immutable",
            action_window_id="window:immutable",
        )
        with self.assertRaises(FrozenInstanceError):
            context.turn_id = "turn:changed"  # type: ignore[misc]

    def test_context_rejects_missing_or_noncanonical_turn_id(self) -> None:
        with self.assertRaisesRegex(RuntimeContextError, "MISSING_TURN_ID"):
            RuntimeContext(self.identity, "", "window:1", 0)
        with self.assertRaisesRegex(RuntimeContextError, "NONCANONICAL_TURN_ID"):
            RuntimeContext(self.identity, " turn:1", "window:1", 0)

    def test_context_rejects_missing_or_invalid_action_window_id(self) -> None:
        with self.assertRaisesRegex(RuntimeContextError, "MISSING_ACTION_WINDOW_ID"):
            RuntimeContext(self.identity, "turn:1", "", 0)
        with self.assertRaisesRegex(RuntimeContextError, "INVALID_ACTION_WINDOW_ID"):
            RuntimeContext(self.identity, "turn:1", "window with spaces", 0)

    def test_context_rejects_invalid_revision(self) -> None:
        with self.assertRaisesRegex(RuntimeContextError, "INVALID_STATE_REVISION"):
            RuntimeContext(self.identity, "turn:1", "window:1", -1)
        with self.assertRaisesRegex(RuntimeContextError, "INVALID_STATE_REVISION"):
            RuntimeContext(self.identity, "turn:1", "window:1", True)  # type: ignore[arg-type]

    def test_capture_rejects_unregistered_actor(self) -> None:
        missing = RuntimeIdentity(self.player_uuid, self.run_uuid, "actor:missing")
        with self.assertRaises(Exception):
            self.runtime.create_context(
                missing,
                turn_id="turn:missing",
                action_window_id="window:missing",
            )

    def test_capture_rejects_wrong_run(self) -> None:
        wrong = RuntimeIdentity(self.player_uuid, str(uuid4()), "actor:player")
        with self.assertRaises(Exception):
            self.runtime.create_context(
                wrong,
                turn_id="turn:wrong",
                action_window_id="window:wrong",
            )

    def test_context_as_dict_is_transport_only(self) -> None:
        context = self.runtime.create_context(
            self.identity,
            turn_id="turn:dict",
            action_window_id="window:dict",
        )
        self.assertEqual(
            context.as_dict(),
            {
                "player_uuid": self.player_uuid,
                "run_uuid": self.run_uuid,
                "actor_instance_id": "actor:player",
                "turn_id": "turn:dict",
                "action_window_id": "window:dict",
                "state_revision": self.session.store.revision,
            },
        )
        self.assertNotIn("state", context.as_dict())
        self.assertNotIn("store", context.as_dict())

    def test_context_revision_is_snapshot_and_does_not_follow_mutation(self) -> None:
        context = self.runtime.create_context(
            self.identity,
            turn_id="turn:snapshot",
            action_window_id="window:snapshot",
        )
        before = context.state_revision
        event_id = "stage9:context:advance"
        self.session.kernel.process(
            Proposal(
                mode=Mode.COMMIT,
                source=Authority.COMMIT_KERNEL,
                event_id=event_id,
                cause="CONTEXT_TEST",
                deltas=(
                    Delta(
                        Domain.RUNTIME_STATE,
                        "stage9.context.bump",
                        1,
                        Authority.RULE_KERNEL,
                        "CONTEXT_TEST",
                        source_event_id=event_id,
                    ),
                ),
            )
        )
        self.assertGreater(self.session.store.revision, before)
        self.assertEqual(context.state_revision, before)


if __name__ == "__main__":
    unittest.main()
