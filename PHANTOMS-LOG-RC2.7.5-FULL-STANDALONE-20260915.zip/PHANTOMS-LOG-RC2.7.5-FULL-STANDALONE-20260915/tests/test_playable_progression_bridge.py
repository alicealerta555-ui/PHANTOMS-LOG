from pathlib import Path
import tempfile

from playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, Domain
from runtime.full_version.progression_runtime import PROGRESSION_RUNTIME_KEY

ROOT=Path(__file__).resolve().parents[1]


def make_game(tmp):
    g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class='GHOST',master_seed=20260913)
    g.complete_character(g.creation_template())
    return g


def test_committed_search_updates_hidden_progression_and_persists():
    with tempfile.TemporaryDirectory() as tmp:
        g=make_game(tmp)
        assert g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,PROGRESSION_RUNTIME_KEY) is None
        text,_=g.handle('/search')
        assert 'Weltzeit' in text
        rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,PROGRESSION_RUNTIME_KEY)
        assert rec['run_uuid']==g.identity.run_uuid
        affinities=rec['payload']['progression']['affinities']
        assert affinities['AFF_PERCEPTION']>0 or affinities['AFF_SURVIVAL']>0 or affinities['AFF_ADAPTATION']>0
        g2=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),master_seed=20260913)
        rec2=g2.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,PROGRESSION_RUNTIME_KEY)
        assert rec2==rec


def test_failed_action_does_not_learn():
    with tempfile.TemporaryDirectory() as tmp:
        g=make_game(tmp)
        before=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,PROGRESSION_RUNTIME_KEY)
        # impossible move is rejected before semantic commit
        try:
            g.execute(action_type='MOVE',raw_input='go nowhere',parameters={'destination_location_id':'loc:not_real'})
        except Exception:
            pass
        after=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,PROGRESSION_RUNTIME_KEY)
        assert after==before
