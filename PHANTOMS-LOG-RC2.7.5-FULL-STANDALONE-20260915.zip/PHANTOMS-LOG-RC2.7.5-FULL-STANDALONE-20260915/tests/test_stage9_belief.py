from __future__ import annotations
import unittest
from uuid import uuid4

from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import StateAuthority, AuthorityStatus
from runtime.stage9.belief import BeliefCommitAdapter, BELIEF_RUNTIME_KEY
from runtime.stage9.effects import EffectProposal, EffectType, AuthorityDomain
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.actor_context import ActorContextProjector
from runtime.stage9.save_snapshot import CanonicalSaveSnapshotBuilder
from runtime.stage9.rehydration import Stage9Rehydrator

class Stage9BeliefTests(unittest.TestCase):
    def setUp(self):
        self.seed=8812; self.m=RunSessionManager(master_seed=self.seed); self.p=str(uuid4()); self.s=self.m.create_run(player_uuid=self.p)
        self.r=RunActorRegistry(self.s); self.i=RuntimeIdentity(self.p,self.s.identity.run_uuid,'actor:npc'); self.r.register(self.i,actor_definition_id='npc')
        self.a=StateAuthority(self.s,actor_registry=self.r); self.b=BeliefCommitAdapter(self.s,actor_registry=self.r)
    def proposal(self,eid='belief:e1'):
        return EffectProposal(effect_id=eid,run_uuid=self.s.identity.run_uuid,resolution_id='res:b',source_action_id='act:b',effect_type=EffectType.BELIEF_UPDATE,target_ref='actor:npc',payload={'actor_instance_id':'actor:npc','belief_key':'door.safe','value':False,'provenance':'INFERENCE','confidence_ppm':750000},authority_domain=AuthorityDomain.BELIEF,expected_state_revision=self.s.store.revision)
    def test_belief_commit_is_separate_from_knowledge_and_truth(self):
        before_truth=dict(self.s.store.world_truth); before_knowledge=dict(self.s.store.actor_knowledge)
        d=self.a.authorize(self.proposal()); self.assertEqual(d.status,AuthorityStatus.ALLOW)
        self.b.apply(d,commit_id='commit:b1',event_id='event:b1')
        self.assertEqual(self.b.snapshot_for_actor('actor:npc')['door.safe']['value'],False)
        self.assertEqual(dict(self.s.store.world_truth),before_truth); self.assertEqual(dict(self.s.store.actor_knowledge),before_knowledge)
    def test_actor_context_projects_belief_separately(self):
        d=self.a.authorize(self.proposal()); self.b.apply(d,commit_id='commit:b2',event_id='event:b2')
        c=ActorContextProjector(self.s,self.r,self.i).project()
        self.assertEqual(len(c.beliefs),1); self.assertEqual(c.beliefs[0].belief_key,'door.safe'); self.assertEqual(c.knowledge,())
    def test_belief_retry_idempotent(self):
        d=self.a.authorize(self.proposal()); first=self.b.apply(d,commit_id='commit:b3',event_id='event:b3'); rev=self.s.store.revision
        # retry re-enters Authority at the current revision but keeps stable semantic ids
        d2=self.a.authorize(self.proposal())
        again=self.b.apply(d2,commit_id='commit:b3',event_id='event:b3-retry')
        self.assertEqual(self.s.store.revision,rev)
    def test_unregistered_actor_rejected_by_authority(self):
        q=EffectProposal(effect_id='belief:bad',run_uuid=self.s.identity.run_uuid,resolution_id='r',source_action_id='a',effect_type=EffectType.BELIEF_UPDATE,target_ref='actor:ghost',payload={'actor_instance_id':'actor:ghost','belief_key':'x','value':True,'provenance':'INFERENCE'},authority_domain=AuthorityDomain.BELIEF,expected_state_revision=self.s.store.revision)
        self.assertNotEqual(self.a.authorize(q).status,AuthorityStatus.ALLOW)
    def test_save_rehydrate_preserves_belief_and_fresh_handle(self):
        d=self.a.authorize(self.proposal()); self.b.apply(d,commit_id='commit:b4',event_id='event:b4')
        snap=CanonicalSaveSnapshotBuilder(self.s).capture(); rr=Stage9Rehydrator(RunSessionManager(master_seed=self.seed)).rehydrate(snap)
        self.assertIsNot(rr.belief_commit,self.b); self.assertEqual(rr.belief_commit.snapshot_for_actor('actor:npc')['door.safe']['confidence_ppm'],750000)
        self.assertEqual(rr.canonical_snapshot.canonical_json,snap.canonical_json)

if __name__=='__main__': unittest.main()
