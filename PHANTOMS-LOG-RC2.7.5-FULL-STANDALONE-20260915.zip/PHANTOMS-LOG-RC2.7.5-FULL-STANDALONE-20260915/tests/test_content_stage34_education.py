
import json, unittest
from pathlib import Path
from runtime.content_stage34.education import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage34_education_training.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_modes(self):
  self.assertGreaterEqual(len(D["learning_modes"]),5)

 def test_progress_requires_time(self):
  self.assertEqual(training_progress(10,20,0),10)

 def test_fatigue_reduces_progress(self):
  a=training_progress(0,20,60,fatigue=0)
  b=training_progress(0,20,60,fatigue=90)
  self.assertGreater(a,b)

 def test_progress_bounded(self):
  self.assertEqual(training_progress(95,100,600,100,100,0,100),100)

 def test_skill_gain_authority(self):
  p=skill_gain_candidate("a","SKILL_TECHNOLOGY",50,40,"EV")
  self.assertTrue(p["authority_required"])
  self.assertGreaterEqual(p["proposed_skill"],50)

 def test_no_gain_without_progress(self):
  self.assertIsNone(skill_gain_candidate("a","SKILL_TECHNOLOGY",50,0,"EV"))

 def test_certification_not_skill_write(self):
  c=certification_record("C","I","a","SKILL_TECHNOLOGY",70,1)
  self.assertFalse(c["writes_skill_directly"])

 def test_institution_capacity(self):
  self.assertTrue(institution_access(10,9,True))
  self.assertFalse(institution_access(10,10,True))
  self.assertFalse(institution_access(10,0,False))

 def test_apprenticeship_requires_context(self):
  self.assertIsNone(apprenticeship_candidate("a","b","SKILL_TECHNOLOGY","",60,"EV"))

 def test_apprenticeship_authority(self):
  p=apprenticeship_candidate("a","b","SKILL_TECHNOLOGY","WORK",60,"EV")
  self.assertTrue(p["authority_required"])

 def test_skill_bands(self):
  self.assertEqual(skill_band(0),"NOVICE")
  self.assertEqual(skill_band(45),"COMPETENT")
  self.assertEqual(skill_band(90),"EXPERT")

if __name__=="__main__": unittest.main()
