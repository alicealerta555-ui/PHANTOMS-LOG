
import json, unittest
from pathlib import Path
from runtime.content_stage39.media import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage39_media_archives.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_media_types(self):
  self.assertGreaterEqual(len(D["media_types"]),5)

 def test_publication_not_truth(self):
  p=publication_record("P","W","PUB","MEDIA_PRINT",1,{"src":"W"})
  self.assertFalse(p["truth_asserted_by_system"])

 def test_publication_reach_bounded(self):
  self.assertEqual(publication_reach(100,10000,10000),100)

 def test_public_archive_access(self):
  a=next(x for x in D["archive_types"] if x["id"]=="ARCHIVE_PUBLIC")
  self.assertTrue(archive_access(a))

 def test_restricted_archive_access(self):
  a=next(x for x in D["archive_types"] if x["id"]=="ARCHIVE_RESTRICTED")
  self.assertFalse(archive_access(a,authorized=False))
  self.assertTrue(archive_access(a,authorized=True))

 def test_censorship_requires_basis(self):
  self.assertIsNone(censorship_candidate("BLOCK_PUBLICATION","P","AUTH","","EV"))

 def test_censorship_not_memory_wipe(self):
  p=censorship_candidate("BLOCK_PUBLICATION","P","AUTH","RULE","EV")
  self.assertFalse(p["erases_actor_knowledge"])
  self.assertTrue(p["authority_required"])

 def test_preservation_requires_time(self):
  self.assertEqual(preservation_projection(80,0,0,0),80)

 def test_preservation_degrades(self):
  self.assertLess(preservation_projection(80,365,0,0),80)

 def test_record_states(self):
  self.assertEqual(record_state(100),"INTACT")
  self.assertEqual(record_state(40),"DAMAGED")
  self.assertEqual(record_state(0),"LOST")

 def test_archive_record_provenance(self):
  self.assertIsNone(archive_record("R","A","S",1,{},100))
  r=archive_record("R","A","S",1,{"origin":"S"},100)
  self.assertIsNotNone(r)

if __name__=="__main__": unittest.main()
