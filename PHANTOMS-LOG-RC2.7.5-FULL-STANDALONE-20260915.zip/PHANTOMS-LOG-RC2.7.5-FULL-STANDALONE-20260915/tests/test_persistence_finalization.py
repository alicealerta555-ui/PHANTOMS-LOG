import copy
from contextlib import contextmanager

from runtime.player_progression.model import PlayerProgressionState, AFFINITIES
from runtime.player_progression.behavior import RawActionEvent
from runtime.player_progression.pipeline import PlayerLearningRuntime
from runtime.player_progression.persistence import (
    CURRENT_SCHEMA_VERSION,
    ProgressionSaveError,
    migrate_payload,
)

@contextmanager
def raises(error):
    try:
        yield
    except error:
        return
    raise AssertionError(f"{error.__name__} was not raised")


def make_runtime():
    return PlayerLearningRuntime(PlayerProgressionState(
        player_uuid="player-A",
        run_uuid="run-A",
        start_class="GHOST",
    ))


def test_roundtrip_preserves_identity_and_hidden_state():
    rt = make_runtime()
    for i in range(5):
        rt.observe(RawActionEvent(
            action_family="stealth",
            affinity_weights={"AFF_STEALTH": 1.0, "AFF_MOBILITY": 0.4},
            location_id=f"loc-{i}",
            target_kind="guard",
            outcome="success",
            difficulty_hint=1.2,
            consequence_hint=1.1,
            context_tags=("dark",),
        ))
    dumped = rt.to_dict()
    loaded = PlayerLearningRuntime.from_dict(copy.deepcopy(dumped))
    assert loaded.progression.player_uuid == "player-A"
    assert loaded.progression.run_uuid == "run-A"
    assert loaded.progression.affinities == rt.progression.affinities
    assert loaded.tracker_state.accepted_events == rt.tracker_state.accepted_events
    assert dumped["schema_version"] == CURRENT_SCHEMA_VERSION


def test_early_direct_payload_migrates_without_inventing_progress():
    old = {
        "schema_version": 1,
        "player_uuid": "p",
        "run_uuid": "r",
        "start_class": "operator",
        "affinities": {"AFF_TECH": 3.25, "BOGUS": 999},
        "unlocked_insights": ["A", "A", "B"],
    }
    result = migrate_payload(old)
    p = result.payload["progression"]
    assert p["start_class"] == "OPERATOR"
    assert p["affinities"]["AFF_TECH"] == 3.25
    assert "BOGUS" not in p["affinities"]
    assert set(p["affinities"]) == set(AFFINITIES)
    assert p["unlocked_insights"] == ["A", "B"]
    assert result.payload["tracker_state"]["accepted_events"] == 0


def test_missing_identity_fails_closed():
    with raises(ProgressionSaveError):
        migrate_payload({"run_uuid": "r", "start_class": "GHOST"})
    with raises(ProgressionSaveError):
        migrate_payload({"player_uuid": "p", "start_class": "GHOST"})


def test_invalid_class_fails_closed():
    with raises(ProgressionSaveError):
        migrate_payload({"player_uuid": "p", "run_uuid": "r", "start_class": "WIZARD"})


def test_save_load_does_not_cross_runs():
    rt = make_runtime()
    payload = rt.to_dict()
    other = copy.deepcopy(payload)
    other["progression"]["run_uuid"] = "run-B"
    loaded_a = PlayerLearningRuntime.from_dict(payload)
    loaded_b = PlayerLearningRuntime.from_dict(other)
    assert loaded_a.progression.run_uuid != loaded_b.progression.run_uuid


def test_ui_snapshot_stays_numeric_free_after_reload():
    rt = make_runtime()
    rt.observe(RawActionEvent(
        action_family="observe",
        affinity_weights={"AFF_PERCEPTION": 1.0},
        location_id="yard",
        target_kind="patrol",
        difficulty_hint=1.0,
        consequence_hint=1.0,
    ))
    loaded = PlayerLearningRuntime.from_dict(rt.to_dict())
    payload = loaded.visible_development()

    def walk(x):
        if isinstance(x, dict):
            for v in x.values(): walk(v)
        elif isinstance(x, (list, tuple)):
            for v in x: walk(v)
        else:
            assert not (isinstance(x, (int, float)) and not isinstance(x, bool))
    walk(payload)
