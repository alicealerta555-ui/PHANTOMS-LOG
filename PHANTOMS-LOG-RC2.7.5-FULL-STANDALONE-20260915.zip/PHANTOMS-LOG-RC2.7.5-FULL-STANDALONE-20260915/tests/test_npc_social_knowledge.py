from runtime.player_progression.npc_naming import NPCNameGenerator, NameRequest
from runtime.player_progression.npc_encounter import NPCFirstContactEngine, NPCVisualSnapshot, NPCEncounterContext, NPCPresentationProfile
from runtime.player_progression.npc_social import NPCSocialKnowledgeEngine, SocialSource


def setup_social():
    names = NPCNameGenerator(seed="social")
    names.generate(NameRequest("n1", "chimera", force_callsign=True))
    contact = NPCFirstContactEngine(names, seed="social-contact")
    social = NPCSocialKnowledgeEngine(names, contact.registry)
    return names, contact, social


def test_unmet_npc_is_not_recognized():
    _, _, social = setup_social()
    r = social.recognize("n1", "market")
    assert not r.recognized
    assert r.display_name == "Unbekannte Person"


def test_met_npc_can_be_recognized_without_new_information():
    _, contact, social = setup_social()
    contact.first_contact(NPCVisualSnapshot("n1"), NPCEncounterContext(encounter_type="crew", player_initiated_contact=True), NPCPresentationProfile(openness=.9, caution=.1, prefers_callsign=True))
    r = social.recognize("n1", "later")
    assert r.recognized
    assert r.display_name != "Unbekannte Person"


def test_unreliable_third_party_profession_stays_claim():
    _, _, social = setup_social()
    r = social.third_party_introduction("n1", "callsign", SocialSource("gossip", relation="third_party", reliability=.35), profession="Ärztin")
    assert "profession:Ärztin" in r.unresolved_claims
    assert social.encounters.get("n1").profession_known is False


def test_authoritative_direct_introduction_can_establish_profession():
    _, _, social = setup_social()
    r = social.third_party_introduction("n1", "full", SocialSource("registry", relation="public_record", reliability=.95, authority=.9, direct=True), profession="Ärztin")
    assert "profession" in r.new_information
    assert social.encounters.get("n1").known_profession == "Ärztin"


def test_self_disclosure_profession_is_not_blindly_true():
    _, _, social = setup_social()
    r = social.self_disclosure("n1", name_level="given", profession="Pilotin", reliability=.75)
    assert "profession:Pilotin" in r.unresolved_claims
    assert not social.encounters.get("n1").profession_known


def test_corroborated_self_disclosure_can_verify_profession():
    _, _, social = setup_social()
    social.record_rumor("n1", "profession", "Pilotin", "crew-mate", reliability=.8)
    r = social.self_disclosure("n1", profession="Pilotin", reliability=.8)
    assert social.encounters.get("n1").profession_known
    assert social.encounters.get("n1").known_profession == "Pilotin"


def test_contradictory_claims_are_preserved_not_silently_resolved():
    _, _, social = setup_social()
    social.record_rumor("n1", "profession", "Pilotin", "a", reliability=.5)
    r = social.record_rumor("n1", "profession", "Schmugglerin", "b", reliability=.5)
    assert any(x.startswith("profession:") for x in r.contradictions)


def test_host_verification_resolves_profession_fact():
    _, _, social = setup_social()
    social.record_rumor("n1", "profession", "Pilotin", "a", reliability=.4)
    r = social.verify_claim("n1", "profession", "Pilotin")
    assert social.encounters.get("n1").profession_known
    assert "profession" in r.new_information


def test_verified_relationship_stays_separate_from_rumor():
    _, _, social = setup_social()
    social.establish_relationship("n1", "n2", "Schwester", verified=False)
    assert "n2" not in social.registry.get("n1").known_relationships
    social.establish_relationship("n1", "n2", "Schwester", verified=True)
    assert social.registry.get("n1").known_relationships["n2"] == "Schwester"


def test_social_registry_roundtrip():
    names, contact, social = setup_social()
    contact.registry.get("n1").met_count = 1
    social.verify_claim("n1", "affiliation", "Greyline")
    raw = social.snapshot_for_save()
    restored = NPCSocialKnowledgeEngine.from_save(names, contact.registry, raw)
    assert "Greyline" in restored.registry.get("n1").known_affiliations


def test_adaptive_runtime_persists_social_knowledge():
    from runtime.player_progression.pipeline import PlayerLearningRuntime
    from runtime.player_progression.model import PlayerProgressionState
    from runtime.player_progression.adaptive_runtime import AdaptiveGameplayRuntime
    prog = PlayerProgressionState(player_uuid="p", run_uuid="r", start_class="GHOST")
    rt = AdaptiveGameplayRuntime.new(PlayerLearningRuntime(prog))
    rt.ensure_npc_name(NameRequest("social-npc", "thresholdborn", force_callsign=True))
    rt.present_npc(NPCVisualSnapshot("social-npc"), NPCEncounterContext(encounter_type="crew", player_initiated_contact=True), NPCPresentationProfile(openness=.9, caution=.1, prefers_callsign=True))
    rt.npc_third_party_introduction("social-npc", "full", SocialSource("record", relation="public_record", reliability=.95, authority=.95, direct=True), profession="Kartografin", affiliation="Greyline")
    raw = rt.snapshot_for_save()
    restored = AdaptiveGameplayRuntime.from_save(raw)
    assert restored.npc_first_contact.registry.get("social-npc").known_profession == "Kartografin"
    assert "Greyline" in restored.npc_social.registry.get("social-npc").known_affiliations
