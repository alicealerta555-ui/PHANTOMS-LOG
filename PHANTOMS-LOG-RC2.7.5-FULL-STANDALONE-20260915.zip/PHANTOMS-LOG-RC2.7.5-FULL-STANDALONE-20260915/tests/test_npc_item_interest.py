from runtime.player_progression.npc_item_interest import (
    NPCItemInterestEngine, ItemSnapshot, NPCEquipmentExpertise, ItemInterestContext,
    InterestAction, ModificationProposal, CalibrationTradeoff,
)


def npc(**kw):
    base = dict(npc_id="npc1", curiosity=.8, sociability=.7, trust=.5, familiarity=.5,
                item_knowledge=.6, repair_skill=.6, modification_skill=.6,
                regional_knowledge=.7, openness=.7)
    base.update(kw)
    return NPCEquipmentExpertise(**base)


def ctx(**kw):
    base = dict(region_id="r1", safe_to_talk=True, social_window=.7, conversation_open=True, turn=1)
    base.update(kw)
    return ItemInterestContext(**base)


def test_invisible_item_never_triggers():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("x", "X", "device", visible=False, regional_rarity=1.0)
    assert e.evaluate(item, npc(), ctx()).action == InterestAction.IGNORE


def test_rare_item_shows_visible_interest():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("x", "Vektor-9", "weapon", regional_rarity=.95)
    r = e.evaluate(item, npc(item_knowledge=.2, modification_skill=.1), ctx())
    assert r.visible_interest
    assert r.cues


def test_danger_defers_topic():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("x", "Vektor-9", "weapon", regional_rarity=.95)
    r = e.evaluate(item, npc(), ctx(danger=.9, safe_to_talk=False))
    assert r.action == InterestAction.DEFER
    assert r.deferred


def test_deferred_topic_can_return_later():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("x", "Vektor-9", "weapon", regional_rarity=.95)
    e.evaluate(item, npc(), ctx(danger=.9, safe_to_talk=False))
    r = e.revisit_deferred(item, npc(), ctx(danger=0, safe_to_talk=True, conversation_open=True, turn=3))
    assert r.action in {InterestAction.QUESTION, InterestAction.SUGGEST, InterestAction.NOTICE}


def test_visible_damage_can_be_warned_about():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("x", "Pumpe", "device", visible_damage=.8)
    r = e.evaluate(item, npc(repair_skill=.8), ctx())
    assert r.action == InterestAction.WARN
    assert r.damage_suspected


def test_hidden_damage_not_leaked_without_diagnostic_access():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("x", "Pumpe", "device", hidden_damage=1.0, regional_rarity=0)
    r = e.evaluate(item, npc(repair_skill=1.0), ctx(diagnostic_access=False))
    assert not r.damage_suspected


def test_hidden_damage_can_be_detected_with_diagnostic_access():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("x", "Pumpe", "device", hidden_damage=1.0)
    r = e.evaluate(item, npc(repair_skill=1.0), ctx(diagnostic_access=True))
    assert r.damage_suspected


def test_low_skill_asks_about_special_modification():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("x", "Gewehr", "weapon", modification_salience=.95)
    r = e.evaluate(item, npc(item_knowledge=.35, modification_skill=.2), ctx())
    assert r.action == InterestAction.QUESTION


def test_high_skill_trusted_npc_suggests_tradeoff_not_powerup():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("x", "Gewehr", "weapon", modification_salience=.9)
    r = e.evaluate(item, npc(modification_skill=.85, trust=.8, familiarity=.8), ctx())
    assert r.action == InterestAction.SUGGEST
    assert r.proposal is not None
    assert r.proposal.tradeoffs
    assert all(t.gain and t.cost for t in r.proposal.tradeoffs)


def test_stranger_does_not_unsolicitedly_teach_even_if_skilled():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("x", "Gewehr", "weapon", modification_salience=.9)
    r = e.evaluate(item, npc(modification_skill=.9, trust=0, familiarity=0), ctx(conversation_open=False, social_window=.2))
    assert r.action in {InterestAction.NOTICE, InterestAction.IGNORE}


def test_explicit_item_topic_allows_advice_without_deep_relationship():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("x", "Scanner", "scanner", modification_salience=.9)
    r = e.evaluate(item, npc(modification_skill=.85, trust=.1, familiarity=.1), ctx(explicit_item_topic=True))
    assert r.action == InterestAction.SUGGEST


def test_repetition_damps_unsolicited_interest():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("x", "Vektor-9", "weapon", regional_rarity=.6)
    first = e.evaluate(item, npc(curiosity=.5), ctx(conversation_open=False))
    for i in range(2, 12):
        last = e.evaluate(item, npc(curiosity=.5), ctx(conversation_open=False, turn=i))
    assert first.visible_interest >= last.visible_interest


def test_modification_proposal_rejects_pure_gain():
    p = ModificationProposal("bad", "bad", (), "hoch")
    try:
        p.validate()
    except ValueError:
        pass
    else:
        raise AssertionError("pure gain/no trade-off proposal must fail")


def test_persistence_roundtrip():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("x", "Vektor-9", "weapon", regional_rarity=.95)
    e.evaluate(item, npc(), ctx(danger=.9, safe_to_talk=False))
    snap = e.snapshot_for_save()
    e2 = NPCItemInterestEngine.from_save(snap)
    assert e2.memory.deferred


def test_body_linked_upgrade_respects_flesh_limits():
    e = NPCItemInterestEngine()
    item = ItemSnapshot(
        "exo", "Servo-Manschette", "exosuit", modification_salience=.9,
        worn_on_body=True, biological_interface=True,
        load_profile=("structural", "neural", "thermal"),
    )
    r = e.evaluate(item, npc(modification_skill=.9, medical_skill=.8, biotech_skill=.7, trust=.8, familiarity=.8),
                   ctx(wearer_species="baseline_human", wearer_condition_tags=("scar_tissue",)))
    assert r.action == InterestAction.SUGGEST
    assert r.proposal is not None
    assert r.proposal.biological_limits is not None
    assert r.proposal.biological_limits.concerns
    assert any("Nerven" in x or "Gewebe" in x or "Wärme" in x for x in r.proposal.biological_limits.concerns)
    assert len(r.proposal.tradeoffs) >= 2


def test_low_biomedical_skill_does_not_invent_flesh_diagnosis():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("implant", "Reflexmodul", "electronics", modification_salience=.9,
                        implanted=True, biological_interface=True, load_profile=("neural", "immune"))
    r = e.evaluate(item, npc(modification_skill=.55, medical_skill=.05, biotech_skill=.05),
                   ctx(explicit_item_topic=True, flesh_limits_known=False))
    assert r.biological_limits is not None
    assert r.biological_limits.confidence == "low"
    assert r.biological_limits.concerns == ()


def test_nonhuman_body_requires_species_specific_check():
    e = NPCItemInterestEngine()
    item = ItemSnapshot("exo", "Lastverstärker", "exosuit", modification_salience=.9,
                        worn_on_body=True, load_profile=("structural",))
    r = e.evaluate(item, npc(modification_skill=.85, medical_skill=.7, biotech_skill=.8, trust=.8, familiarity=.8),
                   ctx(wearer_species="ferrit"))
    assert r.proposal is not None
    assert any("artspezifische Anatomie" in x for x in r.proposal.biological_limits.concerns)


def test_item_interest_persists_through_adaptive_runtime():
    from runtime.player_progression.model import PlayerProgressionState
    from runtime.player_progression.pipeline import PlayerLearningRuntime
    from runtime.player_progression.adaptive_runtime import AdaptiveGameplayRuntime
    state = PlayerProgressionState(player_uuid="p", run_uuid="r", start_class="OPERATOR")
    rt = AdaptiveGameplayRuntime.new(PlayerLearningRuntime(state))
    item = ItemSnapshot("x", "Vektor-9", "weapon", regional_rarity=.95)
    rt.evaluate_item_of_interest(item, npc(), ctx(danger=.9, safe_to_talk=False))
    snap = rt.snapshot_for_save()
    rt2 = AdaptiveGameplayRuntime.from_save(snap)
    assert rt2.npc_item_interest.memory.deferred
