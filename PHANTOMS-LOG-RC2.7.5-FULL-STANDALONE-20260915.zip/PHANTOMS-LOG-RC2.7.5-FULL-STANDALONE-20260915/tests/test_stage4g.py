import json
import tempfile
import unittest
from pathlib import Path

from validation.stage4g import (
    REQUIRED_CHAIN_INVARIANTS,
    REQUIRED_INVARIANTS,
    REQUIRED_PAIR_INVARIANTS,
    CaseResult,
    Invariant,
    Stage4GClosureHarness,
)


class Stage4GClosureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report = Stage4GClosureHarness().run()

    def test_closure_report_passes(self):
        self.assertTrue(self.report.passed, [c.failure for c in self.report.cases if not c.passed])

    def test_all_required_invariants_covered(self):
        self.assertFalse(self.report.missing_invariants)
        self.assertEqual(set(self.report.covered_invariants), {i.value for i in REQUIRED_INVARIANTS})

    def test_minimal_pair_coverage_complete(self):
        self.assertFalse(self.report.missing_pair_coverage)
        self.assertTrue({i.value for i in REQUIRED_PAIR_INVARIANTS}.issubset(self.report.pair_coverage))

    def test_multilayer_coverage_complete(self):
        self.assertFalse(self.report.missing_chain_coverage)
        self.assertTrue({i.value for i in REQUIRED_CHAIN_INVARIANTS}.issubset(self.report.chain_coverage))

    def test_case_matrix_size(self):
        self.assertEqual(len(self.report.cases), 14)
        self.assertEqual(sum(c.family == "MINIMAL_PAIR" for c in self.report.cases), 10)
        self.assertEqual(sum(c.family == "MULTI_LAYER" for c in self.report.cases), 4)

    def test_every_case_passes(self):
        self.assertEqual([c for c in self.report.cases if not c.passed], [])

    def test_chronology_pair_rejects_retroactive_lineage(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-01-CHRONOLOGY")
        self.assertTrue(case.evidence["retroactive_lineage_rejected"])

    def test_cost_pair_rejects_free_advantage(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-02-COSTED-CAPABILITY")
        self.assertTrue(case.evidence["free_advantage_rejected"])

    def test_origin_pair_keeps_tradeoffs(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-03-ORIGIN-TRADEOFF")
        self.assertTrue(case.evidence["all_eight_sources_preserve_costs"])
        self.assertGreater(case.evidence["candidate_count"], 8)

    def test_hybrid_pair_rejects_backdating(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-04-HYBRID-CAUSALITY")
        self.assertEqual(case.evidence["poly_depth"], 2)
        self.assertTrue(case.evidence["retroactive_hybridization_rejected"])

    def test_conflicted_active_trait_is_rejected(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-05-COHERENCE")
        self.assertTrue(case.evidence["conflicted_active_trait_rejected"])
        self.assertTrue(case.evidence["conflict_may_remain_unresolved"])

    def test_genetic_destiny_shortcuts_rejected(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-06-NO-GENETIC-DESTINY")
        self.assertTrue(case.evidence["biology_morality_shortcut_rejected"])
        self.assertTrue(case.evidence["behavior_shortcut_rejected"])

    def test_branch_axes_remain_orthogonal(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-07-BRANCH-AXES")
        self.assertTrue(case.evidence["sapient_feral_synthetic_drift_coexists"])
        self.assertTrue(case.evidence["feral_does_not_infer_cognition"])

    def test_influence_does_not_select_action(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-08-INFLUENCE-NOT-DECISION")
        self.assertEqual(case.evidence["decision_owner"], "INDIVIDUAL_ACTOR_RUNTIME")
        self.assertTrue(case.evidence["conflict_preserved"])

    def test_stage_boundary_pair_rejects_stage4_sensor_ownership(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-09-STAGE-BOUNDARY")
        self.assertTrue(case.evidence["later_stage_ownership_rejected"])

    def test_complexity_pair_preserves_all_eight_sources(self):
        case = next(c for c in self.report.cases if c.case_id == "MP-10-COMPLEXITY")
        self.assertEqual(case.evidence["package_count"], 8)
        self.assertTrue(case.evidence["no_auto_selection"])

    def test_full_bundle_preserves_poly_and_agency(self):
        case = next(c for c in self.report.cases if c.case_id == "CH-01-FULL-BIOLOGICAL-BUNDLE")
        self.assertEqual(case.evidence["hybrid_class"], "POLY")
        self.assertEqual(case.evidence["decision_owner"], "INDIVIDUAL_ACTOR_RUNTIME")

    def test_same_biology_can_diverge_by_context(self):
        case = next(c for c in self.report.cases if c.case_id == "CH-02-CONTEXT-DIVERGENCE")
        self.assertTrue(case.evidence["same_biology_different_context"])
        self.assertNotEqual(case.evidence["calm_pressure"], case.evidence["alert_pressure"])

    def test_many_sources_do_not_auto_become_poly_or_active(self):
        case = next(c for c in self.report.cases if c.case_id == "CH-03-UNRESOLVED-COMPLEXITY")
        self.assertEqual(case.evidence["source_count"], 8)
        self.assertEqual(case.evidence["class"], "MULTI")
        self.assertGreater(case.evidence["unassigned"], 0)

    def test_cross_layer_bundle_fails_closed(self):
        case = next(c for c in self.report.cases if c.case_id == "CH-04-FAIL-CLOSED-BUNDLE")
        self.assertTrue(case.evidence["valid_bundle_passed"])
        self.assertTrue(case.evidence["single_invalid_layer_blocks_bundle"])

    def test_report_serializes(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "stage4.json"
            self.report.write_json(path)
            raw = json.loads(path.read_text())
        self.assertTrue(raw["passed"])
        self.assertEqual(len(raw["cases"]), 14)

    def test_case_wrapper_collects_failure(self):
        def broken():
            raise RuntimeError("synthetic")
        result = Stage4GClosureHarness._case("X", "MINIMAL_PAIR", (Invariant.CHRONOLOGY_CAUSALITY,), broken)
        self.assertIsInstance(result, CaseResult)
        self.assertFalse(result.passed)
        self.assertIn("RuntimeError:synthetic", result.failure)


if __name__ == "__main__":
    unittest.main()
