
import json,unittest
from pathlib import Path
from runtime.content_stage47.waste import *
ROOT=Path(__file__).resolve().parents[1]; D=json.loads((ROOT/"content/full_version/stage47_waste_pollution.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_types(self): self.assertGreaterEqual(len(D["waste_types"]),5)
 def test_collection(self): self.assertEqual(collection(100,40)["remaining"],60)
 def test_recycling_conserves(self):
  x=recycle(100,7000); self.assertEqual(x["recovered"]+x["residue"],100)
 def test_overflow(self): self.assertEqual(sewage_overflow(100,60),40)
 def test_pollution(self): self.assertEqual(pollution_accumulate(10,20,5),25)
 def test_remediation_requires_time(self): self.assertIsNone(remediation_candidate("S",10,True,0,"EV"))
 def test_remediation_authority(self): self.assertTrue(remediation_candidate("S",10,True,60,"EV")["authority_required"])
 def test_disposal_authority(self): self.assertTrue(disposal_candidate("W","LANDFILL",10,"EV")["authority_required"])
 def test_no_disappear_rule(self): self.assertTrue(any("cannot disappear" in x.lower() for x in D["rules"]))
 def test_pollution_persists_rule(self): self.assertTrue(any("may persist" in x.lower() for x in D["rules"]))
 def test_sewage_rule(self): self.assertTrue(any("sewage requires" in x.lower() for x in D["rules"]))
if __name__=="__main__": unittest.main()
