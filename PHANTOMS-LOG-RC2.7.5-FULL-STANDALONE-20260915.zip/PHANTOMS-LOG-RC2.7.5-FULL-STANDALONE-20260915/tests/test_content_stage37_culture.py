
import json, unittest
from pathlib import Path
from runtime.content_stage37.culture import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage37_culture_language.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_custom_types(self):
  self.assertGreaterEqual(len(D["custom_types"]),5)

 def test_language_requires_time(self):
  self.assertEqual(language_progress(20,0),20)

 def test_language_progress_bounded(self):
  self.assertEqual(language_progress(99,100000,100,100),100)

 def test_language_levels(self):
  self.assertEqual(language_level(5),"LANG_NONE")
  self.assertEqual(language_level(45),"LANG_CONVERSATIONAL")
  self.assertEqual(language_level(90),"LANG_NATIVE_LIKE")

 def test_custom_pressure_bounded(self):
  self.assertEqual(custom_pressure(100,0,100),100)

 def test_drift_requires_time(self):
  mode=D["contact_modes"][0]
  self.assertIsNone(cultural_drift_candidate("a","C1","C2",mode,0,80,"EV"))

 def test_drift_not_identity_overwrite(self):
  mode=D["contact_modes"][2]
  p=cultural_drift_candidate("a","C1","C2",mode,90,80,"EV")
  self.assertFalse(p["auto_identity_overwrite"])
  self.assertTrue(p["authority_required"])

 def test_identity_change_authority(self):
  p=identity_change_proposal("a","C1",80,-10,"migration","EV")
  self.assertTrue(p["authority_required"])
  self.assertEqual(p["proposed_strength"],70)

 def test_memory_requires_sources(self):
  r=cultural_memory_record("C","M","story",[],1)
  self.assertFalse(validate_cultural_memory(r))

 def test_memory_valid(self):
  r=cultural_memory_record("C","M","story",["S"],1)
  self.assertTrue(validate_cultural_memory(r))

 def test_unanimity_rule(self):
  self.assertTrue(any("does not imply unanimous" in x.lower() for x in D["rules"]))

if __name__=="__main__": unittest.main()
