
import json, unittest
from pathlib import Path
from runtime.content_stage43.agriculture import *
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage43_agriculture.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_crop_types(self):
  self.assertGreaterEqual(len(D["crop_types"]),5)

 def test_progress_requires_cycle(self):
  self.assertEqual(crop_progress(30,0),0)

 def test_progress_bounded(self):
  self.assertEqual(crop_progress(999,100),100)

 def test_yield_reduced_by_water(self):
  a=projected_yield(100,1,10000,100,100)
  b=projected_yield(100,1,10000,50,100)
  self.assertGreater(a,b)

 def test_harvest_bounded_by_projection(self):
  p=harvest_candidate("C",100,150,1,"EV")
  self.assertEqual(p["actual_harvest"],100)
  self.assertTrue(p["authority_required"])

 def test_livestock_pressure(self):
  self.assertGreater(livestock_pressure(10,0,10,0,50),0)

 def test_spoilage_requires_time(self):
  self.assertEqual(spoilage_projection(100,100,0)["lost"],0)

 def test_spoilage_conserves_stock(self):
  x=spoilage_projection(100,100,10)
  self.assertEqual(x["remaining"]+x["lost"],100)

 def test_production_requires_inputs_and_labor(self):
  self.assertIsNone(production_candidate("C","S","P",False,True,10,"EV"))
  self.assertIsNone(production_candidate("C","S","P",True,False,10,"EV"))

 def test_production_authority(self):
  p=production_candidate("C","S","P",True,True,10,"EV")
  self.assertTrue(p["authority_required"])

 def test_seasonal_output(self):
  self.assertEqual(seasonal_output(100,5000),50)

if __name__=="__main__": unittest.main()
