
import json, unittest
from pathlib import Path
from runtime.content_stage25.diplomacy import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage25_diplomacy.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_states(self):
  self.assertIn("WAR",D["diplomatic_states"])
  self.assertIn("CEASEFIRE",D["diplomatic_states"])

 def test_relation_bounded(self):
  r=relation_delta({"trust":95,"grievance":95},{"trust":50,"grievance":50})
  self.assertEqual(r["trust"],100); self.assertEqual(r["grievance"],100)

 def test_treaty_requires_both(self):
  o=treaty_offer("T1","TREATY_TRADE","A","B",{"trade_access":True},1)
  a=treaty_accept(o,"A",2)
  self.assertFalse(a["active"])
  b=treaty_accept(a,"B",2)
  self.assertTrue(b["active"])

 def test_treaty_authority(self):
  o=treaty_offer("T1","TREATY_TRADE","A","B",{},1)
  a=treaty_accept(o,"A",2)
  self.assertTrue(a["authority_required"])

 def test_invalid_treaty_party(self):
  o=treaty_offer("T1","TREATY_TRADE","A","B",{},1)
  self.assertIsNone(treaty_accept(o,"C",2))

 def test_war_needs_trigger(self):
  self.assertIsNone(war_candidate("A","B","", "EV"))
  self.assertIsNotNone(war_candidate("A","B","formal_declaration","EV"))

 def test_war_authority(self):
  w=war_candidate("A","B","committed_hostile_act","EV")
  self.assertTrue(w["authority_required"])

 def test_ceasefire_not_history_reset(self):
  self.assertTrue(D["ceasefire_contract"]["does_not_erase_history"])

 def test_ceasefire_state(self):
  self.assertEqual(diplomatic_state("HOSTILE",False,True,True),"CEASEFIRE")

 def test_war_state(self):
  self.assertEqual(diplomatic_state("HOSTILE",False,True,False),"WAR")

if __name__=="__main__": unittest.main()
