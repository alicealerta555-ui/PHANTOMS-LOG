from __future__ import annotations
import unittest
from uuid import uuid4
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.gameplay import bootstrap_minimal_world
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.integrity import MANDATORY_CLOSURE_GATES, Stage9IntegrityHarness

class Stage9IntegrityHarnessTests(unittest.TestCase):
    def test_harness_is_read_only_and_requires_executed_evidence(self):
        m=RunSessionManager(master_seed=4); p=str(uuid4()); s=m.create_run(player_uuid=p); r=RunActorRegistry(s)
        r.register(RuntimeIdentity(p,s.identity.run_uuid,"actor:player"),actor_definition_id="player")
        r.register(RuntimeIdentity(p,s.identity.run_uuid,"actor:npc"),actor_definition_id="npc")
        bootstrap_minimal_world(s,r)
        before=(s.store.revision,s.store.state_hash())
        report=Stage9IntegrityHarness(s,r).audit({gate:True for gate in MANDATORY_CLOSURE_GATES})
        self.assertTrue(report.passed, report.failed_gates)
        self.assertEqual((s.store.revision,s.store.state_hash()),before)
        missing=Stage9IntegrityHarness(s,r).audit({})
        self.assertFalse(missing.passed)
        self.assertIn("COMBAT_GOLDEN_PATH",missing.failed_gates)

if __name__=='__main__': unittest.main()
