"""Regression evidence for observed RC1 bugs and the real RC2 launch path."""
import base64
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from playable_full_version.playable.game import FullVersionGame, FullVersionGameError
from playable_full_version.playable.location_images import ImageConfig, LocationImages, LocationImageError
from runtime.full_version.player_character import CharacterCreationError
from runtime.playable_character.gameplay_bridge import action_context
from playable_full_version.playable.input_parser import parse_action

ROOT=Path(__file__).resolve().parents[1]
PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=')
LOCATION={'location_id':'loc:test:01','display_name':'Test room','static_description':'Empty room.',
          'hidden_loot':'SECRET_TOKEN','connections':['SECRET_EXIT'],'npc_memory':'SECRET_MEMORY'}


class RunRegressionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.saves=Path(self.temp.name)
        self.game=FullVersionGame(core_root=ROOT,saves_root=self.saves,start_class='BREAKER')
        self.addCleanup(self.game.images.close)

    def create(self):
        self.game.complete_character(self.game.creation_template())

    def test_new_run_requires_creation_and_has_no_image(self):
        g=self.game;before=g.session.store.state_hash()
        with self.assertRaisesRegex(FullVersionGameError,'CHARACTER_CREATION_INCOMPLETE'):
            g.execute(action_type='MOVE',raw_input='move',parameters={'destination_location_id':'loc:residential_domestic:02'})
        self.assertIn('Charaktererstellung',g.opening())
        self.assertIsNone(g.image_packet());self.assertEqual(before,g.session.store.state_hash())

    def test_created_skills_reach_action_context_and_reload(self):
        self.create();g=self.game
        self.assertEqual(action_context(g.character(),'Ich repariere')['skills']['SKILL_FORCE_APPLICATION'],6)
        g2=FullVersionGame(core_root=ROOT,saves_root=self.saves)
        self.assertEqual(g2.character(),g.character())
        self.assertFalse(g2.character_creation_required)

    def test_creation_does_not_duplicate_starting_items(self):
        before=[k for k in self.game.session.store.runtime_state if k.startswith('item:')]
        self.create()
        self.assertEqual(before,[k for k in self.game.session.store.runtime_state if k.startswith('item:')])

    def test_no_second_creation(self):
        self.create();before=self.game.session.store.state_hash()
        with self.assertRaisesRegex(CharacterCreationError,'ALREADY_CREATED'):
            self.create()
        self.assertEqual(before,self.game.session.store.state_hash())

    def test_invalid_character_choices_cannot_write(self):
        before=self.game.session.store.state_hash()
        for field,value in [('age','abc'),('age',True),('stats',{'STAT_STR':99}),
                            ('skills',{'SKILL_TECHNOLOGY':4}),('world_truth',{'loot':True}),('run_uuid','other')]:
            with self.subTest(field=field,value=value):
                draft=self.game.creation_template();draft[field]=value
                with self.assertRaises((ValueError,CharacterCreationError)):
                    self.game.complete_character(draft)
        self.assertEqual(before,self.game.session.store.state_hash())

    def test_missing_save_does_not_restart_or_write_profile(self):
        g=self.game;before=g.profile_path.read_bytes();g.repo.state_path(g.identity).unlink()
        with self.assertRaisesRegex(FullVersionGameError,'RUN_SAVE_NOT_FOUND'):
            FullVersionGame(core_root=ROOT,saves_root=self.saves)
        self.assertFalse(g.repo.exists(g.identity));self.assertEqual(before,g.profile_path.read_bytes())

    def test_corrupt_save_fails_closed(self):
        g=self.game;path=g.repo.state_path(g.identity);path.write_text('[]')
        with self.assertRaisesRegex(FullVersionGameError,'RUN_SAVE_INVALID'):
            FullVersionGame(core_root=ROOT,saves_root=self.saves)
        self.assertEqual(path.read_text(),'[]')

    def test_profile_origin_mismatch_rejected(self):
        raw=self.game.profile.as_dict();raw['start_class']='OPERATOR'
        self.game.profile_path.write_text(json.dumps(raw))
        with self.assertRaisesRegex(FullVersionGameError,'PROFILE_SAVE_ORIGIN_MISMATCH'):
            FullVersionGame(core_root=ROOT,saves_root=self.saves)

    def test_save_directory_in_core_rejected_before_profile_write(self):
        target=ROOT/'__invalid_rc2_save_test__'
        with self.assertRaisesRegex(RuntimeError,'EXTERNAL_TO_STATIC_CORE'):
            FullVersionGame(core_root=ROOT,saves_root=target,start_class='BREAKER')
        self.assertFalse(target.exists())

    def test_failed_new_profile_does_not_discard_existing_run(self):
        self.create();g=self.game;old=g.identity;profile=g.profile_path.read_bytes()
        with patch.object(g,'_write_profile',side_effect=OSError('disk full')):
            with self.assertRaises(OSError):g.new_run(start_class='OPERATOR')
        self.assertEqual(g.identity,old);self.assertEqual(g.profile_path.read_bytes(),profile)
        self.assertEqual(g.character()['name'],'Nexus')

    def test_new_run_requires_new_creation_and_separate_image_scope(self):
        self.create();g=self.game;g.opening();old=g.identity;old_cache=g.images.root
        g.new_run(start_class='OPERATOR')
        self.assertNotEqual(g.identity.run_uuid,old.run_uuid);self.assertEqual(g.identity.player_uuid,old.player_uuid)
        self.assertTrue(g.character_creation_required);self.assertIsNone(g.image_packet())
        self.assertNotEqual(g.images.root,old_cache);self.assertTrue(g.repo.exists(old))

    def test_intro_only_after_creation_once_and_without_state_change(self):
        self.create();g=self.game;before=g.session.store.state_hash()
        self.assertIn('Was tust du?',g.opening())
        packet=g.consume_intro_packet();self.assertIn('80–120',packet['prompt'])
        self.assertEqual(before,g.session.store.state_hash())
        g2=FullVersionGame(core_root=ROOT,saves_root=self.saves)
        g2.opening();self.assertIsNone(g2.consume_intro_packet())

    def test_visit_return_and_look_reuse_image_request(self):
        self.create();g=self.game;g.opening();first=g.image_packet()['request_id']
        initial=g.location();destination=g.catalog.location(initial)['connections'][0];g.handle('/go '+destination);second=g.image_packet()['request_id']
        self.assertNotEqual(first,second)
        g.handle('/go '+initial);g.handle('/look')
        self.assertEqual(first,g.image_packet()['request_id'])
        self.assertEqual(len(list(g.images.root.glob('*.json'))),2)

    def test_invalid_move_emits_no_image_and_changes_no_state(self):
        self.create();g=self.game;before=g.session.store.state_hash()
        with self.assertRaisesRegex(FullVersionGameError,'NOT_CONNECTED'):
            g.execute(action_type='MOVE',raw_input='go',parameters={'destination_location_id':'loc:missing'})
        self.assertEqual(before,g.session.store.state_hash());self.assertIsNone(g.image_packet())

    def test_image_failure_does_not_reject_committed_move(self):
        self.create();g=self.game
        with patch.object(g.images,'ensure',side_effect=OSError('no image storage')):
            destination=g.catalog.location(g.location())['connections'][0]
            text,_=g.handle('/go '+destination)
        self.assertIn('COMMITTED',text);self.assertEqual(g.location(),destination)

    def test_save_failure_reports_committed_action_truthfully(self):
        self.create();g=self.game
        with patch.object(g.repo,'save',side_effect=OSError('disk full')):
            destination=g.catalog.location(g.location())['connections'][0]
            text,_=g.handle('/go '+destination)
            exit_text,done=g.handle('/quit')
        self.assertIn('Aktion ausgeführt',text);self.assertIn('Speichern fehlgeschlagen',text)
        self.assertFalse(done);self.assertIn('bleibt geöffnet',exit_text)

    def test_pretty_rc1_save_still_loads(self):
        self.create();path=self.game.save();raw=json.loads(path.read_text())
        path.write_text(json.dumps(raw,ensure_ascii=False,indent=2))
        g2=FullVersionGame(core_root=ROOT,saves_root=self.saves)
        self.assertEqual(g2.session.store.state_hash(),self.game.session.store.state_hash())

    def test_json_launch_creation_intro_image_and_resume(self):
        command=[sys.executable,'-m','playable_full_version.playable.cli','--core',str(ROOT),'--saves',str(self.saves),'--json']
        run=subprocess.run(command,input=json.dumps({'create_character':self.game.creation_template()})+'\n'+
                           json.dumps({'action':'/quit'})+'\n',text=True,capture_output=True,timeout=10,cwd=ROOT)
        self.assertEqual(run.returncode,0,run.stderr)
        frames=[json.loads(line) for line in run.stdout.splitlines()]
        self.assertTrue(frames[0]['character_creation']['required']);self.assertIsNone(frames[0]['image'])
        self.assertIsNotNone(frames[1]['intro']);self.assertIsNotNone(frames[1]['arrival'])
        self.assertTrue(frames[1]['image']['prompt_required']);self.assertFalse(frames[1]['image']['generation_required'])
        self.assertTrue(frames[-1]['done'])

    def test_move_automatically_describes_frame_motion_sound_and_light(self):
        self.create();destination=self.game.catalog.location(self.game.location())['connections'][0]
        visible=self.game._present_location(destination)['display_name']
        text,_=self.game.handle('/go '+destination)
        self.assertIn(visible,text)
        packet=self.game.consume_arrival_packet()
        self.assertTrue(packet['automatic_after_move']);self.assertIn('visible_motion',packet['visible_context'])
        self.assertIn('soundscape',packet['visible_context']);self.assertIn('lighting',packet['visible_context'])
        self.assertIn(packet['visible_context']['soundscape'],text)
        self.assertIn(packet['visible_context']['lighting'],text)

    def test_look_is_finer_than_automatic_arrival(self):
        self.create();arrival=self.game.arrival_description();detail=self.game.describe()
        self.assertNotEqual(arrival,detail);self.assertIn('genaueres Umsehen',detail)

    def test_all_locations_have_complete_deterministic_arrival(self):
        self.create();projector=self.game.arrival_projector
        for location in self.game.catalog.world['locations']:
            a=projector.project(location,self.game.session);b=projector.project(location,self.game.session)
            self.assertEqual(a,b)
            self.assertTrue(all((a.scene_frame,a.visible_motion,a.soundscape,a.lighting,a.fine_detail)))

    def test_visible_working_actor_is_reported_but_other_location_is_not(self):
        class Kernel:
            def read(self,*args,**kwargs):
                return {'run_uuid':'R','actors':{'actor:player':{'location_ref':'L'},
                    'actor:worker':{'location_ref':'L','stance':'working'},
                    'actor:hidden_elsewhere':{'location_ref':'OTHER','stance':'working'}}}
        class Identity:run_uuid='R'
        class Session:kernel=Kernel();identity=Identity()
        location={'location_id':'L','display_name':'Werk','primary_category':'industrial_maintenance'}
        out=self.game.arrival_projector.project(location,Session())
        self.assertEqual(len(out.visible_actor_activity),1);self.assertIn('arbeitet',out.visible_actor_activity[0])
        self.assertNotIn('hidden_elsewhere',str(out))

    def test_arrival_is_read_only_and_does_not_reveal_hidden_runtime(self):
        self.create();before=self.game.session.store.state_hash();packet=self.game.arrival_description()
        self.assertEqual(before,self.game.session.store.state_hash())
        self.assertNotIn('npc_memory',packet);self.assertNotIn('SECRET_MEMORY',packet)


class ImageRegressionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)

    def service(self,**kwargs):
        service=LocationImages(self.root,player_uuid='P',run_uuid='R',actor_id='A',**kwargs)
        self.addCleanup(service.close);return service

    def wait_status(self,service,status):
        deadline=time.monotonic()+3
        while time.monotonic()<deadline:
            if service.current()['status']==status:return
            time.sleep(.01)
        self.fail('Image did not reach '+status+': '+str(service.current()))

    def test_prompt_filters_hidden_fields(self):
        s=self.service();s.ensure(LOCATION);packet=s.packet()
        self.assertNotIn('SECRET',json.dumps(packet));self.assertIn('Test room',json.dumps(packet['visible_scene']));self.assertTrue(packet['prompt_required']);self.assertIsNone(packet['prompt'])

    def test_image_cannot_be_attached_before_ai_prompt(self):
        s=self.service();job=s.ensure(LOCATION);image=self.root/'fixture.png';image.write_bytes(PNG)
        with self.assertRaisesRegex(LocationImageError,'PROMPT_REQUIRED'):
            s.attach(job['request_id'],image)

    def test_ai_prompt_binding_enables_generation(self):
        s=self.service();job=s.ensure(LOCATION)
        record=s.submit_prompt(job['request_id'],'Grounded visible test room, cinematic realistic environment, no invented elements.')
        self.assertEqual(record['status'],'pending');self.assertTrue(s.packet()['generation_required']);self.assertFalse(s.packet()['prompt_required'])

    def test_off_mode_creates_no_requests(self):
        s=self.service(config=ImageConfig(mode='off'))
        self.assertIsNone(s.ensure(LOCATION));self.assertFalse(list(self.root.iterdir()))

    def test_attach_persist_and_reuse(self):
        s=self.service();job=s.ensure(LOCATION);s.submit_prompt(job['request_id'],'Cinematic grounded view of the visible test room, no invented objects or people.');image=self.root/'fixture.png';image.write_bytes(PNG)
        s.attach(job['request_id'],image)
        restored=self.service();record=restored.ensure(LOCATION)
        self.assertEqual(record['status'],'ready');self.assertFalse(restored.packet()['generation_required'])

    def test_corrupt_cached_image_becomes_pending(self):
        s=self.service();job=s.ensure(LOCATION);s.submit_prompt(job['request_id'],'Grounded visible test room, realistic materials and readable light, no invented elements.');image=self.root/'fixture.png';image.write_bytes(PNG)
        record=s.attach(job['request_id'],image);s.image_path(record).write_bytes(b'broken')
        self.assertEqual(s.ensure(LOCATION)['status'],'awaiting_prompt');self.assertTrue(s.packet()['prompt_required'])

    def test_invalid_image_rejected(self):
        s=self.service();job=s.ensure(LOCATION);s.submit_prompt(job['request_id'],'Grounded visible test room, realistic environment only, no invented elements.');image=self.root/'invalid.png';image.write_text('<html>error</html>')
        with self.assertRaisesRegex(LocationImageError,'FORMAT_INVALID'):s.attach(job['request_id'],image)
        self.assertEqual(s.current()['status'],'pending')

    def test_request_ids_cannot_traverse_paths(self):
        s=self.service()
        with self.assertRaisesRegex(LocationImageError,'REQUEST_ID_INVALID'):s.attach('../../x',Path('x'))

    def test_other_actor_has_different_cache_key(self):
        s=self.service();a=s.ensure(LOCATION)['request_id']
        other=LocationImages(self.root,player_uuid='P',run_uuid='R',actor_id='B')
        self.assertNotEqual(a,other.ensure(LOCATION)['request_id'])

    def test_slow_backend_does_not_block_and_duplicates_are_coalesced(self):
        started=threading.Event();release=threading.Event();calls=[]
        def backend(job):
            calls.append(job['request_id']);started.set();release.wait(2);return PNG
        s=self.service(backend=backend)
        job=s.ensure(LOCATION);s.submit_prompt(job['request_id'],'Grounded visible test room, cinematic realistic environment, no invented elements.');self.assertTrue(started.wait(1))
        for _ in range(10):s.ensure(LOCATION)
        self.assertEqual(len(calls),1);self.assertFalse(release.is_set())
        release.set();self.wait_status(s,'ready')

    def test_failure_waits_for_explicit_retry(self):
        calls=[]
        def backend(job):
            calls.append(1)
            if len(calls)==1:raise TimeoutError()
            return PNG
        s=self.service(backend=backend);job=s.ensure(LOCATION);s.submit_prompt(job['request_id'],'Grounded visible test room, realistic scene, no invented elements.');self.wait_status(s,'failed')
        s.ensure(LOCATION);self.assertEqual(len(calls),1)
        s.ensure(LOCATION,retry=True);self.wait_status(s,'ready');self.assertEqual(len(calls),2)

    def test_completed_offscreen_image_does_not_replace_current_scene(self):
        release=threading.Event();started=threading.Event()
        def backend(job):
            if job['visible_scene']['location_id']==LOCATION['location_id']:started.set();release.wait(2)
            return PNG
        s=self.service(backend=backend);shown=[];s.on_ready=shown.append
        first=job=s.ensure(LOCATION);s.submit_prompt(job['request_id'],'Grounded visible test room, cinematic realistic environment, no invented elements.');self.assertTrue(started.wait(1))
        second=s.ensure({**LOCATION,'location_id':'loc:test:02','display_name':'Other room'});s.submit_prompt(second['request_id'],'Grounded visible other room, cinematic realistic environment, no invented elements.')
        release.set();self.wait_status(s,'ready')
        self.assertEqual(s.packet()['request_id'],second['request_id'])
        self.assertEqual([p.stem for p in shown],[second['request_id']])

    def test_local_api_payload_and_response(self):
        seen=[]
        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                seen.append((self.path,json.loads(self.rfile.read(int(self.headers['Content-Length'])))))
                raw=json.dumps({'images':[base64.b64encode(PNG).decode()]}).encode()
                self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(raw)
            def log_message(self,*args):pass
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            config=ImageConfig(mode='automatic1111',endpoint=f'http://127.0.0.1:{server.server_port}')
            s=self.service(config=config);job=s.ensure(LOCATION);s.submit_prompt(job['request_id'],'Grounded visible test room, cinematic realistic environment, no invented elements.');self.wait_status(s,'ready')
            self.assertEqual(seen[0][0],'/sdapi/v1/txt2img')
            self.assertEqual(seen[0][1]['batch_size'],1);self.assertNotIn('run_uuid',seen[0][1])
            self.assertNotIn('SECRET',json.dumps(seen[0][1]))
        finally:server.shutdown();server.server_close();thread.join(2)

    def test_network_configuration_remains_local(self):
        for endpoint in ('https://example.com','http://10.0.0.1:7860','http://user@127.0.0.1:7860'):
            with self.assertRaises(LocationImageError):ImageConfig(mode='automatic1111',endpoint=endpoint)


class ComponentRegressionTests(unittest.TestCase):
    def test_parser_rejects_substrings_negation_and_multiple_actions(self):
        self.assertEqual(parse_action('Ich durchsuche die Kiste')['intent'],'SEARCH')
        self.assertEqual(parse_action('Ich behandle die Wunde')['intent'],'TREAT')
        self.assertEqual(parse_action('Das Schaufenster ist hier')['intent'],'UNKNOWN')
        self.assertFalse(parse_action('Ich öffne die Tür nicht')['ok'])
        self.assertFalse(parse_action('Ich öffne die Tür und gehe weiter')['ok'])

if __name__=='__main__':unittest.main()
