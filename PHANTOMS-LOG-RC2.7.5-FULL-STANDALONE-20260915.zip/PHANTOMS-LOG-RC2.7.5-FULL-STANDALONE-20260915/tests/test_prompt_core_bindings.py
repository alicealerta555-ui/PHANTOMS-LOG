from pathlib import Path
import tempfile

from playable.game import FullVersionGame
from playable.location_images import ImageConfig
from playable.prompt_bindings import EVENT_BINDINGS, PromptCoreRegistry

ROOT=Path(__file__).resolve().parents[1]


def game(tmp):
    g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class='OPERATOR',master_seed=20260913,image_config=ImageConfig(mode='off'))
    g.complete_character(g.creation_template())
    # Opening/creation packets are separate host surfaces; isolate gameplay assertion.
    g.consume_narration_packets()
    return g


def test_all_shipped_prompt_cores_are_bound_exactly_to_live_registry():
    files={p.name for p in (ROOT/'content/full_version/prompts').glob('*.md')}
    bound={name for names in EVENT_BINDINGS.values() for name in names}
    assert len(files)==19
    assert files==bound
    registry=PromptCoreRegistry(ROOT)
    assert set(registry.core_names)==files


def test_look_queues_location_stack_and_is_read_only():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp)
        rev=g.session.store.revision
        text=g.describe()
        packets=g.consume_narration_packets()
        assert text
        assert g.session.store.revision==rev
        assert len(packets)==1
        p=packets[0]
        assert p['event']=='location_detail' and p['read_only'] is True
        assert 'LOCATION_DETAIL_PROMPT_CORE.md' in p['prompt_cores']
        assert 'WORLD_CULTURAL_SURFACE_PROMPT_CORE.md' in p['prompt_cores']
        assert 'REGIONAL_WEATHER_ENVIRONMENT_PROMPT_CORE.md' in p['prompt_cores']
        assert 'DYNAMIC_WORLD_EVENTS_PROMPT_CORE.md' in p['prompt_cores']
        assert g.consume_narration_packets()==[]


def test_search_weather_body_population_create_specialized_packets():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp)
        cases=[
            (g.search_location,'search_resolution'),
            (g.weather_status,'weather_environment'),
            (g.body_status,'embodied_needs'),
            (g.population_here,'population_social_context'),
        ]
        for fn,event in cases:
            fn()
            packets=g.consume_narration_packets()
            assert packets and packets[-1]['event']==event


def test_generic_committed_action_queues_world_interaction_packet():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp)
        loc=g.catalog.location(g.location())
        dest=loc['connections'][0]
        receipt=g.execute(action_type='MOVE',raw_input='go test',parameters={'destination_location_id':dest})
        assert receipt.status.value in {'COMMITTED','IDEMPOTENT'}
        packets=g.consume_narration_packets()
        assert packets and packets[-1]['event']=='world_interaction'
        assert packets[-1]['visible_context']['action_type']=='MOVE'
