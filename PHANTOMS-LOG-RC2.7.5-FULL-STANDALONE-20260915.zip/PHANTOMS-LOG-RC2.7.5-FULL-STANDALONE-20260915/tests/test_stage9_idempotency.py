from __future__ import annotations

import unittest
from uuid import uuid4

from runtime.stage3a.kernel import (
    Authority,
    CommitKernel,
    CommitRecord,
    Delta,
    Domain,
    Mode,
    Proposal,
    ValidationResult,
    Verdict,
)
from runtime.stage3c.isolation import RunSessionManager, decode_store, encode_store
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import AuthorityStatus, StateAuthority
from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.idempotency import CommitIdempotencyBoundary, Stage9IdempotencyError
from runtime.stage9.revision import CommitRevisionBoundary


class Stage9CommitIdempotencyTests(unittest.TestCase):
    def setUp(self) -> None:
        self.manager = RunSessionManager(master_seed=20260911)
        self.player_uuid = str(uuid4())
        self.session = self.manager.create_run(player_uuid=self.player_uuid)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(
            self.player_uuid, self.session.identity.run_uuid, "actor:player"
        )
        self.registry.register(self.identity, actor_definition_id="actor-def:player")
        self.authority = StateAuthority(self.session, actor_registry=self.registry)
        self.revision_boundary = CommitRevisionBoundary(self.session)
        self.idempotency_boundary = CommitIdempotencyBoundary(self.session)

    def _effect(self, effect_id: str = "effect:time:1") -> EffectProposal:
        return EffectProposal(
            effect_id=effect_id,
            run_uuid=self.session.identity.run_uuid,
            resolution_id="resolution:1",
            source_action_id="action:1",
            effect_type=EffectType.ADVANCE_WORLD_TIME,
            target_ref=None,
            payload={"seconds": 1},
            authority_domain=AuthorityDomain.WORLD_TIME,
            expected_state_revision=self.session.store.revision,
        )

    @staticmethod
    def _proposal(*, event_id: str, key: str = "time:test", value: int = 1) -> Proposal:
        return Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id=event_id,
            cause="TEST_STAGE9_IDEMPOTENCY",
            deltas=(Delta(
                domain=Domain.RUNTIME_STATE,
                key=key,
                value=value,
                writer=Authority.RULE_KERNEL,
                cause="TEST_STAGE9_IDEMPOTENCY",
                source_event_id=None,
            ),),
        )

    def _bound(self, *, commit_id="commit:1", effect_id="effect:time:1", event_id="IDEM:E1", value=1):
        decision = self.authority.authorize(self._effect(effect_id))
        self.assertEqual(decision.status, AuthorityStatus.ALLOW)
        revision_bound = self.revision_boundary.bind(
            decision.commit_operation,
            self._proposal(event_id=event_id, value=value),
        )
        return self.idempotency_boundary.bind(revision_bound, commit_id=commit_id)

    def test_bound_commit_records_commit_and_effect_ids(self):
        bound = self._bound()
        result = self.session.kernel.process(bound.proposal)
        self.assertIsInstance(result, CommitRecord)
        self.assertEqual(result.commit_id, "commit:1")
        self.assertEqual(result.effect_ids, ("effect:time:1",))

    def test_same_commit_retry_new_event_id_is_idempotent(self):
        first = self._bound(event_id="IDEM:FIRST")
        before = self.session.store.revision
        result1 = self.session.kernel.process(first.proposal)
        self.assertIsInstance(result1, CommitRecord)
        after_first = self.session.store.revision
        self.assertEqual(after_first, before + 1)
        before_hash = self.session.store.state_hash()

        # Build the exact semantic retry without re-authorizing against the newer revision.
        retry = Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id="IDEM:RETRY:NEW-EVENT",
            cause="TEST_STAGE9_IDEMPOTENCY",
            expected_state_revision=first.proposal.expected_state_revision,
            commit_id="commit:1",
            effect_ids=("effect:time:1",),
            deltas=self._proposal(event_id="IGNORED").deltas,
        )
        result2 = self.session.kernel.process(retry)
        self.assertIsInstance(result2, ValidationResult)
        self.assertEqual(result2.verdict, Verdict.HOLD)
        self.assertEqual(result2.reasons, ("DUPLICATE_COMMIT_IDEMPOTENT_SKIP",))
        self.assertEqual(self.session.store.revision, after_first)
        self.assertEqual(self.session.store.state_hash(), before_hash)
        self.assertNotIn("IDEM:RETRY:NEW-EVENT", self.session.store.event_ledger)

    def test_same_commit_id_with_changed_semantics_is_rejected(self):
        first = self._bound()
        self.assertIsInstance(self.session.kernel.process(first.proposal), CommitRecord)
        conflicting = Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id="IDEM:CONFLICT:COMMIT",
            cause="TEST_STAGE9_IDEMPOTENCY",
            commit_id="commit:1",
            effect_ids=("effect:time:1",),
            deltas=self._proposal(event_id="X", value=999).deltas,
        )
        result = self.session.kernel.process(conflicting)
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertEqual(result.reasons, ("COMMIT_ID_REUSE_CONFLICT",))

    def test_same_effect_id_under_new_commit_is_rejected(self):
        first = self._bound(commit_id="commit:first")
        self.assertIsInstance(self.session.kernel.process(first.proposal), CommitRecord)
        retry = Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id="IDEM:EFFECT:NEWCOMMIT",
            cause="TEST_STAGE9_IDEMPOTENCY",
            commit_id="commit:second",
            effect_ids=("effect:time:1",),
            deltas=self._proposal(event_id="X").deltas,
        )
        result = self.session.kernel.process(retry)
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertEqual(result.reasons, ("EFFECT_ID_REUSE_CONFLICT:effect:time:1",))

    def test_idempotency_survives_encode_decode(self):
        first = self._bound(commit_id="commit:persist", effect_id="effect:persist")
        self.assertIsInstance(self.session.kernel.process(first.proposal), CommitRecord)
        encoded = encode_store(self.session.store)
        restored = decode_store(encoded)
        restored_kernel = CommitKernel(store=restored, world_seed=self.session.kernel.world_seed)
        before_revision = restored.revision
        before_hash = restored.state_hash()
        retry = Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id="IDEM:PERSIST:RETRY",
            cause="TEST_STAGE9_IDEMPOTENCY",
            commit_id="commit:persist",
            effect_ids=("effect:persist",),
            deltas=self._proposal(event_id="X").deltas,
        )
        result = restored_kernel.process(retry)
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.HOLD)
        self.assertEqual(result.reasons, ("DUPLICATE_COMMIT_IDEMPOTENT_SKIP",))
        self.assertEqual(restored.revision, before_revision)
        self.assertEqual(restored.state_hash(), before_hash)

    def test_legacy_commit_without_stage9_ids_remains_compatible(self):
        before = self.session.store.revision
        result = self.session.kernel.process(self._proposal(event_id="IDEM:LEGACY"))
        self.assertIsInstance(result, CommitRecord)
        self.assertIsNone(result.commit_id)
        self.assertEqual(result.effect_ids, ())
        self.assertEqual(self.session.store.revision, before + 1)

    def test_commit_id_requires_effect_ids(self):
        p = self._proposal(event_id="IDEM:NOEFFECT")
        p = Proposal(**{**p.__dict__, "commit_id": "commit:noeffect"})
        result = self.session.kernel.process(p)
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertIn("EFFECT_IDS_REQUIRED_FOR_COMMIT_ID", result.reasons)

    def test_effect_ids_require_commit_id(self):
        p = self._proposal(event_id="IDEM:NOCOMMIT")
        p = Proposal(**{**p.__dict__, "effect_ids": ("effect:no-commit",)})
        result = self.session.kernel.process(p)
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertIn("COMMIT_ID_REQUIRED_FOR_EFFECT_IDS", result.reasons)

    def test_duplicate_effect_id_in_one_proposal_is_rejected(self):
        p = self._proposal(event_id="IDEM:DUPINONE")
        p = Proposal(**{**p.__dict__, "commit_id": "commit:dup", "effect_ids": ("effect:x", "effect:x")})
        result = self.session.kernel.process(p)
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertIn("EFFECT_ID_DUPLICATE_IN_PROPOSAL", result.reasons)

    def test_reserved_idempotency_runtime_key_cannot_be_written_by_gameplay_delta(self):
        event = "IDEM:RESERVED"
        p = Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id=event,
            cause="TEST_STAGE9_IDEMPOTENCY",
            deltas=(Delta(
                domain=Domain.RUNTIME_STATE,
                key="__stage9_idempotency__",
                value={"attack": "overwrite"},
                writer=Authority.RULE_KERNEL,
                cause="TEST_STAGE9_IDEMPOTENCY",
                source_event_id=event,
            ),),
        )
        result = self.session.kernel.process(p)
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertIn("RESERVED_RUNTIME_STATE_KEY", result.reasons)

    def test_boundary_rejects_wrong_run(self):
        bound = self._bound(commit_id="commit:run")
        other = self.manager.create_run(player_uuid=self.player_uuid)
        with self.assertRaisesRegex(Stage9IdempotencyError, "RUN_ISOLATION_VIOLATION"):
            CommitIdempotencyBoundary(other).bind(
                self.revision_boundary.bind(
                    self.authority.authorize(self._effect("effect:run2")).commit_operation,
                    self._proposal(event_id="IDEM:RUN"),
                ),
                commit_id="commit:wrong-run",
            )
        # Keep the first valid binding alive so test also exercises construction.
        self.assertEqual(bound.commit_id, "commit:run")

    def test_invalid_commit_id_is_rejected_by_boundary(self):
        decision = self.authority.authorize(self._effect("effect:invalid-id"))
        revision_bound = self.revision_boundary.bind(
            decision.commit_operation, self._proposal(event_id="IDEM:BADID")
        )
        with self.assertRaisesRegex(Stage9IdempotencyError, "COMMIT_ID_INVALID"):
            self.idempotency_boundary.bind(revision_bound, commit_id=" bad id ")


if __name__ == "__main__":
    unittest.main(verbosity=2)
