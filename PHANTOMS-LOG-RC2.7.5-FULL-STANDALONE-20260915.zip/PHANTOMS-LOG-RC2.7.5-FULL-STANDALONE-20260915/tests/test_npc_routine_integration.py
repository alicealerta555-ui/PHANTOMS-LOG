from pathlib import Path
import tempfile

from playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, Domain
from runtime.full_version.npc_routines import ROUTINE_STATE_KEY
from runtime.stage9.actor_context import ACTOR_VISIBLE_RUNTIME_KEY

ROOT=Path(__file__).resolve().parents[1]


def make_game(tmp):
    g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class='OPERATOR',master_seed=20260913)
    g.complete_character(g.creation_template())
    return g


def test_wait_advances_time_and_npcs_follow_connected_routes():
    with tempfile.TemporaryDirectory() as tmp:
        g=make_game(tmp)
        before={k:g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,k)['location_ref'] for k in g.session.store.runtime_state if str(k).startswith('actor:npc:')}
        text,_=g.handle('/wait 8 h')
        assert 'Weltzeit=' in text
        state=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,ROUTINE_STATE_KEY)
        assert state['processed_slot']>=32
        after={k:g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,k)['location_ref'] for k in before}
        assert any(before[k]!=after[k] for k in before)
        # All runtime positions remain valid locations; visible mirror follows them.
        visible=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,ACTOR_VISIBLE_RUNTIME_KEY)
        for k,loc in after.items():
            g.catalog.location(loc)
            assert visible['actors'][k]['location_ref']==loc


def test_schedule_is_persistent_across_reload():
    with tempfile.TemporaryDirectory() as tmp:
        g=make_game(tmp)
        g.handle('/wait 7 h')
        state=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,ROUTINE_STATE_KEY)
        g2=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),master_seed=20260913)
        assert g2.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,ROUTINE_STATE_KEY)==state
