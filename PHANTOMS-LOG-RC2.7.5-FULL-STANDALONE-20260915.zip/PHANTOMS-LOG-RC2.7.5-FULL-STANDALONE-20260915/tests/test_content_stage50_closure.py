
import json,unittest
from pathlib import Path
from runtime.content_stage50.closure import *
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage50_content_closure.json").read_text())
class T(unittest.TestCase):
 def test_static(self): self.assertTrue(D["runtime_i9_frozen"])
 def test_closure_status(self): self.assertEqual(D["closure_status"],"FROZEN_BASELINE")
 def test_presence_ok(self): self.assertTrue(verify_stage_presence([1,2,3],[1,2,3])["ok"])
 def test_presence_missing(self): self.assertEqual(verify_stage_presence([1,2,3],[1,3])["missing"],[2])
 def test_mutable_id_guard(self): self.assertFalse(verify_static_no_mutable_ids({"x":"player_uuid"})["ok"])
 def test_mutable_id_clean(self): self.assertTrue(verify_static_no_mutable_ids({"x":"static only"})["ok"])
 def test_closure_record(self): self.assertEqual(closure_record("S50",100,True)["status"],"FROZEN_BASELINE")
 def test_closure_record_fail(self): self.assertEqual(closure_record("S50",100,False)["status"],"NOT_FROZEN")
 def test_next_work(self): self.assertEqual(D["post_closure_next"],"PLAYABLE_INTEGRATION_AND_END_TO_END_VALIDATION")
 def test_narration_rule(self): self.assertTrue(any("narration remains downstream" in x.lower() for x in D["rules"]))
 def test_distinct_domains_rule(self): self.assertTrue(any("remain distinct authority domains" in x.lower() for x in D["rules"]))
 def test_not_claim_complete_game(self): self.assertTrue(any("does not claim all gameplay is complete" in x.lower() for x in D["rules"]))
if __name__=="__main__": unittest.main()
