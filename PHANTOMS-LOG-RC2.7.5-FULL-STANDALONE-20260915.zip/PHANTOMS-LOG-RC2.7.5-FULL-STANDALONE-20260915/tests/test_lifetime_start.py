from collections import deque
from pathlib import Path
import tempfile

import pytest

from playable_full_version.playable.game import FullVersionGame
from runtime.full_version.lifetime_start import (
    LIFETIME_DIARY_ITEM_ID,
    LIFETIME_ESTATE_KNOWLEDGE_KEY,
    LIFETIME_FAMILY_ACTOR_ID,
    LIFETIME_LOCAL_ACTOR_IDS,
    canonical_origin_label,
)
from runtime.full_version.player_character import CharacterCreationError
from runtime.stage3a.kernel import Authority, Domain

ROOT=Path(__file__).resolve().parents[1]


def make_game(start_class='OPERATOR'):
    td=tempfile.TemporaryDirectory()
    g=FullVersionGame(core_root=ROOT,saves_root=Path(td.name),start_class=start_class,master_seed=20260915)
    g._test_tmp=td
    return g


def close_game(g):
    try: g.images.close()
    finally: g._test_tmp.cleanup()


def complete(g, **skill_overrides):
    draft=g.creation_template()
    draft['skills'].update(skill_overrides)
    g.complete_character(draft)
    return draft


def path_ids(g, target):
    start=g.location(); q=deque([(start,[])]) ; seen={start}
    while q:
        here,path=q.popleft()
        if here==target: return path
        for nxt in g.catalog.location(here)['connections']:
            if nxt not in seen:
                seen.add(nxt); q.append((nxt,path+[nxt]))
    raise AssertionError(f'no route {start}->{target}')


def travel(g,target):
    for step in path_ids(g,target):
        text,_=g.handle('/go '+step)
        assert 'COMMITTED' in text, text
    assert g.location()==target


def test_bootstrap_has_lifetime_household_no_class_loot_and_hidden_remote_estate():
    g=make_game('BREAKER')
    try:
        state=g.lifetime.state()
        assert state['start']['class_independent'] is True
        inv=[]
        for key in g.session.store.runtime_state:
            if not str(key).startswith('item:'): continue
            rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
            if isinstance(rec,dict) and rec.get('location_ref')=='inventory:actor:player': inv.append(key)
        assert inv==[LIFETIME_DIARY_ITEM_ID]
        assert not any(str(x).startswith('item:start:') for x in g.session.store.runtime_state)
        for actor_id in (LIFETIME_FAMILY_ACTOR_ID,*LIFETIME_LOCAL_ACTOR_IDS):
            rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,actor_id)
            assert rec['location_ref']==state['start']['location_id']
        known=g.session.kernel.read(Authority.KNOWLEDGE_ROUTER,Domain.ACTOR_KNOWLEDGE,f'npc_identity:{LIFETIME_FAMILY_ACTOR_ID}',actor_id='actor:player')
        assert isinstance(known,dict)
        for iid in state['estate']['item_instance_ids']:
            rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
            assert rec['location_ref']==state['estate']['target_location_id']
            assert rec['hidden'] is True
    finally: close_game(g)


def test_origin_is_lifetime_owned_not_free_character_biography():
    g=make_game('GHOST')
    try:
        expected=canonical_origin_label(g.lifetime.state())
        assert g.creation_template()['origin']==expected
        bad=g.creation_template(); bad['origin']='frei erfundene andere Herkunft'
        with pytest.raises(CharacterCreationError,match='CHARACTER_ORIGIN_MUST_MATCH_LIFETIME_START'):
            g.complete_character(bad)
        g.complete_character(g.creation_template())
        assert g.character()['origin']==expected
    finally: close_game(g)


def test_diary_never_leaks_exact_estate_before_discovery_and_debt_is_canonical():
    g=make_game()
    try:
        state=g.lifetime.state(); target=state['estate']['target_location_id']; target_name=g.catalog.location(target)['display_name']
        text=g.lifetime.journal_text()
        assert target not in text and target_name not in text
        initial=state['obligations']['current_debt_credits']
        complete(g)
        actor=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,'actor:player')
        assert actor['resources']['credits'] >= 10
        paid=min(10,initial)
        result=g.lifetime.pay_debt(paid)
        assert result['paid']==paid and result['remaining']==initial-paid
        assert g.lifetime.state()['obligations']['initial_debt_credits']==state['obligations']['initial_debt_credits']
    finally: close_game(g)


def test_remote_estate_hidden_until_successful_search_then_takeable_and_persistent():
    g=make_game('OPERATOR')
    try:
        complete(g, SKILL_OBSERVATION=10)
        state=g.lifetime.state(); target=state['estate']['target_location_id']; iid=state['estate']['item_instance_ids'][0]
        travel(g,target)
        blocked,_=g.handle('/take '+iid)
        assert 'BLOCKED' in blocked or 'NOT_DISCOVERED' in blocked
        search,_=g.handle('/search')
        assert 'Gefunden:' in search and iid in search
        rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
        assert rec['hidden'] is False
        knowledge=g.session.kernel.read(Authority.KNOWLEDGE_ROUTER,Domain.ACTOR_KNOWLEDGE,LIFETIME_ESTATE_KNOWLEDGE_KEY,actor_id='actor:player')
        assert knowledge['value']['location_id']==target
        take,_=g.handle('/take '+iid)
        assert 'COMMITTED' in take
        rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
        assert rec['location_ref']=='inventory:actor:player'
        assert 'geborgen' in g.lifetime.inheritance_text()
        g.save()
        saves_root=g.saves_root
        g.images.close()
        loaded=FullVersionGame(core_root=ROOT,saves_root=saves_root,master_seed=20260915)
        try:
            rec2=loaded.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
            assert rec2['location_ref']=='inventory:actor:player'
            assert loaded.lifetime.state()['estate']['discovered_location_id']==target
        finally: loaded.images.close()
    finally:
        # loaded test may already have closed image service; close is idempotent in current backend.
        try: close_game(g)
        except Exception: pass


def test_two_distinct_region_searches_resolve_route_without_magic_marker():
    g=make_game('GHOST')
    try:
        complete(g, SKILL_OBSERVATION=10)
        state=g.lifetime.state(); target=state['estate']['target_location_id']; region=state['estate']['target_region_id']
        candidates=[x['location_id'] for x in g.catalog.world['locations'] if x.get('enterable') and x.get('region_id')==region and x['location_id']!=target]
        assert len(candidates)>=2
        for loc in candidates[:2]:
            travel(g,loc)
            g.handle('/search')
        current=g.lifetime.state()
        assert current['estate']['discovered_location_id']==target
        assert current['diary']['exact_location_known'] is True
        knowledge=g.session.kernel.read(Authority.KNOWLEDGE_ROUTER,Domain.ACTOR_KNOWLEDGE,LIFETIME_ESTATE_KNOWLEDGE_KEY,actor_id='actor:player')
        assert knowledge['value']['location_id']==target
        # Discovery resolves a route clue; it does not teleport or reveal the estate items.
        assert g.location()!=target
        for iid in current['estate']['item_instance_ids']:
            assert g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)['hidden'] is True
    finally: close_game(g)


def test_life_history_is_canonical_class_independent_and_non_power_granting():
    g=make_game('RESONANT')
    try:
        state=g.lifetime.state(); history=state['life_history']
        assert history['schema']=='PHANTOMS_LIFE_HISTORY_V1'
        assert history['mechanical_modifiers']=={}
        assert history['education']['grants_skill_points'] is False
        assert history['early_work']['grants_skill_points'] is False
        assert history['knowledge_policy']=='AUTOBIOGRAPHICAL_ONLY_NO_HIDDEN_WORLD_FACTS'
        assert history['regional_context']['region_id']==state['start']['region_id']
        text=g.lifetime.life_history_text()
        assert 'Lebenslauf vor Spielstart' in text
        assert state['estate']['target_location_id'] not in text
        assert g.handle('/lebenslauf')[0]==text
        assert g.creation_packet()['lifetime_history']==history
    finally: close_game(g)


def test_family_relationship_seed_comes_from_lifetime_history():
    g=make_game('BREAKER')
    try:
        state=g.lifetime.state(); key='|'.join(sorted(('actor:player',LIFETIME_FAMILY_ACTOR_ID)))
        social=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,'__social_faction_runtime__')
        assert social['relationships'][key]==state['life_history']['relationship_seed']
    finally: close_game(g)
