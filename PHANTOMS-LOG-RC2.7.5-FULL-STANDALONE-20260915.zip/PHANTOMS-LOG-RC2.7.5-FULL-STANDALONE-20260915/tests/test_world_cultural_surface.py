import tempfile
from pathlib import Path

from runtime.full_version import FullVersionCatalog
from runtime.full_version.world_surface import WorldSurfaceResolver
from runtime.full_version.content_distribution import ContentDistributionResolver
from playable_full_version.playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, Domain

ROOT=Path(__file__).resolve().parents[1]


def test_world_surface_is_stable_and_contextual():
    c=FullVersionCatalog.load(ROOT); r=WorldSurfaceResolver(c)
    a=r.resolve('loc:residential_domestic:01',run_uuid='run-a')
    b=r.resolve('loc:residential_domestic:01',run_uuid='run-a')
    assert a==b
    assert a.category=='residential_domestic'
    assert a.region_id=='region:01'
    assert a.architecture and a.material and a.services
    assert a.culture_id
    assert a.trade_streams


def test_hybrid_is_culture_not_lineage_claim():
    c=FullVersionCatalog.load(ROOT); r=WorldSurfaceResolver(c)
    # Across a handful of run seeds at least one local surface may be hybrid; regardless,
    # the packet must never contain ancestry/lineage assertions.
    for seed in ['a','b','c','d','e','f','g','h']:
        p=r.resolve('loc:residential_domestic:01',run_uuid=seed).to_dict()
        assert 'lineage_id' not in p and 'species' not in p and 'ancestry' not in p
        assert isinstance(p['hybrid_culture'],bool)


def test_trade_flow_changes_market_context():
    c=FullVersionCatalog.load(ROOT); d=ContentDistributionResolver(c)
    # Components are strongly supported in the industrial category/region.
    m=d.market_flow_multiplier_ppm('item_def:component:005','loc:industrial_maintenance:01')
    assert m>1_000_000
    # Food is not a primary industrial flow.
    f=d.market_flow_multiplier_ppm('item_def:food:003','loc:industrial_maintenance:01')
    assert f<m


def test_npcs_get_persistent_cultural_surface_and_scene_uses_surface():
    with tempfile.TemporaryDirectory() as td:
        g=FullVersionGame(core_root=ROOT,saves_root=Path(td),start_class='OPERATOR',master_seed=20260913)
        g.complete_character(g.creation_template())
        npcs=[]
        for inst in g.actor_registry.instances():
            if inst.actor_instance_id=='actor:player': continue
            rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,inst.actor_instance_id)
            if isinstance(rec,dict) and rec.get('kind')=='actor': npcs.append(rec)
        assert npcs and all(isinstance(x.get('cultural_surface'),dict) for x in npcs)
        assert all(x['cultural_surface'].get('culture_id') for x in npcs)
        text=g.describe()
        assert 'Typische Dienste:' in text
        assert 'Regionaler Warenfluss:' in text
        services,_=g.handle('/services')
        assert 'Lokale Dienste:' in services and 'Regionale Handelsströme:' in services
        g.images.close()
