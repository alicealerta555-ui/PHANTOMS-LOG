
import json,unittest
from pathlib import Path
from runtime.content_stage9.society import *
ROOT=Path(__file__).resolve().parents[1]; D=json.loads((ROOT/"content/full_version/stage9_society.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_settlements(self): self.assertGreaterEqual(len(D["settlements"]),5)
 def test_hours(self): self.assertTrue(is_open(D["institutions"][0]["open_windows"],600)); self.assertFalse(is_open(D["institutions"][0]["open_windows"],1400))
 def test_access(self): self.assertTrue(access_allowed(D["institutions"][0],"medicine_store","medic")); self.assertFalse(access_allowed(D["institutions"][0],"medicine_store","patient"))
 def test_routine(self): self.assertEqual(routine_activity(D["daily_routines"][0],600),"work")
 def test_supply(self):
  s={"water":10}; d={"water":2}; m=plan_supply_transfer(s,{"water":99}); a,b=apply_transfer_projection(s,d,m); self.assertEqual(m["water"],10); self.assertEqual(12,a["water"]+b["water"])
 def test_memory(self):
  r={"subject_id":"x","claim":"c","source_actor_id":"a","observed_at":1,"received_at":2,"channel":"speech","confidence":70}; self.assertTrue(validate_social_memory(r)); r["source_actor_id"]=""; self.assertFalse(validate_social_memory(r))
 def test_relationship(self): self.assertEqual(relationship_delta({"trust":90},{"trust":30})["trust"],100)
if __name__=="__main__": unittest.main()
