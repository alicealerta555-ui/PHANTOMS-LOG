from pathlib import Path
import tempfile
from playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, Domain
from runtime.full_version.authored_missions_runtime import AuthoredMissionRuntime
ROOT=Path(__file__).resolve().parents[1]

def game(tmp):
    g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class='OPERATOR',master_seed=20260915)
    g.complete_character(g.creation_template()); return g

def npc(g):
    for k in g.session.store.runtime_state:
        if str(k).startswith('actor:npc:'):
            r=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,k)
            if isinstance(r,dict): return k
    raise AssertionError

def test_authored_mission_resolves_and_persists_attempt_without_autocomplete():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); n=npc(g); ar=AuthoredMissionRuntime(g.catalog,g.session)
        qid,_=ar.materialize('AM_DRONE_RECON',source_ref=n,location_id=g.location(),issuer_actor_id=n)
        assert g.execute(action_type='QUEST_ACCEPT',raw_input='accept',target_refs=(qid,)).status.value=='COMMITTED'
        entry=g.quest_runtime.resolve_mission_attempt(qid,difficulty=5,preparation_bonus=1)
        q=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid)
        assert entry['outcome'] in {'FULL_SUCCESS','SUCCESS_WITH_COST','PARTIAL_SUCCESS','FAILURE','CRITICAL_FAILURE'}
        assert len(q['mission_attempts'])==1 and q['state']=='ACTIVE'

def test_profession_does_not_lock_mission_and_low_capability_can_fail():
    with tempfile.TemporaryDirectory() as tmp:
        g=game(tmp); n=npc(g); ar=AuthoredMissionRuntime(g.catalog,g.session)
        qid,_=ar.materialize('AM_MED_TRIAGE',source_ref=n,location_id=g.location(),issuer_actor_id=n)
        g.execute(action_type='QUEST_ACCEPT',raw_input='accept',target_refs=(qid,))
        entry=g.quest_runtime.resolve_mission_attempt(qid,difficulty=12,danger=4,time_pressure=4)
        assert entry['outcome'] in {'FAILURE','CRITICAL_FAILURE'}
        cid=f"mission_consequence:{qid.split(':',1)[1]}:1"
        c=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,cid)
        assert c['state']=='PROPOSED' and c['effects']==[]
