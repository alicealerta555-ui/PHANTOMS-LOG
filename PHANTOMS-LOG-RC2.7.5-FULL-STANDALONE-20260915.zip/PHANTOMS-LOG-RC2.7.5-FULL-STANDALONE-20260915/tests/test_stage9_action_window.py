from __future__ import annotations

import threading
import unittest
from dataclasses import FrozenInstanceError
from uuid import uuid4

from runtime.stage3a.kernel import Authority, Delta, Domain, Mode, Proposal
from runtime.stage3b.pipeline import ActionRequest, ActionResult, ActionStatus, ActionRule, OutcomeBranch
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.action_window import ActionWindowStatus, Stage9ActionWindowError
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.playable_runtime import PlayableRuntime, RuntimeLifecycle


class Stage9ActionWindowTests(unittest.TestCase):
    def setUp(self) -> None:
        self.player_uuid = str(uuid4())
        self.run_uuid = str(uuid4())
        self.manager = RunSessionManager(master_seed=913)
        self.session = self.manager.create_run(player_uuid=self.player_uuid, run_uuid=self.run_uuid)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(self.player_uuid, self.run_uuid, "actor:player")
        self.registry.register(self.identity, actor_definition_id="test.player")

    @staticmethod
    def _request(event_id: str) -> ActionRequest:
        return ActionRequest(
            event_id=event_id,
            rule=ActionRule(
                rule_id="STAGE9_WINDOW_TEST",
                outcomes=(OutcomeBranch(outcome_id="NOOP", effects=()),),
            ),
            cause="STAGE9_WINDOW_TEST",
        )

    def _context(self, runtime: PlayableRuntime, suffix: str, *, turn: str | None = None, window: str | None = None):
        return runtime.create_context(
            self.identity,
            turn_id=turn or f"turn:{suffix}",
            action_window_id=window or f"window:{suffix}",
        )

    def test_resolved_no_change_consumes_normal_action_window(self) -> None:
        calls: list[str] = []
        def executor(request: ActionRequest) -> ActionResult:
            calls.append(request.event_id)
            return ActionResult(ActionStatus.RESOLVED_NO_CHANGE, request.event_id, "NOOP")
        runtime = PlayableRuntime(self.session, self.registry, action_executor=executor)
        context = self._context(runtime, "consume")
        runtime.execute_action(context, self._request("event:first"))
        snapshot = runtime.action_window_snapshot(context.action_window_id)
        self.assertIsNotNone(snapshot)
        self.assertEqual(snapshot.status, ActionWindowStatus.CONSUMED)  # type: ignore[union-attr]
        with self.assertRaisesRegex(Stage9ActionWindowError, "ONE_ACTION_GATE_CONSUMED"):
            runtime.execute_action(context, self._request("event:second"))
        self.assertEqual(calls, ["event:first"])
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.READY)

    def test_committed_action_consumes_window(self) -> None:
        event_id = "event:commit"
        def executor(request: ActionRequest) -> ActionResult:
            record = self.session.kernel.process(Proposal(
                mode=Mode.COMMIT,
                source=Authority.COMMIT_KERNEL,
                event_id=event_id,
                cause="WINDOW_COMMIT",
                deltas=(Delta(
                    Domain.RUNTIME_STATE, "window.commit.value", 1,
                    Authority.RULE_KERNEL, "WINDOW_COMMIT", source_event_id=event_id,
                ),),
            ))
            return ActionResult(ActionStatus.COMMITTED, request.event_id, "COMMIT", commit=record)  # type: ignore[arg-type]
        runtime = PlayableRuntime(self.session, self.registry, action_executor=executor)
        context = self._context(runtime, "commit")
        runtime.execute_action(context, self._request(event_id))
        # State revision changed, so capture a fresh context with the same logical window.
        fresh = runtime.create_context(
            self.identity, turn_id=context.turn_id, action_window_id=context.action_window_id,
        )
        with self.assertRaisesRegex(Stage9ActionWindowError, "ONE_ACTION_GATE_CONSUMED"):
            runtime.execute_action(fresh, self._request("event:second"))

    def test_blocked_action_does_not_consume_window(self) -> None:
        results = [ActionStatus.BLOCKED, ActionStatus.RESOLVED_NO_CHANGE]
        def executor(request: ActionRequest) -> ActionResult:
            return ActionResult(results.pop(0), request.event_id, "TEST")
        runtime = PlayableRuntime(self.session, self.registry, action_executor=executor)
        context = self._context(runtime, "blocked")
        first = runtime.execute_action(context, self._request("event:blocked"))
        self.assertEqual(first.action_result.status, ActionStatus.BLOCKED)
        self.assertEqual(runtime.action_window_snapshot(context.action_window_id).status, ActionWindowStatus.AVAILABLE)  # type: ignore[union-attr]
        second = runtime.execute_action(context, self._request("event:accepted"))
        self.assertEqual(second.action_result.status, ActionStatus.RESOLVED_NO_CHANGE)
        self.assertEqual(runtime.action_window_snapshot(context.action_window_id).status, ActionWindowStatus.CONSUMED)  # type: ignore[union-attr]

    def test_hold_and_rejected_do_not_consume_window(self) -> None:
        for status in (ActionStatus.HOLD, ActionStatus.REJECTED):
            with self.subTest(status=status):
                runtime = PlayableRuntime(
                    self.session,
                    self.registry,
                    action_executor=lambda req, s=status: ActionResult(s, req.event_id, "TEST"),
                )
                context = self._context(runtime, f"nonconsume-{status.value}")
                runtime.execute_action(context, self._request(f"event:{status.value}"))
                self.assertEqual(
                    runtime.action_window_snapshot(context.action_window_id).status,  # type: ignore[union-attr]
                    ActionWindowStatus.AVAILABLE,
                )

    def test_different_windows_each_allow_one_action(self) -> None:
        runtime = PlayableRuntime(
            self.session, self.registry,
            action_executor=lambda req: ActionResult(ActionStatus.RESOLVED_NO_CHANGE, req.event_id, "NOOP"),
        )
        runtime.execute_action(self._context(runtime, "a"), self._request("event:a"))
        runtime.execute_action(self._context(runtime, "b"), self._request("event:b"))
        self.assertEqual(runtime.action_window_snapshot("window:a").status, ActionWindowStatus.CONSUMED)  # type: ignore[union-attr]
        self.assertEqual(runtime.action_window_snapshot("window:b").status, ActionWindowStatus.CONSUMED)  # type: ignore[union-attr]

    def test_window_binding_cannot_be_reused_for_other_turn(self) -> None:
        runtime = PlayableRuntime(
            self.session, self.registry,
            action_executor=lambda req: ActionResult(ActionStatus.BLOCKED, req.event_id, "BLOCKED"),
        )
        first = self._context(runtime, "binding", turn="turn:a", window="window:shared")
        runtime.execute_action(first, self._request("event:a"))
        second = self._context(runtime, "binding2", turn="turn:b", window="window:shared")
        with self.assertRaisesRegex(Stage9ActionWindowError, "ACTION_WINDOW_BINDING_MISMATCH"):
            runtime.execute_action(second, self._request("event:b"))

    def test_gate_is_shared_between_runtime_wrappers_of_same_session(self) -> None:
        executor = lambda req: ActionResult(ActionStatus.RESOLVED_NO_CHANGE, req.event_id, "NOOP")
        runtime_a = PlayableRuntime(self.session, self.registry, action_executor=executor)
        runtime_b = PlayableRuntime(self.session, self.registry, action_executor=executor)
        context_a = self._context(runtime_a, "shared", turn="turn:shared", window="window:shared-runtime")
        runtime_a.execute_action(context_a, self._request("event:a"))
        context_b = runtime_b.create_context(
            self.identity, turn_id="turn:shared", action_window_id="window:shared-runtime",
        )
        with self.assertRaisesRegex(Stage9ActionWindowError, "ONE_ACTION_GATE_CONSUMED"):
            runtime_b.execute_action(context_b, self._request("event:b"))

    def test_technical_executor_fault_marks_window_faulted(self) -> None:
        def explode(_request: ActionRequest) -> ActionResult:
            raise RuntimeError("boom")
        runtime = PlayableRuntime(self.session, self.registry, action_executor=explode)
        context = self._context(runtime, "fault")
        with self.assertRaisesRegex(RuntimeError, "boom"):
            runtime.execute_action(context, self._request("event:fault"))
        self.assertEqual(runtime.action_window_snapshot(context.action_window_id).status, ActionWindowStatus.FAULTED)  # type: ignore[union-attr]
        runtime.reset_fault()
        with self.assertRaisesRegex(Stage9ActionWindowError, "ACTION_WINDOW_FAULTED"):
            runtime.execute_action(context, self._request("event:retry"))

    def test_gate_does_not_mutate_canonical_state_for_noop(self) -> None:
        runtime = PlayableRuntime(
            self.session, self.registry,
            action_executor=lambda req: ActionResult(ActionStatus.RESOLVED_NO_CHANGE, req.event_id, "NOOP"),
        )
        context = self._context(runtime, "noncanonical")
        before = self.session.store.snapshot()
        revision = self.session.store.revision
        runtime.execute_action(context, self._request("event:noop"))
        self.assertEqual(before, self.session.store.snapshot())
        self.assertEqual(revision, self.session.store.revision)

    def test_snapshot_is_immutable(self) -> None:
        runtime = PlayableRuntime(
            self.session, self.registry,
            action_executor=lambda req: ActionResult(ActionStatus.RESOLVED_NO_CHANGE, req.event_id, "NOOP"),
        )
        context = self._context(runtime, "immutable")
        runtime.execute_action(context, self._request("event:immutable"))
        snapshot = runtime.action_window_snapshot(context.action_window_id)
        with self.assertRaises((FrozenInstanceError, AttributeError)):
            snapshot.status = ActionWindowStatus.AVAILABLE  # type: ignore[misc,union-attr]

    def test_concurrent_same_window_second_runtime_is_rejected_before_executor(self) -> None:
        entered = threading.Event()
        release = threading.Event()
        calls: list[str] = []

        def slow_executor(request: ActionRequest) -> ActionResult:
            calls.append(request.event_id)
            entered.set()
            self.assertTrue(release.wait(2.0))
            return ActionResult(ActionStatus.RESOLVED_NO_CHANGE, request.event_id, "NOOP")

        runtime_a = PlayableRuntime(self.session, self.registry, action_executor=slow_executor)
        runtime_b = PlayableRuntime(
            self.session, self.registry,
            action_executor=lambda req: calls.append("SECOND_EXECUTOR") or ActionResult(ActionStatus.RESOLVED_NO_CHANGE, req.event_id, "NOOP"),
        )
        context_a = self._context(runtime_a, "concurrent", turn="turn:concurrent", window="window:concurrent")
        context_b = runtime_b.create_context(
            self.identity, turn_id="turn:concurrent", action_window_id="window:concurrent",
        )
        error: list[BaseException] = []

        def run_a() -> None:
            try:
                runtime_a.execute_action(context_a, self._request("event:first"))
            except BaseException as exc:  # pragma: no cover - test transport
                error.append(exc)

        thread = threading.Thread(target=run_a)
        thread.start()
        self.assertTrue(entered.wait(2.0))
        try:
            with self.assertRaisesRegex(Stage9ActionWindowError, "ACTION_WINDOW_ALREADY_RESERVED"):
                runtime_b.execute_action(context_b, self._request("event:second"))
        finally:
            release.set()
            thread.join(2.0)
        self.assertFalse(error)
        self.assertNotIn("SECOND_EXECUTOR", calls)
        self.assertEqual(runtime_a.action_window_snapshot("window:concurrent").status, ActionWindowStatus.CONSUMED)  # type: ignore[union-attr]


if __name__ == "__main__":
    unittest.main()
