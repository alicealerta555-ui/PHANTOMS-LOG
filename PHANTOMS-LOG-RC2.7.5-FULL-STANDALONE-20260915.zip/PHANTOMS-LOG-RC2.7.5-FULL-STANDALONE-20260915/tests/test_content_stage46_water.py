
import json, unittest
from pathlib import Path
from runtime.content_stage46.water import *
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage46_water_systems.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_sources(self): self.assertGreaterEqual(len(D["source_types"]),4)
 def test_extraction_requires_time(self): self.assertEqual(extraction(100,100,0),0)
 def test_extraction_bounded(self): self.assertEqual(extraction(200,100,1),100)
 def test_treatment_conserves(self):
  x=treatment(100,100,9000); self.assertEqual(x["treated"]+x["residual"],100)
 def test_storage_capacity(self): self.assertEqual(storage_add(90,20,100)["accepted"],10)
 def test_distribution_conservation(self):
  x=distribution(100,100,100,1000); self.assertEqual(x["sent"],x["delivered"]+x["loss"])
 def test_distribution_capacity(self): self.assertEqual(distribution(100,100,40,0)["delivered"],40)
 def test_contamination_authority(self): self.assertTrue(contamination_candidate("W","BIOLOGICAL",50,"CAUSE","EV")["authority_required"])
 def test_purification_authority(self): self.assertTrue(purification_candidate("W",50,"FILTER","EV")["authority_required"])
 def test_contamination_persists_rule(self): self.assertTrue(any("contamination persists" in x.lower() for x in D["rules"]))
 def test_clean_look_not_safe(self): self.assertTrue(any("not automatically safe" in x.lower() for x in D["rules"]))
if __name__=="__main__": unittest.main()
