import unittest

from runtime.stage3a.kernel import (
    Authority, CommitKernel, Delta, Domain, Mode, Proposal, StateStore,
    UnresolvedSpec, WeightedOption, Verdict,
)
from runtime.stage3a.integration import RuntimeAuthorityBridge
from runtime.stage3b.pipeline import (
    ActionPipeline, ActionRequest, ActionRule, ActionStatus, BaselineVerifier,
    Condition, Effect, ExprOp, FactRef, Operator, OutcomeBranch, RandomDraw,
    ValueExpr, ValueSource, VerificationDecision,
)
from runtime.stage3d.epistemic import epistemic_stamp


def epi_meta(source="test", t=1):
    return epistemic_stamp(source_type="DIRECT_OBSERVATION", source_id=source, origin_location="TEST", learned_at=t)


def commit_init(kernel, event_id, deltas):
    return kernel.process(Proposal(
        mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL,
        event_id=event_id, cause="TEST_INIT", deltas=tuple(deltas),
    ))


class RejectVerifier:
    def verify(self, **kwargs):
        return VerificationDecision(Verdict.REJECT, ("TEST_VETO",))


class HoldVerifier:
    def verify(self, **kwargs):
        return VerificationDecision(Verdict.HOLD, ("TEST_HOLD",))


class Stage3BTests(unittest.TestCase):
    def setUp(self):
        self.kernel = CommitKernel(StateStore(), world_seed=424242)
        self.bridge = RuntimeAuthorityBridge(self.kernel)
        self.pipeline = ActionPipeline(self.bridge)
        commit_init(self.kernel, "init:runtime", [
            Delta(Domain.RUNTIME_STATE, "door_open", False, Authority.RULE_KERNEL, "INIT", source_event_id="init:runtime"),
            Delta(Domain.RUNTIME_STATE, "energy", 5, Authority.RULE_KERNEL, "INIT", source_event_id="init:runtime"),
            Delta(Domain.WORLD_TRUTH, "door_locked", True, Authority.RULE_KERNEL, "INIT", source_event_id="init:runtime"),
            Delta(Domain.PLAYER_KNOWLEDGE, "has_key", True, Authority.SYSTEM_INIT, "INIT", source_event_id="init:runtime", provenance="inventory bootstrap"),
        ])

    def open_rule(self):
        return ActionRule(
            rule_id="OPEN_DOOR",
            facts=(
                FactRef("locked", Domain.WORLD_TRUTH, "door_locked"),
                FactRef("has_key", Domain.PLAYER_KNOWLEDGE, "has_key"),
            ),
            preconditions=(
                Condition(ValueSource.FACT, "locked", Operator.EQ, True),
                Condition(ValueSource.FACT, "has_key", Operator.EQ, True),
            ),
            outcomes=(OutcomeBranch("OPENED", effects=(
                Effect(Domain.RUNTIME_STATE, "door_open", True, "RULE_KERNEL", "OPEN_DOOR"),
            )),),
            narration_runtime_keys=("door_open",),
        )

    def test_happy_path_commit_then_narration(self):
        r = self.pipeline.execute(ActionRequest("act:1", self.open_rule(), "open door"))
        self.assertEqual(r.status, ActionStatus.COMMITTED)
        self.assertEqual(self.kernel.store.runtime_state["door_open"], True)
        self.assertEqual(r.narration_context["PRESENTATION_RUNTIME"]["door_open"], True)
        self.assertNotIn("WORLD_TRUTH", r.narration_context)

    def test_duplicate_event_is_hold_no_second_effect(self):
        r1 = self.pipeline.execute(ActionRequest("act:dup", self.open_rule()))
        rev = self.kernel.store.revision
        r2 = self.pipeline.execute(ActionRequest("act:dup", self.open_rule()))
        self.assertEqual(r1.status, ActionStatus.COMMITTED)
        self.assertEqual(r2.status, ActionStatus.HOLD)
        self.assertEqual(self.kernel.store.revision, rev)

    def test_precondition_failure_no_commit(self):
        rule = ActionRule(
            rule_id="NEED_ENERGY",
            facts=(FactRef("energy", Domain.RUNTIME_STATE, "energy"),),
            preconditions=(Condition(ValueSource.FACT, "energy", Operator.GE, 99),),
            outcomes=(OutcomeBranch("OK", effects=(Effect(Domain.RUNTIME_STATE, "energy", 0, "RULE_KERNEL", "SPEND"),)),),
        )
        h = self.kernel.store.state_hash()
        r = self.pipeline.execute(ActionRequest("act:fail", rule))
        self.assertEqual(r.status, ActionStatus.BLOCKED)
        self.assertEqual(self.kernel.store.state_hash(), h)

    def test_optional_missing_fact_not_exists(self):
        rule = ActionRule(
            rule_id="OPTIONAL",
            facts=(FactRef("flag", Domain.RUNTIME_STATE, "never_set", required=False),),
            preconditions=(Condition(ValueSource.FACT, "flag", Operator.NOT_EXISTS),),
            outcomes=(OutcomeBranch("OK", effects=(Effect(Domain.RUNTIME_STATE, "x", 1, "RULE_KERNEL", "OK"),)),),
        )
        r = self.pipeline.execute(ActionRequest("act:optional", rule))
        self.assertEqual(r.status, ActionStatus.COMMITTED)

    def test_required_missing_blocks(self):
        rule = ActionRule(
            rule_id="MISSING",
            facts=(FactRef("x", Domain.RUNTIME_STATE, "missing"),),
            outcomes=(OutcomeBranch("OK"),),
        )
        r = self.pipeline.execute(ActionRequest("act:missing", rule))
        self.assertEqual(r.status, ActionStatus.BLOCKED)
        self.assertTrue(any("REQUIRED_FACT_MISSING" in x for x in r.reasons))

    def test_unknown_truth_resolution(self):
        spec = UnresolvedSpec("crate_trapped", (WeightedOption(True, 1), WeightedOption(False, 1)), seed_salt="crate7")
        self.kernel.register_unresolved(spec, event_id="init:trap")
        rule = ActionRule(
            rule_id="INSPECT_CRATE",
            facts=(FactRef("trapped", Domain.WORLD_TRUTH, "crate_trapped", resolve_if_unknown=True),),
            outcomes=(OutcomeBranch("OBSERVED", effects=(
                Effect(Domain.PLAYER_KNOWLEDGE, "crate_trapped", "observed", "KNOWLEDGE_ROUTER", "INSPECT", provenance="direct inspection", epistemic=epi_meta("crate-inspection", 2)),
            )),),
        )
        r = self.pipeline.execute(ActionRequest("act:inspect", rule, player_suggestion=True))
        self.assertEqual(r.status, ActionStatus.COMMITTED)
        self.assertIn("crate_trapped", self.kernel.store.world_truth)
        self.assertNotIn("crate_trapped", self.kernel.store.unresolved_world)

    def test_resolution_anti_suggestion(self):
        def run(suggestion):
            k = CommitKernel(StateStore(), world_seed=777)
            b = RuntimeAuthorityBridge(k)
            p = ActionPipeline(b)
            k.register_unresolved(UnresolvedSpec("x", (WeightedOption("A", 1), WeightedOption("B", 1)), seed_salt="s"), event_id="init:x")
            rule = ActionRule("R", facts=(FactRef("x", Domain.WORLD_TRUTH, "x", resolve_if_unknown=True),), outcomes=(OutcomeBranch("O"),))
            p.execute(ActionRequest("evt", rule, player_suggestion=suggestion))
            return k.store.world_truth["x"]
        self.assertEqual(run("A"), run("B"))

    def test_no_reroll_on_repeat_fact_resolution(self):
        self.kernel.register_unresolved(UnresolvedSpec("weather", (WeightedOption("rain", 1), WeightedOption("clear", 1))), event_id="init:w")
        rule = ActionRule("LOOK", facts=(FactRef("w", Domain.WORLD_TRUTH, "weather", resolve_if_unknown=True),), outcomes=(OutcomeBranch("O"),))
        self.pipeline.execute(ActionRequest("look:1", rule))
        first = self.kernel.store.world_truth["weather"]
        rev = self.kernel.store.revision
        self.pipeline.execute(ActionRequest("look:2", rule))
        self.assertEqual(self.kernel.store.world_truth["weather"], first)
        self.assertEqual(self.kernel.store.revision, rev)  # no fake/empty action commit

    def test_rng_deterministic_and_player_text_independent(self):
        rule = ActionRule("ROLL", random_draws=(RandomDraw("d20", 1, 20),), outcomes=(OutcomeBranch("O"),))
        def draw(text):
            k = CommitKernel(StateStore(), world_seed=9)
            p = ActionPipeline(RuntimeAuthorityBridge(k))
            return p.execute(ActionRequest("same:event", rule, text, player_suggestion=text)).rng["d20"]
        self.assertEqual(draw("I expect 20"), draw("I expect 1"))

    def test_outcome_branching(self):
        rule = ActionRule(
            "BRANCH",
            random_draws=(RandomDraw("d", 1, 1),),
            outcomes=(OutcomeBranch("SUCCESS", (Condition(ValueSource.RNG, "d", Operator.EQ, 1),),
                                    (Effect(Domain.RUNTIME_STATE, "branch", "success", "RULE_KERNEL", "BRANCH"),)),),
            default_outcome=OutcomeBranch("FAIL", effects=(Effect(Domain.RUNTIME_STATE, "branch", "fail", "RULE_KERNEL", "BRANCH"),)),
        )
        r = self.pipeline.execute(ActionRequest("act:branch", rule))
        self.assertEqual(r.outcome_id, "SUCCESS")
        self.assertEqual(self.kernel.store.runtime_state["branch"], "success")

    def test_no_matching_outcome_rejects(self):
        rule = ActionRule("NONE", random_draws=(RandomDraw("d", 1, 1),),
                          outcomes=(OutcomeBranch("IMPOSSIBLE", (Condition(ValueSource.RNG, "d", Operator.EQ, 2),)),))
        h = self.kernel.store.state_hash()
        r = self.pipeline.execute(ActionRequest("act:none", rule))
        self.assertEqual(r.status, ActionStatus.REJECTED)
        self.assertEqual(self.kernel.store.state_hash(), h)

    def test_verifier_reject_prevents_commit(self):
        p = ActionPipeline(self.bridge, verifier=RejectVerifier())
        h = self.kernel.store.state_hash()
        r = p.execute(ActionRequest("act:veto", self.open_rule()))
        self.assertEqual(r.status, ActionStatus.REJECTED)
        self.assertEqual(self.kernel.store.state_hash(), h)

    def test_verifier_hold_prevents_commit(self):
        p = ActionPipeline(self.bridge, verifier=HoldVerifier())
        h = self.kernel.store.state_hash()
        r = p.execute(ActionRequest("act:hold", self.open_rule()))
        self.assertEqual(r.status, ActionStatus.HOLD)
        self.assertEqual(self.kernel.store.state_hash(), h)

    def test_invalid_schema_undeclared_fact(self):
        rule = ActionRule("BAD", preconditions=(Condition(ValueSource.FACT, "ghost", Operator.EQ, 1),), outcomes=(OutcomeBranch("O"),))
        r = self.pipeline.execute(ActionRequest("act:bad", rule))
        self.assertEqual(r.status, ActionStatus.REJECTED)
        self.assertTrue(any("UNDECLARED_FACT_REFERENCE" in x for x in r.reasons))

    def test_invalid_schema_undeclared_rng(self):
        rule = ActionRule("BAD", outcomes=(OutcomeBranch("O", (Condition(ValueSource.RNG, "ghost", Operator.EQ, 1),)),))
        r = self.pipeline.execute(ActionRequest("act:bad2", rule))
        self.assertEqual(r.status, ActionStatus.REJECTED)

    def test_invalid_schema_duplicate_fact(self):
        rule = ActionRule("BAD", facts=(FactRef("x", Domain.RUNTIME_STATE, "a", required=False), FactRef("x", Domain.RUNTIME_STATE, "b", required=False)), outcomes=(OutcomeBranch("O"),))
        self.assertEqual(self.pipeline.execute(ActionRequest("e", rule)).status, ActionStatus.REJECTED)

    def test_system_init_effect_forbidden(self):
        rule = ActionRule("BAD", outcomes=(OutcomeBranch("O", effects=(Effect(Domain.RUNTIME_STATE, "x", 1, "SYSTEM_INIT", "BAD"),)),))
        self.assertEqual(self.pipeline.execute(ActionRequest("e2", rule)).status, ActionStatus.REJECTED)

    def test_unresolved_effect_forbidden(self):
        rule = ActionRule("BAD", outcomes=(OutcomeBranch("O", effects=(Effect(Domain.UNRESOLVED_WORLD, "x", {}, "WORLD_RESOLVER", "BAD"),)),))
        self.assertEqual(self.pipeline.execute(ActionRequest("e3", rule)).status, ActionStatus.REJECTED)

    def test_knowledge_requires_provenance(self):
        rule = ActionRule("BAD", outcomes=(OutcomeBranch("O", effects=(Effect(Domain.PLAYER_KNOWLEDGE, "x", 1, "KNOWLEDGE_ROUTER", "BAD"),)),))
        self.assertEqual(self.pipeline.execute(ActionRequest("e4", rule)).status, ActionStatus.REJECTED)

    def test_actor_knowledge_requires_actor(self):
        rule = ActionRule("BAD", outcomes=(OutcomeBranch("O", effects=(Effect(Domain.ACTOR_KNOWLEDGE, "x", 1, "KNOWLEDGE_ROUTER", "BAD", provenance="heard"),)),))
        self.assertEqual(self.pipeline.execute(ActionRequest("e5", rule)).status, ActionStatus.REJECTED)

    def test_circumstance_rule_requires_current_spec_id(self):
        rule = ActionRule("C", outcomes=(OutcomeBranch("O"),), requires_circumstance=True)
        h = self.kernel.store.state_hash()
        r = self.pipeline.execute(ActionRequest("c1", rule))
        self.assertEqual(r.status, ActionStatus.REJECTED)
        self.assertTrue(any("CIRCUMSTANCE_ID_REQUIRED" in reason for reason in r.reasons))
        self.assertEqual(self.kernel.store.state_hash(), h)

    def test_atomic_multiple_effects(self):
        rule = ActionRule("MULTI", outcomes=(OutcomeBranch("O", effects=(
            Effect(Domain.RUNTIME_STATE, "a", 1, "RULE_KERNEL", "M"),
            Effect(Domain.RUNTIME_STATE, "b", 2, "RULE_KERNEL", "M"),
        )),))
        r = self.pipeline.execute(ActionRequest("multi", rule))
        self.assertEqual(r.status, ActionStatus.COMMITTED)
        self.assertEqual((self.kernel.store.runtime_state["a"], self.kernel.store.runtime_state["b"]), (1, 2))
        self.assertEqual(r.commit.revision, self.kernel.store.revision)

    def test_player_text_never_committed(self):
        rule = ActionRule("TEXT", outcomes=(OutcomeBranch("O", effects=(Effect(Domain.RUNTIME_STATE, "x", 1, "RULE_KERNEL", "T"),)),))
        text = "the secret password is banana"
        self.pipeline.execute(ActionRequest("text1", rule, text, player_suggestion="banana"))
        snap = repr(self.kernel.store.snapshot())
        self.assertNotIn(text, snap)
        self.assertNotIn("banana", snap)

    def test_narration_projection_contains_player_knowledge_not_truth(self):
        rule = ActionRule("N", outcomes=(OutcomeBranch("O"),))
        r = self.pipeline.execute(ActionRequest("n1", rule))
        self.assertEqual(r.status, ActionStatus.RESOLVED_NO_CHANGE)
        self.assertIn("PLAYER_KNOWLEDGE", r.narration_context)
        self.assertNotIn("WORLD_TRUTH", r.narration_context)

    def test_condition_operators(self):
        facts = {"x": 5, "lst": "a", "t": True, "f": False}
        E = self.pipeline._eval_condition
        self.assertTrue(E(Condition(ValueSource.FACT, "x", Operator.GT, 4), facts, {}))
        self.assertTrue(E(Condition(ValueSource.FACT, "x", Operator.GE, 5), facts, {}))
        self.assertTrue(E(Condition(ValueSource.FACT, "x", Operator.LT, 6), facts, {}))
        self.assertTrue(E(Condition(ValueSource.FACT, "x", Operator.LE, 5), facts, {}))
        self.assertTrue(E(Condition(ValueSource.FACT, "x", Operator.NE, 4), facts, {}))
        self.assertTrue(E(Condition(ValueSource.FACT, "lst", Operator.IN, ["a", "b"]), facts, {}))
        self.assertTrue(E(Condition(ValueSource.FACT, "lst", Operator.NOT_IN, ["b"]), facts, {}))
        self.assertTrue(E(Condition(ValueSource.FACT, "t", Operator.TRUTHY), facts, {}))
        self.assertTrue(E(Condition(ValueSource.FACT, "f", Operator.FALSY), facts, {}))

    def test_bad_comparison_fails_closed(self):
        self.assertFalse(self.pipeline._eval_condition(Condition(ValueSource.FACT, "x", Operator.GT, 3), {"x": "abc"}, {}))

    def test_world_truth_effect_can_be_rule_kernel(self):
        rule = ActionRule("WT", outcomes=(OutcomeBranch("O", effects=(Effect(Domain.WORLD_TRUTH, "lamp_broken", True, "RULE_KERNEL", "PLAYER_BREAKS_LAMP"),)),))
        r = self.pipeline.execute(ActionRequest("wt1", rule))
        self.assertEqual(r.status, ActionStatus.COMMITTED)
        self.assertTrue(self.kernel.store.world_truth["lamp_broken"])

    def test_actor_knowledge_effect_with_provenance(self):
        rule = ActionRule("AK", outcomes=(OutcomeBranch("O", effects=(Effect(Domain.ACTOR_KNOWLEDGE, "saw_player", True, "KNOWLEDGE_ROUTER", "LINE_OF_SIGHT", actor_id="npc:1", provenance="direct observation", epistemic=epi_meta("los", 3)),)),))
        r = self.pipeline.execute(ActionRequest("ak1", rule))
        self.assertEqual(r.status, ActionStatus.COMMITTED)
        self.assertTrue(self.kernel.store.actor_knowledge["npc:1"]["saw_player"]["value"])

    def test_rule_schema_callable_expected_rejected(self):
        rule = ActionRule("BAD", facts=(FactRef("x", Domain.RUNTIME_STATE, "energy"),), preconditions=(Condition(ValueSource.FACT, "x", Operator.EQ, lambda: 5),), outcomes=(OutcomeBranch("O"),))
        self.assertEqual(self.pipeline.execute(ActionRequest("badcall", rule)).status, ActionStatus.REJECTED)

    def test_invalid_rng_bounds_rejected(self):
        rule = ActionRule("BAD", random_draws=(RandomDraw("d", 2, 1),), outcomes=(OutcomeBranch("O"),))
        self.assertEqual(self.pipeline.execute(ActionRequest("bad_rng", rule)).status, ActionStatus.REJECTED)


    def test_effect_expression_decrements_fact(self):
        rule = ActionRule(
            "SPEND",
            facts=(FactRef("energy", Domain.RUNTIME_STATE, "energy"),),
            preconditions=(Condition(ValueSource.FACT, "energy", Operator.GE, 1),),
            outcomes=(OutcomeBranch("OK", effects=(
                Effect(Domain.RUNTIME_STATE, "energy", None, "RULE_KERNEL", "SPEND", value_expr=ValueExpr(ValueSource.FACT, "energy", ExprOp.SUB, 1)),
            )),),
        )
        r = self.pipeline.execute(ActionRequest("spend:1", rule))
        self.assertEqual(r.status, ActionStatus.COMMITTED)
        self.assertEqual(self.kernel.store.runtime_state["energy"], 4)

    def test_effect_expression_from_rng(self):
        rule = ActionRule(
            "RNG_EFFECT",
            random_draws=(RandomDraw("d", 7, 7),),
            outcomes=(OutcomeBranch("OK", effects=(
                Effect(Domain.RUNTIME_STATE, "rolled", None, "RULE_KERNEL", "ROLL", value_expr=ValueExpr(ValueSource.RNG, "d")),
            )),),
        )
        r = self.pipeline.execute(ActionRequest("rng-effect", rule))
        self.assertEqual(r.status, ActionStatus.COMMITTED)
        self.assertEqual(self.kernel.store.runtime_state["rolled"], 7)

    def test_effect_expression_undeclared_fact_rejected(self):
        rule = ActionRule("BAD_EXPR", outcomes=(OutcomeBranch("O", effects=(
            Effect(Domain.RUNTIME_STATE, "x", None, "RULE_KERNEL", "X", value_expr=ValueExpr(ValueSource.FACT, "ghost")),
        )),))
        self.assertEqual(self.pipeline.execute(ActionRequest("bad-expr", rule)).status, ActionStatus.REJECTED)


    def test_world_resolver_cannot_be_used_as_direct_action_effect(self):
        rule = ActionRule("BAD_RESOLVER", outcomes=(OutcomeBranch("O", effects=(
            Effect(Domain.WORLD_TRUTH, "secret", "forced", "WORLD_RESOLVER", "BAD"),
        )),))
        r = self.pipeline.execute(ActionRequest("bad-resolver", rule))
        self.assertEqual(r.status, ActionStatus.REJECTED)
        self.assertNotIn("secret", self.kernel.store.world_truth)

    def test_known_failed_precondition_does_not_resolve_unrelated_unknown(self):
        self.kernel.register_unresolved(
            UnresolvedSpec("hidden_alarm", (WeightedOption(True, 1), WeightedOption(False, 1))),
            event_id="init:hidden-alarm",
        )
        rule = ActionRule(
            "IMPOSSIBLE_WITH_UNKNOWN",
            facts=(
                FactRef("energy", Domain.RUNTIME_STATE, "energy"),
                FactRef("alarm", Domain.WORLD_TRUTH, "hidden_alarm", resolve_if_unknown=True),
            ),
            preconditions=(
                Condition(ValueSource.FACT, "energy", Operator.GE, 999),
                Condition(ValueSource.FACT, "alarm", Operator.EXISTS),
            ),
            outcomes=(OutcomeBranch("O"),),
        )
        r = self.pipeline.execute(ActionRequest("impossible", rule))
        self.assertEqual(r.status, ActionStatus.BLOCKED)
        self.assertNotIn("hidden_alarm", self.kernel.store.world_truth)
        self.assertIn("hidden_alarm", self.kernel.store.unresolved_world)


    def test_existing_none_is_not_missing(self):
        commit_init(self.kernel, "init:none", [
            Delta(Domain.RUNTIME_STATE, "nullable", None, Authority.RULE_KERNEL, "INIT", source_event_id="init:none"),
        ])
        rule = ActionRule(
            "NULL_PRESENT",
            facts=(FactRef("nullable", Domain.RUNTIME_STATE, "nullable"),),
            preconditions=(Condition(ValueSource.FACT, "nullable", Operator.EXISTS),),
            outcomes=(OutcomeBranch("OK"),),
        )
        r = self.pipeline.execute(ActionRequest("null-present", rule))
        self.assertEqual(r.status, ActionStatus.RESOLVED_NO_CHANGE)

    def test_ambiguous_literal_and_expression_effect_rejected(self):
        rule = ActionRule(
            "AMBIG", facts=(FactRef("energy", Domain.RUNTIME_STATE, "energy"),),
            outcomes=(OutcomeBranch("O", effects=(
                Effect(Domain.RUNTIME_STATE, "x", 5, "RULE_KERNEL", "X", value_expr=ValueExpr(ValueSource.FACT, "energy")),
            )),),
        )
        self.assertEqual(self.pipeline.execute(ActionRequest("ambig", rule)).status, ActionStatus.REJECTED)

    def test_empty_rule_no_outcome_rejected(self):
        self.assertEqual(self.pipeline.execute(ActionRequest("empty", ActionRule("EMPTY"))).status, ActionStatus.REJECTED)


if __name__ == "__main__":
    unittest.main()
