
import json,unittest
from pathlib import Path
from runtime.content_stage13.economy import *
ROOT=Path(__file__).resolve().parents[1]; D=json.loads((ROOT/"content/full_version/stage13_economy.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_markets(self): self.assertGreaterEqual(len(D["markets"]),5)
 def test_scarcity(self): self.assertGreater(quote_price(10,1,100),quote_price(10,100,100))
 def test_reputation_bounded(self):
  a=quote_price(100,100,100,reputation_bp=-99999); b=quote_price(100,100,100,reputation_bp=-2500); self.assertEqual(a,b)
 def test_no_phantom_stock(self):
  p=make_trade_proposal("s","b","m",[("food",9)],"CUR_SCRIP",1,{"food":5},{"food":3}); self.assertEqual(p["lines"][0]["qty"],3)
 def test_total(self):
  p=make_trade_proposal("s","b","m",[("food",2)],"CUR_SCRIP",1,{"food":5},{"food":3}); self.assertEqual(p["total"],10)
 def test_acceptance(self):
  p=make_trade_proposal("s","b","m",[("food",1)],"CUR_SCRIP",1,{"food":5},{"food":3}); self.assertIsNone(accept_trade(p,"x")); self.assertTrue(accept_trade(p,"b")["accepted"])
 def test_authority(self):
  p=make_trade_proposal("s","b","m",[],"CUR_SCRIP",1,{},{}); self.assertTrue(p["authority_required"])
 def test_service(self):
  p=service_proposal(D["services"][0],"npc","p",10); self.assertTrue(p["authority_required"]); self.assertGreater(p["duration_min"],0)
if __name__=="__main__": unittest.main()
