from runtime.player_progression.npc_lifelike import (
    NPCLivedExperienceEngine, NPCLifeSnapshot, SocialMomentContext,
    ConversationTopic, SocialAction,
)


def npc(**kw):
    base = dict(npc_id="n1", trust=.5, familiarity=.5, sociability=.6,
                patience=.6, curiosity=.7, openness=.6, social_energy=.7,
                interests=("tech", "weapons"))
    base.update(kw)
    return NPCLifeSnapshot(**base)


def ctx(**kw):
    base = dict(turn=10, safe=True, privacy=.7, conversation_open=True)
    base.update(kw)
    return SocialMomentContext(**base)


def topic(**kw):
    base = dict(key="gear", label="ungewöhnliche Ausrüstung", tags=("tech",),
                npc_personal_relevance=.6, player_relevance=.6)
    base.update(kw)
    return ConversationTopic(**base)


def test_interest_can_be_visible_without_forcing_dialogue():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(npc(sociability=.1, social_energy=.25), ctx(conversation_open=False), topic())
    assert r.action in {SocialAction.SILENT, SocialAction.DEFER}
    assert any("Aufmerksamkeit" in c or "interessiert" in r.line_hint for c in r.visible_cues) or r.deferred_topic


def test_busy_npc_keeps_own_task_present():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(npc(active_task="eine Pumpe auseinandernehmen", task_pressure=.7),
                   ctx(npc_busy=True, interruption_cost=.7), topic())
    assert r.resumes_task
    assert any("Pumpe" in c for c in r.visible_cues)


def test_danger_defers_nonurgent_topic():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(npc(), ctx(danger=.9, safe=False), topic())
    assert r.action == SocialAction.DEFER
    assert r.deferred_topic == "gear"


def test_urgent_help_can_get_brief_answer_in_danger():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(npc(), ctx(danger=.9, safe=False, player_needs_help=True),
                   topic(urgency=.9, can_wait=False))
    assert r.action == SocialAction.BRIEF


def test_private_topic_requires_privacy():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(npc(trust=.9, familiarity=.9), ctx(privacy=.1, public_setting=True),
                   topic(key="past", label="Vergangenheit", intimacy=.6, requires_privacy=True))
    assert r.action == SocialAction.DEFER


def test_relationship_boundary_blocks_too_intimate_question():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(npc(trust=.05, familiarity=.05), ctx(explicit_player_question=True),
                   topic(key="trauma", label="Trauma", intimacy=.9))
    assert r.action == SocialAction.DECLINE


def test_explicit_question_gets_answer_when_context_allows():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(npc(), ctx(explicit_player_question=True), topic())
    assert r.action in {SocialAction.ENGAGE, SocialAction.BRIEF}


def test_exhausted_npc_does_not_turn_every_question_into_lecture():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(npc(fatigue=.9, social_energy=.15), ctx(explicit_player_question=True), topic(can_wait=False))
    assert r.action == SocialAction.BRIEF


def test_deferred_topic_can_be_revisited_later():
    e = NPCLivedExperienceEngine()
    e.evaluate(npc(), ctx(turn=1, danger=.9, safe=False), topic())
    r = e.revisit(npc(), ctx(turn=20, danger=0, safe=True, conversation_open=True), "gear")
    assert r.action in {SocialAction.INITIATE, SocialAction.SILENT, SocialAction.DEFER}


def test_repeated_topic_is_damped():
    e = NPCLivedExperienceEngine()
    first = e.evaluate(npc(sociability=.95, social_energy=.95), ctx(turn=1), topic())
    second = e.evaluate(npc(sociability=.95, social_energy=.95), ctx(turn=2), topic())
    assert first.action == SocialAction.INITIATE
    assert second.action != SocialAction.INITIATE


def test_reunion_is_acknowledged_for_familiar_npc():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(npc(familiarity=.8), ctx(reunion_after_absence=True), topic())
    assert any("Wiedersehen" in c for c in r.visible_cues)


def test_player_details_and_promises_persist():
    e = NPCLivedExperienceEngine()
    e.remember_player_detail("n1", "drink", "schwarzer Kaffee")
    e.add_promise("n1", "part", "nach einem Ersatzteil sehen")
    snap = e.snapshot_for_save()
    e2 = NPCLivedExperienceEngine.from_save(snap)
    st = e2.state_for("n1")
    assert st.remembered_player_details["drink"] == "schwarzer Kaffee"
    assert "part" in st.pending_promises


def test_pain_and_stress_show_in_behavior_not_stat_dump():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(npc(pain=.8, stress=.8), ctx(explicit_player_question=True), topic())
    joined = " ".join(r.visible_cues)
    assert "schont" in joined or "angespannter" in joined
    assert "0.8" not in joined


def test_disliked_topic_reduces_unsolicited_initiative():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(npc(dislikes=("tech",), sociability=.4, curiosity=.3), ctx(conversation_open=False), topic())
    assert r.action != SocialAction.INITIATE

def test_lived_experience_persists_through_adaptive_runtime():
    from runtime.player_progression.model import PlayerProgressionState
    from runtime.player_progression.pipeline import PlayerLearningRuntime
    from runtime.player_progression.adaptive_runtime import AdaptiveGameplayRuntime
    state = PlayerProgressionState(player_uuid="p", run_uuid="r", start_class="OPERATOR")
    rt = AdaptiveGameplayRuntime.new(PlayerLearningRuntime(state))
    rt.npc_lived_experience.remember_player_detail("n1", "habit", "prüft immer den Ausgang")
    snap = rt.snapshot_for_save()
    rt2 = AdaptiveGameplayRuntime.from_save(snap)
    assert rt2.npc_lived_experience.state_for("n1").remembered_player_details["habit"] == "prüft immer den Ausgang"


def test_internal_computer_requires_authorization_even_when_npc_is_friendly():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(
        npc(trust=.95, familiarity=.9, openness=.9),
        ctx(explicit_player_question=True),
        topic(key="terminal", label="internen Rechner benutzen", security_sensitive=True,
              requires_authorization=True, authorization_present=False),
    )
    assert r.action == SocialAction.DECLINE
    assert r.reason == "authorization_required"


def test_authorized_internal_access_can_proceed_to_normal_social_logic():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(
        npc(), ctx(explicit_player_question=True),
        topic(key="terminal", label="autorisierten Rechnerzugriff", security_sensitive=True,
              requires_authorization=True, authorization_present=True),
    )
    assert r.action in {SocialAction.ENGAGE, SocialAction.BRIEF}


def test_high_self_risk_is_declined_before_friendliness():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(
        npc(trust=1.0, familiarity=1.0), ctx(explicit_player_question=True),
        topic(key="dangerous_favor", label="gefährlicher Gefallen", physical_risk=.85),
    )
    assert r.action == SocialAction.DECLINE
    assert r.reason == "self_protection_boundary"


def test_out_of_role_risky_request_is_declined():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(
        npc(), ctx(explicit_player_question=True),
        topic(key="records", label="fremde Akten herausgeben", role_appropriate=False,
              professional_risk=.55),
    )
    assert r.action == SocialAction.DECLINE
    assert r.reason == "role_and_self_protection_boundary"


def test_normal_service_request_stays_cooperative():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(
        npc(), ctx(explicit_player_question=True),
        topic(key="parcel", label="Paket abholen", role_appropriate=True),
    )
    assert r.action in {SocialAction.ENGAGE, SocialAction.BRIEF}


def test_market_bargaining_is_not_blocked_by_self_protection_gate():
    e = NPCLivedExperienceEngine()
    r = e.evaluate(
        npc(), ctx(explicit_player_question=True),
        topic(key="haggle", label="Preis verhandeln", tags=("trade",),
              role_appropriate=True, economic_risk=.15),
    )
    assert r.action in {SocialAction.ENGAGE, SocialAction.BRIEF}
