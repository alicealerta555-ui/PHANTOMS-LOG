import unittest
from dataclasses import fields, replace

from runtime.stage4b import (
    EnvironmentalEnvelope, GenelineRecord, HybridizationProfile, KnownBiologicalConstraint,
    LineageProvenance, MetabolismProfile, MorphologyProfile, OriginPackageLink,
    RegenerationProfile, StabilityProfile, STAGE5_DETAIL_FIELDS, STAGE6_DETAIL_FIELDS,
)
from runtime.stage4c import bind_origin_packages, build_canonical_origin_registry
from runtime.stage4e import (
    BranchClass, BranchProfile, BranchProfileRegistry, BranchProvenance,
    CognitiveAssessment, CognitiveBranch, DevelopmentalBranchEvidence,
    classify_branch, validate_branch_profile,
)


def base_lineage(lineage_id="TEST_4E", phase="B6", epoch="E5"):
    return GenelineRecord(
        lineage_id=lineage_id,
        display_name="Stage 4E fixture",
        origin_packages=OriginPackageLink(),
        morphology=MorphologyProfile(("bilateral",), ("terrestrial",), ("fixture",)),
        metabolism=MetabolismProfile(("heterotrophic",), energetic_cost_tags=("finite",)),
        environment=EnvironmentalEnvelope(("temperate",)),
        regeneration=RegenerationProfile("NONE"),
        sensor_hooks=(),
        stability=StabilityProfile(),
        hybridization=HybridizationProfile((), 0),
        known_constraints=(KnownBiologicalConstraint("C4E", "fixture", "Finite biological resources."),),
        provenance=LineageProvenance(phase, epoch, ("STAGE4E_TEST",)),
    )


def bound_lineage(package_refs=("ORG_MAMMALIAN_HOMEOSTASIS",), lineage_id="TEST_4E", phase="B6", epoch="E5"):
    registry = build_canonical_origin_registry()
    return bind_origin_packages(base_lineage(lineage_id, phase, epoch), tuple(package_refs), registry), registry


def profile(lineage, cognitive=CognitiveBranch.UNASSESSED, cognitive_refs=(), scope="", feral=(), synthetic=(), drift=()):
    return BranchProfile(
        lineage_id=lineage.lineage_id,
        cognitive=CognitiveAssessment(cognitive, tuple(cognitive_refs), scope),
        developmental=DevelopmentalBranchEvidence(tuple(feral), tuple(synthetic), tuple(drift)),
        provenance=BranchProvenance(("STAGE4E_TEST",)),
    )


class Stage4EBranchClassTests(unittest.TestCase):
    def test_branch_class_set_is_exact(self):
        self.assertEqual(set(BranchClass), {BranchClass.SAPIENT, BranchClass.SEMI_SAPIENT, BranchClass.FERAL, BranchClass.SYNTHETIC, BranchClass.DRIFT})

    def test_sapient_requires_explicit_evidence(self):
        lineage, registry = bound_lineage()
        result = classify_branch(lineage, profile(lineage, CognitiveBranch.SAPIENT, ("OBS_SYMBOLIC",), "population-level longitudinal evidence"), registry)
        self.assertEqual(result.branch_classes, (BranchClass.SAPIENT,))

    def test_semi_sapient_requires_explicit_evidence(self):
        lineage, registry = bound_lineage()
        result = classify_branch(lineage, profile(lineage, CognitiveBranch.SEMI_SAPIENT, ("OBS_FLEXIBLE_PLAN",), "population-level longitudinal evidence"), registry)
        self.assertEqual(result.branch_classes, (BranchClass.SEMI_SAPIENT,))

    def test_unassessed_cognition_emits_no_cognitive_class(self):
        lineage, registry = bound_lineage()
        result = classify_branch(lineage, profile(lineage), registry)
        self.assertEqual(result.branch_classes, ())
        self.assertEqual(result.cognitive_branch, CognitiveBranch.UNASSESSED)

    def test_sapient_without_evidence_fails_closed(self):
        lineage, registry = bound_lineage()
        with self.assertRaisesRegex(ValueError, "COGNITIVE_CLASS_REQUIRES_EVIDENCE"):
            classify_branch(lineage, profile(lineage, CognitiveBranch.SAPIENT, (), "scope"), registry)

    def test_assessed_cognition_requires_scope(self):
        lineage, registry = bound_lineage()
        with self.assertRaisesRegex(ValueError, "COGNITIVE_ASSESSMENT_SCOPE_REQUIRED"):
            classify_branch(lineage, profile(lineage, CognitiveBranch.SAPIENT, ("OBS",), ""), registry)

    def test_unassessed_with_evidence_fails(self):
        lineage, registry = bound_lineage()
        with self.assertRaisesRegex(ValueError, "COGNITIVE_UNASSESSED_WITH_EVIDENCE"):
            classify_branch(lineage, profile(lineage, CognitiveBranch.UNASSESSED, ("OBS",)), registry)

    def test_feral_can_coexist_with_sapience(self):
        lineage, registry = bound_lineage()
        result = classify_branch(lineage, profile(lineage, CognitiveBranch.SAPIENT, ("OBS",), "longitudinal", feral=("DEV_UNMANAGED",)), registry)
        self.assertEqual(result.branch_classes, (BranchClass.SAPIENT, BranchClass.FERAL))
        self.assertTrue(result.is_feral)

    def test_feral_does_not_imply_any_cognitive_class(self):
        lineage, registry = bound_lineage()
        result = classify_branch(lineage, profile(lineage, feral=("DEV_UNMANAGED",)), registry)
        self.assertEqual(result.branch_classes, (BranchClass.FERAL,))
        self.assertEqual(result.cognitive_branch, CognitiveBranch.UNASSESSED)

    def test_feral_branch_cannot_be_backdated_to_directed_hybridization(self):
        lineage, registry = bound_lineage(phase="B2", epoch="E2")
        with self.assertRaisesRegex(ValueError, "FERAL_BRANCH_BACKDATED"):
            classify_branch(lineage, profile(lineage, feral=("FERAL",)), registry)

    def test_synthetic_is_orthogonal_to_sapience(self):
        lineage, registry = bound_lineage(("ORG_SYNTHETIC_BIOLOGY_PLATFORM",))
        result = classify_branch(lineage, profile(lineage, CognitiveBranch.SAPIENT, ("OBS",), "longitudinal", synthetic=("SYN_SOURCE",)), registry)
        self.assertEqual(result.branch_classes, (BranchClass.SAPIENT, BranchClass.SYNTHETIC))

    def test_synthetic_branch_requires_synthetic_origin(self):
        lineage, registry = bound_lineage()
        with self.assertRaisesRegex(ValueError, "SYNTHETIC_BRANCH_WITHOUT_SYNTHETIC_ORIGIN"):
            classify_branch(lineage, profile(lineage, synthetic=("SYN_SOURCE",)), registry)

    def test_synthetic_origin_does_not_force_synthetic_branch_without_evidence(self):
        lineage, registry = bound_lineage(("ORG_SYNTHETIC_BIOLOGY_PLATFORM",))
        result = classify_branch(lineage, profile(lineage), registry)
        self.assertNotIn(BranchClass.SYNTHETIC, result.branch_classes)

    def test_drift_is_orthogonal_to_cognition(self):
        lineage, registry = bound_lineage()
        result = classify_branch(lineage, profile(lineage, drift=("DRIFT_HISTORY",)), registry)
        self.assertEqual(result.branch_classes, (BranchClass.DRIFT,))
        self.assertEqual(result.cognitive_branch, CognitiveBranch.UNASSESSED)

    def test_drift_cannot_be_backdated_before_free_drift(self):
        lineage, registry = bound_lineage(phase="B4", epoch="E4")
        with self.assertRaisesRegex(ValueError, "DRIFT_BRANCH_BACKDATED"):
            classify_branch(lineage, profile(lineage, drift=("DRIFT_HISTORY",)), registry)

    def test_sapient_feral_drift_combination_preserves_all_axes(self):
        lineage, registry = bound_lineage()
        result = classify_branch(lineage, profile(lineage, CognitiveBranch.SAPIENT, ("OBS",), "longitudinal", feral=("FERAL",), drift=("DRIFT",)), registry)
        self.assertEqual(result.branch_classes, (BranchClass.SAPIENT, BranchClass.FERAL, BranchClass.DRIFT))

    def test_semi_sapient_synthetic_drift_combination(self):
        lineage, registry = bound_lineage(("ORG_SYNTHETIC_BIOLOGY_PLATFORM",))
        result = classify_branch(lineage, profile(lineage, CognitiveBranch.SEMI_SAPIENT, ("OBS",), "longitudinal", synthetic=("SYN",), drift=("DRIFT",)), registry)
        self.assertEqual(result.branch_classes, (BranchClass.SEMI_SAPIENT, BranchClass.SYNTHETIC, BranchClass.DRIFT))

    def test_branch_order_is_canonical_not_input_order(self):
        lineage, registry = bound_lineage(("ORG_SYNTHETIC_BIOLOGY_PLATFORM",))
        result = classify_branch(lineage, profile(lineage, CognitiveBranch.SAPIENT, ("Z", "A"), "scope", feral=("F",), synthetic=("S",), drift=("D",)), registry)
        self.assertEqual(result.branch_classes, (BranchClass.SAPIENT, BranchClass.FERAL, BranchClass.SYNTHETIC, BranchClass.DRIFT))

    def test_duplicate_cognitive_evidence_rejected(self):
        lineage, registry = bound_lineage()
        with self.assertRaisesRegex(ValueError, "COGNITIVE_EVIDENCE_DUPLICATE_REF"):
            validate_branch_profile(lineage, profile(lineage, CognitiveBranch.SAPIENT, ("A", "A"), "scope"), registry)

    def test_duplicate_developmental_evidence_rejected(self):
        lineage, registry = bound_lineage()
        with self.assertRaisesRegex(ValueError, "FERAL_EVIDENCE_DUPLICATE_REF"):
            validate_branch_profile(lineage, profile(lineage, feral=("A", "A")), registry)

    def test_wrong_authority_domain_rejected(self):
        lineage, registry = bound_lineage()
        p = replace(profile(lineage), provenance=BranchProvenance(("SRC",), "ACTOR_KNOWLEDGE"))
        with self.assertRaisesRegex(ValueError, "BRANCH_PROVENANCE_MUST_BE_WORLD_TRUTH"):
            validate_branch_profile(lineage, p, registry)

    def test_empty_provenance_rejected(self):
        lineage, registry = bound_lineage()
        p = replace(profile(lineage), provenance=BranchProvenance(()))
        with self.assertRaisesRegex(ValueError, "BRANCH_PROVENANCE_SOURCE_REQUIRED"):
            validate_branch_profile(lineage, p, registry)

    def test_lineage_mismatch_rejected(self):
        lineage, registry = bound_lineage()
        p = replace(profile(lineage), lineage_id="OTHER")
        with self.assertRaisesRegex(ValueError, "BRANCH_PROFILE_LINEAGE_MISMATCH"):
            validate_branch_profile(lineage, p, registry)

    def test_registry_rejects_duplicate_lineage(self):
        lineage, registry = bound_lineage()
        breg = BranchProfileRegistry(); breg.register(lineage, profile(lineage), registry)
        with self.assertRaisesRegex(ValueError, "BRANCH_PROFILE_DUPLICATE_LINEAGE"):
            breg.register(lineage, profile(lineage), registry)

    def test_registry_digest_is_registration_order_independent(self):
        a, registry = bound_lineage(lineage_id="A")
        b, _ = bound_lineage(lineage_id="B")
        ra = BranchProfileRegistry(); ra.register(a, profile(a, CognitiveBranch.SAPIENT, ("A_OBS",), "scope"), registry); ra.register(b, profile(b, drift=("B_DRIFT",)), registry)
        rb = BranchProfileRegistry(); rb.register(b, profile(b, drift=("B_DRIFT",)), registry); rb.register(a, profile(a, CognitiveBranch.SAPIENT, ("A_OBS",), "scope"), registry)
        self.assertEqual(ra.canonical_digest(), rb.canonical_digest())

    def test_branch_classification_does_not_mutate_geneline_phenotype(self):
        lineage, registry = bound_lineage()
        before = (lineage.morphology, lineage.metabolism, lineage.environment, lineage.regeneration)
        classify_branch(lineage, profile(lineage, CognitiveBranch.SAPIENT, ("OBS",), "scope", feral=("FERAL",), drift=("DRIFT",)), registry)
        self.assertEqual(before, (lineage.morphology, lineage.metabolism, lineage.environment, lineage.regeneration))

    def test_morphology_does_not_infer_cognition(self):
        lineage, registry = bound_lineage()
        lineage = replace(lineage, morphology=MorphologyProfile(("humanoid",), ("bipedal",), ("tool_capable_hands",)))
        result = classify_branch(lineage, profile(lineage), registry)
        self.assertEqual(result.cognitive_branch, CognitiveBranch.UNASSESSED)

    def test_feral_minimal_pair_changes_only_feral_axis(self):
        lineage, registry = bound_lineage()
        plain = classify_branch(lineage, profile(lineage, CognitiveBranch.SAPIENT, ("OBS",), "scope"), registry)
        feral = classify_branch(lineage, profile(lineage, CognitiveBranch.SAPIENT, ("OBS",), "scope", feral=("FERAL",)), registry)
        self.assertEqual(plain.cognitive_branch, feral.cognitive_branch)
        self.assertFalse(plain.is_feral); self.assertTrue(feral.is_feral)

    def test_drift_minimal_pair_changes_only_drift_axis(self):
        lineage, registry = bound_lineage()
        plain = classify_branch(lineage, profile(lineage, CognitiveBranch.SEMI_SAPIENT, ("OBS",), "scope"), registry)
        drift = classify_branch(lineage, profile(lineage, CognitiveBranch.SEMI_SAPIENT, ("OBS",), "scope", drift=("DRIFT",)), registry)
        self.assertEqual(plain.cognitive_branch, drift.cognitive_branch)
        self.assertFalse(plain.is_drift); self.assertTrue(drift.is_drift)

    def test_schema_has_no_behavior_or_stage5_6_detail_fields(self):
        names = {f.name for f in fields(BranchProfile)} | {f.name for f in fields(CognitiveAssessment)} | {f.name for f in fields(DevelopmentalBranchEvidence)}
        forbidden_behavior = {"morality", "personality", "consent", "dominance", "submission", "attraction", "profession", "loyalty", "obedience", "hostility"}
        self.assertFalse(names & forbidden_behavior)
        self.assertFalse(names & (set(STAGE5_DETAIL_FIELDS) | set(STAGE6_DETAIL_FIELDS)))


if __name__ == "__main__":
    unittest.main()
