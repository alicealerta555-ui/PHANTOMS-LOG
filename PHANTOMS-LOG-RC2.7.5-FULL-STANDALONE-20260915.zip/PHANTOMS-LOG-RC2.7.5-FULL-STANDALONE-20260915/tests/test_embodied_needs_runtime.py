from pathlib import Path
import tempfile
from playable.game import FullVersionGame
from runtime.full_version.embodied_needs import EmbodiedNeedsRuntime
from runtime.full_version.bootstrap import PLAYER_ACTOR_INSTANCE_ID

def game():
    td=tempfile.TemporaryDirectory(); core=Path(__file__).resolve().parents[1]
    g=FullVersionGame(core_root=core,saves_root=Path(td.name),start_class="OPERATOR")
    g.complete_character(g.creation_template()); g._tmp=td; return g

def test_safe_routine_is_forgiving():
    g=game(); a=PLAYER_ACTOR_INSTANCE_ID
    before=g.embodied_needs.actor_packet(a)["needs"]["hydration"]["pressure_ppm"]
    g.embodied_needs.advance(3600,activity="light",climate="temperate",situation="safe_settlement",actor_ids=[a])
    after=g.embodied_needs.actor_packet(a)["needs"]["hydration"]["pressure_ppm"]
    assert 0 < after-before < 17000

def test_heat_and_exertion_scale_dynamically():
    g1=game(); a=PLAYER_ACTOR_INSTANCE_ID
    b=g1.embodied_needs.actor_packet(a)["needs"]["hydration"]["pressure_ppm"]
    g1.embodied_needs.advance(3600,activity="strenuous",climate="extreme_heat",situation="danger",actor_ids=[a])
    d=g1.embodied_needs.actor_packet(a)["needs"]["hydration"]["pressure_ppm"]-b
    assert d > 50000

def test_recovery_feels_meaningful_not_constant_snacking():
    g=game(); a=PLAYER_ACTOR_INSTANCE_ID
    g.embodied_needs.advance(8*3600,activity="work",climate="hot",actor_ids=[a])
    before=g.embodied_needs.actor_packet(a)["needs"]["hydration"]["pressure_ppm"]
    g.embodied_needs.recover(a,"drink")
    assert g.embodied_needs.actor_packet(a)["needs"]["hydration"]["pressure_ppm"] < before

def test_player_facing_status_uses_bands_not_numbers():
    g=game(); text=g.body_status()
    assert "ppm" not in text.lower() and "Flüssigkeit:" in text

def test_npc_and_player_share_authoritative_physiology_runtime():
    g=game()
    npc=next(x.actor_instance_id for x in g.actor_registry.instances() if x.actor_instance_id.startswith("actor:npc:"))
    packet=g.embodied_needs.actor_packet(npc)
    assert packet["needs"]["hydration"]["pressure_ppm"]>0
    assert packet["needs"]["nutrition"]["pressure_ppm"]>0

def test_no_level_scaling_in_tables():
    g=game()
    raw=(g.core_root/"content/full_version/embodied_needs_tables.json").read_text()
    assert "level_multiplier" not in raw and "NO_LEVEL_SCALING" in raw
