import tempfile
import unittest
from uuid import uuid4

from runtime.stage3a.integration import RuntimeAuthorityBridge, RuntimeDelta
from runtime.stage3a.kernel import (
    Authority, CommitKernel, CommitRecord, Domain, StateStore, UnresolvedSpec,
    ValidationResult, Verdict, WeightedOption,
)
from runtime.stage3b.pipeline import (
    ActionRequest, ActionRule, ActionStatus, Condition, FactRef, Operator,
    OutcomeBranch, ValueSource,
)
from runtime.stage3c.isolation import FilesystemRunRepository, RunSessionManager
from runtime.stage3e.circumstance import (
    PPM, CircumstanceCandidate, CircumstanceEffect, CircumstanceEngine,
    CircumstanceSpec, GroundTruthResolver, Stage3EError, StateCondition, StateOp,
)


def engine_with_seed(seed=77, specs=()):
    store = StateStore()
    kernel = CommitKernel(store, world_seed=seed)
    bridge = RuntimeAuthorityBridge(kernel)
    return store, kernel, bridge, CircumstanceEngine(bridge, run_seed=seed, specs=specs)


def runtime_set(bridge, event_id, key, value):
    return bridge.commit_runtime_event(
        event_id=event_id, cause="test-runtime-set",
        deltas=(RuntimeDelta("RUNTIME_STATE", key, value, "RULE_KERNEL", "test-runtime-set"),),
    )


def world_set(bridge, event_id, key, value):
    return bridge.commit_runtime_event(
        event_id=event_id, cause="test-world-set",
        deltas=(RuntimeDelta("WORLD_TRUTH", key, value, "RULE_KERNEL", "test-world-set"),),
    )


def basic_runtime_spec(cid="ambient", *, activation_ppm=PPM, candidates=None, anti_pattern=True):
    if candidates is None:
        candidates = (
            CircumstanceCandidate(
                "noise", 1,
                effects=(CircumstanceEffect(Domain.RUNTIME_STATE, "ambient.noise", "bang", "external-noise"),),
                intrinsic_interest_ppm=PPM,
                pattern_group="sound",
            ),
        )
    return CircumstanceSpec(
        cid, tuple(candidates), activation_ppm=activation_ppm,
        min_interest_ppm=1, anti_pattern=anti_pattern,
    )


class Stage3ETests(unittest.TestCase):
    def test_query_trigger_is_no_commit_before_resolution(self):
        store = StateStore()
        kernel = CommitKernel(store, world_seed=44)
        bridge = RuntimeAuthorityBridge(kernel)
        kernel.register_unresolved(UnresolvedSpec(
            "vault.occupied", (WeightedOption(True, 2), WeightedOption(False, 3)), seed_salt="v"
        ))
        resolver = GroundTruthResolver(bridge)
        before_rev = store.revision
        result = resolver.resolve_triggered_by_query(
            "vault.occupied", query_text="Ist dort bestimmt jemand?", player_suggestion=True,
            event_id="RES-Q1",
        )
        self.assertTrue(result.state_unchanged_by_query)
        self.assertEqual(result.query_verdict, Verdict.HOLD)
        self.assertIsInstance(result.resolution, CommitRecord)
        self.assertEqual(store.revision, before_rev + 1)
        self.assertIn("vault.occupied", store.world_truth)

    def test_query_suggestion_does_not_bias_resolution(self):
        outcomes = []
        for suggestion, text in ((True, "Da ist doch jemand?"), (False, "Da ist sicher niemand."), ("x", "Was ist dort?")):
            store = StateStore()
            kernel = CommitKernel(store, world_seed=991)
            bridge = RuntimeAuthorityBridge(kernel)
            kernel.register_unresolved(UnresolvedSpec(
                "room.enemy", (WeightedOption(True, 1), WeightedOption(False, 1)), seed_salt="same"
            ))
            resolver = GroundTruthResolver(bridge)
            resolver.resolve_triggered_by_query(
                "room.enemy", query_text=text, player_suggestion=suggestion, event_id="RES-SAME"
            )
            outcomes.append(store.world_truth["room.enemy"])
        self.assertEqual(len(set(outcomes)), 1)

    def test_resolved_truth_is_never_rerolled(self):
        store = StateStore()
        kernel = CommitKernel(store, world_seed=1)
        bridge = RuntimeAuthorityBridge(kernel)
        kernel.register_unresolved(UnresolvedSpec("x", (WeightedOption("a", 1), WeightedOption("b", 1))))
        resolver = GroundTruthResolver(bridge)
        first = resolver.resolve_unknown("x", event_id="R1")
        self.assertIsInstance(first, CommitRecord)
        value = store.world_truth["x"]
        second = resolver.resolve_unknown("x", event_id="R2")
        self.assertIsInstance(second, ValidationResult)
        self.assertEqual(second.verdict, Verdict.HOLD)
        self.assertIn("ALREADY_RESOLVED_NO_REROLL", second.reasons)
        self.assertEqual(store.world_truth["x"], value)

    def test_unknown_ground_truth_key_fails_closed(self):
        store = StateStore()
        bridge = RuntimeAuthorityBridge(CommitKernel(store, world_seed=1))
        result = GroundTruthResolver(bridge).resolve_unknown("missing", event_id="R")
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)

    def test_world_effect_requires_declared_mutable_key(self):
        candidate = CircumstanceCandidate(
            "weather", 1,
            effects=(CircumstanceEffect(Domain.WORLD_TRUTH, "weather", "rain", "front", expected_current="clear", require_current_match=True),),
            intrinsic_interest_ppm=PPM,
        )
        with self.assertRaises(Stage3EError):
            CircumstanceSpec("wx", (candidate,)).validate()

    def test_world_effect_requires_expected_current(self):
        candidate = CircumstanceCandidate(
            "weather", 1,
            effects=(CircumstanceEffect(Domain.WORLD_TRUTH, "weather", "rain", "front"),),
            intrinsic_interest_ppm=PPM,
        )
        with self.assertRaises(Stage3EError):
            CircumstanceSpec("wx", (candidate,), mutable_world_keys=("weather",)).validate()

    def test_known_mutable_world_state_can_change_causally(self):
        candidate = CircumstanceCandidate(
            "storm", 1,
            effects=(CircumstanceEffect(
                Domain.WORLD_TRUTH, "weather", "storm", "weather-front",
                expected_current="clear", require_current_match=True,
            ),),
            plausibility=(StateCondition(Domain.WORLD_TRUTH, "season", StateOp.EQ, "storm-season"),),
            intrinsic_interest_ppm=PPM,
        )
        spec = CircumstanceSpec("weather-shift", (candidate,), mutable_world_keys=("weather",))
        store, _, bridge, engine = engine_with_seed(specs=(spec,))
        world_set(bridge, "W1", "weather", "clear")
        world_set(bridge, "W2", "season", "storm-season")
        decision = engine.trigger(circumstance_id="weather-shift", trigger_event_id="T1")
        self.assertEqual(decision.verdict, Verdict.PASS)
        self.assertEqual(decision.candidate_id, "storm")
        self.assertEqual(store.world_truth["weather"], "storm")

    def test_absent_world_truth_is_not_invented_by_circumstance(self):
        candidate = CircumstanceCandidate(
            "storm", 1,
            effects=(CircumstanceEffect(
                Domain.WORLD_TRUTH, "weather", "storm", "weather-front",
                expected_current="clear", require_current_match=True,
            ),),
            intrinsic_interest_ppm=PPM,
        )
        spec = CircumstanceSpec("weather-shift", (candidate,), mutable_world_keys=("weather",))
        store, _, _, engine = engine_with_seed(specs=(spec,))
        decision = engine.trigger(circumstance_id="weather-shift", trigger_event_id="T1")
        self.assertEqual(decision.verdict, Verdict.PASS)
        self.assertIsNone(decision.candidate_id)
        self.assertNotIn("weather", store.world_truth)

    def test_plausibility_guard_blocks_candidate(self):
        candidate = CircumstanceCandidate(
            "rain", 1,
            effects=(CircumstanceEffect(Domain.RUNTIME_STATE, "rain", True, "rain"),),
            plausibility=(StateCondition(Domain.RUNTIME_STATE, "outdoors", StateOp.EQ, True),),
            intrinsic_interest_ppm=PPM,
        )
        spec = basic_runtime_spec("p", candidates=(candidate,))
        store, _, _, engine = engine_with_seed(specs=(spec,))
        d = engine.trigger(circumstance_id="p", trigger_event_id="T")
        self.assertIsNone(d.candidate_id)
        self.assertNotIn("rain", store.runtime_state)
        self.assertEqual(store.runtime_state["__circumstance:sequence:p"], 1)

    def test_integrity_guard_blocks_candidate(self):
        candidate = CircumstanceCandidate(
            "alarm", 1,
            effects=(CircumstanceEffect(Domain.RUNTIME_STATE, "alarm", True, "alarm"),),
            integrity=(StateCondition(Domain.RUNTIME_STATE, "system.intact", StateOp.EQ, True),),
            intrinsic_interest_ppm=PPM,
        )
        spec = basic_runtime_spec("i", candidates=(candidate,))
        store, _, bridge, engine = engine_with_seed(specs=(spec,))
        runtime_set(bridge, "INIT", "system.intact", False)
        d = engine.trigger(circumstance_id="i", trigger_event_id="T")
        self.assertIsNone(d.candidate_id)
        self.assertNotIn("alarm", store.runtime_state)

    def test_interest_guard_blocks_noise_without_interest(self):
        candidate = CircumstanceCandidate(
            "noise", 1,
            effects=(CircumstanceEffect(Domain.RUNTIME_STATE, "noise", True, "noise"),),
            interest=(StateCondition(Domain.RUNTIME_STATE, "attention.relevant", StateOp.EQ, True),),
            intrinsic_interest_ppm=0,
        )
        spec = CircumstanceSpec("interest", (candidate,), min_interest_ppm=100)
        store, _, bridge, engine = engine_with_seed(specs=(spec,))
        runtime_set(bridge, "I", "attention.relevant", False)
        d = engine.trigger(circumstance_id="interest", trigger_event_id="T")
        self.assertIsNone(d.candidate_id)
        self.assertNotIn("noise", store.runtime_state)

    def test_live_interest_signal_allows_candidate(self):
        candidate = CircumstanceCandidate(
            "noise", 1,
            effects=(CircumstanceEffect(Domain.RUNTIME_STATE, "noise", True, "noise"),),
            interest=(StateCondition(Domain.RUNTIME_STATE, "attention.relevant", StateOp.EQ, True),),
            intrinsic_interest_ppm=0,
        )
        spec = CircumstanceSpec("interest", (candidate,), min_interest_ppm=100)
        store, _, bridge, engine = engine_with_seed(specs=(spec,))
        runtime_set(bridge, "I", "attention.relevant", True)
        d = engine.trigger(circumstance_id="interest", trigger_event_id="T")
        self.assertEqual(d.candidate_id, "noise")
        self.assertTrue(store.runtime_state["noise"])

    def test_activation_zero_records_check_without_external_event(self):
        spec = basic_runtime_spec("never", activation_ppm=0)
        store, _, _, engine = engine_with_seed(specs=(spec,))
        d = engine.trigger(circumstance_id="never", trigger_event_id="T")
        self.assertEqual(d.verdict, Verdict.PASS)
        self.assertIsNone(d.candidate_id)
        self.assertNotIn("ambient.noise", store.runtime_state)
        self.assertEqual(store.runtime_state["__circumstance:sequence:never"], 1)

    def test_same_trigger_is_idempotent_and_does_not_advance_sequence_twice(self):
        spec = basic_runtime_spec("idem")
        store, _, _, engine = engine_with_seed(specs=(spec,))
        d1 = engine.trigger(circumstance_id="idem", trigger_event_id="T")
        seq = store.runtime_state["__circumstance:sequence:idem"]
        rev = store.revision
        d2 = engine.trigger(circumstance_id="idem", trigger_event_id="T")
        self.assertEqual(d1.event_id, d2.event_id)
        self.assertEqual(store.runtime_state["__circumstance:sequence:idem"], seq)
        self.assertEqual(store.revision, rev)
        self.assertIn("IDEMPOTENT", d2.reasons[0])

    def test_anti_pattern_prefers_other_valid_group(self):
        a = CircumstanceCandidate(
            "a", 1, (CircumstanceEffect(Domain.RUNTIME_STATE, "picked", "a", "a"),),
            intrinsic_interest_ppm=PPM, pattern_group="A",
        )
        b = CircumstanceCandidate(
            "b", 1, (CircumstanceEffect(Domain.RUNTIME_STATE, "picked", "b", "b"),),
            intrinsic_interest_ppm=PPM, pattern_group="B",
        )
        spec = basic_runtime_spec("anti", candidates=(a, b), anti_pattern=True)
        store, _, _, engine = engine_with_seed(seed=2, specs=(spec,))
        d1 = engine.trigger(circumstance_id="anti", trigger_event_id="T1")
        d2 = engine.trigger(circumstance_id="anti", trigger_event_id="T2")
        self.assertIsNotNone(d1.candidate_id)
        self.assertIsNotNone(d2.candidate_id)
        self.assertNotEqual(d1.candidate_id, d2.candidate_id)
        self.assertEqual(store.runtime_state["picked"], d2.candidate_id)

    def test_anti_pattern_does_not_force_implausible_alternative(self):
        a = CircumstanceCandidate(
            "a", 1, (CircumstanceEffect(Domain.RUNTIME_STATE, "picked", "a", "a"),),
            intrinsic_interest_ppm=PPM, pattern_group="A",
        )
        b = CircumstanceCandidate(
            "b", 1, (CircumstanceEffect(Domain.RUNTIME_STATE, "picked", "b", "b"),),
            plausibility=(StateCondition(Domain.RUNTIME_STATE, "never", StateOp.EQ, True),),
            intrinsic_interest_ppm=PPM, pattern_group="B",
        )
        spec = basic_runtime_spec("anti2", candidates=(a, b), anti_pattern=True)
        _, _, _, engine = engine_with_seed(seed=2, specs=(spec,))
        d1 = engine.trigger(circumstance_id="anti2", trigger_event_id="T1")
        d2 = engine.trigger(circumstance_id="anti2", trigger_event_id="T2")
        self.assertEqual(d1.candidate_id, "a")
        self.assertEqual(d2.candidate_id, "a")

    def test_cooldown_prevents_immediate_repeat(self):
        a = CircumstanceCandidate(
            "a", 1, (CircumstanceEffect(Domain.RUNTIME_STATE, "picked", "a", "a"),),
            intrinsic_interest_ppm=PPM, cooldown_checks=2,
        )
        spec = basic_runtime_spec("cool", candidates=(a,), anti_pattern=False)
        _, _, _, engine = engine_with_seed(specs=(spec,))
        d1 = engine.trigger(circumstance_id="cool", trigger_event_id="T1")
        d2 = engine.trigger(circumstance_id="cool", trigger_event_id="T2")
        self.assertEqual(d1.candidate_id, "a")
        self.assertIsNone(d2.candidate_id)

    def test_circumstance_cannot_write_knowledge_domains(self):
        bad = CircumstanceCandidate(
            "bad", 1,
            (CircumstanceEffect(Domain.ACTOR_KNOWLEDGE, "secret", 1, "bad"),),
            intrinsic_interest_ppm=PPM,
        )
        with self.assertRaises(Stage3EError):
            basic_runtime_spec("bad", candidates=(bad,)).validate()

    def test_action_known_failed_precondition_does_not_trigger_circumstance(self):
        spec = basic_runtime_spec("action-c")
        manager = RunSessionManager(master_seed=5, circumstance_specs=(spec,))
        session = manager.create_run(player_uuid=str(uuid4()), run_uuid=str(uuid4()))
        runtime_set(session.bridge, "INIT", "door.ready", False)
        rule = ActionRule(
            "open",
            facts=(FactRef("ready", Domain.RUNTIME_STATE, "door.ready"),),
            preconditions=(Condition(ValueSource.FACT, "ready", Operator.EQ, True),),
            outcomes=(OutcomeBranch("ok"),),
            requires_circumstance=True,
            circumstance_id="action-c",
        )
        result = session.actions.execute(ActionRequest("A1", rule, player_text="open"))
        self.assertEqual(result.status, ActionStatus.BLOCKED)
        self.assertNotIn("__circumstance:sequence:action-c", session.store.runtime_state)

    def test_action_rechecks_facts_after_circumstance(self):
        candidate = CircumstanceCandidate(
            "jam", 1,
            (CircumstanceEffect(Domain.RUNTIME_STATE, "door.ready", False, "external-jam"),),
            intrinsic_interest_ppm=PPM,
        )
        spec = basic_runtime_spec("action-c", candidates=(candidate,))
        manager = RunSessionManager(master_seed=5, circumstance_specs=(spec,))
        session = manager.create_run(player_uuid=str(uuid4()), run_uuid=str(uuid4()))
        runtime_set(session.bridge, "INIT", "door.ready", True)
        rule = ActionRule(
            "open",
            facts=(FactRef("ready", Domain.RUNTIME_STATE, "door.ready"),),
            preconditions=(Condition(ValueSource.FACT, "ready", Operator.EQ, True),),
            outcomes=(OutcomeBranch("ok"),),
            requires_circumstance=True,
            circumstance_id="action-c",
        )
        result = session.actions.execute(ActionRequest("A1", rule, player_text="open"))
        self.assertEqual(result.status, ActionStatus.BLOCKED)
        self.assertIsNotNone(result.circumstance)
        self.assertEqual(result.circumstance.candidate_id, "jam")
        self.assertFalse(session.store.runtime_state["door.ready"])

    def test_action_player_suggestion_not_forwarded_to_ground_truth(self):
        values = []
        for suggestion in (True, False):
            store = StateStore()
            kernel = CommitKernel(store, world_seed=123)
            bridge = RuntimeAuthorityBridge(kernel)
            resolver = GroundTruthResolver(bridge)
            kernel.register_unresolved(UnresolvedSpec(
                "hidden", (WeightedOption("yes", 1), WeightedOption("no", 1)), seed_salt="s"
            ))
            from runtime.stage3b.pipeline import ActionPipeline
            pipe = ActionPipeline(bridge, ground_truth_provider=resolver)
            rule = ActionRule(
                "inspect",
                facts=(FactRef("hidden", Domain.WORLD_TRUTH, "hidden", resolve_if_unknown=True),),
                outcomes=(OutcomeBranch("ok"),),
            )
            result = pipe.execute(ActionRequest("A", rule, player_suggestion=suggestion))
            self.assertIn(result.status, {ActionStatus.RESOLVED_NO_CHANGE, ActionStatus.COMMITTED})
            values.append(store.world_truth["hidden"])
        self.assertEqual(values[0], values[1])

    def test_run_sessions_own_stage3e_services(self):
        spec = basic_runtime_spec("s")
        manager = RunSessionManager(master_seed=9, circumstance_specs=(spec,))
        a = manager.create_run(player_uuid=str(uuid4()), run_uuid=str(uuid4()))
        b = manager.create_run(player_uuid=str(uuid4()), run_uuid=str(uuid4()))
        self.assertIsNot(a.circumstances, b.circumstances)
        self.assertIsNot(a.ground_truth, b.ground_truth)
        a.circumstances.trigger(circumstance_id="s", trigger_event_id="T")
        self.assertIn("__circumstance:sequence:s", a.store.runtime_state)
        self.assertNotIn("__circumstance:sequence:s", b.store.runtime_state)

    def test_circumstance_state_survives_save_load(self):
        spec = basic_runtime_spec("persist")
        master_seed = 17
        manager = RunSessionManager(master_seed=master_seed, circumstance_specs=(spec,))
        identity_player = str(uuid4())
        identity_run = str(uuid4())
        session = manager.create_run(player_uuid=identity_player, run_uuid=identity_run)
        session.circumstances.trigger(circumstance_id="persist", trigger_event_id="T1")
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(td)
            repo.save(session)
            manager2 = RunSessionManager(master_seed=master_seed, circumstance_specs=(spec,))
            loaded = repo.load_session(manager2, session.identity)
            self.assertEqual(loaded.store.runtime_state["__circumstance:sequence:persist"], 1)
            loaded.circumstances.trigger(circumstance_id="persist", trigger_event_id="T2")
            self.assertEqual(loaded.store.runtime_state["__circumstance:sequence:persist"], 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
