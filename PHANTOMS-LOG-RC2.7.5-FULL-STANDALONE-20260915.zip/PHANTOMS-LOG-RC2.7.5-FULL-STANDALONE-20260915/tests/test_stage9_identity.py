from __future__ import annotations

import unittest
from uuid import uuid4

from runtime.stage3c.isolation import RunIdentity
from runtime.stage9.identity import RuntimeIdentity, Stage9IdentityError


class Stage9RuntimeIdentityTests(unittest.TestCase):
    def setUp(self) -> None:
        self.player_uuid = str(uuid4())
        self.run_uuid = str(uuid4())

    def test_requires_explicit_actor_instance_id(self):
        with self.assertRaisesRegex(Stage9IdentityError, "MISSING_ACTOR_INSTANCE_ID"):
            RuntimeIdentity(self.player_uuid, self.run_uuid, "")
        with self.assertRaisesRegex(Stage9IdentityError, "MISSING_ACTOR_INSTANCE_ID"):
            RuntimeIdentity(self.player_uuid, self.run_uuid, None)  # type: ignore[arg-type]

    def test_reuses_stage3c_uuid_validation(self):
        with self.assertRaisesRegex(Stage9IdentityError, "INVALID_PLAYER_UUID"):
            RuntimeIdentity("player-one", self.run_uuid, "actor:main")
        with self.assertRaisesRegex(Stage9IdentityError, "INVALID_RUN_UUID"):
            RuntimeIdentity(self.player_uuid, "run-one", "actor:main")

    def test_uuid_identity_is_canonicalized_without_changing_stage3c_contract(self):
        identity = RuntimeIdentity(
            self.player_uuid.upper(), self.run_uuid.upper(), "actor:main"
        )
        self.assertEqual(identity.player_uuid, self.player_uuid)
        self.assertEqual(identity.run_uuid, self.run_uuid)
        self.assertEqual(identity.run_identity, RunIdentity(self.player_uuid, self.run_uuid))

    def test_actor_instance_id_is_opaque_but_canonical(self):
        accepted = (
            "actor:main",
            "npc:1",
            "actor_0001",
            "550e8400-e29b-41d4-a716-446655440000",
            "drone.alpha-7",
        )
        for actor_instance_id in accepted:
            with self.subTest(actor_instance_id=actor_instance_id):
                identity = RuntimeIdentity(
                    self.player_uuid, self.run_uuid, actor_instance_id
                )
                self.assertEqual(identity.actor_instance_id, actor_instance_id)

    def test_actor_instance_id_rejects_implicit_or_unsafe_forms(self):
        rejected = (" actor:1", "actor:1 ", "actor one", "actor/one", "actor\\one", "@actor")
        for actor_instance_id in rejected:
            with self.subTest(actor_instance_id=actor_instance_id):
                with self.assertRaises(Stage9IdentityError):
                    RuntimeIdentity(self.player_uuid, self.run_uuid, actor_instance_id)

    def test_same_run_can_have_distinct_explicit_actor_identities(self):
        a = RuntimeIdentity(self.player_uuid, self.run_uuid, "actor:a")
        b = RuntimeIdentity(self.player_uuid, self.run_uuid, "actor:b")
        self.assertNotEqual(a, b)
        self.assertEqual(a.run_identity, b.run_identity)

    def test_from_run_identity_requires_real_run_identity(self):
        run_identity = RunIdentity(self.player_uuid, self.run_uuid)
        runtime_identity = RuntimeIdentity.from_run_identity(
            run_identity, actor_instance_id="actor:main"
        )
        self.assertEqual(runtime_identity.run_identity, run_identity)
        with self.assertRaisesRegex(Stage9IdentityError, "INVALID_RUN_IDENTITY"):
            RuntimeIdentity.from_run_identity(  # type: ignore[arg-type]
                {"player_uuid": self.player_uuid, "run_uuid": self.run_uuid},
                actor_instance_id="actor:main",
            )

    def test_mapping_requires_all_three_identity_fields_no_default(self):
        with self.assertRaisesRegex(
            Stage9IdentityError, "MISSING_RUNTIME_IDENTITY_FIELD:actor_instance_id"
        ):
            RuntimeIdentity.from_mapping(
                {"player_uuid": self.player_uuid, "run_uuid": self.run_uuid}
            )
        identity = RuntimeIdentity.from_mapping(
            {
                "player_uuid": self.player_uuid,
                "run_uuid": self.run_uuid,
                "actor_instance_id": "actor:main",
            }
        )
        self.assertEqual(
            identity.as_dict(),
            {
                "player_uuid": self.player_uuid,
                "run_uuid": self.run_uuid,
                "actor_instance_id": "actor:main",
            },
        )

    def test_identity_is_frozen_and_hashable(self):
        identity = RuntimeIdentity(self.player_uuid, self.run_uuid, "actor:main")
        self.assertIn(identity, {identity})
        with self.assertRaises((AttributeError, TypeError)):
            identity.actor_instance_id = "actor:other"  # type: ignore[misc]


if __name__ == "__main__":
    unittest.main(verbosity=2)
