from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from runtime.full_version import FullVersionCatalog, FullVersionBootstrap, FullVersionBootstrapError, PLAYER_ACTOR_INSTANCE_ID
from runtime.stage3a.kernel import Authority, Domain
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from playable_full_version.playable.game import FullVersionGame, FullVersionGameError

ROOT=Path(__file__).resolve().parents[1]


class FullVersionTransitionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog=FullVersionCatalog.load(ROOT)

    def test_full_world_content_minima_and_no_demo_ids(self):
        w=self.catalog.world
        self.assertGreaterEqual(len(w['locations']),100)
        self.assertGreaterEqual(len([x for x in w['locations'] if x['primary_category']=='underground_dungeon']),15)
        self.assertGreaterEqual(len(w['npc_definitions']),45)
        self.assertGreaterEqual(len(w['factions']),5)
        self.assertGreaterEqual(len(w['item_definitions']),80)
        self.assertGreaterEqual(len(w['conflicts']),10)
        self.assertGreaterEqual(len(w['craft_repair_operations']),15)
        self.assertGreaterEqual(len(self.catalog.creature_registry),10)
        self.assertNotIn('demo',str(w).lower())

    def test_fresh_run_requires_explicit_origin_and_has_no_demo_state(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaisesRegex(FullVersionGameError,'START_CLASS_REQUIRED'):
                FullVersionGame(core_root=ROOT,saves_root=Path(td))
            g=FullVersionGame(core_root=ROOT,saves_root=Path(td),start_class='BREAKER')
            self.assertTrue(g.location().startswith('loc:'))
            self.assertNotIn('demo',g.location().lower())
            self.assertTrue(all('demo' not in k.lower() for k in g.session.store.runtime_state))

    def test_bootstrap_is_new_run_only(self):
        m=RunSessionManager(master_seed=1); s=m.create_run(player_uuid='00000000-0000-0000-0000-000000000001'); r=RunActorRegistry(s); b=FullVersionBootstrap(self.catalog)
        b.initialize_new_run(s,r,start_class='OPERATOR')
        self.assertTrue(r.contains(PLAYER_ACTOR_INSTANCE_ID))
        with self.assertRaisesRegex(FullVersionBootstrapError,'ALREADY_INITIALIZED'):
            b.initialize_new_run(s,r,start_class='OPERATOR')

    def test_full_version_save_load_continuity(self):
        with tempfile.TemporaryDirectory() as td:
            saves=Path(td); g=FullVersionGame(core_root=ROOT,saves_root=saves,start_class='GHOST')
            g.complete_character(g.creation_template())
            before=g.location(); dest=self.catalog.location(before)['connections'][0]
            receipt=g.execute(action_type='MOVE',raw_input=f'go {dest}',parameters={'destination_location_id':dest})
            self.assertEqual(g.location(),dest)
            rev=g.session.store.revision; g.save()
            g2=FullVersionGame(core_root=ROOT,saves_root=saves)
            self.assertEqual(g2.location(),dest); self.assertEqual(g2.session.store.revision,rev)
            self.assertEqual(g2.profile.start_class,'GHOST')

    def test_active_paths_have_no_demo_contracts(self):
        self.assertFalse((ROOT/'content'/'demo0').exists())
        self.assertFalse((ROOT/'master'/'DEMO0_PLAN.md').exists())
        self.assertFalse((ROOT/'master'/'DEMO0_CONTRACT.json').exists())
        self.assertFalse((ROOT/'compat'/'playable_turn_loop_v0_1').exists())
        self.assertFalse((ROOT/'history').exists())

class FullVersionLegacySaveRejectionTests(unittest.TestCase):
    def test_stage9_shaped_non_full_version_save_is_rejected(self):
        import json
        from runtime.stage3c.isolation import FilesystemRunRepository, RunIdentity, RunSessionManager
        from runtime.stage9.actors import RunActorRegistry
        from runtime.stage9.identity import RuntimeIdentity
        with tempfile.TemporaryDirectory() as td:
            saves=Path(td)
            player='00000000-0000-0000-0000-000000000111'
            run='00000000-0000-0000-0000-000000000222'
            manager=RunSessionManager(master_seed=20260912)
            session=manager.create_run(player_uuid=player,run_uuid=run)
            reg=RunActorRegistry(session)
            reg.register(RuntimeIdentity(player,run,PLAYER_ACTOR_INSTANCE_ID),actor_definition_id='legacy.player')
            repo=FilesystemRunRepository(saves,static_core_roots=(ROOT,))
            repo.save(session)
            profile=saves/'profiles'/'full_version.json'; profile.parent.mkdir(parents=True,exist_ok=True)
            profile.write_text(json.dumps({'player_uuid':player,'run_uuid':run,'start_class':'BREAKER'}))
            with self.assertRaisesRegex(FullVersionGameError,'FULL_VERSION_RUN_MARKER_MISSING'):
                FullVersionGame(core_root=ROOT,saves_root=saves)
