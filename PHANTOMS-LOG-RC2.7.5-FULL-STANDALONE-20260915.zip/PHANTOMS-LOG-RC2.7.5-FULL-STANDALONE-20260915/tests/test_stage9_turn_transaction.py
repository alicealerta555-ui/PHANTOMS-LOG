from __future__ import annotations

import unittest
from dataclasses import FrozenInstanceError
from uuid import uuid4

from runtime.stage3a.kernel import Authority, Delta, Domain, Mode, Proposal
from runtime.stage3b.pipeline import ActionRequest, ActionResult, ActionRule, ActionStatus, OutcomeBranch
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.context import RuntimeContext
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.playable_runtime import PlayableRuntime, PlayableRuntimeError, RuntimeLifecycle
from runtime.stage9.transaction import (
    TurnTransaction,
    TurnTransactionError,
    TurnTransactionSnapshot,
    TurnTransactionStatus,
)


class Stage9TurnTransactionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.player_uuid = str(uuid4())
        self.run_uuid = str(uuid4())
        self.manager = RunSessionManager(master_seed=1112)
        self.session = self.manager.create_run(player_uuid=self.player_uuid, run_uuid=self.run_uuid)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(self.player_uuid, self.run_uuid, "actor:player")
        self.registry.register(self.identity, actor_definition_id="test.player")
        self.runtime = PlayableRuntime(self.session, self.registry)

    @staticmethod
    def _request(event_id: str = "stage9:txn:test") -> ActionRequest:
        return ActionRequest(
            event_id=event_id,
            rule=ActionRule(
                rule_id="STAGE9_TXN_NOOP",
                outcomes=(OutcomeBranch(outcome_id="NOOP", effects=()),),
            ),
            cause="STAGE9_TXN_TEST",
        )

    def _context(self, suffix: str = "txn") -> RuntimeContext:
        return self.runtime.create_context(
            self.identity,
            turn_id=f"turn:{suffix}",
            action_window_id=f"window:{suffix}",
        )

    def test_transaction_starts_created_and_has_no_world_handles(self) -> None:
        tx = TurnTransaction(self._context("created"))
        self.assertEqual(tx.status, TurnTransactionStatus.CREATED)
        self.assertEqual(tx.revision_before, self.session.store.revision)
        for forbidden in ("store", "state", "state_store", "kernel", "commit_kernel", "authority"):
            self.assertFalse(hasattr(tx, forbidden), forbidden)

    def test_action_can_be_bound_exactly_once(self) -> None:
        tx = TurnTransaction(self._context("bind"))
        request = self._request("stage9:txn:bind")
        tx.bind_action(request)
        self.assertIs(tx.request, request)
        self.assertEqual(tx.status, TurnTransactionStatus.ACTION_BOUND)
        with self.assertRaisesRegex(TurnTransactionError, "TURN_TRANSACTION_STATE_INVALID"):
            tx.bind_action(request)

    def test_execution_requires_bound_action(self) -> None:
        tx = TurnTransaction(self._context("order"))
        with self.assertRaisesRegex(TurnTransactionError, "TURN_TRANSACTION_STATE_INVALID"):
            tx.begin_execution()

    def test_result_records_only_turn_artifacts_and_completes(self) -> None:
        context = self._context("complete")
        tx = TurnTransaction(context)
        request = self._request("stage9:txn:complete")
        tx.bind_action(request)
        tx.begin_execution()
        result = ActionResult(ActionStatus.RESOLVED_NO_CHANGE, request.event_id, request.rule.rule_id)
        tx.record_result(result, revision_after=context.state_revision)
        snapshot = tx.complete()
        self.assertIsInstance(snapshot, TurnTransactionSnapshot)
        self.assertEqual(snapshot.status, TurnTransactionStatus.COMPLETE)
        self.assertEqual(snapshot.runtime_context, context)
        self.assertEqual(snapshot.action_event_id, request.event_id)
        self.assertEqual(snapshot.action_rule_id, request.rule.rule_id)
        self.assertEqual(snapshot.action_status, ActionStatus.RESOLVED_NO_CHANGE.value)
        self.assertFalse(snapshot.observed_revision_changed)

    def test_snapshot_is_immutable(self) -> None:
        tx = TurnTransaction(self._context("immutable"))
        tx.bind_action(self._request("stage9:txn:immutable"))
        tx.begin_execution()
        tx.record_result(
            ActionResult(ActionStatus.RESOLVED_NO_CHANGE, "stage9:txn:immutable", "STAGE9_TXN_NOOP"),
            revision_after=tx.revision_before,
        )
        snapshot = tx.complete()
        with self.assertRaises(FrozenInstanceError):
            snapshot.abort_reason = "changed"  # type: ignore[misc]

    def test_abort_records_reason_without_state_mutation(self) -> None:
        context = self._context("abort")
        before = self.session.store.snapshot()
        tx = TurnTransaction(context)
        tx.bind_action(self._request("stage9:txn:abort"))
        tx.begin_execution()
        snapshot = tx.abort("TECHNICAL_FAILURE", revision_after=self.session.store.revision)
        self.assertEqual(snapshot.status, TurnTransactionStatus.ABORTED)
        self.assertEqual(snapshot.abort_reason, "TECHNICAL_FAILURE")
        self.assertEqual(before, self.session.store.snapshot())

    def test_playable_runtime_receipt_contains_complete_transaction(self) -> None:
        context = self._context("receipt")
        request = self._request("stage9:txn:receipt")
        receipt = self.runtime.execute_action(context, request)
        self.assertEqual(receipt.transaction.status, TurnTransactionStatus.COMPLETE)
        self.assertEqual(receipt.transaction.turn_id, context.turn_id)
        self.assertEqual(receipt.transaction.action_window_id, context.action_window_id)
        self.assertEqual(receipt.transaction.action_event_id, request.event_id)
        self.assertEqual(receipt.transaction.revision_before, receipt.revision_before)
        self.assertEqual(receipt.transaction.revision_after, receipt.revision_after)
        self.assertEqual(self.runtime.last_transaction, receipt.transaction)

    def test_executor_exception_records_aborted_transaction_without_rollback(self) -> None:
        calls: list[str] = []
        def explode(_request: ActionRequest) -> ActionResult:
            calls.append("called")
            raise ValueError("boom")
        runtime = PlayableRuntime(self.session, self.registry, action_executor=explode)
        context = runtime.create_context(self.identity, turn_id="turn:explode-tx", action_window_id="window:explode-tx")
        before = self.session.store.snapshot()
        with self.assertRaisesRegex(ValueError, "boom"):
            runtime.execute_action(context, self._request("stage9:txn:explode"))
        self.assertEqual(calls, ["called"])
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.RUNTIME_FAULT)
        self.assertIsNotNone(runtime.last_transaction)
        assert runtime.last_transaction is not None
        self.assertEqual(runtime.last_transaction.status, TurnTransactionStatus.ABORTED)
        self.assertIn("ValueError:boom", runtime.last_transaction.abort_reason or "")
        self.assertEqual(before, self.session.store.snapshot())

    def test_invalid_executor_result_records_integrity_abort(self) -> None:
        runtime = PlayableRuntime(self.session, self.registry, action_executor=lambda _r: object())  # type: ignore[arg-type]
        context = runtime.create_context(self.identity, turn_id="turn:invalid-tx", action_window_id="window:invalid-tx")
        with self.assertRaisesRegex(PlayableRuntimeError, "ACTION_EXECUTOR_INVALID_RESULT"):
            runtime.execute_action(context, self._request("stage9:txn:invalid"))
        self.assertEqual(runtime.lifecycle, RuntimeLifecycle.INTEGRITY_BLOCKED)
        self.assertIsNotNone(runtime.last_transaction)
        assert runtime.last_transaction is not None
        self.assertEqual(runtime.last_transaction.status, TurnTransactionStatus.ABORTED)
        self.assertEqual(runtime.last_transaction.abort_reason, "ACTION_EXECUTOR_INVALID_RESULT")

    def test_transaction_records_commit_revision_but_does_not_commit_itself(self) -> None:
        event_id = "stage9:txn:commit"
        def executor(_request: ActionRequest) -> ActionResult:
            record = self.session.kernel.process(
                Proposal(
                    mode=Mode.COMMIT,
                    source=Authority.COMMIT_KERNEL,
                    event_id=event_id,
                    cause="STAGE9_TXN_COMMIT",
                    deltas=(
                        Delta(
                            Domain.RUNTIME_STATE,
                            "stage9.txn.value",
                            1,
                            Authority.RULE_KERNEL,
                            "STAGE9_TXN_COMMIT",
                            source_event_id=event_id,
                        ),
                    ),
                )
            )
            return ActionResult(ActionStatus.COMMITTED, event_id, "STAGE9_TXN_COMMIT_RULE", commit=record)  # type: ignore[arg-type]

        runtime = PlayableRuntime(self.session, self.registry, action_executor=executor)
        context = runtime.create_context(self.identity, turn_id="turn:commit-tx", action_window_id="window:commit-tx")
        receipt = runtime.execute_action(context, self._request(event_id))
        self.assertEqual(receipt.transaction.commit_revision, receipt.revision_after)
        self.assertTrue(receipt.transaction.observed_revision_changed)
        self.assertEqual(self.session.store.runtime_state["stage9.txn.value"], 1)

    def test_stale_context_rejection_does_not_create_transaction(self) -> None:
        runtime = self.runtime
        context = runtime.create_context(self.identity, turn_id="turn:stale-tx", action_window_id="window:stale-tx")
        event_id = "stage9:txn:external-bump"
        self.session.kernel.process(
            Proposal(
                mode=Mode.COMMIT,
                source=Authority.COMMIT_KERNEL,
                event_id=event_id,
                cause="STAGE9_TXN_EXTERNAL_BUMP",
                deltas=(
                    Delta(
                        Domain.RUNTIME_STATE,
                        "stage9.txn.external",
                        1,
                        Authority.RULE_KERNEL,
                        "STAGE9_TXN_EXTERNAL_BUMP",
                        source_event_id=event_id,
                    ),
                ),
            )
        )
        with self.assertRaisesRegex(PlayableRuntimeError, "RUNTIME_CONTEXT_STALE"):
            runtime.execute_action(context, self._request("stage9:txn:stale"))
        self.assertIsNone(runtime.last_transaction)


if __name__ == "__main__":
    unittest.main()
