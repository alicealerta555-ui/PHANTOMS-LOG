from __future__ import annotations

import json
import tempfile
import unittest
from dataclasses import FrozenInstanceError
from hashlib import sha256
from pathlib import Path
from uuid import uuid4

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage3c.isolation import FilesystemRunRepository, RunSessionManager, encode_store
from runtime.stage9.actor_context import ACTOR_VISIBLE_RUNTIME_KEY
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.context import RuntimeContext
from runtime.stage9.authority import AuthorityStatus, StateAuthority
from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType
from runtime.stage9.idempotency import IDEMPOTENCY_RUNTIME_KEY
from runtime.stage9.scheduler import SCHEDULER_RUNTIME_KEY, SchedulerCommitAdapter, SchedulerQueue
from runtime.stage9.world_time import WORLD_TIME_RUNTIME_KEY, WorldClock, WorldTimeCommitAdapter
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.save_snapshot import (
    CANONICAL_SAVE_SNAPSHOT_SCHEMA,
    STAGE9_RUNTIME_CONTRACT,
    STAGE9_SAVE_CAPABILITIES,
    CanonicalSaveSnapshotBuilder,
    Stage9SaveSnapshotError,
)
from runtime.stage9.transaction import TurnTransaction


def _canonical_hash(payload) -> str:
    raw = json.dumps(
        payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode("utf-8")
    return sha256(raw).hexdigest()


class Stage9CanonicalSaveSnapshotTests(unittest.TestCase):
    def setUp(self) -> None:
        self.manager = RunSessionManager(master_seed=20260911)
        self.player_uuid = str(uuid4())
        self.session = self.manager.create_run(player_uuid=self.player_uuid)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(
            self.player_uuid, self.session.identity.run_uuid, "actor:player"
        )
        self.registry.register(self.identity, actor_definition_id="actor-def:player")
        self.counter = 0

    def _commit(self, domain: Domain, key: str, value, *, writer=Authority.RULE_KERNEL, actor_id=None):
        self.counter += 1
        event_id = f"SAVE_SNAPSHOT:TEST:{self.counter}"
        result = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id=event_id,
            cause="TEST_SAVE_SNAPSHOT",
            deltas=(Delta(
                domain=domain,
                key=key,
                value=value,
                writer=writer,
                cause="TEST_SAVE_SNAPSHOT",
                source_event_id=event_id,
                actor_id=actor_id,
                provenance="TEST" if domain == Domain.ACTOR_KNOWLEDGE else None,
            ),),
        ))
        self.assertIsInstance(result, CommitRecord)
        return result

    def test_capture_is_read_only_deterministic_and_immutable(self):
        builder = CanonicalSaveSnapshotBuilder(self.session)
        before_revision = self.session.store.revision
        before_hash = self.session.store.state_hash()
        first = builder.capture()
        second = builder.capture()
        self.assertEqual(first, second)
        self.assertEqual(first.canonical_json, second.canonical_json)
        self.assertEqual(self.session.store.revision, before_revision)
        self.assertEqual(self.session.store.state_hash(), before_hash)
        with self.assertRaises(FrozenInstanceError):
            first.state_revision = 999  # type: ignore[misc]

    def test_envelope_hashes_and_schema_are_self_consistent(self):
        snap = CanonicalSaveSnapshotBuilder(self.session).capture()
        payload = snap.as_payload()
        snapshot_hash = payload.pop("snapshot_hash")
        self.assertEqual(snapshot_hash, _canonical_hash(payload))
        self.assertEqual(snap.snapshot_hash, snapshot_hash)
        self.assertEqual(snap.schema, CANONICAL_SAVE_SNAPSHOT_SCHEMA)
        self.assertEqual(snap.runtime_contract, STAGE9_RUNTIME_CONTRACT)
        self.assertEqual(tuple(payload["capabilities"]), STAGE9_SAVE_CAPABILITIES)
        self.assertEqual(payload["runstate_hash"], _canonical_hash(payload["store"]))
        self.assertEqual(payload["state_hash"], self.session.store.state_hash())
        self.assertEqual(payload["state_revision"], self.session.store.revision)

    def test_snapshot_store_is_exact_stage3c_canonical_store_including_ledger(self):
        self._commit(Domain.WORLD_TRUTH, "world.flag", {"value": 7})
        self._commit(Domain.RUNTIME_STATE, "runtime.flag", [1, 2, 3])
        snap = CanonicalSaveSnapshotBuilder(self.session).capture()
        self.assertEqual(snap.store_payload(), encode_store(self.session.store))
        self.assertEqual(len(snap.store_payload()["EVENT_LEDGER"]), self.session.store.revision)

    def test_returned_payload_is_copy_and_cannot_mutate_snapshot(self):
        snap = CanonicalSaveSnapshotBuilder(self.session).capture()
        first = snap.as_payload()
        first["store"]["RUNTIME_STATE"]["forged"] = "bad"
        second = snap.as_payload()
        self.assertNotIn("forged", second["store"]["RUNTIME_STATE"])
        self.assertEqual(snap.snapshot_hash, second["snapshot_hash"])

    def test_transient_runtime_context_and_transaction_never_enter_snapshot(self):
        context = RuntimeContext.capture(
            self.session,
            self.registry,
            self.identity,
            turn_id="turn:transient-only",
            action_window_id="window:transient-only",
        )
        transaction = TurnTransaction(context)
        self.assertEqual(transaction.runtime_context.turn_id, "turn:transient-only")
        snap = CanonicalSaveSnapshotBuilder(self.session).capture()
        text = snap.canonical_json.decode("utf-8")
        self.assertNotIn("turn:transient-only", text)
        self.assertNotIn("window:transient-only", text)
        self.assertNotIn("TurnTransaction", text)
        self.assertNotIn("RuntimeContext", text)

    def test_canonical_mutation_changes_snapshot_hash_and_revision(self):
        before = CanonicalSaveSnapshotBuilder(self.session).capture()
        self._commit(Domain.WORLD_TRUTH, "world.changed", True)
        after = CanonicalSaveSnapshotBuilder(self.session).capture()
        self.assertNotEqual(before.snapshot_hash, after.snapshot_hash)
        self.assertNotEqual(before.state_hash, after.state_hash)
        self.assertEqual(after.state_revision, before.state_revision + 1)

    def test_legacy_stage3c_store_without_actor_registry_is_not_stage9_ready(self):
        legacy = self.manager.create_run(player_uuid=str(uuid4()))
        with self.assertRaisesRegex(
            Stage9SaveSnapshotError,
            "SAVE_SNAPSHOT_STAGE9_NOT_READY:ACTOR_REGISTRY_MISSING",
        ):
            CanonicalSaveSnapshotBuilder(legacy).capture()

    def test_unregistered_actor_knowledge_fails_stage9_readiness(self):
        self._commit(
            Domain.ACTOR_KNOWLEDGE,
            "fact.ghost",
            {"value": "secret"},
            writer=Authority.SYSTEM_INIT,
            actor_id="actor:ghost",
        )
        with self.assertRaisesRegex(
            Stage9SaveSnapshotError,
            "UNREGISTERED_ACTOR_KNOWLEDGE:actor:ghost",
        ):
            CanonicalSaveSnapshotBuilder(self.session).capture()

    def test_unregistered_actor_visible_runtime_fails_stage9_readiness(self):
        self._commit(
            Domain.RUNTIME_STATE,
            ACTOR_VISIBLE_RUNTIME_KEY,
            {
                "run_uuid": self.session.identity.run_uuid,
                "actors": {"actor:ghost": {"location_ref": "room:x"}},
            },
        )
        with self.assertRaisesRegex(
            Stage9SaveSnapshotError,
            "UNREGISTERED_ACTOR_RUNTIME:actor:ghost",
        ):
            CanonicalSaveSnapshotBuilder(self.session).capture()

    def test_existing_stage3c_save_load_preserves_canonical_snapshot_bytes(self):
        self._commit(Domain.WORLD_TRUTH, "world.flag", "alpha")
        self._commit(
            Domain.RUNTIME_STATE,
            ACTOR_VISIBLE_RUNTIME_KEY,
            {
                "run_uuid": self.session.identity.run_uuid,
                "actors": {"actor:player": {"location_ref": "room:a", "energy": 5}},
            },
        )
        before = CanonicalSaveSnapshotBuilder(self.session).capture()
        identity = self.session.identity
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(Path(td))
            repo.save(self.session)
            self.manager.close_run(player_uuid=identity.player_uuid, run_uuid=identity.run_uuid)
            loaded = repo.load_session(self.manager, identity)
            after = CanonicalSaveSnapshotBuilder(loaded).capture()
        self.assertEqual(after.canonical_json, before.canonical_json)
        self.assertEqual(after.snapshot_hash, before.snapshot_hash)
        self.assertEqual(after.state_hash, before.state_hash)
        self.assertEqual(after.state_revision, before.state_revision)

    def test_run_isolation_produces_distinct_identity_bound_snapshots(self):
        other = self.manager.create_run(player_uuid=self.player_uuid)
        other_registry = RunActorRegistry(other)
        other_identity = RuntimeIdentity(self.player_uuid, other.identity.run_uuid, "actor:player")
        other_registry.register(other_identity, actor_definition_id="actor-def:player")
        a = CanonicalSaveSnapshotBuilder(self.session).capture()
        b = CanonicalSaveSnapshotBuilder(other).capture()
        self.assertNotEqual(a.run_uuid, b.run_uuid)
        self.assertNotEqual(a.snapshot_hash, b.snapshot_hash)
        self.assertEqual(a.player_uuid, b.player_uuid)

    def test_absent_world_time_and_scheduler_are_canonical_zero_empty_without_bootstrap_commit(self):
        before_revision = self.session.store.revision
        snap = CanonicalSaveSnapshotBuilder(self.session).capture()
        self.assertEqual(self.session.store.revision, before_revision)
        runtime = snap.store_payload()["RUNTIME_STATE"]
        self.assertNotIn("__stage9_world_time__", runtime)
        self.assertNotIn("__stage9_scheduler__", runtime)

    def test_real_world_time_scheduler_and_idempotency_are_captured_and_survive_stage3c_save_load(self):
        authority = StateAuthority(self.session, actor_registry=self.registry)
        time_adapter = WorldTimeCommitAdapter(self.session)
        scheduler_adapter = SchedulerCommitAdapter(self.session)

        time_proposal = EffectProposal(
            effect_id="effect:snapshot:time",
            run_uuid=self.session.identity.run_uuid,
            resolution_id="resolution:snapshot:time",
            source_action_id="action:snapshot:time",
            effect_type=EffectType.ADVANCE_WORLD_TIME,
            target_ref=None,
            payload={"seconds": 17},
            authority_domain=AuthorityDomain.WORLD_TIME,
            expected_state_revision=self.session.store.revision,
        )
        time_decision = authority.authorize(time_proposal)
        self.assertEqual(time_decision.status, AuthorityStatus.ALLOW)
        self.assertIsInstance(
            time_adapter.advance(
                time_decision,
                commit_id="commit:snapshot:time",
                event_id="SAVE:SNAPSHOT:TIME",
            ),
            CommitRecord,
        )

        schedule_proposal = EffectProposal(
            effect_id="effect:snapshot:schedule",
            run_uuid=self.session.identity.run_uuid,
            resolution_id="resolution:snapshot:schedule",
            source_action_id="action:snapshot:schedule",
            effect_type=EffectType.SCHEDULE_EVENT,
            target_ref="scheduled:snapshot",
            payload={
                "scheduled_event_id": "scheduled:snapshot",
                "event_type": "TEST_EVENT",
                "due_world_time": 21,
                "sequence_key": "001",
                "payload": {"k": "v"},
            },
            authority_domain=AuthorityDomain.SCHEDULER,
            expected_state_revision=self.session.store.revision,
        )
        schedule_decision = authority.authorize(schedule_proposal)
        self.assertEqual(schedule_decision.status, AuthorityStatus.ALLOW)
        self.assertIsInstance(
            scheduler_adapter.apply(
                schedule_decision,
                commit_id="commit:snapshot:schedule",
                event_id="SAVE:SNAPSHOT:SCHEDULE",
            ),
            CommitRecord,
        )

        before = CanonicalSaveSnapshotBuilder(self.session).capture()
        runtime = before.store_payload()["RUNTIME_STATE"]
        self.assertIn(WORLD_TIME_RUNTIME_KEY, runtime)
        self.assertIn(SCHEDULER_RUNTIME_KEY, runtime)
        self.assertIn(IDEMPOTENCY_RUNTIME_KEY, runtime)
        identity = self.session.identity

        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(Path(td))
            repo.save(self.session)
            self.manager.close_run(player_uuid=identity.player_uuid, run_uuid=identity.run_uuid)
            loaded = repo.load_session(self.manager, identity)
            after = CanonicalSaveSnapshotBuilder(loaded).capture()
            self.assertEqual(WorldClock(loaded).seconds, 17)
            self.assertEqual(
                [e.scheduled_event_id for e in SchedulerQueue(loaded).snapshot().events],
                ["scheduled:snapshot"],
            )

        self.assertEqual(after.canonical_json, before.canonical_json)
        self.assertEqual(after.snapshot_hash, before.snapshot_hash)

    def test_pretty_serialization_is_deterministic_and_contains_same_envelope(self):
        snap = CanonicalSaveSnapshotBuilder(self.session).capture()
        pretty1 = snap.to_json_bytes(pretty=True)
        pretty2 = snap.to_json_bytes(pretty=True)
        self.assertEqual(pretty1, pretty2)
        self.assertEqual(json.loads(pretty1), snap.as_payload())
        self.assertTrue(pretty1.endswith(b"\n"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
