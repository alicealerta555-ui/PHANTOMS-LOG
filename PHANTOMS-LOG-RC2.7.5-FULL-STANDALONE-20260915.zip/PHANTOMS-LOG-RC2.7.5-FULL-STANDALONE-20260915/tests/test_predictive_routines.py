from runtime.player_progression.habits import DecisionEvent
from runtime.player_progression.model import PlayerProgressionState
from runtime.player_progression.pipeline import PlayerLearningRuntime


def rt():
    return PlayerLearningRuntime(PlayerProgressionState("p", "r", "GHOST"))


def repeat(runtime, event, n):
    for _ in range(n):
        runtime.observe_decision(event)


def test_stable_instinct_can_be_predicted_as_auto():
    r = rt()
    e = DecisionEvent("room_entry", "use_cover", category="positioning", context_tags=("unknown",))
    repeat(r, e, 22)
    out = r.predict_routine("room_entry", ("unknown",))
    assert out is not None
    assert out["kind"] == "instinct_routine"
    assert out["choice"] == "use_cover"


def test_explicit_player_order_blocks_prediction():
    r = rt()
    repeat(r, DecisionEvent("room_entry", "use_cover", category="positioning"), 22)
    assert r.predict_routine("room_entry", player_has_explicit_order=True) is None


def test_high_stakes_and_irreversible_block_prediction():
    r = rt()
    repeat(r, DecisionEvent("room_entry", "use_cover", category="positioning"), 22)
    assert r.predict_routine("room_entry", high_stakes=True) is None
    assert r.predict_routine("room_entry", reversible=False) is None


def test_risky_instinct_never_auto_predicts():
    r = rt()
    repeat(r, DecisionEvent("opportunity", "take_risk", category="story_choice"), 26)
    assert r.predict_routine("opportunity") is None


def test_retraining_request_does_not_switch_off_existing_instinct():
    r = rt()
    repeat(r, DecisionEvent("travel_departure", "check_gear", category="preparation"), 22)
    before = r.predict_routine("travel_departure")
    assert before is not None and before["kind"] == "instinct_routine"
    r.request_habit_retraining("field_check")
    after = r.predict_routine("travel_departure")
    assert after is not None


def test_countertraining_can_end_old_prediction():
    r = rt()
    repeat(r, DecisionEvent("room_entry", "use_cover", category="positioning"), 18)
    r.request_habit_retraining("cover_entry", "enter_quietly")
    repeat(r, DecisionEvent("room_entry", "enter_quietly", category="micro_routine"), 22)
    old = r.habit_state.habits["cover_entry"]
    assert old.stage in {"forming", "fading"}
    out = r.predict_routine("room_entry")
    assert out is None or out.get("choice") != "use_cover"


def test_prediction_state_roundtrip():
    r = rt()
    repeat(r, DecisionEvent("travel_departure", "check_gear", category="preparation"), 20)
    assert r.predict_routine("travel_departure") is not None
    dumped = r.to_dict()
    loaded = PlayerLearningRuntime.from_dict(dumped)
    assert loaded.predictive_state.situation_choice_counts == r.predictive_state.situation_choice_counts
    assert loaded.progression.player_uuid == "p"
    assert loaded.progression.run_uuid == "r"


def test_player_payload_contains_no_prediction_scores():
    r = rt()
    repeat(r, DecisionEvent("room_entry", "scan_motion", category="perception"), 22)
    out = r.predict_routine("room_entry")
    assert out is not None
    text = repr(out).lower()
    for forbidden in ("confidence", "stability", "score", "threshold", "habit_id"):
        assert forbidden not in text
