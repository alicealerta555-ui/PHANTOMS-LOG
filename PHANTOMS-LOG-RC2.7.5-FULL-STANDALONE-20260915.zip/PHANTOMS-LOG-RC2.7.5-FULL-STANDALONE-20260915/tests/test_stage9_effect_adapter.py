from __future__ import annotations

import unittest
from uuid import uuid4

from runtime.stage3a.integration import RuntimeDelta
from runtime.stage3a.kernel import Domain
from runtime.stage9.effect_adapter import (
    LegacySemanticHint,
    RuntimeDeltaSemanticAdapter,
    Stage9EffectAdapterError,
)
from runtime.stage9.effects import EffectType


class Stage9EffectAdapterTests(unittest.TestCase):
    def setUp(self) -> None:
        self.run_uuid = str(uuid4())
        self.common = dict(
            effect_id="effect:legacy:1",
            run_uuid=self.run_uuid,
            resolution_id="resolution:legacy:1",
            source_action_id="action:legacy:1",
            expected_state_revision=4,
        )

    def test_explicit_door_mapping(self):
        delta = RuntimeDelta(Domain.RUNTIME_STATE.value, "service_door.open", True, "RULE_KERNEL", "OPEN_DOOR")
        proposal = RuntimeDeltaSemanticAdapter.to_effect_proposal(
            delta,
            hint=LegacySemanticHint(EffectType.SET_DOOR_STATE, target_ref="door:service"),
            **self.common,
        )
        self.assertEqual(proposal.effect_type, EffectType.SET_DOOR_STATE)
        self.assertEqual(proposal.payload["new_state"], "OPEN")

    def test_explicit_move_mapping(self):
        delta = RuntimeDelta(Domain.RUNTIME_STATE.value, "player.location", "location:corridor", "RULE_KERNEL", "MOVE")
        proposal = RuntimeDeltaSemanticAdapter.to_effect_proposal(
            delta,
            hint=LegacySemanticHint(EffectType.MOVE_ACTOR, target_ref="actor:player"),
            **self.common,
        )
        self.assertEqual(proposal.target_ref, "actor:player")
        self.assertEqual(proposal.payload["destination_location_id"], "location:corridor")

    def test_actor_knowledge_mapping_preserves_provenance(self):
        delta = RuntimeDelta(
            Domain.ACTOR_KNOWLEDGE.value,
            "door.visible",
            True,
            "KNOWLEDGE_ROUTER",
            "DIRECT_VISION",
            actor_id="actor:player",
            provenance="direct-vision",
            epistemic={"source_type": "VISION"},
        )
        proposal = RuntimeDeltaSemanticAdapter.to_effect_proposal(
            delta,
            hint=LegacySemanticHint(EffectType.WRITE_KNOWLEDGE),
            **self.common,
        )
        self.assertEqual(proposal.target_ref, "actor:player")
        self.assertEqual(proposal.payload["knowledge_key"], "door.visible")
        self.assertEqual(proposal.payload["provenance"], "direct-vision")

    def test_wrong_domain_fails_closed(self):
        delta = RuntimeDelta(Domain.PLAYER_KNOWLEDGE.value, "x", True, "KNOWLEDGE_ROUTER", "X")
        with self.assertRaisesRegex(Stage9EffectAdapterError, "LEGACY_DELTA_INCOMPATIBLE"):
            RuntimeDeltaSemanticAdapter.to_effect_proposal(
                delta,
                hint=LegacySemanticHint(EffectType.SET_DOOR_STATE, target_ref="door:service"),
                **self.common,
            )

    def test_no_generic_runtime_delta_mapping(self):
        delta = RuntimeDelta(Domain.RUNTIME_STATE.value, "player.energy", 2, "RULE_KERNEL", "ACTION_COST")
        with self.assertRaisesRegex(Stage9EffectAdapterError, "LEGACY_DELTA_SEMANTIC_MAPPING_REQUIRED"):
            RuntimeDeltaSemanticAdapter.to_effect_proposal(
                delta,
                hint=LegacySemanticHint(EffectType.RESOURCE_DELTA, target_ref="actor:player"),
                **self.common,
            )

    def test_item_transfer_requires_explicit_source_location(self):
        delta = RuntimeDelta(Domain.RUNTIME_STATE.value, "item.flashlight.location", "inventory:player", "RULE_KERNEL", "TAKE")
        with self.assertRaisesRegex(Stage9EffectAdapterError, "LEGACY_TRANSFER_REFS_REQUIRED"):
            RuntimeDeltaSemanticAdapter.to_effect_proposal(
                delta,
                hint=LegacySemanticHint(EffectType.ITEM_TRANSFER, target_ref="item:flashlight"),
                **self.common,
            )

    def test_knowledge_target_mismatch_rejected(self):
        delta = RuntimeDelta(
            Domain.ACTOR_KNOWLEDGE.value, "x", True, "KNOWLEDGE_ROUTER", "X",
            actor_id="actor:a", provenance="direct", epistemic={"source_type": "VISION"},
        )
        with self.assertRaisesRegex(Stage9EffectAdapterError, "LEGACY_KNOWLEDGE_TARGET_MISMATCH"):
            RuntimeDeltaSemanticAdapter.to_effect_proposal(
                delta,
                hint=LegacySemanticHint(EffectType.WRITE_KNOWLEDGE, target_ref="actor:b"),
                **self.common,
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
