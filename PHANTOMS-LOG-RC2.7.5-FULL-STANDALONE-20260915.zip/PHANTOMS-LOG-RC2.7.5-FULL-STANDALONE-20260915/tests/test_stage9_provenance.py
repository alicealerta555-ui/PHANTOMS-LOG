from __future__ import annotations
import unittest
from uuid import uuid4
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import StateAuthority
from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.provenance import MutationProvenanceAuditor
from runtime.stage9.world_time import WorldTimeCommitAdapter

class Stage9ProvenanceTests(unittest.TestCase):
    def test_stage9_commit_has_traceable_commit_effect_event_lineage(self):
        m=RunSessionManager(master_seed=9); p=str(uuid4()); s=m.create_run(player_uuid=p)
        r=RunActorRegistry(s); i=RuntimeIdentity(p,s.identity.run_uuid,"actor:player"); r.register(i, actor_definition_id="player")
        a=StateAuthority(s, actor_registry=r)
        ep=EffectProposal(effect_id="effect:prov:time",run_uuid=s.identity.run_uuid,resolution_id="resolution:prov",source_action_id="action:prov",effect_type=EffectType.ADVANCE_WORLD_TIME,target_ref=None,payload={"seconds":1},authority_domain=AuthorityDomain.WORLD_TIME,expected_state_revision=s.store.revision)
        d=a.authorize(ep); rec=WorldTimeCommitAdapter(s).advance(d,commit_id="commit:prov:time",event_id="EVENT:PROV:TIME")
        trace=MutationProvenanceAuditor(s).trace_record(rec)
        self.assertEqual(trace.commit_id,"commit:prov:time")
        self.assertEqual(trace.effect_ids,("effect:prov:time",))
        self.assertIn("EVENT:PROV:TIME",trace.source_event_ids)

if __name__ == "__main__": unittest.main()
