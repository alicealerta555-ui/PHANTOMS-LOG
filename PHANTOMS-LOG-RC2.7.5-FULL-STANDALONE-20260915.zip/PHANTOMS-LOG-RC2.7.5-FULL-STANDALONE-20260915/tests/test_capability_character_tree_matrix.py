from __future__ import annotations

import pytest

from runtime.full_version.capability_catalog import (
    CLASS_TALENTS, SKILLS, STATS, TALENTS, validate_catalog,
)
from runtime.full_version.capability_resolution import (
    CapabilityZone, StageDemand, assess_talent,
)


def _character_for(talent_id: str):
    talent=TALENTS[talent_id]
    return {
        "stats": {sid: 8 for sid in STATS},
        "skills": {sid: (7 if sid in talent.required_skills else 1) for sid in SKILLS},
        "talents": [talent_id],
        "expertises": {},
        "stat_penalties": {},
    }


def _demands_for(talent_id: str, *, difficulty=6, hard_min=4):
    t=TALENTS[talent_id]
    stages=[]
    for stage in t.modifies_stages:
        # Every talent gets a stage-local natural-limit check.  This is deliberately
        # conservative: method-specific runtime actions can provide narrower subsets.
        stats={sid: hard_min for sid in t.required_stats}
        stages.append(StageDemand(stage,stats,difficulty))
    return tuple(stages)


def test_catalog_is_structurally_complete():
    assert validate_catalog() == ()
    assert len(STATS) == 10
    assert len(SKILLS) == 30
    assert len(TALENTS) == 26
    assert {k:len(v) for k,v in CLASS_TALENTS.items()} == {
        "BREAKER":6,"GHOST":6,"OPERATOR":6,"RESONANT":8,
    }


@pytest.mark.parametrize("talent_id", sorted(TALENTS))
def test_each_talent_has_stats_skills_stages_and_situations(talent_id):
    t=TALENTS[talent_id]
    assert t.required_stats
    assert t.required_skills
    assert t.modifies_stages
    assert t.situations
    assert all(x in STATS for x in t.required_stats)
    assert all(x in SKILLS for x in t.required_skills)


@pytest.mark.parametrize("talent_id", sorted(TALENTS))
def test_each_talent_safe_application(talent_id):
    c=_character_for(talent_id)
    r=assess_talent(c,talent_id,_demands_for(talent_id,difficulty=4,hard_min=3))
    assert r.zone == CapabilityZone.SAFE


@pytest.mark.parametrize("talent_id", sorted(TALENTS))
def test_each_talent_becomes_inaccessible_when_not_learned(talent_id):
    c=_character_for(talent_id); c["talents"]=[]
    r=assess_talent(c,talent_id,_demands_for(talent_id))
    assert r.zone == CapabilityZone.INACCESSIBLE


@pytest.mark.parametrize("talent_id", sorted(TALENTS))
def test_each_talent_becomes_inaccessible_when_required_skill_missing(talent_id):
    c=_character_for(talent_id)
    c["skills"][TALENTS[talent_id].required_skills[0]]=0
    r=assess_talent(c,talent_id,_demands_for(talent_id))
    assert r.zone == CapabilityZone.INACCESSIBLE


@pytest.mark.parametrize("talent_id", sorted(TALENTS))
def test_each_talent_hard_limit_precedes_luck_expertise_and_tools(talent_id):
    c=_character_for(talent_id)
    stat=TALENTS[talent_id].required_stats[0]
    c["stats"][stat]=2
    r=assess_talent(c,talent_id,_demands_for(talent_id,hard_min=5),expertise_bonus=20,situational_bonus=20)
    assert r.zone == CapabilityZone.HARD_LIMIT
    assert r.failure_stage == TALENTS[talent_id].modifies_stages[0]


@pytest.mark.parametrize("talent_id", sorted(TALENTS))
def test_each_talent_current_condition_can_create_hard_limit_without_rewriting_base_stat(talent_id):
    c=_character_for(talent_id)
    stat=TALENTS[talent_id].required_stats[0]
    original=c["stats"][stat]
    c["stat_penalties"][stat]=5
    r=assess_talent(c,talent_id,_demands_for(talent_id,hard_min=5))
    assert r.zone == CapabilityZone.HARD_LIMIT
    assert c["stats"][stat] == original


@pytest.mark.parametrize("talent_id", sorted(TALENTS))
def test_each_talent_edge_and_extreme_are_rollable_not_impossible(talent_id):
    c=_character_for(talent_id)
    edge=assess_talent(c,talent_id,_demands_for(talent_id,difficulty=10,hard_min=3))
    extreme=assess_talent(c,talent_id,_demands_for(talent_id,difficulty=14,hard_min=3))
    assert edge.zone in {CapabilityZone.EDGE,CapabilityZone.EXTREME}
    assert extreme.zone == CapabilityZone.EXTREME


@pytest.mark.parametrize("talent_id", sorted(TALENTS))
def test_each_talent_expertise_changes_reliability_not_hard_limit(talent_id):
    c=_character_for(talent_id)
    base=assess_talent(c,talent_id,_demands_for(talent_id,difficulty=11,hard_min=3))
    trained=assess_talent(c,talent_id,_demands_for(talent_id,difficulty=11,hard_min=3),expertise_bonus=3)
    order={CapabilityZone.EXTREME:0,CapabilityZone.EDGE:1,CapabilityZone.SAFE:2}
    assert order[trained.zone] >= order[base.zone]
    stat=TALENTS[talent_id].required_stats[0]
    c["stats"][stat]=1
    blocked=assess_talent(c,talent_id,_demands_for(talent_id,difficulty=4,hard_min=5),expertise_bonus=99)
    assert blocked.zone == CapabilityZone.HARD_LIMIT


def test_resonant_can_sense_presence_but_fail_later_focus_stage():
    c={"stats":{sid:8 for sid in STATS},"skills":{sid:1 for sid in SKILLS},"talents":[],"stat_penalties":{}}
    c["skills"]["SKILL_RESONANCE_SENSE"]=8
    c["skills"]["SKILL_RESONANCE_CONTROL"]=5
    # Sensing is safely inside capacity.
    from runtime.full_version.capability_resolution import assess_skill
    sensed=assess_skill(c,"SKILL_RESONANCE_SENSE",(
        StageDemand("INPUT",{"STAT_RES":4,"STAT_PER":4},4),
    ))
    assert sensed.zone == CapabilityZone.SAFE
    # Focusing/contact can still be impossible in current condition.
    c["stat_penalties"]["STAT_WIL"]=5
    focused=assess_skill(c,"SKILL_RESONANCE_CONTROL",(
        StageDemand("SETUP",{"STAT_WIL":5},6),
        StageDemand("EXECUTE",{"STAT_RES":4},6),
    ))
    assert focused.zone == CapabilityZone.HARD_LIMIT
    assert focused.failure_stage == "SETUP"


def test_breaker_can_have_correct_setup_but_insufficient_strength():
    c={"stats":{sid:8 for sid in STATS},"skills":{sid:1 for sid in SKILLS},"talents":[],"stat_penalties":{}}
    c["skills"]["SKILL_FORCE_APPLICATION"]=8
    c["stats"]["STAT_STR"]=4
    from runtime.full_version.capability_resolution import assess_skill
    result=assess_skill(c,"SKILL_FORCE_APPLICATION",(
        StageDemand("SETUP",{"STAT_MOB":4,"STAT_COG":4},4),
        StageDemand("EXECUTE",{"STAT_STR":7},5),
    ))
    assert result.zone == CapabilityZone.HARD_LIMIT
    assert result.stages[0].passed_information is True
    assert result.failure_stage == "EXECUTE"


def test_ghost_can_read_quiet_route_but_fail_balance_execution():
    c={"stats":{sid:8 for sid in STATS},"skills":{sid:1 for sid in SKILLS},"talents":[],"stat_penalties":{}}
    c["skills"]["SKILL_STEALTH"]=8
    c["stats"]["STAT_MOB"]=4
    from runtime.full_version.capability_resolution import assess_skill
    result=assess_skill(c,"SKILL_STEALTH",(
        StageDemand("INPUT",{"STAT_PER":4},4),
        StageDemand("INTERPRET",{"STAT_COG":4},4),
        StageDemand("EXECUTE",{"STAT_MOB":6,"STAT_DEX":4},5),
    ))
    assert result.zone == CapabilityZone.HARD_LIMIT
    assert [s.passed_information for s in result.stages[:2]] == [True,True]
    assert result.failure_stage == "EXECUTE"


def _skill_character(skill_id: str):
    return {
        "stats": {sid: 8 for sid in STATS},
        "skills": {sid: (7 if sid == skill_id else 1) for sid in SKILLS},
        "talents": [],
        "expertises": {},
        "stat_penalties": {},
    }


def _skill_demands(skill_id: str, *, difficulty=6, hard_min=4):
    skill=SKILLS[skill_id]
    return tuple(StageDemand(stage.stage,{sid:hard_min for sid in stage.stats},difficulty) for stage in skill.stages)


@pytest.mark.parametrize("skill_id", sorted(SKILLS))
def test_each_skill_has_complete_capability_chain_and_examples(skill_id):
    skill=SKILLS[skill_id]
    assert skill.stages
    assert skill.situations
    assert skill.expertise_examples
    assert skill.stats
    assert all(stage.stats for stage in skill.stages)


@pytest.mark.parametrize("skill_id", sorted(SKILLS))
def test_each_skill_safe_application(skill_id):
    from runtime.full_version.capability_resolution import assess_skill
    c=_skill_character(skill_id)
    r=assess_skill(c,skill_id,_skill_demands(skill_id,difficulty=4,hard_min=3))
    assert r.zone == CapabilityZone.SAFE


@pytest.mark.parametrize("skill_id", sorted(SKILLS))
def test_each_skill_inaccessible_when_not_learned(skill_id):
    from runtime.full_version.capability_resolution import assess_skill
    c=_skill_character(skill_id); c["skills"][skill_id]=0
    r=assess_skill(c,skill_id,_skill_demands(skill_id))
    assert r.zone == CapabilityZone.INACCESSIBLE


@pytest.mark.parametrize("skill_id", sorted(SKILLS))
def test_each_skill_hard_limit_precedes_expertise(skill_id):
    from runtime.full_version.capability_resolution import assess_skill
    c=_skill_character(skill_id)
    first_stat=SKILLS[skill_id].stages[0].stats[0]
    c["stats"][first_stat]=2
    r=assess_skill(c,skill_id,_skill_demands(skill_id,hard_min=5),expertise_bonus=50,situational_bonus=50)
    assert r.zone == CapabilityZone.HARD_LIMIT


@pytest.mark.parametrize("skill_id", sorted(SKILLS))
def test_each_skill_current_condition_can_reduce_available_capacity(skill_id):
    from runtime.full_version.capability_resolution import assess_skill
    c=_skill_character(skill_id)
    first_stat=SKILLS[skill_id].stages[0].stats[0]
    base=c["stats"][first_stat]
    c["stat_penalties"][first_stat]=5
    r=assess_skill(c,skill_id,_skill_demands(skill_id,hard_min=5))
    assert r.zone == CapabilityZone.HARD_LIMIT
    assert c["stats"][first_stat] == base


@pytest.mark.parametrize("skill_id", sorted(SKILLS))
def test_each_skill_edge_and_extreme_remain_rollable(skill_id):
    from runtime.full_version.capability_resolution import assess_skill
    c=_skill_character(skill_id)
    edge=assess_skill(c,skill_id,_skill_demands(skill_id,difficulty=10,hard_min=3))
    extreme=assess_skill(c,skill_id,_skill_demands(skill_id,difficulty=14,hard_min=3))
    assert edge.zone in {CapabilityZone.EDGE,CapabilityZone.EXTREME}
    assert extreme.zone == CapabilityZone.EXTREME


@pytest.mark.parametrize("skill_id", sorted(SKILLS))
def test_each_skill_expertise_only_improves_reliability(skill_id):
    from runtime.full_version.capability_resolution import assess_skill
    c=_skill_character(skill_id)
    base=assess_skill(c,skill_id,_skill_demands(skill_id,difficulty=11,hard_min=3))
    trained=assess_skill(c,skill_id,_skill_demands(skill_id,difficulty=11,hard_min=3),expertise_bonus=3)
    order={CapabilityZone.EXTREME:0,CapabilityZone.EDGE:1,CapabilityZone.SAFE:2}
    assert order[trained.zone] >= order[base.zone]
    first_stat=SKILLS[skill_id].stages[0].stats[0]
    c["stats"][first_stat]=1
    blocked=assess_skill(c,skill_id,_skill_demands(skill_id,difficulty=4,hard_min=5),expertise_bonus=99)
    assert blocked.zone == CapabilityZone.HARD_LIMIT
