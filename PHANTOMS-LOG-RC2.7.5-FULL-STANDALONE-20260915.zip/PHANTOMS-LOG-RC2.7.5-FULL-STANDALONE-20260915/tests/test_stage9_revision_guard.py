from __future__ import annotations

import unittest
from uuid import uuid4

from runtime.stage3a.kernel import (
    Authority,
    CommitRecord,
    Delta,
    Domain,
    Mode,
    Proposal,
    ValidationResult,
    Verdict,
)
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import StateAuthority, AuthorityStatus
from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.revision import CommitRevisionBoundary, Stage9RevisionGuardError


class Stage9RevisionGuardTests(unittest.TestCase):
    def setUp(self) -> None:
        self.manager = RunSessionManager(master_seed=20260911)
        self.player_uuid = str(uuid4())
        self.session = self.manager.create_run(player_uuid=self.player_uuid)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(
            self.player_uuid, self.session.identity.run_uuid, "actor:player"
        )
        self.registry.register(self.identity, actor_definition_id="actor-def:player")
        self.authority = StateAuthority(self.session, actor_registry=self.registry)
        self.boundary = CommitRevisionBoundary(self.session)

    def _effect(self, *, effect_id: str = "effect:time:1") -> EffectProposal:
        return EffectProposal(
            effect_id=effect_id,
            run_uuid=self.session.identity.run_uuid,
            resolution_id="resolution:1",
            source_action_id="action:1",
            effect_type=EffectType.ADVANCE_WORLD_TIME,
            target_ref=None,
            payload={"seconds": 1},
            authority_domain=AuthorityDomain.WORLD_TIME,
            expected_state_revision=self.session.store.revision,
        )

    def _legacy_commit_proposal(
        self,
        *,
        event_id: str,
        value: int,
        expected_state_revision=None,
    ) -> Proposal:
        return Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id=event_id,
            cause="TEST_STAGE9_REVISION_GUARD",
            expected_state_revision=expected_state_revision,
            deltas=(Delta(
                domain=Domain.RUNTIME_STATE,
                key=event_id,
                value=value,
                writer=Authority.RULE_KERNEL,
                cause="TEST_STAGE9_REVISION_GUARD",
                source_event_id=event_id,
            ),),
        )

    def test_exact_revision_bound_commit_succeeds(self):
        decision = self.authority.authorize(self._effect())
        self.assertEqual(decision.status, AuthorityStatus.ALLOW)
        before = self.session.store.revision
        bound = self.boundary.bind(
            decision.commit_operation,
            self._legacy_commit_proposal(event_id="REV:OK", value=1),
        )
        result = self.session.kernel.process(bound.proposal)
        self.assertIsInstance(result, CommitRecord)
        self.assertEqual(result.revision, before + 1)

    def test_authority_to_commit_toc_tou_is_rejected(self):
        decision = self.authority.authorize(self._effect(effect_id="effect:stale"))
        self.assertEqual(decision.status, AuthorityStatus.ALLOW)
        approved = decision.commit_operation.approved_state_revision

        bump = self.session.kernel.process(
            self._legacy_commit_proposal(event_id="REV:BUMP", value=99)
        )
        self.assertIsInstance(bump, CommitRecord)
        self.assertGreater(self.session.store.revision, approved)

        with self.assertRaisesRegex(Stage9RevisionGuardError, "STALE_STATE_REVISION"):
            self.boundary.bind(
                decision.commit_operation,
                self._legacy_commit_proposal(event_id="REV:STALE", value=2),
            )

    def test_kernel_rechecks_revision_immediately_before_mutation(self):
        current = self.session.store.revision
        before_hash = self.session.store.state_hash()
        p = self._legacy_commit_proposal(
            event_id="REV:KERNEL:STALE",
            value=3,
            expected_state_revision=current + 1,
        )
        result = self.session.kernel.process(p)
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertEqual(result.reasons, ("STALE_STATE_REVISION",))
        self.assertEqual(self.session.store.revision, current)
        self.assertEqual(self.session.store.state_hash(), before_hash)
        self.assertNotIn("REV:KERNEL:STALE", self.session.store.runtime_state)

    def test_future_revision_is_rejected_without_mutation(self):
        current = self.session.store.revision
        p = self._legacy_commit_proposal(
            event_id="REV:FUTURE",
            value=4,
            expected_state_revision=current + 100,
        )
        result = self.session.kernel.process(p)
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.reasons, ("STALE_STATE_REVISION",))
        self.assertEqual(self.session.store.revision, current)

    def test_invalid_expected_revision_is_rejected(self):
        current = self.session.store.revision
        p = self._legacy_commit_proposal(
            event_id="REV:INVALID",
            value=5,
            expected_state_revision=-1,
        )
        result = self.session.kernel.process(p)
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertIn("EXPECTED_STATE_REVISION_INVALID", result.reasons)
        self.assertEqual(self.session.store.revision, current)

    def test_legacy_commit_without_expected_revision_remains_compatible(self):
        before = self.session.store.revision
        result = self.session.kernel.process(
            self._legacy_commit_proposal(event_id="REV:LEGACY", value=6)
        )
        self.assertIsInstance(result, CommitRecord)
        self.assertEqual(result.revision, before + 1)

    def test_wrong_run_operation_cannot_be_bound(self):
        decision = self.authority.authorize(self._effect(effect_id="effect:run"))
        self.assertEqual(decision.status, AuthorityStatus.ALLOW)
        other = self.manager.create_run(player_uuid=self.player_uuid)
        other_boundary = CommitRevisionBoundary(other)
        with self.assertRaisesRegex(Stage9RevisionGuardError, "RUN_ISOLATION_VIOLATION"):
            other_boundary.bind(
                decision.commit_operation,
                self._legacy_commit_proposal(event_id="REV:WRONGRUN", value=7),
            )

    def test_prebound_conflicting_revision_is_rejected(self):
        decision = self.authority.authorize(self._effect(effect_id="effect:conflict"))
        with self.assertRaisesRegex(Stage9RevisionGuardError, "COMMIT_PROPOSAL_REVISION_CONFLICT"):
            self.boundary.bind(
                decision.commit_operation,
                self._legacy_commit_proposal(
                    event_id="REV:CONFLICT",
                    value=8,
                    expected_state_revision=self.session.store.revision + 1,
                ),
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
