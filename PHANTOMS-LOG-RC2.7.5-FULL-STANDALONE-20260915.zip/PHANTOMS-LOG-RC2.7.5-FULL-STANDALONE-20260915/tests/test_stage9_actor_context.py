from __future__ import annotations

import tempfile
import unittest
from dataclasses import FrozenInstanceError, asdict
from pathlib import Path
from uuid import uuid4

from phantoms_stage5.senses import BoundSense, Expression, SenseProfile
from phantoms_stage5.visual import VisualLimits
from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage3c.isolation import FilesystemRunRepository, RunSessionManager
from runtime.stage9.actor_context import (
    ACTOR_VISIBLE_RUNTIME_KEY,
    ActorContextProjector,
    PerceptionProjectionRequest,
    Stage9ActorContextError,
)
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.knowledge import PerceptionKnowledgePath
from runtime.stage9.perception import PERCEPTION_INPUT_WORLD_KEY, PerceptionReader


class Stage9ActorContextTests(unittest.TestCase):
    def setUp(self) -> None:
        self.manager = RunSessionManager(master_seed=20260911)
        self.player_uuid = str(uuid4())
        self.session = self.manager.create_run(player_uuid=self.player_uuid)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(self.player_uuid, self.session.identity.run_uuid, "actor:player")
        self.npc_identity = RuntimeIdentity(self.player_uuid, self.session.identity.run_uuid, "actor:npc")
        self.registry.register(self.identity, actor_definition_id="actor-def:player")
        self.registry.register(self.npc_identity, actor_definition_id="actor-def:npc")
        self.sense = BoundSense(
            lineage_id="lineage:human",
            hook_id="sense:eye",
            modality="visual",
            profile=SenseProfile("profile:eye", "visual", ("constraint:light",)),
            expression=Expression.ACTIVE,
            evidence_refs=("static:sense",),
            condition_refs=(),
        )
        self.limits = VisualLimits("profile:eye", 20.0, 2.0)
        self.reader = PerceptionReader(
            self.session, self.registry, self.identity, sense=self.sense, limits=self.limits
        )
        self.projector = ActorContextProjector(self.session, self.registry, self.identity)
        self.counter = 0

    def _commit(self, domain: Domain, key: str, value, *, writer=Authority.RULE_KERNEL, actor_id=None):
        self.counter += 1
        eid = f"ACTOR_CONTEXT:TEST:{self.counter}"
        delta = Delta(
            domain=domain,
            key=key,
            value=value,
            writer=writer,
            cause="TEST_ACTOR_CONTEXT",
            source_event_id=eid,
            actor_id=actor_id,
            provenance="TEST" if domain == Domain.ACTOR_KNOWLEDGE else None,
            epistemic=(
                {
                    "source_type": "TEST",
                    "source_id": "test",
                    "origin_location": "test",
                    "learned_at": 0,
                    "path": [],
                    "confidence_ppm": 1_000_000,
                    "distortions": [],
                }
                if domain == Domain.ACTOR_KNOWLEDGE
                else None
            ),
        )
        result = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id=eid,
            cause="TEST_ACTOR_CONTEXT",
            deltas=(delta,),
        ))
        self.assertIsInstance(result, CommitRecord)
        return result

    def _visual_record(self, *, observer="actor:player", los=True, subject="object:door"):
        return {
            "run_uuid": self.session.identity.run_uuid,
            "observer_actor_instance_id": observer,
            "subject_ref": subject,
            "channel": "visual",
            "lineage_id": self.sense.lineage_id,
            "hook_id": self.sense.hook_id,
            "conditions": {
                "distance_m": 5.0,
                "incident_illuminance_lux": 10.0,
                "line_of_sight_clear": los,
            },
        }

    def _commit_perception_inputs(self, entries):
        self._commit(Domain.WORLD_TRUTH, PERCEPTION_INPUT_WORLD_KEY, entries)

    def _commit_visible_runtime(self, actors):
        self._commit(
            Domain.RUNTIME_STATE,
            ACTOR_VISIBLE_RUNTIME_KEY,
            {"run_uuid": self.session.identity.run_uuid, "actors": actors},
        )

    def test_empty_context_is_read_only_compact_and_fingerprinted(self):
        before_rev = self.session.store.revision
        before_hash = self.session.store.state_hash()
        ctx = self.projector.project()
        self.assertEqual(ctx.run_uuid, self.session.identity.run_uuid)
        self.assertEqual(ctx.actor_instance_id, "actor:player")
        self.assertEqual(ctx.actor_definition_id, "actor-def:player")
        self.assertEqual(ctx.knowledge, ())
        self.assertEqual(ctx.perception, ())
        self.assertEqual(ctx.runtime_visible, ())
        self.assertEqual(len(ctx.context_fingerprint), 64)
        self.assertEqual(self.session.store.revision, before_rev)
        self.assertEqual(self.session.store.state_hash(), before_hash)
        for forbidden in ("store", "session", "kernel", "authority", "world_truth"):
            self.assertFalse(hasattr(ctx, forbidden))

    def test_own_knowledge_only_other_actor_is_not_projected(self):
        self._commit(Domain.ACTOR_KNOWLEDGE, "fact.own", {"value": "alpha"}, writer=Authority.KNOWLEDGE_ROUTER, actor_id="actor:player")
        self._commit(Domain.ACTOR_KNOWLEDGE, "fact.npc", {"secret": "omega"}, writer=Authority.KNOWLEDGE_ROUTER, actor_id="actor:npc")
        ctx = self.projector.project()
        self.assertEqual(tuple(f.knowledge_key for f in ctx.knowledge), ("fact.own",))
        text = repr(ctx)
        self.assertNotIn("fact.npc", text)
        self.assertNotIn("omega", text)

    def test_detected_perception_is_projected_but_not_detected_is_omitted(self):
        self._commit_perception_inputs({
            "input:door": self._visual_record(los=True),
            "input:hidden": self._visual_record(los=False, subject="object:hidden"),
        })
        ctx = self.projector.project(perception_requests=(
            PerceptionProjectionRequest(self.reader, "input:door", "object:door"),
            PerceptionProjectionRequest(self.reader, "input:hidden", "object:hidden"),
        ))
        self.assertEqual(len(ctx.perception), 1)
        self.assertEqual(ctx.perception[0].subject_ref, "object:door")
        self.assertEqual(ctx.perception[0].channel, "visual")
        self.assertNotIn("OCCLUDED", repr(ctx))

    def test_raw_world_truth_and_perception_conditions_never_appear(self):
        self._commit(Domain.WORLD_TRUTH, "secret.world", {"boss_code": "OMEGA-42"})
        self._commit_perception_inputs({"input:door": self._visual_record()})
        ctx = self.projector.project(perception_requests=(
            PerceptionProjectionRequest(self.reader, "input:door", "object:door"),
        ))
        exposed = repr(asdict(ctx))
        self.assertNotIn("OMEGA-42", exposed)
        self.assertNotIn("incident_illuminance_lux", exposed)
        self.assertNotIn("line_of_sight_clear", exposed)
        self.assertNotIn("WORLD_TRUTH", exposed)

    def test_only_dedicated_actor_visible_runtime_record_is_projected(self):
        self._commit(Domain.RUNTIME_STATE, "global.secret", "do-not-leak")
        self._commit_visible_runtime({
            "actor:player": {"location_ref": "room:a", "energy": 7, "status_flags": ["alert"]},
            "actor:npc": {"location_ref": "vault:secret", "energy": 99},
        })
        ctx = self.projector.project()
        fields = {f.name: f.value for f in ctx.runtime_visible}
        self.assertEqual(set(fields), {"energy", "location_ref", "status_flags"})
        self.assertNotIn("do-not-leak", repr(ctx))
        self.assertNotIn("vault:secret", repr(ctx))

    def test_unknown_actor_visible_runtime_field_fails_closed(self):
        self._commit_visible_runtime({
            "actor:player": {"location_ref": "room:a", "hidden_admin_state": "secret"},
        })
        with self.assertRaisesRegex(Stage9ActorContextError, "ACTOR_VISIBLE_RUNTIME_FIELD_FORBIDDEN"):
            self.projector.project()

    def test_reader_bound_to_other_actor_is_rejected(self):
        npc_reader = PerceptionReader(
            self.session, self.registry, self.npc_identity, sense=self.sense, limits=self.limits
        )
        with self.assertRaisesRegex(Stage9ActorContextError, "PERCEPTION_READER_ACTOR_MISMATCH"):
            self.projector.project(perception_requests=(
                PerceptionProjectionRequest(npc_reader, "input:any", "object:any"),
            ))

    def test_unregistered_actor_cannot_get_context(self):
        ghost = RuntimeIdentity(self.player_uuid, self.session.identity.run_uuid, "actor:ghost")
        with self.assertRaises(Stage9ActorContextError) as ctx:
            ActorContextProjector(self.session, self.registry, ghost)
        self.assertIn("ACTOR_NOT_REGISTERED_IN_RUN", str(ctx.exception))

    def test_cross_run_registry_or_identity_fails_closed(self):
        other = self.manager.create_run(player_uuid=self.player_uuid)
        other_registry = RunActorRegistry(other)
        other_identity = RuntimeIdentity(self.player_uuid, other.identity.run_uuid, "actor:player")
        other_registry.register(other_identity, actor_definition_id="actor-def:player")
        with self.assertRaisesRegex(Stage9ActorContextError, "ACTOR_REGISTRY_RUN_MISMATCH"):
            ActorContextProjector(self.session, other_registry, self.identity)
        with self.assertRaises(Stage9ActorContextError):
            ActorContextProjector(self.session, self.registry, other_identity)

    def test_context_and_nested_projection_are_immutable(self):
        self._commit_visible_runtime({"actor:player": {"status_flags": ["alert"]}})
        ctx = self.projector.project()
        with self.assertRaises(FrozenInstanceError):
            ctx.world_time = 3  # type: ignore[misc]
        self.assertIsInstance(ctx.runtime_visible[0].value, tuple)

    def test_context_fingerprint_is_stable_and_changes_with_visible_context(self):
        first = self.projector.project()
        second = self.projector.project()
        self.assertEqual(first.context_fingerprint, second.context_fingerprint)
        self._commit_visible_runtime({"actor:player": {"energy": 3}})
        third = self.projector.project()
        self.assertNotEqual(first.context_fingerprint, third.context_fingerprint)
        self.assertNotEqual(first.state_revision, third.state_revision)

    def test_save_load_preserves_projected_context_and_fingerprint(self):
        self._commit(Domain.ACTOR_KNOWLEDGE, "fact.own", {"value": "alpha"}, writer=Authority.KNOWLEDGE_ROUTER, actor_id="actor:player")
        self._commit_visible_runtime({"actor:player": {"location_ref": "room:a", "energy": 7}})
        before = self.projector.project()
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(Path(td))
            repo.save(self.session)
            ident = self.session.identity
            self.manager.close_run(player_uuid=ident.player_uuid, run_uuid=ident.run_uuid)
            loaded = repo.load_session(self.manager, ident)
            loaded_registry = RunActorRegistry(loaded)
            loaded_projector = ActorContextProjector(loaded, loaded_registry, self.identity)
            after = loaded_projector.project()
        self.assertEqual(after, before)

    def test_real_9a019_knowledge_is_consumed_without_internal_metadata_leak(self):
        self._commit_perception_inputs({"input:door": self._visual_record()})
        observation = self.reader.project(perception_input_id="input:door", subject_ref="object:door")
        receipt = PerceptionKnowledgePath(self.session, self.registry, self.identity).commit_observation(observation)
        self.assertEqual(receipt.status.value, "COMMITTED")
        ctx = self.projector.project()
        self.assertEqual(len(ctx.knowledge), 1)
        exposed = repr(ctx)
        self.assertNotIn("source_event_id", exposed)
        self.assertNotIn("provenance", exposed)
        self.assertNotIn("epistemic", exposed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
