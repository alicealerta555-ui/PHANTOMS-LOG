from __future__ import annotations

import unittest
from uuid import uuid4

from runtime.stage3c.isolation import RunIdentity, RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.entry import Stage9EntryError, require_runtime_identity
from runtime.stage9.identity import RuntimeIdentity


class Stage9EntryBoundaryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.player_uuid = str(uuid4())
        self.manager = RunSessionManager(master_seed=20260911)
        self.session = self.manager.create_run(player_uuid=self.player_uuid)
        self.run_uuid = self.session.identity.run_uuid
        self.bound = RunIdentity(self.player_uuid, self.run_uuid)
        self.registry = RunActorRegistry(self.session)
        self.runtime_identity = RuntimeIdentity(
            self.player_uuid,
            self.run_uuid,
            "actor:main",
        )
        self.registry.register(self.runtime_identity, actor_definition_id="def.player")

    def _require(self, runtime_identity):
        return require_runtime_identity(
            runtime_identity,
            bound_run_identity=self.bound,
            actor_registry=self.registry,
        )

    def test_accepts_explicit_matching_registered_runtime_identity(self):
        result = self._require(self.runtime_identity)
        self.assertIs(result, self.runtime_identity)

    def test_missing_runtime_identity_fails_closed_no_fallback(self):
        with self.assertRaisesRegex(Stage9EntryError, "MISSING_RUNTIME_IDENTITY"):
            self._require(None)

    def test_mapping_is_not_implicitly_converted_at_authoritative_entry(self):
        with self.assertRaisesRegex(Stage9EntryError, "INVALID_RUNTIME_IDENTITY"):
            self._require(self.runtime_identity.as_dict())

    def test_run_identity_alone_is_not_enough(self):
        with self.assertRaisesRegex(Stage9EntryError, "INVALID_RUNTIME_IDENTITY"):
            self._require(self.bound)

    def test_wrong_player_fails_closed(self):
        wrong = RuntimeIdentity(str(uuid4()), self.run_uuid, "actor:main")
        with self.assertRaisesRegex(Stage9EntryError, "PLAYER_IDENTITY_MISMATCH"):
            self._require(wrong)

    def test_wrong_run_fails_closed(self):
        wrong = RuntimeIdentity(self.player_uuid, str(uuid4()), "actor:main")
        with self.assertRaisesRegex(Stage9EntryError, "RUN_IDENTITY_MISMATCH"):
            self._require(wrong)

    def test_unregistered_actor_same_run_fails_closed(self):
        other_actor_same_run = RuntimeIdentity(
            self.player_uuid,
            self.run_uuid,
            "actor:other",
        )
        with self.assertRaisesRegex(Stage9EntryError, "ACTOR_NOT_REGISTERED_IN_RUN"):
            self._require(other_actor_same_run)

    def test_actor_registered_in_other_run_cannot_enter_bound_run(self):
        other_session = self.manager.create_run(player_uuid=self.player_uuid)
        other_registry = RunActorRegistry(other_session)
        other = RuntimeIdentity(
            self.player_uuid,
            other_session.identity.run_uuid,
            "actor:other",
        )
        other_registry.register(other)
        forged = RuntimeIdentity(self.player_uuid, self.run_uuid, "actor:other")
        with self.assertRaisesRegex(Stage9EntryError, "ACTOR_NOT_REGISTERED_IN_RUN"):
            self._require(forged)

    def test_registry_bound_to_other_run_is_rejected(self):
        other_session = self.manager.create_run(player_uuid=self.player_uuid)
        other_registry = RunActorRegistry(other_session)
        with self.assertRaisesRegex(Stage9EntryError, "ACTOR_REGISTRY_RUN_MISMATCH"):
            require_runtime_identity(
                self.runtime_identity,
                bound_run_identity=self.bound,
                actor_registry=other_registry,
            )

    def test_invalid_registry_is_rejected(self):
        with self.assertRaisesRegex(Stage9EntryError, "INVALID_ACTOR_REGISTRY"):
            require_runtime_identity(
                self.runtime_identity,
                bound_run_identity=self.bound,
                actor_registry=None,  # type: ignore[arg-type]
            )

    def test_invalid_bound_identity_is_rejected(self):
        with self.assertRaisesRegex(Stage9EntryError, "INVALID_BOUND_RUN_IDENTITY"):
            require_runtime_identity(
                self.runtime_identity,
                bound_run_identity={"player_uuid": self.player_uuid},  # type: ignore[arg-type]
                actor_registry=self.registry,
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
