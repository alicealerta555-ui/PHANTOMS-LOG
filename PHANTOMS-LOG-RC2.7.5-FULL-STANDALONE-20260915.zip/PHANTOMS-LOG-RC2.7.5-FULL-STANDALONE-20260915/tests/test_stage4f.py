import unittest
from dataclasses import fields, replace

from runtime.stage4b import (
    EnvironmentalEnvelope, GenelineRecord, HybridizationProfile, KnownBiologicalConstraint,
    LineageProvenance, MetabolismProfile, MorphologyProfile, OriginPackageLink,
    RegenerationProfile, StabilityProfile,
)
from runtime.stage4c import bind_origin_packages, build_canonical_origin_registry
from runtime.stage4e import (
    BranchProfile, BranchProvenance, CognitiveAssessment, CognitiveBranch,
    DevelopmentalBranchEvidence, classify_branch,
)
from runtime.stage4f import (
    BehavioralEcho, BiologicalDisposition, CognitiveDomain, CognitiveDriftProfile,
    CognitiveDriftRegistry, ContextInfluence, DriftProvenance, InfluenceContext,
    InfluenceLayer, InfluenceEnvelope, MAX_BEHAVIORAL_ECHO_STRENGTH, MAX_BIOLOGICAL_SIGNAL_STRENGTH,
    ResponseLayer, evaluate_influence_envelope, validate_cognitive_drift_profile,
    validate_influence_context,
)


def base_lineage(lineage_id="LINEAGE_4F", phase="B6", epoch="E5"):
    return GenelineRecord(
        lineage_id=lineage_id,
        display_name=lineage_id,
        origin_packages=OriginPackageLink(),
        morphology=MorphologyProfile(("bilateral",)),
        metabolism=MetabolismProfile(("heterotrophic",), energetic_cost_tags=("finite_energy",)),
        environment=EnvironmentalEnvelope(("temperate",)),
        regeneration=RegenerationProfile("NONE"),
        sensor_hooks=(),
        stability=StabilityProfile(),
        hybridization=HybridizationProfile((), 0),
        known_constraints=(KnownBiologicalConstraint(f"C_{lineage_id}", "energy", "Finite energetic budget."),),
        provenance=LineageProvenance(phase, epoch, ("STAGE4F_TEST",)),
    )


def bound_lineage(lineage_id="LINEAGE_4F", packages=("ORG_MAMMALIAN_HOMEOSTASIS",)):
    registry = build_canonical_origin_registry()
    return bind_origin_packages(base_lineage(lineage_id), packages, registry), registry


def bio(signal_id="BIO_ALERT", domain=CognitiveDomain.ATTENTIONAL_SALIENCE, strength=0.2, triggers=("ambiguous_motion",), response=ResponseLayer.COGNITIVE):
    return BiologicalDisposition(signal_id, domain, response, strength, tuple(triggers), (f"E_{signal_id}",), "population-level bounded disposition")


def echo(echo_id="ECHO_WATCH", domain=CognitiveDomain.ATTENTIONAL_SALIENCE, strength=0.15, triggers=("ambiguous_motion",), bio_refs=("BIO_ALERT",), culture_refs=("CULT_WATCH",), response=ResponseLayer.COGNITIVE):
    return BehavioralEcho(echo_id, domain, response, strength, tuple(triggers), tuple(bio_refs), tuple(culture_refs), (f"E_{echo_id}",), "bio-cultural echo, not a chosen action")


def profile(lineage, bios=None, echoes=()):
    if bios is None:
        bios = (bio(),)
    return CognitiveDriftProfile(lineage.lineage_id, tuple(bios), tuple(echoes), DriftProvenance(("STAGE4F_TEST",)))


def ctx_signal(signal_id, layer, domain, strength, response=ResponseLayer.COGNITIVE):
    return ContextInfluence(signal_id, layer, domain, response, strength, (f"E_{signal_id}",), "context contribution")


class Stage4FTests(unittest.TestCase):
    def test_valid_profile_accepts_bounded_biological_disposition(self):
        lineage, registry = bound_lineage()
        validate_cognitive_drift_profile(lineage, profile(lineage), registry)

    def test_profile_requires_biological_disposition(self):
        lineage, registry = bound_lineage()
        p = profile(lineage, bios=())
        with self.assertRaisesRegex(ValueError, "BIOLOGICAL_DISPOSITION_REQUIRED"):
            validate_cognitive_drift_profile(lineage, p, registry)

    def test_profile_lineage_mismatch_rejected(self):
        lineage, registry = bound_lineage()
        with self.assertRaisesRegex(ValueError, "COGNITIVE_DRIFT_LINEAGE_MISMATCH"):
            validate_cognitive_drift_profile(lineage, replace(profile(lineage), lineage_id="OTHER"), registry)

    def test_profile_requires_world_truth_provenance(self):
        lineage, registry = bound_lineage()
        p = replace(profile(lineage), provenance=DriftProvenance(("SRC",), "ACTOR_KNOWLEDGE"))
        with self.assertRaisesRegex(ValueError, "PROVENANCE_MUST_BE_WORLD_TRUTH"):
            validate_cognitive_drift_profile(lineage, p, registry)

    def test_profile_requires_source_provenance(self):
        lineage, registry = bound_lineage()
        p = replace(profile(lineage), provenance=DriftProvenance(()))
        with self.assertRaisesRegex(ValueError, "PROVENANCE_SOURCE_REF_REQUIRED"):
            validate_cognitive_drift_profile(lineage, p, registry)

    def test_biological_strength_is_bounded(self):
        lineage, registry = bound_lineage()
        p = profile(lineage, bios=(bio(strength=MAX_BIOLOGICAL_SIGNAL_STRENGTH + 0.001),))
        with self.assertRaisesRegex(ValueError, "BIOLOGICAL_DISPOSITION_STRENGTH:OUT_OF_BOUNDS"):
            validate_cognitive_drift_profile(lineage, p, registry)

    def test_behavioral_echo_strength_is_more_strictly_bounded(self):
        lineage, registry = bound_lineage()
        p = profile(lineage, echoes=(echo(strength=MAX_BEHAVIORAL_ECHO_STRENGTH + 0.001),))
        with self.assertRaisesRegex(ValueError, "BEHAVIORAL_ECHO_STRENGTH:OUT_OF_BOUNDS"):
            validate_cognitive_drift_profile(lineage, p, registry)

    def test_zero_strength_signal_rejected_as_noninformative(self):
        lineage, registry = bound_lineage()
        with self.assertRaisesRegex(ValueError, "ZERO_NOT_INFORMATIVE"):
            validate_cognitive_drift_profile(lineage, profile(lineage, bios=(bio(strength=0),)), registry)

    def test_biological_disposition_requires_evidence(self):
        lineage, registry = bound_lineage()
        bad = replace(bio(), evidence_refs=())
        with self.assertRaisesRegex(ValueError, "BIOLOGICAL_DISPOSITION_EVIDENCE_REF_REQUIRED"):
            validate_cognitive_drift_profile(lineage, profile(lineage, bios=(bad,)), registry)

    def test_echo_requires_biological_anchor(self):
        lineage, registry = bound_lineage()
        bad = replace(echo(), biological_disposition_refs=())
        with self.assertRaisesRegex(ValueError, "BEHAVIORAL_ECHO_BIO_REF_REQUIRED"):
            validate_cognitive_drift_profile(lineage, profile(lineage, echoes=(bad,)), registry)

    def test_echo_requires_culture_anchor(self):
        lineage, registry = bound_lineage()
        bad = replace(echo(), culture_anchor_refs=())
        with self.assertRaisesRegex(ValueError, "BEHAVIORAL_ECHO_CULTURE_REF_REQUIRED"):
            validate_cognitive_drift_profile(lineage, profile(lineage, echoes=(bad,)), registry)

    def test_echo_unknown_bio_anchor_rejected(self):
        lineage, registry = bound_lineage()
        bad = replace(echo(), biological_disposition_refs=("UNKNOWN",))
        with self.assertRaisesRegex(ValueError, "BEHAVIORAL_ECHO_UNKNOWN_BIO_DISPOSITION"):
            validate_cognitive_drift_profile(lineage, profile(lineage, echoes=(bad,)), registry)

    def test_duplicate_signal_ids_rejected_across_dispositions_and_echoes(self):
        lineage, registry = bound_lineage()
        bad_echo = replace(echo(), echo_id="BIO_ALERT")
        with self.assertRaisesRegex(ValueError, "COGNITIVE_DRIFT_DUPLICATE_SIGNAL_ID"):
            validate_cognitive_drift_profile(lineage, profile(lineage, echoes=(bad_echo,)), registry)

    def test_forbidden_behavior_tag_cannot_be_smuggled_through_trigger(self):
        lineage, registry = bound_lineage()
        bad = bio(triggers=("behavior:attack",))
        with self.assertRaisesRegex(ValueError, "GENETIC_DETERMINISM_TAG_FORBIDDEN"):
            validate_cognitive_drift_profile(lineage, profile(lineage, bios=(bad,)), registry)

    def test_context_layer_mismatch_rejected(self):
        signal = ctx_signal("CULT", InfluenceLayer.INDIVIDUAL_PSYCHOLOGY, CognitiveDomain.ATTENTIONAL_SALIENCE, 0.2)
        with self.assertRaisesRegex(ValueError, "CONTEXT_LAYER_MISMATCH"):
            validate_influence_context(InfluenceContext(culture_history=(signal,)))

    def test_context_duplicate_ids_rejected_across_layers(self):
        a = ctx_signal("DUP", InfluenceLayer.CULTURE_HISTORY, CognitiveDomain.ATTENTIONAL_SALIENCE, 0.2)
        b = ctx_signal("DUP", InfluenceLayer.CURRENT_SITUATION, CognitiveDomain.ATTENTIONAL_SALIENCE, -0.2)
        with self.assertRaisesRegex(ValueError, "CONTEXT_INFLUENCE_DUPLICATE_ID"):
            validate_influence_context(InfluenceContext(culture_history=(a,), current_situation=(b,)))

    def test_biology_activates_only_when_trigger_context_matches(self):
        lineage, registry = bound_lineage()
        env_off = evaluate_influence_envelope(lineage, profile(lineage), registry, InfluenceContext(situation_tags=("quiet",)))
        env_on = evaluate_influence_envelope(lineage, profile(lineage), registry, InfluenceContext(situation_tags=("ambiguous_motion",)))
        self.assertEqual(len(env_off.contributions), 0)
        self.assertEqual([c.contribution_id for c in env_on.contributions], ["BIO_ALERT"])

    def test_echo_requires_biology_culture_and_trigger_together(self):
        lineage, registry = bound_lineage()
        p = profile(lineage, echoes=(echo(),))
        culture = ctx_signal("CULT_WATCH", InfluenceLayer.CULTURE_HISTORY, CognitiveDomain.ATTENTIONAL_SALIENCE, 0.1)
        no_culture = evaluate_influence_envelope(lineage, p, registry, InfluenceContext(situation_tags=("ambiguous_motion",)))
        with_culture = evaluate_influence_envelope(lineage, p, registry, InfluenceContext(culture_history=(culture,), situation_tags=("ambiguous_motion",)))
        self.assertNotIn("ECHO_WATCH", [c.contribution_id for c in no_culture.contributions])
        self.assertIn("ECHO_WATCH", [c.contribution_id for c in with_culture.contributions])

    def test_echo_does_not_activate_when_its_biological_anchor_trigger_is_inactive(self):
        lineage, registry = bound_lineage()
        p = profile(lineage, echoes=(echo(triggers=("quiet",)),))
        culture = ctx_signal("CULT_WATCH", InfluenceLayer.CULTURE_HISTORY, CognitiveDomain.ATTENTIONAL_SALIENCE, 0.1)
        env = evaluate_influence_envelope(lineage, p, registry, InfluenceContext(culture_history=(culture,), situation_tags=("quiet",)))
        self.assertNotIn("ECHO_WATCH", [c.contribution_id for c in env.contributions])

    def test_causal_layers_are_retained_as_separate_contributions(self):
        lineage, registry = bound_lineage()
        culture = ctx_signal("CULT_WATCH", InfluenceLayer.CULTURE_HISTORY, CognitiveDomain.ATTENTIONAL_SALIENCE, 0.1)
        individual = ctx_signal("IND_VALUE", InfluenceLayer.INDIVIDUAL_PSYCHOLOGY, CognitiveDomain.ATTENTIONAL_SALIENCE, -0.3)
        situation = ctx_signal("SIT_RISK", InfluenceLayer.CURRENT_SITUATION, CognitiveDomain.ATTENTIONAL_SALIENCE, 0.25)
        p = profile(lineage, echoes=(echo(),))
        env = evaluate_influence_envelope(lineage, p, registry, InfluenceContext((culture,), (individual,), (situation,), ("ambiguous_motion",)))
        layers = {c.layer for c in env.contributions}
        self.assertEqual(layers, {InfluenceLayer.BIOLOGICAL_DISPOSITION, InfluenceLayer.BEHAVIORAL_ECHO, InfluenceLayer.CULTURE_HISTORY, InfluenceLayer.INDIVIDUAL_PSYCHOLOGY, InfluenceLayer.CURRENT_SITUATION})

    def test_opposing_pressures_are_preserved_as_unresolved_conflict(self):
        lineage, registry = bound_lineage()
        individual = ctx_signal("IND_CALM", InfluenceLayer.INDIVIDUAL_PSYCHOLOGY, CognitiveDomain.ATTENTIONAL_SALIENCE, -0.2)
        env = evaluate_influence_envelope(lineage, profile(lineage), registry, InfluenceContext(individual_psychology=(individual,), situation_tags=("ambiguous_motion",)))
        pressure = env.domain_pressures[0]
        self.assertTrue(pressure.has_internal_conflict)
        self.assertTrue(env.unresolved_conflicts)
        self.assertEqual(set(pressure.contribution_ids), {"BIO_ALERT", "IND_CALM"})

    def test_exact_opposition_does_not_erase_source_evidence(self):
        lineage, registry = bound_lineage()
        individual = ctx_signal("IND_CALM", InfluenceLayer.INDIVIDUAL_PSYCHOLOGY, CognitiveDomain.ATTENTIONAL_SALIENCE, -0.2)
        env = evaluate_influence_envelope(lineage, profile(lineage), registry, InfluenceContext(individual_psychology=(individual,), situation_tags=("ambiguous_motion",)))
        self.assertEqual(env.domain_pressures[0].net_pressure, 0.0)
        self.assertEqual(len(env.contributions), 2)

    def test_evaluation_selects_no_behavior(self):
        lineage, registry = bound_lineage()
        env = evaluate_influence_envelope(lineage, profile(lineage), registry, InfluenceContext(situation_tags=("ambiguous_motion",)))
        self.assertEqual(env.resolution_status, "INFLUENCE_ONLY_NO_BEHAVIOR_SELECTED")
        self.assertEqual(env.decision_owner, "INDIVIDUAL_ACTOR_RUNTIME")
        self.assertFalse(hasattr(env, "behavior"))
        self.assertFalse(hasattr(env, "chosen_action"))

    def test_physiological_and_cognitive_pressures_remain_distinct(self):
        lineage, registry = bound_lineage()
        bios = (
            bio("BIO_COG", CognitiveDomain.ATTENTIONAL_SALIENCE, 0.2, ("trigger",), ResponseLayer.COGNITIVE),
            bio("BIO_PHYS", CognitiveDomain.ACTIVATION_THRESHOLD, -0.2, ("trigger",), ResponseLayer.PHYSIOLOGICAL),
        )
        env = evaluate_influence_envelope(lineage, profile(lineage, bios=bios), registry, InfluenceContext(situation_tags=("trigger",)))
        self.assertEqual({p.response_layer for p in env.domain_pressures}, {ResponseLayer.COGNITIVE, ResponseLayer.PHYSIOLOGICAL})

    def test_4e_drift_branch_does_not_auto_create_4f_signal(self):
        lineage, registry = bound_lineage()
        bprofile = BranchProfile(lineage.lineage_id, CognitiveAssessment(CognitiveBranch.UNASSESSED), DevelopmentalBranchEvidence(drift_evidence_refs=("DRIFT_HISTORY",)), BranchProvenance(("SRC",)))
        classification = classify_branch(lineage, bprofile, registry)
        self.assertTrue(classification.is_drift)
        # 4F still requires explicit evidence-backed disposition records.
        with self.assertRaisesRegex(ValueError, "BIOLOGICAL_DISPOSITION_REQUIRED"):
            validate_cognitive_drift_profile(lineage, profile(lineage, bios=()), registry)

    def test_non_drift_branch_can_have_evidence_backed_4f_profile(self):
        lineage, registry = bound_lineage()
        bprofile = BranchProfile(lineage.lineage_id, CognitiveAssessment(CognitiveBranch.SAPIENT, ("OBS",), "longitudinal"), DevelopmentalBranchEvidence(), BranchProvenance(("SRC",)))
        classification = classify_branch(lineage, bprofile, registry)
        self.assertFalse(classification.is_drift)
        validate_cognitive_drift_profile(lineage, profile(lineage), registry)

    def test_morphology_does_not_change_4f_evaluation(self):
        lineage, registry = bound_lineage()
        altered = replace(lineage, morphology=MorphologyProfile(("very_different_body_plan",), ("winged",), ("armored",)))
        a = evaluate_influence_envelope(lineage, profile(lineage), registry, InfluenceContext(situation_tags=("ambiguous_motion",)))
        b = evaluate_influence_envelope(altered, replace(profile(lineage), lineage_id=altered.lineage_id), registry, InfluenceContext(situation_tags=("ambiguous_motion",)))
        self.assertEqual(a.domain_pressures, b.domain_pressures)

    def test_context_strength_can_outweigh_biology_without_overwriting_it(self):
        lineage, registry = bound_lineage()
        individual = ctx_signal("IND_STRONG", InfluenceLayer.INDIVIDUAL_PSYCHOLOGY, CognitiveDomain.ATTENTIONAL_SALIENCE, -0.9)
        env = evaluate_influence_envelope(lineage, profile(lineage), registry, InfluenceContext(individual_psychology=(individual,), situation_tags=("ambiguous_motion",)))
        self.assertLess(env.domain_pressures[0].net_pressure, 0)
        self.assertIn("BIO_ALERT", env.domain_pressures[0].contribution_ids)

    def test_context_order_does_not_change_result(self):
        lineage, registry = bound_lineage()
        a = ctx_signal("CULT_A", InfluenceLayer.CULTURE_HISTORY, CognitiveDomain.NOVELTY_SALIENCE, 0.2)
        b = ctx_signal("CULT_B", InfluenceLayer.CULTURE_HISTORY, CognitiveDomain.NOVELTY_SALIENCE, -0.1)
        env1 = evaluate_influence_envelope(lineage, profile(lineage), registry, InfluenceContext(culture_history=(a,b), situation_tags=("ambiguous_motion",)))
        env2 = evaluate_influence_envelope(lineage, profile(lineage), registry, InfluenceContext(culture_history=(b,a), situation_tags=("ambiguous_motion",)))
        self.assertEqual(env1, env2)

    def test_registry_rejects_duplicate_lineage(self):
        lineage, registry = bound_lineage()
        r = CognitiveDriftRegistry(); r.register(lineage, profile(lineage), registry)
        with self.assertRaisesRegex(ValueError, "COGNITIVE_DRIFT_PROFILE_DUPLICATE_LINEAGE"):
            r.register(lineage, profile(lineage), registry)

    def test_registry_digest_is_registration_order_independent(self):
        a, registry = bound_lineage("A")
        b, _ = bound_lineage("B")
        ra = CognitiveDriftRegistry(); ra.register(a, profile(a), registry); ra.register(b, profile(b, bios=(bio("BIO_B"),)), registry)
        rb = CognitiveDriftRegistry(); rb.register(b, profile(b, bios=(bio("BIO_B"),)), registry); rb.register(a, profile(a), registry)
        self.assertEqual(ra.canonical_digest(), rb.canonical_digest())

    def test_registry_digest_normalizes_signal_and_ref_order(self):
        lineage, registry = bound_lineage()
        b1 = bio("B1", triggers=("z","a")); b2 = bio("B2", CognitiveDomain.NOVELTY_SALIENCE, -0.1, ("x",))
        e = echo("E1", bio_refs=("B2","B1"), culture_refs=("C2","C1"), triggers=("z","a"))
        p1 = CognitiveDriftProfile(lineage.lineage_id, (b1,b2), (e,), DriftProvenance(("Z","A")))
        p2 = CognitiveDriftProfile(lineage.lineage_id, (replace(b2), replace(b1, trigger_tags=("a","z"))), (replace(e, biological_disposition_refs=("B1","B2"), culture_anchor_refs=("C1","C2"), trigger_tags=("a","z")),), DriftProvenance(("A","Z")))
        r1=CognitiveDriftRegistry(); r1.register(lineage,p1,registry)
        r2=CognitiveDriftRegistry(); r2.register(lineage,p2,registry)
        self.assertEqual(r1.canonical_digest(), r2.canonical_digest())

    def test_schema_contains_no_action_choice_morality_consent_fields(self):
        names = set()
        for cls in (BiologicalDisposition, BehavioralEcho, CognitiveDriftProfile, ContextInfluence, InfluenceEnvelope):
            names |= {f.name for f in fields(cls)}
        forbidden = {"morality", "personality", "consent", "attraction", "dominance", "submission", "profession", "loyalty", "obedience", "hostility", "behavior", "chosen_action", "decision"}
        self.assertFalse(names & forbidden)

    def test_evaluation_does_not_mutate_lineage_or_profile(self):
        lineage, registry = bound_lineage()
        p = profile(lineage, echoes=(echo(),))
        before = (lineage, p)
        culture = ctx_signal("CULT_WATCH", InfluenceLayer.CULTURE_HISTORY, CognitiveDomain.ATTENTIONAL_SALIENCE, 0.1)
        evaluate_influence_envelope(lineage, p, registry, InfluenceContext(culture_history=(culture,), situation_tags=("ambiguous_motion",)))
        self.assertEqual(before, (lineage, p))

    def test_net_pressure_clamps_but_contributions_are_not_discarded(self):
        lineage, registry = bound_lineage()
        signals = tuple(ctx_signal(f"S{i}", InfluenceLayer.CURRENT_SITUATION, CognitiveDomain.ATTENTIONAL_SALIENCE, 1.0) for i in range(3))
        env = evaluate_influence_envelope(lineage, profile(lineage), registry, InfluenceContext(current_situation=signals, situation_tags=("ambiguous_motion",)))
        pressure = next(p for p in env.domain_pressures if p.domain == CognitiveDomain.ATTENTIONAL_SALIENCE)
        self.assertEqual(pressure.net_pressure, 1.0)
        self.assertEqual(len(pressure.contribution_ids), 4)


if __name__ == "__main__":
    unittest.main()
