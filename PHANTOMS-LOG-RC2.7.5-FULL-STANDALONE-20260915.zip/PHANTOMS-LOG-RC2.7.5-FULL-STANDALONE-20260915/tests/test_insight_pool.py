from runtime.player_progression import (
    PlayerProgressionState, InsightResolver, INSIGHTS,
    PlayerLearningRuntime, RawActionEvent
)


def test_catalog_has_96_insights():
    assert len(INSIGHTS) == 96
    assert sum(1 for x in INSIGHTS.values() if x.hybrid) == 32


def test_locked_chain_requires_predecessor():
    s = PlayerProgressionState('p','r','GHOST')
    s.affinities['AFF_STEALTH'] = 999
    s.pattern_evidence['sneak'] = 999
    resolver = InsightResolver()
    assert resolver.candidate(s, 'stealth_noise_mask') is None
    s.unlocked_insights.append('stealth_soft_step')
    assert resolver.candidate(s, 'stealth_noise_mask') is not None


def test_contextual_unlock_only_on_matching_action():
    s = PlayerProgressionState('p','r','GHOST')
    s.affinities['AFF_STEALTH'] = 50
    s.pattern_evidence['sneak'] = 50
    resolver = InsightResolver()
    assert resolver.unlock_best(s, 'repair') is None
    d = resolver.unlock_best(s, 'sneak')
    assert d is not None
    assert d.insight_id == 'stealth_soft_step'


def test_hybrid_requires_both_sides():
    s = PlayerProgressionState('p','r','BREAKER')
    s.affinities['AFF_FORCE'] = 100
    s.affinities['AFF_TECH'] = 1
    s.pattern_evidence['repair'] = 100
    resolver = InsightResolver()
    c = resolver.candidate(s, 'hyb_field_armorer')
    assert c is not None and c.readiness < 1.0
    s.affinities['AFF_TECH'] = 100
    assert resolver.candidate(s, 'hyb_field_armorer').readiness >= 1.0


def test_player_unlock_payload_contains_no_numbers():
    d = INSIGHTS['tech_fault_sound']
    payload = InsightResolver().player_visible_unlock(d)
    assert set(payload) == {'kind','name','description','effect_key'}
    assert not any(isinstance(v, (int,float)) for v in payload.values())


def test_runtime_emits_at_most_one_unlock_per_event():
    s = PlayerProgressionState('p','r','GHOST')
    s.affinities['AFF_STEALTH'] = 100
    s.pattern_evidence['sneak'] = 100
    rt = PlayerLearningRuntime(s)
    rt.observe(RawActionEvent('sneak', {'AFF_STEALTH':1.0}, location_id='A', difficulty_hint=1.0, consequence_hint=1.0))
    unlocks = rt.drain_unlocks()
    assert len(unlocks) <= 1


def test_npc_event_cannot_unlock():
    s = PlayerProgressionState('p','r','OPERATOR')
    s.affinities['AFF_TECH'] = 100
    s.pattern_evidence['repair'] = 100
    rt = PlayerLearningRuntime(s)
    assert not rt.observe(RawActionEvent('repair', {'AFF_TECH':1.0}, actor_is_player=False))
    assert rt.drain_unlocks() == []
