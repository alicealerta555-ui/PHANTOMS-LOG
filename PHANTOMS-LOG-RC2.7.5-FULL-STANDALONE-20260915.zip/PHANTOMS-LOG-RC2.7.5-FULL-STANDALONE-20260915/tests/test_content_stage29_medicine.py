
import json, unittest
from pathlib import Path
from runtime.content_stage29.medicine import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage29_medicine_health.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_conditions(self):
  self.assertGreaterEqual(len(D["condition_profiles"]),4)

 def test_infection_requires_causal_exposure(self):
  self.assertIsNone(infection_candidate("COND","a","","air",1,None))

 def test_infection_authority(self):
  p=infection_candidate("COND","a","EV","air",1,"b")
  self.assertTrue(p["authority_required"])

 def test_diagnosis_not_truth(self):
  m=D["diagnostic_methods"][1]
  d=diagnosis_candidate("a","COND",m,2,0,1)
  self.assertFalse(d["confirmed_truth"])

 def test_diagnosis_uncertainty(self):
  m=D["diagnostic_methods"][0]
  a=diagnosis_candidate("a","COND",m,3,0,1)["confidence"]
  b=diagnosis_candidate("a","COND",m,3,3,1)["confidence"]
  self.assertGreater(a,b)

 def test_treatment_requires_resources(self):
  t=D["treatment_profiles"][1]
  self.assertIsNone(treatment_candidate("a",t,False,60,100,"EV"))

 def test_targeted_treatment_depends_on_diagnosis(self):
  t=next(x for x in D["treatment_profiles"] if x["id"]=="TX_TARGETED")
  a=treatment_candidate("a",t,True,60,100,"EV")["effect_bp"]
  b=treatment_candidate("a",t,True,60,20,"EV")["effect_bp"]
  self.assertGreater(a,b)

 def test_progression_uses_time(self):
  self.assertEqual(progression_projection(10,12,0,0),10)
  self.assertGreater(progression_projection(10,12,1440,0),10)

 def test_recovery_bounded(self):
  self.assertEqual(recovery_projection(5,100,1440),0)

 def test_chronic_authority(self):
  p=chronic_consequence_candidate("COND","a",20,1000,"EV")
  self.assertTrue(p["authority_required"])

if __name__=="__main__": unittest.main()
