from pathlib import Path
import tempfile
from playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, Domain

ROOT=Path(__file__).resolve().parents[1]

def make_game(tmp):
    g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class='OPERATOR',master_seed=20260913)
    g.complete_character(g.creation_template())
    return g


def move_to(g,target):
    from collections import deque
    start=g.location(); q=deque([start]); parent={start:None}
    while q:
        cur=q.popleft()
        if cur==target: break
        for nxt in g.catalog.location(cur)['connections']:
            if nxt not in parent: parent[nxt]=cur; q.append(nxt)
    path=[]; cur=target
    while cur!=start: path.append(cur); cur=parent[cur]
    for dest in reversed(path): g.execute(action_type='MOVE',raw_input='test move',parameters={'destination_location_id':dest})

def colocated_merchant(g):
    actor=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,'actor:player')
    for key in g.session.store.runtime_state:
        if str(key).startswith('actor:npc:'):
            rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
            if rec.get('role')=='merchant':
                # move player through test-only direct setup is forbidden; instead return merchant if present
                if rec.get('location_ref')==actor.get('location_ref'): return key
    return None

def test_npc_item_query_uses_real_inventory_only():
    with tempfile.TemporaryDirectory() as tmp:
        g=make_game(tmp)
        # move legally to any NPC and query a known real inventory entry
        npc=next(k for k in g.session.store.runtime_state if str(k).startswith('actor:npc:'))
        nrec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,npc)
        move_to(g,nrec['location_ref'])
        assert any(x['actor_instance_id']==npc for x in g.actors_here())
        records=[]
        for key in g.session.store.runtime_state:
            rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
            if isinstance(rec,dict) and rec.get('kind')=='item' and rec.get('location_ref')==f'inventory:{npc}': records.append(rec)
        assert records
        d=g.catalog.item_definition(records[0]['item_definition_id'])
        text=g.ask_npc_for_item(npc,d['kind'])
        assert d['display_name'] in text
        assert 'nichts Passendes' in g.ask_npc_for_item(npc,'definitely-not-an-item')

def test_buy_transfer_updates_owner():
    with tempfile.TemporaryDirectory() as tmp:
        g=make_game(tmp)
        # relocate to first merchant using connected-path moves
        merchants=[]
        for key in g.session.store.runtime_state:
            if str(key).startswith('actor:npc:'):
                rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
                if rec.get('role')=='merchant': merchants.append((key,rec['location_ref']))
        mid,target=merchants[0]
        move_to(g,target)
        stock=g.merchant_stock(mid); assert stock
        iid=stock[0]['instance_id']
        r=g.execute(action_type='TRADE_BUY',raw_input='buy',target_refs=(iid,mid))
        assert r.status.value in {'COMMITTED','IDEMPOTENT'}
        item=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
        assert item['owner_actor_instance_id']=='actor:player'
        assert item['merchant_stock'] is False
        text=g.sell_item(iid,mid)
        assert 'TRADE_SELL_OK' in text
        item2=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
        assert item2['owner_actor_instance_id']==mid
        assert item2['merchant_stock'] is True
