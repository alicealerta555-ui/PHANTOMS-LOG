from pathlib import Path
import tempfile, pytest
from playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, Domain
from runtime.full_version.bootstrap import PLAYER_ACTOR_INSTANCE_ID
from runtime.full_version.progression_quest_runtime import ProgressionQuestRuntime, PersistentQuestGroupRuntime, ProgressionQuestRuntimeError
ROOT=Path(__file__).resolve().parents[1]
def game(tmp,cls='OPERATOR'):
 g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class=cls,master_seed=20260915); g.complete_character(g.creation_template()); return g
def npc(g):
 for k in g.session.store.runtime_state:
  if str(k).startswith('actor:npc:') and isinstance(g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,k),dict): return k
 raise AssertionError

def test_class_quest_world_bound_and_failure_persists():
 with tempfile.TemporaryDirectory() as tmp:
  g=game(tmp); n=npc(g); r=ProgressionQuestRuntime(g.catalog,g.session); qid,_=r.materialize_class_quest('CQ_OPERATOR_CORE_01',actor_id=PLAYER_ACTOR_INSTANCE_ID,world_ref=n,evidence_ref=n); q=r.resolve(qid,outcome='FAILURE',evidence_ref=n); assert q['state']=='FAILED'
def test_class_quest_cannot_fabricate_world_binding():
 with tempfile.TemporaryDirectory() as tmp:
  g=game(tmp); r=ProgressionQuestRuntime(g.catalog,g.session)
  with pytest.raises(ProgressionQuestRuntimeError,match='WORLD_BINDING_REQUIRED'): r.materialize_class_quest('CQ_OPERATOR_CORE_01',actor_id=PLAYER_ACTOR_INSTANCE_ID,world_ref='missing',evidence_ref='missing')
def test_legend_failure_never_revokes_path():
 with tempfile.TemporaryDirectory() as tmp:
  g=game(tmp); n=npc(g); r=ProgressionQuestRuntime(g.catalog,g.session); sid=r.content.legend_candidates('THE_SWARM')[0]['scenario_id']; qid,_=r.materialize_legend(sid,actor_id=PLAYER_ACTOR_INSTANCE_ID,world_refs=[n],evidence_refs=[n],end_path='THE_SWARM'); q=r.resolve(qid,outcome='CRITICAL_FAILURE',evidence_ref=n); assert q['state']=='FAILED' and q['path_revocation_on_failure'] is False
def test_group_state_persists_without_reset():
 with tempfile.TemporaryDirectory() as tmp:
  g=game(tmp,'GHOST'); n=npc(g); r=PersistentQuestGroupRuntime(g.catalog,g.session); r.ensure('QG_03',location_ref=n,evidence_ref=n); r.update('QG_03',state='work',experience_delta=3,evidence_ref=n); _,x=r.ensure('QG_03',location_ref=n,evidence_ref=n); assert x['state']=='work' and x['experience']==3 and len(x['history'])==2
