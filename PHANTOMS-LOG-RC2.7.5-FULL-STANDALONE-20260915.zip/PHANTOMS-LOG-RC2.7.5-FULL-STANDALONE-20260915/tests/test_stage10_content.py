from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from uuid import uuid4

from runtime.full_version import FullVersionCatalog
from runtime.stage3c.isolation import FilesystemRunRepository, RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import AuthorityStatus, StateAuthority
from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.world_time import WorldTimeCommitAdapter, WorldClock
from runtime.stage10.creatures import CreatureProfileRegistry
from runtime.stage10.encounter import EncounterEngine, EncounterStance
from runtime.stage10.state import Stage10CommitAdapter, Stage10WorldView
from runtime.stage10.ecology import RecolonizationPlanner, RecolonizationProcessor
from runtime.stage9.actor_context import ActorDecisionContext

ROOT=Path(__file__).resolve().parents[1]


class Stage10ContentTests(unittest.TestCase):
    def setUp(self):
        self.catalog=FullVersionCatalog.load(ROOT)
        self.manager=RunSessionManager(master_seed=20260912)
        self.session=self.manager.create_run(player_uuid=str(uuid4()))
        self.registry=RunActorRegistry(self.session)
        self.registry.register(RuntimeIdentity(self.session.identity.player_uuid,self.session.identity.run_uuid,'actor:observer'),actor_definition_id='actor-def:observer')
        self.authority=StateAuthority(self.session,actor_registry=self.registry)
        self.adapter=Stage10CommitAdapter(self.session,dungeon_definitions=self.catalog.dungeons)

    def effect(self,typ,target,payload,eid='effect:s10:1'):
        return EffectProposal(effect_id=eid,run_uuid=self.session.identity.run_uuid,resolution_id='resolution:s10',source_action_id='action:s10',effect_type=typ,target_ref=target,payload=payload,authority_domain={
            EffectType.DUNGEON_OCCUPANCY_SET:AuthorityDomain.DUNGEON,
            EffectType.DUNGEON_TRACE_APPEND:AuthorityDomain.DUNGEON,
            EffectType.ECOLOGY_RESOURCE_DELTA:AuthorityDomain.ECOLOGY,
            EffectType.ECOLOGY_POPULATION_DELTA:AuthorityDomain.ECOLOGY,
            EffectType.ADVANCE_WORLD_TIME:AuthorityDomain.WORLD_TIME,
        }[typ],expected_state_revision=self.session.store.revision)

    def test_creature_profiles_bridge_branch_senses_needs(self):
        self.assertGreaterEqual(len(self.catalog.creature_registry),10)
        p=self.catalog.creature_registry.get('creature:ash_hound')
        self.assertIn('visual',p.sense_modalities); self.assertIn('food',p.needs); self.assertTrue(p.branch_classes)

    def test_encounter_cannot_target_unperceived_actor(self):
        p=self.catalog.creature_registry.get('creature:ash_hound')
        ctx=ActorDecisionContext(run_uuid=self.session.identity.run_uuid,actor_instance_id='actor:observer',actor_definition_id='actor-def:observer',state_revision=self.session.store.revision,world_time=0,knowledge=(),beliefs=(),perception=(),runtime_visible=(),context_fingerprint='f'*64)
        d=EncounterEngine().decide(p,ctx,target_ref='actor:player',resource_pressure=10)
        self.assertEqual(d.stance,EncounterStance.IGNORE); self.assertIsNone(d.target_ref)

    def test_persistent_dungeon_occupancy_and_trace(self):
        did=self.catalog.dungeons[0]['dungeon_id']
        e1=self.effect(EffectType.DUNGEON_OCCUPANCY_SET,did,{'dungeon_id':did,'occupancy':'VACANT','cause_ref':'action:test'},'effect:d:vacate')
        d1=self.authority.authorize(e1); self.assertEqual(d1.status,AuthorityStatus.ALLOW)
        self.adapter.apply_many((d1,),commit_id='commit:d:vacate',event_id='S10:D:VACATE')
        e2=self.effect(EffectType.DUNGEON_TRACE_APPEND,did,{'dungeon_id':did,'trace_id':'trace:001','trace_type':'PLAYER_CAUSED_VACANCY','source_ref':'actor:observer','world_time':WorldClock(self.session).seconds},'effect:d:trace')
        d2=self.authority.authorize(e2); self.assertEqual(d2.status,AuthorityStatus.ALLOW)
        self.adapter.apply_many((d2,),commit_id='commit:d:trace',event_id='S10:D:TRACE')
        state=self.adapter.view.snapshot().dungeons[did]
        self.assertEqual(state.occupancy,'VACANT'); self.assertEqual(state.traces[0]['trace_id'],'trace:001')

    def test_ecology_population_and_resource_are_nonnegative(self):
        e=self.effect(EffectType.ECOLOGY_RESOURCE_DELTA,'dungeon:01',{'site_id':'dungeon:01','resource_key':'water','delta':5,'cause_ref':'rain'},'effect:e:water')
        d=self.authority.authorize(e); self.adapter.apply_many((d,),commit_id='commit:e:water',event_id='S10:E:WATER')
        snap=self.adapter.view.snapshot(); self.assertEqual(snap.ecology['dungeon:01'].resources['water'],5)
        bad=self.effect(EffectType.ECOLOGY_RESOURCE_DELTA,'dungeon:01',{'site_id':'dungeon:01','resource_key':'water','delta':-6,'cause_ref':'drought'},'effect:e:under')
        bd=self.authority.authorize(bad)
        with self.assertRaisesRegex(Exception,'UNDERFLOW'):
            self.adapter.apply_many((bd,),commit_id='commit:e:under',event_id='S10:E:UNDER')

    def test_recolonization_requires_time_and_causal_attractors(self):
        definition=next(x for x in self.catalog.dungeons if x['initial_occupancy']=='VACANT')
        did=definition['dungeon_id']; state=self.adapter.view.snapshot().dungeons[did]
        planner=RecolonizationPlanner(self.session,self.registry,minimum_vacancy_seconds=3600)
        self.assertIsNone(planner.plan(state,definition,tuple(self.catalog.creature_registry.get(x) for x in self.catalog.creature_registry.ids()),cause_ref='world:vacancy'))
        time_effect=self.effect(EffectType.ADVANCE_WORLD_TIME,None,{'seconds':4000},'effect:time:4000')
        td=self.authority.authorize(time_effect); WorldTimeCommitAdapter(self.session).advance(td,commit_id='commit:time:4000',event_id='S10:TIME')
        state=self.adapter.view.snapshot().dungeons[did]
        plan=planner.plan(state,definition,tuple(self.catalog.creature_registry.get(x) for x in self.catalog.creature_registry.ids()),cause_ref='world:vacancy')
        self.assertIsNotNone(plan); self.assertGreater(plan.score,0); self.assertGreater(plan.due_world_time,WorldClock(self.session).seconds)

    def test_recolonization_event_changes_world_once(self):
        definition=next(x for x in self.catalog.dungeons if x['initial_occupancy']=='VACANT'); did=definition['dungeon_id']
        t=self.effect(EffectType.ADVANCE_WORLD_TIME,None,{'seconds':4000},'effect:t:recol'); WorldTimeCommitAdapter(self.session).advance(self.authority.authorize(t),commit_id='commit:t:recol',event_id='S10:T:RECOL')
        planner=RecolonizationPlanner(self.session,self.registry,minimum_vacancy_seconds=3600)
        profiles=tuple(self.catalog.creature_registry.get(x) for x in self.catalog.creature_registry.ids()); plan=planner.plan(self.adapter.view.snapshot().dungeons[did],definition,profiles,cause_ref='vacancy:test')
        planner.schedule(plan)
        # advance to event due
        seconds=plan.due_world_time-WorldClock(self.session).seconds
        te=self.effect(EffectType.ADVANCE_WORLD_TIME,None,{'seconds':seconds},'effect:t:due'); WorldTimeCommitAdapter(self.session).advance(self.authority.authorize(te),commit_id='commit:t:due',event_id='S10:T:DUE')
        processor=RecolonizationProcessor(self.session,self.registry,self.adapter); processor.process_one_due()
        snap=self.adapter.view.snapshot(); self.assertEqual(snap.dungeons[did].occupancy,'OCCUPIED'); self.assertEqual(snap.dungeons[did].population_id,plan.population_id); self.assertEqual(snap.ecology[did].populations[plan.population_id],1)
        rev=self.session.store.revision
        self.assertIsNone(processor.process_one_due())
        self.assertEqual(self.session.store.revision,rev)

    def test_stage10_state_survives_existing_save_load(self):
        did=self.catalog.dungeons[0]['dungeon_id']; e=self.effect(EffectType.DUNGEON_OCCUPANCY_SET,did,{'dungeon_id':did,'occupancy':'VACANT','cause_ref':'test:save'},'effect:d:save'); self.adapter.apply_many((self.authority.authorize(e),),commit_id='commit:d:save',event_id='S10:D:SAVE')
        with tempfile.TemporaryDirectory() as td:
            repo=FilesystemRunRepository(Path(td)); repo.save(self.session)
            manager2=RunSessionManager(master_seed=20260912); loaded=repo.load_session(manager2,self.session.identity)
            view=Stage10WorldView(loaded,dungeon_definitions=self.catalog.dungeons)
            self.assertEqual(view.snapshot().dungeons[did].occupancy,'VACANT')

class Stage10RuntimeFacadeTests(unittest.TestCase):
    def test_full_version_visit_leave_time_recolonize_save_load_return(self):
        from playable_full_version.playable.game import FullVersionGame
        from runtime.stage9.authority import StateAuthority
        from runtime.stage9.effects import EffectProposal, EffectType, AuthorityDomain
        from runtime.stage9.world_time import WorldTimeCommitAdapter, WorldClock
        from collections import deque
        with tempfile.TemporaryDirectory() as td:
            g=FullVersionGame(core_root=ROOT,saves_root=Path(td),start_class='BREAKER')
            g.complete_character(g.creation_template())
            definition=next(x for x in g.catalog.dungeons if x['initial_occupancy']=='OCCUPIED')
            target=definition['location_ids'][0]
            graph={x['location_id']:tuple(x['connections']) for x in g.catalog.world['locations']}
            def path(a,b):
                q=deque([(a,())]); seen={a}
                while q:
                    cur,p=q.popleft()
                    if cur==b: return p
                    for n in graph[cur]:
                        if n not in seen: seen.add(n); q.append((n,p+(n,)))
                raise AssertionError('no route')
            for dest in path(g.location(),target):
                g.execute(action_type='MOVE',raw_input=f'go {dest}',parameters={'destination_location_id':dest})
            self.assertEqual(g.location(),target)
            g.stage10.record_vacancy(definition['dungeon_id'],cause_ref='player:cleared',source_ref='actor:player')
            state=g.stage10.snapshot().dungeons[definition['dungeon_id']]
            self.assertEqual(state.occupancy,'VACANT'); self.assertTrue(state.traces)
            exit_loc=graph[target][0]
            g.execute(action_type='MOVE',raw_input=f'go {exit_loc}',parameters={'destination_location_id':exit_loc})
            auth=StateAuthority(g.session,actor_registry=g.actor_registry)
            e=EffectProposal(effect_id='effect:accept:wait',run_uuid=g.session.identity.run_uuid,resolution_id='resolution:accept',source_action_id='action:accept:wait',effect_type=EffectType.ADVANCE_WORLD_TIME,target_ref=None,payload={'seconds':4000},authority_domain=AuthorityDomain.WORLD_TIME,expected_state_revision=g.session.store.revision)
            WorldTimeCommitAdapter(g.session).advance(auth.authorize(e),commit_id='commit:accept:wait',event_id='S10:ACCEPT:WAIT')
            plan=g.stage10.plan_recolonization(definition['dungeon_id'],cause_ref='ecology:vacancy')
            self.assertIsNotNone(plan); g.stage10.schedule_recolonization(plan)
            seconds=plan.due_world_time-WorldClock(g.session).seconds
            e2=EffectProposal(effect_id='effect:accept:due',run_uuid=g.session.identity.run_uuid,resolution_id='resolution:accept:due',source_action_id='action:accept:due',effect_type=EffectType.ADVANCE_WORLD_TIME,target_ref=None,payload={'seconds':seconds},authority_domain=AuthorityDomain.WORLD_TIME,expected_state_revision=g.session.store.revision)
            WorldTimeCommitAdapter(g.session).advance(auth.authorize(e2),commit_id='commit:accept:due',event_id='S10:ACCEPT:DUE')
            g.save()
            g2=FullVersionGame(core_root=ROOT,saves_root=Path(td))
            self.assertEqual(g2.stage10.snapshot().dungeons[definition['dungeon_id']].occupancy,'VACANT')
            g2.stage10.process_due_recolonization(); g2.save()
            for dest in path(g2.location(),target):
                g2.execute(action_type='MOVE',raw_input=f'go {dest}',parameters={'destination_location_id':dest})
            final=g2.stage10.snapshot().dungeons[definition['dungeon_id']]
            self.assertEqual(g2.location(),target); self.assertEqual(final.occupancy,'OCCUPIED'); self.assertEqual(final.population_id,plan.population_id); self.assertTrue(final.traces)
