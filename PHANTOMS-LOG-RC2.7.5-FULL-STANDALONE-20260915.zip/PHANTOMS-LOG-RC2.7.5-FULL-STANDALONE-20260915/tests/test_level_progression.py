from runtime.player_progression.levels import xp_for_level, level_for_xp
from runtime.player_progression.model import PlayerProgressionState
from runtime.player_progression.pipeline import PlayerLearningRuntime
from runtime.player_progression.behavior import RawActionEvent
from runtime.player_progression.persistence import migrate_payload


def _state():
    return PlayerProgressionState(player_uuid="p", run_uuid="r", start_class="GHOST")


def _meaningful_event(family="explore", location="loc:a"):
    return RawActionEvent(
        action_family=family,
        affinity_weights={"AFF_PERCEPTION": 1.0},
        location_id=location,
        difficulty_hint=2.0,
        consequence_hint=2.0,
        intentionality_hint=1.0,
        context_tags=("meaningful",),
    )


def test_level_curve_has_required_early_thresholds():
    assert xp_for_level(1) == 0.0
    assert xp_for_level(2) == 12.0
    assert 35.0 <= xp_for_level(3) <= 36.1
    assert level_for_xp(11.999) == 1
    assert level_for_xp(12.0) == 2
    assert level_for_xp(xp_for_level(3)) == 3
    assert xp_for_level(50) == 1100.0


def test_gameplay_evidence_awards_xp_and_levels_up():
    rt = PlayerLearningRuntime(_state())
    # Distinct contexts avoid anti-farm collapse and each event is capped at 4 XP.
    for i in range(3):
        e = _meaningful_event(f"explore_{i}", f"loc:{i}")
        assert rt.observe(e)
    assert rt.progression.xp >= 12.0
    assert rt.progression.level >= 2


def test_legacy_save_backfills_xp_from_existing_pattern_evidence_once():
    legacy = {
        "schema_version": 8,
        "progression": {
            "player_uuid": "p", "run_uuid": "r", "start_class": "GHOST",
            "level": 1,
            "pattern_evidence": {"search": 8.0, "craft": 5.0},
        },
    }
    migrated = migrate_payload(legacy).payload["progression"]
    assert migrated["xp"] == 13.0
    assert migrated["level"] == 2
    # Re-migration must not add the evidence a second time.
    migrated_again = migrate_payload({"schema_version": 10, "progression": migrated}).payload["progression"]
    assert migrated_again["xp"] == 13.0


def test_xp_is_persisted_in_runtime_payload():
    rt = PlayerLearningRuntime(_state())
    rt.observe(_meaningful_event())
    payload = rt.to_dict()
    assert payload["schema_version"] == 10
    assert payload["progression"]["xp"] == rt.progression.xp
    assert payload["progression"]["level"] == rt.progression.level
