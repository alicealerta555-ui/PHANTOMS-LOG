from pathlib import Path
import tempfile

import pytest

from playable_full_version.playable.game import FullVersionGame
from runtime.full_version.capability_catalog import class_start_talents
from runtime.full_version.class_tutorial import CLASS_TUTORIAL_STATE_KEY, CLASS_TUTORIAL_SCHEMA
from runtime.full_version.player_character import CharacterCreationError
from runtime.stage3a.kernel import Authority, Domain
from runtime.stage9.world_time import WorldClock

ROOT=Path(__file__).resolve().parents[1]
CLASSES=('BREAKER','GHOST','OPERATOR','RESONANT')


def make_game(start_class):
    td=tempfile.TemporaryDirectory()
    g=FullVersionGame(core_root=ROOT,saves_root=Path(td.name),start_class=start_class,master_seed=20260915)
    g._test_tmp=td
    return g


def close_game(g):
    try: g.images.close()
    finally: g._test_tmp.cleanup()


def tutorial_state(g):
    return g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,CLASS_TUTORIAL_STATE_KEY)


def inventory_snapshot(g):
    out={}
    for key in sorted(g.session.store.runtime_state):
        if not str(key).startswith('item:'): continue
        rec=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
        if isinstance(rec,dict) and rec.get('location_ref')=='inventory:actor:player':
            out[key]=rec
    return out


def test_level_one_defaults_have_exactly_two_distinct_class_talents():
    for cls in CLASSES:
        talents=class_start_talents(cls)
        assert len(talents)==2
        assert len(set(talents))==2


def test_character_creation_rejects_less_or_more_than_two_start_talents():
    g=make_game('OPERATOR')
    try:
        one=g.creation_template(); one['talents']=one['talents'][:1]
        with pytest.raises(CharacterCreationError,match='EXACTLY_TWO'):
            g.complete_character(one)
        three=g.creation_template(); three['talents']=['TALENT_MACHINEWORK','TALENT_SYSTEM_VIEW','TALENT_FIELD_REPAIR']
        with pytest.raises(CharacterCreationError,match='EXACTLY_TWO'):
            g.complete_character(three)
    finally: close_game(g)


def test_tutorial_tracks_exact_custom_selected_pair():
    g=make_game('OPERATOR')
    try:
        draft=g.creation_template()
        draft['talents']=['TALENT_SIGILCRAFT','TALENT_CONTAINMENT']
        g.complete_character(draft)
        state=tutorial_state(g)
        assert state['schema']==CLASS_TUTORIAL_SCHEMA
        assert state['start_class']=='OPERATOR'
        assert [x['talent_id'] for x in state['steps']]==draft['talents']
        assert state['status']=='ACTIVE'
        assert 'Klassen-Tutorial' in g.opening()
    finally: close_game(g)


@pytest.mark.parametrize('start_class',CLASSES)
def test_each_class_tutorial_applies_both_real_talents_without_world_rewards(start_class):
    g=make_game(start_class)
    try:
        draft=g.creation_template(); g.complete_character(draft)
        before_location=g.location()
        before_time=WorldClock(g.session).seconds
        before_inventory=inventory_snapshot(g)
        before_progression=g.progression_runtime.snapshot()
        assert g.class_tutorial.active()

        for expected_tid in draft['talents']:
            state=tutorial_state(g)
            step=state['steps'][state['step_index']]
            assert step['talent_id']==expected_tid
            text,_=g.handle(step['hint'])
            assert expected_tid in {x['talent_id'] for x in tutorial_state(g)['attempts']}
            assert tutorial_state(g)['attempts'][-1]['talent_applied']==expected_tid
            assert 'angewendet' in text

        state=tutorial_state(g)
        assert state['status']=='COMPLETE'
        assert all(x['completed'] for x in state['steps'])
        assert len(state['attempts'])==2
        assert state['rewards']=={}
        assert g.location()==before_location
        assert WorldClock(g.session).seconds==before_time
        assert inventory_snapshot(g)==before_inventory
        assert g.progression_runtime.snapshot()==before_progression
        assert not g.class_tutorial.active()
    finally: close_game(g)


def test_tutorial_is_skippable_without_reward_or_character_change():
    g=make_game('GHOST')
    try:
        draft=g.creation_template(); g.complete_character(draft)
        before=g.character(); before_progression=g.progression_runtime.snapshot()
        text,_=g.handle('/tutorial überspringen')
        assert 'übersprungen' in text
        state=tutorial_state(g)
        assert state['status']=='SKIPPED'
        assert state['rewards']=={}
        after=g.character()
        for field in ('stats','skills','talents','class_abilities','expertises'):
            assert after[field]==before[field]
        assert g.progression_runtime.snapshot()==before_progression
    finally: close_game(g)
