from __future__ import annotations

import unittest
from uuid import uuid4

from runtime.stage3c.isolation import RunSessionManager

from runtime.stage9.effects import (
    AuthorityDomain,
    EffectPrecondition,
    EffectProposal,
    EffectType,
    PreconditionType,
    Stage9EffectError,
    assert_no_generic_effect_types,
)


class Stage9EffectProposalTests(unittest.TestCase):
    def setUp(self) -> None:
        self.run_uuid = str(uuid4())

    def proposal(self, **overrides):
        data = dict(
            effect_id="effect:door-open:1",
            run_uuid=self.run_uuid,
            resolution_id="resolution:1",
            source_action_id="action:1",
            effect_type=EffectType.SET_DOOR_STATE,
            target_ref="door:service",
            payload={"door_instance_id": "door:service", "new_state": "OPEN"},
            authority_domain=AuthorityDomain.WORLD_OBJECT,
            expected_state_revision=7,
        )
        data.update(overrides)
        return EffectProposal(**data)

    def test_valid_semantic_door_proposal(self):
        p = self.proposal()
        self.assertEqual(p.effect_type, EffectType.SET_DOOR_STATE)
        self.assertEqual(p.authority_domain, AuthorityDomain.WORLD_OBJECT)
        self.assertEqual(p.expected_state_revision, 7)
        self.assertEqual(p.as_dict()["payload"]["new_state"], "OPEN")

    def test_authority_domain_is_fixed_by_effect_type(self):
        with self.assertRaisesRegex(Stage9EffectError, "EFFECT_AUTHORITY_DOMAIN_MISMATCH"):
            self.proposal(authority_domain=AuthorityDomain.COMBAT)

    def test_extra_payload_field_cannot_smuggle_state_path(self):
        with self.assertRaisesRegex(Stage9EffectError, "EFFECT_PAYLOAD_FIELD_FORBIDDEN"):
            self.proposal(payload={
                "door_instance_id": "door:service",
                "new_state": "OPEN",
                "state_path": "runtime_state.admin",
            })

    def test_target_must_match_semantic_payload_target(self):
        with self.assertRaisesRegex(Stage9EffectError, "EFFECT_TARGET_MISMATCH"):
            self.proposal(target_ref="door:other")

    def test_expected_revision_must_be_nonnegative_integer(self):
        with self.assertRaisesRegex(Stage9EffectError, "EFFECT_EXPECTED_STATE_REVISION_INVALID"):
            self.proposal(expected_state_revision=-1)

    def test_run_uuid_is_canonical(self):
        with self.assertRaisesRegex(Stage9EffectError, "RUN_UUID_INVALID"):
            self.proposal(run_uuid="not-a-run")

    def test_item_transfer_schema(self):
        p = self.proposal(
            effect_id="effect:item:1",
            effect_type=EffectType.ITEM_TRANSFER,
            target_ref="item:flashlight",
            payload={
                "item_instance_id": "item:flashlight",
                "from_location_ref": "location:room-a",
                "to_location_ref": "inventory:actor-player",
            },
            authority_domain=AuthorityDomain.INVENTORY,
        )
        self.assertEqual(p.payload["item_instance_id"], "item:flashlight")

    def test_move_actor_schema(self):
        p = self.proposal(
            effect_id="effect:move:1",
            effect_type=EffectType.MOVE_ACTOR,
            target_ref="actor:player",
            payload={
                "actor_instance_id": "actor:player",
                "destination_location_id": "location:room-b",
            },
            authority_domain=AuthorityDomain.ACTOR_STATE,
        )
        self.assertEqual(p.payload["destination_location_id"], "location:room-b")

    def test_world_time_advance_has_no_target_and_positive_seconds(self):
        p = self.proposal(
            effect_id="effect:time:1",
            effect_type=EffectType.ADVANCE_WORLD_TIME,
            target_ref=None,
            payload={"seconds": 5},
            authority_domain=AuthorityDomain.WORLD_TIME,
        )
        self.assertEqual(p.payload["seconds"], 5)
        with self.assertRaisesRegex(Stage9EffectError, "EFFECT_PAYLOAD_SECONDS_INVALID"):
            self.proposal(
                effect_id="effect:time:bad",
                effect_type=EffectType.ADVANCE_WORLD_TIME,
                target_ref=None,
                payload={"seconds": 0},
                authority_domain=AuthorityDomain.WORLD_TIME,
            )

    def test_knowledge_proposal_requires_semantic_epistemic_fields(self):
        p = self.proposal(
            effect_id="effect:knowledge:1",
            effect_type=EffectType.WRITE_KNOWLEDGE,
            target_ref="actor:player",
            payload={
                "actor_instance_id": "actor:player",
                "knowledge_key": "door.visible",
                "value": True,
                "provenance": "direct-vision",
                "epistemic": {"source_type": "VISION"},
            },
            authority_domain=AuthorityDomain.KNOWLEDGE,
        )
        self.assertEqual(p.payload["provenance"], "direct-vision")
        with self.assertRaisesRegex(Stage9EffectError, "EFFECT_PAYLOAD_EPISTEMIC_REQUIRED"):
            self.proposal(
                effect_id="effect:knowledge:bad",
                effect_type=EffectType.WRITE_KNOWLEDGE,
                target_ref="actor:player",
                payload={
                    "actor_instance_id": "actor:player",
                    "knowledge_key": "door.visible",
                    "value": True,
                    "provenance": "direct-vision",
                    "epistemic": "not-a-map",
                },
                authority_domain=AuthorityDomain.KNOWLEDGE,
            )

    def test_resource_delta_rejects_zero(self):
        with self.assertRaisesRegex(Stage9EffectError, "EFFECT_PAYLOAD_DELTA_INVALID"):
            self.proposal(
                effect_id="effect:resource:1",
                effect_type=EffectType.RESOURCE_DELTA,
                target_ref="actor:player",
                payload={"owner_ref": "actor:player", "resource_key": "energy", "delta": 0},
                authority_domain=AuthorityDomain.RESOURCE,
            )

    def test_precondition_is_semantic_and_serializable(self):
        pre = EffectPrecondition(
            PreconditionType.SOURCE_LOCATION_EQUALS,
            "item:flashlight",
            field="location",
            expected="location:room-a",
        )
        p = self.proposal(preconditions=(pre,))
        self.assertEqual(p.as_dict()["preconditions"][0]["kind"], "SOURCE_LOCATION_EQUALS")

    def test_payload_is_copied_from_caller(self):
        payload = {"door_instance_id": "door:service", "new_state": "OPEN"}
        p = self.proposal(payload=payload)
        payload["new_state"] = "CLOSED"
        self.assertEqual(p.payload["new_state"], "OPEN")

    def test_forbidden_generic_effect_types_are_absent(self):
        assert_no_generic_effect_types()
        defined = {e.value for e in EffectType}
        for forbidden in ("RAW_PATCH", "SET_STATE", "SET_ANY_PATH", "WRITE_PATH", "EXEC_CODE"):
            self.assertNotIn(forbidden, defined)

    def test_constructing_proposal_never_mutates_canonical_state(self):
        manager = RunSessionManager(master_seed=20260911)
        session = manager.create_run(player_uuid=str(uuid4()))
        before = session.store.snapshot()
        before_hash = session.store.state_hash()
        before_revision = session.store.revision
        EffectProposal(
            effect_id="effect:door-open:nonmutation",
            run_uuid=session.identity.run_uuid,
            resolution_id="resolution:nonmutation",
            source_action_id="action:nonmutation",
            effect_type=EffectType.SET_DOOR_STATE,
            target_ref="door:service",
            payload={"door_instance_id": "door:service", "new_state": "OPEN"},
            authority_domain=AuthorityDomain.WORLD_OBJECT,
            expected_state_revision=before_revision,
        )
        self.assertEqual(session.store.snapshot(), before)
        self.assertEqual(session.store.state_hash(), before_hash)
        self.assertEqual(session.store.revision, before_revision)

    def test_schedule_event_payload_is_closed_and_json_safe(self):
        p = self.proposal(
            effect_id="effect:event:1",
            effect_type=EffectType.SCHEDULE_EVENT,
            target_ref="event:light-off",
            payload={
                "scheduled_event_id": "event:light-off",
                "event_type": "AUTO_LIGHT_OFF",
                "due_world_time": 10,
                "payload": {"device_instance_id": "device:lamp"},
                "sequence_key": "001",
            },
            authority_domain=AuthorityDomain.SCHEDULER,
        )
        self.assertEqual(p.payload["due_world_time"], 10)


if __name__ == "__main__":
    unittest.main(verbosity=2)
