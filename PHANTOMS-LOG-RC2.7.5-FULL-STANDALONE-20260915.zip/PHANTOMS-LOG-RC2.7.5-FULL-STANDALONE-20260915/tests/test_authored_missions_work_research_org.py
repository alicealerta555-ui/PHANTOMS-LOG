import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
CONTENT=ROOT/'content/full_version'

def test_new_pack_has_16_universally_accessible_missions():
    d=json.loads((CONTENT/'authored_missions_agriculture_investigation_research_organization.json').read_text())
    assert d['schema']=='PH4NT0M5_AUTHORED_MISSIONS_V1'
    assert len(d['missions'])==16
    assert all(not m['access']['class_lock'] and not m['access']['profession_lock'] for m in d['missions'])
    assert all(m['resolution']['failure_allowed'] and m['resolution']['critical_failure_allowed'] for m in d['missions'])

def test_new_families_have_resolution_and_consequence_profiles():
    rp=json.loads((CONTENT/'mission_resolution_policy.json').read_text())['families']
    cp=json.loads((CONTENT/'mission_consequence_profiles.json').read_text())['families']
    families={'AGRICULTURE_WORK','INVESTIGATION_CASE','RESEARCH_LAB','ORGANIZATION_OPERATION'}
    assert families <= rp.keys()
    assert families <= cp.keys()

def test_all_authored_ids_unique_and_world_bound():
    ids=[]
    for p in CONTENT.glob('authored_missions_*.json'):
        for m in json.loads(p.read_text())['missions']:
            ids.append(m['id'])
            assert m['requirements']['source_ref_required']
            assert m['requirements']['location_id_required']
            assert 'world_state_before_build_fit' in m['rules']
    assert len(ids)==len(set(ids))
