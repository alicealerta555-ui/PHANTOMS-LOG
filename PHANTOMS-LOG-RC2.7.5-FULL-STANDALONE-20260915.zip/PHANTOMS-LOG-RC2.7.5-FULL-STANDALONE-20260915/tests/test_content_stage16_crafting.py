
import json,unittest
from pathlib import Path
from runtime.content_stage16.crafting import *
ROOT=Path(__file__).resolve().parents[1]; D=json.loads((ROOT/"content/full_version/stage16_crafting.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_recipes(self): self.assertGreaterEqual(len(D["recipes"]),3)
 def test_missing_material(self):
  r=D["recipes"][0]; self.assertFalse(can_craft(r,{"MAT_CLOTH":1,"MAT_CHEM":1},["TOOL_BASIC_KIT"],99))
 def test_tool_gate(self):
  r=D["recipes"][0]; self.assertFalse(can_craft(r,{"MAT_CLOTH":2,"MAT_CHEM":1},[],99))
 def test_skill_gate(self):
  r=D["recipes"][0]; self.assertFalse(can_craft(r,{"MAT_CLOTH":2,"MAT_CHEM":1},["TOOL_BASIC_KIT"],0))
 def test_craft_authority(self):
  r=D["recipes"][0]; p=craft_proposal(r,"a","L","EV",["SRC"]); self.assertTrue(p["authority_required"]); self.assertEqual(p["consume"],r["inputs"])
 def test_repair_bounded(self):
  prof=D["repair_profiles"][0]; self.assertEqual(repair_amount(90,100,99,prof),10); self.assertEqual(repair_amount(20,100,99,prof),35)
 def test_repair_authority(self):
  p=repair_proposal(D["repair_profiles"][0],"i","a",50,100,20,"EV"); self.assertTrue(p["authority_required"])
 def test_provenance(self):
  r=provenance_record("o","REC",["SRC1","SRC2"],"a","L",5); self.assertTrue(validate_provenance(r)); self.assertEqual(r["input_sources"],["SRC1","SRC2"])
 def test_no_unique_duplication_rule(self): self.assertTrue(any("Unique artifacts cannot be duplicated" in x for x in D["rules"]))
if __name__=="__main__": unittest.main()
