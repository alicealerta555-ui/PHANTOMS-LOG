from __future__ import annotations

import pytest

from runtime.full_version.capability_catalog import SKILLS, STATS, TALENTS
from runtime.player_progression.class_abilities import ABILITIES, ability_payload


@pytest.mark.parametrize("ability_id", sorted(ABILITIES))
def test_every_class_ability_is_rooted_in_character_tree(ability_id):
    a=ABILITIES[ability_id]
    assert a.required_skills
    assert a.required_stats
    assert all(s in SKILLS for s in a.required_skills)
    assert all(s in STATS for s in a.required_stats)
    assert all(t in TALENTS for t in a.talent_roots)
    payload=ability_payload(a)
    assert payload["required_skills"] == list(a.required_skills)
    assert payload["required_stats"] == list(a.required_stats)


def test_every_character_skill_feeds_at_least_one_class_ability():
    used={s for a in ABILITIES.values() for s in a.required_skills}
    assert used == set(SKILLS)


def test_every_base_talent_feeds_at_least_one_class_ability():
    used={t for a in ABILITIES.values() for t in a.talent_roots}
    assert used == set(TALENTS)
