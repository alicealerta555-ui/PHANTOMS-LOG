
import json, unittest
from pathlib import Path
from runtime.content_stage30.ecology import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage30_ecology.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_population_profiles(self):
  self.assertGreaterEqual(len(D["population_profiles"]),4)

 def test_population_requires_time(self):
  self.assertEqual(population_projection(100,500,250,0,0),100)

 def test_population_bounded_by_capacity(self):
  self.assertEqual(population_projection(499,500,10000,1440,0),500)

 def test_pressure_reduces_population(self):
  a=population_projection(100,500,250,1440,0)
  b=population_projection(100,500,250,1440,5000)
  self.assertGreater(a,b)

 def test_resource_regeneration_requires_time(self):
  self.assertEqual(resource_regeneration(100,1000,20,0,10000),100)

 def test_resource_regeneration_bounded(self):
  self.assertEqual(resource_regeneration(995,1000,100,1440,10000),1000)

 def test_predator_prey_pressure(self):
  self.assertEqual(predator_prey_pressure(0,100),0)
  self.assertGreater(predator_prey_pressure(10,100),0)

 def test_migration_requires_route(self):
  self.assertIsNone(migration_candidate("POP","A","B","",10,1,"EV"))

 def test_migration_authority(self):
  p=migration_candidate("POP","A","B","ROUTE_X",10,1,"EV")
  self.assertTrue(p["authority_required"])

 def test_environment_change_requires_time(self):
  self.assertIsNone(environmental_change_proposal("R","drought",50,0,"EV"))

 def test_extinction_persistent_state(self):
  self.assertEqual(extinction_state(0),"EXTINCT_LOCAL")
  self.assertEqual(extinction_state(1),"PRESENT")

if __name__=="__main__": unittest.main()
