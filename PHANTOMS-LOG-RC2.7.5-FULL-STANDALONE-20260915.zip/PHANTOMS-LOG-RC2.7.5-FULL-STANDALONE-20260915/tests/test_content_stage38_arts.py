
import json, unittest
from pathlib import Path
from runtime.content_stage38.arts import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage38_arts_entertainment.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_art_forms(self):
  self.assertGreaterEqual(len(D["art_forms"]),5)

 def test_work_provenance(self):
  w=creative_work("W",["a"],"ART_MUSIC",1,{"source":"a"})
  self.assertFalse(w["truth_status_written"])

 def test_performance_authority(self):
  p=performance_candidate("P","W",["a"],"L",1,50,"EV")
  self.assertTrue(p["authority_required"])

 def test_performance_requires_location(self):
  self.assertIsNone(performance_candidate("P","W",["a"],"",1,50,"EV"))

 def test_audience_reach_bounded(self):
  self.assertEqual(audience_reach(100,10000,10000),100)

 def test_fame_bounded(self):
  x=fame_delta({"local":95,"notoriety":95},100,100,100)
  self.assertEqual(x["local"],100)
  self.assertEqual(x["notoriety"],100)

 def test_festival_requires_resources(self):
  f=D["festival_types"][0]
  self.assertIsNone(festival_candidate("F",f,"L","O",False,100,"EV"))

 def test_festival_capacity_bounded(self):
  f=D["festival_types"][0]
  p=festival_candidate("F",f,"L","O",True,999,"EV")
  self.assertEqual(p["capacity"],f["capacity"])
  self.assertTrue(p["authority_required"])

 def test_popularity_not_truth(self):
  x=cultural_production_influence(100,10)
  self.assertFalse(x["truth_from_popularity"])

 def test_contract_provenance_rule(self):
  self.assertTrue(D["work_contract"]["creator_provenance_required"])

 def test_fame_dimensions(self):
  self.assertIn("local",D["fame_dimensions"])
  self.assertIn("notoriety",D["fame_dimensions"])

if __name__=="__main__": unittest.main()
