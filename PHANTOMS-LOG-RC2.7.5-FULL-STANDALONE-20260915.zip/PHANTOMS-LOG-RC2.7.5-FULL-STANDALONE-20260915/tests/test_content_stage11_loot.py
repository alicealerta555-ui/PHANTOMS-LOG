
import json,unittest
from pathlib import Path
from runtime.content_stage11.loot import *
ROOT=Path(__file__).resolve().parents[1]; D=json.loads((ROOT/"content/full_version/stage11_loot_artifacts.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_tables(self): self.assertGreaterEqual(len(D["loot_tables"]),3)
 def test_artifacts(self): self.assertGreaterEqual(len(D["artifacts"]),5)
 def test_sites(self): self.assertGreaterEqual(len(D["power_sites"]),5); self.assertTrue(all(x["bounded"] for x in D["power_sites"]))
 def test_deterministic_pick(self):
  e=D["loot_tables"][0]["entries"]; self.assertEqual(weighted_pick(e,"abc"),weighted_pick(e,"abc"))
 def test_unique(self):
  a=next(x for x in D["artifacts"] if x["id"]=="ART_REACTOR_KEY"); self.assertTrue(can_spawn(a,[])); self.assertFalse(can_spawn(a,[a["id"]]))
 def test_provenance(self):
  a=D["artifacts"][0]; r=provenance_record(a,"LOC_X",12,"ACTOR_X"); self.assertTrue(validate_provenance(r)); self.assertEqual(r["origin_id"],a["origin_id"])
 def test_site_requires_tag(self):
  site=next(x for x in D["power_sites"] if x["id"]=="SITE_REACTOR_VAULT")
  key=next(x for x in D["artifacts"] if x["id"]=="ART_REACTOR_KEY")
  shard=next(x for x in D["artifacts"] if x["id"]=="ART_DATA_SHARD")
  self.assertIsNotNone(power_site_candidate(site,key)); self.assertIsNone(power_site_candidate(site,shard))
 def test_authority_gate(self):
  site=D["power_sites"][0]; a=next(x for x in D["artifacts"] if "access" in x["tags"])
  self.assertTrue(power_site_candidate(site,a)["authority_required"])

 def test_no_legacy_aggregate_item_aliases(self):
  refs=[ref for table in D["loot_tables"] for ref,_ in table["entries"]]; self.assertNotIn("ITEM_PARTS",refs); self.assertNotIn("ITEM_WATER",refs); self.assertNotIn("ITEM_FOOD",refs)
 def test_nonartifact_loot_resolves_to_concrete_display_name(self):
  world=json.loads((ROOT/"content/full_version/world_catalog.json").read_text())
  refs=[ref for table in D["loot_tables"] for ref,_ in table["entries"] if str(ref).startswith("item_def:")]
  self.assertTrue(refs)
  for ref in refs:
   rec=resolve_loot_ref(ref,world,D["artifacts"]); self.assertTrue(rec["display_name"]); self.assertNotEqual(rec["display_name"],ref)
 def test_legacy_alias_fails_closed(self):
  world=json.loads((ROOT/"content/full_version/world_catalog.json").read_text())
  with self.assertRaises(KeyError): resolve_loot_ref("ITEM_PARTS",world,D["artifacts"])
if __name__=="__main__": unittest.main()
