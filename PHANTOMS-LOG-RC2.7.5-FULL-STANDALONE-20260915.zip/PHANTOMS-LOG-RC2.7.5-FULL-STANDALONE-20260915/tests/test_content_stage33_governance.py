
import json, unittest
from pathlib import Path
from runtime.content_stage33.governance import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage33_governance.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_governance_models(self):
  self.assertGreaterEqual(len(D["governance_models"]),4)

 def test_tax_requires_jurisdiction(self):
  tax=D["tax_types"][0]
  self.assertIsNone(assess_tax(tax,100,"","actor",1,"EV"))

 def test_tax_amount(self):
  tax=next(x for x in D["tax_types"] if x["id"]=="TAX_MARKET_FEE")
  p=assess_tax(tax,1000,"J","actor",1,"EV")
  self.assertEqual(p["amount"],50)
  self.assertTrue(p["authority_required"])

 def test_budget_no_implicit_deficit(self):
  b=budget_projection(100,20,200,False)
  self.assertEqual(b["spending"],120)
  self.assertEqual(b["closing_balance"],0)

 def test_budget_explicit_deficit(self):
  b=budget_projection(100,0,150,True)
  self.assertEqual(b["closing_balance"],-50)

 def test_service_capacity_and_budget(self):
  s=D["public_services"][0]
  low=service_delivery(s,25,100)
  high=service_delivery(s,1000,100)
  self.assertLess(low["served"],high["served"])

 def test_service_shortage(self):
  s=D["public_services"][1]
  x=service_delivery(s,30,100)
  self.assertGreater(x["shortage"],0)

 def test_legitimacy_bounded(self):
  x=legitimacy_delta({"overall":95},{"overall":50})
  self.assertEqual(x["overall"],100)

 def test_policy_authority(self):
  p=policy_proposal("GOV","rationing",{"water":True},"EV")
  self.assertTrue(p["authority_required"])

 def test_spending_cannot_exceed_balance(self):
  self.assertIsNone(public_spending_proposal("G","SERVICE_WATER",101,100,"EV"))

 def test_spending_authority(self):
  p=public_spending_proposal("G","SERVICE_WATER",100,100,"EV")
  self.assertTrue(p["authority_required"])

if __name__=="__main__": unittest.main()
