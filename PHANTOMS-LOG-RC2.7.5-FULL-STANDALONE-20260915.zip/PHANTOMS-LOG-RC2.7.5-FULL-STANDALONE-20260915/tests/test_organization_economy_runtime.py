from pathlib import Path
import tempfile
import pytest
from playable.game import FullVersionGame
from runtime.full_version.organization_runtime import OrganizationRuntimeError

ROOT=Path(__file__).resolve().parents[1]

def game():
    td=tempfile.TemporaryDirectory(); g=FullVersionGame(core_root=ROOT,saves_root=Path(td.name),start_class='OPERATOR'); g.complete_character(g.creation_template()); g._tmp=td
    g.organization_runtime.create_organization('Werkbund')
    return g

def test_persistent_warehouse_stock_requires_authoritative_evidence():
    g=game(); g.organization_runtime.create_warehouse('wh:a',location_id='site:a',display_name='Lager A',capacity_units=10,authority_ref='world:warehouse:a')
    with pytest.raises(OrganizationRuntimeError,match='WAREHOUSE_EVIDENCE_REQUIRED'):
        g.organization_runtime.record_warehouse_flow('wh:a',direction='IN',resource_ref='SCRAP',quantity=2,evidence_ref='')
    g.organization_runtime.record_warehouse_flow('wh:a',direction='IN',resource_ref='SCRAP',quantity=4,evidence_ref='loot:1')
    assert g.organization_runtime.state_view()['warehouses']['wh:a']['stock']['SCRAP']==4

def test_warehouse_capacity_and_no_negative_stock():
    g=game(); g.organization_runtime.create_warehouse('wh:a',location_id='site:a',display_name='A',capacity_units=5,authority_ref='world:a')
    g.organization_runtime.record_warehouse_flow('wh:a',direction='IN',resource_ref='ORE',quantity=5,evidence_ref='loot:ore')
    with pytest.raises(OrganizationRuntimeError,match='WAREHOUSE_CAPACITY_EXCEEDED'):
        g.organization_runtime.record_warehouse_flow('wh:a',direction='IN',resource_ref='ORE',quantity=1,evidence_ref='loot:more')
    with pytest.raises(OrganizationRuntimeError,match='WAREHOUSE_STOCK_INSUFFICIENT'):
        g.organization_runtime.record_warehouse_flow('wh:a',direction='OUT',resource_ref='ORE',quantity=6,evidence_ref='use:1')

def test_facility_is_persistent_and_production_requires_real_inputs_outputs():
    g=game()
    for wid in ('wh:in','wh:out'): g.organization_runtime.create_warehouse(wid,location_id='site:factory',display_name=wid,capacity_units=50,authority_ref='world:'+wid)
    fac=g.organization_runtime.create_facility('fac:1',facility_kind='WORKSHOP',location_id='site:factory',input_warehouse_id='wh:in',output_warehouse_id='wh:out',authority_ref='industry:fac1')
    assert fac['status']=='ACTIVE'
    with pytest.raises(OrganizationRuntimeError,match='PRODUCTION_FLOW_UNRESOLVED'):
        g.organization_runtime.record_production_run('fac:1',input_facts=[],output_facts=[{'resource_ref':'PART','quantity':1,'evidence_ref':'prod:o'}],result_ref='prod:result')
    run=g.organization_runtime.record_production_run('fac:1',input_facts=[{'resource_ref':'ORE','quantity':2,'evidence_ref':'prod:i'}],output_facts=[{'resource_ref':'PART','quantity':1,'evidence_ref':'prod:o'}],result_ref='prod:result')
    assert run['output_facts'][0]['resource_ref']=='PART'

def test_supply_chain_requires_real_team_stock_and_arrival_evidence_for_delivery():
    g=game()
    for wid,loc in (('wh:a','site:a'),('wh:b','site:b')): g.organization_runtime.create_warehouse(wid,location_id=loc,display_name=wid,capacity_units=50,authority_ref='world:'+wid)
    g.organization_runtime.record_warehouse_flow('wh:a',direction='IN',resource_ref='FOOD',quantity=10,evidence_ref='stock:food')
    npc=next(x.actor_instance_id for x in g.actor_registry.instances() if x.actor_instance_id.startswith('actor:npc:'))
    offer=g.organization_runtime.offer_recruitment(npc,'ROLE_TRADER'); g.organization_runtime.resolve_recruitment(offer['offer_id'],npc,'ACCEPT')
    team=g.organization_runtime.create_team('team:haul','CONVOY',['actor:player',npc],leader_actor_id='actor:player')
    chain=g.organization_runtime.create_supply_chain('chain:1',source_warehouse_id='wh:a',destination_warehouse_id='wh:b',resource_ref='FOOD',team_id=team['team_id'],authority_ref='logistics:route1')
    assert chain['status']=='ACTIVE'
    ship=g.organization_runtime.record_supply_shipment('chain:1',quantity=3,departure_evidence_ref='dispatch:1')
    assert ship['status']=='IN_TRANSIT' and 'FOOD' not in g.organization_runtime.state_view()['warehouses']['wh:b']['stock']
    ship=g.organization_runtime.record_supply_shipment('chain:1',quantity=2,departure_evidence_ref='dispatch:2',arrival_evidence_ref='arrival:2')
    view=g.organization_runtime.state_view(); assert ship['status']=='DELIVERED' and view['warehouses']['wh:b']['stock']['FOOD']==2

def test_economy_objects_survive_state_reads():
    g=game(); g.organization_runtime.create_warehouse('wh:a',location_id='site:a',display_name='A',capacity_units=10,authority_ref='world:a')
    a=g.organization_runtime.state_view(); b=g.organization_runtime.state_view()
    assert a['warehouses']==b['warehouses'] and a['warehouses']['wh:a']['location_id']=='site:a'

def _production_game():
    g=game()
    for wid in ('wh:in','wh:out'): g.organization_runtime.create_warehouse(wid,location_id='site:factory',display_name=wid,capacity_units=50,authority_ref='world:'+wid)
    g.organization_runtime.create_facility('fac:p',facility_kind='WORKSHOP',location_id='site:factory',input_warehouse_id='wh:in',output_warehouse_id='wh:out',authority_ref='industry:p')
    g.organization_runtime.record_warehouse_flow('wh:in',direction='IN',resource_ref='ORE',quantity=10,evidence_ref='stock:ore')
    return g

def test_production_reserves_inputs_and_prevents_double_spend():
    g=_production_game(); run=g.organization_runtime.start_production_run('fac:p','run:1',input_facts=[{'resource_ref':'ORE','quantity':7,'evidence_ref':'recipe:1'}],duration_seconds=0,start_evidence_ref='start:1')
    assert run['status']=='IN_PROGRESS' and g.organization_runtime.state_view()['warehouses']['wh:in']['stock']['ORE']==3
    with pytest.raises(OrganizationRuntimeError,match='WAREHOUSE_STOCK_INSUFFICIENT'):
        g.organization_runtime.start_production_run('fac:p','run:2',input_facts=[{'resource_ref':'ORE','quantity':4,'evidence_ref':'recipe:2'}],duration_seconds=0,start_evidence_ref='start:2')

def test_production_output_only_after_authoritative_resolution_and_no_duplication():
    g=_production_game(); g.organization_runtime.start_production_run('fac:p','run:1',input_facts=[{'resource_ref':'ORE','quantity':4,'evidence_ref':'recipe:1'}],duration_seconds=0,start_evidence_ref='start:1')
    assert g.organization_runtime.state_view()['warehouses']['wh:out']['stock']=={}
    r=g.organization_runtime.resolve_production_run('run:1',outcome='PARTIAL_SUCCESS',output_facts=[{'resource_ref':'PART','quantity':1,'evidence_ref':'prod:partial'}],result_ref='result:1')
    assert r['resolution']['outcome']=='PARTIAL_SUCCESS' and g.organization_runtime.state_view()['warehouses']['wh:out']['stock']['PART']==1
    with pytest.raises(OrganizationRuntimeError,match='PRODUCTION_RUN_ALREADY_RESOLVED'):
        g.organization_runtime.resolve_production_run('run:1',outcome='FULL_SUCCESS',output_facts=[{'resource_ref':'PART','quantity':5,'evidence_ref':'prod:again'}],result_ref='result:2')

def test_failed_production_consumes_reserved_inputs_but_fabricates_no_output():
    g=_production_game(); g.organization_runtime.start_production_run('fac:p','run:f',input_facts=[{'resource_ref':'ORE','quantity':3,'evidence_ref':'recipe:f'}],duration_seconds=0,start_evidence_ref='start:f')
    g.organization_runtime.resolve_production_run('run:f',outcome='FAILURE',output_facts=[],result_ref='result:f'); view=g.organization_runtime.state_view()
    assert view['warehouses']['wh:in']['stock']['ORE']==7 and view['warehouses']['wh:out']['stock']=={}

def test_cancel_can_return_reserved_inputs_only_when_explicitly_authorized():
    g=_production_game(); g.organization_runtime.start_production_run('fac:p','run:c',input_facts=[{'resource_ref':'ORE','quantity':2,'evidence_ref':'recipe:c'}],duration_seconds=0,start_evidence_ref='start:c')
    g.organization_runtime.cancel_production_run('run:c',cancellation_ref='cancel:c',return_reserved_inputs=True)
    assert g.organization_runtime.state_view()['warehouses']['wh:in']['stock']['ORE']==10

def test_team_skills_can_resolve_production_and_output_remains_evidence_bound():
    g=_production_game(); g.organization_runtime.start_production_run('fac:p','run:team',input_facts=[{'resource_ref':'ORE','quantity':2,'evidence_ref':'recipe:team'}],duration_seconds=0,start_evidence_ref='start:team')
    snap=[{'evidence_ref':'crew:snapshot:1','relevant_skill_values':{'SKILL_TECHNOLOGY':8,'SKILL_FINE_MECHANICS':7},'equipment_modifier':2,'condition_modifier':1,'machine_support':2,'readiness':1.0}]
    r=g.organization_runtime.resolve_production_run_with_team('run:team',team_snapshots=snap,difficulty=3,output_facts=[{'resource_ref':'PART','quantity':2,'evidence_ref':'prod:team'}],result_ref='result:team')
    assert r['resolution']['outcome'] in {'FULL_SUCCESS','SUCCESS_WITH_COST','PARTIAL_SUCCESS','FAILURE','CRITICAL_FAILURE'}
    assert r['workforce_resolution']['evidence_refs']==['crew:snapshot:1']
    assert g.organization_runtime.state_view()['warehouses']['wh:out']['stock'].get('PART',0)==2

def test_weak_team_can_really_fail_production_without_fabricated_output():
    g=_production_game(); g.organization_runtime.start_production_run('fac:p','run:weak',input_facts=[{'resource_ref':'ORE','quantity':2,'evidence_ref':'recipe:weak'}],duration_seconds=0,start_evidence_ref='start:weak')
    snap=[{'evidence_ref':'crew:snapshot:weak','relevant_skill_values':{'SKILL_TECHNOLOGY':0},'equipment_modifier':-2,'condition_modifier':-2,'machine_support':0,'readiness':0.5}]
    r=g.organization_runtime.resolve_production_run_with_team('run:weak',team_snapshots=snap,difficulty=10,danger=3,time_pressure=3,output_facts=[],result_ref='result:weak')
    assert r['resolution']['outcome'] in {'FAILURE','CRITICAL_FAILURE'}
    assert g.organization_runtime.state_view()['warehouses']['wh:out']['stock']=={}

def test_production_team_resolution_requires_authoritative_snapshot_evidence():
    g=_production_game(); g.organization_runtime.start_production_run('fac:p','run:noev',input_facts=[{'resource_ref':'ORE','quantity':1,'evidence_ref':'recipe:noev'}],duration_seconds=0,start_evidence_ref='start:noev')
    with pytest.raises(OrganizationRuntimeError,match='AUTHORITATIVE_TEAM_EVIDENCE_REQUIRED'):
        g.organization_runtime.resolve_production_run_with_team('run:noev',team_snapshots=[{'relevant_skill_values':{'SKILL_TECHNOLOGY':5}}],difficulty=5,output_facts=[],result_ref='result:noev')

def test_recipe_restricts_facility_kind_and_exact_inputs():
    g=_production_game()
    with pytest.raises(OrganizationRuntimeError,match='PRODUCTION_RECIPE_FACILITY_MISMATCH'):
        g.organization_runtime.start_production_run('fac:p','run:badkind',input_facts=[{'resource_ref':'RAW_WATER','quantity':3,'evidence_ref':'recipe:water'}],duration_seconds=0,start_evidence_ref='start:water',recipe_id='RECIPE_STERILE_WATER')
    with pytest.raises(OrganizationRuntimeError,match='PRODUCTION_RECIPE_INPUT_MISMATCH'):
        g.organization_runtime.start_production_run('fac:p','run:badinput',input_facts=[{'resource_ref':'ORE','quantity':2,'evidence_ref':'recipe:x'}],duration_seconds=0,start_evidence_ref='start:x',recipe_id='RECIPE_SCRAP_PARTS')

def test_recipe_output_is_bound_to_recipe_and_batch_maximum():
    g=_production_game(); g.organization_runtime.record_warehouse_flow('wh:in',direction='IN',resource_ref='SCRAP',quantity=4,evidence_ref='stock:scrap')
    g.organization_runtime.start_production_run('fac:p','run:r',input_facts=[{'resource_ref':'SCRAP','quantity':4,'evidence_ref':'recipe:r'}],duration_seconds=0,start_evidence_ref='start:r',recipe_id='RECIPE_SCRAP_PARTS')
    g.handle('/wait 1 h')
    with pytest.raises(OrganizationRuntimeError,match='PRODUCTION_RECIPE_OUTPUT_EXCEEDS_BATCH'):
        g.organization_runtime.resolve_production_run('run:r',outcome='FULL_SUCCESS',output_facts=[{'resource_ref':'PART','quantity':3,'evidence_ref':'prod:r'}],result_ref='result:r')

def test_facility_specialization_unlocks_higher_recipe_tier():
    g=game()
    for wid in ('wh:mi','wh:mo'): g.organization_runtime.create_warehouse(wid,location_id='site:med',display_name=wid,capacity_units=50,authority_ref='world:'+wid)
    g.organization_runtime.create_facility('fac:med',facility_kind='MEDICAL',location_id='site:med',input_warehouse_id='wh:mi',output_warehouse_id='wh:mo',authority_ref='industry:med')
    g.organization_runtime.record_warehouse_flow('wh:mi',direction='IN',resource_ref='MEDICAL_SUPPLY',quantity=2,evidence_ref='stock:med')
    g.organization_runtime.record_warehouse_flow('wh:mi',direction='IN',resource_ref='STERILE_WATER',quantity=1,evidence_ref='stock:water')
    facts=[{'resource_ref':'MEDICAL_SUPPLY','quantity':2,'evidence_ref':'recipe:med1'},{'resource_ref':'STERILE_WATER','quantity':1,'evidence_ref':'recipe:med2'}]
    with pytest.raises(OrganizationRuntimeError,match='PRODUCTION_RECIPE_SPECIALIZATION_TOO_LOW'):
        g.organization_runtime.start_production_run('fac:med','run:m1',input_facts=facts,duration_seconds=0,start_evidence_ref='start:m1',recipe_id='RECIPE_MEDKIT')
    g.organization_runtime.set_facility_specialization_level('fac:med',2,authority_ref='upgrade:med')
    run=g.organization_runtime.start_production_run('fac:med','run:m2',input_facts=facts,duration_seconds=0,start_evidence_ref='start:m2',recipe_id='RECIPE_MEDKIT')
    assert run['recipe_id']=='RECIPE_MEDKIT' and run['recipe_batches']==1
