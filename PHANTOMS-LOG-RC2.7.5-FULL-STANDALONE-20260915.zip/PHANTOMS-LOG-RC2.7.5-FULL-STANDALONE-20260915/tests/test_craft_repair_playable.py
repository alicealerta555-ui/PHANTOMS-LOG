from pathlib import Path
import tempfile, unittest
from collections import deque
from playable_full_version.playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, Domain
from runtime.full_version.search import SEARCH_STATE_PREFIX

ROOT=Path(__file__).resolve().parents[1]
class CraftRepairPlayableTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.g=FullVersionGame(core_root=ROOT,saves_root=Path(self.tmp.name),start_class='OPERATOR',master_seed=20260913)
        self.g.complete_character(self.g.creation_template()); self.addCleanup(self.g.images.close)
    def route_to(self,target):
        q=deque([(self.g.location(),[])]); seen={self.g.location()}
        while q:
            x,path=q.popleft()
            if x==target:
                for y in path: self.g.handle('/go '+y)
                return
            for y in self.g.catalog.location(x)['connections']:
                if y not in seen: seen.add(y); q.append((y,path+[y]))
        self.fail('route')
    def merchant(self):
        for i in self.g.actor_registry.instances():
            if i.actor_instance_id=='actor:player': continue
            r=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,i.actor_instance_id)
            if isinstance(r,dict) and r.get('role')=='merchant': return i.actor_instance_id,r
        self.fail('merchant')
    def buy_def(self,definition):
        mid,m=self.merchant(); self.route_to(m['location_ref'])
        for x in self.g.merchant_stock(mid):
            rec=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,x['instance_id'])
            if rec['item_definition_id']==definition:
                txt,_=self.g.handle('/buy '+x['instance_id']+' '+mid); self.assertIn('COMMITTED',txt); return x['instance_id']
        self.fail('stock def missing '+definition)
    def test_craft_consumes_real_input_and_materializes_output(self):
        iid=self.buy_def('item_def:component:029')
        txt,_=self.g.handle('/craft operation:04')
        self.assertIn('Hergestellt',txt)
        inp=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
        self.assertTrue(inp['location_ref'].startswith('consumed:'))
        crafted=[k for k in self.g.session.store.runtime_state if str(k).startswith('item:crafted:')]
        self.assertEqual(len(crafted),1)
    def test_repair_consumes_component_and_restores_bounded_condition(self):
        material=self.buy_def('item_def:component:021')
        # Search until a damaged item exists at current location, then take it.
        target=None
        for _ in range(4):
            self.g.handle('/search')
            for k in self.g.session.store.runtime_state:
                r=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,k)
                if isinstance(r,dict) and r.get('provenance')=='LOCATION_SEARCH' and r.get('location_ref')==self.g.location(): target=k; break
            if target: break
        self.assertIsNotNone(target); self.g.handle('/take '+target)
        before=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,target)['condition']
        txt,_=self.g.handle('/repair operation:03 '+target)
        self.assertIn('Repariert',txt)
        after=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,target)['condition']
        self.assertGreater(after,before); self.assertLessEqual(after,100)
        mat=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,material)
        self.assertTrue(mat['location_ref'].startswith('consumed:'))
