from pathlib import Path
from runtime.full_version.progression_quest_content import ProgressionQuestContent
ROOT=Path(__file__).resolve().parents[1]
def test_all_classes_have_progression_content():
 c=ProgressionQuestContent(ROOT)
 for cls in ('BREAKER','GHOST','OPERATOR','RESONANT'):
  assert len(c.class_candidates(cls))>=4
def test_specialization_content_is_eligibility_filtered():
 c=ProgressionQuestContent(ROOT)
 ids={x['quest_id'] for x in c.class_candidates('OPERATOR',specialization='CONTROLLER')}
 assert 'CQ_OPERATOR_SPEC_CONTROLLER' in ids
 assert 'CQ_OPERATOR_SPEC_GEARSMITH' not in ids
def test_all_legend_paths_have_three_capstones():
 c=ProgressionQuestContent(ROOT)
 assert len(c.legend_scenarios)==48
 for pid in {x['path_id'] for x in c.legend_scenarios.values()}:
  assert len(c.legend_candidates(pid))==3
def test_quest_groups_are_persistent_templates_not_resettable():
 c=ProgressionQuestContent(ROOT)
 assert len(c.quest_groups)==12
 assert all(x['persistent'] and x['state_reset_forbidden'] for x in c.quest_groups.values())
