import pytest
from runtime.full_version.organization_resource_flows import OrganizationResourceFlowPlanner, OrganizationResourceFlowError

def F(ref="SCRAP",q=2,e="EV"):
    return {"resource_ref":ref,"quantity":q,"evidence_ref":e,"location_id":"SITE"}

def test_dungeon_farming_cannot_invent_loot():
    p=OrganizationResourceFlowPlanner().plan(operation_kind="DUNGEON_FARM",outcome="FULL_SUCCESS")
    assert p.proposed_outputs==()

def test_authoritative_salvage_can_flow():
    p=OrganizationResourceFlowPlanner().plan(operation_kind="SALVAGE_RECOVERY",outcome="PARTIAL_SUCCESS",output_facts=[F()])
    assert p.proposed_outputs[0]["resource_ref"]=="SCRAP"

def test_production_requires_real_inputs_and_outputs():
    p=OrganizationResourceFlowPlanner().plan(operation_kind="PRODUCTION_CHAIN",outcome="FULL_SUCCESS",input_facts=[F("ORE",3,"E1")],output_facts=[F("PART",1,"E2")])
    assert not p.unresolved and p.accepted_inputs[0]["quantity"]==3

def test_production_without_input_is_unresolved_not_fabricated():
    p=OrganizationResourceFlowPlanner().plan(operation_kind="PRODUCTION_CHAIN",outcome="FULL_SUCCESS",output_facts=[F("PART",1,"E2")])
    assert "REAL_INPUTS_REQUIRED" in p.unresolved

def test_supply_requires_real_cargo():
    p=OrganizationResourceFlowPlanner().plan(operation_kind="SUPPLY_CHAIN",outcome="FAILURE")
    assert "REAL_CARGO_REQUIRED" in p.unresolved

def test_evidence_required():
    with pytest.raises(OrganizationResourceFlowError,match="OUTPUT_EVIDENCE_REQUIRED"):
        OrganizationResourceFlowPlanner().plan(operation_kind="DUNGEON_FARM",outcome="FULL_SUCCESS",output_facts=[{"resource_ref":"X","quantity":1}])
