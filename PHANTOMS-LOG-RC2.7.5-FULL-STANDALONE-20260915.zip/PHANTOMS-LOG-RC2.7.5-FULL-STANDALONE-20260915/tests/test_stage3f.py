from __future__ import annotations

import tempfile
import unittest
from uuid import uuid4

from runtime.stage3a.integration import RuntimeAuthorityBridge, RuntimeDelta
from runtime.stage3a.kernel import (
    Authority,
    CommitKernel,
    Delta,
    Domain,
    Mode,
    Proposal,
    StateStore,
    UnresolvedSpec,
    ValidationResult,
    Verdict,
    WeightedOption,
)
from runtime.stage3b.pipeline import (
    ActionRequest,
    ActionRule,
    Condition,
    Effect,
    Operator,
    OutcomeBranch,
    ValueSource,
)
from runtime.stage3c.isolation import FilesystemRunRepository, RunSessionManager
from runtime.stage3d.epistemic import epistemic_stamp
from runtime.stage3f.verification import (
    ALL_DIMENSIONS,
    TenfoldVerificationGate,
    VerificationDimension,
)


def meta(source: str, t: int, *, path=(), origin="A"):
    return epistemic_stamp(
        source_type="DIRECT_OBSERVATION",
        source_id=source,
        origin_location=origin,
        learned_at=t,
        path=path,
    )


class Stage3FTenfoldTests(unittest.TestCase):
    def make_session(self):
        manager = RunSessionManager(master_seed=20260903)
        session = manager.create_run(player_uuid=str(uuid4()), run_uuid=str(uuid4()))
        return manager, session

    def test_session_wires_same_tenfold_gate_into_action_and_commit(self):
        _, session = self.make_session()
        self.assertIs(session.kernel.precommit_guard, session.verification)
        self.assertIs(session.actions.verifier, session.verification)
        self.assertIs(session.verification.store, session.store)

    def test_commit_report_always_has_exactly_ten_dimensions(self):
        _, session = self.make_session()
        result = session.bridge.commit_runtime_event(
            event_id="F:10", cause="test",
            deltas=(RuntimeDelta("RUNTIME_STATE", "credits", 5, "RULE_KERNEL", "test"),),
        )
        self.assertNotIsInstance(result, ValidationResult)
        report = session.verification.last_commit_report
        self.assertIsNotNone(report)
        self.assertEqual(len(report.signals), 10)
        self.assertEqual(tuple(s.dimension for s in report.signals), ALL_DIMENSIONS)
        self.assertEqual(report.verdict, Verdict.PASS)

    def test_action_report_always_has_exactly_ten_dimensions(self):
        _, session = self.make_session()
        rule = ActionRule(
            "ok",
            outcomes=(OutcomeBranch("ok", effects=(Effect(
                Domain.RUNTIME_STATE, "energy", 4, "RULE_KERNEL", "spend",
            ),)),),
        )
        result = session.actions.execute(ActionRequest("A:10", rule, player_text="ordinary text"))
        self.assertEqual(result.status.value, "COMMITTED")
        report = session.verification.last_action_report
        self.assertIsNotNone(report)
        self.assertEqual(len(report.signals), 10)
        self.assertEqual(report.verdict, Verdict.PASS)

    # 1 STATE
    def test_state_dimension_rejects_conflicting_same_target_deltas(self):
        _, session = self.make_session()
        result = session.bridge.commit_runtime_event(
            event_id="F:state", cause="conflict",
            deltas=(
                RuntimeDelta("RUNTIME_STATE", "door", True, "RULE_KERNEL", "conflict"),
                RuntimeDelta("RUNTIME_STATE", "door", False, "RULE_KERNEL", "conflict"),
            ),
        )
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertTrue(any("V3F:STATE:CONFLICTING_COMMIT_DELTAS" in r for r in result.reasons))
        self.assertNotIn("door", session.store.runtime_state)

    def test_state_dimension_rejects_unresolved_truth_bypass(self):
        _, session = self.make_session()
        session.kernel.register_unresolved(UnresolvedSpec(
            "latent.color", (WeightedOption("red", 1), WeightedOption("blue", 1)),
        ))
        result = session.bridge.commit_runtime_event(
            event_id="F:bypass", cause="bad",
            deltas=(RuntimeDelta("WORLD_TRUTH", "latent.color", "red", "RULE_KERNEL", "bad"),),
        )
        self.assertIsInstance(result, ValidationResult)
        self.assertTrue(any("UNRESOLVED_TRUTH_RESOLVER_BYPASS" in r for r in result.reasons))
        self.assertNotIn("latent.color", session.store.world_truth)

    # 2 INVENTORY / RESOURCES
    def test_inventory_resource_dimension_rejects_negative_resource(self):
        _, session = self.make_session()
        result = session.bridge.commit_runtime_event(
            event_id="F:res", cause="bad",
            deltas=(RuntimeDelta("RUNTIME_STATE", "credits", -1, "RULE_KERNEL", "bad"),),
        )
        self.assertIsInstance(result, ValidationResult)
        self.assertTrue(any("V3F:INVENTORY_RESOURCES:NEGATIVE_RESOURCE:credits" == r for r in result.reasons))

    def test_inventory_resource_dimension_checks_nested_quantity(self):
        _, session = self.make_session()
        result = session.bridge.commit_runtime_event(
            event_id="F:inv", cause="bad",
            deltas=(RuntimeDelta(
                "RUNTIME_STATE", "inventory.pack", {"medkit": {"quantity": -1}}, "RULE_KERNEL", "bad",
            ),),
        )
        self.assertIsInstance(result, ValidationResult)
        self.assertTrue(any("NEGATIVE_RESOURCE_QUANTITY" in r for r in result.reasons))

    # 3 TIME
    def test_time_dimension_rejects_regression(self):
        _, session = self.make_session()
        session.bridge.commit_runtime_event(
            event_id="F:t0", cause="clock",
            deltas=(RuntimeDelta("RUNTIME_STATE", "time", 10, "RULE_KERNEL", "clock"),),
        )
        result = session.bridge.commit_runtime_event(
            event_id="F:t1", cause="clock",
            deltas=(RuntimeDelta("RUNTIME_STATE", "time", 9, "RULE_KERNEL", "clock"),),
        )
        self.assertIsInstance(result, ValidationResult)
        self.assertTrue(any("V3F:TIME:TIME_REGRESSION:time" == r for r in result.reasons))
        self.assertEqual(session.store.runtime_state["time"], 10)

    # 4 POSITION / SPACE
    def test_position_dimension_rejects_clearly_invalid_position(self):
        _, session = self.make_session()
        result = session.bridge.commit_runtime_event(
            event_id="F:pos", cause="move",
            deltas=(RuntimeDelta("RUNTIME_STATE", "position", "", "RULE_KERNEL", "move"),),
        )
        self.assertIsInstance(result, ValidationResult)
        self.assertTrue(any("V3F:POSITION_SPACE:INVALID_POSITION:position" == r for r in result.reasons))

    # 5 RULES / MECHANICS
    def test_rules_dimension_rechecks_selected_outcome_condition(self):
        store = StateStore()
        gate = TenfoldVerificationGate(store)
        outcome = OutcomeBranch("wrong", conditions=(Condition(ValueSource.RNG, "roll", Operator.GE, 10),))
        rule = ActionRule("r", random_draws=(), default_outcome=OutcomeBranch("fallback"))
        request = ActionRequest("F:rules", rule)
        decision = gate.verify(request=request, outcome=outcome, facts={}, rng={"roll": 3}, deltas=())
        self.assertEqual(decision.verdict, Verdict.REJECT)
        self.assertTrue(any("V3F:RULES_MECHANICS:OUTCOME_CONDITION_NOT_SATISFIED" in r for r in decision.reasons))

    # 6 CAUSALITY / PRECONDITIONS
    def test_causality_dimension_rechecks_precondition(self):
        store = StateStore()
        gate = TenfoldVerificationGate(store)
        rule = ActionRule(
            "r",
            facts=(),
            preconditions=(Condition(ValueSource.RNG, "roll", Operator.GE, 5),),
            random_draws=(),
            default_outcome=OutcomeBranch("ok"),
        )
        decision = gate.verify(
            request=ActionRequest("F:cause", rule), outcome=OutcomeBranch("ok"),
            facts={}, rng={"roll": 2}, deltas=(),
        )
        self.assertEqual(decision.verdict, Verdict.REJECT)
        self.assertTrue(any("V3F:CAUSALITY_PRECONDITIONS:PRECONDITION_NOT_SATISFIED" in r for r in decision.reasons))

    # 7 NPC KNOWLEDGE / EPISTEMICS
    def test_epistemic_dimension_rejects_knowledge_from_future(self):
        _, session = self.make_session()
        session.bridge.commit_runtime_event(
            event_id="F:clock", cause="clock",
            deltas=(RuntimeDelta("RUNTIME_STATE", "time", 5, "RULE_KERNEL", "clock"),),
        )
        result = session.epistemics.record_actor_observation(
            actor_id="NPC-A", fact_key="alarm", value=True, event_id="F:future",
            source_id="sensor", location="A", world_time=6,
        )
        self.assertIsInstance(result, ValidationResult)
        self.assertTrue(any("V3F:NPC_KNOWLEDGE_EPISTEMICS:KNOWLEDGE_FROM_FUTURE" in r for r in result.reasons))
        self.assertNotIn("NPC-A", session.store.actor_knowledge)

    def test_epistemic_dimension_rejects_discontinuous_route(self):
        _, session = self.make_session()
        bad_path = (
            {"edge_id": "e1", "from": "A", "to": "B", "channel": "road", "depart_at": 1, "arrive_at": 2},
            {"edge_id": "e2", "from": "C", "to": "D", "channel": "road", "depart_at": 2, "arrive_at": 3},
        )
        result = session.bridge.commit_runtime_event(
            event_id="F:path", cause="knowledge",
            deltas=(RuntimeDelta(
                "ACTOR_KNOWLEDGE", "rumor", "x", "KNOWLEDGE_ROUTER", "knowledge",
                actor_id="NPC-A", provenance="relay", epistemic=meta("relay", 3, path=bad_path, origin="A"),
            ),),
        )
        self.assertIsInstance(result, ValidationResult)
        self.assertTrue(any("KNOWLEDGE_ROUTE_DISCONTINUITY" in r for r in result.reasons))

    # 8 MEMORY / RETCON
    def test_memory_dimension_rejects_knowledge_timestamp_regression(self):
        _, session = self.make_session()
        first = session.bridge.commit_runtime_event(
            event_id="F:m0", cause="knowledge",
            deltas=(RuntimeDelta(
                "ACTOR_KNOWLEDGE", "door", "open", "KNOWLEDGE_ROUTER", "knowledge",
                actor_id="NPC-A", provenance="obs", epistemic=meta("obs", 5),
            ),),
        )
        self.assertNotIsInstance(first, ValidationResult)
        result = session.bridge.commit_runtime_event(
            event_id="F:m1", cause="knowledge",
            deltas=(RuntimeDelta(
                "ACTOR_KNOWLEDGE", "door", "closed", "KNOWLEDGE_ROUTER", "knowledge",
                actor_id="NPC-A", provenance="obs2", epistemic=meta("obs2", 4),
            ),),
        )
        self.assertIsInstance(result, ValidationResult)
        self.assertTrue(any("V3F:MEMORY_RETCON:KNOWLEDGE_TIME_REGRESSION:door" == r for r in result.reasons))

    def test_memory_dimension_rejects_retcon_of_immutable_resolved_truth(self):
        _, session = self.make_session()
        session.kernel.register_unresolved(UnresolvedSpec(
            "latent.owner", (WeightedOption("A", 1), WeightedOption("B", 1)), immutable_after_resolution=True,
        ))
        resolved = session.ground_truth.resolve_unknown("latent.owner", event_id="F:resolve")
        self.assertNotIsInstance(resolved, ValidationResult)
        old = session.store.world_truth["latent.owner"]
        new = "B" if old == "A" else "A"
        result = session.bridge.commit_runtime_event(
            event_id="F:retcon", cause="retcon",
            deltas=(RuntimeDelta("WORLD_TRUTH", "latent.owner", new, "RULE_KERNEL", "retcon"),),
        )
        self.assertIsInstance(result, ValidationResult)
        self.assertTrue(any("IMMUTABLE_RESOLVED_TRUTH_RETCON" in r for r in result.reasons))
        self.assertEqual(session.store.world_truth["latent.owner"], old)

    # 9 PLAYER AGENCY
    def test_player_agency_dimension_rejects_engine_invented_choice(self):
        _, session = self.make_session()
        result = session.bridge.commit_runtime_event(
            event_id="F:agency", cause="bad",
            deltas=(RuntimeDelta("RUNTIME_STATE", "player.choice.route", "left", "RULE_KERNEL", "bad"),),
        )
        self.assertIsInstance(result, ValidationResult)
        self.assertTrue(any("V3F:PLAYER_AGENCY:ENGINE_WRITES_PLAYER_CHOICE" in r for r in result.reasons))

    # 10 NARRATION VS COMMIT
    def test_narration_dimension_rejects_hidden_domain_projection_request(self):
        store = StateStore()
        gate = TenfoldVerificationGate(store)
        rule = ActionRule("r", default_outcome=OutcomeBranch("ok"), narration_runtime_keys=("WORLD_TRUTH",))
        decision = gate.verify(
            request=ActionRequest("F:narr", rule), outcome=rule.default_outcome,
            facts={}, rng={}, deltas=(),
        )
        self.assertEqual(decision.verdict, Verdict.REJECT)
        self.assertTrue(any("V3F:NARRATION_VS_COMMIT:HIDDEN_DOMAIN_NARRATION_REQUEST" in r for r in decision.reasons))

    def test_safe_narration_projection_passes_independent_check(self):
        _, session = self.make_session()
        session.bridge.commit_runtime_event(
            event_id="F:narr2", cause="state",
            deltas=(RuntimeDelta("RUNTIME_STATE", "position", "A", "RULE_KERNEL", "state"),),
        )
        view = session.bridge.project_player_narration(runtime_keys=("position",))
        decision = session.verification.verify_narration_projection(view)
        self.assertEqual(decision.verdict, Verdict.PASS)
        self.assertNotIn("WORLD_TRUTH", view)

    # false-veto / uncertainty behavior
    def test_player_text_is_never_semantically_scanned_for_veto(self):
        _, session = self.make_session()
        rule = ActionRule(
            "text-safe",
            outcomes=(OutcomeBranch("ok", effects=(Effect(
                Domain.RUNTIME_STATE, "credits", 1, "RULE_KERNEL", "award",
            ),)),),
        )
        text = "I mention -999 credits, impossible teleportation, death, retcon and WORLD_TRUTH, but this is only prose."
        result = session.actions.execute(ActionRequest("F:false-veto", rule, player_text=text))
        self.assertEqual(result.status.value, "COMMITTED")
        signal = session.verification.last_action_report.signal(VerificationDimension.PLAYER_AGENCY)
        self.assertIn("PLAYER_TEXT_NOT_USED_AS_VETO_SIGNAL", signal.notes)

    def test_unclassified_negative_value_is_not_false_veto(self):
        _, session = self.make_session()
        result = session.bridge.commit_runtime_event(
            event_id="F:temp", cause="weather",
            deltas=(RuntimeDelta("RUNTIME_STATE", "temperature", -20, "RULE_KERNEL", "weather"),),
        )
        self.assertNotIsInstance(result, ValidationResult)
        self.assertEqual(session.store.runtime_state["temperature"], -20)

    def test_unknown_structured_state_passes_when_no_hard_contradiction_is_proven(self):
        _, session = self.make_session()
        payload = {"unclassified": {"maybe": "unknown"}}
        result = session.bridge.commit_runtime_event(
            event_id="F:unknown", cause="state",
            deltas=(RuntimeDelta("RUNTIME_STATE", "custom.system", payload, "RULE_KERNEL", "state"),),
        )
        self.assertNotIsInstance(result, ValidationResult)

    def test_global_gate_catches_non_action_negative_resource(self):
        _, session = self.make_session()
        # Direct bridge simulates a world/system producer path, not ActionPipeline.
        result = session.bridge.commit_runtime_event(
            event_id="F:global", cause="world-sim",
            deltas=(RuntimeDelta("RUNTIME_STATE", "energy", -5, "RULE_KERNEL", "world-sim"),),
        )
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)

    def test_gate_is_run_local_and_survives_save_reload_reconstruction(self):
        manager, session = self.make_session()
        other = manager.create_run(player_uuid=str(uuid4()), run_uuid=str(uuid4()))
        self.assertIsNot(session.verification, other.verification)
        self.assertIsNot(session.verification.store, other.verification.store)
        session.bridge.commit_runtime_event(
            event_id="F:save", cause="state",
            deltas=(RuntimeDelta("RUNTIME_STATE", "credits", 2, "RULE_KERNEL", "state"),),
        )
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(td)
            repo.save(session)
            identity = session.identity
            manager.close_run(player_uuid=identity.player_uuid, run_uuid=identity.run_uuid)
            loaded = repo.load_session(manager, identity)
            self.assertIs(loaded.kernel.precommit_guard, loaded.verification)
            self.assertIs(loaded.verification.store, loaded.store)
            bad = loaded.bridge.commit_runtime_event(
                event_id="F:save-bad", cause="bad",
                deltas=(RuntimeDelta("RUNTIME_STATE", "credits", -2, "RULE_KERNEL", "bad"),),
            )
            self.assertIsInstance(bad, ValidationResult)

    def test_system_init_knowledge_bootstrap_remains_compatible(self):
        store = StateStore()
        gate = TenfoldVerificationGate(store)
        kernel = CommitKernel(store, world_seed=1, precommit_guard=gate)
        result = kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id="F:init-k",
            cause="bootstrap",
            deltas=(Delta(
                Domain.PLAYER_KNOWLEDGE, "known.rule", True, Authority.SYSTEM_INIT,
                "bootstrap", source_event_id="F:init-k", provenance="STATIC_BOOTSTRAP",
            ),),
        ))
        self.assertNotIsInstance(result, ValidationResult)


if __name__ == "__main__":
    unittest.main()
