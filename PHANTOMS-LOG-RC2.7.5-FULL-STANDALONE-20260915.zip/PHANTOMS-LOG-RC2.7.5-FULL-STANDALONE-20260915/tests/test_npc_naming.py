from runtime.player_progression.npc_naming import (
    NPCNameGenerator, NPCNameRegistry, NameRequest, PROFILES,
)


def test_profiles_exist_for_all_core_families():
    expected = {"baseline_human", "genmorph", "chimera", "ferrite", "silicier", "mycelial", "mimetic", "swarm", "thresholdborn"}
    assert expected <= set(PROFILES)


def test_name_generation_is_deterministic():
    req = NameRequest("npc-1", "thresholdborn", force_callsign=True, known_to_player=True)
    a = NPCNameGenerator(seed="x").generate(req)
    b = NPCNameGenerator(seed="x").generate(req)
    assert a.full_name == b.full_name


def test_persisted_identity_never_regenerates():
    g = NPCNameGenerator(seed="x")
    req = NameRequest("npc-2", "chimera", force_callsign=True, known_to_player=True)
    first = g.generate(req)
    second = g.generate(NameRequest("npc-2", "baseline_human", known_to_player=True))
    assert first == second


def test_callsign_is_middle_element():
    g = NPCNameGenerator(seed="x")
    n = g.generate(NameRequest("npc-3", "ferrite", force_callsign=True, known_to_player=True))
    assert n.callsign
    assert f'“{n.callsign}”' in n.full_name
    assert n.full_name.index(f'“{n.callsign}”') > 0


def test_unknown_player_does_not_get_name_leak():
    g = NPCNameGenerator(seed="x")
    n = g.generate(NameRequest("npc-4", "silicier", known_to_player=False))
    assert n.display_name == "Unbekannte Person"
    assert n.full_name != n.display_name


def test_human_culture_can_override_hybrid_phonetics():
    g = NPCNameGenerator(seed="x")
    n = g.generate(NameRequest("npc-5", "ferrite", culture_profile="baseline_human", known_to_player=True))
    assert n.phonetic_pattern == "human_culture_override"
    assert any(x in n.full_name for x in ("Vuković", "Okafor", "Krämer", "Idris", "Nguyen", "Serrano", "Omura", "Darzi", "Becker", "Kovács", "Park", "Mensah", "Rahman", "Novak"))


def test_exotic_profiles_can_produce_nonstandard_marks():
    marks = set("'·:-~/")
    seen = set()
    g = NPCNameGenerator(seed="marks")
    for i in range(80):
        n = g.generate(NameRequest(f"thr-{i}", "thresholdborn", known_to_player=True))
        seen |= set(n.full_name) & marks
    assert seen


def test_exotic_profiles_show_pattern_variety():
    g = NPCNameGenerator(seed="patterns")
    patterns = {g.generate(NameRequest(f"c-{i}", "chimera", known_to_player=True)).phonetic_pattern for i in range(80)}
    assert len(patterns) >= 3


def test_registry_roundtrip():
    g = NPCNameGenerator(seed="x")
    n = g.generate(NameRequest("npc-8", "swarm", force_callsign=True, known_to_player=True))
    raw = g.registry.to_dict()
    restored = NPCNameRegistry.from_dict(raw)
    assert restored.names["npc-8"].full_name == n.full_name
    assert n.full_name in restored.used_full_names


def test_reveal_levels_are_epistemic():
    g = NPCNameGenerator(seed="x")
    n = g.generate(NameRequest("npc-9", "thresholdborn", force_callsign=True, known_to_player=False))
    assert g.reveal("npc-9", "unknown") == "Unbekannte Person"
    assert g.reveal("npc-9", "given") == n.canonical_given
    assert n.canonical_given in g.reveal("npc-9", "callsign")
    assert g.reveal("npc-9", "full") == n.full_name


def test_collision_repair_preserves_uniqueness():
    reg = NPCNameRegistry()
    g = NPCNameGenerator(registry=reg, seed="same")
    a = g.generate(NameRequest("a", "baseline_human", given_name_hint="Mara", family_name_hint="Vuković", allow_callsign=False, known_to_player=True))
    b = g.generate(NameRequest("b", "baseline_human", given_name_hint="Mara", family_name_hint="Vuković", allow_callsign=False, known_to_player=True))
    assert a.full_name != b.full_name


def test_thresholdborn_need_not_be_easy_to_pronounce():
    g = NPCNameGenerator(seed="alien")
    values = [g.generate(NameRequest(f"alien-{i}", "thresholdborn", known_to_player=True)).full_name for i in range(40)]
    assert any(any(cluster in n.lower() for cluster in ("qhh", "rrh", "tzh", "kth", "nkh", "khh")) for n in values)
