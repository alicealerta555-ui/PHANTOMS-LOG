
import json,unittest
from pathlib import Path
from runtime.content_stage48.communications import *
ROOT=Path(__file__).resolve().parents[1]; D=json.loads((ROOT/"content/full_version/stage48_communications.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_channels(self): self.assertGreaterEqual(len(D["channels"]),4)
 def test_message(self): self.assertIsNotNone(message_record("M","A","REF",1))
 def test_transmission_requires_channel(self): self.assertIsNone(transmission_candidate("M","","A","B",True,1,"EV"))
 def test_transmission_authority(self): self.assertTrue(transmission_candidate("M","C","A","B",True,1,"EV")["authority_required"])
 def test_delivery_latency(self):
  self.assertEqual(delivery_state(True,True,0,5),"IN_TRANSIT"); self.assertEqual(delivery_state(True,True,5,5),"DELIVERED")
 def test_delivery_blocked(self): self.assertEqual(delivery_state(True,False,10,1),"BLOCKED")
 def test_capacity_condition(self): self.assertEqual(network_capacity(100,100,50),50)
 def test_broadcast_bounded_by_coverage(self): self.assertEqual(broadcast_reach(100,50),50)
 def test_outage_authority(self): self.assertTrue(outage_candidate("N","FAIL",["RADIO_SHORT"],1,"EV")["authority_required"])
 def test_sent_not_delivered_rule(self): self.assertTrue(any("not automatically delivered" in x.lower() for x in D["rules"]))
 def test_no_memory_erase_rule(self): self.assertTrue(any("do not erase already received" in x.lower() for x in D["rules"]))
if __name__=="__main__": unittest.main()
