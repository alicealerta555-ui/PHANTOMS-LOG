from __future__ import annotations
import json,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class ActorIntelligenceLogicContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.state=json.loads((ROOT/'master'/'PROJECT_STATE.json').read_text(encoding='utf-8'))
        cls.logic=(ROOT/'master'/'ACTOR_INTELLIGENCE_LOGIC.md').read_text(encoding='utf-8')
    def test_enabled_logic_is_compact(self):
        a=self.state['actor_intelligence_logic']
        self.assertEqual(a['enabled_decisions'],['YES','NO','MAYBE'])
    def test_both_neither_reserved_disabled(self):
        a=self.state['actor_intelligence_logic']
        self.assertEqual(a['reserved_disabled_decisions'],['BOTH','NEITHER'])
        self.assertTrue(a['training_requires_no_both_neither_targets'])
    def test_engine_keeps_truth_and_commit(self):
        a=self.state['actor_intelligence_logic']
        self.assertTrue(a['world_truth_owned_by_engine'])
        self.assertTrue(a['commit_owned_by_engine'])
    def test_scope_is_intelligence_only(self):
        self.assertIn('interpretation of already-available perception',self.logic)
        self.assertIn('does **not** own raw sensing',self.logic)
if __name__=='__main__': unittest.main()
