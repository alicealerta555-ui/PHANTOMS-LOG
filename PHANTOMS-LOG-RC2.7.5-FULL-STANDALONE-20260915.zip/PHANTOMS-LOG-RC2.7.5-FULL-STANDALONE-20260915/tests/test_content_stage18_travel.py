
import json,unittest
from pathlib import Path
from runtime.content_stage18.travel import *
ROOT=Path(__file__).resolve().parents[1]; D=json.loads((ROOT/"content/full_version/stage18_travel.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_routes(self): self.assertGreaterEqual(len(D["routes"]),5)
 def test_profiles(self): self.assertGreaterEqual(len(D["transport_profiles"]),4)
 def test_explicit_route(self):
  r=D["routes"][0]; t=D["transport_profiles"][0]; self.assertGreater(travel_minutes(r,t),0)
 def test_disallowed_transport(self):
  r=D["routes"][2]; t=next(x for x in D["transport_profiles"] if x["id"]=="TR_CART"); self.assertIsNone(travel_minutes(r,t))
 def test_capacity(self):
  t=D["transport_profiles"][0]; self.assertTrue(cargo_allowed(t,25)); self.assertFalse(cargo_allowed(t,26))
 def test_travel_authority(self):
  p=travel_proposal(D["routes"][0],D["transport_profiles"][0],["a"],10,"EV"); self.assertTrue(p["authority_required"])
 def test_overload_rejected(self):
  self.assertIsNone(travel_proposal(D["routes"][0],D["transport_profiles"][0],["a"],999,"EV"))
 def test_hazard_deterministic(self):
  r=dict(D["routes"][0]); r["hazard_bp"]=10000
  self.assertEqual(hazard_candidate(r,D["hazards"],"seed"),hazard_candidate(r,D["hazards"],"seed"))
 def test_hazard_authority(self):
  r=dict(D["routes"][0]); r["hazard_bp"]=10000; self.assertTrue(hazard_candidate(r,D["hazards"],"x")["authority_required"])
 def test_cargo_provenance(self):
  c=cargo_record("v","o",{"food":2},5,"A","B",1,["SRC"]); self.assertTrue(validate_cargo(c)); self.assertEqual(c["provenance"],["SRC"])
if __name__=="__main__": unittest.main()
