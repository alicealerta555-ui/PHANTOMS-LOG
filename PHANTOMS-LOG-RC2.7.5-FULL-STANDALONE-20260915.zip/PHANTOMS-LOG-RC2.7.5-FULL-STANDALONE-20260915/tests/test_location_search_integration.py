from pathlib import Path
import tempfile
import unittest

from playable_full_version.playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, Domain
from runtime.stage9.world_time import WorldClock
from runtime.full_version.search import SEARCH_STATE_PREFIX

ROOT=Path(__file__).resolve().parents[1]

class LocationSearchIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.game=FullVersionGame(core_root=ROOT,saves_root=Path(self.tmp.name),start_class='OPERATOR',master_seed=20260913)
        self.game.complete_character(self.game.creation_template())
        self.addCleanup(self.game.images.close)

    def test_search_commits_state_and_advances_time(self):
        before=WorldClock(self.game.session).seconds
        text,_=self.game.handle('/search')
        after=WorldClock(self.game.session).seconds
        self.assertGreater(after,before)
        state=self.game.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,SEARCH_STATE_PREFIX+self.game.location())
        self.assertEqual(state['search_count'],1)
        self.assertIn('Sekunden Weltzeit',text)

    def test_search_result_persists_reload(self):
        self.game.handle('/search')
        loc=self.game.location()
        before=self.game.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,SEARCH_STATE_PREFIX+loc)
        self.game.save()
        g2=FullVersionGame(core_root=ROOT,saves_root=Path(self.tmp.name),master_seed=20260913)
        self.addCleanup(g2.images.close)
        after=g2.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,SEARCH_STATE_PREFIX+loc)
        self.assertEqual(before,after)

    def test_search_is_bounded_no_infinite_loot(self):
        loc=self.game.location()
        for _ in range(8): self.game.handle('/search')
        state=self.game.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,SEARCH_STATE_PREFIX+loc)
        rules=self.game.catalog.search_tables['rules']
        self.assertLessEqual(len(state['resource_finds']),rules['max_resource_finds_per_location'])
        self.assertLessEqual(len(state['information_finds']),rules['max_information_finds_per_location'])
        found=[]
        for key in self.game.session.store.runtime_state:
            rec=self.game.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
            if isinstance(rec,dict) and rec.get('provenance')=='LOCATION_SEARCH' and rec.get('source_location_id')==loc:
                found.append(key)
        self.assertLessEqual(len(found),2)

    def test_found_item_can_be_taken(self):
        loc=self.game.location(); iid=None
        for _ in range(4):
            self.game.handle('/search')
            state=self.game.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,SEARCH_STATE_PREFIX+loc)
            for key in self.game.session.store.runtime_state:
                rec=self.game.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,key)
                if isinstance(rec,dict) and rec.get('provenance')=='LOCATION_SEARCH' and rec.get('location_ref')==loc:
                    iid=key; break
            if iid: break
        self.assertIsNotNone(iid)
        text,_=self.game.handle('/take '+iid)
        self.assertIn('COMMITTED',text)
        rec=self.game.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,iid)
        self.assertEqual(rec['location_ref'],'inventory:actor:player')

    def test_search_knowledge_is_local_observation(self):
        self.game.handle('/search')
        loc=self.game.location()
        state=self.game.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,SEARCH_STATE_PREFIX+loc)
        self.assertTrue(state['information_finds'])
        info=state['information_finds'][0]
        key=f'local_observation:{loc}:{info}'
        value=self.game.session.kernel.read(Authority.KNOWLEDGE_ROUTER,Domain.ACTOR_KNOWLEDGE,key,actor_id='actor:player')
        self.assertIsInstance(value,dict)
        self.assertEqual(value['value']['location_id'],loc)
        self.assertEqual(value['epistemic']['source_type'],'DIRECT_OBSERVATION')

if __name__=='__main__': unittest.main()
