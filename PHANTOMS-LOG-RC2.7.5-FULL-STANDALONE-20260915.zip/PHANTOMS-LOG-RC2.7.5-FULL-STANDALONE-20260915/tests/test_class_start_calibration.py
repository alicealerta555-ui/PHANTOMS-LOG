from pathlib import Path

from runtime.full_version.catalog import FullVersionCatalog
from runtime.full_version.lifetime_start import build_lifetime_start, canonical_origin_label
from playable_full_version.playable.location_naming import present_location

ROOT=Path(__file__).resolve().parents[1]


def test_exact_four_classes_and_no_legacy_class_start_payloads():
    c=FullVersionCatalog.load(ROOT)
    starts=c.world['character_class_starts']
    assert {x['start_class'] for x in starts} == {'BREAKER','GHOST','OPERATOR','RESONANT'}
    forbidden={'start_categories','starting_item_groups','starting_knowledge','starter_impulses'}
    assert all(not (forbidden & set(x)) for x in starts)


def test_lifetime_start_is_run_stable_and_class_independent():
    c=FullVersionCatalog.load(ROOT)
    labels={x['region_id']:x['display_name'] for x in c.world.get('regions',[])}
    a=build_lifetime_start(c.world,'run-A',region_labels=labels)
    b=build_lifetime_start(c.world,'run-A',region_labels=labels)
    assert a==b
    assert a['start']['class_independent'] is True
    assert a['start']['settlement_scale']=='SMALL_OUTSKIRT_SETTLEMENT'
    assert a['start']['region_id']=='region:04'
    assert a['start']['location_id'] != a['estate']['target_location_id']
    assert canonical_origin_label(a)


def test_diary_is_broad_clue_never_exact_world_truth():
    c=FullVersionCatalog.load(ROOT)
    state=build_lifetime_start(c.world,'run-B')
    diary=state['diary']; estate=state['estate']
    assert diary['exact_location_known'] is False
    assert estate['target_location_id'] not in diary['note']
    target=c.location(estate['target_location_id'])
    assert target['display_name'] not in diary['note']
    assert diary['target_region_id']==estate['target_region_id']


def test_generation_policy_is_explicitly_enabled():
    c=FullVersionCatalog.load(ROOT)
    state=build_lifetime_start(c.world,'run-C')
    policy=state['generation_policy']
    assert policy['descendant_inheritance_enabled'] is True
    assert {'assets','debts','diaries','contacts','reputation','open_obligations','unresolved_traces'} <= set(policy['inherits'])


def test_location_names_stable_within_run_and_can_vary_between_runs():
    c=FullVersionCatalog.load(ROOT)
    loc=dict(c.world['locations'][0])
    assert present_location(loc,'r1')['display_name']==present_location(loc,'r1')['display_name']
    names={present_location(loc,f'run-{i}')['display_name'] for i in range(12)}
    assert len(names)>1
    assert all('Habitat 0' not in n and 'Works 0' not in n for n in names)
