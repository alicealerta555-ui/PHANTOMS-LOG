import unittest

from runtime.stage3a.kernel import (
    Authority, CommitKernel, CommitRecord, Domain, Stage3AError, StateStore,
    UnresolvedSpec, ValidationResult, Verdict, WeightedOption,
)
from runtime.stage3a.integration import FixedPhaseCommitBuffer, RuntimeAuthorityBridge, RuntimeDelta
from runtime.stage3d.epistemic import epistemic_stamp


def epi_meta(source="test", t=1):
    return epistemic_stamp(source_type="DIRECT_OBSERVATION", source_id=source, origin_location="TEST", learned_at=t)



class RuntimeIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.store = StateStore()
        self.kernel = CommitKernel(self.store, world_seed=20260903)
        self.bridge = RuntimeAuthorityBridge(self.kernel)

    def test_rule_delta_flows_through_single_commit_kernel(self):
        rec = self.bridge.commit_runtime_event(
            event_id="TURN-1", cause="move",
            deltas=(RuntimeDelta("RUNTIME_STATE", "position", "B", "RULE_KERNEL", "move"),),
        )
        self.assertIsInstance(rec, CommitRecord)
        self.assertEqual(self.store.runtime_state["position"], "B")

    def test_unknown_domain_fails_closed(self):
        with self.assertRaises(Stage3AError):
            self.bridge.commit_runtime_event(
                event_id="TURN-2", cause="bad",
                deltas=(RuntimeDelta("WORLD_STATE", "x", 1, "RULE_KERNEL", "bad"),),
            )
        self.assertNotIn("x", self.store.runtime_state)

    def test_unknown_producer_fails_closed(self):
        with self.assertRaises(Stage3AError):
            self.bridge.commit_runtime_event(
                event_id="TURN-3", cause="bad",
                deltas=(RuntimeDelta("WORLD_TRUTH", "x", 1, "NARRATOR", "bad"),),
            )
        self.assertNotIn("x", self.store.world_truth)

    def test_player_query_is_no_commit(self):
        before = self.store.state_hash()
        result = self.bridge.query_player_text("Ist hinter der Tür jemand?", suggestion=True)
        self.assertEqual(result.verdict, Verdict.HOLD)
        self.assertEqual(before, self.store.state_hash())

    def test_registration_is_a_real_commit(self):
        rec = self.kernel.register_unresolved(
            UnresolvedSpec("door.enemy", (WeightedOption(True, 1), WeightedOption(False, 1)))
        )
        self.assertIsInstance(rec, CommitRecord)
        self.assertEqual(self.store.revision, 1)
        self.assertIn("INIT_UNRESOLVED:door.enemy", self.store.event_ledger)

    def test_resolution_consumes_unresolved_and_commits_truth(self):
        self.kernel.register_unresolved(
            UnresolvedSpec("door.enemy", (WeightedOption(True, 1), WeightedOption(False, 1)))
        )
        rec = self.bridge.resolve_unknown("door.enemy", event_id="RES-1")
        self.assertIsInstance(rec, CommitRecord)
        self.assertIn("door.enemy", self.store.world_truth)
        self.assertNotIn("door.enemy", self.store.unresolved_world)

    def test_player_suggestion_does_not_change_resolution(self):
        def one(suggestion):
            store = StateStore()
            kernel = CommitKernel(store, world_seed=77)
            bridge = RuntimeAuthorityBridge(kernel)
            kernel.register_unresolved(UnresolvedSpec(
                "x", (WeightedOption("A", 1), WeightedOption("B", 3)), seed_salt="same"
            ))
            bridge.resolve_unknown("x", event_id="RES-X", player_suggestion=suggestion)
            return store.world_truth["x"]
        self.assertEqual(one("A"), one("B"))
        self.assertEqual(one("A"), one(None))

    def test_actor_context_does_not_include_world_truth(self):
        self.store.world_truth["secret"] = "omega"
        self.bridge.commit_runtime_event(
            event_id="K-1", cause="heard",
            deltas=(RuntimeDelta(
                "ACTOR_KNOWLEDGE", "heard_alarm", True, "KNOWLEDGE_ROUTER", "heard",
                actor_id="NPC-1", provenance="OBS:alarm", epistemic=epi_meta("alarm", 4)
            ),),
        )
        view = self.bridge.project_actor_context("NPC-1", knowledge_keys=("heard_alarm",))
        self.assertNotIn("WORLD_TRUTH", view)
        self.assertEqual(view["ACTOR_KNOWLEDGE"]["heard_alarm"], True)
        self.assertNotIn("secret", view["ACTOR_KNOWLEDGE"])

    def test_narrator_projection_does_not_include_world_truth(self):
        self.store.world_truth["secret"] = "omega"
        self.bridge.commit_runtime_event(
            event_id="PK-1", cause="observed",
            deltas=(RuntimeDelta(
                "PLAYER_KNOWLEDGE", "door.open", True, "KNOWLEDGE_ROUTER", "observed",
                provenance="OBS:door", epistemic=epi_meta("door", 5)
            ),),
        )
        view = self.bridge.project_player_narration()
        self.assertNotIn("WORLD_TRUTH", view)
        self.assertNotIn("UNRESOLVED_WORLD", view)
        self.assertEqual(view["PLAYER_KNOWLEDGE"]["door.open"], True)

    def test_narrator_runtime_is_explicit_allowlist(self):
        self.store.runtime_state["visible.time"] = "10:00"
        self.store.runtime_state["hidden.seed"] = 1234
        view = self.bridge.project_player_narration(runtime_keys=("visible.time",))
        self.assertEqual(view["PRESENTATION_RUNTIME"], {"visible.time": "10:00"})
        self.assertNotIn("hidden.seed", view["PRESENTATION_RUNTIME"])

    def test_fixed_phase_buffer_accepts_p0_p9_only(self):
        buf = FixedPhaseCommitBuffer(self.bridge, "SIM-1", "world tick")
        buf.add("P0", RuntimeDelta("RUNTIME_STATE", "time", 1, "RULE_KERNEL", "tick"))
        buf.add("P9", RuntimeDelta("WORLD_TRUTH", "weather", "rain", "RULE_KERNEL", "weather tick"))
        rec = buf.commit_once()
        self.assertIsInstance(rec, CommitRecord)
        self.assertEqual(self.store.revision, 1)
        self.assertEqual(self.store.runtime_state["time"], 1)
        self.assertEqual(self.store.world_truth["weather"], "rain")

    def test_fixed_phase_buffer_rejects_unknown_phase(self):
        buf = FixedPhaseCommitBuffer(self.bridge, "SIM-2", "world tick")
        with self.assertRaises(Stage3AError):
            buf.add("P10", RuntimeDelta("RUNTIME_STATE", "time", 1, "RULE_KERNEL", "tick"))

    def test_fixed_phase_buffer_commits_only_once(self):
        buf = FixedPhaseCommitBuffer(self.bridge, "SIM-3", "world tick")
        buf.add("P0", RuntimeDelta("RUNTIME_STATE", "time", 1, "RULE_KERNEL", "tick"))
        buf.commit_once()
        with self.assertRaises(Stage3AError):
            buf.commit_once()

    def test_mixed_phase_transaction_is_atomic(self):
        before = self.store.state_hash()
        buf = FixedPhaseCommitBuffer(self.bridge, "SIM-4", "mixed")
        buf.add("P0", RuntimeDelta("RUNTIME_STATE", "good", 1, "RULE_KERNEL", "good"))
        # KNOWLEDGE_ROUTER cannot write WORLD_TRUTH.
        buf.add("P1", RuntimeDelta("WORLD_TRUTH", "bad", 1, "KNOWLEDGE_ROUTER", "bad"))
        result = buf.commit_once()
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertEqual(before, self.store.state_hash())

    def test_duplicate_runtime_event_has_no_second_effect(self):
        delta = RuntimeDelta("RUNTIME_STATE", "credits", 10, "RULE_KERNEL", "award")
        first = self.bridge.commit_runtime_event(event_id="DUP-1", cause="award", deltas=(delta,))
        rev = self.store.revision
        second = self.bridge.commit_runtime_event(event_id="DUP-1", cause="award", deltas=(delta,))
        self.assertIsInstance(first, CommitRecord)
        self.assertIsInstance(second, ValidationResult)
        self.assertEqual(second.verdict, Verdict.HOLD)
        self.assertEqual(self.store.revision, rev)

    def test_direct_rule_kernel_as_commit_source_is_rejected(self):
        from runtime.stage3a.kernel import Delta, Mode, Proposal
        result = self.kernel.process(Proposal(
            mode=Mode.COMMIT, source=Authority.RULE_KERNEL, event_id="DIRECT-1", cause="bad",
            deltas=(Delta(Domain.RUNTIME_STATE, "x", 1, Authority.RULE_KERNEL, "bad"),),
        ))
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertNotIn("x", self.store.runtime_state)

    def test_source_event_mismatch_rejected(self):
        from runtime.stage3a.kernel import Delta, Mode, Proposal
        result = self.kernel.process(Proposal(
            mode=Mode.COMMIT, source=Authority.COMMIT_KERNEL, event_id="E-A", cause="mismatch",
            deltas=(Delta(Domain.RUNTIME_STATE, "x", 1, Authority.RULE_KERNEL, "mismatch", source_event_id="E-B"),),
        ))
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertTrue(any("SOURCE_EVENT_MISMATCH" in r for r in result.reasons))

    def test_non_json_state_value_rejected(self):
        bad_value = {"x": {1, 2, 3}}
        result = self.bridge.commit_runtime_event(
            event_id="JSON-1", cause="bad value",
            deltas=(RuntimeDelta("RUNTIME_STATE", "bad", bad_value, "RULE_KERNEL", "bad value"),),
        )
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertNotIn("bad", self.store.runtime_state)

    def test_unresolved_duplicate_registration_fails_closed(self):
        spec = UnresolvedSpec("same", (WeightedOption("A", 1), WeightedOption("B", 1)))
        self.kernel.register_unresolved(spec)
        with self.assertRaises(Stage3AError):
            self.kernel.register_unresolved(spec, event_id="INIT-OTHER")

    def test_projection_guard_rejects_injected_world_truth(self):
        from runtime.stage3a.kernel import NarrationGate
        with self.assertRaises(Stage3AError):
            NarrationGate.assert_projection_safe({"WORLD_TRUTH": {"secret": 1}})

    def test_commit_record_revision_matches_store_revision(self):
        rec = self.bridge.commit_runtime_event(
            event_id="REV-1", cause="revision",
            deltas=(RuntimeDelta("RUNTIME_STATE", "x", 1, "RULE_KERNEL", "revision"),),
        )
        self.assertEqual(rec.revision, self.store.revision)


if __name__ == "__main__":
    unittest.main(verbosity=2)
