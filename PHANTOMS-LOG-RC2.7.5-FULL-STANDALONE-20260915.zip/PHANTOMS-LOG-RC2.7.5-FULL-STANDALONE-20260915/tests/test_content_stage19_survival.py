
import json,unittest
from pathlib import Path
from runtime.content_stage19.survival import *
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage19_survival.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_weather(self):
  self.assertGreaterEqual(len(D["weather_profiles"]),5)

 def test_need_drift(self):
  n={"hunger":0,"thirst":0,"fatigue":0,"exposure":0}
  x=apply_need_drift(n,360)
  self.assertGreater(x["hunger"],0); self.assertGreater(x["thirst"],0); self.assertGreater(x["fatigue"],0)

 def test_shelter_reduces_exposure(self):
  n={"exposure":0}
  a=apply_need_drift(n,600,weather_exposure_bp=5000,shelter_reduction_bp=0)["exposure"]
  b=apply_need_drift(n,600,weather_exposure_bp=5000,shelter_reduction_bp=4000)["exposure"]
  self.assertGreater(a,b)

 def test_no_resource_no_consume(self):
  c=D["consumables"][0]
  self.assertIsNone(consume_proposal("a","water",0,c,"EV"))

 def test_consume_authority(self):
  c=D["consumables"][0]
  p=consume_proposal("a","water",2,c,"EV")
  self.assertTrue(p["authority_required"]); self.assertEqual(p["consume_qty"],1)

 def test_rest_uses_time(self):
  r=rest_projection({"fatigue":80,"hunger":0,"thirst":0},480,10000,True)
  self.assertLess(r["projected_needs"]["fatigue"],80)
  self.assertEqual(r["elapsed_min"],480)

 def test_rest_not_magic_reset(self):
  r=rest_projection({"fatigue":100,"hunger":10,"thirst":10},60,5000,True)
  self.assertGreater(r["projected_needs"]["fatigue"],0)

 def test_camp_requirements(self):
  p=D["camp_profiles"][1]
  self.assertIsNone(camp_setup_proposal(p,"a",{"MAT_CLOTH":1},"L","EV"))

 def test_camp_authority(self):
  p=D["camp_profiles"][0]
  q=camp_setup_proposal(p,"a",{"MAT_CLOTH":1},"L","EV")
  self.assertTrue(q["authority_required"])

 def test_survival_consequence(self):
  needs={"thirst":90,"hunger":0,"fatigue":0,"exposure":0}
  x=survival_consequence_proposals(needs,D["survival_consequences"],"a","EV")
  self.assertTrue(any(v["id"]=="SURV_DEHYDRATION" for v in x))
  self.assertTrue(all(v["authority_required"] for v in x))

if __name__=="__main__": unittest.main()
