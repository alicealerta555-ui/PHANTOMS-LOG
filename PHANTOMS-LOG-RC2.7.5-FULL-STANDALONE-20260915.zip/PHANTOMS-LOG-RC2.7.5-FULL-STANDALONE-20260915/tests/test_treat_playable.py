from pathlib import Path
import copy, tempfile
from playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage9.actor_context import ACTOR_VISIBLE_RUNTIME_KEY

ROOT=Path(__file__).resolve().parents[1]

def test_treat_consumes_real_medical_item_heals_and_updates_mirror():
    with tempfile.TemporaryDirectory() as tmp:
        g=FullVersionGame(core_root=ROOT,saves_root=Path(tmp),start_class='OPERATOR',master_seed=20260913)
        data=g.creation_template(); data['skills']['SKILL_MEDICINE']=10; g.complete_character(data)
        actor=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,'actor:player'); actor=copy.deepcopy(actor); actor['hp']=5
        vis=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,ACTOR_VISIBLE_RUNTIME_KEY); vis=copy.deepcopy(vis); vis['actors']['actor:player']['health_state']='hp:5/10'
        med={'run_uuid':g.identity.run_uuid,'kind':'item','item_definition_id':'item_def:medical:002','location_ref':'inventory:actor:player','owner_actor_instance_id':'actor:player','condition':100,'max_condition':100,'provenance':'TEST_ONLY'}
        event='TEST_TREAT_FIXTURE'; r=g.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(
            Delta(Domain.RUNTIME_STATE,'actor:player',actor,Authority.RULE_KERNEL,'TEST_FIXTURE',source_event_id=event,provenance='TEST_ONLY'),
            Delta(Domain.RUNTIME_STATE,ACTOR_VISIBLE_RUNTIME_KEY,vis,Authority.RULE_KERNEL,'TEST_FIXTURE',source_event_id=event,provenance='TEST_ONLY'),
            Delta(Domain.RUNTIME_STATE,'item:test:med',med,Authority.RULE_KERNEL,'TEST_FIXTURE',source_event_id=event,provenance='TEST_ONLY'),
        ),event_id=event,cause='TEST_FIXTURE',expected_state_revision=g.session.store.revision)); assert isinstance(r,CommitRecord)
        text=g.treat_operation('operation:02')
        assert 'HP 5→7' in text
        treated=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,'actor:player')
        assert treated['hp']==7
        consumed=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,'item:test:med')
        assert consumed['location_ref'].startswith('consumed:') and 'owner_actor_instance_id' not in consumed
        mirror=g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,ACTOR_VISIBLE_RUNTIME_KEY)
        assert mirror['actors']['actor:player']['health_state']=='hp:7/10'
