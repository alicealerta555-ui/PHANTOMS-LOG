from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from uuid import uuid4

from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal, ValidationResult, Verdict
from runtime.stage3c.isolation import FilesystemRunRepository, RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import AuthorityStatus, StateAuthority
from runtime.stage9.effects import AuthorityDomain, EffectProposal, EffectType
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.scheduler import (
    SCHEDULER_RUNTIME_KEY,
    SchedulerCommitAdapter,
    SchedulerQueue,
    Stage9SchedulerError,
)
from runtime.stage9.world_time import WorldClock, WorldTimeCommitAdapter


class Stage9SchedulerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.manager = RunSessionManager(master_seed=20260911)
        self.player_uuid = str(uuid4())
        self.session = self.manager.create_run(player_uuid=self.player_uuid)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(self.player_uuid, self.session.identity.run_uuid, "actor:player")
        self.registry.register(self.identity, actor_definition_id="actor-def:player")
        self.authority = StateAuthority(self.session, actor_registry=self.registry)
        self.queue = SchedulerQueue(self.session)
        self.scheduler = SchedulerCommitAdapter(self.session)
        self.clock = WorldClock(self.session)
        self.time = WorldTimeCommitAdapter(self.session)
        self.counter = 0

    def _schedule_decision(
        self,
        event_id: str,
        due: int,
        *,
        event_type: str = "TEST_EVENT",
        sequence_key: str | None = None,
        payload: dict | None = None,
        effect_id: str | None = None,
    ):
        self.counter += 1
        body = {
            "scheduled_event_id": event_id,
            "event_type": event_type,
            "due_world_time": due,
            "payload": payload or {"n": self.counter},
        }
        if sequence_key is not None:
            body["sequence_key"] = sequence_key
        proposal = EffectProposal(
            effect_id=effect_id or f"effect:schedule:{self.counter}",
            run_uuid=self.session.identity.run_uuid,
            resolution_id=f"resolution:schedule:{self.counter}",
            source_action_id=f"action:schedule:{self.counter}",
            effect_type=EffectType.SCHEDULE_EVENT,
            target_ref=event_id,
            payload=body,
            authority_domain=AuthorityDomain.SCHEDULER,
            expected_state_revision=self.session.store.revision,
        )
        decision = self.authority.authorize(proposal)
        self.assertEqual(decision.status, AuthorityStatus.ALLOW)
        return decision

    def _cancel_decision(self, event_id: str, *, effect_id: str | None = None):
        self.counter += 1
        proposal = EffectProposal(
            effect_id=effect_id or f"effect:cancel:{self.counter}",
            run_uuid=self.session.identity.run_uuid,
            resolution_id=f"resolution:cancel:{self.counter}",
            source_action_id=f"action:cancel:{self.counter}",
            effect_type=EffectType.CANCEL_EVENT,
            target_ref=event_id,
            payload={"scheduled_event_id": event_id},
            authority_domain=AuthorityDomain.SCHEDULER,
            expected_state_revision=self.session.store.revision,
        )
        decision = self.authority.authorize(proposal)
        self.assertEqual(decision.status, AuthorityStatus.ALLOW)
        return decision

    def _apply_schedule(self, event_id: str, due: int, *, sequence_key: str | None = None, payload: dict | None = None):
        decision = self._schedule_decision(event_id, due, sequence_key=sequence_key, payload=payload)
        return self.scheduler.apply(
            decision,
            commit_id=f"commit:schedule:{self.counter}",
            event_id=f"SCHED:SCHEDULE:{self.counter}",
        )

    def _advance_time(self, seconds: int):
        self.counter += 1
        p = EffectProposal(
            effect_id=f"effect:time:{self.counter}",
            run_uuid=self.session.identity.run_uuid,
            resolution_id=f"resolution:time:{self.counter}",
            source_action_id=f"action:time:{self.counter}",
            effect_type=EffectType.ADVANCE_WORLD_TIME,
            target_ref=None,
            payload={"seconds": seconds},
            authority_domain=AuthorityDomain.WORLD_TIME,
            expected_state_revision=self.session.store.revision,
        )
        d = self.authority.authorize(p)
        self.assertEqual(d.status, AuthorityStatus.ALLOW)
        return self.time.advance(d, commit_id=f"commit:time:{self.counter}", event_id=f"TIME:{self.counter}")

    def test_fresh_queue_is_empty_without_bootstrap_commit(self):
        revision = self.session.store.revision
        state_hash = self.session.store.state_hash()
        snap = self.queue.snapshot()
        self.assertEqual(snap.events, ())
        self.assertEqual(snap.state_revision, revision)
        self.assertNotIn(SCHEDULER_RUNTIME_KEY, self.session.store.runtime_state)
        self.assertEqual(self.session.store.state_hash(), state_hash)

    def test_schedule_event_commits_canonically(self):
        before = self.session.store.revision
        result = self._apply_schedule("scheduled:a", 12, sequence_key="010", payload={"door": "d1"})
        self.assertIsInstance(result, CommitRecord)
        snap = self.queue.snapshot()
        self.assertEqual(self.session.store.revision, before + 1)
        self.assertEqual(len(snap.events), 1)
        event = snap.events[0]
        self.assertEqual(event.scheduled_event_id, "scheduled:a")
        self.assertEqual(event.sequence_key, "010")
        self.assertEqual(event.payload, {"door": "d1"})

    def test_dispatch_due_is_read_only_and_does_not_remove(self):
        self._apply_schedule("scheduled:a", 5)
        self._advance_time(5)
        revision = self.session.store.revision
        state_hash = self.session.store.state_hash()
        first = self.queue.dispatch_due()
        second = self.queue.dispatch_due()
        self.assertEqual([e.scheduled_event_id for e in first.events], ["scheduled:a"])
        self.assertEqual([e.scheduled_event_id for e in second.events], ["scheduled:a"])
        self.assertEqual(self.session.store.revision, revision)
        self.assertEqual(self.session.store.state_hash(), state_hash)
        self.assertIsNotNone(self.queue.get("scheduled:a"))

    def test_due_order_is_deterministic(self):
        self._apply_schedule("scheduled:z", 10, sequence_key="b")
        self._apply_schedule("scheduled:c", 5, sequence_key="z")
        self._apply_schedule("scheduled:b", 10, sequence_key="a")
        self._apply_schedule("scheduled:a", 10, sequence_key="a")
        self._advance_time(10)
        batch = self.queue.dispatch_due()
        self.assertEqual(
            [e.scheduled_event_id for e in batch.events],
            ["scheduled:c", "scheduled:a", "scheduled:b", "scheduled:z"],
        )

    def test_future_event_not_dispatched(self):
        self._apply_schedule("scheduled:future", 11)
        self._advance_time(10)
        self.assertEqual(self.queue.dispatch_due().events, ())
        self._advance_time(1)
        self.assertEqual([e.scheduled_event_id for e in self.queue.dispatch_due().events], ["scheduled:future"])

    def test_dispatch_limit_preserves_deterministic_prefix(self):
        for event_id in ("scheduled:c", "scheduled:a", "scheduled:b"):
            self._apply_schedule(event_id, 1, sequence_key="x")
        self._advance_time(1)
        batch = self.queue.dispatch_due(limit=2)
        self.assertEqual([e.scheduled_event_id for e in batch.events], ["scheduled:a", "scheduled:b"])

    def test_cancel_event_is_authority_commit_not_dispatch_side_effect(self):
        self._apply_schedule("scheduled:cancel", 0)
        revision = self.session.store.revision
        dispatch = self.queue.dispatch_due()
        self.assertEqual([e.scheduled_event_id for e in dispatch.events], ["scheduled:cancel"])
        self.assertEqual(self.session.store.revision, revision)
        decision = self._cancel_decision("scheduled:cancel")
        result = self.scheduler.apply(decision, commit_id="commit:cancel", event_id="SCHED:CANCEL")
        self.assertIsInstance(result, CommitRecord)
        self.assertIsNone(self.queue.get("scheduled:cancel"))
        self.assertEqual(self.queue.dispatch_due().events, ())

    def test_duplicate_event_id_fails_closed_before_commit(self):
        self._apply_schedule("scheduled:dup", 2)
        decision = self._schedule_decision("scheduled:dup", 3)
        with self.assertRaisesRegex(Stage9SchedulerError, "SCHEDULED_EVENT_ALREADY_EXISTS"):
            self.scheduler.prepare(decision, commit_id="commit:dup:2", event_id="SCHED:DUP:2")

    def test_cancel_missing_event_fails_closed(self):
        decision = self._cancel_decision("scheduled:missing")
        with self.assertRaisesRegex(Stage9SchedulerError, "SCHEDULED_EVENT_NOT_FOUND"):
            self.scheduler.prepare(decision, commit_id="commit:missing", event_id="SCHED:MISSING")

    def test_past_due_schedule_fails_closed(self):
        self._advance_time(10)
        decision = self._schedule_decision("scheduled:past", 9)
        with self.assertRaisesRegex(Stage9SchedulerError, "SCHEDULED_EVENT_DUE_TIME_IN_PAST"):
            self.scheduler.prepare(decision, commit_id="commit:past", event_id="SCHED:PAST")

    def test_replay_same_prepared_schedule_plan_is_idempotent(self):
        decision = self._schedule_decision("scheduled:retry", 3, effect_id="effect:schedule:retry")
        plan = self.scheduler.prepare(decision, commit_id="commit:schedule:retry", event_id="SCHED:RETRY")
        first = self.scheduler.commit(plan)
        self.assertIsInstance(first, CommitRecord)
        revision = self.session.store.revision
        state_hash = self.session.store.state_hash()
        second = self.scheduler.commit(plan)
        self.assertIsInstance(second, ValidationResult)
        self.assertEqual(second.verdict, Verdict.HOLD)
        self.assertIn("DUPLICATE_COMMIT_IDEMPOTENT_SKIP", second.reasons)
        self.assertEqual(self.session.store.revision, revision)
        self.assertEqual(self.session.store.state_hash(), state_hash)

    def test_generic_rule_writer_cannot_write_reserved_scheduler_key(self):
        result = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id="SCHED:ROGUE",
            cause="ROGUE_SCHEDULER_WRITE",
            deltas=(Delta(
                domain=Domain.RUNTIME_STATE,
                key=SCHEDULER_RUNTIME_KEY,
                value={"run_uuid": self.session.identity.run_uuid, "events": {}},
                writer=Authority.RULE_KERNEL,
                cause="ROGUE_SCHEDULER_WRITE",
                source_event_id="SCHED:ROGUE",
            ),),
        ))
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertIn("SCHEDULER_WRITER_REQUIRED", result.reasons)
        self.assertNotIn(SCHEDULER_RUNTIME_KEY, self.session.store.runtime_state)

    def test_scheduler_authority_cannot_write_other_runtime_key(self):
        result = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id="SCHED:OTHER",
            cause="ROGUE_SCHEDULER_OTHER_KEY",
            deltas=(Delta(
                domain=Domain.RUNTIME_STATE,
                key="other:key",
                value=1,
                writer=Authority.SCHEDULER,
                cause="ROGUE_SCHEDULER_OTHER_KEY",
                source_event_id="SCHED:OTHER",
            ),),
        ))
        self.assertIsInstance(result, ValidationResult)
        self.assertEqual(result.verdict, Verdict.REJECT)
        self.assertIn("SCHEDULER_RESERVED_KEY_ONLY", result.reasons)

    def test_run_isolation(self):
        other = self.manager.create_run(player_uuid=self.player_uuid)
        other_queue = SchedulerQueue(other)
        self._apply_schedule("scheduled:iso", 2)
        self.assertEqual([e.scheduled_event_id for e in self.queue.snapshot().events], ["scheduled:iso"])
        self.assertEqual(other_queue.snapshot().events, ())
        self.assertNotIn(SCHEDULER_RUNTIME_KEY, other.store.runtime_state)

    def test_save_load_preserves_queue_world_time_and_dispatch_order(self):
        self._apply_schedule("scheduled:b", 7, sequence_key="a", payload={"x": 2})
        self._apply_schedule("scheduled:a", 7, sequence_key="a", payload={"x": 1})
        self._advance_time(7)
        expected_revision = self.session.store.revision
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(Path(td))
            repo.save(self.session)
            identity = self.session.identity
            self.manager.close_run(player_uuid=identity.player_uuid, run_uuid=identity.run_uuid)
            loaded = repo.load_session(self.manager, identity)
            loaded_queue = SchedulerQueue(loaded)
            self.assertEqual(loaded.store.revision, expected_revision)
            self.assertEqual(
                [e.scheduled_event_id for e in loaded_queue.dispatch_due().events],
                ["scheduled:a", "scheduled:b"],
            )
            self.assertEqual(loaded.store.revision, expected_revision)


if __name__ == "__main__":
    unittest.main(verbosity=2)
