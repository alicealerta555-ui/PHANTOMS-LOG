from runtime.full_version.action_capability_policy import (
    ACTION_CAPABILITY_POLICIES, ROUTINE_SAFE, SKILL, DYNAMIC_SKILL,
    validate_action_capability_policy,
)
from runtime.full_version.capability_catalog import SCHEMA_ID, class_start_stats, class_start_skills, class_start_talents
from runtime.full_version.capability_resolution import CapabilityZone
from runtime.full_version.capability_runtime import assess_action, deterministic_uncertain_success


def actor(start_class='OPERATOR'):
    return {
        'character_profile': {
            'schema': SCHEMA_ID,
            'stats': class_start_stats(start_class),
            'skills': class_start_skills(start_class),
            'talents': class_start_talents(start_class),
            'expertises': {},
        },
        'status_flags': [],
    }


def test_policy_is_closed_and_valid():
    assert validate_action_capability_policy() == ()
    assert {'LOOK','TAKE','OPEN','MOVE','TALK','TRADE_BUY','TRADE_SELL','QUEST_ACCEPT','ATTACK'} <= set(ACTION_CAPABILITY_POLICIES)
    assert {'SEARCH','CRAFT','REPAIR','TREAT','DATA_READ','REBUILD','CORPSE_INVESTIGATION','CLASS_ABILITY'} <= set(ACTION_CAPABILITY_POLICIES)


def test_routine_actions_are_explicit_not_accidental():
    for action in ('LOOK','TAKE','OPEN','MOVE','TALK','TRADE_BUY','TRADE_SELL','QUEST_ACCEPT'):
        assert ACTION_CAPABILITY_POLICIES[action].mode == ROUTINE_SAFE
        assert ACTION_CAPABILITY_POLICIES[action].note


def test_skill_actions_point_to_canonical_skill_ids():
    assert ACTION_CAPABILITY_POLICIES['ATTACK'].mode == SKILL
    assert ACTION_CAPABILITY_POLICIES['ATTACK'].skill_id == 'SKILL_AIM_CONTROL'
    assert ACTION_CAPABILITY_POLICIES['SEARCH'].skill_id == 'SKILL_OBSERVATION'
    assert ACTION_CAPABILITY_POLICIES['REBUILD'].skill_id == 'SKILL_TECHNOLOGY'
    assert ACTION_CAPABILITY_POLICIES['CORPSE_INVESTIGATION'].skill_id == 'SKILL_MEDICINE'
    assert ACTION_CAPABILITY_POLICIES['CLASS_ABILITY'].mode == DYNAMIC_SKILL


def test_safe_edge_extreme_are_real_runtime_zones():
    op=actor('OPERATOR')
    assert assess_action(op,'SKILL_TECHNOLOGY',4,context_tags=('reparatur',)).zone == CapabilityZone.SAFE
    breaker=actor('BREAKER')
    assert assess_action(breaker,'SKILL_TECHNOLOGY',2,context_tags=('reparatur',)).zone == CapabilityZone.EDGE
    assert assess_action(breaker,'SKILL_TECHNOLOGY',6,context_tags=('reparatur',)).zone == CapabilityZone.EXTREME


def test_hard_limit_precedes_expertise_and_talent():
    op=actor('OPERATOR')
    op['character_profile']['stats']['STAT_DEX']=1
    op['character_profile']['expertises']={'SKILL_TECHNOLOGY':99}
    cap=assess_action(op,'SKILL_TECHNOLOGY',6,context_tags=('reparatur','maschinen'))
    assert cap.zone == CapabilityZone.HARD_LIMIT
    assert cap.failure_stage is not None
    assert cap.expertise_bonus == 3  # capped reliability bonus, still cannot bypass the hard limit


def test_talent_only_applies_when_situation_matches():
    op=actor('OPERATOR')
    matching=assess_action(op,'SKILL_TECHNOLOGY',5,context_tags=('reparatur','maschinen'))
    unrelated=assess_action(op,'SKILL_TECHNOLOGY',5,context_tags=('kochen','gespräch'))
    assert matching.talent_id in {'TALENT_MACHINEWORK','TALENT_FIELD_REPAIR','TALENT_ARTIFACT_ENGINEERING'}
    assert matching.situational_bonus >= 1
    assert unrelated.talent_id is None


def test_uncertainty_roll_is_deterministic_and_never_rolls_hard_limit():
    breaker=actor('BREAKER')
    edge=assess_action(breaker,'SKILL_TECHNOLOGY',2,context_tags=('reparatur',))
    a=deterministic_uncertain_success(edge,'same-seed')
    b=deterministic_uncertain_success(edge,'same-seed')
    assert a == b
    assert a[2] == 10
    breaker['character_profile']['stats']['STAT_COG']=1
    hard=assess_action(breaker,'SKILL_TECHNOLOGY',8,context_tags=('reparatur',))
    assert hard.zone == CapabilityZone.HARD_LIMIT
    assert deterministic_uncertain_success(hard,'anything') == (False,0,99)
