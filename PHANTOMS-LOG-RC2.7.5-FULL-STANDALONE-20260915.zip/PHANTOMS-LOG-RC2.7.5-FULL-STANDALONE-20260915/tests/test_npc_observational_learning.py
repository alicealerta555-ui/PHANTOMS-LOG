from runtime.player_progression.gameplay_hooks import ResolvedGameplayEvent
from runtime.player_progression.npc_learning import (
    NPCActorSnapshot, NPCWitnessContext, NPCObservationEngine, NPCObservationalLearningBridge,
)


def actor(npc_id="n1", intelligence=7, **kw):
    return NPCActorSnapshot(
        npc_id=npc_id,
        intelligence_grade=intelligence,
        trust_player=kw.pop("trust", 0.8),
        openness=kw.pop("openness", 0.8),
        stubbornness=kw.pop("stubbornness", 0.2),
        self_interest=kw.pop("self_interest", 0.3),
        competencies=kw.pop("competencies", {"exploration": 0.7, "combat": 0.7, "medicine": 0.7}),
        **kw,
    )


def event(**kw):
    base = dict(domain="exploration", action_family="scan_motion", committed=True,
                actor_is_player=True, situation_family="room_entry", choice_key="scan_motion",
                visible_context_tags=("unknown_room",), outcome="success")
    base.update(kw)
    return ResolvedGameplayEvent(**base)


def test_unwitnessed_action_not_learned():
    eng = NPCObservationEngine()
    r = eng.observe(actor(), event(), NPCWitnessContext(witnessed=False))
    assert r.reaction == "none"
    assert eng.state_for("n1").patterns == {}


def test_npc_never_receives_player_insights():
    eng = NPCObservationEngine()
    for i in range(6):
        eng.observe(actor(), event(location_id=f"r{i}"), NPCWitnessContext(visible_tags=(f"ctx{i}",)))
    state = eng.state_for("n1")
    assert hasattr(state, "learned_routines")
    assert not hasattr(state, "unlocked_insights")


def test_intelligent_npc_rejects_absurd_pattern():
    eng = NPCObservationEngine()
    r = eng.observe(actor(intelligence=5), event(visible_context_tags=("absurd", "wasteful")))
    assert r.reaction in {"reject", "suggest"}
    assert "room_entry|scan_motion" in eng.state_for("n1").rejected_routines or r.reaction == "suggest"


def test_high_intelligence_competent_npc_can_suggest_better_method():
    eng = NPCObservationEngine()
    a = actor(intelligence=9, competencies={"exploration": 0.95})
    out = None
    for i in range(4):
        out = eng.observe(a, event(), NPCWitnessContext(visible_tags=(f"context_{i}",)))
    assert out.reaction == "suggest"
    assert out.suggested_alternative


def test_mid_high_intelligence_can_adapt_instead_of_copy():
    eng = NPCObservationEngine()
    a = actor(intelligence=7, competencies={"exploration": 0.7})
    out = None
    for i in range(5):
        out = eng.observe(a, event(), NPCWitnessContext(visible_tags=(f"context_{i}",)))
    assert out.reaction in {"adapt", "suggest"}


def test_personality_can_reject_useful_method():
    eng = NPCObservationEngine()
    a = actor(intelligence=6, openness=0.1, stubbornness=1.0, trust=0.1, self_interest=0.8,
              competencies={"exploration": 0.4})
    out = None
    for i in range(8):
        out = eng.observe(a, event(), NPCWitnessContext(visible_tags=(f"context_{i}",)))
    assert out.reaction == "reject"


def test_low_intelligence_can_copy_if_trusted_and_successful():
    eng = NPCObservationEngine()
    a = actor(intelligence=2, openness=0.95, stubbornness=0.05, trust=1.0, self_interest=0.1,
              competencies={"exploration": 0.1})
    out = None
    for i in range(9):
        out = eng.observe(a, event(), NPCWitnessContext(visible_tags=(f"context_{i}",)))
    assert out.reaction == "adopt"


def test_catastrophically_bad_behavior_is_never_copied():
    eng = NPCObservationEngine()
    a = actor(intelligence=1, openness=1.0, stubbornness=0.0, trust=1.0)
    r = eng.observe(a, event(visible_context_tags=("self_destructive",)))
    assert r.reaction == "reject"


def test_discussion_reflects_actual_npc_stance():
    eng = NPCObservationEngine()
    a = actor(intelligence=9, competencies={"exploration": 0.95})
    for i in range(4):
        eng.observe(a, event(), NPCWitnessContext(visible_tags=(f"context_{i}",)))
    r = eng.discuss(a, "room_entry|scan_motion")
    assert "anders" in r.dialogue_hook or "brauchbar" in r.dialogue_hook


def test_persistence_roundtrip_keeps_learning_state():
    eng = NPCObservationEngine()
    a = actor()
    for i in range(5):
        eng.observe(a, event(), NPCWitnessContext(visible_tags=(f"context_{i}",)))
    payload = eng.to_dict()
    restored = NPCObservationEngine.from_dict(payload)
    assert restored.to_dict() == payload


def test_bridge_fans_out_only_to_actual_observers():
    bridge = NPCObservationalLearningBridge()
    observers = [
        (actor("a"), NPCWitnessContext(witnessed=True, visible_tags=("hall",))),
        (actor("b"), NPCWitnessContext(witnessed=False, visible_tags=("hall",))),
    ]
    bridge.after_player_resolution(event(), observers)
    assert bridge.engine.state_for("a").patterns
    assert bridge.engine.state_for("b").patterns == {}


def test_player_visible_payload_contains_no_internal_numbers():
    eng = NPCObservationEngine()
    r = eng.observe(actor(intelligence=5), event(visible_context_tags=("absurd",)))
    payload = r.player_visible_payload()
    text = repr(payload).lower()
    assert "intelligence" not in text
    assert "confidence" not in text
    assert "threshold" not in text
    assert "observation" not in text
