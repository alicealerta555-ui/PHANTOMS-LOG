from runtime.player_progression.npc_psychology import *

def snap(**kw):
    d=dict(npc_id="n1", trust=.6, trigger_tags=("tunnel",), avoidance_tags=("tunnel",))
    d.update(kw); return PsychologicalSnapshot(**d)

def test_short_support_accumulates_without_instant_cure():
    e=NPCPsychologyEngine(); s=snap()
    r=e.support(s, SupportContext(1, player_listens=True, player_respects_boundary=True, context_tags=("tunnel",)))
    assert r.action in {"SMALL_SUPPORT","SUPPORTED"}
    t=e.state_for("n1").themes["tunnel"]
    assert t.safety_memory>0 and t.burden>0

def test_force_is_harmful_not_progress():
    e=NPCPsychologyEngine(); s=snap()
    e.support(s, SupportContext(1, player_forces_exposure=True, context_tags=("tunnel",)))
    t=e.state_for("n1").themes["tunnel"]
    assert t.harmful_moments==1 and t.avoidance>0

def test_positive_exposure_requires_voluntary():
    e=NPCPsychologyEngine(); s=snap()
    bad=e.positive_exposure(s,"tunnel",1,voluntary=False)
    good=e.positive_exposure(s,"tunnel",2,voluntary=True,supported=True)
    assert bad.action=="PRESSURED_EXPOSURE" and good.action=="POSITIVE_EXPOSURE"

def test_danger_gates_long_support():
    e=NPCPsychologyEngine(); r=e.support(snap(), SupportContext(1,danger=.9,player_listens=True))
    assert r.action=="STABILIZE_ONLY"

def test_persistence_roundtrip():
    e=NPCPsychologyEngine(); e.support(snap(), SupportContext(1,player_listens=True,context_tags=("tunnel",)))
    e2=NPCPsychologyEngine.from_save(e.snapshot_for_save())
    assert "tunnel" in e2.state_for("n1").themes
