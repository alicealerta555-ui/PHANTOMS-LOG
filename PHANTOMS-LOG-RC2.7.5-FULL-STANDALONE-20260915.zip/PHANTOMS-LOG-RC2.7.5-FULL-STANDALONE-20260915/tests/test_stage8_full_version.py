# PH4NT0M5-L0G provenance: M a n u e l  M e i k o  K o h l | © 2026 | non-functional marker
import unittest
from pathlib import Path
from uuid import UUID

from runtime.full_version.catalog import FullVersionCatalog
from runtime.full_version.bootstrap import FullVersionBootstrap, PLAYER_ACTOR_INSTANCE_ID
from runtime.stage3a.kernel import Authority, Domain
from runtime.stage3c.isolation import RunSessionManager
from runtime.stage8.world import *
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.authority import StateAuthority
from runtime.stage9.gameplay import SemanticCommitAdapter
from runtime.stage9.world_time import WorldClock

PLAYER=str(UUID('33333333-3333-4333-8333-333333333333'))

class Stage8FullVersionTests(unittest.TestCase):
    def setUp(self):
        self.root=Path(__file__).resolve().parents[1]; self.catalog=FullVersionCatalog.load(self.root); self.s8=self.catalog.stage8_world; self.manager=RunSessionManager(master_seed=808); self.session=self.manager.create_run(player_uuid=PLAYER); self.registry=RunActorRegistry(self.session); FullVersionBootstrap(self.catalog).initialize_new_run(self.session,self.registry,start_class='BREAKER'); self.authority=StateAuthority(self.session,actor_registry=self.registry); self.view=Stage8WorldView(self.session,self.s8); self.adapter=Stage8CommitAdapter(self.session,self.s8)
    def test_every_full_world_location_has_region_and_route_for_every_connection(self):
        self.assertEqual(len(self.s8.locations),len(self.catalog.world['locations'])); self.assertEqual(set(x['region_id'] for x in self.catalog.world['locations']),set(self.s8.regions)); self.assertGreaterEqual(len(self.s8.routes),100)
    def test_travel_changes_position_and_time_atomically(self):
        origin=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,PLAYER_ACTOR_INSTANCE_ID)['location_ref']; destination=self.catalog.location(origin)['connections'][0]; engine=Stage8TravelEngine(self.s8); plan=engine.plan(origin,destination); self.assertGreater(plan.travel_seconds,0)
        eps=engine.proposals(self.session,PLAYER_ACTOR_INSTANCE_ID,origin,destination,resolution_id='resolution:travel',source_action_id='action:travel',effect_prefix='effect:travel'); decisions=tuple(self.authority.authorize(x) for x in eps); adapter=SemanticCommitAdapter(self.session,self.registry); plan_commit=adapter.prepare_many(decisions,commit_id='commit:travel',event_id='event:travel'); adapter.commit(plan_commit)
        actor=self.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,PLAYER_ACTOR_INSTANCE_ID); self.assertEqual(actor['location_ref'],destination); self.assertEqual(WorldClock(self.session).seconds,plan.travel_seconds)
    def test_information_requires_real_channel_and_latency(self):
        info=Stage8InformationEngine(self.s8,self.view); path=info.route('region:01','region:03','data'); self.assertGreaterEqual(path.latency_seconds,1); self.assertTrue(path.infrastructure_ids)
        e=Stage8MigrationEngine(self.session,self.s8,self.view).infrastructure_proposal(infrastructure_id='infra:data_mesh',new_state='OFFLINE',cause_ref='cause:outage',resolution_id='resolution:outage',source_action_id='action:outage',effect_id='effect:outage'); self.adapter.apply_many((self.authority.authorize(e),),commit_id='commit:outage',event_id='event:outage')
        with self.assertRaises(Stage8WorldError): Stage8InformationEngine(self.s8,self.view).route('region:01','region:03','data')
    def test_migration_conserves_population_and_requires_route(self):
        engine=Stage8MigrationEngine(self.session,self.s8,self.view); before_a=self.view.population('region:01','population:residents'); before_b=self.view.population('region:02','population:residents'); total=before_a+before_b
        ep=engine.proposal(from_region_id='region:01',to_region_id='region:02',population_id='population:residents',amount=1000,cause_ref='cause:jobs',resolution_id='resolution:migrate',source_action_id='action:migrate',effect_id='effect:migrate'); self.adapter.apply_many((self.authority.authorize(ep),),commit_id='commit:migrate',event_id='event:migrate')
        self.assertEqual(self.view.population('region:01','population:residents')+self.view.population('region:02','population:residents'),total); self.assertEqual(self.view.population('region:01','population:residents'),before_a-1000)
        with self.assertRaises(Stage8WorldError): engine.proposal(from_region_id='region:01',to_region_id='region:03',population_id='population:residents',amount=1,cause_ref='cause:no-route',resolution_id='resolution:no',source_action_id='action:no',effect_id='effect:no')
    def test_regions_have_distinct_conditions_and_cultural_continuity(self):
        temps={r['conditions']['temperature_c'] for r in self.s8.regions.values()}; self.assertGreater(len(temps),2); self.assertTrue(all(r.get('cultural_continuity') for r in self.s8.regions.values()))

if __name__=='__main__': unittest.main(verbosity=2)
