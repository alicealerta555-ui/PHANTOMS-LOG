from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from uuid import uuid4

from runtime.stage3c.isolation import FilesystemRunRepository, RunSessionManager
from runtime.stage9.actors import (
    ACTOR_REGISTRY_RUNTIME_KEY,
    RunActorRegistry,
    Stage9ActorError,
)
from runtime.stage9.identity import RuntimeIdentity


class Stage9RunActorRegistryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.player_uuid = str(uuid4())
        self.manager = RunSessionManager(master_seed=20260911)
        self.a = self.manager.create_run(player_uuid=self.player_uuid)
        self.b = self.manager.create_run(player_uuid=self.player_uuid)
        self.reg_a = RunActorRegistry(self.a)
        self.reg_b = RunActorRegistry(self.b)
        self.id_a = RuntimeIdentity(
            self.player_uuid, self.a.identity.run_uuid, "actor:a"
        )
        self.id_b = RuntimeIdentity(
            self.player_uuid, self.b.identity.run_uuid, "actor:b"
        )

    def test_registration_is_committed_into_run_state(self):
        before_revision = self.a.store.revision
        actor = self.reg_a.register(self.id_a, actor_definition_id="def.player")
        self.assertEqual(actor.actor_instance_id, "actor:a")
        self.assertEqual(actor.run_uuid, self.a.identity.run_uuid)
        self.assertEqual(self.a.store.revision, before_revision + 1)
        raw = self.a.store.runtime_state[ACTOR_REGISTRY_RUNTIME_KEY]
        self.assertIn("actor:a", raw)
        self.assertEqual(raw["actor:a"]["run_uuid"], self.a.identity.run_uuid)

    def test_same_registration_is_idempotent_without_new_revision(self):
        first = self.reg_a.register(self.id_a, actor_definition_id="def.player")
        revision = self.a.store.revision
        second = self.reg_a.register(self.id_a, actor_definition_id="def.player")
        self.assertEqual(first, second)
        self.assertEqual(self.a.store.revision, revision)

    def test_conflicting_registration_rejected(self):
        self.reg_a.register(self.id_a, actor_definition_id="def.one")
        with self.assertRaisesRegex(Stage9ActorError, "ACTOR_INSTANCE_REGISTRATION_CONFLICT"):
            self.reg_a.register(self.id_a, actor_definition_id="def.two")

    def test_runtime_identity_from_other_run_cannot_be_registered_here(self):
        with self.assertRaisesRegex(Stage9ActorError, "ACTOR_REGISTRY_RUNTIME_RUN_MISMATCH"):
            self.reg_a.register(self.id_b)

    def test_unregistered_actor_fails_closed(self):
        with self.assertRaisesRegex(Stage9ActorError, "ACTOR_NOT_REGISTERED_IN_RUN"):
            self.reg_a.require_runtime_identity(self.id_a)

    def test_actor_from_other_run_not_visible_in_registry(self):
        self.reg_b.register(self.id_b)
        forged_for_a = RuntimeIdentity(
            self.player_uuid, self.a.identity.run_uuid, self.id_b.actor_instance_id
        )
        with self.assertRaisesRegex(Stage9ActorError, "ACTOR_NOT_REGISTERED_IN_RUN"):
            self.reg_a.require_runtime_identity(forged_for_a)

    def test_same_opaque_actor_id_is_scoped_by_run(self):
        actor_id = "npc:shared-name"
        ida = RuntimeIdentity(self.player_uuid, self.a.identity.run_uuid, actor_id)
        idb = RuntimeIdentity(self.player_uuid, self.b.identity.run_uuid, actor_id)
        self.reg_a.register(ida, actor_definition_id="def.a")
        self.reg_b.register(idb, actor_definition_id="def.b")
        self.assertEqual(self.reg_a.get(actor_id).run_uuid, self.a.identity.run_uuid)
        self.assertEqual(self.reg_b.get(actor_id).run_uuid, self.b.identity.run_uuid)
        self.assertNotEqual(self.reg_a.get(actor_id), self.reg_b.get(actor_id))

    def test_registry_persists_through_stage3c_save_load(self):
        self.reg_a.register(self.id_a, actor_definition_id="def.player")
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(Path(td))
            repo.save(self.a)
            fresh = RunSessionManager(master_seed=20260911)
            loaded = repo.load_session(fresh, self.a.identity)
            loaded_registry = RunActorRegistry(loaded)
            actor = loaded_registry.require_runtime_identity(self.id_a)
            self.assertEqual(actor.actor_definition_id, "def.player")
            self.assertEqual(loaded.store.revision, self.a.store.revision)

    def test_tampered_registry_run_metadata_fails_closed(self):
        self.reg_a.register(self.id_a)
        # Deliberate test corruption: ownership validation must not trust the actor key alone.
        self.a.store.runtime_state[ACTOR_REGISTRY_RUNTIME_KEY]["actor:a"]["run_uuid"] = self.b.identity.run_uuid
        with self.assertRaisesRegex(Stage9ActorError, "ACTOR_REGISTRY_RUN_MISMATCH"):
            self.reg_a.get("actor:a")

    def test_run_a_registration_does_not_mutate_run_b(self):
        before_b = self.b.store.snapshot()
        before_hash_b = self.b.store.state_hash()
        before_revision_b = self.b.store.revision
        self.reg_a.register(self.id_a, actor_definition_id="def.player")
        self.assertEqual(self.b.store.snapshot(), before_b)
        self.assertEqual(self.b.store.state_hash(), before_hash_b)
        self.assertEqual(self.b.store.revision, before_revision_b)

    def test_listing_is_deterministic(self):
        second = RuntimeIdentity(self.player_uuid, self.a.identity.run_uuid, "actor:z")
        first = RuntimeIdentity(self.player_uuid, self.a.identity.run_uuid, "actor:a")
        self.reg_a.register(second)
        self.reg_a.register(first)
        self.assertEqual(
            [actor.actor_instance_id for actor in self.reg_a.instances()],
            ["actor:a", "actor:z"],
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
