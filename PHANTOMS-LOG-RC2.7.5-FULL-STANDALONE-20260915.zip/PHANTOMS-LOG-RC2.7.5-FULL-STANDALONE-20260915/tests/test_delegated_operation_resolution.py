import pytest
from runtime.full_version.delegated_operation_resolution import DelegatedOperationResolver, DelegatedOperationResolutionError

def test_requires_authoritative_evidence():
    with pytest.raises(DelegatedOperationResolutionError, match="AUTHORITATIVE_TEAM_EVIDENCE_REQUIRED"):
        DelegatedOperationResolver().resolve(operation_id="OP1", team_snapshots=[{"relevant_skill_values":{"TECH":5}}])

def test_low_skill_can_fail():
    r=DelegatedOperationResolver().resolve(operation_id="OPX",team_snapshots=[{"evidence_ref":"E1","relevant_skill_values":{"TECH":1},"readiness":.5}],difficulty=10,danger=4,seed="fixed")
    assert r.outcome in {"FAILURE","CRITICAL_FAILURE"}

def test_preparation_and_multiple_teams_help_without_guarantee():
    base=[{"evidence_ref":"E1","relevant_skill_values":{"TECH":5,"OBSERVATION":4},"readiness":1.0}]
    more=base+[{"evidence_ref":"E2","relevant_skill_values":{"LOGISTICS":6,"TECH":3},"machine_support":2,"readiness":1.0}]
    a=DelegatedOperationResolver().resolve(operation_id="OP",team_snapshots=base,difficulty=7,seed="same")
    b=DelegatedOperationResolver().resolve(operation_id="OP",team_snapshots=more,difficulty=7,preparation_bonus=1,logistics_bonus=1,seed="same")
    assert b.score>a.score

def test_deterministic_for_same_run_inputs():
    kw=dict(operation_id="OP",team_snapshots=[{"evidence_ref":"E","relevant_skill_values":{"SOCIAL":7}}],difficulty=5,seed="RUN")
    assert DelegatedOperationResolver().resolve(**kw)==DelegatedOperationResolver().resolve(**kw)
