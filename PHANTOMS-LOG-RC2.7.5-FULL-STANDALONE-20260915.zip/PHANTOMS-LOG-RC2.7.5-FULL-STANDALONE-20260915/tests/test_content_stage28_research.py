
import json, unittest
from pathlib import Path
from runtime.content_stage28.research import *

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"content/full_version/stage28_technology_research.json").read_text())

class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower()
  self.assertNotIn("player_uuid",raw)
  self.assertNotIn("run_uuid",raw)
  self.assertTrue(D["runtime_i9_frozen"])

 def test_tiers(self):
  self.assertGreaterEqual(len(D["technology_tiers"]),6)

 def test_discovery_not_understanding(self):
  r=discovery_record("ART","a","L",1,["visual"])
  self.assertEqual(r["knowledge_state"],"OBSERVED")
  self.assertTrue(D["discovery_contract"]["discovery_does_not_imply_understanding"])

 def test_progress_requires_time(self):
  self.assertEqual(research_progress(10,20,50,50,0),10)

 def test_progress_bounded(self):
  self.assertEqual(research_progress(95,100,100,0,600),100)

 def test_knowledge_states(self):
  self.assertEqual(knowledge_state_from_progress(0),"UNKNOWN")
  self.assertEqual(knowledge_state_from_progress(30),"HYPOTHESIZED")
  self.assertEqual(knowledge_state_from_progress(95),"REPRODUCIBLE")

 def test_reverse_requires_tools(self):
  self.assertIsNone(reverse_engineering_candidate("ART","a",[],"L",60,80,50,"EV"))

 def test_reverse_authority(self):
  p=reverse_engineering_candidate("ART","a",["TOOL"],"L",60,80,50,"EV")
  self.assertTrue(p["authority_required"])
  self.assertGreaterEqual(p["progress"],0)

 def test_transfer_requires_channel(self):
  self.assertIsNone(knowledge_transfer_proposal("K","a","b","", "scope","EV"))

 def test_transfer_authority(self):
  p=knowledge_transfer_proposal("K","a","b","CHAN","scope","EV")
  self.assertTrue(p["authority_required"])

 def test_reproduction_requires_resources(self):
  a=reproducibility_candidate("REPRODUCIBLE",True,True,False,"EV")
  b=reproducibility_candidate("REPRODUCIBLE",True,True,True,"EV")
  self.assertFalse(a["reproducible"])
  self.assertTrue(b["reproducible"])

if __name__=="__main__": unittest.main()
