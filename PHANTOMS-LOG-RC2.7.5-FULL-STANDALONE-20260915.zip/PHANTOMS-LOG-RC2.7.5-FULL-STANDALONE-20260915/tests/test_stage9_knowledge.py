from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from uuid import uuid4

from phantoms_stage5.senses import BoundSense, Expression, SenseProfile
from phantoms_stage5.visual import VisualLimits
from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal
from runtime.stage3c.isolation import FilesystemRunRepository, RunSessionManager
from runtime.stage9.actors import RunActorRegistry
from runtime.stage9.identity import RuntimeIdentity
from runtime.stage9.knowledge import (
    KnowledgeCommitAdapter,
    KnowledgeCommitStatus,
    PerceptionKnowledgePath,
    Stage9KnowledgeError,
)
from runtime.stage9.perception import (
    PERCEPTION_INPUT_WORLD_KEY,
    PerceptionDetection,
    PerceptionReader,
)


class Stage9KnowledgeCommitTests(unittest.TestCase):
    def setUp(self) -> None:
        self.manager = RunSessionManager(master_seed=20260911)
        self.player_uuid = str(uuid4())
        self.session = self.manager.create_run(player_uuid=self.player_uuid)
        self.registry = RunActorRegistry(self.session)
        self.identity = RuntimeIdentity(self.player_uuid, self.session.identity.run_uuid, "actor:player")
        self.npc_identity = RuntimeIdentity(self.player_uuid, self.session.identity.run_uuid, "actor:npc")
        self.registry.register(self.identity, actor_definition_id="actor-def:player")
        self.registry.register(self.npc_identity, actor_definition_id="actor-def:npc")
        self.sense = BoundSense(
            lineage_id="lineage:human",
            hook_id="sense:eye",
            modality="visual",
            profile=SenseProfile("profile:eye", "visual", ("constraint:light",)),
            expression=Expression.ACTIVE,
            evidence_refs=("static:sense",),
            condition_refs=(),
        )
        self.limits = VisualLimits("profile:eye", 20.0, 2.0)
        self.reader = PerceptionReader(
            self.session, self.registry, self.identity, sense=self.sense, limits=self.limits
        )
        self.path = PerceptionKnowledgePath(self.session, self.registry, self.identity)
        self.counter = 0

    def _record(self, *, observer: str | None = None, **conditions):
        data = {
            "distance_m": 5.0,
            "incident_illuminance_lux": 10.0,
            "line_of_sight_clear": True,
        }
        data.update(conditions)
        return {
            "run_uuid": self.session.identity.run_uuid,
            "observer_actor_instance_id": observer or self.identity.actor_instance_id,
            "subject_ref": "object:door",
            "channel": "visual",
            "lineage_id": self.sense.lineage_id,
            "hook_id": self.sense.hook_id,
            "conditions": data,
        }

    def _commit_input(self, key: str = "input:door", *, observer: str | None = None, **conditions):
        self.counter += 1
        event_id = f"KNOWLEDGE:INPUT:{self.counter}"
        result = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id=event_id,
            cause="TEST_KNOWLEDGE_PERCEPTION_INPUT",
            deltas=(Delta(
                domain=Domain.WORLD_TRUTH,
                key=PERCEPTION_INPUT_WORLD_KEY,
                value={key: self._record(observer=observer, **conditions)},
                writer=Authority.RULE_KERNEL,
                cause="TEST_KNOWLEDGE_PERCEPTION_INPUT",
                source_event_id=event_id,
            ),),
        ))
        self.assertIsInstance(result, CommitRecord)
        return self.reader.project(perception_input_id=key, subject_ref="object:door")

    def test_detected_observation_commits_actor_knowledge_not_player_knowledge(self):
        observation = self._commit_input()
        self.assertEqual(observation.detection, PerceptionDetection.DETECTED)
        before = self.session.store.revision
        receipt = self.path.commit_observation(observation)
        self.assertEqual(receipt.status, KnowledgeCommitStatus.COMMITTED)
        self.assertEqual(self.session.store.revision, before + 1)
        self.assertIn(receipt.knowledge_key, self.session.store.actor_knowledge["actor:player"])
        record = self.session.store.actor_knowledge["actor:player"][receipt.knowledge_key]
        self.assertEqual(record["value"]["signal_detected"], True)
        self.assertEqual(record["value"]["subject_ref"], "object:door")
        self.assertEqual(record["epistemic"]["source_type"], "SENSOR")
        self.assertEqual(record["epistemic"]["source_id"], "sense:eye")
        self.assertEqual(self.session.store.player_knowledge, {})

    def test_not_detected_does_not_create_knowledge_or_revision(self):
        observation = self._commit_input(line_of_sight_clear=False)
        self.assertEqual(observation.detection, PerceptionDetection.NOT_DETECTED)
        before_rev = self.session.store.revision
        before_hash = self.session.store.state_hash()
        receipt = self.path.commit_observation(observation)
        self.assertEqual(receipt.status, KnowledgeCommitStatus.NO_KNOWLEDGE)
        self.assertEqual(receipt.reason_codes, ("PERCEPTION_NOT_DETECTED_NO_KNOWLEDGE",))
        self.assertEqual(self.session.store.revision, before_rev)
        self.assertEqual(self.session.store.state_hash(), before_hash)
        self.assertEqual(self.session.store.actor_knowledge, {})

    def test_unresolved_does_not_create_knowledge(self):
        observation = self.reader.project(perception_input_id="input:missing", subject_ref="object:door")
        self.assertEqual(observation.detection, PerceptionDetection.UNRESOLVED)
        before = self.session.store.state_hash()
        receipt = self.path.commit_observation(observation)
        self.assertEqual(receipt.status, KnowledgeCommitStatus.NO_KNOWLEDGE)
        self.assertEqual(receipt.reason_codes, ("PERCEPTION_UNRESOLVED_NO_KNOWLEDGE",))
        self.assertEqual(self.session.store.state_hash(), before)

    def test_observation_cannot_be_committed_by_different_actor_path(self):
        observation = self._commit_input()
        npc_path = PerceptionKnowledgePath(self.session, self.registry, self.npc_identity)
        with self.assertRaisesRegex(Stage9KnowledgeError, "KNOWLEDGE_OBSERVER_MISMATCH"):
            npc_path.commit_observation(observation)

    def test_unregistered_actor_cannot_construct_knowledge_path(self):
        ghost = RuntimeIdentity(self.player_uuid, self.session.identity.run_uuid, "actor:ghost")
        with self.assertRaises(Stage9KnowledgeError) as ctx:
            PerceptionKnowledgePath(self.session, self.registry, ghost)
        self.assertIn("ACTOR_NOT_REGISTERED_IN_RUN", str(ctx.exception))

    def test_stale_observation_is_authority_rejected_without_mutation(self):
        observation = self._commit_input()
        event_id = "KNOWLEDGE:UNRELATED"
        result = self.session.kernel.process(Proposal(
            mode=Mode.COMMIT,
            source=Authority.COMMIT_KERNEL,
            event_id=event_id,
            cause="TEST_UNRELATED_MUTATION",
            deltas=(Delta(
                domain=Domain.RUNTIME_STATE,
                key="test:unrelated",
                value=1,
                writer=Authority.RULE_KERNEL,
                cause="TEST_UNRELATED_MUTATION",
                source_event_id=event_id,
            ),),
        ))
        self.assertIsInstance(result, CommitRecord)
        before = self.session.store.state_hash()
        receipt = self.path.commit_observation(observation)
        self.assertEqual(receipt.status, KnowledgeCommitStatus.AUTHORITY_REJECTED)
        self.assertEqual(receipt.reason_codes, ("STALE_STATE_REVISION",))
        self.assertEqual(self.session.store.state_hash(), before)
        self.assertEqual(self.session.store.actor_knowledge, {})

    def test_exact_retry_is_idempotent_even_after_revision_advanced(self):
        observation = self._commit_input()
        first = self.path.commit_observation(observation)
        self.assertEqual(first.status, KnowledgeCommitStatus.COMMITTED)
        revision = self.session.store.revision
        state_hash = self.session.store.state_hash()
        second = self.path.commit_observation(observation)
        self.assertEqual(second.status, KnowledgeCommitStatus.IDEMPOTENT)
        self.assertEqual(second.reason_codes, ("KNOWLEDGE_ALREADY_COMMITTED",))
        self.assertEqual(self.session.store.revision, revision)
        self.assertEqual(self.session.store.state_hash(), state_hash)

    def test_save_load_preserves_knowledge_and_retry_idempotency(self):
        observation = self._commit_input()
        first = self.path.commit_observation(observation)
        self.assertEqual(first.status, KnowledgeCommitStatus.COMMITTED)
        with tempfile.TemporaryDirectory() as td:
            repo = FilesystemRunRepository(Path(td))
            repo.save(self.session)
            ident = self.session.identity
            self.manager.close_run(player_uuid=ident.player_uuid, run_uuid=ident.run_uuid)
            loaded = repo.load_session(self.manager, ident)
            loaded_registry = RunActorRegistry(loaded)
            loaded_path = PerceptionKnowledgePath(loaded, loaded_registry, self.identity)
            before_rev = loaded.store.revision
            before_hash = loaded.store.state_hash()
            retry = loaded_path.commit_observation(observation)
            self.assertEqual(retry.status, KnowledgeCommitStatus.IDEMPOTENT)
            self.assertEqual(loaded.store.revision, before_rev)
            self.assertEqual(loaded.store.state_hash(), before_hash)
            self.assertIn(first.knowledge_key, loaded.store.actor_knowledge["actor:player"])
            self.assertEqual(loaded.store.player_knowledge, {})

    def test_cross_run_observation_rejected(self):
        observation = self._commit_input()
        other = self.manager.create_run(player_uuid=self.player_uuid)
        other_registry = RunActorRegistry(other)
        other_identity = RuntimeIdentity(self.player_uuid, other.identity.run_uuid, "actor:player")
        other_registry.register(other_identity, actor_definition_id="actor-def:player")
        other_path = PerceptionKnowledgePath(other, other_registry, other_identity)
        with self.assertRaisesRegex(Stage9KnowledgeError, "RUN_ISOLATION_VIOLATION"):
            other_path.commit_observation(observation)
        self.assertEqual(other.store.actor_knowledge, {})

    def test_proposal_is_closed_and_does_not_copy_raw_perception_conditions(self):
        observation = self._commit_input()
        proposal = self.path.propose(observation)
        self.assertEqual(proposal.effect_type.value, "WRITE_KNOWLEDGE")
        self.assertEqual(proposal.target_ref, "actor:player")
        self.assertEqual(proposal.payload["actor_instance_id"], "actor:player")
        self.assertEqual(
            set(proposal.payload["value"]),
            {"signal_detected", "subject_ref", "channel", "source_hook_id"},
        )
        self.assertNotIn("conditions", proposal.payload["value"])
        self.assertNotIn("reasons", proposal.payload["value"])
        self.assertNotIn("world_truth", proposal.payload["value"])

    def test_player_character_namespace_is_actor_knowledge_only(self):
        observation = self._commit_input()
        self.path.commit_observation(observation)
        self.assertIn("actor:player", self.session.store.actor_knowledge)
        self.assertEqual(self.session.store.player_knowledge, {})

    def test_generic_knowledge_adapter_rejects_wrong_run_registry(self):
        other = self.manager.create_run(player_uuid=self.player_uuid)
        other_registry = RunActorRegistry(other)
        with self.assertRaisesRegex(Stage9KnowledgeError, "ACTOR_REGISTRY_RUN_MISMATCH"):
            KnowledgeCommitAdapter(self.session, actor_registry=other_registry)


if __name__ == "__main__":
    unittest.main(verbosity=2)
