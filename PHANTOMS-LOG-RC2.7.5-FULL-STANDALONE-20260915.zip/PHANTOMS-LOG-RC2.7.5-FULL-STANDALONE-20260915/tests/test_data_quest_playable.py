from pathlib import Path
from collections import deque
import tempfile, unittest
from playable_full_version.playable.game import FullVersionGame
from runtime.stage3a.kernel import Authority, CommitRecord, Delta, Domain, Mode, Proposal

ROOT=Path(__file__).resolve().parents[1]
class DataQuestPlayableTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.g=FullVersionGame(core_root=ROOT,saves_root=Path(self.tmp.name),start_class='OPERATOR',master_seed=20260913)
        draft=self.g.creation_template(); draft['skills']['SKILL_NETWORKS']=10
        self.g.complete_character(draft); self.addCleanup(self.g.images.close)
    def path(self,target):
        start=self.g.location(); q=deque([(start,[])]); seen={start}
        while q:
            here,path=q.popleft()
            if here==target:
                for step in path:
                    txt,_=self.g.handle('/go '+step); self.assertIn('COMMITTED',txt)
                return
            for nxt in self.g.catalog.location(here)['connections']:
                if nxt not in seen: seen.add(nxt); q.append((nxt,path+[nxt]))
        self.fail('route')
    def first_location(self,category):
        return next(x['location_id'] for x in self.g.catalog.world['locations'] if x['primary_category']==category)
    def npc_with_role(self,roles):
        for inst in self.g.actor_registry.instances():
            if inst.actor_instance_id=='actor:player': continue
            r=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,inst.actor_instance_id)
            if isinstance(r,dict) and r.get('role') in roles: return inst.actor_instance_id,r
        self.fail('npc')
    def test_data_terminal_reads_owned_data_into_knowledge(self):
        # Data-terminal behavior is tested with an explicit fixture; lifetime start no longer grants class loot.
        data_id='item:test:data-terminal'
        item={'run_uuid':self.g.identity.run_uuid,'kind':'item','item_definition_id':'item_def:data:016','location_ref':'inventory:actor:player','owner_actor_instance_id':'actor:player','condition':100,'max_condition':100,'provenance':'TEST_ONLY'}
        event='TEST_DATA_TERMINAL_FIXTURE'
        r=self.g.session.kernel.process(Proposal(mode=Mode.COMMIT,source=Authority.COMMIT_KERNEL,deltas=(Delta(Domain.RUNTIME_STATE,data_id,item,Authority.RULE_KERNEL,'TEST_FIXTURE',source_event_id=event,provenance='TEST_ONLY'),),event_id=event,cause='TEST_FIXTURE',expected_state_revision=self.g.session.store.revision))
        self.assertIsInstance(r,CommitRecord)
        if not self.g.data_runtime.terminals(self.g.location()):
            self.path(self.first_location('industrial_maintenance'))
        txt,_=self.g.handle('/read '+data_id)
        self.assertIn('Datensatz',txt)
        contents=self.g.data_runtime.contents[item['item_definition_id']]
        k='data_read:'+contents['content_id']
        value=self.g.session.kernel.read(Authority.KNOWLEDGE_ROUTER,Domain.ACTOR_KNOWLEDGE,k,actor_id='actor:player')
        self.assertIsInstance(value,dict); self.assertEqual(value['value']['content_id'],contents['content_id'])
    def test_search_discovery_unlocks_real_questgiver_and_accept(self):
        industrial=self.first_location('industrial_maintenance'); self.path(industrial)
        for _ in range(4): self.g.handle('/search')
        discovery=self.g.session.kernel.read(Authority.KNOWLEDGE_ROUTER,Domain.ACTOR_KNOWLEDGE,'event:pump_pressure',actor_id='actor:player')
        self.assertIsInstance(discovery,dict)
        npc_id,npc=self.npc_with_role({'technician','mechanic'}); self.path(npc['location_ref'])
        talk,_=self.g.handle('/talk '+npc_id)
        self.assertIn('Q_PUMP_CRISIS',talk)
        quests=[(qid,r) for qid,r in self.g.quest_runtime.active() if r['template_id']=='Q_PUMP_CRISIS']
        self.assertEqual(len(quests),1); qid,rec=quests[0]; self.assertEqual(rec['state'],'AVAILABLE')
        accepted,_=self.g.handle('/accept '+qid); self.assertIn('COMMITTED',accepted)
        rec=self.g.session.kernel.read(Authority.COMMIT_KERNEL,Domain.RUNTIME_STATE,qid); self.assertEqual(rec['state'],'ACTIVE')
