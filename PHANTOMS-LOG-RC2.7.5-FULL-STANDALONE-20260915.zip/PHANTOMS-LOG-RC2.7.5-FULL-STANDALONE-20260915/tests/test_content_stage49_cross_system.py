
import json,unittest
from pathlib import Path
from runtime.content_stage49.cross_system import *
ROOT=Path(__file__).resolve().parents[1]; D=json.loads((ROOT/"content/full_version/stage49_cross_system.json").read_text())
class T(unittest.TestCase):
 def test_static(self):
  raw=json.dumps(D).lower(); self.assertNotIn("player_uuid",raw); self.assertNotIn("run_uuid",raw); self.assertTrue(D["runtime_i9_frozen"])
 def test_links(self): self.assertGreaterEqual(len(D["links"]),8)
 def test_cross_effect_requires_distinct_systems(self): self.assertIsNone(cross_effect_candidate("E","a","a","X",{},"EV"))
 def test_cross_effect_authority(self): self.assertTrue(cross_effect_candidate("E","a","b","X",{},"EV")["authority_required"])
 def test_cascade_hop_authority(self): self.assertTrue(cascade_hop("E1","X","health","EV")["authority_required"])
 def test_long_term_requires_time(self): self.assertEqual(long_term_projection(10,5,0),10)
 def test_long_term_progress(self): self.assertEqual(long_term_projection(10,5,2),20)
 def test_mitigation(self): self.assertEqual(mitigate(50,20),30)
 def test_provenance_chain_valid(self):
  ev=[{"event_id":"A"},{"event_id":"B","parent_event_id":"A"},{"event_id":"C","parent_event_id":"B"}]; self.assertTrue(provenance_chain(ev))
 def test_provenance_chain_invalid(self):
  ev=[{"event_id":"A"},{"event_id":"B","parent_event_id":"X"}]; self.assertFalse(provenance_chain(ev))
 def test_duplicate_guard(self): self.assertFalse(duplicate_guard("A","X",[("A","X")]))
 def test_no_bypass_rule(self): self.assertTrue(any("cannot directly bypass" in x.lower() for x in D["rules"]))
if __name__=="__main__": unittest.main()
