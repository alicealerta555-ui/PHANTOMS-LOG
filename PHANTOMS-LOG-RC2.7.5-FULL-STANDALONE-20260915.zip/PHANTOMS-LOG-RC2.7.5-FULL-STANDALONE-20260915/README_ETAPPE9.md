# PH4NT0M5-L0G RC2.2 – Etappe 9: Predictive Routine Engine

Etappe 9 erweitert den Player-only Habit/Instinct-Layer um konservative Vorausschau.

## Kernregel

Der Charakter darf kleine, reversible Routinen vorausahnen, wenn der Spieler in sehr ähnlichen Situationen stabil dasselbe Verhalten gezeigt und daraus bereits eine Gewohnheit/Instinkt entwickelt hat.

## Niemals automatisch

- moralische Entscheidungen
- Töten/Verrat
- Fraktions- oder Storyentscheidungen
- irreversible Handlungen
- große Ressourcenentscheidungen
- riskante Gelegenheiten
- jede Situation, in der der Spieler bereits ausdrücklich etwas anderes angeordnet hat

## Umlernen

"Lass das" ist kein Schalter. Es markiert bewussten Umlernwunsch. Der alte Reflex bleibt zunächst erhalten. Erst echte Gegenpraxis verändert oder ersetzt ihn.

## Spieleroberfläche

Keine Scores, Schwellenwerte, Wahrscheinlichkeiten oder Confidence-Werte werden angezeigt. Die Runtime rechnet; der Spieler erhält nur Verhalten und Bedeutung.
