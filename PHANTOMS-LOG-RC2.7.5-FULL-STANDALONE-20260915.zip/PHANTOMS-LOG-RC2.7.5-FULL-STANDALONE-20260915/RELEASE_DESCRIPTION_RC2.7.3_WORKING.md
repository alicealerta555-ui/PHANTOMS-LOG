# PHANTOMS-LOG RC2.7.3 — Crew & Organization Working Master

RC2.7.3 turns class identity into a much clearer difference in **how the player can build and use groups**.

Breaker grows toward strong direct field groups. Ghost grows toward distributed specialist cells. Operator grows toward drones, automation, salvage, logistics and production. Resonant can grow into the strongest human organization builder, where Social capacity determines how large a structure can become while Command determines how many teams can actually be coordinated at once.

The Operator's Controller/Drohnenwart path is deliberately narrow: Networks, Electronics, Diagnostics and Attention form the core line. Later scale comes from the drones themselves. Scout, repair, network, cargo and medical-support machines provide their own bounded functions without magically raising the Operator's personal skills.

Large organizations are hierarchical rather than magical. Recruitment still needs the NPC's decision, orders are requests, and a theoretical 300+ member Resonant organization still needs real officers/deputies to carry that structure. NPC autonomy, knowledge and self-interest remain intact.

New group templates cover dungeon front groups, dungeon scouts, intelligence cells, salvage, loot recovery, drone wings, production groups, outpost construction, convoys, security patrols, rescue teams, recruitment and diplomacy. These templates connect to the existing dungeon, loot, travel, labor and industry systems instead of bypassing them.

Useful chat surfaces:

- `/crew`
- `/teamtypen`
- `/organisation gründen <Name>`
- `/org`

Validation on the final code state: **4608/4608 main tests + 23 subtests, 3025/3025 capability tests, 216/216 Stage-5 tests, all architecture/release gates PASS.**

This remains a **Working Master**, not a newly promoted Full Master or Standalone release.
