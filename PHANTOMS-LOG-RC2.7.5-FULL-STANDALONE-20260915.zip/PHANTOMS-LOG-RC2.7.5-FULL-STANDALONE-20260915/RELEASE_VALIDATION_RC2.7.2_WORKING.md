# PHANTOMS-LOG RC2.7.2 Working Validation

Date: 2026-09-15
Result: **PASS**
Classification: **WORKING MASTER validation**, not FULL-Master promotion.

## Executed test evidence

The complete `tests/test_*.py` inventory was collected as **4,598 tests**. Because the execution harness has a wall-time limit, the inventory was executed in disjoint file partitions; every test file is covered exactly once in the final accounting:

| Test-file partition | Result |
|---|---:|
| files 1–40 | 2,492 PASS |
| files 41–80 | 344 PASS |
| files 81–86 | 73 PASS + 6 subtests |
| files 87–90 | 17 PASS |
| files 91–105 | 231 PASS |
| files 106–120 | 267 PASS + 2 subtests |
| files 121–136 | 132 PASS + 15 subtests |
| files 137–152 | 1,042 PASS |
| **Total** | **4,598 PASS + 23 subtests PASS** |

Additional validation:

- capability character tree / talent scenario / class binding / action policy: **3,025 PASS**
- Stage-5 sensory suite: **216 PASS**
- `playable_full_version.playable.selftest`: **PASS**
- `compileall` over runtime, Stage-5, playable and tests: **PASS**
- capability tree audit: **PASS**
- action capability policy audit: **PASS**
- Stage-9 audits from single-writer through integrity harness: **PASS**
- full-version transition audit: **PASS**
- Stage 6, 7, 8 and 10 audits: **PASS**
- reference audit: **PASS**
- full-version master consistency audit: **PASS**
- master merge audit: **PASS**
- lifetime-start audit: **PASS**
- class-tutorial audit: **PASS**
- RC2.7.0 base-release metadata audit: **PASS**

## Environment note: fsync

The current container returns `EIO` from normal `os.fsync()` calls even for temporary test files. This is an execution-environment limitation, not a game assertion failure. Persistence tests were therefore executed with an **external test-only OS preload shim** that makes `fsync`/`fdatasync` return success. The shim is outside the project tree and is **not included in the package**. Production persistence code was not weakened or changed for this workaround.

The CLI subprocess regressions were specifically re-run under the inherited preload environment; `tests/test_playable_rc2_regressions.py` completed **38 PASS + 6 subtests PASS**.

## Tutorial acceptance

`CLASS_TUTORIAL_AUDIT=PASS` verifies:

- exactly two Level-1 talents
- both talents belong to the selected class
- +1 talent per later level contract
- automatic tutorial onboarding
- exact selected-talent targeting
- real resolver use
- zero reward/progression side effects
- skip support
- two-step tutorial schemas for BREAKER, GHOST, OPERATOR and RESONANT

## Final status

**RC2.7.2 Working Master code state: VALIDATED PASS.**

This document does not promote RC2.7.2 to FULL Master or Standalone.
